/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_layout_sr_defpg.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_layout_sr_defpg : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htCT_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htEN_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGD_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLAY_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLNK_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRD_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSEC_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcCB_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htPGML_ML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPGML_MLO = new System.Collections.Hashtable();
        private string sPGML_MLengg_page_horder = "0";
        private string sPGML_MLengg_page_vorder = "0";
        private string s_HDRfprowno = "0";
        private string sPGML_MLengg_page_toptb = "0";
        private string sPGML_MLengg_page_bottomtb = "0";
        private string sPGML_MLengg_page_lefttb = "0";
        private string sPGML_MLengg_page_righttb = "0";
        private string modeFlagValue = string.Empty;
        public Cep_layout_sr_defpg()
        {
            base.iEDKESEngineInit("ep_layout_sr_defpg", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htCT_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htCT_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvcTmp["engg_cont_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htEN_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("en_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("en_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htEN_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htEN_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htEN_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvcTmp["engg_enum_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("en_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGD_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("gd_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("gd_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htGD_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGD_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGD_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvcTmp["engg_grid_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("gd_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLAY_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lay_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lay_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htLAY_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLAY_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLAY_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvcTmp["engg_lay_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lay_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLNK_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lnk_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lnk_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htLNK_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLNK_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLNK_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvcTmp["engg_lnk_page_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lnk_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRD_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rd_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rd_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htRD_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRD_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRD_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvcTmp["engg_radio_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rd_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSEC_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sec_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sec_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htSEC_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSEC_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSEC_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvcTmp["engg_sec_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sec_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvcCB_HDR != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cb_hdr", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cb_hdr");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvcCB_HDR["engg_cont_page_bts"]));
                    this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvcCB_HDR["engg_enum_page_bts"]));
                    this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvcCB_HDR["engg_grid_page_bts"]));
                    this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvcCB_HDR["engg_lay_page_bts"]));
                    this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvcCB_HDR["engg_lnk_page_descr"]));
                    this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvcCB_HDR["engg_radio_page_bts"]));
                    this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvcCB_HDR["engg_sec_page_bts"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("cb_hdr", nvcCB_HDR);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htPGML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pgml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pgml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htPGML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htPGML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPGML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_hdr_pos", System.Convert.ToString(nvcTmp["engg_hdr_pos"]));
                            this.writer.WriteAttributeString("engg_pag_lay_con", System.Convert.ToString(nvcTmp["engg_pag_lay_con"]));
                            this.writer.WriteAttributeString("engg_page_bottomtb", System.Convert.ToString(nvcTmp["engg_page_bottomtb"]));
                            this.writer.WriteAttributeString("engg_page_btsynname", System.Convert.ToString(nvcTmp["engg_page_btsynname"]));
                            this.writer.WriteAttributeString("engg_page_descr", System.Convert.ToString(nvcTmp["engg_page_descr"]));
                            this.writer.WriteAttributeString("engg_page_doc", System.Convert.ToString(nvcTmp["engg_page_doc"]));
                            this.writer.WriteAttributeString("engg_page_horder", System.Convert.ToString(nvcTmp["engg_page_horder"]));
                            this.writer.WriteAttributeString("engg_page_img", System.Convert.ToString(nvcTmp["engg_page_img"]));
                            this.writer.WriteAttributeString("engg_page_lay", System.Convert.ToString(nvcTmp["engg_page_lay"]));
                            this.writer.WriteAttributeString("engg_page_lefttb", System.Convert.ToString(nvcTmp["engg_page_lefttb"]));
                            this.writer.WriteAttributeString("engg_page_righttb", System.Convert.ToString(nvcTmp["engg_page_righttb"]));
                            this.writer.WriteAttributeString("engg_page_toptb", System.Convert.ToString(nvcTmp["engg_page_toptb"]));
                            this.writer.WriteAttributeString("engg_page_type", System.Convert.ToString(nvcTmp["engg_page_type"]));
                            this.writer.WriteAttributeString("engg_page_vorder", System.Convert.ToString(nvcTmp["engg_page_vorder"]));
                            this.writer.WriteAttributeString("engg_tab_icon_pos", System.Convert.ToString(nvcTmp["engg_tab_icon_pos"]));
                            this.writer.WriteAttributeString("engg_tab_rot", System.Convert.ToString(nvcTmp["engg_tab_rot"]));
                            this.writer.WriteAttributeString("engg_tab_title_st", System.Convert.ToString(nvcTmp["engg_tab_title_st"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pgml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hdr":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HDR[DataItem] = DIValue;
                        return 0;
                    case "cb_hdr":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lay_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lnk_page_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcCB_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcCB_HDR[DataItem] = DIValue;
                        return 0;
                    case "pgml_ml":
                        switch (DataItem)
                        {
                            case "engg_page_bottomtb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_page_btsynname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_doc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_horder":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_page_img":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_lefttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_page_righttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_page_toptb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_page_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_vorder":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htPGML_ML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htPGML_ML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htPGML_ML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htPGML_ML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    type = 1;
                    break;
                case "en_pg_cb":
                    type = 1;
                    break;
                case "gd_pg_cb":
                    type = 1;
                    break;
                case "lay_pg_cb":
                    type = 1;
                    break;
                case "lnk_pg_cb":
                    type = 1;
                    break;
                case "rd_pg_cb":
                    type = 1;
                    break;
                case "sec_pg_cb":
                    type = 1;
                    break;
                case "_hdr":
                    type = 0;
                    break;
                case "cb_hdr":
                    type = 0;
                    break;
                case "pgml_ml":
                    type = 1;
                    break;
                case "pgml_mlo":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    return htCT_PG_CB.Count;
                    break;
                case "en_pg_cb":
                    return htEN_PG_CB.Count;
                    break;
                case "gd_pg_cb":
                    return htGD_PG_CB.Count;
                    break;
                case "lay_pg_cb":
                    return htLAY_PG_CB.Count;
                    break;
                case "lnk_pg_cb":
                    return htLNK_PG_CB.Count;
                    break;
                case "rd_pg_cb":
                    return htRD_PG_CB.Count;
                    break;
                case "sec_pg_cb":
                    return htSEC_PG_CB.Count;
                    break;
                case "pgml_ml":
                    return htPGML_ML.Count;
                    break;
                case "pgml_mlo":
                    return htPGML_MLO.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    return this.htCT_PG_CB;
                case "en_pg_cb":
                    return this.htEN_PG_CB;
                case "gd_pg_cb":
                    return this.htGD_PG_CB;
                case "lay_pg_cb":
                    return this.htLAY_PG_CB;
                case "lnk_pg_cb":
                    return this.htLNK_PG_CB;
                case "rd_pg_cb":
                    return this.htRD_PG_CB;
                case "sec_pg_cb":
                    return this.htSEC_PG_CB;
                case "pgml_ml":
                    return this.htPGML_ML;
                case "pgml_mlo":
                    return this.htPGML_MLO;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hdr":
                    return this.nvc_HDR;
                case "cb_hdr":
                    return this.nvcCB_HDR;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "ct_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_pg_cb = (NameValueCollection)htCT_PG_CB[lnInstNumber];
                        return nvcTmpct_pg_cb[szDataItem];
                        break;
                    case "en_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpen_pg_cb = (NameValueCollection)htEN_PG_CB[lnInstNumber];
                        return nvcTmpen_pg_cb[szDataItem];
                        break;
                    case "gd_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgd_pg_cb = (NameValueCollection)htGD_PG_CB[lnInstNumber];
                        return nvcTmpgd_pg_cb[szDataItem];
                        break;
                    case "lay_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmplay_pg_cb = (NameValueCollection)htLAY_PG_CB[lnInstNumber];
                        return nvcTmplay_pg_cb[szDataItem];
                        break;
                    case "lnk_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmplnk_pg_cb = (NameValueCollection)htLNK_PG_CB[lnInstNumber];
                        return nvcTmplnk_pg_cb[szDataItem];
                        break;
                    case "rd_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmprd_pg_cb = (NameValueCollection)htRD_PG_CB[lnInstNumber];
                        return nvcTmprd_pg_cb[szDataItem];
                        break;
                    case "sec_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpsec_pg_cb = (NameValueCollection)htSEC_PG_CB[lnInstNumber];
                        return nvcTmpsec_pg_cb[szDataItem];
                        break;
                    case "_hdr":
                        return nvc_HDR[szDataItem];
                        break;
                    case "cb_hdr":
                        return nvcCB_HDR[szDataItem];
                        break;
                    case "pgml_ml":
                        System.Collections.Specialized.NameValueCollection nvcTmppgml_ml = (NameValueCollection)htPGML_ML[lnInstNumber];
                        return nvcTmppgml_ml[szDataItem];
                        break;
                    case "pgml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmppgml_mlo = (NameValueCollection)htPGML_MLO[lnInstNumber];
                        return nvcTmppgml_mlo[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_layout_sr_defpg Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                this.ProcessPS4();
                this.ProcessPS5();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_layout_sr_defpg Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpg");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpg_hsv", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpg_hsv", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61569, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61569, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("fprowno");
                                nvc_HDR["fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61569, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htPGML_ML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpg_pgml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htPGML_ML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["engg_page_btsynname"];
                            base.Parameters("@engg_page_btsynname_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["engg_page_descr"];
                            base.Parameters("@engg_page_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["engg_page_doc"];
                            base.Parameters("@engg_page_doc_in", DBType.NVarchar, 3999, sValue);
                            sValue = nvcTmp["engg_page_horder"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_horder = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_horder);
                            base.Parameters("@engg_page_horder_in", DBType.Int, 32, sPGML_MLengg_page_horder);
                            sValue = nvcTmp["engg_page_vorder"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_vorder = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_vorder);
                            base.Parameters("@engg_page_vorder_in", DBType.Int, 32, sPGML_MLengg_page_vorder);
                            sValue = nvcTmp["engg_page_type"];
                            base.Parameters("@engg_page_type_in", DBType.NVarchar, 20, sValue);
                            sValue = nvcTmp["engg_page_img"];
                            base.Parameters("@engg_page_img_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag_in", DBType.NVarchar, 2, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_io", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvcTmp["engg_page_toptb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_toptb = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_toptb);
                            base.Parameters("@engg_page_toptb", DBType.Int, 32, sPGML_MLengg_page_toptb);
                            sValue = nvcTmp["engg_page_bottomtb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_bottomtb = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_bottomtb);
                            base.Parameters("@engg_page_bottomtb", DBType.Int, 32, sPGML_MLengg_page_bottomtb);
                            sValue = nvcTmp["engg_page_lefttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_lefttb = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_lefttb);
                            base.Parameters("@engg_page_lefttb", DBType.Int, 32, sPGML_MLengg_page_lefttb);
                            sValue = nvcTmp["engg_page_righttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sPGML_MLengg_page_righttb = (Double.TryParse(sValue, out result) == true ? sValue : sPGML_MLengg_page_righttb);
                            base.Parameters("@engg_page_righttb", DBType.Int, 32, sPGML_MLengg_page_righttb);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgpgml", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgpgml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61570, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61570, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("fprowno_io");
                                nvc_HDR["fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61570, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgct_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgct_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61571, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61571, 3, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_page_bts");
                                    nvcTmp["engg_cont_page_bts"] = sValue;
                                    htCT_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61571, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 2  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgen_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgen_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61572, 3, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61572, 3, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htEN_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_page_bts");
                                    nvcTmp["engg_enum_page_bts"] = sValue;
                                    htEN_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61572, 3, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 3  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpggd_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpggd_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61573, 3, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61573, 3, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGD_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_page_bts");
                                    nvcTmp["engg_grid_page_bts"] = sValue;
                                    htGD_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61573, 3, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 4  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpglay_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpglay_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61574, 3, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61574, 3, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLAY_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_page_bts");
                                    nvcTmp["engg_lay_page_bts"] = sValue;
                                    htLAY_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61574, 3, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 5  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpglnk_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpglnk_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61575, 3, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61575, 3, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLNK_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lnk_page_descr");
                                    nvcTmp["engg_lnk_page_descr"] = sValue;
                                    htLNK_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61575, 3, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 6  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgrd_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgrd_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61576, 3, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61576, 3, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRD_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_page_bts");
                                    nvcTmp["engg_radio_page_bts"] = sValue;
                                    htRD_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61576, 3, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 7  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbload");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgsec_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgsec_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61577, 3, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61577, 3, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSEC_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sec_page_bts");
                                    nvcTmp["engg_sec_page_bts"] = sValue;
                                    htSEC_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61577, 3, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS4()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 4;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 4
                // Starting to execute the BR - 1  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpgcbdef");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvcCB_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            sValue = nvcCB_HDR["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts_io", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts_io", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts_io", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts_io", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr_io", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_radio_page_bts"];
                            base.Parameters("@engg_radpage_bts_io", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts_io", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgcbdef", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgcbdef", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61578, 4, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61578, 4, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_cont_page_bts_io");
                                nvcCB_HDR["engg_cont_page_bts"] = sValue;
                                sValue = this.GetValue("engg_enum_page_bts_io");
                                nvcCB_HDR["engg_enum_page_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_page_bts_io");
                                nvcCB_HDR["engg_grid_page_bts"] = sValue;
                                sValue = this.GetValue("engg_lay_page_bts_io");
                                nvcCB_HDR["engg_lay_page_bts"] = sValue;
                                sValue = this.GetValue("engg_lnk_page_descr_io");
                                nvcCB_HDR["engg_lnk_page_descr"] = sValue;
                                sValue = this.GetValue("engg_radpage_bts_io");
                                nvcCB_HDR["engg_radio_page_bts"] = sValue;
                                sValue = this.GetValue("engg_sec_page_bts_io");
                                nvcCB_HDR["engg_sec_page_bts"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61578, 4, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS5()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 5;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 5
                // Starting to execute the BR - 1  under the process section - 5
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 5;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_defpg_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 5 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_defpgpgml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_defpgpgml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61579, 5, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61579, 5, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPGML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_hdr_pos");
                                    nvcTmp["engg_hdr_pos"] = sValue;
                                    sValue = this.GetValue("engg_pag_lay_con");
                                    nvcTmp["engg_pag_lay_con"] = sValue;
                                    sValue = this.GetValue("engg_page_bottomtb");
                                    nvcTmp["engg_page_bottomtb"] = sValue;
                                    sValue = this.GetValue("engg_page_btsynname");
                                    nvcTmp["engg_page_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_page_descr");
                                    nvcTmp["engg_page_descr"] = sValue;
                                    sValue = this.GetValue("engg_page_doc");
                                    nvcTmp["engg_page_doc"] = sValue;
                                    sValue = this.GetValue("engg_page_horder");
                                    nvcTmp["engg_page_horder"] = sValue;
                                    sValue = this.GetValue("engg_page_img");
                                    nvcTmp["engg_page_img"] = sValue;
                                    sValue = this.GetValue("engg_page_lay");
                                    nvcTmp["engg_page_lay"] = sValue;
                                    sValue = this.GetValue("engg_page_lefttb");
                                    nvcTmp["engg_page_lefttb"] = sValue;
                                    sValue = this.GetValue("engg_page_righttb");
                                    nvcTmp["engg_page_righttb"] = sValue;
                                    sValue = this.GetValue("engg_page_toptb");
                                    nvcTmp["engg_page_toptb"] = sValue;
                                    sValue = this.GetValue("engg_page_type");
                                    nvcTmp["engg_page_type"] = sValue;
                                    sValue = this.GetValue("engg_page_vorder");
                                    nvcTmp["engg_page_vorder"] = sValue;
                                    sValue = this.GetValue("engg_tab_icon_pos");
                                    nvcTmp["engg_tab_icon_pos"] = sValue;
                                    sValue = this.GetValue("engg_tab_rot");
                                    nvcTmp["engg_tab_rot"] = sValue;
                                    sValue = this.GetValue("engg_tab_title_st");
                                    nvcTmp["engg_tab_title_st"] = sValue;
                                    htPGML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 5 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61579, 5, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 5 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "ct_pg_cb":
                            Localtable = (NameValueCollection)htCT_PG_CB[lInstance];
                            break;
                        case "en_pg_cb":
                            Localtable = (NameValueCollection)htEN_PG_CB[lInstance];
                            break;
                        case "gd_pg_cb":
                            Localtable = (NameValueCollection)htGD_PG_CB[lInstance];
                            break;
                        case "lay_pg_cb":
                            Localtable = (NameValueCollection)htLAY_PG_CB[lInstance];
                            break;
                        case "lnk_pg_cb":
                            Localtable = (NameValueCollection)htLNK_PG_CB[lInstance];
                            break;
                        case "rd_pg_cb":
                            Localtable = (NameValueCollection)htRD_PG_CB[lInstance];
                            break;
                        case "sec_pg_cb":
                            Localtable = (NameValueCollection)htSEC_PG_CB[lInstance];
                            break;
                        case "_hdr":
                            Localtable = nvc_HDR;
                            break;
                        case "cb_hdr":
                            Localtable = nvcCB_HDR;
                            break;
                        case "pgml_ml":
                            Localtable = (NameValueCollection)htPGML_ML[lInstance];
                            break;
                        case "pgml_mlo":
                            Localtable = (NameValueCollection)htPGML_MLO[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_layout_sr_defpg(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_layout_sr_defpg(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_layout_sr_defpg.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

