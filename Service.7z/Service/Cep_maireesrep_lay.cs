/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_maireesrep_lay.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_maireesrep_lay : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htCCBR_LAUNCHTYPE = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCCBR_UISUBTYPE = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGCTR_CBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGGRP_CBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGPAG_CBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGSEC_CBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_DCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_ECBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_GCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_ICBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_KCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_NCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_OCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_PCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_SCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGDICBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGIOCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGLACBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGRACBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSEC_PGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable ht_SECMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGGRD_MLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_CMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_LMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_MMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_RMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_YMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGADMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGPAMLOUT = new System.Collections.Hashtable();
        private string s_HSEGengg_tab_height = "0";
        private string s_HSEGengg_lefttb = "0";
        private string s_HSEGengg_righttb = "0";
        private string s_HSEGengg_toptb = "0";
        private string s_HSEGengg_bottomtb = "0";
        private string s_HSEGengg_att_sidebar = "0";
        private string s_HSEGenggad_fprowno = "0";
        private string s_HSEGenggpa_fprowno = "0";
        private string s_HSEGengg_c_fprowno = "0";
        private string s_HSEGengg_l_fprowno = "0";
        private string s_HSEGengg_m_fprowno = "0";
        private string s_HSEGengg_r_fprowno = "0";
        private string s_HSEGengg_y_fprowno = "0";
        private string s_HSEG_sec_fprowno = "0";
        private string modeFlagValue = string.Empty;
        public Cep_maireesrep_lay()
        {
            base.iEDKESEngineInit("ep_maireesrep_lay", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htCCBR_LAUNCHTYPE != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ccbr_launchtype", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ccbr_launchtype");
                    this.writer.WriteAttributeString("RecordCount", htCCBR_LAUNCHTYPE.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCCBR_LAUNCHTYPE.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCCBR_LAUNCHTYPE[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_launch_type", System.Convert.ToString(nvcTmp["engg_launch_type"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ccbr_launchtype", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCCBR_UISUBTYPE != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ccbr_uisubtype", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ccbr_uisubtype");
                    this.writer.WriteAttributeString("RecordCount", htCCBR_UISUBTYPE.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCCBR_UISUBTYPE.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCCBR_UISUBTYPE[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_uisubtype", System.Convert.ToString(nvcTmp["engg_uisubtype"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ccbr_uisubtype", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGCTR_CBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgctr_cbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgctr_cbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGCTR_CBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGCTR_CBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGCTR_CBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvcTmp["engg_control_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgctr_cbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGGRP_CBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cggrp_cbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cggrp_cbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGGRP_CBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGGRP_CBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGGRP_CBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvcTmp["engg_group_caption"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cggrp_cbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGPAG_CBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgpag_cbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgpag_cbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGPAG_CBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGPAG_CBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGPAG_CBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvcTmp["engg_page_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgpag_cbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGSEC_CBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgsec_cbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgsec_cbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGSEC_CBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGSEC_CBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGSEC_CBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvcTmp["engg_sect_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgsec_cbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_DCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_dcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_dcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_DCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_DCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_DCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_sec_bts", System.Convert.ToString(nvcTmp["engg_grid_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_dcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_ECBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_ecbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_ecbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_ECBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_ECBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_ECBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_btsynname", System.Convert.ToString(nvcTmp["engg_enum_btsynname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_ecbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_GCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_gcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_gcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_GCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_GCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_GCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvcTmp["engg_grid_grid_code"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_gcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_ICBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_icbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_icbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_ICBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_ICBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_ICBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvcTmp["engg_grid_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_icbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_KCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_kcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_kcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_KCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_KCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_KCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvcTmp["engg_lnk_page_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_kcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_NCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_ncbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_ncbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_NCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_NCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_NCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_cont_sec_bts", System.Convert.ToString(nvcTmp["engg_cont_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_ncbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_OCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_ocbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_ocbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_OCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_OCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_OCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvcTmp["engg_cont_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_ocbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_PCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_pcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_pcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_PCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_PCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_PCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvcTmp["engg_enum_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_pcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_SCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_scbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_scbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_SCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_SCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_SCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_sec_bts", System.Convert.ToString(nvcTmp["engg_enum_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_scbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGDICBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggdicbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggdicbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGDICBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGDICBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGDICBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvcTmp["engg_radio_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggdicbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGIOCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggiocbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggiocbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGIOCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGIOCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGIOCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_sec_bts", System.Convert.ToString(nvcTmp["engg_radio_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggiocbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGLACBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engglacbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engglacbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGLACBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGLACBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGLACBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvcTmp["engg_lay_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engglacbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGRACBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggracbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggracbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGRACBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGRACBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGRACBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_btsynname", System.Convert.ToString(nvcTmp["engg_radio_btsynname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggracbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSEC_PGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sec_pgcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sec_pgcbseg");
                    this.writer.WriteAttributeString("RecordCount", htSEC_PGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSEC_PGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSEC_PGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvcTmp["engg_sec_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sec_pgcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvc_HSEG["engg_act_descr"]));
                    this.writer.WriteAttributeString("engg_att_docked", System.Convert.ToString(nvc_HSEG["engg_att_docked"]));
                    this.writer.WriteAttributeString("engg_att_sidebar", System.Convert.ToString(nvc_HSEG["engg_att_sidebar"]));
                    this.writer.WriteAttributeString("engg_att_ui_cap_align", System.Convert.ToString(nvc_HSEG["engg_att_ui_cap_align"]));
                    this.writer.WriteAttributeString("engg_att_ui_format", System.Convert.ToString(nvc_HSEG["engg_att_ui_format"]));
                    this.writer.WriteAttributeString("engg_att_ui_grid_type", System.Convert.ToString(nvc_HSEG["engg_att_ui_grid_type"]));
                    this.writer.WriteAttributeString("engg_att_ui_trail_bar", System.Convert.ToString(nvc_HSEG["engg_att_ui_trail_bar"]));
                    this.writer.WriteAttributeString("engg_att_ui_type", System.Convert.ToString(nvc_HSEG["engg_att_ui_type"]));
                    this.writer.WriteAttributeString("engg_bottomtb", System.Convert.ToString(nvc_HSEG["engg_bottomtb"]));
                    this.writer.WriteAttributeString("engg_callout_type", System.Convert.ToString(nvc_HSEG["engg_callout_type"]));
                    this.writer.WriteAttributeString("engg_component", System.Convert.ToString(nvc_HSEG["engg_component"]));
                    this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvc_HSEG["engg_cont_page_bts"]));
                    this.writer.WriteAttributeString("engg_cont_sec_bts", System.Convert.ToString(nvc_HSEG["engg_cont_sec_bts"]));
                    this.writer.WriteAttributeString("engg_cont_sec_type_bts", System.Convert.ToString(nvc_HSEG["engg_cont_sec_type_bts"]));
                    this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvc_HSEG["engg_control_name"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HSEG["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_desk_brw", System.Convert.ToString(nvc_HSEG["engg_desk_brw"]));
                    this.writer.WriteAttributeString("engg_enum_btsynname", System.Convert.ToString(nvc_HSEG["engg_enum_btsynname"]));
                    this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvc_HSEG["engg_enum_page_bts"]));
                    this.writer.WriteAttributeString("engg_enum_sec_bts", System.Convert.ToString(nvc_HSEG["engg_enum_sec_bts"]));
                    this.writer.WriteAttributeString("engg_grid_ctrl_type_bts", System.Convert.ToString(nvc_HSEG["engg_grid_ctrl_type_bts"]));
                    this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvc_HSEG["engg_grid_grid_code"]));
                    this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvc_HSEG["engg_grid_page_bts"]));
                    this.writer.WriteAttributeString("engg_grid_sec_bts", System.Convert.ToString(nvc_HSEG["engg_grid_sec_bts"]));
                    this.writer.WriteAttributeString("engg_grid_sec_type_bts", System.Convert.ToString(nvc_HSEG["engg_grid_sec_type_bts"]));
                    this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvc_HSEG["engg_group_caption"]));
                    this.writer.WriteAttributeString("engg_group_name", System.Convert.ToString(nvc_HSEG["engg_group_name"]));
                    this.writer.WriteAttributeString("engg_hdrpersonalisation", System.Convert.ToString(nvc_HSEG["engg_hdrpersonalisation"]));
                    this.writer.WriteAttributeString("engg_hide_print", System.Convert.ToString(nvc_HSEG["engg_hide_print"]));
                    this.writer.WriteAttributeString("engg_ilbotitle", System.Convert.ToString(nvc_HSEG["engg_ilbotitle"]));
                    this.writer.WriteAttributeString("engg_impdefault", System.Convert.ToString(nvc_HSEG["engg_impdefault"]));
                    this.writer.WriteAttributeString("engg_isdevice", System.Convert.ToString(nvc_HSEG["engg_isdevice"]));
                    this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvc_HSEG["engg_lay_page_bts"]));
                    this.writer.WriteAttributeString("engg_lefttb", System.Convert.ToString(nvc_HSEG["engg_lefttb"]));
                    this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvc_HSEG["engg_lnk_page_descr"]));
                    this.writer.WriteAttributeString("engg_nativeapp", System.Convert.ToString(nvc_HSEG["engg_nativeapp"]));
                    this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvc_HSEG["engg_page_name"]));
                    this.writer.WriteAttributeString("engg_phone", System.Convert.ToString(nvc_HSEG["engg_phone"]));
                    this.writer.WriteAttributeString("engg_popup_close", System.Convert.ToString(nvc_HSEG["engg_popup_close"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HSEG["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HSEG["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_radio_btsynname", System.Convert.ToString(nvc_HSEG["engg_radio_btsynname"]));
                    this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvc_HSEG["engg_radio_page_bts"]));
                    this.writer.WriteAttributeString("engg_radio_sec_bts", System.Convert.ToString(nvc_HSEG["engg_radio_sec_bts"]));
                    this.writer.WriteAttributeString("engg_req_no", System.Convert.ToString(nvc_HSEG["engg_req_no"]));
                    this.writer.WriteAttributeString("engg_rf_act", System.Convert.ToString(nvc_HSEG["engg_rf_act"]));
                    this.writer.WriteAttributeString("engg_rf_comp", System.Convert.ToString(nvc_HSEG["engg_rf_comp"]));
                    this.writer.WriteAttributeString("engg_rf_ui", System.Convert.ToString(nvc_HSEG["engg_rf_ui"]));
                    this.writer.WriteAttributeString("engg_righttb", System.Convert.ToString(nvc_HSEG["engg_righttb"]));
                    this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvc_HSEG["engg_sec_page_bts"]));
                    this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvc_HSEG["engg_sect_name"]));
                    this.writer.WriteAttributeString("engg_smarthide", System.Convert.ToString(nvc_HSEG["engg_smarthide"]));
                    this.writer.WriteAttributeString("engg_syst_excl_tab_ind", System.Convert.ToString(nvc_HSEG["engg_syst_excl_tab_ind"]));
                    this.writer.WriteAttributeString("engg_tab_hdr_pos", System.Convert.ToString(nvc_HSEG["engg_tab_hdr_pos"]));
                    this.writer.WriteAttributeString("engg_tab_height", System.Convert.ToString(nvc_HSEG["engg_tab_height"]));
                    this.writer.WriteAttributeString("engg_tab_rotate", System.Convert.ToString(nvc_HSEG["engg_tab_rotate"]));
                    this.writer.WriteAttributeString("engg_tab_style", System.Convert.ToString(nvc_HSEG["engg_tab_style"]));
                    this.writer.WriteAttributeString("engg_tablet", System.Convert.ToString(nvc_HSEG["engg_tablet"]));
                    this.writer.WriteAttributeString("engg_titlebar_search", System.Convert.ToString(nvc_HSEG["engg_titlebar_search"]));
                    this.writer.WriteAttributeString("engg_toptb", System.Convert.ToString(nvc_HSEG["engg_toptb"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HSEG["engg_ui_descr"]));
                    this.writer.WriteAttributeString("engg_ui_laycon", System.Convert.ToString(nvc_HSEG["engg_ui_laycon"]));
                    this.writer.WriteAttributeString("engg_ui_layout", System.Convert.ToString(nvc_HSEG["engg_ui_layout"]));
                    this.writer.WriteAttributeString("engg_uisubtype", System.Convert.ToString(nvc_HSEG["engg_uisubtype"]));
                    this.writer.WriteAttributeString("ezee_taskpane", System.Convert.ToString(nvc_HSEG["ezee_taskpane"]));
                    this.writer.WriteAttributeString("state_processing", System.Convert.ToString(nvc_HSEG["state_processing"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.ht_SECMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_secmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_secmlout");
                    this.writer.WriteAttributeString("RecordCount", ht_SECMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= ht_SECMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)ht_SECMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_associatedcontrol", System.Convert.ToString(nvcTmp["engg_associatedcontrol"]));
                            this.writer.WriteAttributeString("engg_col_dir", System.Convert.ToString(nvcTmp["engg_col_dir"]));
                            this.writer.WriteAttributeString("engg_region", System.Convert.ToString(nvcTmp["engg_region"]));
                            this.writer.WriteAttributeString("engg_sec_bord_req", System.Convert.ToString(nvcTmp["engg_sec_bord_req"]));
                            this.writer.WriteAttributeString("engg_sec_bottomtb", System.Convert.ToString(nvcTmp["engg_sec_bottomtb"]));
                            this.writer.WriteAttributeString("engg_sec_btsynname", System.Convert.ToString(nvcTmp["engg_sec_btsynname"]));
                            this.writer.WriteAttributeString("engg_sec_cap_align", System.Convert.ToString(nvcTmp["engg_sec_cap_align"]));
                            this.writer.WriteAttributeString("engg_sec_cap_format", System.Convert.ToString(nvcTmp["engg_sec_cap_format"]));
                            this.writer.WriteAttributeString("engg_sec_descr", System.Convert.ToString(nvcTmp["engg_sec_descr"]));
                            this.writer.WriteAttributeString("engg_sec_lay_con", System.Convert.ToString(nvcTmp["engg_sec_lay_con"]));
                            this.writer.WriteAttributeString("engg_sec_lefttb", System.Convert.ToString(nvcTmp["engg_sec_lefttb"]));
                            this.writer.WriteAttributeString("engg_sec_minrows", System.Convert.ToString(nvcTmp["engg_sec_minrows"]));
                            this.writer.WriteAttributeString("engg_sec_righttb", System.Convert.ToString(nvcTmp["engg_sec_righttb"]));
                            this.writer.WriteAttributeString("engg_sec_secpreclass", System.Convert.ToString(nvcTmp["engg_sec_secpreclass"]));
                            this.writer.WriteAttributeString("engg_sec_title_align", System.Convert.ToString(nvcTmp["engg_sec_title_align"]));
                            this.writer.WriteAttributeString("engg_sec_title_req", System.Convert.ToString(nvcTmp["engg_sec_title_req"]));
                            this.writer.WriteAttributeString("engg_sec_titleaction", System.Convert.ToString(nvcTmp["engg_sec_titleaction"]));
                            this.writer.WriteAttributeString("engg_sec_titleicon", System.Convert.ToString(nvcTmp["engg_sec_titleicon"]));
                            this.writer.WriteAttributeString("engg_sec_toptb", System.Convert.ToString(nvcTmp["engg_sec_toptb"]));
                            this.writer.WriteAttributeString("engg_sec_type", System.Convert.ToString(nvcTmp["engg_sec_type"]));
                            this.writer.WriteAttributeString("engg_sec_visible", System.Convert.ToString(nvcTmp["engg_sec_visible"]));
                            this.writer.WriteAttributeString("engg_sec_vwmode", System.Convert.ToString(nvcTmp["engg_sec_vwmode"]));
                            this.writer.WriteAttributeString("engg_sect_doc", System.Convert.ToString(nvcTmp["engg_sect_doc"]));
                            this.writer.WriteAttributeString("engg_sect_lay", System.Convert.ToString(nvcTmp["engg_sect_lay"]));
                            this.writer.WriteAttributeString("engg_title_pos", System.Convert.ToString(nvcTmp["engg_title_pos"]));
                            this.writer.WriteAttributeString("sec_collapse", System.Convert.ToString(nvcTmp["sec_collapse"]));
                            this.writer.WriteAttributeString("sec_collapsemode", System.Convert.ToString(nvcTmp["sec_collapsemode"]));
                            this.writer.WriteAttributeString("section_colspan", System.Convert.ToString(nvcTmp["section_colspan"]));
                            this.writer.WriteAttributeString("section_rowspan", System.Convert.ToString(nvcTmp["section_rowspan"]));
                            this.writer.WriteAttributeString("sectionheight", System.Convert.ToString(nvcTmp["sectionheight"]));
                            this.writer.WriteAttributeString("sectionwidth", System.Convert.ToString(nvcTmp["sectionwidth"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("_secmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGGRD_MLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cggrd_mlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cggrd_mlout");
                    this.writer.WriteAttributeString("RecordCount", htCGGRD_MLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCGGRD_MLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGGRD_MLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_col_or_group", System.Convert.ToString(nvcTmp["engg_col_or_group"]));
                            this.writer.WriteAttributeString("engg_map_seq", System.Convert.ToString(nvcTmp["engg_map_seq"]));
                            this.writer.WriteAttributeString("engg_mapped_entity", System.Convert.ToString(nvcTmp["engg_mapped_entity"]));
                            this.writer.WriteAttributeString("engg_ui_map", System.Convert.ToString(nvcTmp["engg_ui_map"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cggrd_mlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_CMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_cmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_cmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_CMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_CMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_CMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("accesskey", System.Convert.ToString(nvcTmp["accesskey"]));
                            this.writer.WriteAttributeString("cont_class_ext6", System.Convert.ToString(nvcTmp["cont_class_ext6"]));
                            this.writer.WriteAttributeString("ctrl_temp_cat", System.Convert.ToString(nvcTmp["ctrl_temp_cat"]));
                            this.writer.WriteAttributeString("ctrl_temp_specific", System.Convert.ToString(nvcTmp["ctrl_temp_specific"]));
                            this.writer.WriteAttributeString("engg_cont_btsynname", System.Convert.ToString(nvcTmp["engg_cont_btsynname"]));
                            this.writer.WriteAttributeString("engg_cont_colspan", System.Convert.ToString(nvcTmp["engg_cont_colspan"]));
                            this.writer.WriteAttributeString("engg_cont_control_format", System.Convert.ToString(nvcTmp["engg_cont_control_format"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlclass", System.Convert.ToString(nvcTmp["engg_cont_ctrlclass"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlimg", System.Convert.ToString(nvcTmp["engg_cont_ctrlimg"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlimgclass", System.Convert.ToString(nvcTmp["engg_cont_ctrlimgclass"]));
                            this.writer.WriteAttributeString("engg_cont_datawidth", System.Convert.ToString(nvcTmp["engg_cont_datawidth"]));
                            this.writer.WriteAttributeString("engg_cont_descr", System.Convert.ToString(nvcTmp["engg_cont_descr"]));
                            this.writer.WriteAttributeString("engg_cont_doc", System.Convert.ToString(nvcTmp["engg_cont_doc"]));
                            this.writer.WriteAttributeString("engg_cont_elem_type", System.Convert.ToString(nvcTmp["engg_cont_elem_type"]));
                            this.writer.WriteAttributeString("engg_cont_helptabstop", System.Convert.ToString(nvcTmp["engg_cont_helptabstop"]));
                            this.writer.WriteAttributeString("engg_cont_horder", System.Convert.ToString(nvcTmp["engg_cont_horder"]));
                            this.writer.WriteAttributeString("engg_cont_labclass", System.Convert.ToString(nvcTmp["engg_cont_labclass"]));
                            this.writer.WriteAttributeString("engg_cont_labimgclass", System.Convert.ToString(nvcTmp["engg_cont_labimgclass"]));
                            this.writer.WriteAttributeString("engg_cont_labwidth", System.Convert.ToString(nvcTmp["engg_cont_labwidth"]));
                            this.writer.WriteAttributeString("engg_cont_rowspan", System.Convert.ToString(nvcTmp["engg_cont_rowspan"]));
                            this.writer.WriteAttributeString("engg_cont_samp_data", System.Convert.ToString(nvcTmp["engg_cont_samp_data"]));
                            this.writer.WriteAttributeString("engg_cont_sequence", System.Convert.ToString(nvcTmp["engg_cont_sequence"]));
                            this.writer.WriteAttributeString("engg_cont_tabseq", System.Convert.ToString(nvcTmp["engg_cont_tabseq"]));
                            this.writer.WriteAttributeString("engg_cont_tempid", System.Convert.ToString(nvcTmp["engg_cont_tempid"]));
                            this.writer.WriteAttributeString("engg_cont_tooltip", System.Convert.ToString(nvcTmp["engg_cont_tooltip"]));
                            this.writer.WriteAttributeString("engg_cont_vis_length", System.Convert.ToString(nvcTmp["engg_cont_vis_length"]));
                            this.writer.WriteAttributeString("engg_cont_vorder", System.Convert.ToString(nvcTmp["engg_cont_vorder"]));
                            this.writer.WriteAttributeString("engg_dynamicstyle", System.Convert.ToString(nvcTmp["engg_dynamicstyle"]));
                            this.writer.WriteAttributeString("engg_imageasdata", System.Convert.ToString(nvcTmp["engg_imageasdata"]));
                            this.writer.WriteAttributeString("engg_msc_ass_control", System.Convert.ToString(nvcTmp["engg_msc_ass_control"]));
                            this.writer.WriteAttributeString("icon_class", System.Convert.ToString(nvcTmp["icon_class"]));
                            this.writer.WriteAttributeString("icon_position", System.Convert.ToString(nvcTmp["icon_position"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_cmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_LMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_lmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_lmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_LMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_LMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_LMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_launch_type", System.Convert.ToString(nvcTmp["engg_launch_type"]));
                            this.writer.WriteAttributeString("engg_links_assoctrl", System.Convert.ToString(nvcTmp["engg_links_assoctrl"]));
                            this.writer.WriteAttributeString("engg_links_height", System.Convert.ToString(nvcTmp["engg_links_height"]));
                            this.writer.WriteAttributeString("engg_links_link_act", System.Convert.ToString(nvcTmp["engg_links_link_act"]));
                            this.writer.WriteAttributeString("engg_links_link_comp", System.Convert.ToString(nvcTmp["engg_links_link_comp"]));
                            this.writer.WriteAttributeString("engg_links_link_type", System.Convert.ToString(nvcTmp["engg_links_link_type"]));
                            this.writer.WriteAttributeString("engg_links_link_ui", System.Convert.ToString(nvcTmp["engg_links_link_ui"]));
                            this.writer.WriteAttributeString("engg_links_pcv_caption", System.Convert.ToString(nvcTmp["engg_links_pcv_caption"]));
                            this.writer.WriteAttributeString("engg_links_width", System.Convert.ToString(nvcTmp["engg_links_width"]));
                            this.writer.WriteAttributeString("engg_toolbar_notreq", System.Convert.ToString(nvcTmp["engg_toolbar_notreq"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_lmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_MMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_mmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_mmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_MMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_MMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_MMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_enum_caption", System.Convert.ToString(nvcTmp["engg_enum_caption"]));
                            this.writer.WriteAttributeString("engg_enum_code", System.Convert.ToString(nvcTmp["engg_enum_code"]));
                            this.writer.WriteAttributeString("engg_enum_default", System.Convert.ToString(nvcTmp["engg_enum_default"]));
                            this.writer.WriteAttributeString("engg_enum_seq", System.Convert.ToString(nvcTmp["engg_enum_seq"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_mmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_RMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_rmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_rmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_RMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_RMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_RMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("col_associate_ctrl", System.Convert.ToString(nvcTmp["col_associate_ctrl"]));
                            this.writer.WriteAttributeString("col_class_ext6", System.Convert.ToString(nvcTmp["col_class_ext6"]));
                            this.writer.WriteAttributeString("col_compact_view", System.Convert.ToString(nvcTmp["col_compact_view"]));
                            this.writer.WriteAttributeString("col_icon_class", System.Convert.ToString(nvcTmp["col_icon_class"]));
                            this.writer.WriteAttributeString("col_icon_position", System.Convert.ToString(nvcTmp["col_icon_position"]));
                            this.writer.WriteAttributeString("col_temp_cat", System.Convert.ToString(nvcTmp["col_temp_cat"]));
                            this.writer.WriteAttributeString("col_temp_specific", System.Convert.ToString(nvcTmp["col_temp_specific"]));
                            this.writer.WriteAttributeString("col_transform_as", System.Convert.ToString(nvcTmp["col_transform_as"]));
                            this.writer.WriteAttributeString("columnclass", System.Convert.ToString(nvcTmp["columnclass"]));
                            this.writer.WriteAttributeString("engg_col_descr", System.Convert.ToString(nvcTmp["engg_col_descr"]));
                            this.writer.WriteAttributeString("engg_col_tempid", System.Convert.ToString(nvcTmp["engg_col_tempid"]));
                            this.writer.WriteAttributeString("engg_grd_visible", System.Convert.ToString(nvcTmp["engg_grd_visible"]));
                            this.writer.WriteAttributeString("engg_grid_btsynname", System.Convert.ToString(nvcTmp["engg_grid_btsynname"]));
                            this.writer.WriteAttributeString("engg_grid_colno", System.Convert.ToString(nvcTmp["engg_grid_colno"]));
                            this.writer.WriteAttributeString("engg_grid_default", System.Convert.ToString(nvcTmp["engg_grid_default"]));
                            this.writer.WriteAttributeString("engg_grid_doc", System.Convert.ToString(nvcTmp["engg_grid_doc"]));
                            this.writer.WriteAttributeString("engg_grid_elem_type", System.Convert.ToString(nvcTmp["engg_grid_elem_type"]));
                            this.writer.WriteAttributeString("engg_grid_samp_data", System.Convert.ToString(nvcTmp["engg_grid_samp_data"]));
                            this.writer.WriteAttributeString("engg_grid_tooltip", System.Convert.ToString(nvcTmp["engg_grid_tooltip"]));
                            this.writer.WriteAttributeString("engg_grid_vis_length", System.Convert.ToString(nvcTmp["engg_grid_vis_length"]));
                            this.writer.WriteAttributeString("forcefit", System.Convert.ToString(nvcTmp["forcefit"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_rmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_YMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_ymlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_ymlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_YMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_YMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_YMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_lay_horder", System.Convert.ToString(nvcTmp["engg_lay_horder"]));
                            this.writer.WriteAttributeString("engg_lay_parent_sec", System.Convert.ToString(nvcTmp["engg_lay_parent_sec"]));
                            this.writer.WriteAttributeString("engg_lay_sec_name", System.Convert.ToString(nvcTmp["engg_lay_sec_name"]));
                            this.writer.WriteAttributeString("engg_lay_vorder", System.Convert.ToString(nvcTmp["engg_lay_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_ymlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGADMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggadmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggadmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGADMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGADMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGADMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_radio_caption", System.Convert.ToString(nvcTmp["engg_radio_caption"]));
                            this.writer.WriteAttributeString("engg_radio_code", System.Convert.ToString(nvcTmp["engg_radio_code"]));
                            this.writer.WriteAttributeString("engg_radio_default", System.Convert.ToString(nvcTmp["engg_radio_default"]));
                            this.writer.WriteAttributeString("engg_radio_horder", System.Convert.ToString(nvcTmp["engg_radio_horder"]));
                            this.writer.WriteAttributeString("engg_radio_seq", System.Convert.ToString(nvcTmp["engg_radio_seq"]));
                            this.writer.WriteAttributeString("engg_radio_vorder", System.Convert.ToString(nvcTmp["engg_radio_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggadmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGPAMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggpamlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggpamlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGPAMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGPAMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGPAMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_hdr_pos", System.Convert.ToString(nvcTmp["engg_hdr_pos"]));
                            this.writer.WriteAttributeString("engg_pag_lay_con", System.Convert.ToString(nvcTmp["engg_pag_lay_con"]));
                            this.writer.WriteAttributeString("engg_page_bottomtb", System.Convert.ToString(nvcTmp["engg_page_bottomtb"]));
                            this.writer.WriteAttributeString("engg_page_btsynname", System.Convert.ToString(nvcTmp["engg_page_btsynname"]));
                            this.writer.WriteAttributeString("engg_page_descr", System.Convert.ToString(nvcTmp["engg_page_descr"]));
                            this.writer.WriteAttributeString("engg_page_doc", System.Convert.ToString(nvcTmp["engg_page_doc"]));
                            this.writer.WriteAttributeString("engg_page_horder", System.Convert.ToString(nvcTmp["engg_page_horder"]));
                            this.writer.WriteAttributeString("engg_page_img", System.Convert.ToString(nvcTmp["engg_page_img"]));
                            this.writer.WriteAttributeString("engg_page_lay", System.Convert.ToString(nvcTmp["engg_page_lay"]));
                            this.writer.WriteAttributeString("engg_page_lefttb", System.Convert.ToString(nvcTmp["engg_page_lefttb"]));
                            this.writer.WriteAttributeString("engg_page_righttb", System.Convert.ToString(nvcTmp["engg_page_righttb"]));
                            this.writer.WriteAttributeString("engg_page_toptb", System.Convert.ToString(nvcTmp["engg_page_toptb"]));
                            this.writer.WriteAttributeString("engg_page_type", System.Convert.ToString(nvcTmp["engg_page_type"]));
                            this.writer.WriteAttributeString("engg_page_vorder", System.Convert.ToString(nvcTmp["engg_page_vorder"]));
                            this.writer.WriteAttributeString("engg_tab_icon_pos", System.Convert.ToString(nvcTmp["engg_tab_icon_pos"]));
                            this.writer.WriteAttributeString("engg_tab_rot", System.Convert.ToString(nvcTmp["engg_tab_rot"]));
                            this.writer.WriteAttributeString("engg_tab_title_st", System.Convert.ToString(nvcTmp["engg_tab_title_st"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggpamlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_docked":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_sidebar":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_att_ui_cap_align":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_format":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_grid_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_trail_bar":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_bottomtb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_callout_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_sec_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_control_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_desk_brw":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_btsynname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_ctrl_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_grid_code":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_caption":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_hdrpersonalisation":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_hide_print":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ilbotitle":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_impdefault":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_isdevice":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lay_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lefttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_lnk_page_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_nativeapp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_phone":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_popup_close":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_btsynname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_righttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_sec_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sect_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_smarthide":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_syst_excl_tab_ind":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_hdr_pos":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_height":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_tab_rotate":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_style":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tablet":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_titlebar_search":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_toptb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_laycon":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_layout":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_uisubtype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ezee_taskpane":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "state_processing":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ccbr_launchtype":
                    type = 1;
                    break;
                case "ccbr_uisubtype":
                    type = 1;
                    break;
                case "cgctr_cbseg":
                    type = 1;
                    break;
                case "cggrp_cbseg":
                    type = 1;
                    break;
                case "cgpag_cbseg":
                    type = 1;
                    break;
                case "cgsec_cbseg":
                    type = 1;
                    break;
                case "engg_dcbseg":
                    type = 1;
                    break;
                case "engg_ecbseg":
                    type = 1;
                    break;
                case "engg_gcbseg":
                    type = 1;
                    break;
                case "engg_icbseg":
                    type = 1;
                    break;
                case "engg_kcbseg":
                    type = 1;
                    break;
                case "engg_ncbseg":
                    type = 1;
                    break;
                case "engg_ocbseg":
                    type = 1;
                    break;
                case "engg_pcbseg":
                    type = 1;
                    break;
                case "engg_scbseg":
                    type = 1;
                    break;
                case "enggdicbseg":
                    type = 1;
                    break;
                case "enggiocbseg":
                    type = 1;
                    break;
                case "engglacbseg":
                    type = 1;
                    break;
                case "enggracbseg":
                    type = 1;
                    break;
                case "sec_pgcbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "_secmlout":
                    type = 1;
                    break;
                case "cggrd_mlout":
                    type = 1;
                    break;
                case "engg_cmlout":
                    type = 1;
                    break;
                case "engg_lmlout":
                    type = 1;
                    break;
                case "engg_mmlout":
                    type = 1;
                    break;
                case "engg_rmlout":
                    type = 1;
                    break;
                case "engg_ymlout":
                    type = 1;
                    break;
                case "enggadmlout":
                    type = 1;
                    break;
                case "enggpamlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ccbr_launchtype":
                    return htCCBR_LAUNCHTYPE.Count;
                    break;
                case "ccbr_uisubtype":
                    return htCCBR_UISUBTYPE.Count;
                    break;
                case "cgctr_cbseg":
                    return htCGCTR_CBSEG.Count;
                    break;
                case "cggrp_cbseg":
                    return htCGGRP_CBSEG.Count;
                    break;
                case "cgpag_cbseg":
                    return htCGPAG_CBSEG.Count;
                    break;
                case "cgsec_cbseg":
                    return htCGSEC_CBSEG.Count;
                    break;
                case "engg_dcbseg":
                    return htENGG_DCBSEG.Count;
                    break;
                case "engg_ecbseg":
                    return htENGG_ECBSEG.Count;
                    break;
                case "engg_gcbseg":
                    return htENGG_GCBSEG.Count;
                    break;
                case "engg_icbseg":
                    return htENGG_ICBSEG.Count;
                    break;
                case "engg_kcbseg":
                    return htENGG_KCBSEG.Count;
                    break;
                case "engg_ncbseg":
                    return htENGG_NCBSEG.Count;
                    break;
                case "engg_ocbseg":
                    return htENGG_OCBSEG.Count;
                    break;
                case "engg_pcbseg":
                    return htENGG_PCBSEG.Count;
                    break;
                case "engg_scbseg":
                    return htENGG_SCBSEG.Count;
                    break;
                case "enggdicbseg":
                    return htENGGDICBSEG.Count;
                    break;
                case "enggiocbseg":
                    return htENGGIOCBSEG.Count;
                    break;
                case "engglacbseg":
                    return htENGGLACBSEG.Count;
                    break;
                case "enggracbseg":
                    return htENGGRACBSEG.Count;
                    break;
                case "sec_pgcbseg":
                    return htSEC_PGCBSEG.Count;
                    break;
                case "_secmlout":
                    return ht_SECMLOUT.Count;
                    break;
                case "cggrd_mlout":
                    return htCGGRD_MLOUT.Count;
                    break;
                case "engg_cmlout":
                    return htENGG_CMLOUT.Count;
                    break;
                case "engg_lmlout":
                    return htENGG_LMLOUT.Count;
                    break;
                case "engg_mmlout":
                    return htENGG_MMLOUT.Count;
                    break;
                case "engg_rmlout":
                    return htENGG_RMLOUT.Count;
                    break;
                case "engg_ymlout":
                    return htENGG_YMLOUT.Count;
                    break;
                case "enggadmlout":
                    return htENGGADMLOUT.Count;
                    break;
                case "enggpamlout":
                    return htENGGPAMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ccbr_launchtype":
                    return this.htCCBR_LAUNCHTYPE;
                case "ccbr_uisubtype":
                    return this.htCCBR_UISUBTYPE;
                case "cgctr_cbseg":
                    return this.htCGCTR_CBSEG;
                case "cggrp_cbseg":
                    return this.htCGGRP_CBSEG;
                case "cgpag_cbseg":
                    return this.htCGPAG_CBSEG;
                case "cgsec_cbseg":
                    return this.htCGSEC_CBSEG;
                case "engg_dcbseg":
                    return this.htENGG_DCBSEG;
                case "engg_ecbseg":
                    return this.htENGG_ECBSEG;
                case "engg_gcbseg":
                    return this.htENGG_GCBSEG;
                case "engg_icbseg":
                    return this.htENGG_ICBSEG;
                case "engg_kcbseg":
                    return this.htENGG_KCBSEG;
                case "engg_ncbseg":
                    return this.htENGG_NCBSEG;
                case "engg_ocbseg":
                    return this.htENGG_OCBSEG;
                case "engg_pcbseg":
                    return this.htENGG_PCBSEG;
                case "engg_scbseg":
                    return this.htENGG_SCBSEG;
                case "enggdicbseg":
                    return this.htENGGDICBSEG;
                case "enggiocbseg":
                    return this.htENGGIOCBSEG;
                case "engglacbseg":
                    return this.htENGGLACBSEG;
                case "enggracbseg":
                    return this.htENGGRACBSEG;
                case "sec_pgcbseg":
                    return this.htSEC_PGCBSEG;
                case "_secmlout":
                    return this.ht_SECMLOUT;
                case "cggrd_mlout":
                    return this.htCGGRD_MLOUT;
                case "engg_cmlout":
                    return this.htENGG_CMLOUT;
                case "engg_lmlout":
                    return this.htENGG_LMLOUT;
                case "engg_mmlout":
                    return this.htENGG_MMLOUT;
                case "engg_rmlout":
                    return this.htENGG_RMLOUT;
                case "engg_ymlout":
                    return this.htENGG_YMLOUT;
                case "enggadmlout":
                    return this.htENGGADMLOUT;
                case "enggpamlout":
                    return this.htENGGPAMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "ccbr_launchtype":
                        System.Collections.Specialized.NameValueCollection nvcTmpccbr_launchtype = (NameValueCollection)htCCBR_LAUNCHTYPE[lnInstNumber];
                        return nvcTmpccbr_launchtype[szDataItem];
                        break;
                    case "ccbr_uisubtype":
                        System.Collections.Specialized.NameValueCollection nvcTmpccbr_uisubtype = (NameValueCollection)htCCBR_UISUBTYPE[lnInstNumber];
                        return nvcTmpccbr_uisubtype[szDataItem];
                        break;
                    case "cgctr_cbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgctr_cbseg = (NameValueCollection)htCGCTR_CBSEG[lnInstNumber];
                        return nvcTmpcgctr_cbseg[szDataItem];
                        break;
                    case "cggrp_cbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcggrp_cbseg = (NameValueCollection)htCGGRP_CBSEG[lnInstNumber];
                        return nvcTmpcggrp_cbseg[szDataItem];
                        break;
                    case "cgpag_cbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgpag_cbseg = (NameValueCollection)htCGPAG_CBSEG[lnInstNumber];
                        return nvcTmpcgpag_cbseg[szDataItem];
                        break;
                    case "cgsec_cbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgsec_cbseg = (NameValueCollection)htCGSEC_CBSEG[lnInstNumber];
                        return nvcTmpcgsec_cbseg[szDataItem];
                        break;
                    case "engg_dcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_dcbseg = (NameValueCollection)htENGG_DCBSEG[lnInstNumber];
                        return nvcTmpengg_dcbseg[szDataItem];
                        break;
                    case "engg_ecbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_ecbseg = (NameValueCollection)htENGG_ECBSEG[lnInstNumber];
                        return nvcTmpengg_ecbseg[szDataItem];
                        break;
                    case "engg_gcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_gcbseg = (NameValueCollection)htENGG_GCBSEG[lnInstNumber];
                        return nvcTmpengg_gcbseg[szDataItem];
                        break;
                    case "engg_icbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_icbseg = (NameValueCollection)htENGG_ICBSEG[lnInstNumber];
                        return nvcTmpengg_icbseg[szDataItem];
                        break;
                    case "engg_kcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_kcbseg = (NameValueCollection)htENGG_KCBSEG[lnInstNumber];
                        return nvcTmpengg_kcbseg[szDataItem];
                        break;
                    case "engg_ncbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_ncbseg = (NameValueCollection)htENGG_NCBSEG[lnInstNumber];
                        return nvcTmpengg_ncbseg[szDataItem];
                        break;
                    case "engg_ocbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_ocbseg = (NameValueCollection)htENGG_OCBSEG[lnInstNumber];
                        return nvcTmpengg_ocbseg[szDataItem];
                        break;
                    case "engg_pcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_pcbseg = (NameValueCollection)htENGG_PCBSEG[lnInstNumber];
                        return nvcTmpengg_pcbseg[szDataItem];
                        break;
                    case "engg_scbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_scbseg = (NameValueCollection)htENGG_SCBSEG[lnInstNumber];
                        return nvcTmpengg_scbseg[szDataItem];
                        break;
                    case "enggdicbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggdicbseg = (NameValueCollection)htENGGDICBSEG[lnInstNumber];
                        return nvcTmpenggdicbseg[szDataItem];
                        break;
                    case "enggiocbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggiocbseg = (NameValueCollection)htENGGIOCBSEG[lnInstNumber];
                        return nvcTmpenggiocbseg[szDataItem];
                        break;
                    case "engglacbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengglacbseg = (NameValueCollection)htENGGLACBSEG[lnInstNumber];
                        return nvcTmpengglacbseg[szDataItem];
                        break;
                    case "enggracbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggracbseg = (NameValueCollection)htENGGRACBSEG[lnInstNumber];
                        return nvcTmpenggracbseg[szDataItem];
                        break;
                    case "sec_pgcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsec_pgcbseg = (NameValueCollection)htSEC_PGCBSEG[lnInstNumber];
                        return nvcTmpsec_pgcbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "_secmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmp_secmlout = (NameValueCollection)ht_SECMLOUT[lnInstNumber];
                        return nvcTmp_secmlout[szDataItem];
                        break;
                    case "cggrd_mlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpcggrd_mlout = (NameValueCollection)htCGGRD_MLOUT[lnInstNumber];
                        return nvcTmpcggrd_mlout[szDataItem];
                        break;
                    case "engg_cmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_cmlout = (NameValueCollection)htENGG_CMLOUT[lnInstNumber];
                        return nvcTmpengg_cmlout[szDataItem];
                        break;
                    case "engg_lmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_lmlout = (NameValueCollection)htENGG_LMLOUT[lnInstNumber];
                        return nvcTmpengg_lmlout[szDataItem];
                        break;
                    case "engg_mmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_mmlout = (NameValueCollection)htENGG_MMLOUT[lnInstNumber];
                        return nvcTmpengg_mmlout[szDataItem];
                        break;
                    case "engg_rmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_rmlout = (NameValueCollection)htENGG_RMLOUT[lnInstNumber];
                        return nvcTmpengg_rmlout[szDataItem];
                        break;
                    case "engg_ymlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_ymlout = (NameValueCollection)htENGG_YMLOUT[lnInstNumber];
                        return nvcTmpengg_ymlout[szDataItem];
                        break;
                    case "enggadmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggadmlout = (NameValueCollection)htENGGADMLOUT[lnInstNumber];
                        return nvcTmpenggadmlout[szDataItem];
                        break;
                    case "enggpamlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggpamlout = (NameValueCollection)htENGGPAMLOUT[lnInstNumber];
                        return nvcTmpenggpamlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_maireesrep_lay Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                this.ProcessPS4();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_maireesrep_lay Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_lay");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_isdevice"];
                            base.Parameters("@engg_isdevice", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_smarthide"];
                            base.Parameters("@engg_smarthide", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_ilbotitle"];
                            base.Parameters("@engg_ilbotitle", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_hdrpersonalisation"];
                            base.Parameters("@engg_hdrpersonalisation", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_syst_excl_tab_ind"];
                            base.Parameters("@engg_syst_excl_tab_ind", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_phone"];
                            base.Parameters("@engg_phone", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tablet"];
                            base.Parameters("@engg_tablet", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_desk_brw"];
                            base.Parameters("@engg_desk_brw", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_hide_print"];
                            base.Parameters("@engg_hide_print", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_impdefault"];
                            base.Parameters("@engg_hide_default", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_lefttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_lefttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_lefttb);
                            base.Parameters("@engg_lefttb", DBType.Int, 32, s_HSEGengg_lefttb);
                            sValue = nvc_HSEG["engg_righttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_righttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_righttb);
                            base.Parameters("@engg_righttb", DBType.Int, 32, s_HSEGengg_righttb);
                            sValue = nvc_HSEG["engg_toptb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_toptb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_toptb);
                            base.Parameters("@engg_toptb", DBType.Int, 32, s_HSEGengg_toptb);
                            sValue = nvc_HSEG["engg_bottomtb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_bottomtb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_bottomtb);
                            base.Parameters("@engg_bottomtb", DBType.Int, 32, s_HSEGengg_bottomtb);
                            sValue = nvc_HSEG["engg_att_sidebar"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_att_sidebar = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_att_sidebar);
                            base.Parameters("@engg_att_sidebar", DBType.Int, 32, s_HSEGengg_att_sidebar);
                            sValue = nvc_HSEG["engg_att_docked"];
                            base.Parameters("@engg_att_docked", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layhdrsav", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layhdrsav", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106133, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106133, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("_sec_fprowno");
                                nvc_HSEG["_sec_fprowno"] = sValue;
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                                sValue = this.GetValue("engg_l_fprowno");
                                nvc_HSEG["engg_l_fprowno"] = sValue;
                                sValue = this.GetValue("engg_m_fprowno");
                                nvc_HSEG["engg_m_fprowno"] = sValue;
                                sValue = this.GetValue("engg_r_fprowno");
                                nvc_HSEG["engg_r_fprowno"] = sValue;
                                sValue = this.GetValue("engg_y_fprowno");
                                nvc_HSEG["engg_y_fprowno"] = sValue;
                                sValue = this.GetValue("enggad_fprowno");
                                nvc_HSEG["enggad_fprowno"] = sValue;
                                sValue = this.GetValue("enggpa_fprowno");
                                nvc_HSEG["enggpa_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106133, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106134, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106134, 2, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_OCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_page_bts");
                                    nvcTmp["engg_cont_page_bts"] = sValue;
                                    htENGG_OCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106134, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 2  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_n", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_n", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106135, 2, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106135, 2, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_NCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_sec_bts");
                                    nvcTmp["engg_cont_sec_bts"] = sValue;
                                    htENGG_NCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106135, 2, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 3  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_e", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_e", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106136, 2, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106136, 2, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_ECBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_btsynname");
                                    nvcTmp["engg_enum_btsynname"] = sValue;
                                    htENGG_ECBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106136, 2, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 4  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_p", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_p", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106137, 2, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106137, 2, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_PCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_page_bts");
                                    nvcTmp["engg_enum_page_bts"] = sValue;
                                    htENGG_PCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106137, 2, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 5  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_s", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_s", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106138, 2, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106138, 2, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_SCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_sec_bts");
                                    nvcTmp["engg_enum_sec_bts"] = sValue;
                                    htENGG_SCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106138, 2, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 6  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_g", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_g", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106139, 2, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106139, 2, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_GCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_grid_code");
                                    nvcTmp["engg_grid_grid_code"] = sValue;
                                    htENGG_GCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106139, 2, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 7  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_i", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_i", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106140, 2, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106140, 2, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_ICBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_page_bts");
                                    nvcTmp["engg_grid_page_bts"] = sValue;
                                    htENGG_ICBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106140, 2, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 8  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_d", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_d", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106141, 2, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106141, 2, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_DCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_sec_bts");
                                    nvcTmp["engg_grid_sec_bts"] = sValue;
                                    htENGG_DCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106141, 2, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 9  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggla", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggla", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106142, 2, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106142, 2, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGLACBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_page_bts");
                                    nvcTmp["engg_lay_page_bts"] = sValue;
                                    htENGGLACBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106142, 2, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 10  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_k", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_k", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106143, 2, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106143, 2, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_KCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lnk_page_descr");
                                    nvcTmp["engg_lnk_page_descr"] = sValue;
                                    htENGG_KCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106143, 2, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 11  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggra", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggra", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106144, 2, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106144, 2, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGRACBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_btsynname");
                                    nvcTmp["engg_radio_btsynname"] = sValue;
                                    htENGGRACBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106144, 2, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 12  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggdi", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggdi", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106145, 2, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106145, 2, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGDICBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_page_bts");
                                    nvcTmp["engg_radio_page_bts"] = sValue;
                                    htENGGDICBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106145, 2, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 13  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggio", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggio", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106146, 2, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106146, 2, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGIOCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_sec_bts");
                                    nvcTmp["engg_radio_sec_bts"] = sValue;
                                    htENGGIOCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106146, 2, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 14  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 14;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 14 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laysec_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laysec_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106147, 2, 14);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106147, 2, 14);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSEC_PGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sec_page_bts");
                                    nvcTmp["engg_sec_page_bts"] = sValue;
                                    htSEC_PGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 14", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106147, 2, 14);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 14 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 15  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 15;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 15 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laycgpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laycgpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115467, 2, 15);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115467, 2, 15);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGPAG_CBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_page_name");
                                    nvcTmp["engg_page_name"] = sValue;
                                    htCGPAG_CBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 15", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115467, 2, 15);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 15 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 16  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 16;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 16 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laycgsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laycgsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115468, 2, 16);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115468, 2, 16);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGSEC_CBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sect_name");
                                    nvcTmp["engg_sect_name"] = sValue;
                                    htCGSEC_CBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 16", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115468, 2, 16);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 16 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 17  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 17;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 17 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laycgctr", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laycgctr", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115469, 2, 17);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115469, 2, 17);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGCTR_CBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_control_name");
                                    nvcTmp["engg_control_name"] = sValue;
                                    htCGCTR_CBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 17", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115469, 2, 17);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 17 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 18  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 18;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 18 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laycggrp", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laycggrp", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115470, 2, 18);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115470, 2, 18);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGGRP_CBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_group_caption");
                                    nvcTmp["engg_group_caption"] = sValue;
                                    htCGGRP_CBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 18", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115470, 2, 18);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 18 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 19  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 19;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 512, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 19 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_subtypecombo", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_subtypecombo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 116534, 2, 19);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 116534, 2, 19);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCCBR_UISUBTYPE.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_uisubtype");
                                    nvcTmp["engg_uisubtype"] = sValue;
                                    htCCBR_UISUBTYPE[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 19", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 116534, 2, 19);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 19 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 20  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 20;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laycbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 512, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 20 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_launchtype", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_launchtype", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 116535, 2, 20);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 116535, 2, 20);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCCBR_LAUNCHTYPE.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_launch_type");
                                    nvcTmp["engg_launch_type"] = sValue;
                                    htCCBR_LAUNCHTYPE[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 20", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 116535, 2, 20);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 20 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_layhpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            sValue = nvc_HSEG["engg_isdevice"];
                            base.Parameters("@engg_isdevice", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_smarthide"];
                            base.Parameters("@engg_smarthide", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_ilbotitle"];
                            base.Parameters("@engg_ilbotitle", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_hdrpersonalisation"];
                            base.Parameters("@engg_hdrpersonalisation", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_syst_excl_tab_ind"];
                            base.Parameters("@engg_syst_excl_tab_ind", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_phone"];
                            base.Parameters("@engg_phone", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tablet"];
                            base.Parameters("@engg_tablet", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_desk_brw"];
                            base.Parameters("@engg_desk_brw", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_hide_print"];
                            base.Parameters("@engg_hide_print", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_impdefault"];
                            base.Parameters("@engg_hide_default", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_uisubtype"];
                            base.Parameters("@engg_uisubtype", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_nativeapp"];
                            base.Parameters("@engg_nativeapp", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_popup_close"];
                            base.Parameters("@engg_popup_close", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_titlebar_search"];
                            base.Parameters("@engg_titlebar_search", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_lefttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_lefttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_lefttb);
                            base.Parameters("@engg_lefttb", DBType.Int, 32, s_HSEGengg_lefttb);
                            sValue = nvc_HSEG["engg_righttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_righttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_righttb);
                            base.Parameters("@engg_righttb", DBType.Int, 32, s_HSEGengg_righttb);
                            sValue = nvc_HSEG["engg_toptb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_toptb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_toptb);
                            base.Parameters("@engg_toptb", DBType.Int, 32, s_HSEGengg_toptb);
                            sValue = nvc_HSEG["engg_bottomtb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_bottomtb = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_bottomtb);
                            base.Parameters("@engg_bottomtb", DBType.Int, 32, s_HSEGengg_bottomtb);
                            sValue = nvc_HSEG["engg_att_sidebar"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_att_sidebar = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_att_sidebar);
                            base.Parameters("@engg_att_sidebar", DBType.Int, 32, s_HSEGengg_att_sidebar);
                            sValue = nvc_HSEG["engg_att_docked"];
                            base.Parameters("@engg_att_docked", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_type_bts"];
                            base.Parameters("@engg_cont_sec_type_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_type_bts"];
                            base.Parameters("@engg_grid_sec_type_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_ctrl_type_bts"];
                            base.Parameters("@engg_grid_ctrl_type_bts", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layhdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106148, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106148, 3, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("_sec_fprowno");
                                nvc_HSEG["_sec_fprowno"] = sValue;
                                sValue = this.GetValue("engg_act_descr");
                                nvc_HSEG["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_att_docked");
                                nvc_HSEG["engg_att_docked"] = sValue;
                                sValue = this.GetValue("engg_att_sidebar");
                                nvc_HSEG["engg_att_sidebar"] = sValue;
                                sValue = this.GetValue("engg_att_ui_cap_align");
                                nvc_HSEG["engg_att_ui_cap_align"] = sValue;
                                sValue = this.GetValue("engg_att_ui_format");
                                nvc_HSEG["engg_att_ui_format"] = sValue;
                                sValue = this.GetValue("engg_att_ui_grid_type");
                                nvc_HSEG["engg_att_ui_grid_type"] = sValue;
                                sValue = this.GetValue("engg_att_ui_trail_bar");
                                nvc_HSEG["engg_att_ui_trail_bar"] = sValue;
                                sValue = this.GetValue("engg_att_ui_type");
                                nvc_HSEG["engg_att_ui_type"] = sValue;
                                sValue = this.GetValue("engg_bottomtb");
                                nvc_HSEG["engg_bottomtb"] = sValue;
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                                sValue = this.GetValue("engg_callout_type");
                                nvc_HSEG["engg_callout_type"] = sValue;
                                sValue = this.GetValue("engg_component");
                                nvc_HSEG["engg_component"] = sValue;
                                sValue = this.GetValue("engg_cont_page_bts");
                                nvc_HSEG["engg_cont_page_bts"] = sValue;
                                sValue = this.GetValue("engg_cont_sec_bts");
                                nvc_HSEG["engg_cont_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_cont_sec_type_bts");
                                nvc_HSEG["engg_cont_sec_type_bts"] = sValue;
                                sValue = this.GetValue("engg_control_name");
                                nvc_HSEG["engg_control_name"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HSEG["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_desk_brw");
                                nvc_HSEG["engg_desk_brw"] = sValue;
                                sValue = this.GetValue("engg_enum_btsynname");
                                nvc_HSEG["engg_enum_btsynname"] = sValue;
                                sValue = this.GetValue("engg_enum_page_bts");
                                nvc_HSEG["engg_enum_page_bts"] = sValue;
                                sValue = this.GetValue("engg_enum_sec_bts");
                                nvc_HSEG["engg_enum_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_ctrl_type_bts");
                                nvc_HSEG["engg_grid_ctrl_type_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_grid_code");
                                nvc_HSEG["engg_grid_grid_code"] = sValue;
                                sValue = this.GetValue("engg_grid_page_bts");
                                nvc_HSEG["engg_grid_page_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_bts");
                                nvc_HSEG["engg_grid_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_type_bts");
                                nvc_HSEG["engg_grid_sec_type_bts"] = sValue;
                                sValue = this.GetValue("engg_group_caption");
                                nvc_HSEG["engg_group_caption"] = sValue;
                                sValue = this.GetValue("engg_group_name");
                                nvc_HSEG["engg_group_name"] = sValue;
                                sValue = this.GetValue("engg_hdrpersonalisation");
                                nvc_HSEG["engg_hdrpersonalisation"] = sValue;
                                sValue = this.GetValue("engg_hide_default");
                                nvc_HSEG["engg_impdefault"] = sValue;
                                sValue = this.GetValue("engg_hide_print");
                                nvc_HSEG["engg_hide_print"] = sValue;
                                sValue = this.GetValue("engg_ilbotitle");
                                nvc_HSEG["engg_ilbotitle"] = sValue;
                                sValue = this.GetValue("engg_isdevice");
                                nvc_HSEG["engg_isdevice"] = sValue;
                                sValue = this.GetValue("engg_l_fprowno");
                                nvc_HSEG["engg_l_fprowno"] = sValue;
                                sValue = this.GetValue("engg_lay_page_bts");
                                nvc_HSEG["engg_lay_page_bts"] = sValue;
                                sValue = this.GetValue("engg_lefttb");
                                nvc_HSEG["engg_lefttb"] = sValue;
                                sValue = this.GetValue("engg_lnk_page_descr");
                                nvc_HSEG["engg_lnk_page_descr"] = sValue;
                                sValue = this.GetValue("engg_m_fprowno");
                                nvc_HSEG["engg_m_fprowno"] = sValue;
                                sValue = this.GetValue("engg_nativeapp");
                                nvc_HSEG["engg_nativeapp"] = sValue;
                                sValue = this.GetValue("engg_page_name");
                                nvc_HSEG["engg_page_name"] = sValue;
                                sValue = this.GetValue("engg_phone");
                                nvc_HSEG["engg_phone"] = sValue;
                                sValue = this.GetValue("engg_popup_close");
                                nvc_HSEG["engg_popup_close"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HSEG["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HSEG["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_r_fprowno");
                                nvc_HSEG["engg_r_fprowno"] = sValue;
                                sValue = this.GetValue("engg_radio_btsynname");
                                nvc_HSEG["engg_radio_btsynname"] = sValue;
                                sValue = this.GetValue("engg_radio_page_bts");
                                nvc_HSEG["engg_radio_page_bts"] = sValue;
                                sValue = this.GetValue("engg_radio_sec_bts");
                                nvc_HSEG["engg_radio_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_req_no");
                                nvc_HSEG["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_rf_act");
                                nvc_HSEG["engg_rf_act"] = sValue;
                                sValue = this.GetValue("engg_rf_comp");
                                nvc_HSEG["engg_rf_comp"] = sValue;
                                sValue = this.GetValue("engg_rf_ui");
                                nvc_HSEG["engg_rf_ui"] = sValue;
                                sValue = this.GetValue("engg_righttb");
                                nvc_HSEG["engg_righttb"] = sValue;
                                sValue = this.GetValue("engg_sec_page_bts");
                                nvc_HSEG["engg_sec_page_bts"] = sValue;
                                sValue = this.GetValue("engg_sect_name");
                                nvc_HSEG["engg_sect_name"] = sValue;
                                sValue = this.GetValue("engg_smarthide");
                                nvc_HSEG["engg_smarthide"] = sValue;
                                sValue = this.GetValue("engg_syst_excl_tab_ind");
                                nvc_HSEG["engg_syst_excl_tab_ind"] = sValue;
                                sValue = this.GetValue("engg_tab_hdr_pos");
                                nvc_HSEG["engg_tab_hdr_pos"] = sValue;
                                sValue = this.GetValue("engg_tab_height");
                                nvc_HSEG["engg_tab_height"] = sValue;
                                sValue = this.GetValue("engg_tab_rotate");
                                nvc_HSEG["engg_tab_rotate"] = sValue;
                                sValue = this.GetValue("engg_tab_style");
                                nvc_HSEG["engg_tab_style"] = sValue;
                                sValue = this.GetValue("engg_tablet");
                                nvc_HSEG["engg_tablet"] = sValue;
                                sValue = this.GetValue("engg_titlebar_search");
                                nvc_HSEG["engg_titlebar_search"] = sValue;
                                sValue = this.GetValue("engg_toptb");
                                nvc_HSEG["engg_toptb"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HSEG["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("engg_ui_laycon");
                                nvc_HSEG["engg_ui_laycon"] = sValue;
                                sValue = this.GetValue("engg_ui_layout");
                                nvc_HSEG["engg_ui_layout"] = sValue;
                                sValue = this.GetValue("engg_uisubtype");
                                nvc_HSEG["engg_uisubtype"] = sValue;
                                sValue = this.GetValue("engg_y_fprowno");
                                nvc_HSEG["engg_y_fprowno"] = sValue;
                                sValue = this.GetValue("enggad_fprowno");
                                nvc_HSEG["enggad_fprowno"] = sValue;
                                sValue = this.GetValue("enggpa_fprowno");
                                nvc_HSEG["enggpa_fprowno"] = sValue;
                                sValue = this.GetValue("ezee_taskpane");
                                nvc_HSEG["ezee_taskpane"] = sValue;
                                sValue = this.GetValue("state_processing");
                                nvc_HSEG["state_processing"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106148, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS4()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 4;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 4
                // Starting to execute the BR - 1  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_cmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_cspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106149, 4, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106149, 4, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_CMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("accesskey");
                                    nvcTmp["accesskey"] = sValue;
                                    sValue = this.GetValue("cont_class_ext6");
                                    nvcTmp["cont_class_ext6"] = sValue;
                                    sValue = this.GetValue("ctrl_temp_cat");
                                    nvcTmp["ctrl_temp_cat"] = sValue;
                                    sValue = this.GetValue("ctrl_temp_specific");
                                    nvcTmp["ctrl_temp_specific"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_cont_btsynname");
                                    nvcTmp["engg_cont_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_cont_colspan");
                                    nvcTmp["engg_cont_colspan"] = sValue;
                                    sValue = this.GetValue("engg_cont_control_format");
                                    nvcTmp["engg_cont_control_format"] = sValue;
                                    sValue = this.GetValue("engg_cont_ctrlclass");
                                    nvcTmp["engg_cont_ctrlclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_ctrlimg");
                                    nvcTmp["engg_cont_ctrlimg"] = sValue;
                                    sValue = this.GetValue("engg_cont_ctrlimgclass");
                                    nvcTmp["engg_cont_ctrlimgclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_datawidth");
                                    nvcTmp["engg_cont_datawidth"] = sValue;
                                    sValue = this.GetValue("engg_cont_descr");
                                    nvcTmp["engg_cont_descr"] = sValue;
                                    sValue = this.GetValue("engg_cont_doc");
                                    nvcTmp["engg_cont_doc"] = sValue;
                                    sValue = this.GetValue("engg_cont_elem_type");
                                    nvcTmp["engg_cont_elem_type"] = sValue;
                                    sValue = this.GetValue("engg_cont_helptabstop");
                                    nvcTmp["engg_cont_helptabstop"] = sValue;
                                    sValue = this.GetValue("engg_cont_horder");
                                    nvcTmp["engg_cont_horder"] = sValue;
                                    sValue = this.GetValue("engg_cont_labclass");
                                    nvcTmp["engg_cont_labclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_labimgclass");
                                    nvcTmp["engg_cont_labimgclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_labwidth");
                                    nvcTmp["engg_cont_labwidth"] = sValue;
                                    sValue = this.GetValue("engg_cont_rowspan");
                                    nvcTmp["engg_cont_rowspan"] = sValue;
                                    sValue = this.GetValue("engg_cont_samp_data");
                                    nvcTmp["engg_cont_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_cont_sequence");
                                    nvcTmp["engg_cont_sequence"] = sValue;
                                    sValue = this.GetValue("engg_cont_tabseq");
                                    nvcTmp["engg_cont_tabseq"] = sValue;
                                    sValue = this.GetValue("engg_cont_tempid");
                                    nvcTmp["engg_cont_tempid"] = sValue;
                                    sValue = this.GetValue("engg_cont_tooltip");
                                    nvcTmp["engg_cont_tooltip"] = sValue;
                                    sValue = this.GetValue("engg_cont_vis_length");
                                    nvcTmp["engg_cont_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_cont_vorder");
                                    nvcTmp["engg_cont_vorder"] = sValue;
                                    sValue = this.GetValue("engg_dynamicstyle");
                                    nvcTmp["engg_dynamicstyle"] = sValue;
                                    sValue = this.GetValue("engg_imageasdata");
                                    nvcTmp["engg_imageasdata"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_msc_ass_control");
                                    nvcTmp["engg_msc_ass_control"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    sValue = this.GetValue("icon_class");
                                    nvcTmp["icon_class"] = sValue;
                                    sValue = this.GetValue("icon_position");
                                    nvcTmp["icon_position"] = sValue;
                                    htENGG_CMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106149, 4, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 2  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_mmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_mspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106150, 4, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106150, 4, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_MMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_enum_caption");
                                    nvcTmp["engg_enum_caption"] = sValue;
                                    sValue = this.GetValue("engg_enum_code");
                                    nvcTmp["engg_enum_code"] = sValue;
                                    sValue = this.GetValue("engg_enum_default");
                                    nvcTmp["engg_enum_default"] = sValue;
                                    sValue = this.GetValue("engg_enum_seq");
                                    nvcTmp["engg_enum_seq"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    htENGG_MMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106150, 4, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 3  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_rmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_rspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106151, 4, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106151, 4, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_RMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("col_associate_ctrl");
                                    nvcTmp["col_associate_ctrl"] = sValue;
                                    sValue = this.GetValue("col_class_ext6");
                                    nvcTmp["col_class_ext6"] = sValue;
                                    sValue = this.GetValue("col_compact_view");
                                    nvcTmp["col_compact_view"] = sValue;
                                    sValue = this.GetValue("col_icon_class");
                                    nvcTmp["col_icon_class"] = sValue;
                                    sValue = this.GetValue("col_icon_position");
                                    nvcTmp["col_icon_position"] = sValue;
                                    sValue = this.GetValue("col_temp_cat");
                                    nvcTmp["col_temp_cat"] = sValue;
                                    sValue = this.GetValue("col_temp_specific");
                                    nvcTmp["col_temp_specific"] = sValue;
                                    sValue = this.GetValue("col_transform_as");
                                    nvcTmp["col_transform_as"] = sValue;
                                    sValue = this.GetValue("columnclass");
                                    nvcTmp["columnclass"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_col_descr");
                                    nvcTmp["engg_col_descr"] = sValue;
                                    sValue = this.GetValue("engg_col_tempid");
                                    nvcTmp["engg_col_tempid"] = sValue;
                                    sValue = this.GetValue("engg_grd_visible");
                                    nvcTmp["engg_grd_visible"] = sValue;
                                    sValue = this.GetValue("engg_grid_btsynname");
                                    nvcTmp["engg_grid_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_grid_colno");
                                    nvcTmp["engg_grid_colno"] = sValue;
                                    sValue = this.GetValue("engg_grid_default");
                                    nvcTmp["engg_grid_default"] = sValue;
                                    sValue = this.GetValue("engg_grid_doc");
                                    nvcTmp["engg_grid_doc"] = sValue;
                                    sValue = this.GetValue("engg_grid_elem_type");
                                    nvcTmp["engg_grid_elem_type"] = sValue;
                                    sValue = this.GetValue("engg_grid_samp_data");
                                    nvcTmp["engg_grid_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_grid_tooltip");
                                    nvcTmp["engg_grid_tooltip"] = sValue;
                                    sValue = this.GetValue("engg_grid_vis_length");
                                    nvcTmp["engg_grid_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    sValue = this.GetValue("forcefit");
                                    nvcTmp["forcefit"] = sValue;
                                    htENGG_RMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106151, 4, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 4  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_ymto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_yspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106152, 4, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106152, 4, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_YMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_lay_horder");
                                    nvcTmp["engg_lay_horder"] = sValue;
                                    sValue = this.GetValue("engg_lay_parent_sec");
                                    nvcTmp["engg_lay_parent_sec"] = sValue;
                                    sValue = this.GetValue("engg_lay_sec_name");
                                    nvcTmp["engg_lay_sec_name"] = sValue;
                                    sValue = this.GetValue("engg_lay_vorder");
                                    nvcTmp["engg_lay_vorder"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    htENGG_YMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106152, 4, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 5  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layengg_lmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layengg_lspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106153, 4, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106153, 4, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_LMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_launch_type");
                                    nvcTmp["engg_launch_type"] = sValue;
                                    sValue = this.GetValue("engg_links_assoctrl");
                                    nvcTmp["engg_links_assoctrl"] = sValue;
                                    sValue = this.GetValue("engg_links_height");
                                    nvcTmp["engg_links_height"] = sValue;
                                    sValue = this.GetValue("engg_links_link_act");
                                    nvcTmp["engg_links_link_act"] = sValue;
                                    sValue = this.GetValue("engg_links_link_comp");
                                    nvcTmp["engg_links_link_comp"] = sValue;
                                    sValue = this.GetValue("engg_links_link_type");
                                    nvcTmp["engg_links_link_type"] = sValue;
                                    sValue = this.GetValue("engg_links_link_ui");
                                    nvcTmp["engg_links_link_ui"] = sValue;
                                    sValue = this.GetValue("engg_links_pcv_caption");
                                    nvcTmp["engg_links_pcv_caption"] = sValue;
                                    sValue = this.GetValue("engg_links_width");
                                    nvcTmp["engg_links_width"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_toolbar_notreq");
                                    nvcTmp["engg_toolbar_notreq"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    htENGG_LMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106153, 4, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 6  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggpamto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggpaspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106154, 4, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106154, 4, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGPAMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_hdr_pos");
                                    nvcTmp["engg_hdr_pos"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_pag_lay_con");
                                    nvcTmp["engg_pag_lay_con"] = sValue;
                                    sValue = this.GetValue("engg_page_bottomtb");
                                    nvcTmp["engg_page_bottomtb"] = sValue;
                                    sValue = this.GetValue("engg_page_btsynname");
                                    nvcTmp["engg_page_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_page_descr");
                                    nvcTmp["engg_page_descr"] = sValue;
                                    sValue = this.GetValue("engg_page_doc");
                                    nvcTmp["engg_page_doc"] = sValue;
                                    sValue = this.GetValue("engg_page_horder");
                                    nvcTmp["engg_page_horder"] = sValue;
                                    sValue = this.GetValue("engg_page_img");
                                    nvcTmp["engg_page_img"] = sValue;
                                    sValue = this.GetValue("engg_page_lay");
                                    nvcTmp["engg_page_lay"] = sValue;
                                    sValue = this.GetValue("engg_page_lefttb");
                                    nvcTmp["engg_page_lefttb"] = sValue;
                                    sValue = this.GetValue("engg_page_righttb");
                                    nvcTmp["engg_page_righttb"] = sValue;
                                    sValue = this.GetValue("engg_page_toptb");
                                    nvcTmp["engg_page_toptb"] = sValue;
                                    sValue = this.GetValue("engg_page_type");
                                    nvcTmp["engg_page_type"] = sValue;
                                    sValue = this.GetValue("engg_page_vorder");
                                    nvcTmp["engg_page_vorder"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_tab_icon_pos");
                                    nvcTmp["engg_tab_icon_pos"] = sValue;
                                    sValue = this.GetValue("engg_tab_rot");
                                    nvcTmp["engg_tab_rot"] = sValue;
                                    sValue = this.GetValue("engg_tab_title_st");
                                    nvcTmp["engg_tab_title_st"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    htENGGPAMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106154, 4, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 7  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_layenggadmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_layenggadspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106155, 4, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106155, 4, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGADMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_radio_caption");
                                    nvcTmp["engg_radio_caption"] = sValue;
                                    sValue = this.GetValue("engg_radio_code");
                                    nvcTmp["engg_radio_code"] = sValue;
                                    sValue = this.GetValue("engg_radio_default");
                                    nvcTmp["engg_radio_default"] = sValue;
                                    sValue = this.GetValue("engg_radio_horder");
                                    nvcTmp["engg_radio_horder"] = sValue;
                                    sValue = this.GetValue("engg_radio_seq");
                                    nvcTmp["engg_radio_seq"] = sValue;
                                    sValue = this.GetValue("engg_radio_vorder");
                                    nvcTmp["engg_radio_vorder"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    htENGGADMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106155, 4, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 8  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_cont_page_bts"];
                            base.Parameters("@engg_cont_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_cont_sec_bts"];
                            base.Parameters("@engg_cont_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_btsynname"];
                            base.Parameters("@engg_enum_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_page_bts"];
                            base.Parameters("@engg_enum_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_enum_sec_bts"];
                            base.Parameters("@engg_enum_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_page_bts"];
                            base.Parameters("@engg_lay_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lnk_page_descr"];
                            base.Parameters("@engg_lnk_page_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_btsynname"];
                            base.Parameters("@engg_radio_btsynname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_page_bts"];
                            base.Parameters("@engg_radio_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_radio_sec_bts"];
                            base.Parameters("@engg_radio_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_page_bts"];
                            base.Parameters("@engg_sec_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["enggad_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggad_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggad_fprowno);
                            base.Parameters("@enggad_fprowno", DBType.Int, 32, s_HSEGenggad_fprowno);
                            sValue = nvc_HSEG["enggpa_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGenggpa_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGenggpa_fprowno);
                            base.Parameters("@enggpa_fprowno", DBType.Int, 32, s_HSEGenggpa_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_l_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_l_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_l_fprowno);
                            base.Parameters("@engg_l_fprowno", DBType.Int, 32, s_HSEGengg_l_fprowno);
                            sValue = nvc_HSEG["engg_m_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_m_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_m_fprowno);
                            base.Parameters("@engg_m_fprowno", DBType.Int, 32, s_HSEGengg_m_fprowno);
                            sValue = nvc_HSEG["engg_r_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_r_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_r_fprowno);
                            base.Parameters("@engg_r_fprowno", DBType.Int, 32, s_HSEGengg_r_fprowno);
                            sValue = nvc_HSEG["engg_y_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_y_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_y_fprowno);
                            base.Parameters("@engg_y_fprowno", DBType.Int, 32, s_HSEGengg_y_fprowno);
                            sValue = nvc_HSEG["_sec_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEG_sec_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEG_sec_fprowno);
                            base.Parameters("@_sec_fprowno", DBType.Int, 32, s_HSEG_sec_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_lay_secmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_lay_secspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106156, 4, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106156, 4, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = ht_SECMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("_sec_fprowno");
                                    nvc_HSEG["_sec_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_associatedcontrol");
                                    nvcTmp["engg_associatedcontrol"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_col_dir");
                                    nvcTmp["engg_col_dir"] = sValue;
                                    sValue = this.GetValue("engg_l_fprowno");
                                    nvc_HSEG["engg_l_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_m_fprowno");
                                    nvc_HSEG["engg_m_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_r_fprowno");
                                    nvc_HSEG["engg_r_fprowno"] = sValue;
                                    sValue = this.GetValue("engg_region");
                                    nvcTmp["engg_region"] = sValue;
                                    sValue = this.GetValue("engg_sec_bord_req");
                                    nvcTmp["engg_sec_bord_req"] = sValue;
                                    sValue = this.GetValue("engg_sec_bottomtb");
                                    nvcTmp["engg_sec_bottomtb"] = sValue;
                                    sValue = this.GetValue("engg_sec_btsynname");
                                    nvcTmp["engg_sec_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_sec_cap_align");
                                    nvcTmp["engg_sec_cap_align"] = sValue;
                                    sValue = this.GetValue("engg_sec_cap_format");
                                    nvcTmp["engg_sec_cap_format"] = sValue;
                                    sValue = this.GetValue("engg_sec_descr");
                                    nvcTmp["engg_sec_descr"] = sValue;
                                    sValue = this.GetValue("engg_sec_lay_con");
                                    nvcTmp["engg_sec_lay_con"] = sValue;
                                    sValue = this.GetValue("engg_sec_lefttb");
                                    nvcTmp["engg_sec_lefttb"] = sValue;
                                    sValue = this.GetValue("engg_sec_minrows");
                                    nvcTmp["engg_sec_minrows"] = sValue;
                                    sValue = this.GetValue("engg_sec_righttb");
                                    nvcTmp["engg_sec_righttb"] = sValue;
                                    sValue = this.GetValue("engg_sec_secpreclass");
                                    nvcTmp["engg_sec_secpreclass"] = sValue;
                                    sValue = this.GetValue("engg_sec_title_align");
                                    nvcTmp["engg_sec_title_align"] = sValue;
                                    sValue = this.GetValue("engg_sec_title_req");
                                    nvcTmp["engg_sec_title_req"] = sValue;
                                    sValue = this.GetValue("engg_sec_titleaction");
                                    nvcTmp["engg_sec_titleaction"] = sValue;
                                    sValue = this.GetValue("engg_sec_titleicon");
                                    nvcTmp["engg_sec_titleicon"] = sValue;
                                    sValue = this.GetValue("engg_sec_toptb");
                                    nvcTmp["engg_sec_toptb"] = sValue;
                                    sValue = this.GetValue("engg_sec_type");
                                    nvcTmp["engg_sec_type"] = sValue;
                                    sValue = this.GetValue("engg_sec_visible");
                                    nvcTmp["engg_sec_visible"] = sValue;
                                    sValue = this.GetValue("engg_sec_vwmode");
                                    nvcTmp["engg_sec_vwmode"] = sValue;
                                    sValue = this.GetValue("engg_sect_doc");
                                    nvcTmp["engg_sect_doc"] = sValue;
                                    sValue = this.GetValue("engg_sect_lay");
                                    nvcTmp["engg_sect_lay"] = sValue;
                                    sValue = this.GetValue("engg_title_pos");
                                    nvcTmp["engg_title_pos"] = sValue;
                                    sValue = this.GetValue("engg_y_fprowno");
                                    nvc_HSEG["engg_y_fprowno"] = sValue;
                                    sValue = this.GetValue("enggad_fprowno");
                                    nvc_HSEG["enggad_fprowno"] = sValue;
                                    sValue = this.GetValue("enggpa_fprowno");
                                    nvc_HSEG["enggpa_fprowno"] = sValue;
                                    sValue = this.GetValue("sec_collapse");
                                    nvcTmp["sec_collapse"] = sValue;
                                    sValue = this.GetValue("sec_collapsemode");
                                    nvcTmp["sec_collapsemode"] = sValue;
                                    sValue = this.GetValue("section_colspan");
                                    nvcTmp["section_colspan"] = sValue;
                                    sValue = this.GetValue("section_rowspan");
                                    nvcTmp["section_rowspan"] = sValue;
                                    sValue = this.GetValue("sectionheight");
                                    nvcTmp["sectionheight"] = sValue;
                                    sValue = this.GetValue("sectionwidth");
                                    nvcTmp["sectionwidth"] = sValue;
                                    ht_SECMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106156, 4, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 4
                // Starting to execute the BR - 9  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psep_laypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_maireemtep_laycggrdo", nLoop, nMax));
                        base.Execute_SP(true, "ep_maireespep_laycggrdo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115472, 4, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115472, 4, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGGRD_MLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_col_or_group");
                                    nvcTmp["engg_col_or_group"] = sValue;
                                    sValue = this.GetValue("engg_map_seq");
                                    nvcTmp["engg_map_seq"] = sValue;
                                    sValue = this.GetValue("engg_mapped_entity");
                                    nvcTmp["engg_mapped_entity"] = sValue;
                                    sValue = this.GetValue("engg_ui_map");
                                    nvcTmp["engg_ui_map"] = sValue;
                                    htCGGRD_MLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115472, 4, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "ccbr_launchtype":
                            Localtable = (NameValueCollection)htCCBR_LAUNCHTYPE[lInstance];
                            break;
                        case "ccbr_uisubtype":
                            Localtable = (NameValueCollection)htCCBR_UISUBTYPE[lInstance];
                            break;
                        case "cgctr_cbseg":
                            Localtable = (NameValueCollection)htCGCTR_CBSEG[lInstance];
                            break;
                        case "cggrp_cbseg":
                            Localtable = (NameValueCollection)htCGGRP_CBSEG[lInstance];
                            break;
                        case "cgpag_cbseg":
                            Localtable = (NameValueCollection)htCGPAG_CBSEG[lInstance];
                            break;
                        case "cgsec_cbseg":
                            Localtable = (NameValueCollection)htCGSEC_CBSEG[lInstance];
                            break;
                        case "engg_dcbseg":
                            Localtable = (NameValueCollection)htENGG_DCBSEG[lInstance];
                            break;
                        case "engg_ecbseg":
                            Localtable = (NameValueCollection)htENGG_ECBSEG[lInstance];
                            break;
                        case "engg_gcbseg":
                            Localtable = (NameValueCollection)htENGG_GCBSEG[lInstance];
                            break;
                        case "engg_icbseg":
                            Localtable = (NameValueCollection)htENGG_ICBSEG[lInstance];
                            break;
                        case "engg_kcbseg":
                            Localtable = (NameValueCollection)htENGG_KCBSEG[lInstance];
                            break;
                        case "engg_ncbseg":
                            Localtable = (NameValueCollection)htENGG_NCBSEG[lInstance];
                            break;
                        case "engg_ocbseg":
                            Localtable = (NameValueCollection)htENGG_OCBSEG[lInstance];
                            break;
                        case "engg_pcbseg":
                            Localtable = (NameValueCollection)htENGG_PCBSEG[lInstance];
                            break;
                        case "engg_scbseg":
                            Localtable = (NameValueCollection)htENGG_SCBSEG[lInstance];
                            break;
                        case "enggdicbseg":
                            Localtable = (NameValueCollection)htENGGDICBSEG[lInstance];
                            break;
                        case "enggiocbseg":
                            Localtable = (NameValueCollection)htENGGIOCBSEG[lInstance];
                            break;
                        case "engglacbseg":
                            Localtable = (NameValueCollection)htENGGLACBSEG[lInstance];
                            break;
                        case "enggracbseg":
                            Localtable = (NameValueCollection)htENGGRACBSEG[lInstance];
                            break;
                        case "sec_pgcbseg":
                            Localtable = (NameValueCollection)htSEC_PGCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "_secmlout":
                            Localtable = (NameValueCollection)ht_SECMLOUT[lInstance];
                            break;
                        case "cggrd_mlout":
                            Localtable = (NameValueCollection)htCGGRD_MLOUT[lInstance];
                            break;
                        case "engg_cmlout":
                            Localtable = (NameValueCollection)htENGG_CMLOUT[lInstance];
                            break;
                        case "engg_lmlout":
                            Localtable = (NameValueCollection)htENGG_LMLOUT[lInstance];
                            break;
                        case "engg_mmlout":
                            Localtable = (NameValueCollection)htENGG_MMLOUT[lInstance];
                            break;
                        case "engg_rmlout":
                            Localtable = (NameValueCollection)htENGG_RMLOUT[lInstance];
                            break;
                        case "engg_ymlout":
                            Localtable = (NameValueCollection)htENGG_YMLOUT[lInstance];
                            break;
                        case "enggadmlout":
                            Localtable = (NameValueCollection)htENGGADMLOUT[lInstance];
                            break;
                        case "enggpamlout":
                            Localtable = (NameValueCollection)htENGGPAMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_maireesrep_lay(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_maireesrep_lay(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_maireesrep_lay.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

