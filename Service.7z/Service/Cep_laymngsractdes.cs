/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_laymngsractdes.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_laymngsractdes : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htCGCTRCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGGCAPCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGPAGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCGSECCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCNTPAGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCNTSECCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCOLGDNCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCOLPAGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCOLSECCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htDEVTYPCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPARSECMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSECPAGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htUIDESCCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htCGGRIDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCNTGRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCOLGRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPAGGRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvcPLF_STATE_SEGMENT = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htSECGRDMLOUT = new System.Collections.Hashtable();
        private string s_HSEGengg_tab_height = "0";
        private string modeFlagValue = string.Empty;
        public Cep_laymngsractdes()
        {
            base.iEDKESEngineInit("ep_laymngsractdes", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htCGCTRCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgctrcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgctrcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGCTRCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGCTRCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGCTRCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvcTmp["engg_control_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgctrcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGGCAPCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cggcapcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cggcapcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGGCAPCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGGCAPCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGGCAPCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvcTmp["engg_group_caption"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cggcapcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGPAGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgpagcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgpagcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGPAGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGPAGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGPAGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvcTmp["engg_page_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgpagcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCGSECCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cgseccbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cgseccbseg");
                    this.writer.WriteAttributeString("RecordCount", htCGSECCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCGSECCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGSECCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvcTmp["engg_sect_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cgseccbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCNTPAGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cntpagcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cntpagcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCNTPAGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCNTPAGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCNTPAGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_cont_pag", System.Convert.ToString(nvcTmp["ep_lay_cont_pag"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cntpagcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCNTSECCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cntseccbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cntseccbseg");
                    this.writer.WriteAttributeString("RecordCount", htCNTSECCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCNTSECCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCNTSECCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_cont_sect", System.Convert.ToString(nvcTmp["ep_lay_cont_sect"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cntseccbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCOLGDNCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("colgdncbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("colgdncbseg");
                    this.writer.WriteAttributeString("RecordCount", htCOLGDNCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCOLGDNCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCOLGDNCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_col_grd", System.Convert.ToString(nvcTmp["ep_lay_col_grd"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("colgdncbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCOLPAGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("colpagcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("colpagcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCOLPAGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCOLPAGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCOLPAGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_col_page", System.Convert.ToString(nvcTmp["ep_lay_col_page"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("colpagcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCOLSECCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("colseccbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("colseccbseg");
                    this.writer.WriteAttributeString("RecordCount", htCOLSECCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCOLSECCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCOLSECCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_col_sec", System.Convert.ToString(nvcTmp["ep_lay_col_sec"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("colseccbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htDEVTYPCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("devtypcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("devtypcbseg");
                    this.writer.WriteAttributeString("RecordCount", htDEVTYPCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htDEVTYPCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htDEVTYPCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_app_dev_typ", System.Convert.ToString(nvcTmp["engg_app_dev_typ"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("devtypcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPARSECMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("parsecmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("parsecmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htPARSECMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPARSECMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPARSECMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lay_parent_sec", System.Convert.ToString(nvcTmp["engg_lay_parent_sec"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("parsecmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSECPAGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("secpagcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("secpagcbseg");
                    this.writer.WriteAttributeString("RecordCount", htSECPAGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSECPAGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSECPAGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_lay_sec_page", System.Convert.ToString(nvcTmp["ep_lay_sec_page"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("secpagcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htUIDESCCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("uidesccbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("uidesccbseg");
                    this.writer.WriteAttributeString("RecordCount", htUIDESCCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htUIDESCCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htUIDESCCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvcTmp["engg_ui_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("uidesccbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvc_HSEG["engg_act_descr"]));
                    this.writer.WriteAttributeString("engg_app_dev_typ", System.Convert.ToString(nvc_HSEG["engg_app_dev_typ"]));
                    this.writer.WriteAttributeString("engg_att_def", System.Convert.ToString(nvc_HSEG["engg_att_def"]));
                    this.writer.WriteAttributeString("engg_att_ui_format", System.Convert.ToString(nvc_HSEG["engg_att_ui_format"]));
                    this.writer.WriteAttributeString("engg_colgrp_def", System.Convert.ToString(nvc_HSEG["engg_colgrp_def"]));
                    this.writer.WriteAttributeString("engg_component", System.Convert.ToString(nvc_HSEG["engg_component"]));
                    this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvc_HSEG["engg_control_name"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HSEG["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvc_HSEG["engg_group_caption"]));
                    this.writer.WriteAttributeString("engg_group_name", System.Convert.ToString(nvc_HSEG["engg_group_name"]));
                    this.writer.WriteAttributeString("engg_lay_pag_tab", System.Convert.ToString(nvc_HSEG["engg_lay_pag_tab"]));
                    this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvc_HSEG["engg_page_name"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HSEG["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HSEG["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_req_no", System.Convert.ToString(nvc_HSEG["engg_req_no"]));
                    this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvc_HSEG["engg_sect_name"]));
                    this.writer.WriteAttributeString("engg_tab_hdr_pos", System.Convert.ToString(nvc_HSEG["engg_tab_hdr_pos"]));
                    this.writer.WriteAttributeString("engg_tab_height", System.Convert.ToString(nvc_HSEG["engg_tab_height"]));
                    this.writer.WriteAttributeString("engg_tab_rotate", System.Convert.ToString(nvc_HSEG["engg_tab_rotate"]));
                    this.writer.WriteAttributeString("engg_tab_style", System.Convert.ToString(nvc_HSEG["engg_tab_style"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HSEG["engg_ui_descr"]));
                    this.writer.WriteAttributeString("engg_ui_laycon", System.Convert.ToString(nvc_HSEG["engg_ui_laycon"]));
                    this.writer.WriteAttributeString("engg_ui_layout", System.Convert.ToString(nvc_HSEG["engg_ui_layout"]));
                    this.writer.WriteAttributeString("ep_lay_col_def", System.Convert.ToString(nvc_HSEG["ep_lay_col_def"]));
                    this.writer.WriteAttributeString("ep_lay_col_grd", System.Convert.ToString(nvc_HSEG["ep_lay_col_grd"]));
                    this.writer.WriteAttributeString("ep_lay_col_page", System.Convert.ToString(nvc_HSEG["ep_lay_col_page"]));
                    this.writer.WriteAttributeString("ep_lay_col_sec", System.Convert.ToString(nvc_HSEG["ep_lay_col_sec"]));
                    this.writer.WriteAttributeString("ep_lay_cont_def", System.Convert.ToString(nvc_HSEG["ep_lay_cont_def"]));
                    this.writer.WriteAttributeString("ep_lay_cont_pag", System.Convert.ToString(nvc_HSEG["ep_lay_cont_pag"]));
                    this.writer.WriteAttributeString("ep_lay_cont_sect", System.Convert.ToString(nvc_HSEG["ep_lay_cont_sect"]));
                    this.writer.WriteAttributeString("ep_lay_sec_page", System.Convert.ToString(nvc_HSEG["ep_lay_sec_page"]));
                    this.writer.WriteAttributeString("ep_lay_sect_def", System.Convert.ToString(nvc_HSEG["ep_lay_sect_def"]));
                    this.writer.WriteAttributeString("hdncustomer", System.Convert.ToString(nvc_HSEG["hdncustomer"]));
                    this.writer.WriteAttributeString("hdnproject", System.Convert.ToString(nvc_HSEG["hdnproject"]));
                    this.writer.WriteAttributeString("prj_hdn_ctrl", System.Convert.ToString(nvc_HSEG["prj_hdn_ctrl"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htCGGRIDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cggridmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cggridmlout");
                    this.writer.WriteAttributeString("RecordCount", htCGGRIDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCGGRIDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCGGRIDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_col_or_group", System.Convert.ToString(nvcTmp["engg_col_or_group"]));
                            this.writer.WriteAttributeString("engg_map_seq", System.Convert.ToString(nvcTmp["engg_map_seq"]));
                            this.writer.WriteAttributeString("engg_mapped_entity", System.Convert.ToString(nvcTmp["engg_mapped_entity"]));
                            this.writer.WriteAttributeString("engg_ui_map", System.Convert.ToString(nvcTmp["engg_ui_map"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cggridmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCNTGRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cntgrdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cntgrdmlout");
                    this.writer.WriteAttributeString("RecordCount", htCNTGRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCNTGRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCNTGRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("ctrl_temp_cat", System.Convert.ToString(nvcTmp["ctrl_temp_cat"]));
                            this.writer.WriteAttributeString("ctrl_temp_specific", System.Convert.ToString(nvcTmp["ctrl_temp_specific"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlclass", System.Convert.ToString(nvcTmp["engg_cont_ctrlclass"]));
                            this.writer.WriteAttributeString("engg_cont_labclass", System.Convert.ToString(nvcTmp["engg_cont_labclass"]));
                            this.writer.WriteAttributeString("engg_cont_samp_data", System.Convert.ToString(nvcTmp["engg_cont_samp_data"]));
                            this.writer.WriteAttributeString("engg_cont_tempid", System.Convert.ToString(nvcTmp["engg_cont_tempid"]));
                            this.writer.WriteAttributeString("engg_cont_vis_length", System.Convert.ToString(nvcTmp["engg_cont_vis_length"]));
                            this.writer.WriteAttributeString("engg_freezecount", System.Convert.ToString(nvcTmp["engg_freezecount"]));
                            this.writer.WriteAttributeString("ep_lay_cont_capt", System.Convert.ToString(nvcTmp["ep_lay_cont_capt"]));
                            this.writer.WriteAttributeString("ep_lay_cont_hord", System.Convert.ToString(nvcTmp["ep_lay_cont_hord"]));
                            this.writer.WriteAttributeString("ep_lay_cont_map", System.Convert.ToString(nvcTmp["ep_lay_cont_map"]));
                            this.writer.WriteAttributeString("ep_lay_cont_name", System.Convert.ToString(nvcTmp["ep_lay_cont_name"]));
                            this.writer.WriteAttributeString("ep_lay_cont_seq", System.Convert.ToString(nvcTmp["ep_lay_cont_seq"]));
                            this.writer.WriteAttributeString("ep_lay_cont_type", System.Convert.ToString(nvcTmp["ep_lay_cont_type"]));
                            this.writer.WriteAttributeString("ep_lay_cont_vord", System.Convert.ToString(nvcTmp["ep_lay_cont_vord"]));
                            this.writer.WriteAttributeString("ep_lay_dat_col_wid", System.Convert.ToString(nvcTmp["ep_lay_dat_col_wid"]));
                            this.writer.WriteAttributeString("ep_lay_lab_col_wid", System.Convert.ToString(nvcTmp["ep_lay_lab_col_wid"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cntgrdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCOLGRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("colgrdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("colgrdmlout");
                    this.writer.WriteAttributeString("RecordCount", htCOLGRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCOLGRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCOLGRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("col_temp_cat", System.Convert.ToString(nvcTmp["col_temp_cat"]));
                            this.writer.WriteAttributeString("col_temp_specific", System.Convert.ToString(nvcTmp["col_temp_specific"]));
                            this.writer.WriteAttributeString("engg_col_tempid", System.Convert.ToString(nvcTmp["engg_col_tempid"]));
                            this.writer.WriteAttributeString("engg_columnclass", System.Convert.ToString(nvcTmp["engg_columnclass"]));
                            this.writer.WriteAttributeString("engg_grid_samp_data", System.Convert.ToString(nvcTmp["engg_grid_samp_data"]));
                            this.writer.WriteAttributeString("engg_grid_vis_length", System.Convert.ToString(nvcTmp["engg_grid_vis_length"]));
                            this.writer.WriteAttributeString("ep_lay_col_capt", System.Convert.ToString(nvcTmp["ep_lay_col_capt"]));
                            this.writer.WriteAttributeString("ep_lay_col_map", System.Convert.ToString(nvcTmp["ep_lay_col_map"]));
                            this.writer.WriteAttributeString("ep_lay_col_name", System.Convert.ToString(nvcTmp["ep_lay_col_name"]));
                            this.writer.WriteAttributeString("ep_lay_col_no", System.Convert.ToString(nvcTmp["ep_lay_col_no"]));
                            this.writer.WriteAttributeString("ep_lay_col_typ", System.Convert.ToString(nvcTmp["ep_lay_col_typ"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("colgrdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPAGGRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("paggrdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("paggrdmlout");
                    this.writer.WriteAttributeString("RecordCount", htPAGGRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htPAGGRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPAGGRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("ep_lay_hdr_post", System.Convert.ToString(nvcTmp["ep_lay_hdr_post"]));
                            this.writer.WriteAttributeString("ep_lay_pag_desc", System.Convert.ToString(nvcTmp["ep_lay_pag_desc"]));
                            this.writer.WriteAttributeString("ep_lay_pag_hord", System.Convert.ToString(nvcTmp["ep_lay_pag_hord"]));
                            this.writer.WriteAttributeString("ep_lay_pag_lay", System.Convert.ToString(nvcTmp["ep_lay_pag_lay"]));
                            this.writer.WriteAttributeString("ep_lay_pag_map", System.Convert.ToString(nvcTmp["ep_lay_pag_map"]));
                            this.writer.WriteAttributeString("ep_lay_pag_nam", System.Convert.ToString(nvcTmp["ep_lay_pag_nam"]));
                            this.writer.WriteAttributeString("ep_lay_pag_vord", System.Convert.ToString(nvcTmp["ep_lay_pag_vord"]));
                            this.writer.WriteAttributeString("ep_lay_tab_icpos", System.Convert.ToString(nvcTmp["ep_lay_tab_icpos"]));
                            this.writer.WriteAttributeString("ep_lay_tab_rot", System.Convert.ToString(nvcTmp["ep_lay_tab_rot"]));
                            this.writer.WriteAttributeString("ep_lay_tab_tstyl", System.Convert.ToString(nvcTmp["ep_lay_tab_tstyl"]));
                            this.writer.WriteAttributeString("ep_pag_lay_con", System.Convert.ToString(nvcTmp["ep_pag_lay_con"]));
                            this.writer.WriteAttributeString("ep_page_class", System.Convert.ToString(nvcTmp["ep_page_class"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("paggrdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvcPLF_STATE_SEGMENT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("plf_state_segment", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("plf_state_segment");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("hdnrt_stcontrol", System.Convert.ToString(nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("plf_state_segment", nvcPLF_STATE_SEGMENT);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htSECGRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("secgrdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("secgrdmlout");
                    this.writer.WriteAttributeString("RecordCount", htSECGRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htSECGRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSECGRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_lay_parent_sec", System.Convert.ToString(nvcTmp["engg_lay_parent_sec"]));
                            this.writer.WriteAttributeString("engg_sec_secclass", System.Convert.ToString(nvcTmp["engg_sec_secclass"]));
                            this.writer.WriteAttributeString("ep_lay_cap_algn", System.Convert.ToString(nvcTmp["ep_lay_cap_algn"]));
                            this.writer.WriteAttributeString("ep_lay_cap_for", System.Convert.ToString(nvcTmp["ep_lay_cap_for"]));
                            this.writer.WriteAttributeString("ep_lay_region", System.Convert.ToString(nvcTmp["ep_lay_region"]));
                            this.writer.WriteAttributeString("ep_lay_sec_bord", System.Convert.ToString(nvcTmp["ep_lay_sec_bord"]));
                            this.writer.WriteAttributeString("ep_lay_sec_coldir", System.Convert.ToString(nvcTmp["ep_lay_sec_coldir"]));
                            this.writer.WriteAttributeString("ep_lay_sec_height", System.Convert.ToString(nvcTmp["ep_lay_sec_height"]));
                            this.writer.WriteAttributeString("ep_lay_sec_hord", System.Convert.ToString(nvcTmp["ep_lay_sec_hord"]));
                            this.writer.WriteAttributeString("ep_lay_sec_lay", System.Convert.ToString(nvcTmp["ep_lay_sec_lay"]));
                            this.writer.WriteAttributeString("ep_lay_sec_map", System.Convert.ToString(nvcTmp["ep_lay_sec_map"]));
                            this.writer.WriteAttributeString("ep_lay_sec_nam", System.Convert.ToString(nvcTmp["ep_lay_sec_nam"]));
                            this.writer.WriteAttributeString("ep_lay_sec_titalgn", System.Convert.ToString(nvcTmp["ep_lay_sec_titalgn"]));
                            this.writer.WriteAttributeString("ep_lay_sec_titl", System.Convert.ToString(nvcTmp["ep_lay_sec_titl"]));
                            this.writer.WriteAttributeString("ep_lay_sec_titpos", System.Convert.ToString(nvcTmp["ep_lay_sec_titpos"]));
                            this.writer.WriteAttributeString("ep_lay_sec_titreq", System.Convert.ToString(nvcTmp["ep_lay_sec_titreq"]));
                            this.writer.WriteAttributeString("ep_lay_sec_typ", System.Convert.ToString(nvcTmp["ep_lay_sec_typ"]));
                            this.writer.WriteAttributeString("ep_lay_sec_vord", System.Convert.ToString(nvcTmp["ep_lay_sec_vord"]));
                            this.writer.WriteAttributeString("ep_lay_sec_wid", System.Convert.ToString(nvcTmp["ep_lay_sec_wid"]));
                            this.writer.WriteAttributeString("ep_sec_lay_con", System.Convert.ToString(nvcTmp["ep_sec_lay_con"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("secgrdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_app_dev_typ":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_format":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_colgrp_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_control_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_caption":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lay_pag_tab":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sect_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_hdr_pos":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_height":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_tab_rotate":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_style":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_laycon":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_layout":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_col_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_col_grd":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_col_page":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_col_sec":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_cont_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_cont_pag":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_cont_sect":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_page":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sect_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdncustomer":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnproject":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "prj_hdn_ctrl":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "plf_state_segment":
                        switch (DataItem)
                        {
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "cgctrcbseg":
                    type = 1;
                    break;
                case "cggcapcbseg":
                    type = 1;
                    break;
                case "cgpagcbseg":
                    type = 1;
                    break;
                case "cgseccbseg":
                    type = 1;
                    break;
                case "cntpagcbseg":
                    type = 1;
                    break;
                case "cntseccbseg":
                    type = 1;
                    break;
                case "colgdncbseg":
                    type = 1;
                    break;
                case "colpagcbseg":
                    type = 1;
                    break;
                case "colseccbseg":
                    type = 1;
                    break;
                case "devtypcbseg":
                    type = 1;
                    break;
                case "parsecmlcbsg":
                    type = 1;
                    break;
                case "secpagcbseg":
                    type = 1;
                    break;
                case "uidesccbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "cggridmlout":
                    type = 1;
                    break;
                case "cntgrdmlout":
                    type = 1;
                    break;
                case "colgrdmlout":
                    type = 1;
                    break;
                case "paggrdmlout":
                    type = 1;
                    break;
                case "plf_state_segment":
                    type = 0;
                    break;
                case "secgrdmlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "cgctrcbseg":
                    return htCGCTRCBSEG.Count;
                    break;
                case "cggcapcbseg":
                    return htCGGCAPCBSEG.Count;
                    break;
                case "cgpagcbseg":
                    return htCGPAGCBSEG.Count;
                    break;
                case "cgseccbseg":
                    return htCGSECCBSEG.Count;
                    break;
                case "cntpagcbseg":
                    return htCNTPAGCBSEG.Count;
                    break;
                case "cntseccbseg":
                    return htCNTSECCBSEG.Count;
                    break;
                case "colgdncbseg":
                    return htCOLGDNCBSEG.Count;
                    break;
                case "colpagcbseg":
                    return htCOLPAGCBSEG.Count;
                    break;
                case "colseccbseg":
                    return htCOLSECCBSEG.Count;
                    break;
                case "devtypcbseg":
                    return htDEVTYPCBSEG.Count;
                    break;
                case "parsecmlcbsg":
                    return htPARSECMLCBSG.Count;
                    break;
                case "secpagcbseg":
                    return htSECPAGCBSEG.Count;
                    break;
                case "uidesccbseg":
                    return htUIDESCCBSEG.Count;
                    break;
                case "cggridmlout":
                    return htCGGRIDMLOUT.Count;
                    break;
                case "cntgrdmlout":
                    return htCNTGRDMLOUT.Count;
                    break;
                case "colgrdmlout":
                    return htCOLGRDMLOUT.Count;
                    break;
                case "paggrdmlout":
                    return htPAGGRDMLOUT.Count;
                    break;
                case "secgrdmlout":
                    return htSECGRDMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "cgctrcbseg":
                    return this.htCGCTRCBSEG;
                case "cggcapcbseg":
                    return this.htCGGCAPCBSEG;
                case "cgpagcbseg":
                    return this.htCGPAGCBSEG;
                case "cgseccbseg":
                    return this.htCGSECCBSEG;
                case "cntpagcbseg":
                    return this.htCNTPAGCBSEG;
                case "cntseccbseg":
                    return this.htCNTSECCBSEG;
                case "colgdncbseg":
                    return this.htCOLGDNCBSEG;
                case "colpagcbseg":
                    return this.htCOLPAGCBSEG;
                case "colseccbseg":
                    return this.htCOLSECCBSEG;
                case "devtypcbseg":
                    return this.htDEVTYPCBSEG;
                case "parsecmlcbsg":
                    return this.htPARSECMLCBSG;
                case "secpagcbseg":
                    return this.htSECPAGCBSEG;
                case "uidesccbseg":
                    return this.htUIDESCCBSEG;
                case "cggridmlout":
                    return this.htCGGRIDMLOUT;
                case "cntgrdmlout":
                    return this.htCNTGRDMLOUT;
                case "colgrdmlout":
                    return this.htCOLGRDMLOUT;
                case "paggrdmlout":
                    return this.htPAGGRDMLOUT;
                case "secgrdmlout":
                    return this.htSECGRDMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                case "plf_state_segment":
                    return this.nvcPLF_STATE_SEGMENT;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "cgctrcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgctrcbseg = (NameValueCollection)htCGCTRCBSEG[lnInstNumber];
                        return nvcTmpcgctrcbseg[szDataItem];
                        break;
                    case "cggcapcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcggcapcbseg = (NameValueCollection)htCGGCAPCBSEG[lnInstNumber];
                        return nvcTmpcggcapcbseg[szDataItem];
                        break;
                    case "cgpagcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgpagcbseg = (NameValueCollection)htCGPAGCBSEG[lnInstNumber];
                        return nvcTmpcgpagcbseg[szDataItem];
                        break;
                    case "cgseccbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcgseccbseg = (NameValueCollection)htCGSECCBSEG[lnInstNumber];
                        return nvcTmpcgseccbseg[szDataItem];
                        break;
                    case "cntpagcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcntpagcbseg = (NameValueCollection)htCNTPAGCBSEG[lnInstNumber];
                        return nvcTmpcntpagcbseg[szDataItem];
                        break;
                    case "cntseccbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcntseccbseg = (NameValueCollection)htCNTSECCBSEG[lnInstNumber];
                        return nvcTmpcntseccbseg[szDataItem];
                        break;
                    case "colgdncbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcolgdncbseg = (NameValueCollection)htCOLGDNCBSEG[lnInstNumber];
                        return nvcTmpcolgdncbseg[szDataItem];
                        break;
                    case "colpagcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcolpagcbseg = (NameValueCollection)htCOLPAGCBSEG[lnInstNumber];
                        return nvcTmpcolpagcbseg[szDataItem];
                        break;
                    case "colseccbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcolseccbseg = (NameValueCollection)htCOLSECCBSEG[lnInstNumber];
                        return nvcTmpcolseccbseg[szDataItem];
                        break;
                    case "devtypcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpdevtypcbseg = (NameValueCollection)htDEVTYPCBSEG[lnInstNumber];
                        return nvcTmpdevtypcbseg[szDataItem];
                        break;
                    case "parsecmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpparsecmlcbsg = (NameValueCollection)htPARSECMLCBSG[lnInstNumber];
                        return nvcTmpparsecmlcbsg[szDataItem];
                        break;
                    case "secpagcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsecpagcbseg = (NameValueCollection)htSECPAGCBSEG[lnInstNumber];
                        return nvcTmpsecpagcbseg[szDataItem];
                        break;
                    case "uidesccbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpuidesccbseg = (NameValueCollection)htUIDESCCBSEG[lnInstNumber];
                        return nvcTmpuidesccbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "cggridmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpcggridmlout = (NameValueCollection)htCGGRIDMLOUT[lnInstNumber];
                        return nvcTmpcggridmlout[szDataItem];
                        break;
                    case "cntgrdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpcntgrdmlout = (NameValueCollection)htCNTGRDMLOUT[lnInstNumber];
                        return nvcTmpcntgrdmlout[szDataItem];
                        break;
                    case "colgrdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpcolgrdmlout = (NameValueCollection)htCOLGRDMLOUT[lnInstNumber];
                        return nvcTmpcolgrdmlout[szDataItem];
                        break;
                    case "paggrdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmppaggrdmlout = (NameValueCollection)htPAGGRDMLOUT[lnInstNumber];
                        return nvcTmppaggrdmlout[szDataItem];
                        break;
                    case "plf_state_segment":
                        return nvcPLF_STATE_SEGMENT[szDataItem];
                        break;
                    case "secgrdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpsecgrdmlout = (NameValueCollection)htSECGRDMLOUT[lnInstNumber];
                        return nvcTmpsecgrdmlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_laymngsractdes Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_laymngsractdes Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdesdevtyp", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdesdevtyp", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115493, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115493, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htDEVTYPCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_app_dev_typ");
                                    nvcTmp["engg_app_dev_typ"] = sValue;
                                    htDEVTYPCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115493, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 2  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescgctr", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescgctr", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115494, 1, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115494, 1, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGCTRCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_control_name");
                                    nvcTmp["engg_control_name"] = sValue;
                                    htCGCTRCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115494, 1, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 3  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescggcap", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescggcap", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115495, 1, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115495, 1, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGGCAPCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_group_caption");
                                    nvcTmp["engg_group_caption"] = sValue;
                                    htCGGCAPCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115495, 1, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 4  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescgpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescgpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115496, 1, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115496, 1, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGPAGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_page_name");
                                    nvcTmp["engg_page_name"] = sValue;
                                    htCGPAGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115496, 1, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 5  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescgsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescgsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115497, 1, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115497, 1, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGSECCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sect_name");
                                    nvcTmp["engg_sect_name"] = sValue;
                                    htCGSECCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115497, 1, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 6  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdesuidesc", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdesuidesc", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115498, 1, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115498, 1, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htUIDESCCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_ui_descr");
                                    nvcTmp["engg_ui_descr"] = sValue;
                                    htUIDESCCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115498, 1, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 7  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescolgdn", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescolgdn", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115499, 1, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115499, 1, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCOLGDNCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_col_grd");
                                    nvcTmp["ep_lay_col_grd"] = sValue;
                                    htCOLGDNCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115499, 1, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 8  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescolpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescolpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115500, 1, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115500, 1, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCOLPAGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_col_page");
                                    nvcTmp["ep_lay_col_page"] = sValue;
                                    htCOLPAGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115500, 1, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 9  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescolsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescolsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115501, 1, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115501, 1, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCOLSECCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_col_sec");
                                    nvcTmp["ep_lay_col_sec"] = sValue;
                                    htCOLSECCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115501, 1, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 10  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescntpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescntpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115502, 1, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115502, 1, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCNTPAGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_cont_pag");
                                    nvcTmp["ep_lay_cont_pag"] = sValue;
                                    htCNTPAGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115502, 1, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 11  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescntsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescntsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115503, 1, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115503, 1, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCNTSECCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_cont_sect");
                                    nvcTmp["ep_lay_cont_sect"] = sValue;
                                    htCNTSECCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115503, 1, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 12  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdessecpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdessecpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115504, 1, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115504, 1, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSECPAGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_sec_page");
                                    nvcTmp["ep_lay_sec_page"] = sValue;
                                    htSECPAGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115504, 1, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 13  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdescbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdesparsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdesparsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115505, 1, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115505, 1, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPARSECMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_parent_sec");
                                    nvcTmp["engg_lay_parent_sec"] = sValue;
                                    htPARSECMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115505, 1, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdeshpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdeshdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdeshdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115506, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115506, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_act_descr");
                                nvc_HSEG["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_app_dev_typ");
                                nvc_HSEG["engg_app_dev_typ"] = sValue;
                                sValue = this.GetValue("engg_att_def");
                                nvc_HSEG["engg_att_def"] = sValue;
                                sValue = this.GetValue("engg_att_ui_format");
                                nvc_HSEG["engg_att_ui_format"] = sValue;
                                sValue = this.GetValue("engg_colgrp_def");
                                nvc_HSEG["engg_colgrp_def"] = sValue;
                                sValue = this.GetValue("engg_component");
                                nvc_HSEG["engg_component"] = sValue;
                                sValue = this.GetValue("engg_control_name");
                                nvc_HSEG["engg_control_name"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HSEG["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_group_caption");
                                nvc_HSEG["engg_group_caption"] = sValue;
                                sValue = this.GetValue("engg_group_name");
                                nvc_HSEG["engg_group_name"] = sValue;
                                sValue = this.GetValue("engg_lay_pag_tab");
                                nvc_HSEG["engg_lay_pag_tab"] = sValue;
                                sValue = this.GetValue("engg_page_name");
                                nvc_HSEG["engg_page_name"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HSEG["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HSEG["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_req_no");
                                nvc_HSEG["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_sect_name");
                                nvc_HSEG["engg_sect_name"] = sValue;
                                sValue = this.GetValue("engg_tab_hdr_pos");
                                nvc_HSEG["engg_tab_hdr_pos"] = sValue;
                                sValue = this.GetValue("engg_tab_height");
                                nvc_HSEG["engg_tab_height"] = sValue;
                                sValue = this.GetValue("engg_tab_rotate");
                                nvc_HSEG["engg_tab_rotate"] = sValue;
                                sValue = this.GetValue("engg_tab_style");
                                nvc_HSEG["engg_tab_style"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HSEG["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("engg_ui_laycon");
                                nvc_HSEG["engg_ui_laycon"] = sValue;
                                sValue = this.GetValue("engg_ui_layout");
                                nvc_HSEG["engg_ui_layout"] = sValue;
                                sValue = this.GetValue("ep_lay_col_def");
                                nvc_HSEG["ep_lay_col_def"] = sValue;
                                sValue = this.GetValue("ep_lay_col_grd");
                                nvc_HSEG["ep_lay_col_grd"] = sValue;
                                sValue = this.GetValue("ep_lay_col_page");
                                nvc_HSEG["ep_lay_col_page"] = sValue;
                                sValue = this.GetValue("ep_lay_col_sec");
                                nvc_HSEG["ep_lay_col_sec"] = sValue;
                                sValue = this.GetValue("ep_lay_cont_def");
                                nvc_HSEG["ep_lay_cont_def"] = sValue;
                                sValue = this.GetValue("ep_lay_cont_pag");
                                nvc_HSEG["ep_lay_cont_pag"] = sValue;
                                sValue = this.GetValue("ep_lay_cont_sect");
                                nvc_HSEG["ep_lay_cont_sect"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_page");
                                nvc_HSEG["ep_lay_sec_page"] = sValue;
                                sValue = this.GetValue("ep_lay_sect_def");
                                nvc_HSEG["ep_lay_sect_def"] = sValue;
                                sValue = this.GetValue("hdncustomer");
                                nvc_HSEG["hdncustomer"] = sValue;
                                sValue = this.GetValue("hdnproject");
                                nvc_HSEG["hdnproject"] = sValue;
                                sValue = this.GetValue("prj_hdn_ctrl");
                                nvc_HSEG["prj_hdn_ctrl"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115506, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescggridmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescggridspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115507, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115507, 3, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCGGRIDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_col_or_group");
                                    nvcTmp["engg_col_or_group"] = sValue;
                                    sValue = this.GetValue("engg_map_seq");
                                    nvcTmp["engg_map_seq"] = sValue;
                                    sValue = this.GetValue("engg_mapped_entity");
                                    nvcTmp["engg_mapped_entity"] = sValue;
                                    sValue = this.GetValue("engg_ui_map");
                                    nvcTmp["engg_ui_map"] = sValue;
                                    htCGGRIDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115507, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 2  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescolgrdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescolgrdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115508, 3, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115508, 3, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCOLGRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("col_temp_cat");
                                    nvcTmp["col_temp_cat"] = sValue;
                                    sValue = this.GetValue("col_temp_specific");
                                    nvcTmp["col_temp_specific"] = sValue;
                                    sValue = this.GetValue("engg_col_tempid");
                                    nvcTmp["engg_col_tempid"] = sValue;
                                    sValue = this.GetValue("engg_columnclass");
                                    nvcTmp["engg_columnclass"] = sValue;
                                    sValue = this.GetValue("engg_grid_samp_data");
                                    nvcTmp["engg_grid_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_grid_vis_length");
                                    nvcTmp["engg_grid_vis_length"] = sValue;
                                    sValue = this.GetValue("ep_lay_col_capt");
                                    nvcTmp["ep_lay_col_capt"] = sValue;
                                    sValue = this.GetValue("ep_lay_col_map");
                                    nvcTmp["ep_lay_col_map"] = sValue;
                                    sValue = this.GetValue("ep_lay_col_name");
                                    nvcTmp["ep_lay_col_name"] = sValue;
                                    sValue = this.GetValue("ep_lay_col_no");
                                    nvcTmp["ep_lay_col_no"] = sValue;
                                    sValue = this.GetValue("ep_lay_col_typ");
                                    nvcTmp["ep_lay_col_typ"] = sValue;
                                    htCOLGRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115508, 3, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 3  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdescntgrdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdescntgrdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115509, 3, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115509, 3, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCNTGRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ctrl_temp_cat");
                                    nvcTmp["ctrl_temp_cat"] = sValue;
                                    sValue = this.GetValue("ctrl_temp_specific");
                                    nvcTmp["ctrl_temp_specific"] = sValue;
                                    sValue = this.GetValue("engg_cont_ctrlclass");
                                    nvcTmp["engg_cont_ctrlclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_labclass");
                                    nvcTmp["engg_cont_labclass"] = sValue;
                                    sValue = this.GetValue("engg_cont_samp_data");
                                    nvcTmp["engg_cont_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_cont_tempid");
                                    nvcTmp["engg_cont_tempid"] = sValue;
                                    sValue = this.GetValue("engg_cont_vis_length");
                                    nvcTmp["engg_cont_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_freezecount");
                                    nvcTmp["engg_freezecount"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_capt");
                                    nvcTmp["ep_lay_cont_capt"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_hord");
                                    nvcTmp["ep_lay_cont_hord"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_map");
                                    nvcTmp["ep_lay_cont_map"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_name");
                                    nvcTmp["ep_lay_cont_name"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_seq");
                                    nvcTmp["ep_lay_cont_seq"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_type");
                                    nvcTmp["ep_lay_cont_type"] = sValue;
                                    sValue = this.GetValue("ep_lay_cont_vord");
                                    nvcTmp["ep_lay_cont_vord"] = sValue;
                                    sValue = this.GetValue("ep_lay_dat_col_wid");
                                    nvcTmp["ep_lay_dat_col_wid"] = sValue;
                                    sValue = this.GetValue("ep_lay_lab_col_wid");
                                    nvcTmp["ep_lay_lab_col_wid"] = sValue;
                                    htCNTGRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115509, 3, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 4  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdespaggrdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdespaggrdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115510, 3, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115510, 3, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPAGGRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_lay_hdr_post");
                                    nvcTmp["ep_lay_hdr_post"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_desc");
                                    nvcTmp["ep_lay_pag_desc"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_hord");
                                    nvcTmp["ep_lay_pag_hord"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_lay");
                                    nvcTmp["ep_lay_pag_lay"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_map");
                                    nvcTmp["ep_lay_pag_map"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_nam");
                                    nvcTmp["ep_lay_pag_nam"] = sValue;
                                    sValue = this.GetValue("ep_lay_pag_vord");
                                    nvcTmp["ep_lay_pag_vord"] = sValue;
                                    sValue = this.GetValue("ep_lay_tab_icpos");
                                    nvcTmp["ep_lay_tab_icpos"] = sValue;
                                    sValue = this.GetValue("ep_lay_tab_rot");
                                    nvcTmp["ep_lay_tab_rot"] = sValue;
                                    sValue = this.GetValue("ep_lay_tab_tstyl");
                                    nvcTmp["ep_lay_tab_tstyl"] = sValue;
                                    sValue = this.GetValue("ep_pag_lay_con");
                                    nvcTmp["ep_pag_lay_con"] = sValue;
                                    sValue = this.GetValue("ep_page_class");
                                    nvcTmp["ep_page_class"] = sValue;
                                    htPAGGRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115510, 3, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 5  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdessecgrdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdessecgrdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115511, 3, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115511, 3, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSECGRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_parent_sec");
                                    nvcTmp["engg_lay_parent_sec"] = sValue;
                                    sValue = this.GetValue("engg_sec_secclass");
                                    nvcTmp["engg_sec_secclass"] = sValue;
                                    sValue = this.GetValue("ep_lay_cap_algn");
                                    nvcTmp["ep_lay_cap_algn"] = sValue;
                                    sValue = this.GetValue("ep_lay_cap_for");
                                    nvcTmp["ep_lay_cap_for"] = sValue;
                                    sValue = this.GetValue("ep_lay_region");
                                    nvcTmp["ep_lay_region"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_bord");
                                    nvcTmp["ep_lay_sec_bord"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_coldir");
                                    nvcTmp["ep_lay_sec_coldir"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_height");
                                    nvcTmp["ep_lay_sec_height"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_hord");
                                    nvcTmp["ep_lay_sec_hord"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_lay");
                                    nvcTmp["ep_lay_sec_lay"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_map");
                                    nvcTmp["ep_lay_sec_map"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_nam");
                                    nvcTmp["ep_lay_sec_nam"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_titalgn");
                                    nvcTmp["ep_lay_sec_titalgn"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_titl");
                                    nvcTmp["ep_lay_sec_titl"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_titpos");
                                    nvcTmp["ep_lay_sec_titpos"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_titreq");
                                    nvcTmp["ep_lay_sec_titreq"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_typ");
                                    nvcTmp["ep_lay_sec_typ"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_vord");
                                    nvcTmp["ep_lay_sec_vord"] = sValue;
                                    sValue = this.GetValue("ep_lay_sec_wid");
                                    nvcTmp["ep_lay_sec_wid"] = sValue;
                                    sValue = this.GetValue("ep_sec_lay_con");
                                    nvcTmp["ep_sec_lay_con"] = sValue;
                                    htSECGRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115511, 3, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 3
                // Starting to execute the BR - 6  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactdespsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_app_dev_typ"];
                            base.Parameters("@engg_app_dev_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_att_def"];
                            base.Parameters("@engg_att_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_colgrp_def"];
                            base.Parameters("@engg_colgrp_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_lay_pag_tab"];
                            base.Parameters("@engg_lay_pag_tab", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HSEGengg_tab_height);
                            sValue = nvc_HSEG["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_def"];
                            base.Parameters("@ep_lay_col_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_col_grd"];
                            base.Parameters("@ep_lay_col_grd", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_page"];
                            base.Parameters("@ep_lay_col_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_col_sec"];
                            base.Parameters("@ep_lay_col_sec", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_def"];
                            base.Parameters("@ep_lay_cont_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_pag"];
                            base.Parameters("@ep_lay_cont_pag", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_cont_sect"];
                            base.Parameters("@ep_lay_cont_sect", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 128, sValue);
                            sValue = nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtactdes_statemto", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspactdes_statespo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115512, 3, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115512, 3, 6);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("hdnrt_stcontrol");
                                nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115512, 3, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "cgctrcbseg":
                            Localtable = (NameValueCollection)htCGCTRCBSEG[lInstance];
                            break;
                        case "cggcapcbseg":
                            Localtable = (NameValueCollection)htCGGCAPCBSEG[lInstance];
                            break;
                        case "cgpagcbseg":
                            Localtable = (NameValueCollection)htCGPAGCBSEG[lInstance];
                            break;
                        case "cgseccbseg":
                            Localtable = (NameValueCollection)htCGSECCBSEG[lInstance];
                            break;
                        case "cntpagcbseg":
                            Localtable = (NameValueCollection)htCNTPAGCBSEG[lInstance];
                            break;
                        case "cntseccbseg":
                            Localtable = (NameValueCollection)htCNTSECCBSEG[lInstance];
                            break;
                        case "colgdncbseg":
                            Localtable = (NameValueCollection)htCOLGDNCBSEG[lInstance];
                            break;
                        case "colpagcbseg":
                            Localtable = (NameValueCollection)htCOLPAGCBSEG[lInstance];
                            break;
                        case "colseccbseg":
                            Localtable = (NameValueCollection)htCOLSECCBSEG[lInstance];
                            break;
                        case "devtypcbseg":
                            Localtable = (NameValueCollection)htDEVTYPCBSEG[lInstance];
                            break;
                        case "parsecmlcbsg":
                            Localtable = (NameValueCollection)htPARSECMLCBSG[lInstance];
                            break;
                        case "secpagcbseg":
                            Localtable = (NameValueCollection)htSECPAGCBSEG[lInstance];
                            break;
                        case "uidesccbseg":
                            Localtable = (NameValueCollection)htUIDESCCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "cggridmlout":
                            Localtable = (NameValueCollection)htCGGRIDMLOUT[lInstance];
                            break;
                        case "cntgrdmlout":
                            Localtable = (NameValueCollection)htCNTGRDMLOUT[lInstance];
                            break;
                        case "colgrdmlout":
                            Localtable = (NameValueCollection)htCOLGRDMLOUT[lInstance];
                            break;
                        case "paggrdmlout":
                            Localtable = (NameValueCollection)htPAGGRDMLOUT[lInstance];
                            break;
                        case "plf_state_segment":
                            Localtable = nvcPLF_STATE_SEGMENT;
                            break;
                        case "secgrdmlout":
                            Localtable = (NameValueCollection)htSECGRDMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_laymngsractdes(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_laymngsractdes(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_laymngsractdes.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

