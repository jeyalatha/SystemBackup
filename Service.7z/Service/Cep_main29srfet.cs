/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_main29srfet.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_main29srfet : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htLISTEDIT_ENGGLT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLISTEDIT_ENGGOL = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htENG_PLMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGB_RMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_BMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_DMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_EMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_GMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGABMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGC_MLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGHDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGLIMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGLLMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGMLMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGPLMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGRLMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGSYMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGLINMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGPAGMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGS_LMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGSECMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htEP_CONMLOUT = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvcPLF_STATE_SEGMENT = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htTREE_CONFIG_SEGMENT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTREE_DATA_SEGMENT = new System.Collections.Hashtable();
        private string modeFlagValue = string.Empty;
        public Cep_main29srfet()
        {
            base.iEDKESEngineInit("ep_main29srfet", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htLISTEDIT_ENGGLT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("listedit_engglt", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("listedit_engglt");
                    this.writer.WriteAttributeString("RecordCount", htLISTEDIT_ENGGLT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLISTEDIT_ENGGLT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLISTEDIT_ENGGLT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ctrl_descr", System.Convert.ToString(nvcTmp["ctrl_descr"]));
                            this.writer.WriteAttributeString("ctrl_type", System.Convert.ToString(nvcTmp["ctrl_type"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("listedit_engglt", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLISTEDIT_ENGGOL != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("listedit_enggol", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("listedit_enggol");
                    this.writer.WriteAttributeString("RecordCount", htLISTEDIT_ENGGOL.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLISTEDIT_ENGGOL.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLISTEDIT_ENGGOL[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("col_descr", System.Convert.ToString(nvcTmp["col_descr"]));
                            this.writer.WriteAttributeString("col_type", System.Convert.ToString(nvcTmp["col_type"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("listedit_enggol", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvc_HSEG["engg_act_descr"]));
                    this.writer.WriteAttributeString("engg_action_type", System.Convert.ToString(nvc_HSEG["engg_action_type"]));
                    this.writer.WriteAttributeString("engg_component", System.Convert.ToString(nvc_HSEG["engg_component"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HSEG["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_gen_task_uage", System.Convert.ToString(nvc_HSEG["engg_gen_task_uage"]));
                    this.writer.WriteAttributeString("engg_hdr_ctrl_btscap", System.Convert.ToString(nvc_HSEG["engg_hdr_ctrl_btscap"]));
                    this.writer.WriteAttributeString("engg_hdr_ctrl_btsyn", System.Convert.ToString(nvc_HSEG["engg_hdr_ctrl_btsyn"]));
                    this.writer.WriteAttributeString("engg_lls_name", System.Convert.ToString(nvc_HSEG["engg_lls_name"]));
                    this.writer.WriteAttributeString("engg_mob_task_uage", System.Convert.ToString(nvc_HSEG["engg_mob_task_uage"]));
                    this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvc_HSEG["engg_page_name"]));
                    this.writer.WriteAttributeString("engg_pls_name", System.Convert.ToString(nvc_HSEG["engg_pls_name"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HSEG["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HSEG["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_psec_name", System.Convert.ToString(nvc_HSEG["engg_psec_name"]));
                    this.writer.WriteAttributeString("engg_req_no", System.Convert.ToString(nvc_HSEG["engg_req_no"]));
                    this.writer.WriteAttributeString("engg_rls_name", System.Convert.ToString(nvc_HSEG["engg_rls_name"]));
                    this.writer.WriteAttributeString("engg_sec_name", System.Convert.ToString(nvc_HSEG["engg_sec_name"]));
                    this.writer.WriteAttributeString("engg_tab_lls_name", System.Convert.ToString(nvc_HSEG["engg_tab_lls_name"]));
                    this.writer.WriteAttributeString("engg_tab_pls_name", System.Convert.ToString(nvc_HSEG["engg_tab_pls_name"]));
                    this.writer.WriteAttributeString("engg_tab_rls_name", System.Convert.ToString(nvc_HSEG["engg_tab_rls_name"]));
                    this.writer.WriteAttributeString("engg_tab_task_uage", System.Convert.ToString(nvc_HSEG["engg_tab_task_uage"]));
                    this.writer.WriteAttributeString("engg_task_uage", System.Convert.ToString(nvc_HSEG["engg_task_uage"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HSEG["engg_ui_descr"]));
                    this.writer.WriteAttributeString("hdncustomer", System.Convert.ToString(nvc_HSEG["hdncustomer"]));
                    this.writer.WriteAttributeString("hdnproject", System.Convert.ToString(nvc_HSEG["hdnproject"]));
                    this.writer.WriteAttributeString("prj_hdn_ctrl", System.Convert.ToString(nvc_HSEG["prj_hdn_ctrl"]));
                    this.writer.WriteAttributeString("treenodetask", System.Convert.ToString(nvc_HSEG["treenodetask"]));
                    this.writer.WriteAttributeString("treenodetaskgeneral", System.Convert.ToString(nvc_HSEG["treenodetaskgeneral"]));
                    this.writer.WriteAttributeString("treenodetasktablet", System.Convert.ToString(nvc_HSEG["treenodetasktablet"]));
                    this.writer.WriteAttributeString("tvwengg_mobile_treenodeid", System.Convert.ToString(nvc_HSEG["tvwengg_mobile_treenodeid"]));
                    this.writer.WriteAttributeString("tvwengg_system_treenodeid", System.Convert.ToString(nvc_HSEG["tvwengg_system_treenodeid"]));
                    this.writer.WriteAttributeString("tvwengg_tablet_treenodeid", System.Convert.ToString(nvc_HSEG["tvwengg_tablet_treenodeid"]));
                    this.writer.WriteAttributeString("xmlgeneditctrlgeneral", System.Convert.ToString(nvc_HSEG["xmlgeneditctrlgeneral"]));
                    this.writer.WriteAttributeString("xmlgeneditctrlmob", System.Convert.ToString(nvc_HSEG["xmlgeneditctrlmob"]));
                    this.writer.WriteAttributeString("xmlgeneditctrltab", System.Convert.ToString(nvc_HSEG["xmlgeneditctrltab"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htENG_PLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("eng_plmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("eng_plmlout");
                    this.writer.WriteAttributeString("RecordCount", htENG_PLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENG_PLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENG_PLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_tab_pls_descr", System.Convert.ToString(nvcTmp["engg_tab_pls_descr"]));
                            this.writer.WriteAttributeString("engg_tab_pls_horder", System.Convert.ToString(nvcTmp["engg_tab_pls_horder"]));
                            this.writer.WriteAttributeString("engg_tab_pls_img_name", System.Convert.ToString(nvcTmp["engg_tab_pls_img_name"]));
                            this.writer.WriteAttributeString("engg_tab_pls_nam", System.Convert.ToString(nvcTmp["engg_tab_pls_nam"]));
                            this.writer.WriteAttributeString("engg_tab_pls_titreq", System.Convert.ToString(nvcTmp["engg_tab_pls_titreq"]));
                            this.writer.WriteAttributeString("engg_tab_pls_visible", System.Convert.ToString(nvcTmp["engg_tab_pls_visible"]));
                            this.writer.WriteAttributeString("engg_tab_pls_vorder", System.Convert.ToString(nvcTmp["engg_tab_pls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("eng_plmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGB_RMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engb_rmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engb_rmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGB_RMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGB_RMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGB_RMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_tab_rls_descr", System.Convert.ToString(nvcTmp["engg_tab_rls_descr"]));
                            this.writer.WriteAttributeString("engg_tab_rls_horder", System.Convert.ToString(nvcTmp["engg_tab_rls_horder"]));
                            this.writer.WriteAttributeString("engg_tab_rls_img_name", System.Convert.ToString(nvcTmp["engg_tab_rls_img_name"]));
                            this.writer.WriteAttributeString("engg_tab_rls_nam", System.Convert.ToString(nvcTmp["engg_tab_rls_nam"]));
                            this.writer.WriteAttributeString("engg_tab_rls_titreq", System.Convert.ToString(nvcTmp["engg_tab_rls_titreq"]));
                            this.writer.WriteAttributeString("engg_tab_rls_visible", System.Convert.ToString(nvcTmp["engg_tab_rls_visible"]));
                            this.writer.WriteAttributeString("engg_tab_rls_vorder", System.Convert.ToString(nvcTmp["engg_tab_rls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engb_rmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_BMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_bmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_bmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_BMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_BMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_BMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_mob_ctrl_btsyn", System.Convert.ToString(nvcTmp["engg_mob_ctrl_btsyn"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_caption", System.Convert.ToString(nvcTmp["engg_mob_ctrl_caption"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_horder", System.Convert.ToString(nvcTmp["engg_mob_ctrl_horder"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_image_name", System.Convert.ToString(nvcTmp["engg_mob_ctrl_image_name"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_ordseq", System.Convert.ToString(nvcTmp["engg_mob_ctrl_ordseq"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_type", System.Convert.ToString(nvcTmp["engg_mob_ctrl_type"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_vislen", System.Convert.ToString(nvcTmp["engg_mob_ctrl_vislen"]));
                            this.writer.WriteAttributeString("engg_mob_ctrl_vorder", System.Convert.ToString(nvcTmp["engg_mob_ctrl_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_bmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_DMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_dmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_dmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_DMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_DMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_DMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_radio_caption", System.Convert.ToString(nvcTmp["engg_radio_caption"]));
                            this.writer.WriteAttributeString("engg_radio_code", System.Convert.ToString(nvcTmp["engg_radio_code"]));
                            this.writer.WriteAttributeString("engg_radio_default", System.Convert.ToString(nvcTmp["engg_radio_default"]));
                            this.writer.WriteAttributeString("engg_radio_horder", System.Convert.ToString(nvcTmp["engg_radio_horder"]));
                            this.writer.WriteAttributeString("engg_radio_seq", System.Convert.ToString(nvcTmp["engg_radio_seq"]));
                            this.writer.WriteAttributeString("engg_radio_vorder", System.Convert.ToString(nvcTmp["engg_radio_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_dmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_EMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_emlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_emlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_EMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_EMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_EMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_enum_caption", System.Convert.ToString(nvcTmp["engg_enum_caption"]));
                            this.writer.WriteAttributeString("engg_enum_code", System.Convert.ToString(nvcTmp["engg_enum_code"]));
                            this.writer.WriteAttributeString("engg_enum_default", System.Convert.ToString(nvcTmp["engg_enum_default"]));
                            this.writer.WriteAttributeString("engg_enum_seqno", System.Convert.ToString(nvcTmp["engg_enum_seqno"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_emlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_GMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_gmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_gmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_GMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_GMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_GMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_grid_colcap", System.Convert.ToString(nvcTmp["engg_grid_colcap"]));
                            this.writer.WriteAttributeString("engg_grid_coliskey", System.Convert.ToString(nvcTmp["engg_grid_coliskey"]));
                            this.writer.WriteAttributeString("engg_grid_coliskeyno", System.Convert.ToString(nvcTmp["engg_grid_coliskeyno"]));
                            this.writer.WriteAttributeString("engg_grid_colname", System.Convert.ToString(nvcTmp["engg_grid_colname"]));
                            this.writer.WriteAttributeString("engg_grid_colno", System.Convert.ToString(nvcTmp["engg_grid_colno"]));
                            this.writer.WriteAttributeString("engg_grid_coltype", System.Convert.ToString(nvcTmp["engg_grid_coltype"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_gmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGABMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggabmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggabmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGABMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGABMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGABMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_tab_ctrl_btsyn", System.Convert.ToString(nvcTmp["engg_tab_ctrl_btsyn"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_caption", System.Convert.ToString(nvcTmp["engg_tab_ctrl_caption"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_horder", System.Convert.ToString(nvcTmp["engg_tab_ctrl_horder"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_image_name", System.Convert.ToString(nvcTmp["engg_tab_ctrl_image_name"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_ordseq", System.Convert.ToString(nvcTmp["engg_tab_ctrl_ordseq"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_type", System.Convert.ToString(nvcTmp["engg_tab_ctrl_type"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_vislen", System.Convert.ToString(nvcTmp["engg_tab_ctrl_vislen"]));
                            this.writer.WriteAttributeString("engg_tab_ctrl_vorder", System.Convert.ToString(nvcTmp["engg_tab_ctrl_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggabmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGC_MLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggc_mlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggc_mlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGC_MLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGC_MLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGC_MLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_sys_psec_capalg", System.Convert.ToString(nvcTmp["engg_sys_psec_capalg"]));
                            this.writer.WriteAttributeString("engg_sys_psec_capfor", System.Convert.ToString(nvcTmp["engg_sys_psec_capfor"]));
                            this.writer.WriteAttributeString("engg_sys_psec_descr", System.Convert.ToString(nvcTmp["engg_sys_psec_descr"]));
                            this.writer.WriteAttributeString("engg_sys_psec_doc", System.Convert.ToString(nvcTmp["engg_sys_psec_doc"]));
                            this.writer.WriteAttributeString("engg_sys_psec_hig", System.Convert.ToString(nvcTmp["engg_sys_psec_hig"]));
                            this.writer.WriteAttributeString("engg_sys_psec_horder", System.Convert.ToString(nvcTmp["engg_sys_psec_horder"]));
                            this.writer.WriteAttributeString("engg_sys_psec_name", System.Convert.ToString(nvcTmp["engg_sys_psec_name"]));
                            this.writer.WriteAttributeString("engg_sys_psec_prefix", System.Convert.ToString(nvcTmp["engg_sys_psec_prefix"]));
                            this.writer.WriteAttributeString("engg_sys_psec_titalign", System.Convert.ToString(nvcTmp["engg_sys_psec_titalign"]));
                            this.writer.WriteAttributeString("engg_sys_psec_titreq", System.Convert.ToString(nvcTmp["engg_sys_psec_titreq"]));
                            this.writer.WriteAttributeString("engg_sys_psec_visible", System.Convert.ToString(nvcTmp["engg_sys_psec_visible"]));
                            this.writer.WriteAttributeString("engg_sys_psec_vorder", System.Convert.ToString(nvcTmp["engg_sys_psec_vorder"]));
                            this.writer.WriteAttributeString("engg_sys_psec_wid", System.Convert.ToString(nvcTmp["engg_sys_psec_wid"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggc_mlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGHDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engghdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engghdmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGHDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGHDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGHDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("hdngrid_hidden_1", System.Convert.ToString(nvcTmp["hdngrid_hidden_1"]));
                            this.writer.WriteAttributeString("hdngrid_hidden_2", System.Convert.ToString(nvcTmp["hdngrid_hidden_2"]));
                            this.writer.WriteAttributeString("hdngrid_hidden_3", System.Convert.ToString(nvcTmp["hdngrid_hidden_3"]));
                            this.writer.WriteAttributeString("hdngrid_hidden_4", System.Convert.ToString(nvcTmp["hdngrid_hidden_4"]));
                            this.writer.WriteAttributeString("hdngrid_hidden_5", System.Convert.ToString(nvcTmp["hdngrid_hidden_5"]));
                            this.writer.WriteAttributeString("hdngrid_node_id", System.Convert.ToString(nvcTmp["hdngrid_node_id"]));
                            this.writer.WriteAttributeString("hdngrid_parentnode_id", System.Convert.ToString(nvcTmp["hdngrid_parentnode_id"]));
                            this.writer.WriteAttributeString("hdngrid_root_id", System.Convert.ToString(nvcTmp["hdngrid_root_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engghdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGLIMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engglimlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engglimlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGLIMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGLIMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGLIMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_mob_linked_lls", System.Convert.ToString(nvcTmp["engg_mob_linked_lls"]));
                            this.writer.WriteAttributeString("engg_mob_linked_pls", System.Convert.ToString(nvcTmp["engg_mob_linked_pls"]));
                            this.writer.WriteAttributeString("engg_mob_linked_rls", System.Convert.ToString(nvcTmp["engg_mob_linked_rls"]));
                            this.writer.WriteAttributeString("engg_mob_mapped_lls", System.Convert.ToString(nvcTmp["engg_mob_mapped_lls"]));
                            this.writer.WriteAttributeString("engg_mob_mapped_pls", System.Convert.ToString(nvcTmp["engg_mob_mapped_pls"]));
                            this.writer.WriteAttributeString("engg_mob_mapped_rls", System.Convert.ToString(nvcTmp["engg_mob_mapped_rls"]));
                            this.writer.WriteAttributeString("enggb_engg_mob_link_type", System.Convert.ToString(nvcTmp["enggb_engg_mob_link_type"]));
                            this.writer.WriteAttributeString("enggb_engg_mob_linked_act", System.Convert.ToString(nvcTmp["enggb_engg_mob_linked_act"]));
                            this.writer.WriteAttributeString("enggb_engg_mob_linked_comp", System.Convert.ToString(nvcTmp["enggb_engg_mob_linked_comp"]));
                            this.writer.WriteAttributeString("enggb_engg_mob_linked_ui", System.Convert.ToString(nvcTmp["enggb_engg_mob_linked_ui"]));
                            this.writer.WriteAttributeString("enggb_engg_mob_lnkctrl_btsyn", System.Convert.ToString(nvcTmp["enggb_engg_mob_lnkctrl_btsyn"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engglimlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGLLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggllmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggllmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGLLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGLLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGLLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_mob_lls_descr", System.Convert.ToString(nvcTmp["engg_mob_lls_descr"]));
                            this.writer.WriteAttributeString("engg_mob_lls_horder", System.Convert.ToString(nvcTmp["engg_mob_lls_horder"]));
                            this.writer.WriteAttributeString("engg_mob_lls_img_name", System.Convert.ToString(nvcTmp["engg_mob_lls_img_name"]));
                            this.writer.WriteAttributeString("engg_mob_lls_name", System.Convert.ToString(nvcTmp["engg_mob_lls_name"]));
                            this.writer.WriteAttributeString("engg_mob_lls_titreq", System.Convert.ToString(nvcTmp["engg_mob_lls_titreq"]));
                            this.writer.WriteAttributeString("engg_mob_lls_visible", System.Convert.ToString(nvcTmp["engg_mob_lls_visible"]));
                            this.writer.WriteAttributeString("engg_mob_lls_vorder", System.Convert.ToString(nvcTmp["engg_mob_lls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggllmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGMLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggmlmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggmlmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGMLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGMLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGMLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_tab_lls_descr", System.Convert.ToString(nvcTmp["engg_tab_lls_descr"]));
                            this.writer.WriteAttributeString("engg_tab_lls_horder", System.Convert.ToString(nvcTmp["engg_tab_lls_horder"]));
                            this.writer.WriteAttributeString("engg_tab_lls_img_name", System.Convert.ToString(nvcTmp["engg_tab_lls_img_name"]));
                            this.writer.WriteAttributeString("engg_tab_lls_nam", System.Convert.ToString(nvcTmp["engg_tab_lls_nam"]));
                            this.writer.WriteAttributeString("engg_tab_lls_titreq", System.Convert.ToString(nvcTmp["engg_tab_lls_titreq"]));
                            this.writer.WriteAttributeString("engg_tab_lls_visible", System.Convert.ToString(nvcTmp["engg_tab_lls_visible"]));
                            this.writer.WriteAttributeString("engg_tab_lls_vorder", System.Convert.ToString(nvcTmp["engg_tab_lls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggmlmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGPLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggplmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggplmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGPLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGPLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGPLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_mob_pls_descr", System.Convert.ToString(nvcTmp["engg_mob_pls_descr"]));
                            this.writer.WriteAttributeString("engg_mob_pls_horder", System.Convert.ToString(nvcTmp["engg_mob_pls_horder"]));
                            this.writer.WriteAttributeString("engg_mob_pls_img_name", System.Convert.ToString(nvcTmp["engg_mob_pls_img_name"]));
                            this.writer.WriteAttributeString("engg_mob_pls_name", System.Convert.ToString(nvcTmp["engg_mob_pls_name"]));
                            this.writer.WriteAttributeString("engg_mob_pls_titreq", System.Convert.ToString(nvcTmp["engg_mob_pls_titreq"]));
                            this.writer.WriteAttributeString("engg_mob_pls_visible", System.Convert.ToString(nvcTmp["engg_mob_pls_visible"]));
                            this.writer.WriteAttributeString("engg_mob_pls_vorder", System.Convert.ToString(nvcTmp["engg_mob_pls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggplmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGRLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggrlmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggrlmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGRLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGRLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGRLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_mob_rls_descr", System.Convert.ToString(nvcTmp["engg_mob_rls_descr"]));
                            this.writer.WriteAttributeString("engg_mob_rls_horder", System.Convert.ToString(nvcTmp["engg_mob_rls_horder"]));
                            this.writer.WriteAttributeString("engg_mob_rls_img_name", System.Convert.ToString(nvcTmp["engg_mob_rls_img_name"]));
                            this.writer.WriteAttributeString("engg_mob_rls_name", System.Convert.ToString(nvcTmp["engg_mob_rls_name"]));
                            this.writer.WriteAttributeString("engg_mob_rls_titreq", System.Convert.ToString(nvcTmp["engg_mob_rls_titreq"]));
                            this.writer.WriteAttributeString("engg_mob_rls_visible", System.Convert.ToString(nvcTmp["engg_mob_rls_visible"]));
                            this.writer.WriteAttributeString("engg_mob_rls_vorder", System.Convert.ToString(nvcTmp["engg_mob_rls_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggrlmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGSYMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggsymlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggsymlout");
                    this.writer.WriteAttributeString("RecordCount", htENGGSYMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGGSYMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGSYMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_sys_ctmap_chkbx", System.Convert.ToString(nvcTmp["engg_sys_ctmap_chkbx"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_btsyn", System.Convert.ToString(nvcTmp["engg_sys_ctrl_btsyn"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_caption", System.Convert.ToString(nvcTmp["engg_sys_ctrl_caption"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_ccls", System.Convert.ToString(nvcTmp["engg_sys_ctrl_ccls"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_cimgcls", System.Convert.ToString(nvcTmp["engg_sys_ctrl_cimgcls"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_doc", System.Convert.ToString(nvcTmp["engg_sys_ctrl_doc"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_dwid", System.Convert.ToString(nvcTmp["engg_sys_ctrl_dwid"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_horder", System.Convert.ToString(nvcTmp["engg_sys_ctrl_horder"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_lcls", System.Convert.ToString(nvcTmp["engg_sys_ctrl_lcls"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_limgcls", System.Convert.ToString(nvcTmp["engg_sys_ctrl_limgcls"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_lwid", System.Convert.ToString(nvcTmp["engg_sys_ctrl_lwid"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_ordseq", System.Convert.ToString(nvcTmp["engg_sys_ctrl_ordseq"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_pref", System.Convert.ToString(nvcTmp["engg_sys_ctrl_pref"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_sdata", System.Convert.ToString(nvcTmp["engg_sys_ctrl_sdata"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_tip", System.Convert.ToString(nvcTmp["engg_sys_ctrl_tip"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_tseq", System.Convert.ToString(nvcTmp["engg_sys_ctrl_tseq"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_tstop", System.Convert.ToString(nvcTmp["engg_sys_ctrl_tstop"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_type", System.Convert.ToString(nvcTmp["engg_sys_ctrl_type"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_vislen", System.Convert.ToString(nvcTmp["engg_sys_ctrl_vislen"]));
                            this.writer.WriteAttributeString("engg_sys_ctrl_vorder", System.Convert.ToString(nvcTmp["engg_sys_ctrl_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggsymlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGLINMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("englinmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("englinmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGLINMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGLINMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGLINMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_tab_link_type", System.Convert.ToString(nvcTmp["engg_tab_link_type"]));
                            this.writer.WriteAttributeString("engg_tab_linked_act", System.Convert.ToString(nvcTmp["engg_tab_linked_act"]));
                            this.writer.WriteAttributeString("engg_tab_linked_comp", System.Convert.ToString(nvcTmp["engg_tab_linked_comp"]));
                            this.writer.WriteAttributeString("engg_tab_linked_lls", System.Convert.ToString(nvcTmp["engg_tab_linked_lls"]));
                            this.writer.WriteAttributeString("engg_tab_linked_pls", System.Convert.ToString(nvcTmp["engg_tab_linked_pls"]));
                            this.writer.WriteAttributeString("engg_tab_linked_rls", System.Convert.ToString(nvcTmp["engg_tab_linked_rls"]));
                            this.writer.WriteAttributeString("engg_tab_linked_ui", System.Convert.ToString(nvcTmp["engg_tab_linked_ui"]));
                            this.writer.WriteAttributeString("engg_tab_lnkctrl_btsyn", System.Convert.ToString(nvcTmp["engg_tab_lnkctrl_btsyn"]));
                            this.writer.WriteAttributeString("engg_tab_mapped_lls", System.Convert.ToString(nvcTmp["engg_tab_mapped_lls"]));
                            this.writer.WriteAttributeString("engg_tab_mapped_pls", System.Convert.ToString(nvcTmp["engg_tab_mapped_pls"]));
                            this.writer.WriteAttributeString("engg_tab_mapped_rls", System.Convert.ToString(nvcTmp["engg_tab_mapped_rls"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("englinmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGPAGMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engpagmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engpagmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGPAGMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGPAGMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGPAGMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_sys_page_descr", System.Convert.ToString(nvcTmp["engg_sys_page_descr"]));
                            this.writer.WriteAttributeString("engg_sys_page_doc", System.Convert.ToString(nvcTmp["engg_sys_page_doc"]));
                            this.writer.WriteAttributeString("engg_sys_page_horder", System.Convert.ToString(nvcTmp["engg_sys_page_horder"]));
                            this.writer.WriteAttributeString("engg_sys_page_name", System.Convert.ToString(nvcTmp["engg_sys_page_name"]));
                            this.writer.WriteAttributeString("engg_sys_page_type", System.Convert.ToString(nvcTmp["engg_sys_page_type"]));
                            this.writer.WriteAttributeString("engg_sys_page_vorder", System.Convert.ToString(nvcTmp["engg_sys_page_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engpagmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGS_LMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engs_lmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engs_lmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGS_LMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGS_LMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGS_LMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("enggsy_engg_mob_link_type", System.Convert.ToString(nvcTmp["enggsy_engg_mob_link_type"]));
                            this.writer.WriteAttributeString("enggsy_engg_mob_linked_act", System.Convert.ToString(nvcTmp["enggsy_engg_mob_linked_act"]));
                            this.writer.WriteAttributeString("enggsy_engg_mob_linked_comp", System.Convert.ToString(nvcTmp["enggsy_engg_mob_linked_comp"]));
                            this.writer.WriteAttributeString("enggsy_engg_mob_linked_ui", System.Convert.ToString(nvcTmp["enggsy_engg_mob_linked_ui"]));
                            this.writer.WriteAttributeString("enggsy_engg_mob_lnkctrl_btsyn", System.Convert.ToString(nvcTmp["enggsy_engg_mob_lnkctrl_btsyn"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engs_lmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGSECMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engsecmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engsecmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGSECMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGSECMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGSECMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_sys_sec_capalg", System.Convert.ToString(nvcTmp["engg_sys_sec_capalg"]));
                            this.writer.WriteAttributeString("engg_sys_sec_capfor", System.Convert.ToString(nvcTmp["engg_sys_sec_capfor"]));
                            this.writer.WriteAttributeString("engg_sys_sec_descr", System.Convert.ToString(nvcTmp["engg_sys_sec_descr"]));
                            this.writer.WriteAttributeString("engg_sys_sec_doc", System.Convert.ToString(nvcTmp["engg_sys_sec_doc"]));
                            this.writer.WriteAttributeString("engg_sys_sec_hig", System.Convert.ToString(nvcTmp["engg_sys_sec_hig"]));
                            this.writer.WriteAttributeString("engg_sys_sec_horder", System.Convert.ToString(nvcTmp["engg_sys_sec_horder"]));
                            this.writer.WriteAttributeString("engg_sys_sec_name", System.Convert.ToString(nvcTmp["engg_sys_sec_name"]));
                            this.writer.WriteAttributeString("engg_sys_sec_prefix", System.Convert.ToString(nvcTmp["engg_sys_sec_prefix"]));
                            this.writer.WriteAttributeString("engg_sys_sec_titalign", System.Convert.ToString(nvcTmp["engg_sys_sec_titalign"]));
                            this.writer.WriteAttributeString("engg_sys_sec_titreq", System.Convert.ToString(nvcTmp["engg_sys_sec_titreq"]));
                            this.writer.WriteAttributeString("engg_sys_sec_type", System.Convert.ToString(nvcTmp["engg_sys_sec_type"]));
                            this.writer.WriteAttributeString("engg_sys_sec_visible", System.Convert.ToString(nvcTmp["engg_sys_sec_visible"]));
                            this.writer.WriteAttributeString("engg_sys_sec_vorder", System.Convert.ToString(nvcTmp["engg_sys_sec_vorder"]));
                            this.writer.WriteAttributeString("engg_sys_sec_wid", System.Convert.ToString(nvcTmp["engg_sys_sec_wid"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engsecmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htEP_CONMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ep_conmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ep_conmlout");
                    this.writer.WriteAttributeString("RecordCount", htEP_CONMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htEP_CONMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htEP_CONMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_cont_btsyncap", System.Convert.ToString(nvcTmp["engg_cont_btsyncap"]));
                            this.writer.WriteAttributeString("engg_cont_btsynname", System.Convert.ToString(nvcTmp["engg_cont_btsynname"]));
                            this.writer.WriteAttributeString("engg_cont_conttype", System.Convert.ToString(nvcTmp["engg_cont_conttype"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ep_conmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvcPLF_STATE_SEGMENT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("plf_state_segment", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("plf_state_segment");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("hdnrt_stcontrol", System.Convert.ToString(nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("plf_state_segment", nvcPLF_STATE_SEGMENT);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htTREE_CONFIG_SEGMENT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tree_config_segment", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tree_config_segment");
                    this.writer.WriteAttributeString("RecordCount", htTREE_CONFIG_SEGMENT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htTREE_CONFIG_SEGMENT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTREE_CONFIG_SEGMENT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("plf_attribute_name", System.Convert.ToString(nvcTmp["plf_attribute_name"]));
                            this.writer.WriteAttributeString("plf_attribute_value", System.Convert.ToString(nvcTmp["plf_attribute_value"]));
                            this.writer.WriteAttributeString("plf_node_type", System.Convert.ToString(nvcTmp["plf_node_type"]));
                            this.writer.WriteAttributeString("plf_tree_id", System.Convert.ToString(nvcTmp["plf_tree_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tree_config_segment", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htTREE_DATA_SEGMENT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tree_data_segment", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tree_data_segment");
                    this.writer.WriteAttributeString("RecordCount", htTREE_DATA_SEGMENT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htTREE_DATA_SEGMENT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTREE_DATA_SEGMENT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("plf_node_desc", System.Convert.ToString(nvcTmp["plf_node_desc"]));
                            this.writer.WriteAttributeString("plf_node_id", System.Convert.ToString(nvcTmp["plf_node_id"]));
                            this.writer.WriteAttributeString("plf_node_type", System.Convert.ToString(nvcTmp["plf_node_type"]));
                            this.writer.WriteAttributeString("plf_parentnode_id", System.Convert.ToString(nvcTmp["plf_parentnode_id"]));
                            this.writer.WriteAttributeString("plf_tree_id", System.Convert.ToString(nvcTmp["plf_tree_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tree_data_segment", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_action_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gen_task_uage":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_hdr_ctrl_btscap":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_hdr_ctrl_btsyn":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_mob_task_uage":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_pls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_psec_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_lls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_pls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_rls_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_task_uage":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_uage":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdncustomer":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnproject":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "prj_hdn_ctrl":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treenodetask":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treenodetaskgeneral":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treenodetasktablet":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "tvwengg_mobile_treenodeid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "tvwengg_system_treenodeid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "tvwengg_tablet_treenodeid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "xmlgeneditctrlgeneral":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "xmlgeneditctrlmob":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "xmlgeneditctrltab":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "plf_state_segment":
                        switch (DataItem)
                        {
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_engglt":
                    type = 1;
                    break;
                case "listedit_enggol":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "eng_plmlout":
                    type = 1;
                    break;
                case "engb_rmlout":
                    type = 1;
                    break;
                case "engg_bmlout":
                    type = 1;
                    break;
                case "engg_dmlout":
                    type = 1;
                    break;
                case "engg_emlout":
                    type = 1;
                    break;
                case "engg_gmlout":
                    type = 1;
                    break;
                case "enggabmlout":
                    type = 1;
                    break;
                case "enggc_mlout":
                    type = 1;
                    break;
                case "engghdmlout":
                    type = 1;
                    break;
                case "engglimlout":
                    type = 1;
                    break;
                case "enggllmlout":
                    type = 1;
                    break;
                case "enggmlmlout":
                    type = 1;
                    break;
                case "enggplmlout":
                    type = 1;
                    break;
                case "enggrlmlout":
                    type = 1;
                    break;
                case "enggsymlout":
                    type = 1;
                    break;
                case "englinmlout":
                    type = 1;
                    break;
                case "engpagmlout":
                    type = 1;
                    break;
                case "engs_lmlout":
                    type = 1;
                    break;
                case "engsecmlout":
                    type = 1;
                    break;
                case "ep_conmlout":
                    type = 1;
                    break;
                case "plf_state_segment":
                    type = 0;
                    break;
                case "tree_config_segment":
                    type = 1;
                    break;
                case "tree_data_segment":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_engglt":
                    return htLISTEDIT_ENGGLT.Count;
                    break;
                case "listedit_enggol":
                    return htLISTEDIT_ENGGOL.Count;
                    break;
                case "eng_plmlout":
                    return htENG_PLMLOUT.Count;
                    break;
                case "engb_rmlout":
                    return htENGB_RMLOUT.Count;
                    break;
                case "engg_bmlout":
                    return htENGG_BMLOUT.Count;
                    break;
                case "engg_dmlout":
                    return htENGG_DMLOUT.Count;
                    break;
                case "engg_emlout":
                    return htENGG_EMLOUT.Count;
                    break;
                case "engg_gmlout":
                    return htENGG_GMLOUT.Count;
                    break;
                case "enggabmlout":
                    return htENGGABMLOUT.Count;
                    break;
                case "enggc_mlout":
                    return htENGGC_MLOUT.Count;
                    break;
                case "engghdmlout":
                    return htENGGHDMLOUT.Count;
                    break;
                case "engglimlout":
                    return htENGGLIMLOUT.Count;
                    break;
                case "enggllmlout":
                    return htENGGLLMLOUT.Count;
                    break;
                case "enggmlmlout":
                    return htENGGMLMLOUT.Count;
                    break;
                case "enggplmlout":
                    return htENGGPLMLOUT.Count;
                    break;
                case "enggrlmlout":
                    return htENGGRLMLOUT.Count;
                    break;
                case "enggsymlout":
                    return htENGGSYMLOUT.Count;
                    break;
                case "englinmlout":
                    return htENGLINMLOUT.Count;
                    break;
                case "engpagmlout":
                    return htENGPAGMLOUT.Count;
                    break;
                case "engs_lmlout":
                    return htENGS_LMLOUT.Count;
                    break;
                case "engsecmlout":
                    return htENGSECMLOUT.Count;
                    break;
                case "ep_conmlout":
                    return htEP_CONMLOUT.Count;
                    break;
                case "tree_config_segment":
                    return htTREE_CONFIG_SEGMENT.Count;
                    break;
                case "tree_data_segment":
                    return htTREE_DATA_SEGMENT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_engglt":
                    return this.htLISTEDIT_ENGGLT;
                case "listedit_enggol":
                    return this.htLISTEDIT_ENGGOL;
                case "eng_plmlout":
                    return this.htENG_PLMLOUT;
                case "engb_rmlout":
                    return this.htENGB_RMLOUT;
                case "engg_bmlout":
                    return this.htENGG_BMLOUT;
                case "engg_dmlout":
                    return this.htENGG_DMLOUT;
                case "engg_emlout":
                    return this.htENGG_EMLOUT;
                case "engg_gmlout":
                    return this.htENGG_GMLOUT;
                case "enggabmlout":
                    return this.htENGGABMLOUT;
                case "enggc_mlout":
                    return this.htENGGC_MLOUT;
                case "engghdmlout":
                    return this.htENGGHDMLOUT;
                case "engglimlout":
                    return this.htENGGLIMLOUT;
                case "enggllmlout":
                    return this.htENGGLLMLOUT;
                case "enggmlmlout":
                    return this.htENGGMLMLOUT;
                case "enggplmlout":
                    return this.htENGGPLMLOUT;
                case "enggrlmlout":
                    return this.htENGGRLMLOUT;
                case "enggsymlout":
                    return this.htENGGSYMLOUT;
                case "englinmlout":
                    return this.htENGLINMLOUT;
                case "engpagmlout":
                    return this.htENGPAGMLOUT;
                case "engs_lmlout":
                    return this.htENGS_LMLOUT;
                case "engsecmlout":
                    return this.htENGSECMLOUT;
                case "ep_conmlout":
                    return this.htEP_CONMLOUT;
                case "tree_config_segment":
                    return this.htTREE_CONFIG_SEGMENT;
                case "tree_data_segment":
                    return this.htTREE_DATA_SEGMENT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                case "plf_state_segment":
                    return this.nvcPLF_STATE_SEGMENT;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "listedit_engglt":
                        System.Collections.Specialized.NameValueCollection nvcTmplistedit_engglt = (NameValueCollection)htLISTEDIT_ENGGLT[lnInstNumber];
                        return nvcTmplistedit_engglt[szDataItem];
                        break;
                    case "listedit_enggol":
                        System.Collections.Specialized.NameValueCollection nvcTmplistedit_enggol = (NameValueCollection)htLISTEDIT_ENGGOL[lnInstNumber];
                        return nvcTmplistedit_enggol[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "eng_plmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpeng_plmlout = (NameValueCollection)htENG_PLMLOUT[lnInstNumber];
                        return nvcTmpeng_plmlout[szDataItem];
                        break;
                    case "engb_rmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengb_rmlout = (NameValueCollection)htENGB_RMLOUT[lnInstNumber];
                        return nvcTmpengb_rmlout[szDataItem];
                        break;
                    case "engg_bmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_bmlout = (NameValueCollection)htENGG_BMLOUT[lnInstNumber];
                        return nvcTmpengg_bmlout[szDataItem];
                        break;
                    case "engg_dmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_dmlout = (NameValueCollection)htENGG_DMLOUT[lnInstNumber];
                        return nvcTmpengg_dmlout[szDataItem];
                        break;
                    case "engg_emlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_emlout = (NameValueCollection)htENGG_EMLOUT[lnInstNumber];
                        return nvcTmpengg_emlout[szDataItem];
                        break;
                    case "engg_gmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_gmlout = (NameValueCollection)htENGG_GMLOUT[lnInstNumber];
                        return nvcTmpengg_gmlout[szDataItem];
                        break;
                    case "enggabmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggabmlout = (NameValueCollection)htENGGABMLOUT[lnInstNumber];
                        return nvcTmpenggabmlout[szDataItem];
                        break;
                    case "enggc_mlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggc_mlout = (NameValueCollection)htENGGC_MLOUT[lnInstNumber];
                        return nvcTmpenggc_mlout[szDataItem];
                        break;
                    case "engghdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengghdmlout = (NameValueCollection)htENGGHDMLOUT[lnInstNumber];
                        return nvcTmpengghdmlout[szDataItem];
                        break;
                    case "engglimlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengglimlout = (NameValueCollection)htENGGLIMLOUT[lnInstNumber];
                        return nvcTmpengglimlout[szDataItem];
                        break;
                    case "enggllmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggllmlout = (NameValueCollection)htENGGLLMLOUT[lnInstNumber];
                        return nvcTmpenggllmlout[szDataItem];
                        break;
                    case "enggmlmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggmlmlout = (NameValueCollection)htENGGMLMLOUT[lnInstNumber];
                        return nvcTmpenggmlmlout[szDataItem];
                        break;
                    case "enggplmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggplmlout = (NameValueCollection)htENGGPLMLOUT[lnInstNumber];
                        return nvcTmpenggplmlout[szDataItem];
                        break;
                    case "enggrlmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggrlmlout = (NameValueCollection)htENGGRLMLOUT[lnInstNumber];
                        return nvcTmpenggrlmlout[szDataItem];
                        break;
                    case "enggsymlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggsymlout = (NameValueCollection)htENGGSYMLOUT[lnInstNumber];
                        return nvcTmpenggsymlout[szDataItem];
                        break;
                    case "englinmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpenglinmlout = (NameValueCollection)htENGLINMLOUT[lnInstNumber];
                        return nvcTmpenglinmlout[szDataItem];
                        break;
                    case "engpagmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengpagmlout = (NameValueCollection)htENGPAGMLOUT[lnInstNumber];
                        return nvcTmpengpagmlout[szDataItem];
                        break;
                    case "engs_lmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengs_lmlout = (NameValueCollection)htENGS_LMLOUT[lnInstNumber];
                        return nvcTmpengs_lmlout[szDataItem];
                        break;
                    case "engsecmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengsecmlout = (NameValueCollection)htENGSECMLOUT[lnInstNumber];
                        return nvcTmpengsecmlout[szDataItem];
                        break;
                    case "ep_conmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpep_conmlout = (NameValueCollection)htEP_CONMLOUT[lnInstNumber];
                        return nvcTmpep_conmlout[szDataItem];
                        break;
                    case "plf_state_segment":
                        return nvcPLF_STATE_SEGMENT[szDataItem];
                        break;
                    case "tree_config_segment":
                        System.Collections.Specialized.NameValueCollection nvcTmptree_config_segment = (NameValueCollection)htTREE_CONFIG_SEGMENT[lnInstNumber];
                        return nvcTmptree_config_segment[szDataItem];
                        break;
                    case "tree_data_segment":
                        System.Collections.Specialized.NameValueCollection nvcTmptree_data_segment = (NameValueCollection)htTREE_DATA_SEGMENT[lnInstNumber];
                        return nvcTmptree_data_segment[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_main29srfet Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_main29srfet Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfethdrfet", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfethdrfet", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106396, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106396, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_act_descr");
                                nvc_HSEG["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_action_type");
                                nvc_HSEG["engg_action_type"] = sValue;
                                sValue = this.GetValue("engg_component");
                                nvc_HSEG["engg_component"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HSEG["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_gen_task_uage");
                                nvc_HSEG["engg_gen_task_uage"] = sValue;
                                sValue = this.GetValue("engg_hdr_ctrl_btscap");
                                nvc_HSEG["engg_hdr_ctrl_btscap"] = sValue;
                                sValue = this.GetValue("engg_hdr_ctrl_btsyn");
                                nvc_HSEG["engg_hdr_ctrl_btsyn"] = sValue;
                                sValue = this.GetValue("engg_lls_name");
                                nvc_HSEG["engg_lls_name"] = sValue;
                                sValue = this.GetValue("engg_mob_task_uage");
                                nvc_HSEG["engg_mob_task_uage"] = sValue;
                                sValue = this.GetValue("engg_page_name");
                                nvc_HSEG["engg_page_name"] = sValue;
                                sValue = this.GetValue("engg_pls_name");
                                nvc_HSEG["engg_pls_name"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HSEG["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HSEG["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_psec_name");
                                nvc_HSEG["engg_psec_name"] = sValue;
                                sValue = this.GetValue("engg_req_no");
                                nvc_HSEG["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_rls_name");
                                nvc_HSEG["engg_rls_name"] = sValue;
                                sValue = this.GetValue("engg_sec_name");
                                nvc_HSEG["engg_sec_name"] = sValue;
                                sValue = this.GetValue("engg_tab_lls_name");
                                nvc_HSEG["engg_tab_lls_name"] = sValue;
                                sValue = this.GetValue("engg_tab_pls_name");
                                nvc_HSEG["engg_tab_pls_name"] = sValue;
                                sValue = this.GetValue("engg_tab_rls_name");
                                nvc_HSEG["engg_tab_rls_name"] = sValue;
                                sValue = this.GetValue("engg_tab_task_uage");
                                nvc_HSEG["engg_tab_task_uage"] = sValue;
                                sValue = this.GetValue("engg_task_uage");
                                nvc_HSEG["engg_task_uage"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HSEG["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("hdncustomer");
                                nvc_HSEG["hdncustomer"] = sValue;
                                sValue = this.GetValue("hdnproject");
                                nvc_HSEG["hdnproject"] = sValue;
                                sValue = this.GetValue("prj_hdn_ctrl");
                                nvc_HSEG["prj_hdn_ctrl"] = sValue;
                                sValue = this.GetValue("treenodetask");
                                nvc_HSEG["treenodetask"] = sValue;
                                sValue = this.GetValue("treenodetaskgeneral");
                                nvc_HSEG["treenodetaskgeneral"] = sValue;
                                sValue = this.GetValue("treenodetasktablet");
                                nvc_HSEG["treenodetasktablet"] = sValue;
                                sValue = this.GetValue("tvwengg_mobile_treenodeid");
                                nvc_HSEG["tvwengg_mobile_treenodeid"] = sValue;
                                sValue = this.GetValue("tvwengg_system_treenodeid");
                                nvc_HSEG["tvwengg_system_treenodeid"] = sValue;
                                sValue = this.GetValue("tvwengg_tablet_treenodeid");
                                nvc_HSEG["tvwengg_tablet_treenodeid"] = sValue;
                                sValue = this.GetValue("xmlgeneditctrlgeneral");
                                nvc_HSEG["xmlgeneditctrlgeneral"] = sValue;
                                sValue = this.GetValue("xmlgeneditctrlmob");
                                nvc_HSEG["xmlgeneditctrlmob"] = sValue;
                                sValue = this.GetValue("xmlgeneditctrltab");
                                nvc_HSEG["xmlgeneditctrltab"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106396, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 2  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengg_e", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengg_e", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106397, 1, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106397, 1, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_EMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_caption");
                                    nvcTmp["engg_enum_caption"] = sValue;
                                    sValue = this.GetValue("engg_enum_code");
                                    nvcTmp["engg_enum_code"] = sValue;
                                    sValue = this.GetValue("engg_enum_default");
                                    nvcTmp["engg_enum_default"] = sValue;
                                    sValue = this.GetValue("engg_enum_seqno");
                                    nvcTmp["engg_enum_seqno"] = sValue;
                                    htENGG_EMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106397, 1, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 3  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengg_g", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengg_g", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106398, 1, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106398, 1, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_GMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_colcap");
                                    nvcTmp["engg_grid_colcap"] = sValue;
                                    sValue = this.GetValue("engg_grid_coliskey");
                                    nvcTmp["engg_grid_coliskey"] = sValue;
                                    sValue = this.GetValue("engg_grid_coliskeyno");
                                    nvcTmp["engg_grid_coliskeyno"] = sValue;
                                    sValue = this.GetValue("engg_grid_colname");
                                    nvcTmp["engg_grid_colname"] = sValue;
                                    sValue = this.GetValue("engg_grid_colno");
                                    nvcTmp["engg_grid_colno"] = sValue;
                                    sValue = this.GetValue("engg_grid_coltype");
                                    nvcTmp["engg_grid_coltype"] = sValue;
                                    htENGG_GMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106398, 1, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 4  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengghd", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengghd", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106399, 1, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106399, 1, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGHDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("hdngrid_hidden_1");
                                    nvcTmp["hdngrid_hidden_1"] = sValue;
                                    sValue = this.GetValue("hdngrid_hidden_2");
                                    nvcTmp["hdngrid_hidden_2"] = sValue;
                                    sValue = this.GetValue("hdngrid_hidden_3");
                                    nvcTmp["hdngrid_hidden_3"] = sValue;
                                    sValue = this.GetValue("hdngrid_hidden_4");
                                    nvcTmp["hdngrid_hidden_4"] = sValue;
                                    sValue = this.GetValue("hdngrid_hidden_5");
                                    nvcTmp["hdngrid_hidden_5"] = sValue;
                                    sValue = this.GetValue("hdngrid_node_id");
                                    nvcTmp["hdngrid_node_id"] = sValue;
                                    sValue = this.GetValue("hdngrid_parentnode_id");
                                    nvcTmp["hdngrid_parentnode_id"] = sValue;
                                    sValue = this.GetValue("hdngrid_root_id");
                                    nvcTmp["hdngrid_root_id"] = sValue;
                                    htENGGHDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106399, 1, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 5  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggll", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggll", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106400, 1, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106400, 1, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGLLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_mob_lls_descr");
                                    nvcTmp["engg_mob_lls_descr"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_horder");
                                    nvcTmp["engg_mob_lls_horder"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_img_name");
                                    nvcTmp["engg_mob_lls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_name");
                                    nvcTmp["engg_mob_lls_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_titreq");
                                    nvcTmp["engg_mob_lls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_visible");
                                    nvcTmp["engg_mob_lls_visible"] = sValue;
                                    sValue = this.GetValue("engg_mob_lls_vorder");
                                    nvcTmp["engg_mob_lls_vorder"] = sValue;
                                    htENGGLLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106400, 1, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 6  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengg_b", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengg_b", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106401, 1, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106401, 1, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_BMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_mob_ctrl_btsyn");
                                    nvcTmp["engg_mob_ctrl_btsyn"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_caption");
                                    nvcTmp["engg_mob_ctrl_caption"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_horder");
                                    nvcTmp["engg_mob_ctrl_horder"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_image_name");
                                    nvcTmp["engg_mob_ctrl_image_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_ordseq");
                                    nvcTmp["engg_mob_ctrl_ordseq"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_type");
                                    nvcTmp["engg_mob_ctrl_type"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_vislen");
                                    nvcTmp["engg_mob_ctrl_vislen"] = sValue;
                                    sValue = this.GetValue("engg_mob_ctrl_vorder");
                                    nvcTmp["engg_mob_ctrl_vorder"] = sValue;
                                    htENGG_BMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106401, 1, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 7  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggli", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggli", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106402, 1, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106402, 1, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGLIMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_mob_linked_lls");
                                    nvcTmp["engg_mob_linked_lls"] = sValue;
                                    sValue = this.GetValue("engg_mob_linked_pls");
                                    nvcTmp["engg_mob_linked_pls"] = sValue;
                                    sValue = this.GetValue("engg_mob_linked_rls");
                                    nvcTmp["engg_mob_linked_rls"] = sValue;
                                    sValue = this.GetValue("engg_mob_mapped_lls");
                                    nvcTmp["engg_mob_mapped_lls"] = sValue;
                                    sValue = this.GetValue("engg_mob_mapped_pls");
                                    nvcTmp["engg_mob_mapped_pls"] = sValue;
                                    sValue = this.GetValue("engg_mob_mapped_rls");
                                    nvcTmp["engg_mob_mapped_rls"] = sValue;
                                    sValue = this.GetValue("enggb_engg_mob_link_type");
                                    nvcTmp["enggb_engg_mob_link_type"] = sValue;
                                    sValue = this.GetValue("enggb_engg_mob_linked_act");
                                    nvcTmp["enggb_engg_mob_linked_act"] = sValue;
                                    sValue = this.GetValue("enggb_engg_mob_linked_comp");
                                    nvcTmp["enggb_engg_mob_linked_comp"] = sValue;
                                    sValue = this.GetValue("enggb_engg_mob_linked_ui");
                                    nvcTmp["enggb_engg_mob_linked_ui"] = sValue;
                                    sValue = this.GetValue("enggb_engg_mob_lnkctrl_btsyn");
                                    nvcTmp["enggb_engg_mob_lnkctrl_btsyn"] = sValue;
                                    htENGGLIMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106402, 1, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 8  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenglin", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenglin", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106403, 1, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106403, 1, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGLINMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_tab_link_type");
                                    nvcTmp["engg_tab_link_type"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_act");
                                    nvcTmp["engg_tab_linked_act"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_comp");
                                    nvcTmp["engg_tab_linked_comp"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_lls");
                                    nvcTmp["engg_tab_linked_lls"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_pls");
                                    nvcTmp["engg_tab_linked_pls"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_rls");
                                    nvcTmp["engg_tab_linked_rls"] = sValue;
                                    sValue = this.GetValue("engg_tab_linked_ui");
                                    nvcTmp["engg_tab_linked_ui"] = sValue;
                                    sValue = this.GetValue("engg_tab_lnkctrl_btsyn");
                                    nvcTmp["engg_tab_lnkctrl_btsyn"] = sValue;
                                    sValue = this.GetValue("engg_tab_mapped_lls");
                                    nvcTmp["engg_tab_mapped_lls"] = sValue;
                                    sValue = this.GetValue("engg_tab_mapped_pls");
                                    nvcTmp["engg_tab_mapped_pls"] = sValue;
                                    sValue = this.GetValue("engg_tab_mapped_rls");
                                    nvcTmp["engg_tab_mapped_rls"] = sValue;
                                    htENGLINMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106403, 1, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 9  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengpag", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengpag", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106404, 1, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106404, 1, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGPAGMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sys_page_descr");
                                    nvcTmp["engg_sys_page_descr"] = sValue;
                                    sValue = this.GetValue("engg_sys_page_doc");
                                    nvcTmp["engg_sys_page_doc"] = sValue;
                                    sValue = this.GetValue("engg_sys_page_horder");
                                    nvcTmp["engg_sys_page_horder"] = sValue;
                                    sValue = this.GetValue("engg_sys_page_name");
                                    nvcTmp["engg_sys_page_name"] = sValue;
                                    sValue = this.GetValue("engg_sys_page_type");
                                    nvcTmp["engg_sys_page_type"] = sValue;
                                    sValue = this.GetValue("engg_sys_page_vorder");
                                    nvcTmp["engg_sys_page_vorder"] = sValue;
                                    htENGPAGMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106404, 1, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 10  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggpl", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggpl", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106405, 1, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106405, 1, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGPLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_mob_pls_descr");
                                    nvcTmp["engg_mob_pls_descr"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_horder");
                                    nvcTmp["engg_mob_pls_horder"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_img_name");
                                    nvcTmp["engg_mob_pls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_name");
                                    nvcTmp["engg_mob_pls_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_titreq");
                                    nvcTmp["engg_mob_pls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_visible");
                                    nvcTmp["engg_mob_pls_visible"] = sValue;
                                    sValue = this.GetValue("engg_mob_pls_vorder");
                                    nvcTmp["engg_mob_pls_vorder"] = sValue;
                                    htENGGPLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106405, 1, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 11  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggc_", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggc_", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106406, 1, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106406, 1, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGC_MLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sys_psec_capalg");
                                    nvcTmp["engg_sys_psec_capalg"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_capfor");
                                    nvcTmp["engg_sys_psec_capfor"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_descr");
                                    nvcTmp["engg_sys_psec_descr"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_doc");
                                    nvcTmp["engg_sys_psec_doc"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_hig");
                                    nvcTmp["engg_sys_psec_hig"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_horder");
                                    nvcTmp["engg_sys_psec_horder"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_name");
                                    nvcTmp["engg_sys_psec_name"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_prefix");
                                    nvcTmp["engg_sys_psec_prefix"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_titalign");
                                    nvcTmp["engg_sys_psec_titalign"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_titreq");
                                    nvcTmp["engg_sys_psec_titreq"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_visible");
                                    nvcTmp["engg_sys_psec_visible"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_vorder");
                                    nvcTmp["engg_sys_psec_vorder"] = sValue;
                                    sValue = this.GetValue("engg_sys_psec_wid");
                                    nvcTmp["engg_sys_psec_wid"] = sValue;
                                    htENGGC_MLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106406, 1, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 12  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengg_d", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengg_d", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106407, 1, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106407, 1, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_DMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_caption");
                                    nvcTmp["engg_radio_caption"] = sValue;
                                    sValue = this.GetValue("engg_radio_code");
                                    nvcTmp["engg_radio_code"] = sValue;
                                    sValue = this.GetValue("engg_radio_default");
                                    nvcTmp["engg_radio_default"] = sValue;
                                    sValue = this.GetValue("engg_radio_horder");
                                    nvcTmp["engg_radio_horder"] = sValue;
                                    sValue = this.GetValue("engg_radio_seq");
                                    nvcTmp["engg_radio_seq"] = sValue;
                                    sValue = this.GetValue("engg_radio_vorder");
                                    nvcTmp["engg_radio_vorder"] = sValue;
                                    htENGG_DMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106407, 1, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 13  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggrl", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggrl", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106408, 1, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106408, 1, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGRLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_mob_rls_descr");
                                    nvcTmp["engg_mob_rls_descr"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_horder");
                                    nvcTmp["engg_mob_rls_horder"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_img_name");
                                    nvcTmp["engg_mob_rls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_name");
                                    nvcTmp["engg_mob_rls_name"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_titreq");
                                    nvcTmp["engg_mob_rls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_visible");
                                    nvcTmp["engg_mob_rls_visible"] = sValue;
                                    sValue = this.GetValue("engg_mob_rls_vorder");
                                    nvcTmp["engg_mob_rls_vorder"] = sValue;
                                    htENGGRLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106408, 1, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 14  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 14;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 14 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106409, 1, 14);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106409, 1, 14);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGSECMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sys_sec_capalg");
                                    nvcTmp["engg_sys_sec_capalg"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_capfor");
                                    nvcTmp["engg_sys_sec_capfor"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_descr");
                                    nvcTmp["engg_sys_sec_descr"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_doc");
                                    nvcTmp["engg_sys_sec_doc"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_hig");
                                    nvcTmp["engg_sys_sec_hig"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_horder");
                                    nvcTmp["engg_sys_sec_horder"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_name");
                                    nvcTmp["engg_sys_sec_name"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_prefix");
                                    nvcTmp["engg_sys_sec_prefix"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_titalign");
                                    nvcTmp["engg_sys_sec_titalign"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_titreq");
                                    nvcTmp["engg_sys_sec_titreq"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_type");
                                    nvcTmp["engg_sys_sec_type"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_visible");
                                    nvcTmp["engg_sys_sec_visible"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_vorder");
                                    nvcTmp["engg_sys_sec_vorder"] = sValue;
                                    sValue = this.GetValue("engg_sys_sec_wid");
                                    nvcTmp["engg_sys_sec_wid"] = sValue;
                                    htENGSECMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 14", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106409, 1, 14);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 14 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 15  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 15;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 15 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggsy", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggsy", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106410, 1, 15);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106410, 1, 15);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGSYMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sys_ctmap_chkbx");
                                    nvcTmp["engg_sys_ctmap_chkbx"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_btsyn");
                                    nvcTmp["engg_sys_ctrl_btsyn"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_caption");
                                    nvcTmp["engg_sys_ctrl_caption"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_ccls");
                                    nvcTmp["engg_sys_ctrl_ccls"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_cimgcls");
                                    nvcTmp["engg_sys_ctrl_cimgcls"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_doc");
                                    nvcTmp["engg_sys_ctrl_doc"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_dwid");
                                    nvcTmp["engg_sys_ctrl_dwid"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_horder");
                                    nvcTmp["engg_sys_ctrl_horder"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_lcls");
                                    nvcTmp["engg_sys_ctrl_lcls"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_limgcls");
                                    nvcTmp["engg_sys_ctrl_limgcls"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_lwid");
                                    nvcTmp["engg_sys_ctrl_lwid"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_ordseq");
                                    nvcTmp["engg_sys_ctrl_ordseq"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_pref");
                                    nvcTmp["engg_sys_ctrl_pref"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_sdata");
                                    nvcTmp["engg_sys_ctrl_sdata"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_tip");
                                    nvcTmp["engg_sys_ctrl_tip"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_tseq");
                                    nvcTmp["engg_sys_ctrl_tseq"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_tstop");
                                    nvcTmp["engg_sys_ctrl_tstop"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_type");
                                    nvcTmp["engg_sys_ctrl_type"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_vislen");
                                    nvcTmp["engg_sys_ctrl_vislen"] = sValue;
                                    sValue = this.GetValue("engg_sys_ctrl_vorder");
                                    nvcTmp["engg_sys_ctrl_vorder"] = sValue;
                                    htENGGSYMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 15", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106410, 1, 15);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 15 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 16  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 16;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 16 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengs_l", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengs_l", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106411, 1, 16);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106411, 1, 16);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGS_LMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("enggsy_engg_mob_link_type");
                                    nvcTmp["enggsy_engg_mob_link_type"] = sValue;
                                    sValue = this.GetValue("enggsy_engg_mob_linked_act");
                                    nvcTmp["enggsy_engg_mob_linked_act"] = sValue;
                                    sValue = this.GetValue("enggsy_engg_mob_linked_comp");
                                    nvcTmp["enggsy_engg_mob_linked_comp"] = sValue;
                                    sValue = this.GetValue("enggsy_engg_mob_linked_ui");
                                    nvcTmp["enggsy_engg_mob_linked_ui"] = sValue;
                                    sValue = this.GetValue("enggsy_engg_mob_lnkctrl_btsyn");
                                    nvcTmp["enggsy_engg_mob_lnkctrl_btsyn"] = sValue;
                                    htENGS_LMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 16", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106411, 1, 16);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 16 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 17  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 17;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 17 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggab", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggab", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106412, 1, 17);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106412, 1, 17);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGABMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_tab_ctrl_btsyn");
                                    nvcTmp["engg_tab_ctrl_btsyn"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_caption");
                                    nvcTmp["engg_tab_ctrl_caption"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_horder");
                                    nvcTmp["engg_tab_ctrl_horder"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_image_name");
                                    nvcTmp["engg_tab_ctrl_image_name"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_ordseq");
                                    nvcTmp["engg_tab_ctrl_ordseq"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_type");
                                    nvcTmp["engg_tab_ctrl_type"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_vislen");
                                    nvcTmp["engg_tab_ctrl_vislen"] = sValue;
                                    sValue = this.GetValue("engg_tab_ctrl_vorder");
                                    nvcTmp["engg_tab_ctrl_vorder"] = sValue;
                                    htENGGABMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 17", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106412, 1, 17);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 17 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 18  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 18;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 18 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetenggml", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetenggml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106413, 1, 18);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106413, 1, 18);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGMLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_tab_lls_descr");
                                    nvcTmp["engg_tab_lls_descr"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_horder");
                                    nvcTmp["engg_tab_lls_horder"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_img_name");
                                    nvcTmp["engg_tab_lls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_nam");
                                    nvcTmp["engg_tab_lls_nam"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_titreq");
                                    nvcTmp["engg_tab_lls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_visible");
                                    nvcTmp["engg_tab_lls_visible"] = sValue;
                                    sValue = this.GetValue("engg_tab_lls_vorder");
                                    nvcTmp["engg_tab_lls_vorder"] = sValue;
                                    htENGGMLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 18", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106413, 1, 18);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 18 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 19  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 19;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 19 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfeteng_pl", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfeteng_pl", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106414, 1, 19);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106414, 1, 19);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENG_PLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_tab_pls_descr");
                                    nvcTmp["engg_tab_pls_descr"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_horder");
                                    nvcTmp["engg_tab_pls_horder"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_img_name");
                                    nvcTmp["engg_tab_pls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_nam");
                                    nvcTmp["engg_tab_pls_nam"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_titreq");
                                    nvcTmp["engg_tab_pls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_visible");
                                    nvcTmp["engg_tab_pls_visible"] = sValue;
                                    sValue = this.GetValue("engg_tab_pls_vorder");
                                    nvcTmp["engg_tab_pls_vorder"] = sValue;
                                    htENG_PLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 19", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106414, 1, 19);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 19 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 20  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 20;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 20 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetengb_r", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetengb_r", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106415, 1, 20);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106415, 1, 20);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGB_RMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_tab_rls_descr");
                                    nvcTmp["engg_tab_rls_descr"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_horder");
                                    nvcTmp["engg_tab_rls_horder"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_img_name");
                                    nvcTmp["engg_tab_rls_img_name"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_nam");
                                    nvcTmp["engg_tab_rls_nam"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_titreq");
                                    nvcTmp["engg_tab_rls_titreq"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_visible");
                                    nvcTmp["engg_tab_rls_visible"] = sValue;
                                    sValue = this.GetValue("engg_tab_rls_vorder");
                                    nvcTmp["engg_tab_rls_vorder"] = sValue;
                                    htENGB_RMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 20", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106415, 1, 20);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 20 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 21  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 21;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 21 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfetep_con", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfetep_con", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106416, 1, 21);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106416, 1, 21);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htEP_CONMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_btsyncap");
                                    nvcTmp["engg_cont_btsyncap"] = sValue;
                                    sValue = this.GetValue("engg_cont_btsynname");
                                    nvcTmp["engg_cont_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_cont_conttype");
                                    nvcTmp["engg_cont_conttype"] = sValue;
                                    htEP_CONMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 21", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106416, 1, 21);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 21 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 22  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 22;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 22 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfet_statemto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfet_statespo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106423, 1, 22);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106423, 1, 22);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("hdnrt_stcontrol");
                                nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 22", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106423, 1, 22);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 22 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 23  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 23;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 23 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfet_enggolleo", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfet_enggolleo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106424, 1, 23);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106424, 1, 23);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLISTEDIT_ENGGOL.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("col_descr");
                                    nvcTmp["col_descr"] = sValue;
                                    sValue = this.GetValue("col_type");
                                    nvcTmp["col_type"] = sValue;
                                    htLISTEDIT_ENGGOL[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 23", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106424, 1, 23);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 23 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 24  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 24;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfet");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 24 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfet_enggltleo", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfet_enggltleo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106425, 1, 24);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106425, 1, 24);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLISTEDIT_ENGGLT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ctrl_descr");
                                    nvcTmp["ctrl_descr"] = sValue;
                                    sValue = this.GetValue("ctrl_type");
                                    nvcTmp["ctrl_type"] = sValue;
                                    htLISTEDIT_ENGGLT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 24", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106425, 1, 24);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 24 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettc_tvwengmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettc_tvwengspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106417, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106417, 2, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_CONFIG_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_attribute_name");
                                    nvcTmp["plf_attribute_name"] = sValue;
                                    sValue = this.GetValue("plf_attribute_value");
                                    nvcTmp["plf_attribute_value"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_CONFIG_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106417, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 2  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettd_tvwengmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettd_tvwengspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106418, 2, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106418, 2, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_DATA_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_node_desc");
                                    nvcTmp["plf_node_desc"] = sValue;
                                    sValue = this.GetValue("plf_node_id");
                                    nvcTmp["plf_node_id"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_parentnode_id");
                                    nvcTmp["plf_parentnode_id"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_DATA_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106418, 2, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 3  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettc_tvwen_mto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettc_tvwen_spo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106419, 2, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106419, 2, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_CONFIG_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_attribute_name");
                                    nvcTmp["plf_attribute_name"] = sValue;
                                    sValue = this.GetValue("plf_attribute_value");
                                    nvcTmp["plf_attribute_value"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_CONFIG_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106419, 2, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 4  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettd_tvwen_mto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettd_tvwen_spo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106420, 2, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106420, 2, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_DATA_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_node_desc");
                                    nvcTmp["plf_node_desc"] = sValue;
                                    sValue = this.GetValue("plf_node_id");
                                    nvcTmp["plf_node_id"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_parentnode_id");
                                    nvcTmp["plf_parentnode_id"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_DATA_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106420, 2, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 5  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettc_tvwentmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettc_tvwentspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106421, 2, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106421, 2, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_CONFIG_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_attribute_name");
                                    nvcTmp["plf_attribute_name"] = sValue;
                                    sValue = this.GetValue("plf_attribute_value");
                                    nvcTmp["plf_attribute_value"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_CONFIG_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106421, 2, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 6  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psfetpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_action_type"];
                            base.Parameters("@engg_action_type", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gen_task_uage"];
                            base.Parameters("@engg_gen_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btscap"];
                            base.Parameters("@engg_hdr_ctrl_btscap", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_hdr_ctrl_btsyn"];
                            base.Parameters("@engg_hdr_ctrl_btsyn", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_lls_name"];
                            base.Parameters("@engg_lls_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_mob_task_uage"];
                            base.Parameters("@engg_mob_task_uage", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_pls_name"];
                            base.Parameters("@engg_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_psec_name"];
                            base.Parameters("@engg_psec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_rls_name"];
                            base.Parameters("@engg_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_name"];
                            base.Parameters("@engg_sec_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_tab_lls_name"];
                            base.Parameters("@engg_tab_lls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_pls_name"];
                            base.Parameters("@engg_tab_pls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_rls_name"];
                            base.Parameters("@engg_tab_rls_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_tab_task_uage"];
                            base.Parameters("@engg_tab_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_uage"];
                            base.Parameters("@engg_task_uage", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetask"];
                            base.Parameters("@treenodetask", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["treenodetaskgeneral"];
                            base.Parameters("@treenodetaskgeneral", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treenodetasktablet"];
                            base.Parameters("@treenodetasktablet", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["tvwengg_mobile_treenodeid"];
                            base.Parameters("@tvwengg_mobile_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_system_treenodeid"];
                            base.Parameters("@tvwengg_system_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["tvwengg_tablet_treenodeid"];
                            base.Parameters("@tvwengg_tablet_treenodeid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlgeneral"];
                            base.Parameters("@xmlgeneditctrlgeneral", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrlmob"];
                            base.Parameters("@xmlgeneditctrlmob", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["xmlgeneditctrltab"];
                            base.Parameters("@xmlgeneditctrltab", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_main29mtfettd_tvwentmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_main29spfettd_tvwentspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106422, 2, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106422, 2, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTREE_DATA_SEGMENT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("plf_node_desc");
                                    nvcTmp["plf_node_desc"] = sValue;
                                    sValue = this.GetValue("plf_node_id");
                                    nvcTmp["plf_node_id"] = sValue;
                                    sValue = this.GetValue("plf_node_type");
                                    nvcTmp["plf_node_type"] = sValue;
                                    sValue = this.GetValue("plf_parentnode_id");
                                    nvcTmp["plf_parentnode_id"] = sValue;
                                    sValue = this.GetValue("plf_tree_id");
                                    nvcTmp["plf_tree_id"] = sValue;
                                    htTREE_DATA_SEGMENT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106422, 2, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "listedit_engglt":
                            Localtable = (NameValueCollection)htLISTEDIT_ENGGLT[lInstance];
                            break;
                        case "listedit_enggol":
                            Localtable = (NameValueCollection)htLISTEDIT_ENGGOL[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "eng_plmlout":
                            Localtable = (NameValueCollection)htENG_PLMLOUT[lInstance];
                            break;
                        case "engb_rmlout":
                            Localtable = (NameValueCollection)htENGB_RMLOUT[lInstance];
                            break;
                        case "engg_bmlout":
                            Localtable = (NameValueCollection)htENGG_BMLOUT[lInstance];
                            break;
                        case "engg_dmlout":
                            Localtable = (NameValueCollection)htENGG_DMLOUT[lInstance];
                            break;
                        case "engg_emlout":
                            Localtable = (NameValueCollection)htENGG_EMLOUT[lInstance];
                            break;
                        case "engg_gmlout":
                            Localtable = (NameValueCollection)htENGG_GMLOUT[lInstance];
                            break;
                        case "enggabmlout":
                            Localtable = (NameValueCollection)htENGGABMLOUT[lInstance];
                            break;
                        case "enggc_mlout":
                            Localtable = (NameValueCollection)htENGGC_MLOUT[lInstance];
                            break;
                        case "engghdmlout":
                            Localtable = (NameValueCollection)htENGGHDMLOUT[lInstance];
                            break;
                        case "engglimlout":
                            Localtable = (NameValueCollection)htENGGLIMLOUT[lInstance];
                            break;
                        case "enggllmlout":
                            Localtable = (NameValueCollection)htENGGLLMLOUT[lInstance];
                            break;
                        case "enggmlmlout":
                            Localtable = (NameValueCollection)htENGGMLMLOUT[lInstance];
                            break;
                        case "enggplmlout":
                            Localtable = (NameValueCollection)htENGGPLMLOUT[lInstance];
                            break;
                        case "enggrlmlout":
                            Localtable = (NameValueCollection)htENGGRLMLOUT[lInstance];
                            break;
                        case "enggsymlout":
                            Localtable = (NameValueCollection)htENGGSYMLOUT[lInstance];
                            break;
                        case "englinmlout":
                            Localtable = (NameValueCollection)htENGLINMLOUT[lInstance];
                            break;
                        case "engpagmlout":
                            Localtable = (NameValueCollection)htENGPAGMLOUT[lInstance];
                            break;
                        case "engs_lmlout":
                            Localtable = (NameValueCollection)htENGS_LMLOUT[lInstance];
                            break;
                        case "engsecmlout":
                            Localtable = (NameValueCollection)htENGSECMLOUT[lInstance];
                            break;
                        case "ep_conmlout":
                            Localtable = (NameValueCollection)htEP_CONMLOUT[lInstance];
                            break;
                        case "plf_state_segment":
                            Localtable = nvcPLF_STATE_SEGMENT;
                            break;
                        case "tree_config_segment":
                            Localtable = (NameValueCollection)htTREE_CONFIG_SEGMENT[lInstance];
                            break;
                        case "tree_data_segment":
                            Localtable = (NameValueCollection)htTREE_DATA_SEGMENT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_main29srfet(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_main29srfet(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_main29srfet.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

