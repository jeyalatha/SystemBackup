/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :preview_ltmcr.cs
* Code Generated on         :08/24/2022 17:11:01
* Code Generated From       :ramco/PLF/Prw_ECR_00383/techwarcnv56\inst2/sa/Rvw20AppDB/TECHWARCNV56
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Reflection;
using System.Diagnostics;
[assembly: AssemblyDescription("ramco/PLF/Prw_ECR_00383/techwarcnv56-inst2/sa/Rvw20AppDB/TECHWARCNV56/24-08-2022")]
//transction scope - Dotnet ltm transaction scope - 0 - Required, 1 - Required New, 2 - Supported
// model scope - 0 Supported, 1 - Required
//outZBytes - true - zipped byte[]  , false - string
//tdFormat = 0 - String , 1- JSON , 2-Dataset
namespace com.ramco.vw.preview.service
{
	public class Cpreview_ltmcr
	{
		public const int ATMA_SUCCESS = 0;
		public const int ATMA_FAILURE = 999;
		public const int ATMA_INVALID_SERVICE = 998;


		public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, bool outZBytes, int tdFormat, ref string szOutMtd, ref byte[] byteOutMtd)
		{
			DefaultTraceListener output = new DefaultTraceListener();
			try
			{
				szOutMtd = "";
				byteOutMtd = null;

				Cpreview_ltm cpreview_ltm = new Cpreview_ltm();
				switch (szServiceName.ToLower().Trim())
				{
					case("ep_autoupsract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_autoupsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_autoupsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_autoupsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_autoupsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_autoupsrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_autoupsrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_axsattsrconnec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrconnec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrconnec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrconnec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_axsattsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_axsattsrfetdet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfetdet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfetdet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrfetdet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_axsattsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_axsattsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_axsattsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrpage"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrpage service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrpage service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrpage service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrsect"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsect service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsect service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrsect service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_calendsrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_calendsrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrbkgnd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrbkgnd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrbkgnd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrbkgnd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrdeffor"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrdeffor service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrdeffor service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrdeffor service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrfetdet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfetdet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfetdet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrfetdet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrpgdesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrpgdesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrpgdesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrpgdesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrsampft"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampft service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampft service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampft service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrsampsv"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampsv service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampsv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsampsv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrsecdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsecdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsecdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrsecdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsruides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsruides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrxfetdt"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfetdt service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfetdt service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfetdt service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrxfrmt"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfrmt service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfrmt service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxfrmt service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrxsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrxsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsryfetdt"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryfetdt service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryfetdt service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryfetdt service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsryform"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryform service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryform service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsryform service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_chtdetsrysave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrysave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrysave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_chtdetsrysave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_cusborsrengust"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_cusborsrengust service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_cusborsrengust service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_cusborsrengust service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_detplsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_detplsrgettpl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettpl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettpl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettpl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_detplsrgettplid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettplid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettplid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrgettplid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_detplsrsavtpl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrsavtpl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrsavtpl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_detplsrsavtpl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrcontro"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrcontro service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrcontro service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrcontro service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_g"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_g service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_g service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_g service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_l"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_l service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_l service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_l service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_n"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_n service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_n service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_n service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_s"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_s service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_s service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_s service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsrtype"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrtype service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrtype service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsrtype service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_devsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_devsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_dnld"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_dnld service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_dnld service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_dnld service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_dnld_sr_selreq"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selreq service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selreq service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_dnld_sr_selreq service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_edmasksrcomput"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrcomput service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrcomput service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrcomput service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_edmasksrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_edmasksrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrctrl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrctrl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrctrl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrctrl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrexttyp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrexttyp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrexttyp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrexttyp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrpage"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrpage service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrpage service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrpage service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ep_extsrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ep_extsrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrct_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrct_pgn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_pgn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_pgn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_pgn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrct_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrct_scn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_scn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_scn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrct_scn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrctrlty"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrctrlty service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrctrlty service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrctrlty service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrenggct"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggct service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggct service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggct service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrenggol"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggol service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggol service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggol service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrenggse"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggse service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggse service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrenggse service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrextnjc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnjc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnjc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnjc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrextnje"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnje service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnje service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrextnje service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrfetdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrfetdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrgenprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrgenprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrgenprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrgenprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrpage"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrpage service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrpage service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrpage service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsc_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsc_pgn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_pgn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_pgn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_pgn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsc_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsc_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsecfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsecsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrsecsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrsecsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ext_mnsrvwprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrvwprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrvwprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ext_mnsrvwprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesresp_fe"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_fe service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_fe service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_fe service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesresp_sv"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_sv service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_sv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesresp_sv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrespilb"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrespilb service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrespilb service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrespilb service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrez_act"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrez_act service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrez_act service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrez_act service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrezui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrezui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrezui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrezui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrtrgfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ezeesrtrgsv"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgsv service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgsv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ezeesrtrgsv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_savact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_savact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_savact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_savact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_selpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_selpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_seltsk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_seltsk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_seltsk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_seltsk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_flow_sr_ui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_ui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_ui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_flow_sr_ui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_gdextnsrenggxt"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrenggxt service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrenggxt service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrenggxt service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_gdextnsrsavext"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrsavext service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrsavext service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_gdextnsrsavext service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glosry_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glosry_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glosry_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glosry_sr_search"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_search service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_search service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_search service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glosry_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glosry_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glsfun_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glsfun_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glsfun_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glsfun_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glswr_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glswr_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glswr_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_glswr_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_glswr_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_hlasbtsrep_ass"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrep_ass service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrep_ass service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrep_ass service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_hlasbtsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_hlasbtsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlasbtsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_hlptplsrhlpsrh"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlptplsrhlpsrh service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlptplsrhlpsrh service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_hlptplsrhlpsrh service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgctr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgctr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgctr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgctr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcggcap"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcggcap service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcggcap service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcggcap service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcglang"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcglang service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcglang service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcglang service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgsavg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsavg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsavg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsavg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcgsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcgsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcntdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcntfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcntpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcntsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcntsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcntsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcoldes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcoldes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcoldes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcoldes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcolfe"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolfe service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolfe service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolfe service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcolgdn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolgdn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolgdn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolgdn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcolpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcolsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrcolsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrcolsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrdelgr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrdelgrp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgrp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgrp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdelgrp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrdevtyp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdevtyp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdevtyp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrdevtyp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrenggui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrenggui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrenggui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrenggui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrfordes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfordes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfordes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrfordes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrforfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrforsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrforsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrgrpnam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrgrpnam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrgrpnam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrgrpnam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrpagdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrpagfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrpagsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrpagsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrprew"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrprew service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrprew service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrprew service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrsecdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrsecfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrseclay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrseclay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrseclay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrseclay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrsecpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrsecsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrsecsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_laymngsrvwprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrvwprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrvwprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_laymngsrvwprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defctl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defctl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defctl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defctl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defen"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defen service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defen service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defen service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_deffrm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deffrm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deffrm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deffrm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defgrd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defgrd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defgrd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defgrd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_deflay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_deflnk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflnk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflnk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_deflnk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defrad"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defrad service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defrad service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defrad service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_defsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_defsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_entcsn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entcsn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entcsn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entcsn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_entgsn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entgsn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entgsn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entgsn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_entpsn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entpsn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entpsn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entpsn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_entssn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entssn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entssn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_entssn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetctl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetctl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetctl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetctl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_feten"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_feten service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_feten service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_feten service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetgrd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetgrd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetgrd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetgrd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetlay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetlnk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlnk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlnk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetlnk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetrad"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetrad service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetrad service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetrad service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_fetsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_fetsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_genlnk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_genlnk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_genlnk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_genlnk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_prvw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_prvw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_prvw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_prvw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_sact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savctl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savctl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savctl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savctl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_saven"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_saven service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_saven service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_saven service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savfrm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savfrm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savfrm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savfrm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savgrd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savgrd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savgrd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savgrd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savlay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savlay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savlay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savlay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savln"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savln service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savln service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savln service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_savrd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savrd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savrd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_savrd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selcpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selcsc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcsc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcsc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selcsc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selepg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selepg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selepg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selepg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selesn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selesn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selggd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selggd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selggd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selggd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selgpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selgsc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgsc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgsc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selgsc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_sellay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_sellpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_sellpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selrpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selrsc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selrsn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selrsn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selspg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selspg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selspg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selspg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_seltp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_seltp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_seltp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_seltp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_selui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_selui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_valid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_valid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_valid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_valid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layout_sr_view"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_view service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_view service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layout_sr_view service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrborctl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborctl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborctl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborctl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrborpg"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborpg service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborpg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborpg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrborsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrborsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrborsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcactnm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcactnm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcactnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcactnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcapgnm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcapgnm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcapgnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcapgnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcasave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcasave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcasave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcasave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcascnm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcascnm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcascnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcascnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcstbor"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcstbor service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcstbor service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcstbor service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcusact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrcusbor"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusbor service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusbor service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrcusbor service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrep_spm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrep_spm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrep_spm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrep_spm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrtitact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtitact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtitact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtitact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_layoutsrtmpsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtmpsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtmpsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_layoutsrtmpsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrcolfth"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolfth service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolfth service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolfth service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrcollst"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcollst service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcollst service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcollst service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrcolsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrcolsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdeffth"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdeffth service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdeffth service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdeffth service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdefsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdefsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdefsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdefsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdh_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdh_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdh_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdy_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrdy_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrdy_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrfeatyp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfeatyp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfeatyp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfeatyp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrgenprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrgenprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrgenprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrgenprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrhdrcol"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcol service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcol service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcol service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrhdrcon"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcon service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcon service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrhdrcon service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrmapfth"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapfth service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapfth service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapfth service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrmapsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrmapsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrvalctr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalctr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalctr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalctr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrvalfth"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalfth service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalfth service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalfth service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrvallst"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvallst service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvallst service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvallst service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrvalsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvalsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_lstedtsrvwprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvwprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvwprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_lstedtsrvwprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srengg__"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg__ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg__ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg__ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srlistco"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srlistco service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srlistco service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srlistco service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srrslvec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srrslvec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srrslvec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srrslvec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srsmart_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsmart_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsmart_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsmart_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maii45srsrchco"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsrchco service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsrchco service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maii45srsrchco service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13sr_hp_enggdm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13sr_hp_enggdm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13sr_hp_enggdm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13sr_hp_enggdm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srengg_b"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_b service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_b service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_b service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srengg_k"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_k service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_k service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_k service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srengg_v"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_v service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_v service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_v service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srengg_w"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_w service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_w service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srengg_w service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggad"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggad service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggad service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggad service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggcm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggcm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggcm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggcm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggmb"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggmb service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggmb service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggmb service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggne"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggne service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggne service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggne service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggpa"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggpa service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggpa service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggpa service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srenggse"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggse service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggse service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srenggse service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srfill17"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfill17 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfill17 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfill17 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main13srfille6"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfille6 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfille6 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main13srfille6 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main14srep_la_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_la_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_la_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_la_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main14srep_lae"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_lae service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_lae service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srep_lae service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main14srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main14srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main14srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22sractivi"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22sractivi service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22sractivi service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22sractivi service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srcontro"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srcontro service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srcontro service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srcontro service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srfetch1"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch1 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srfetch2"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch2 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch2 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srfetch2 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srpage_n"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srpage_n service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srpage_n service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srpage_n service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srsave1"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave1 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srsave2"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave2 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave2 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsave2 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srsectio"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsectio service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsectio service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srsectio service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main22srui_des"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srui_des service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srui_des service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main22srui_des service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29sreng_sa"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29sreng_sa service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29sreng_sa service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29sreng_sa service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengap_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengap_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengap_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengap_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengb_s"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengb_s service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengb_s service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengb_s service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengg_t"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_t service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_t service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_t service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengg_v"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_v service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_v service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_v service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengg_w"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_w service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_w service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengg_w service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggac"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggac service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggac service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggac service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggb_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggb_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggb_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggb_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggdr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggdr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggdr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggdr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengge_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengge_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengge_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengge_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggge"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggge service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggge service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggge service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggks"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggks service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggks service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggks service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggmo"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggmo service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggmo service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggmo service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggob"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggob service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggob service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggob service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggp_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggp_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggp_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggp_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggpr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggpr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggpr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggpr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggsa"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggsa service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggsa service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggsa service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggve"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggve service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggve service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggve service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggvw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggvw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggvw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggvw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggwp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggwp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggwp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggwp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srenggys"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggys service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggys service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srenggys service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengs_s"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengs_s service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengs_s service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengs_s service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srengys_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengys_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengys_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srengys_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srgentaa"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentaa service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentaa service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentaa service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srgentab"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentab service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentab service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentab service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srgentas"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentas service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentas service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srgentas service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtreend"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreend service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreend service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreend service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtreene"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreene service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreene service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreene service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtreeno"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreeno service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreeno service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtreeno service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtvwen_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwen_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwen_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwen_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtvweng"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvweng service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvweng service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvweng service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main29srtvwent"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwent service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwent service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main29srtvwent service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main30srengg_p"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_p service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_p service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_p service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main30srengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main30srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main30srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main30srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main31srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main31srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main31srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main31srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srengg_i"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_i service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_i service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_i service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srengg_o"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_o service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_o service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srengg_o service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srep_ui_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srep_ui_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srep_ui_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srep_ui_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main32srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main32srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srcomboa"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboa service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboa service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboa service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srcomboo"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboo service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboo service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcomboo service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srcombos"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombos service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombos service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombos service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srcombou"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombou service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombou service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srcombou service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main34srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main34srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srqr_act"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_act service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_act service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_act service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srqr_con"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_con service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_con service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_con service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srqr_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main35srqr_ui1"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_ui1 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_ui1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main35srqr_ui1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36sractivi"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36sractivi service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36sractivi service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36sractivi service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srconten"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srconten service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srconten service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srconten service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srpagede"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srpagede service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srpagede service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srpagede service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srsave1"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsave1 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsave1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsave1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srsectio"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsectio service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsectio service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srsectio service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srtarget"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srtarget service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srtarget service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srtarget service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main36srui_des"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srui_des service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srui_des service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main36srui_des service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main37srcustom"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srcustom service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srcustom service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srcustom service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main37srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main37srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main37srprojec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srprojec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srprojec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main37srprojec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main38sractivi"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38sractivi service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38sractivi service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38sractivi service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main38srcompon"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srcompon service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srcompon service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srcompon service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main38srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main38srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main38srui_des"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srui_des service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srui_des service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main38srui_des service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srep_smr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srep_smr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srep_smr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srep_smr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main45srpagede"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srpagede service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srpagede service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main45srpagede service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srengg_a"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_a service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_a service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_a service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srengg_u"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_u service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_u service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_u service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srengg_v"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_v service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_v service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srengg_v service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_main46srsmart_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srsmart_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srsmart_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_main46srsmart_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrfeatur"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfeatur service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfeatur service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfeatur service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrlang"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrlang service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrlang service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrlang service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrpage"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrpage service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrpage service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrpage service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsrsect"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsect service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsect service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsrsect service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainplsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainplsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainresres_tra"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainresres_tra service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainresres_tra service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainresres_tra service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mains7srcreate"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mains7srcreate service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mains7srcreate service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mains7srcreate service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mainsesraddnew"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainsesraddnew service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainsesraddnew service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mainsesraddnew service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesr_scsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_scsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_scsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_scsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesr_uinam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_uinam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_uinam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesr_uinam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrcgdef"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrcgdef service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrcgdef service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrcgdef service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrctrnam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrctrnam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrctrnam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrctrnam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrdelete"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelete service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelete service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelete service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrdelgr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrdelgrp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgrp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgrp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrdelgrp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrep_lat"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lat service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lat service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lat service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrep_lau"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lau service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lau service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lau service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrep_lay"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lay service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lay service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrep_lay service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrgrpcap"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpcap service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpcap service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpcap service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrgrpnam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpnam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpnam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpnam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrgrpsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrgrpsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrlannam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrlannam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrlannam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrlannam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrpagnam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrpagnam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrpagnam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrpagnam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_maireesrsecnam"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsecnam service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsecnam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_maireesrsecnam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrmactde"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmactde service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmactde service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmactde service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrmsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrmsearc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsearc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsearc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmsearc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mansensrmuides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmuides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmuides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mansensrmuides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg__"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg__ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg__ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg__ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_d"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_d service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_d service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_d service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_f"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_f service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_f service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_f service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_g"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_g service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_g service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_g service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_h"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_h service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_h service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_h service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_l"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_l service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_l service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_l service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_s"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_s service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_s service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_s service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_t"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_t service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_t service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_t service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_v"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_v service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_v service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_v service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrengg_y"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_y service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_y service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrengg_y service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrenggno"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggno service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggno service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggno service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrenggtv"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggtv service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggtv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggtv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrenggvs"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggvs service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggvs service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrenggvs service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_mntlsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_mntlsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrep_nag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrep_nag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrep_nag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrep_nag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesrsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesrsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_nativesruides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesruides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_nativesruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pagevesrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pagevesrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrctrl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrctrl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrctrl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrctrl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pivgrdsrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pivgrdsrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prevw_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prevw_sr_genui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_genui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_genui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_genui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prevw_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prevw_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prevw_sr_view"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_view service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_view service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prevw_sr_view service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prffun_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prffun_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prffun_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prffun_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prfwr_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prfwr_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prfwr_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_prfwr_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_prfwr_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubact_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubact_sr_publ"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_publ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_publ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_publ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubact_sr_unpub"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_unpub service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_unpub service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubact_sr_unpub service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubcmp_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubcmp_sr_publ"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_publ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_publ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_publ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pubcmp_sr_unpub"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_unpub service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_unpub service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pubcmp_sr_unpub service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_publ"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_publ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_publ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_publ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_publ_sr_unpub"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_unpub service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_unpub service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_publ_sr_unpub service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvcr_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvcr_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvcr_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvcr_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvcr_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvcr_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransract"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransract service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransract service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransract service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrsearch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsearch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsearch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrsearch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_pvtransrui"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrui service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrui service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_pvtransrui service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_qlay_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_qlay_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_qlay_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_qlay_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrfactor"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfactor service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfactor service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfactor service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrparsec"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrparsec service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrparsec service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrparsec service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrsecfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrsecpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrsecsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrsecsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsruides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsruides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrwtfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrwtpag"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtpag service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtpag service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtpag service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_respsrwtsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_respsrwtsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revrs_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revrs_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revrs_sr_ref"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_ref service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_ref service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_ref service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revrs_sr_rscr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_rscr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_rscr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revrs_sr_rscr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_ainc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_ainc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_ainc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_ainc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_cinc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_cinc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_cinc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_cinc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_excl"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_excl service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_excl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_excl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_final"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_final service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_final service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_final service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_rinc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_rinc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_rinc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_rinc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revw_sr_selcmp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_selcmp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_selcmp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revw_sr_selcmp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revwr_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revwr_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revwr_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_revwr_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_revwr_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksrcomp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrcomp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrcomp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrcomp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksrrolbak"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrrolbak service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrrolbak service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksrrolbak service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_rolbaksruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_rolbaksruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selact_sr_cmp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_cmp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_cmp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_cmp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selact_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selact_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selact_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selcmp_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selcmp_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selcmp_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selcmp_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selrcr_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selrcr_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selrcr_sr_selcus"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selcus service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selcus service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selcus service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_selrcr_sr_selprj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selprj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selprj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_selrcr_sr_selprj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_serattsrconn"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrconn service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrconn service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrconn service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_serattsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_serattsrfetdet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfetdet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfetdet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrfetdet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_serattsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_serattsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_serattsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_synhlp_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_synhlp_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_synhlp_sr_search"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_search service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_search service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_search service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_synhlp_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_synhlp_sr_selcmp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selcmp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selcmp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_synhlp_sr_selcmp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasraddnew"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasraddnew service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasraddnew service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasraddnew service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrcust"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrcust service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrcust service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrcust service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrdelete"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrdelete service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrdelete service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrdelete service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrep_te_"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_te_ service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_te_ service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_te_ service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrep_tef"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_tef service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_tef service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrep_tef service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrnewsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrnewsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrnewsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrnewsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrproj"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrproj service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrproj service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrproj service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_templasrtempid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrtempid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrtempid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_templasrtempid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsractcon"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractcon service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractcon service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractcon service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsractsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsractsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrpage"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpage service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpage service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpage service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrparsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrparsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrparsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrparsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrpcontr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpcontr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpcontr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpcontr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrphsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrphsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrphsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrphsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrpopsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpopsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpopsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrpopsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrptemid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrptemid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrptemid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrptemid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrsect"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrsect service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrsect service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrsect service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrtcontr"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtcontr service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtcontr service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtcontr service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrtempid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtempid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtempid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtempid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrtpccol"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtpccol service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtpccol service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtpccol service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsrtsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsrtsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tempsruides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsruides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tempsruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_translsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_translsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_translsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_translsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_translsrsearch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsearch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsearch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_translsrsearch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trglo_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trglo_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trglo_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trglo_sr_search"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_search service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_search service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_search service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trglo_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trglo_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_trviewsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trviewsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trviewsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_trviewsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tsk_stsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tsk_stsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tsk_stsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tsk_stsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_tsk_stsrtsknm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrtsknm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrtsknm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_tsk_stsrtsknm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_irule_srchk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_irule_srchk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_irule_srchk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_irule_srchk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrdelete"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrdelete service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrdelete service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrdelete service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrengg_g"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrengg_g service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrengg_g service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrengg_g service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrfetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrfetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrgenprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgenprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgenprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgenprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrgrpadd"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgrpadd service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgrpadd service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrgrpadd service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrhgrpid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrhgrpid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrhgrpid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrhgrpid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrlstfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrlstsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrlstsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrsave"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrsave1"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave1 service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrsave1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrtask_g"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrtask_g service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrtask_g service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrtask_g service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsruidesc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsruidesc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsruidesc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsruidesc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_ui_tbrsrvwprw"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrvwprw service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrvwprw service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_ui_tbrsrvwprw service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uidef_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uidef_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uidef_sr_save"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_save service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_save service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_save service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uidef_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uidef_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uihelp_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uihelp_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uihelp_sr_search"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_search service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_search service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_search service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uihelp_sr_selact"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selact service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selact service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selact service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uihelp_sr_selcmp"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selcmp service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selcmp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uihelp_sr_selcmp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_init"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_init service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_init service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_init service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_savcon"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savcon service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savcon service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savcon service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_savect"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savect service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savect service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savect service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_savehc"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savehc service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savehc service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savehc service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_savess"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savess service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savess service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savess service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uip_sr_savett"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savett service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savett service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uip_sr_savett service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_sractdes"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sractdes service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srcldef"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srcldef service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srcldef service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srcldef service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srclfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srclsav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclsav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srclstid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclstid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclstid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srclstid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srct_def"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_def service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_def service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_def service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srct_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srct_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srct_sid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srct_sid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srctblnm"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srctblnm service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srctblnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srctblnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srpfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srpstdef"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstdef service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstdef service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstdef service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srpstis"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstis service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstis service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpstis service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srpsv"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpsv service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpsv service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srpsv service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srsc_def"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_def service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_def service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_def service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srsc_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srsc_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srsc_sid"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sid service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sid service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srsc_sid service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srst_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srst_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srst_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srtk_dft"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_dft service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_dft service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_dft service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srtk_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srtk_lnk"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_lnk service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_lnk service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_lnk service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_srtk_sav"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_sav service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_sav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_srtk_sav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_uista_sruides"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sruides service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_uista_sruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwlog_sr_fetch"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwlog_sr_fetch service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwlog_sr_fetch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwlog_sr_fetch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwrcr_sr_fet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwrcr_sr_fet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwrcr_sr_fet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwrcr_sr_fet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwsensrfet"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrfet service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwsensrinit"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrinit service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwsensrvwcust"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwcust service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwcust service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwcust service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("ep_vwsensrvwsear"):
						output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwsear service started.");
						if (cpreview_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwsear service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("PREVIEW.Cpreview_ltmcr.ProcessDocument - ep_vwsensrvwsear service executed with a failure.");
							return ATMA_FAILURE;
						}
					default:
						output.WriteLine("Cpreview_ltmcr.ProcessDocument - Service referred Is Not part of the runtime component-" + szServiceName);
						return ATMA_INVALID_SERVICE;
				}
			}
			catch (Exception e)
			{
				output.WriteLine("Cpreview_ltmcr.ProcessDocument - General Exception :");
				output.WriteLine(e.Message);
				szOutMtd = "";
				return ATMA_FAILURE;
			}
			finally
			{
			}
		}
	}
}
