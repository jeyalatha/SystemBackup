/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_layoutsrborsec.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_layoutsrborsec : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htBORCTLCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        private string s_HSEGep_custom_bor_bw = "0";
        private string s_HSEGep_custom_bor_lw = "0";
        private string s_HSEGep_custom_bor_rw = "0";
        private string s_HSEGep_custom_bor_tw = "0";
        private string modeFlagValue = string.Empty;
        public Cep_layoutsrborsec()
        {
            base.iEDKESEngineInit("ep_layoutsrborsec", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htBORCTLCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("borctlcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("borctlcbseg");
                    this.writer.WriteAttributeString("RecordCount", htBORCTLCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htBORCTLCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htBORCTLCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_custom_bor_ctrlname", System.Convert.ToString(nvcTmp["ep_custom_bor_ctrlname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("borctlcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvc_HSEG["engg_act_descr"]));
                    this.writer.WriteAttributeString("engg_component", System.Convert.ToString(nvc_HSEG["engg_component"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HSEG["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HSEG["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HSEG["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_req_no", System.Convert.ToString(nvc_HSEG["engg_req_no"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HSEG["engg_ui_descr"]));
                    this.writer.WriteAttributeString("ep_custom_bor_bc", System.Convert.ToString(nvc_HSEG["ep_custom_bor_bc"]));
                    this.writer.WriteAttributeString("ep_custom_bor_bottom_lr", System.Convert.ToString(nvc_HSEG["ep_custom_bor_bottom_lr"]));
                    this.writer.WriteAttributeString("ep_custom_bor_bottom_rr", System.Convert.ToString(nvc_HSEG["ep_custom_bor_bottom_rr"]));
                    this.writer.WriteAttributeString("ep_custom_bor_bw", System.Convert.ToString(nvc_HSEG["ep_custom_bor_bw"]));
                    this.writer.WriteAttributeString("ep_custom_bor_ctrlname", System.Convert.ToString(nvc_HSEG["ep_custom_bor_ctrlname"]));
                    this.writer.WriteAttributeString("ep_custom_bor_lc", System.Convert.ToString(nvc_HSEG["ep_custom_bor_lc"]));
                    this.writer.WriteAttributeString("ep_custom_bor_lw", System.Convert.ToString(nvc_HSEG["ep_custom_bor_lw"]));
                    this.writer.WriteAttributeString("ep_custom_bor_pgename", System.Convert.ToString(nvc_HSEG["ep_custom_bor_pgename"]));
                    this.writer.WriteAttributeString("ep_custom_bor_rc", System.Convert.ToString(nvc_HSEG["ep_custom_bor_rc"]));
                    this.writer.WriteAttributeString("ep_custom_bor_rw", System.Convert.ToString(nvc_HSEG["ep_custom_bor_rw"]));
                    this.writer.WriteAttributeString("ep_custom_bor_secname", System.Convert.ToString(nvc_HSEG["ep_custom_bor_secname"]));
                    this.writer.WriteAttributeString("ep_custom_bor_style", System.Convert.ToString(nvc_HSEG["ep_custom_bor_style"]));
                    this.writer.WriteAttributeString("ep_custom_bor_tc", System.Convert.ToString(nvc_HSEG["ep_custom_bor_tc"]));
                    this.writer.WriteAttributeString("ep_custom_bor_top_lr", System.Convert.ToString(nvc_HSEG["ep_custom_bor_top_lr"]));
                    this.writer.WriteAttributeString("ep_custom_bor_top_rr", System.Convert.ToString(nvc_HSEG["ep_custom_bor_top_rr"]));
                    this.writer.WriteAttributeString("ep_custom_bor_tw", System.Convert.ToString(nvc_HSEG["ep_custom_bor_tw"]));
                    this.writer.WriteAttributeString("ep_custom_hidden1", System.Convert.ToString(nvc_HSEG["ep_custom_hidden1"]));
                    this.writer.WriteAttributeString("ep_custom_hidden2", System.Convert.ToString(nvc_HSEG["ep_custom_hidden2"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_bc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_bottom_lr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_bottom_rr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_bw":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_custom_bor_ctrlname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_lc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_lw":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_custom_bor_pgename":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_rc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_rw":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_custom_bor_secname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_style":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_tc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_top_lr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_top_rr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_bor_tw":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_custom_hidden1":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_custom_hidden2":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "borctlcbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "borctlcbseg":
                    return htBORCTLCBSEG.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "borctlcbseg":
                    return this.htBORCTLCBSEG;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "borctlcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpborctlcbseg = (NameValueCollection)htBORCTLCBSEG[lnInstNumber];
                        return nvcTmpborctlcbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_layoutsrborsec Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_layoutsrborsec Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psborseccbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bc"];
                            base.Parameters("@ep_custom_bor_bc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bottom_lr"];
                            base.Parameters("@ep_custom_bor_bottom_lr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bottom_rr"];
                            base.Parameters("@ep_custom_bor_bottom_rr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_bw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_bw);
                            base.Parameters("@ep_custom_bor_bw", DBType.Int, 32, s_HSEGep_custom_bor_bw);
                            sValue = nvc_HSEG["ep_custom_bor_lc"];
                            base.Parameters("@ep_custom_bor_lc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_lw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_lw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_lw);
                            base.Parameters("@ep_custom_bor_lw", DBType.Int, 32, s_HSEGep_custom_bor_lw);
                            sValue = nvc_HSEG["ep_custom_bor_pgename"];
                            base.Parameters("@ep_custom_bor_pgename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_rc"];
                            base.Parameters("@ep_custom_bor_rc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_rw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_rw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_rw);
                            base.Parameters("@ep_custom_bor_rw", DBType.Int, 32, s_HSEGep_custom_bor_rw);
                            sValue = nvc_HSEG["ep_custom_bor_secname"];
                            base.Parameters("@ep_custom_bor_secname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_style"];
                            base.Parameters("@ep_custom_bor_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_tc"];
                            base.Parameters("@ep_custom_bor_tc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_top_lr"];
                            base.Parameters("@ep_custom_bor_top_lr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_top_rr"];
                            base.Parameters("@ep_custom_bor_top_rr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_tw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_tw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_tw);
                            base.Parameters("@ep_custom_bor_tw", DBType.Int, 32, s_HSEGep_custom_bor_tw);
                            sValue = nvc_HSEG["ep_custom_hidden1"];
                            base.Parameters("@ep_custom_hidden1", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_hidden2"];
                            base.Parameters("@ep_custom_hidden2", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layoutmtborsecborctl", nLoop, nMax));
                        base.Execute_SP(true, "ep_layoutspborsecborctl", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128877, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128877, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htBORCTLCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_custom_bor_ctrlname");
                                    nvcTmp["ep_custom_bor_ctrlname"] = sValue;
                                    htBORCTLCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128877, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psborsechpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bc"];
                            base.Parameters("@ep_custom_bor_bc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bottom_lr"];
                            base.Parameters("@ep_custom_bor_bottom_lr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bottom_rr"];
                            base.Parameters("@ep_custom_bor_bottom_rr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_bw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_bw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_bw);
                            base.Parameters("@ep_custom_bor_bw", DBType.Int, 32, s_HSEGep_custom_bor_bw);
                            sValue = nvc_HSEG["ep_custom_bor_ctrlname"];
                            base.Parameters("@ep_custom_bor_ctrlname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_lc"];
                            base.Parameters("@ep_custom_bor_lc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_lw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_lw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_lw);
                            base.Parameters("@ep_custom_bor_lw", DBType.Int, 32, s_HSEGep_custom_bor_lw);
                            sValue = nvc_HSEG["ep_custom_bor_pgename"];
                            base.Parameters("@ep_custom_bor_pgename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_rc"];
                            base.Parameters("@ep_custom_bor_rc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_rw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_rw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_rw);
                            base.Parameters("@ep_custom_bor_rw", DBType.Int, 32, s_HSEGep_custom_bor_rw);
                            sValue = nvc_HSEG["ep_custom_bor_secname"];
                            base.Parameters("@ep_custom_bor_secname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_style"];
                            base.Parameters("@ep_custom_bor_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_tc"];
                            base.Parameters("@ep_custom_bor_tc", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_top_lr"];
                            base.Parameters("@ep_custom_bor_top_lr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_top_rr"];
                            base.Parameters("@ep_custom_bor_top_rr", DBType.NVarchar, 10, sValue);
                            sValue = nvc_HSEG["ep_custom_bor_tw"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_custom_bor_tw = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_custom_bor_tw);
                            base.Parameters("@ep_custom_bor_tw", DBType.Int, 32, s_HSEGep_custom_bor_tw);
                            sValue = nvc_HSEG["ep_custom_hidden1"];
                            base.Parameters("@ep_custom_hidden1", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_custom_hidden2"];
                            base.Parameters("@ep_custom_hidden2", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layoutmtborsechdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_layoutspborsechdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128878, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128878, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_act_descr");
                                nvc_HSEG["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_component");
                                nvc_HSEG["engg_component"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HSEG["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HSEG["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HSEG["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_req_no");
                                nvc_HSEG["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HSEG["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_bc");
                                nvc_HSEG["ep_custom_bor_bc"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_bottom_lr");
                                nvc_HSEG["ep_custom_bor_bottom_lr"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_bottom_rr");
                                nvc_HSEG["ep_custom_bor_bottom_rr"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_bw");
                                nvc_HSEG["ep_custom_bor_bw"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_ctrlname");
                                nvc_HSEG["ep_custom_bor_ctrlname"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_lc");
                                nvc_HSEG["ep_custom_bor_lc"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_lw");
                                nvc_HSEG["ep_custom_bor_lw"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_pgename");
                                nvc_HSEG["ep_custom_bor_pgename"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_rc");
                                nvc_HSEG["ep_custom_bor_rc"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_rw");
                                nvc_HSEG["ep_custom_bor_rw"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_secname");
                                nvc_HSEG["ep_custom_bor_secname"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_style");
                                nvc_HSEG["ep_custom_bor_style"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_tc");
                                nvc_HSEG["ep_custom_bor_tc"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_top_lr");
                                nvc_HSEG["ep_custom_bor_top_lr"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_top_rr");
                                nvc_HSEG["ep_custom_bor_top_rr"] = sValue;
                                sValue = this.GetValue("ep_custom_bor_tw");
                                nvc_HSEG["ep_custom_bor_tw"] = sValue;
                                sValue = this.GetValue("ep_custom_hidden1");
                                nvc_HSEG["ep_custom_hidden1"] = sValue;
                                sValue = this.GetValue("ep_custom_hidden2");
                                nvc_HSEG["ep_custom_hidden2"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128878, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "borctlcbseg":
                            Localtable = (NameValueCollection)htBORCTLCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_layoutsrborsec(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_layoutsrborsec(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_layoutsrborsec.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

