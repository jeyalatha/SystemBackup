/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_tempsractcon.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_tempsractcon : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htLISTEDIT_POPLE = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPPSCNMCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcACTGRDUIML = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcPLF_STATE_SEGMENT = new System.Collections.Specialized.NameValueCollection();
        private string s_HSEGep_tpl_act = "0";
        private string s_HSEGep_tpl_act_chlheight = "0";
        private string s_HSEGep_tpl_act_chlwidth = "0";
        private string s_HSEGep_tpl_params = "0";
        private string modeFlagValue = string.Empty;
        public Cep_tempsractcon()
        {
            base.iEDKESEngineInit("ep_tempsractcon", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htLISTEDIT_POPLE != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("listedit_pople", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("listedit_pople");
                    this.writer.WriteAttributeString("RecordCount", htLISTEDIT_POPLE.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLISTEDIT_POPLE.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLISTEDIT_POPLE[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_tpl_pop_lstactdesc", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstactdesc"]));
                            this.writer.WriteAttributeString("ep_tpl_pop_lstactname", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstactname"]));
                            this.writer.WriteAttributeString("ep_tpl_pop_lstcompdesc", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstcompdesc"]));
                            this.writer.WriteAttributeString("ep_tpl_pop_lstcompname", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstcompname"]));
                            this.writer.WriteAttributeString("ep_tpl_pop_lstuidesc", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstuidesc"]));
                            this.writer.WriteAttributeString("ep_tpl_pop_lstuiname", System.Convert.ToString(nvcTmp["ep_tpl_pop_lstuiname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("listedit_pople", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPPSCNMCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ppscnmcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ppscnmcbseg");
                    this.writer.WriteAttributeString("RecordCount", htPPSCNMCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPPSCNMCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPPSCNMCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("ep_tpl_act_popsecname", System.Convert.ToString(nvcTmp["ep_tpl_act_popsecname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ppscnmcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvcACTGRDUIML != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("actgrduiml", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("actgrduiml");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("ep_tpl_act_actionname", System.Convert.ToString(nvcACTGRDUIML["ep_tpl_act_actionname"]));
                    this.writer.WriteAttributeString("ep_tpl_act_actiontype", System.Convert.ToString(nvcACTGRDUIML["ep_tpl_act_actiontype"]));
                    this.writer.WriteAttributeString("ep_tpl_act_configure", System.Convert.ToString(nvcACTGRDUIML["ep_tpl_act_configure"]));
                    this.writer.WriteAttributeString("ep_tpl_act_reporttask", System.Convert.ToString(nvcACTGRDUIML["ep_tpl_act_reporttask"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("actgrduiml", nvcACTGRDUIML);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.nvcPLF_STATE_SEGMENT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("plf_state_segment", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("plf_state_segment");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("hdnrt_stcontrol", System.Convert.ToString(nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("plf_state_segment", nvcPLF_STATE_SEGMENT);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "ep_temp_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_cust":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_page":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_proc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_proj":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_req":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_section":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_temp_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_tpl_act_chlheight":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_tpl_act_chlwidth":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_tpl_act_launchmode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_popsecname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_targetact":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_targetcomp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_targetui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_par_ctrl_col":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_par_tplid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_params":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "hdncustomer":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnproject":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "prj_hdn_ctrl":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "actgrduiml":
                        switch (DataItem)
                        {
                            case "ep_tpl_act_actionname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_actiontype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_configure":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_tpl_act_reporttask":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcACTGRDUIML[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcACTGRDUIML[DataItem] = DIValue;
                        return 0;
                    case "plf_state_segment":
                        switch (DataItem)
                        {
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcPLF_STATE_SEGMENT[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_pople":
                    type = 1;
                    break;
                case "ppscnmcbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "actgrduiml":
                    type = 0;
                    break;
                case "plf_state_segment":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_pople":
                    return htLISTEDIT_POPLE.Count;
                    break;
                case "ppscnmcbseg":
                    return htPPSCNMCBSEG.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_pople":
                    return this.htLISTEDIT_POPLE;
                case "ppscnmcbseg":
                    return this.htPPSCNMCBSEG;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                case "actgrduiml":
                    return this.nvcACTGRDUIML;
                case "plf_state_segment":
                    return this.nvcPLF_STATE_SEGMENT;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "listedit_pople":
                        System.Collections.Specialized.NameValueCollection nvcTmplistedit_pople = (NameValueCollection)htLISTEDIT_POPLE[lnInstNumber];
                        return nvcTmplistedit_pople[szDataItem];
                        break;
                    case "ppscnmcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpppscnmcbseg = (NameValueCollection)htPPSCNMCBSEG[lnInstNumber];
                        return nvcTmpppscnmcbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "actgrduiml":
                        return nvcACTGRDUIML[szDataItem];
                        break;
                    case "plf_state_segment":
                        return nvcPLF_STATE_SEGMENT[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_tempsractcon Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_tempsractcon Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactcon");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_temp_act"];
                            base.Parameters("@ep_temp_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_comp"];
                            base.Parameters("@ep_temp_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_cust"];
                            base.Parameters("@ep_temp_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_page"];
                            base.Parameters("@ep_temp_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_proc"];
                            base.Parameters("@ep_temp_proc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_proj"];
                            base.Parameters("@ep_temp_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_req"];
                            base.Parameters("@ep_temp_req", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_section"];
                            base.Parameters("@ep_temp_section", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_ui"];
                            base.Parameters("@ep_temp_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_tpl_act"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act);
                            base.Parameters("@ep_tpl_act", DBType.Int, 32, s_HSEGep_tpl_act);
                            sValue = nvc_HSEG["ep_tpl_act_chlheight"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlheight = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlheight);
                            base.Parameters("@ep_tpl_act_chlheight", DBType.Int, 32, s_HSEGep_tpl_act_chlheight);
                            sValue = nvc_HSEG["ep_tpl_act_chlwidth"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlwidth = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlwidth);
                            base.Parameters("@ep_tpl_act_chlwidth", DBType.Int, 32, s_HSEGep_tpl_act_chlwidth);
                            sValue = nvc_HSEG["ep_tpl_act_launchmode"];
                            base.Parameters("@ep_tpl_act_launchmode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_popsecname"];
                            base.Parameters("@ep_tpl_act_popsecname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetact"];
                            base.Parameters("@ep_tpl_act_targetact", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetcomp"];
                            base.Parameters("@ep_tpl_act_targetcomp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetui"];
                            base.Parameters("@ep_tpl_act_targetui", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_params"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_params = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_params);
                            base.Parameters("@ep_tpl_params", DBType.Int, 32, s_HSEGep_tpl_params);
                            sValue = nvc_HSEG["ep_tpl_par_ctrl_col"];
                            base.Parameters("@ep_tpl_par_ctrl_col", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_par_tplid"];
                            base.Parameters("@ep_tpl_par_tplid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvcACTGRDUIML["ep_tpl_act_actionname"];
                            base.Parameters("@ep_tpl_act_actionname", DBType.NVarchar, 60, sValue);
                            sValue = nvcACTGRDUIML["ep_tpl_act_actiontype"];
                            base.Parameters("@ep_tpl_act_actiontype", DBType.NVarchar, 60, sValue);
                            sValue = nvcACTGRDUIML["ep_tpl_act_configure"];
                            base.Parameters("@ep_tpl_act_configure", DBType.NVarchar, 60, sValue);
                            sValue = nvcACTGRDUIML["ep_tpl_act_reporttask"];
                            base.Parameters("@ep_tpl_act_reporttask", DBType.NVarchar, 20, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_tempmtactconumactcon", nLoop, nMax));
                        base.Execute_SP(true, "ep_tempspactconumactcon", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128187, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128187, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("ep_tpl_act_actionname");
                                nvcACTGRDUIML["ep_tpl_act_actionname"] = sValue;
                                sValue = this.GetValue("ep_tpl_act_actiontype");
                                nvcACTGRDUIML["ep_tpl_act_actiontype"] = sValue;
                                sValue = this.GetValue("ep_tpl_act_configure");
                                nvcACTGRDUIML["ep_tpl_act_configure"] = sValue;
                                sValue = this.GetValue("ep_tpl_act_reporttask");
                                nvcACTGRDUIML["ep_tpl_act_reporttask"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128187, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactconpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_temp_act"];
                            base.Parameters("@ep_temp_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_comp"];
                            base.Parameters("@ep_temp_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_cust"];
                            base.Parameters("@ep_temp_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_page"];
                            base.Parameters("@ep_temp_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_proc"];
                            base.Parameters("@ep_temp_proc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_proj"];
                            base.Parameters("@ep_temp_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_req"];
                            base.Parameters("@ep_temp_req", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_section"];
                            base.Parameters("@ep_temp_section", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_ui"];
                            base.Parameters("@ep_temp_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_tpl_act"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act);
                            base.Parameters("@ep_tpl_act", DBType.Int, 32, s_HSEGep_tpl_act);
                            sValue = nvc_HSEG["ep_tpl_act_chlheight"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlheight = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlheight);
                            base.Parameters("@ep_tpl_act_chlheight", DBType.Int, 32, s_HSEGep_tpl_act_chlheight);
                            sValue = nvc_HSEG["ep_tpl_act_chlwidth"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlwidth = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlwidth);
                            base.Parameters("@ep_tpl_act_chlwidth", DBType.Int, 32, s_HSEGep_tpl_act_chlwidth);
                            sValue = nvc_HSEG["ep_tpl_act_launchmode"];
                            base.Parameters("@ep_tpl_act_launchmode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_popsecname"];
                            base.Parameters("@ep_tpl_act_popsecname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetact"];
                            base.Parameters("@ep_tpl_act_targetact", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetcomp"];
                            base.Parameters("@ep_tpl_act_targetcomp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetui"];
                            base.Parameters("@ep_tpl_act_targetui", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_params"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_params = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_params);
                            base.Parameters("@ep_tpl_params", DBType.Int, 32, s_HSEGep_tpl_params);
                            sValue = nvc_HSEG["ep_tpl_par_ctrl_col"];
                            base.Parameters("@ep_tpl_par_ctrl_col", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_par_tplid"];
                            base.Parameters("@ep_tpl_par_tplid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            sValue = nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_tempmtactcon_statemto", nLoop, nMax));
                        base.Execute_SP(true, "ep_tempspactcon_statespo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128188, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128188, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("hdnrt_stcontrol");
                                nvcPLF_STATE_SEGMENT["hdnrt_stcontrol"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128188, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 2  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactconpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_temp_act"];
                            base.Parameters("@ep_temp_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_comp"];
                            base.Parameters("@ep_temp_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_cust"];
                            base.Parameters("@ep_temp_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_page"];
                            base.Parameters("@ep_temp_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_proc"];
                            base.Parameters("@ep_temp_proc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_proj"];
                            base.Parameters("@ep_temp_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_req"];
                            base.Parameters("@ep_temp_req", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_section"];
                            base.Parameters("@ep_temp_section", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_ui"];
                            base.Parameters("@ep_temp_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_tpl_act"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act);
                            base.Parameters("@ep_tpl_act", DBType.Int, 32, s_HSEGep_tpl_act);
                            sValue = nvc_HSEG["ep_tpl_act_chlheight"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlheight = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlheight);
                            base.Parameters("@ep_tpl_act_chlheight", DBType.Int, 32, s_HSEGep_tpl_act_chlheight);
                            sValue = nvc_HSEG["ep_tpl_act_chlwidth"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlwidth = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlwidth);
                            base.Parameters("@ep_tpl_act_chlwidth", DBType.Int, 32, s_HSEGep_tpl_act_chlwidth);
                            sValue = nvc_HSEG["ep_tpl_act_launchmode"];
                            base.Parameters("@ep_tpl_act_launchmode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_popsecname"];
                            base.Parameters("@ep_tpl_act_popsecname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetact"];
                            base.Parameters("@ep_tpl_act_targetact", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetcomp"];
                            base.Parameters("@ep_tpl_act_targetcomp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetui"];
                            base.Parameters("@ep_tpl_act_targetui", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_params"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_params = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_params);
                            base.Parameters("@ep_tpl_params", DBType.Int, 32, s_HSEGep_tpl_params);
                            sValue = nvc_HSEG["ep_tpl_par_ctrl_col"];
                            base.Parameters("@ep_tpl_par_ctrl_col", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_par_tplid"];
                            base.Parameters("@ep_tpl_par_tplid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_tempmtactcon_popleleo", nLoop, nMax));
                        base.Execute_SP(true, "ep_tempspactcon_popleleo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128189, 2, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128189, 2, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLISTEDIT_POPLE.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_tpl_pop_lstactdesc");
                                    nvcTmp["ep_tpl_pop_lstactdesc"] = sValue;
                                    sValue = this.GetValue("ep_tpl_pop_lstactname");
                                    nvcTmp["ep_tpl_pop_lstactname"] = sValue;
                                    sValue = this.GetValue("ep_tpl_pop_lstcompdesc");
                                    nvcTmp["ep_tpl_pop_lstcompdesc"] = sValue;
                                    sValue = this.GetValue("ep_tpl_pop_lstcompname");
                                    nvcTmp["ep_tpl_pop_lstcompname"] = sValue;
                                    sValue = this.GetValue("ep_tpl_pop_lstuidesc");
                                    nvcTmp["ep_tpl_pop_lstuidesc"] = sValue;
                                    sValue = this.GetValue("ep_tpl_pop_lstuiname");
                                    nvcTmp["ep_tpl_pop_lstuiname"] = sValue;
                                    htLISTEDIT_POPLE[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128189, 2, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psactconcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_temp_act"];
                            base.Parameters("@ep_temp_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_comp"];
                            base.Parameters("@ep_temp_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_cust"];
                            base.Parameters("@ep_temp_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_page"];
                            base.Parameters("@ep_temp_page", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_proc"];
                            base.Parameters("@ep_temp_proc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_temp_proj"];
                            base.Parameters("@ep_temp_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_req"];
                            base.Parameters("@ep_temp_req", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_section"];
                            base.Parameters("@ep_temp_section", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_temp_ui"];
                            base.Parameters("@ep_temp_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ep_tpl_act"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act);
                            base.Parameters("@ep_tpl_act", DBType.Int, 32, s_HSEGep_tpl_act);
                            sValue = nvc_HSEG["ep_tpl_act_chlheight"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlheight = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlheight);
                            base.Parameters("@ep_tpl_act_chlheight", DBType.Int, 32, s_HSEGep_tpl_act_chlheight);
                            sValue = nvc_HSEG["ep_tpl_act_chlwidth"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_act_chlwidth = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_act_chlwidth);
                            base.Parameters("@ep_tpl_act_chlwidth", DBType.Int, 32, s_HSEGep_tpl_act_chlwidth);
                            sValue = nvc_HSEG["ep_tpl_act_launchmode"];
                            base.Parameters("@ep_tpl_act_launchmode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetact"];
                            base.Parameters("@ep_tpl_act_targetact", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetcomp"];
                            base.Parameters("@ep_tpl_act_targetcomp", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_act_targetui"];
                            base.Parameters("@ep_tpl_act_targetui", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_params"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGep_tpl_params = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGep_tpl_params);
                            base.Parameters("@ep_tpl_params", DBType.Int, 32, s_HSEGep_tpl_params);
                            sValue = nvc_HSEG["ep_tpl_par_ctrl_col"];
                            base.Parameters("@ep_tpl_par_ctrl_col", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ep_tpl_par_tplid"];
                            base.Parameters("@ep_tpl_par_tplid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdncustomer"];
                            base.Parameters("@hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdnproject"];
                            base.Parameters("@hdnproject", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["prj_hdn_ctrl"];
                            base.Parameters("@prj_hdn_ctrl", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_tempmtactconppscnm", nLoop, nMax));
                        base.Execute_SP(true, "ep_tempspactconppscnm", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128186, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128186, 3, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPPSCNMCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ep_tpl_act_popsecname");
                                    nvcTmp["ep_tpl_act_popsecname"] = sValue;
                                    htPPSCNMCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128186, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "listedit_pople":
                            Localtable = (NameValueCollection)htLISTEDIT_POPLE[lInstance];
                            break;
                        case "ppscnmcbseg":
                            Localtable = (NameValueCollection)htPPSCNMCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "actgrduiml":
                            Localtable = nvcACTGRDUIML;
                            break;
                        case "plf_state_segment":
                            Localtable = nvcPLF_STATE_SEGMENT;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_tempsractcon(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_tempsractcon(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_tempsractcon.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

