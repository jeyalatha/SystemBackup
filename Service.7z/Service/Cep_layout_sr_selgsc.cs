/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_layout_sr_selgsc.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_layout_sr_selgsc : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htG_GRID_CB = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcCB_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htGDML_MLO = new System.Collections.Hashtable();
        private string s_HDRfprowno = "0";
        private string modeFlagValue = string.Empty;
        public Cep_layout_sr_selgsc()
        {
            base.iEDKESEngineInit("ep_layout_sr_selgsc", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htG_GRID_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("g_grid_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("g_grid_cb");
                    this.writer.WriteAttributeString("RecordCount", htG_GRID_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htG_GRID_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htG_GRID_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvcTmp["engg_grid_grid_code"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("g_grid_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HDR != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hdr", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hdr");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_grid_ctrl_type_bts", System.Convert.ToString(nvc_HDR["engg_grid_ctrl_type_bts"]));
                    this.writer.WriteAttributeString("engg_grid_sec_type_bts", System.Convert.ToString(nvc_HDR["engg_grid_sec_type_bts"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hdr", nvc_HDR);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.nvcCB_HDR != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cb_hdr", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cb_hdr");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvcCB_HDR["engg_grid_grid_code"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("cb_hdr", nvcCB_HDR);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htGDML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("gdml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("gdml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htGDML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htGDML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGDML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("col_associate_ctrl", System.Convert.ToString(nvcTmp["col_associate_ctrl"]));
                            this.writer.WriteAttributeString("col_class_ext6", System.Convert.ToString(nvcTmp["col_class_ext6"]));
                            this.writer.WriteAttributeString("col_compact_view", System.Convert.ToString(nvcTmp["col_compact_view"]));
                            this.writer.WriteAttributeString("col_icon_class", System.Convert.ToString(nvcTmp["col_icon_class"]));
                            this.writer.WriteAttributeString("col_icon_position", System.Convert.ToString(nvcTmp["col_icon_position"]));
                            this.writer.WriteAttributeString("col_temp_cat", System.Convert.ToString(nvcTmp["col_temp_cat"]));
                            this.writer.WriteAttributeString("col_temp_specific", System.Convert.ToString(nvcTmp["col_temp_specific"]));
                            this.writer.WriteAttributeString("col_transform_as", System.Convert.ToString(nvcTmp["col_transform_as"]));
                            this.writer.WriteAttributeString("columnclass", System.Convert.ToString(nvcTmp["columnclass"]));
                            this.writer.WriteAttributeString("engg_col_descr", System.Convert.ToString(nvcTmp["engg_col_descr"]));
                            this.writer.WriteAttributeString("engg_col_tempid", System.Convert.ToString(nvcTmp["engg_col_tempid"]));
                            this.writer.WriteAttributeString("engg_extensionorder", System.Convert.ToString(nvcTmp["engg_extensionorder"]));
                            this.writer.WriteAttributeString("engg_extensionreqd", System.Convert.ToString(nvcTmp["engg_extensionreqd"]));
                            this.writer.WriteAttributeString("engg_grd_visible", System.Convert.ToString(nvcTmp["engg_grd_visible"]));
                            this.writer.WriteAttributeString("engg_grid_btsynname", System.Convert.ToString(nvcTmp["engg_grid_btsynname"]));
                            this.writer.WriteAttributeString("engg_grid_colno", System.Convert.ToString(nvcTmp["engg_grid_colno"]));
                            this.writer.WriteAttributeString("engg_grid_default", System.Convert.ToString(nvcTmp["engg_grid_default"]));
                            this.writer.WriteAttributeString("engg_grid_doc", System.Convert.ToString(nvcTmp["engg_grid_doc"]));
                            this.writer.WriteAttributeString("engg_grid_elem_type", System.Convert.ToString(nvcTmp["engg_grid_elem_type"]));
                            this.writer.WriteAttributeString("engg_grid_samp_data", System.Convert.ToString(nvcTmp["engg_grid_samp_data"]));
                            this.writer.WriteAttributeString("engg_grid_tooltip", System.Convert.ToString(nvcTmp["engg_grid_tooltip"]));
                            this.writer.WriteAttributeString("engg_grid_vis_length", System.Convert.ToString(nvcTmp["engg_grid_vis_length"]));
                            this.writer.WriteAttributeString("engg_tree_column", System.Convert.ToString(nvcTmp["engg_tree_column"]));
                            this.writer.WriteAttributeString("forcefit", System.Convert.ToString(nvcTmp["forcefit"]));
                            this.writer.WriteAttributeString("formenabled", System.Convert.ToString(nvcTmp["formenabled"]));
                            this.writer.WriteAttributeString("rowexpander", System.Convert.ToString(nvcTmp["rowexpander"]));
                            this.writer.WriteAttributeString("set_user_pref_ml", System.Convert.ToString(nvcTmp["set_user_pref_ml"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("gdml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hdr":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_ctrl_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_grid_code":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HDR[DataItem] = DIValue;
                        return 0;
                    case "cb_hdr":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_grid_code":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcCB_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcCB_HDR[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "g_grid_cb":
                    type = 1;
                    break;
                case "_hdr":
                    type = 0;
                    break;
                case "cb_hdr":
                    type = 0;
                    break;
                case "gdml_mlo":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "g_grid_cb":
                    return htG_GRID_CB.Count;
                    break;
                case "gdml_mlo":
                    return htGDML_MLO.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "g_grid_cb":
                    return this.htG_GRID_CB;
                case "gdml_mlo":
                    return this.htGDML_MLO;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hdr":
                    return this.nvc_HDR;
                case "cb_hdr":
                    return this.nvcCB_HDR;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "g_grid_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpg_grid_cb = (NameValueCollection)htG_GRID_CB[lnInstNumber];
                        return nvcTmpg_grid_cb[szDataItem];
                        break;
                    case "_hdr":
                        return nvc_HDR[szDataItem];
                        break;
                    case "cb_hdr":
                        return nvcCB_HDR[szDataItem];
                        break;
                    case "gdml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpgdml_mlo = (NameValueCollection)htGDML_MLO[lnInstNumber];
                        return nvcTmpgdml_mlo[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_layout_sr_selgsc Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                this.ProcessPS4();
                this.ProcessPS5();
                this.ProcessPS6();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_layout_sr_selgsc Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgsc");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscuihdr", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_selgscuihdr", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61775, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61775, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("fprowno");
                                nvc_HDR["fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61775, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgsc_gdml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscgdml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_selgscgdml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61776, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61776, 2, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgscuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscg_grid", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_selgscg_grid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61777, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61777, 3, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htG_GRID_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_grid_code");
                                    nvcTmp["engg_grid_grid_code"] = sValue;
                                    htG_GRID_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61777, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS4()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 4;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 4
                // Starting to execute the BR - 1  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgscuicbdf");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvcCB_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscucdef", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_selgscucdef", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61778, 4, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61778, 4, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_grid_grid_code");
                                nvcCB_HDR["engg_grid_grid_code"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61778, 4, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS5()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 5;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 5
                // Starting to execute the BR - 1  under the process section - 5
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 5;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgsc_href");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_grid_code"];
                            base.Parameters("@engg_grid_grid_code", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_grid_sec_type_bts"];
                            base.Parameters("@engg_grid_sec_type_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_ctrl_type_bts"];
                            base.Parameters("@engg_grid_ctrl_type_bts", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 5 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscgdhdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_selgscgdhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128975, 5, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128975, 5, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_act_descr");
                                nvc_HDR["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_component");
                                nvc_HDR["engg_component"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HDR["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_grid_ctrl_type_bts");
                                nvc_HDR["engg_grid_ctrl_type_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_grid_code");
                                nvc_HDR["engg_grid_grid_code"] = sValue;
                                sValue = this.GetValue("engg_grid_page_bts");
                                nvc_HDR["engg_grid_page_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_bts");
                                nvc_HDR["engg_grid_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_type_bts");
                                nvc_HDR["engg_grid_sec_type_bts"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HDR["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HDR["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_req_no");
                                nvc_HDR["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HDR["engg_ui_descr"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 5 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128975, 5, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 5 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS6()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 6;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 6
                // Starting to execute the BR - 1  under the process section - 6
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 6;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selgsc_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_page_bts"];
                            base.Parameters("@engg_grid_page_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_bts"];
                            base.Parameters("@engg_grid_sec_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 6 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_selgscgdml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_selgscgdml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61779, 6, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61779, 6, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGDML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("col_associate_ctrl");
                                    nvcTmp["col_associate_ctrl"] = sValue;
                                    sValue = this.GetValue("col_class_ext6");
                                    nvcTmp["col_class_ext6"] = sValue;
                                    sValue = this.GetValue("col_compact_view");
                                    nvcTmp["col_compact_view"] = sValue;
                                    sValue = this.GetValue("col_icon_class");
                                    nvcTmp["col_icon_class"] = sValue;
                                    sValue = this.GetValue("col_icon_position");
                                    nvcTmp["col_icon_position"] = sValue;
                                    sValue = this.GetValue("col_temp_cat");
                                    nvcTmp["col_temp_cat"] = sValue;
                                    sValue = this.GetValue("col_temp_specific");
                                    nvcTmp["col_temp_specific"] = sValue;
                                    sValue = this.GetValue("col_transform_as");
                                    nvcTmp["col_transform_as"] = sValue;
                                    sValue = this.GetValue("columnclass");
                                    nvcTmp["columnclass"] = sValue;
                                    sValue = this.GetValue("engg_col_descr");
                                    nvcTmp["engg_col_descr"] = sValue;
                                    sValue = this.GetValue("engg_col_tempid");
                                    nvcTmp["engg_col_tempid"] = sValue;
                                    sValue = this.GetValue("engg_expander");
                                    nvcTmp["rowexpander"] = sValue;
                                    sValue = this.GetValue("engg_extensionorder");
                                    nvcTmp["engg_extensionorder"] = sValue;
                                    sValue = this.GetValue("engg_extensionreqd");
                                    nvcTmp["engg_extensionreqd"] = sValue;
                                    sValue = this.GetValue("engg_formenabled");
                                    nvcTmp["formenabled"] = sValue;
                                    sValue = this.GetValue("engg_grd_visible");
                                    nvcTmp["engg_grd_visible"] = sValue;
                                    sValue = this.GetValue("engg_grid_btsynname");
                                    nvcTmp["engg_grid_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_grid_colno");
                                    nvcTmp["engg_grid_colno"] = sValue;
                                    sValue = this.GetValue("engg_grid_default");
                                    nvcTmp["engg_grid_default"] = sValue;
                                    sValue = this.GetValue("engg_grid_doc");
                                    nvcTmp["engg_grid_doc"] = sValue;
                                    sValue = this.GetValue("engg_grid_elem_type");
                                    nvcTmp["engg_grid_elem_type"] = sValue;
                                    sValue = this.GetValue("engg_grid_samp_data");
                                    nvcTmp["engg_grid_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_grid_tooltip");
                                    nvcTmp["engg_grid_tooltip"] = sValue;
                                    sValue = this.GetValue("engg_grid_vis_length");
                                    nvcTmp["engg_grid_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_tree_column");
                                    nvcTmp["engg_tree_column"] = sValue;
                                    sValue = this.GetValue("forcefit");
                                    nvcTmp["forcefit"] = sValue;
                                    sValue = this.GetValue("set_user_pref_ml");
                                    nvcTmp["set_user_pref_ml"] = sValue;
                                    htGDML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 6 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61779, 6, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 6 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "g_grid_cb":
                            Localtable = (NameValueCollection)htG_GRID_CB[lInstance];
                            break;
                        case "_hdr":
                            Localtable = nvc_HDR;
                            break;
                        case "cb_hdr":
                            Localtable = nvcCB_HDR;
                            break;
                        case "gdml_mlo":
                            Localtable = (NameValueCollection)htGDML_MLO[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_layout_sr_selgsc(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_layout_sr_selgsc(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_layout_sr_selgsc.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

