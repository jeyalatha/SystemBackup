/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_uista_srinit.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_uista_srinit : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htACTDESCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCLSTIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCOLVISMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_ENAMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_SIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_VISMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCTBLNMCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPENABMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPSTISCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPVISMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_COLMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_ENAMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_SIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_VISMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTK_DEFMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTK_FCTMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htUIDESCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        private string modeFlagValue = string.Empty;
        public Cep_uista_srinit()
        {
            base.iEDKESEngineInit("ep_uista_srinit", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htACTDESCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("actdescbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("actdescbseg");
                    this.writer.WriteAttributeString("RecordCount", htACTDESCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htACTDESCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htACTDESCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_activity_descr", System.Convert.ToString(nvcTmp["engg_activity_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("actdescbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCLSTIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("clstidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("clstidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCLSTIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCLSTIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCLSTIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("column_state_id", System.Convert.ToString(nvcTmp["column_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("clstidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCOLVISMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("colvismlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("colvismlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htCOLVISMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCOLVISMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCOLVISMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("column_visible", System.Convert.ToString(nvcTmp["column_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("colvismlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_ENAMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_enamlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_enamlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htCT_ENAMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_ENAMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_ENAMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("control_enable", System.Convert.ToString(nvcTmp["control_enable"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_enamlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_SIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_sidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_sidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCT_SIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_SIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_SIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_ctrl_state_id", System.Convert.ToString(nvcTmp["engg_ctrl_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_sidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_VISMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_vismlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_vismlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htCT_VISMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_VISMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_VISMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("control_visible", System.Convert.ToString(nvcTmp["control_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_vismlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCTBLNMCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ctblnmcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ctblnmcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCTBLNMCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCTBLNMCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCTBLNMCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_column_control", System.Convert.ToString(nvcTmp["engg_column_control"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ctblnmcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPENABMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("penabmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("penabmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htPENABMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPENABMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPENABMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("page_enable", System.Convert.ToString(nvcTmp["page_enable"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("penabmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPSTISCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pstiscbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pstiscbseg");
                    this.writer.WriteAttributeString("RecordCount", htPSTISCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPSTISCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPSTISCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_page_state_id", System.Convert.ToString(nvcTmp["engg_page_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pstiscbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPVISMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pvismlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pvismlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htPVISMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPVISMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPVISMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("page_visible", System.Convert.ToString(nvcTmp["page_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pvismlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_COLMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_colmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_colmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htSC_COLMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSC_COLMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_COLMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("section_collapse", System.Convert.ToString(nvcTmp["section_collapse"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_colmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_ENAMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_enamlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_enamlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htSC_ENAMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSC_ENAMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_ENAMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("section_enable", System.Convert.ToString(nvcTmp["section_enable"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_enamlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_SIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_sidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_sidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htSC_SIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSC_SIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_SIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sec_state_id", System.Convert.ToString(nvcTmp["engg_sec_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_sidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_VISMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_vismlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_vismlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htSC_VISMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSC_VISMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_VISMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("section_visible", System.Convert.ToString(nvcTmp["section_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_vismlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htTK_DEFMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tk_defmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tk_defmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htTK_DEFMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htTK_DEFMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTK_DEFMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("default_task_state", System.Convert.ToString(nvcTmp["default_task_state"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tk_defmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htTK_FCTMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tk_fctmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tk_fctmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htTK_FCTMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htTK_FCTMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTK_FCTMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("focus_control", System.Convert.ToString(nvcTmp["focus_control"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tk_fctmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htUIDESCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("uidescbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("uidescbseg");
                    this.writer.WriteAttributeString("RecordCount", htUIDESCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htUIDESCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htUIDESCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvcTmp["engg_ui_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("uidescbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_component_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_reqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    type = 1;
                    break;
                case "clstidcbseg":
                    type = 1;
                    break;
                case "colvismlcbsg":
                    type = 1;
                    break;
                case "ct_enamlcbsg":
                    type = 1;
                    break;
                case "ct_sidcbseg":
                    type = 1;
                    break;
                case "ct_vismlcbsg":
                    type = 1;
                    break;
                case "ctblnmcbseg":
                    type = 1;
                    break;
                case "penabmlcbsg":
                    type = 1;
                    break;
                case "pstiscbseg":
                    type = 1;
                    break;
                case "pvismlcbsg":
                    type = 1;
                    break;
                case "sc_colmlcbsg":
                    type = 1;
                    break;
                case "sc_enamlcbsg":
                    type = 1;
                    break;
                case "sc_sidcbseg":
                    type = 1;
                    break;
                case "sc_vismlcbsg":
                    type = 1;
                    break;
                case "tk_defmlcbsg":
                    type = 1;
                    break;
                case "tk_fctmlcbsg":
                    type = 1;
                    break;
                case "uidescbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    return htACTDESCBSEG.Count;
                    break;
                case "clstidcbseg":
                    return htCLSTIDCBSEG.Count;
                    break;
                case "colvismlcbsg":
                    return htCOLVISMLCBSG.Count;
                    break;
                case "ct_enamlcbsg":
                    return htCT_ENAMLCBSG.Count;
                    break;
                case "ct_sidcbseg":
                    return htCT_SIDCBSEG.Count;
                    break;
                case "ct_vismlcbsg":
                    return htCT_VISMLCBSG.Count;
                    break;
                case "ctblnmcbseg":
                    return htCTBLNMCBSEG.Count;
                    break;
                case "penabmlcbsg":
                    return htPENABMLCBSG.Count;
                    break;
                case "pstiscbseg":
                    return htPSTISCBSEG.Count;
                    break;
                case "pvismlcbsg":
                    return htPVISMLCBSG.Count;
                    break;
                case "sc_colmlcbsg":
                    return htSC_COLMLCBSG.Count;
                    break;
                case "sc_enamlcbsg":
                    return htSC_ENAMLCBSG.Count;
                    break;
                case "sc_sidcbseg":
                    return htSC_SIDCBSEG.Count;
                    break;
                case "sc_vismlcbsg":
                    return htSC_VISMLCBSG.Count;
                    break;
                case "tk_defmlcbsg":
                    return htTK_DEFMLCBSG.Count;
                    break;
                case "tk_fctmlcbsg":
                    return htTK_FCTMLCBSG.Count;
                    break;
                case "uidescbseg":
                    return htUIDESCBSEG.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    return this.htACTDESCBSEG;
                case "clstidcbseg":
                    return this.htCLSTIDCBSEG;
                case "colvismlcbsg":
                    return this.htCOLVISMLCBSG;
                case "ct_enamlcbsg":
                    return this.htCT_ENAMLCBSG;
                case "ct_sidcbseg":
                    return this.htCT_SIDCBSEG;
                case "ct_vismlcbsg":
                    return this.htCT_VISMLCBSG;
                case "ctblnmcbseg":
                    return this.htCTBLNMCBSEG;
                case "penabmlcbsg":
                    return this.htPENABMLCBSG;
                case "pstiscbseg":
                    return this.htPSTISCBSEG;
                case "pvismlcbsg":
                    return this.htPVISMLCBSG;
                case "sc_colmlcbsg":
                    return this.htSC_COLMLCBSG;
                case "sc_enamlcbsg":
                    return this.htSC_ENAMLCBSG;
                case "sc_sidcbseg":
                    return this.htSC_SIDCBSEG;
                case "sc_vismlcbsg":
                    return this.htSC_VISMLCBSG;
                case "tk_defmlcbsg":
                    return this.htTK_DEFMLCBSG;
                case "tk_fctmlcbsg":
                    return this.htTK_FCTMLCBSG;
                case "uidescbseg":
                    return this.htUIDESCBSEG;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "actdescbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpactdescbseg = (NameValueCollection)htACTDESCBSEG[lnInstNumber];
                        return nvcTmpactdescbseg[szDataItem];
                        break;
                    case "clstidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpclstidcbseg = (NameValueCollection)htCLSTIDCBSEG[lnInstNumber];
                        return nvcTmpclstidcbseg[szDataItem];
                        break;
                    case "colvismlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpcolvismlcbsg = (NameValueCollection)htCOLVISMLCBSG[lnInstNumber];
                        return nvcTmpcolvismlcbsg[szDataItem];
                        break;
                    case "ct_enamlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_enamlcbsg = (NameValueCollection)htCT_ENAMLCBSG[lnInstNumber];
                        return nvcTmpct_enamlcbsg[szDataItem];
                        break;
                    case "ct_sidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_sidcbseg = (NameValueCollection)htCT_SIDCBSEG[lnInstNumber];
                        return nvcTmpct_sidcbseg[szDataItem];
                        break;
                    case "ct_vismlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_vismlcbsg = (NameValueCollection)htCT_VISMLCBSG[lnInstNumber];
                        return nvcTmpct_vismlcbsg[szDataItem];
                        break;
                    case "ctblnmcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpctblnmcbseg = (NameValueCollection)htCTBLNMCBSEG[lnInstNumber];
                        return nvcTmpctblnmcbseg[szDataItem];
                        break;
                    case "penabmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmppenabmlcbsg = (NameValueCollection)htPENABMLCBSG[lnInstNumber];
                        return nvcTmppenabmlcbsg[szDataItem];
                        break;
                    case "pstiscbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmppstiscbseg = (NameValueCollection)htPSTISCBSEG[lnInstNumber];
                        return nvcTmppstiscbseg[szDataItem];
                        break;
                    case "pvismlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmppvismlcbsg = (NameValueCollection)htPVISMLCBSG[lnInstNumber];
                        return nvcTmppvismlcbsg[szDataItem];
                        break;
                    case "sc_colmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_colmlcbsg = (NameValueCollection)htSC_COLMLCBSG[lnInstNumber];
                        return nvcTmpsc_colmlcbsg[szDataItem];
                        break;
                    case "sc_enamlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_enamlcbsg = (NameValueCollection)htSC_ENAMLCBSG[lnInstNumber];
                        return nvcTmpsc_enamlcbsg[szDataItem];
                        break;
                    case "sc_sidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_sidcbseg = (NameValueCollection)htSC_SIDCBSEG[lnInstNumber];
                        return nvcTmpsc_sidcbseg[szDataItem];
                        break;
                    case "sc_vismlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_vismlcbsg = (NameValueCollection)htSC_VISMLCBSG[lnInstNumber];
                        return nvcTmpsc_vismlcbsg[szDataItem];
                        break;
                    case "tk_defmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmptk_defmlcbsg = (NameValueCollection)htTK_DEFMLCBSG[lnInstNumber];
                        return nvcTmptk_defmlcbsg[szDataItem];
                        break;
                    case "tk_fctmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmptk_fctmlcbsg = (NameValueCollection)htTK_FCTMLCBSG[lnInstNumber];
                        return nvcTmptk_fctmlcbsg[szDataItem];
                        break;
                    case "uidescbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpuidescbseg = (NameValueCollection)htUIDESCBSEG[lnInstNumber];
                        return nvcTmpuidescbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_uista_srinit Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_uista_srinit Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitclstid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitclstid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93236, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93236, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCLSTIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("column_state_id");
                                    nvcTmp["column_state_id"] = sValue;
                                    htCLSTIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93236, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 2  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitactdes", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitactdes", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93237, 1, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93237, 1, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htACTDESCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_activity_descr");
                                    nvcTmp["engg_activity_descr"] = sValue;
                                    htACTDESCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93237, 1, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 3  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitctblnm", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitctblnm", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93238, 1, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93238, 1, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCTBLNMCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_column_control");
                                    nvcTmp["engg_column_control"] = sValue;
                                    htCTBLNMCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93238, 1, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 4  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitct_sid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitct_sid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93239, 1, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93239, 1, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_SIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_ctrl_state_id");
                                    nvcTmp["engg_ctrl_state_id"] = sValue;
                                    htCT_SIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93239, 1, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 5  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitpstis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitpstis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93240, 1, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93240, 1, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPSTISCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_page_state_id");
                                    nvcTmp["engg_page_state_id"] = sValue;
                                    htPSTISCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93240, 1, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 6  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitsc_sid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitsc_sid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93241, 1, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93241, 1, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_SIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sec_state_id");
                                    nvcTmp["engg_sec_state_id"] = sValue;
                                    htSC_SIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93241, 1, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 7  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinituides", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinituides", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93242, 1, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93242, 1, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htUIDESCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_ui_descr");
                                    nvcTmp["engg_ui_descr"] = sValue;
                                    htUIDESCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93242, 1, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 8  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitcolvis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitcolvis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93243, 1, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93243, 1, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCOLVISMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("column_visible");
                                    nvcTmp["column_visible"] = sValue;
                                    htCOLVISMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93243, 1, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 9  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitpenab", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitpenab", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93244, 1, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93244, 1, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPENABMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("page_enable");
                                    nvcTmp["page_enable"] = sValue;
                                    htPENABMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93244, 1, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 10  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitpvis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitpvis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93245, 1, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93245, 1, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPVISMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("page_visible");
                                    nvcTmp["page_visible"] = sValue;
                                    htPVISMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93245, 1, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 11  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitct_ena", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitct_ena", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93246, 1, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93246, 1, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_ENAMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("control_enable");
                                    nvcTmp["control_enable"] = sValue;
                                    htCT_ENAMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93246, 1, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 12  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitct_vis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitct_vis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93247, 1, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93247, 1, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_VISMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("control_visible");
                                    nvcTmp["control_visible"] = sValue;
                                    htCT_VISMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93247, 1, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 13  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitsc_col", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitsc_col", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93248, 1, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93248, 1, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_COLMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("section_collapse");
                                    nvcTmp["section_collapse"] = sValue;
                                    htSC_COLMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93248, 1, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 14  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 14;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 14 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitsc_ena", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitsc_ena", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93249, 1, 14);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93249, 1, 14);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_ENAMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("section_enable");
                                    nvcTmp["section_enable"] = sValue;
                                    htSC_ENAMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 14", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93249, 1, 14);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 14 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 15  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 15;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 15 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinitsc_vis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinitsc_vis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93250, 1, 15);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93250, 1, 15);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_VISMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("section_visible");
                                    nvcTmp["section_visible"] = sValue;
                                    htSC_VISMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 15", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93250, 1, 15);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 15 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 16  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 16;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 16 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinittk_def", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinittk_def", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93251, 1, 16);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93251, 1, 16);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTK_DEFMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("default_task_state");
                                    nvcTmp["default_task_state"] = sValue;
                                    htTK_DEFMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 16", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93251, 1, 16);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 16 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 17  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 17;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 17 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtinittk_fct", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spinittk_fct", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93252, 1, 17);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 93252, 1, 17);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTK_FCTMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("focus_control");
                                    nvcTmp["focus_control"] = sValue;
                                    htTK_FCTMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 17", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 93252, 1, 17);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 17 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "actdescbseg":
                            Localtable = (NameValueCollection)htACTDESCBSEG[lInstance];
                            break;
                        case "clstidcbseg":
                            Localtable = (NameValueCollection)htCLSTIDCBSEG[lInstance];
                            break;
                        case "colvismlcbsg":
                            Localtable = (NameValueCollection)htCOLVISMLCBSG[lInstance];
                            break;
                        case "ct_enamlcbsg":
                            Localtable = (NameValueCollection)htCT_ENAMLCBSG[lInstance];
                            break;
                        case "ct_sidcbseg":
                            Localtable = (NameValueCollection)htCT_SIDCBSEG[lInstance];
                            break;
                        case "ct_vismlcbsg":
                            Localtable = (NameValueCollection)htCT_VISMLCBSG[lInstance];
                            break;
                        case "ctblnmcbseg":
                            Localtable = (NameValueCollection)htCTBLNMCBSEG[lInstance];
                            break;
                        case "penabmlcbsg":
                            Localtable = (NameValueCollection)htPENABMLCBSG[lInstance];
                            break;
                        case "pstiscbseg":
                            Localtable = (NameValueCollection)htPSTISCBSEG[lInstance];
                            break;
                        case "pvismlcbsg":
                            Localtable = (NameValueCollection)htPVISMLCBSG[lInstance];
                            break;
                        case "sc_colmlcbsg":
                            Localtable = (NameValueCollection)htSC_COLMLCBSG[lInstance];
                            break;
                        case "sc_enamlcbsg":
                            Localtable = (NameValueCollection)htSC_ENAMLCBSG[lInstance];
                            break;
                        case "sc_sidcbseg":
                            Localtable = (NameValueCollection)htSC_SIDCBSEG[lInstance];
                            break;
                        case "sc_vismlcbsg":
                            Localtable = (NameValueCollection)htSC_VISMLCBSG[lInstance];
                            break;
                        case "tk_defmlcbsg":
                            Localtable = (NameValueCollection)htTK_DEFMLCBSG[lInstance];
                            break;
                        case "tk_fctmlcbsg":
                            Localtable = (NameValueCollection)htTK_FCTMLCBSG[lInstance];
                            break;
                        case "uidescbseg":
                            Localtable = (NameValueCollection)htUIDESCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_uista_srinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_uista_srinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_uista_srinit.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

