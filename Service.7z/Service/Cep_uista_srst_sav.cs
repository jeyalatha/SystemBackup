/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_uista_srst_sav.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_uista_srst_sav : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htCLSTIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_SIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPSTISCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_SIDCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTK_DEFMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcCB_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htCT_GRDML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_GRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG__ML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG__MLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_CML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_CMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_GRDML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSC_GRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htST_GRDML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htST_GRDMLOUT = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTK_GRDML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htTK_GRDMLOUT = new System.Collections.Hashtable();
        private string s_HSEGct_grd_fprowno = "0";
        private string s_HSEGengg_c_fprowno = "0";
        private string s_HSEGengg___fprowno = "0";
        private string s_HSEGsc_grd_fprowno = "0";
        private string s_HSEGst_grd_fprowno = "0";
        private string s_HSEGtk_grd_fprowno = "0";
        private string sENGG_CMLcolumn_sequence = "0";
        private string modeFlagValue = string.Empty;
        public Cep_uista_srst_sav()
        {
            base.iEDKESEngineInit("ep_uista_srst_sav", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htCLSTIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("clstidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("clstidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCLSTIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCLSTIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCLSTIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("column_state_id", System.Convert.ToString(nvcTmp["column_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("clstidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_SIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_sidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_sidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htCT_SIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_SIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_SIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_ctrl_state_id", System.Convert.ToString(nvcTmp["engg_ctrl_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_sidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPSTISCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pstiscbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pstiscbseg");
                    this.writer.WriteAttributeString("RecordCount", htPSTISCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPSTISCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPSTISCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_page_state_id", System.Convert.ToString(nvcTmp["engg_page_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pstiscbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_SIDCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_sidcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_sidcbseg");
                    this.writer.WriteAttributeString("RecordCount", htSC_SIDCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSC_SIDCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_SIDCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sec_state_id", System.Convert.ToString(nvcTmp["engg_sec_state_id"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_sidcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htTK_DEFMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tk_defmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tk_defmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htTK_DEFMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htTK_DEFMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTK_DEFMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("default_task_state", System.Convert.ToString(nvcTmp["default_task_state"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tk_defmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("column_state_descr", System.Convert.ToString(nvc_HSEG["column_state_descr"]));
                    this.writer.WriteAttributeString("column_state_id", System.Convert.ToString(nvc_HSEG["column_state_id"]));
                    this.writer.WriteAttributeString("engg_activity_descr", System.Convert.ToString(nvc_HSEG["engg_activity_descr"]));
                    this.writer.WriteAttributeString("engg_column_control", System.Convert.ToString(nvc_HSEG["engg_column_control"]));
                    this.writer.WriteAttributeString("engg_component_descr", System.Convert.ToString(nvc_HSEG["engg_component_descr"]));
                    this.writer.WriteAttributeString("engg_ctrl_state_descr", System.Convert.ToString(nvc_HSEG["engg_ctrl_state_descr"]));
                    this.writer.WriteAttributeString("engg_ctrl_state_id", System.Convert.ToString(nvc_HSEG["engg_ctrl_state_id"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HSEG["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_page_state_descr", System.Convert.ToString(nvc_HSEG["engg_page_state_descr"]));
                    this.writer.WriteAttributeString("engg_page_state_id", System.Convert.ToString(nvc_HSEG["engg_page_state_id"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HSEG["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HSEG["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_reqno", System.Convert.ToString(nvc_HSEG["engg_reqno"]));
                    this.writer.WriteAttributeString("engg_sec_state_descr", System.Convert.ToString(nvc_HSEG["engg_sec_state_descr"]));
                    this.writer.WriteAttributeString("engg_sec_state_id", System.Convert.ToString(nvc_HSEG["engg_sec_state_id"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HSEG["engg_ui_descr"]));
                    this.writer.WriteAttributeString("hdn_guid", System.Convert.ToString(nvc_HSEG["hdn_guid"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.nvcCB_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cb_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cb_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("column_state_id", System.Convert.ToString(nvcCB_HSEG["column_state_id"]));
                    this.writer.WriteAttributeString("engg_ctrl_state_id", System.Convert.ToString(nvcCB_HSEG["engg_ctrl_state_id"]));
                    this.writer.WriteAttributeString("engg_page_state_id", System.Convert.ToString(nvcCB_HSEG["engg_page_state_id"]));
                    this.writer.WriteAttributeString("engg_sec_state_id", System.Convert.ToString(nvcCB_HSEG["engg_sec_state_id"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("cb_hseg", nvcCB_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_GRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_grdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_grdmlout");
                    this.writer.WriteAttributeString("RecordCount", htCT_GRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCT_GRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_GRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("control_bt_synonym", System.Convert.ToString(nvcTmp["control_bt_synonym"]));
                            this.writer.WriteAttributeString("control_enable", System.Convert.ToString(nvcTmp["control_enable"]));
                            this.writer.WriteAttributeString("control_visible", System.Convert.ToString(nvcTmp["control_visible"]));
                            this.writer.WriteAttributeString("section_name", System.Convert.ToString(nvcTmp["section_name"]));
                            this.writer.WriteAttributeString("stctr_page_name", System.Convert.ToString(nvcTmp["stctr_page_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_grdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG__MLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg__mlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg__mlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG__MLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG__MLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG__MLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("page_enable", System.Convert.ToString(nvcTmp["page_enable"]));
                            this.writer.WriteAttributeString("page_page_name", System.Convert.ToString(nvcTmp["page_page_name"]));
                            this.writer.WriteAttributeString("page_visible", System.Convert.ToString(nvcTmp["page_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg__mlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_CMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_cmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_cmlout");
                    this.writer.WriteAttributeString("RecordCount", htENGG_CMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENGG_CMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_CMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("column_enable", System.Convert.ToString(nvcTmp["column_enable"]));
                            this.writer.WriteAttributeString("column_name", System.Convert.ToString(nvcTmp["column_name"]));
                            this.writer.WriteAttributeString("column_page_name", System.Convert.ToString(nvcTmp["column_page_name"]));
                            this.writer.WriteAttributeString("column_section_name", System.Convert.ToString(nvcTmp["column_section_name"]));
                            this.writer.WriteAttributeString("column_sequence", System.Convert.ToString(nvcTmp["column_sequence"]));
                            this.writer.WriteAttributeString("column_visible", System.Convert.ToString(nvcTmp["column_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_cmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSC_GRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sc_grdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sc_grdmlout");
                    this.writer.WriteAttributeString("RecordCount", htSC_GRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htSC_GRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSC_GRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("section_bt_synonym", System.Convert.ToString(nvcTmp["section_bt_synonym"]));
                            this.writer.WriteAttributeString("section_collapse", System.Convert.ToString(nvcTmp["section_collapse"]));
                            this.writer.WriteAttributeString("section_enable", System.Convert.ToString(nvcTmp["section_enable"]));
                            this.writer.WriteAttributeString("section_page", System.Convert.ToString(nvcTmp["section_page"]));
                            this.writer.WriteAttributeString("section_visible", System.Convert.ToString(nvcTmp["section_visible"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sc_grdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htST_GRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("st_grdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("st_grdmlout");
                    this.writer.WriteAttributeString("RecordCount", htST_GRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htST_GRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htST_GRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("state_description_ml", System.Convert.ToString(nvcTmp["state_description_ml"]));
                            this.writer.WriteAttributeString("state_id_ml", System.Convert.ToString(nvcTmp["state_id_ml"]));
                            this.writer.WriteAttributeString("stdef_hdncustomer", System.Convert.ToString(nvcTmp["stdef_hdncustomer"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("st_grdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htTK_GRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("tk_grdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("tk_grdmlout");
                    this.writer.WriteAttributeString("RecordCount", htTK_GRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htTK_GRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htTK_GRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("default_task_state", System.Convert.ToString(nvcTmp["default_task_state"]));
                            this.writer.WriteAttributeString("focus_control", System.Convert.ToString(nvcTmp["focus_control"]));
                            this.writer.WriteAttributeString("override_state", System.Convert.ToString(nvcTmp["override_state"]));
                            this.writer.WriteAttributeString("sttas_page_name", System.Convert.ToString(nvcTmp["sttas_page_name"]));
                            this.writer.WriteAttributeString("task_description", System.Convert.ToString(nvcTmp["task_description"]));
                            this.writer.WriteAttributeString("task_name", System.Convert.ToString(nvcTmp["task_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("tk_grdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "column_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "column_state_id":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_activity_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_column_control":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ctrl_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ctrl_state_id":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_state_id":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_reqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_state_id":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdn_guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "cb_hseg":
                        switch (DataItem)
                        {
                            case "column_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_activity_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_column_control":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ctrl_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_reqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_state_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdn_guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcCB_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcCB_HSEG[DataItem] = DIValue;
                        return 0;
                    case "ct_grdml":
                        switch (DataItem)
                        {
                            case "control_bt_synonym":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "control_enable":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "control_visible":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "section_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "stctr_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htCT_GRDML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htCT_GRDML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htCT_GRDML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htCT_GRDML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    case "engg__ml":
                        switch (DataItem)
                        {
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "page_enable":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "page_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "page_visible":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htENGG__ML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htENGG__ML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htENGG__ML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htENGG__ML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    case "engg_cml":
                        switch (DataItem)
                        {
                            case "column_enable":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "column_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "column_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "column_section_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "column_sequence":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "column_visible":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htENGG_CML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htENGG_CML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htENGG_CML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htENGG_CML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    case "sc_grdml":
                        switch (DataItem)
                        {
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "section_bt_synonym":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "section_collapse":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "section_enable":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "section_page":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "section_visible":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htSC_GRDML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htSC_GRDML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htSC_GRDML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htSC_GRDML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    case "st_grdml":
                        switch (DataItem)
                        {
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "state_description_ml":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "state_id_ml":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "stdef_hdncustomer":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htST_GRDML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htST_GRDML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htST_GRDML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htST_GRDML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    case "tk_grdml":
                        switch (DataItem)
                        {
                            case "default_task_state":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "focus_control":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "override_state":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "sttas_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "task_description":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "task_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htTK_GRDML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htTK_GRDML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htTK_GRDML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htTK_GRDML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "clstidcbseg":
                    type = 1;
                    break;
                case "ct_sidcbseg":
                    type = 1;
                    break;
                case "pstiscbseg":
                    type = 1;
                    break;
                case "sc_sidcbseg":
                    type = 1;
                    break;
                case "tk_defmlcbsg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "cb_hseg":
                    type = 0;
                    break;
                case "ct_grdml":
                    type = 1;
                    break;
                case "ct_grdmlout":
                    type = 1;
                    break;
                case "engg__ml":
                    type = 1;
                    break;
                case "engg__mlout":
                    type = 1;
                    break;
                case "engg_cml":
                    type = 1;
                    break;
                case "engg_cmlout":
                    type = 1;
                    break;
                case "sc_grdml":
                    type = 1;
                    break;
                case "sc_grdmlout":
                    type = 1;
                    break;
                case "st_grdml":
                    type = 1;
                    break;
                case "st_grdmlout":
                    type = 1;
                    break;
                case "tk_grdml":
                    type = 1;
                    break;
                case "tk_grdmlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "clstidcbseg":
                    return htCLSTIDCBSEG.Count;
                    break;
                case "ct_sidcbseg":
                    return htCT_SIDCBSEG.Count;
                    break;
                case "pstiscbseg":
                    return htPSTISCBSEG.Count;
                    break;
                case "sc_sidcbseg":
                    return htSC_SIDCBSEG.Count;
                    break;
                case "tk_defmlcbsg":
                    return htTK_DEFMLCBSG.Count;
                    break;
                case "ct_grdml":
                    return htCT_GRDML.Count;
                    break;
                case "ct_grdmlout":
                    return htCT_GRDMLOUT.Count;
                    break;
                case "engg__ml":
                    return htENGG__ML.Count;
                    break;
                case "engg__mlout":
                    return htENGG__MLOUT.Count;
                    break;
                case "engg_cml":
                    return htENGG_CML.Count;
                    break;
                case "engg_cmlout":
                    return htENGG_CMLOUT.Count;
                    break;
                case "sc_grdml":
                    return htSC_GRDML.Count;
                    break;
                case "sc_grdmlout":
                    return htSC_GRDMLOUT.Count;
                    break;
                case "st_grdml":
                    return htST_GRDML.Count;
                    break;
                case "st_grdmlout":
                    return htST_GRDMLOUT.Count;
                    break;
                case "tk_grdml":
                    return htTK_GRDML.Count;
                    break;
                case "tk_grdmlout":
                    return htTK_GRDMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "clstidcbseg":
                    return this.htCLSTIDCBSEG;
                case "ct_sidcbseg":
                    return this.htCT_SIDCBSEG;
                case "pstiscbseg":
                    return this.htPSTISCBSEG;
                case "sc_sidcbseg":
                    return this.htSC_SIDCBSEG;
                case "tk_defmlcbsg":
                    return this.htTK_DEFMLCBSG;
                case "ct_grdml":
                    return this.htCT_GRDML;
                case "ct_grdmlout":
                    return this.htCT_GRDMLOUT;
                case "engg__ml":
                    return this.htENGG__ML;
                case "engg__mlout":
                    return this.htENGG__MLOUT;
                case "engg_cml":
                    return this.htENGG_CML;
                case "engg_cmlout":
                    return this.htENGG_CMLOUT;
                case "sc_grdml":
                    return this.htSC_GRDML;
                case "sc_grdmlout":
                    return this.htSC_GRDMLOUT;
                case "st_grdml":
                    return this.htST_GRDML;
                case "st_grdmlout":
                    return this.htST_GRDMLOUT;
                case "tk_grdml":
                    return this.htTK_GRDML;
                case "tk_grdmlout":
                    return this.htTK_GRDMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                case "cb_hseg":
                    return this.nvcCB_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "clstidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpclstidcbseg = (NameValueCollection)htCLSTIDCBSEG[lnInstNumber];
                        return nvcTmpclstidcbseg[szDataItem];
                        break;
                    case "ct_sidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_sidcbseg = (NameValueCollection)htCT_SIDCBSEG[lnInstNumber];
                        return nvcTmpct_sidcbseg[szDataItem];
                        break;
                    case "pstiscbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmppstiscbseg = (NameValueCollection)htPSTISCBSEG[lnInstNumber];
                        return nvcTmppstiscbseg[szDataItem];
                        break;
                    case "sc_sidcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_sidcbseg = (NameValueCollection)htSC_SIDCBSEG[lnInstNumber];
                        return nvcTmpsc_sidcbseg[szDataItem];
                        break;
                    case "tk_defmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmptk_defmlcbsg = (NameValueCollection)htTK_DEFMLCBSG[lnInstNumber];
                        return nvcTmptk_defmlcbsg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "cb_hseg":
                        return nvcCB_HSEG[szDataItem];
                        break;
                    case "ct_grdml":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_grdml = (NameValueCollection)htCT_GRDML[lnInstNumber];
                        return nvcTmpct_grdml[szDataItem];
                        break;
                    case "ct_grdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_grdmlout = (NameValueCollection)htCT_GRDMLOUT[lnInstNumber];
                        return nvcTmpct_grdmlout[szDataItem];
                        break;
                    case "engg__ml":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg__ml = (NameValueCollection)htENGG__ML[lnInstNumber];
                        return nvcTmpengg__ml[szDataItem];
                        break;
                    case "engg__mlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg__mlout = (NameValueCollection)htENGG__MLOUT[lnInstNumber];
                        return nvcTmpengg__mlout[szDataItem];
                        break;
                    case "engg_cml":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_cml = (NameValueCollection)htENGG_CML[lnInstNumber];
                        return nvcTmpengg_cml[szDataItem];
                        break;
                    case "engg_cmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_cmlout = (NameValueCollection)htENGG_CMLOUT[lnInstNumber];
                        return nvcTmpengg_cmlout[szDataItem];
                        break;
                    case "sc_grdml":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_grdml = (NameValueCollection)htSC_GRDML[lnInstNumber];
                        return nvcTmpsc_grdml[szDataItem];
                        break;
                    case "sc_grdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpsc_grdmlout = (NameValueCollection)htSC_GRDMLOUT[lnInstNumber];
                        return nvcTmpsc_grdmlout[szDataItem];
                        break;
                    case "st_grdml":
                        System.Collections.Specialized.NameValueCollection nvcTmpst_grdml = (NameValueCollection)htST_GRDML[lnInstNumber];
                        return nvcTmpst_grdml[szDataItem];
                        break;
                    case "st_grdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpst_grdmlout = (NameValueCollection)htST_GRDMLOUT[lnInstNumber];
                        return nvcTmpst_grdmlout[szDataItem];
                        break;
                    case "tk_grdml":
                        System.Collections.Specialized.NameValueCollection nvcTmptk_grdml = (NameValueCollection)htTK_GRDML[lnInstNumber];
                        return nvcTmptk_grdml[szDataItem];
                        break;
                    case "tk_grdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmptk_grdmlout = (NameValueCollection)htTK_GRDMLOUT[lnInstNumber];
                        return nvcTmptk_grdmlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_uista_srst_sav Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                this.ProcessPS4();
                this.ProcessPS5();
                this.ProcessPS6();
                this.ProcessPS7();
                this.ProcessPS8();
                this.ProcessPS9();
                this.ProcessPS10();
                this.ProcessPS11();
                this.ProcessPS12();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_uista_srst_sav Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_sav");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savhdrsav", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savhdrsav", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106093, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106093, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("ct_grd_fprowno");
                                nvc_HSEG["ct_grd_fprowno"] = sValue;
                                sValue = this.GetValue("engg___fprowno");
                                nvc_HSEG["engg___fprowno"] = sValue;
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                                sValue = this.GetValue("sc_grd_fprowno");
                                nvc_HSEG["sc_grd_fprowno"] = sValue;
                                sValue = this.GetValue("st_grd_fprowno");
                                nvc_HSEG["st_grd_fprowno"] = sValue;
                                sValue = this.GetValue("tk_grd_fprowno");
                                nvc_HSEG["tk_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106093, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS10()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 10;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 10
                // Starting to execute the BR - 1  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbdef");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvcCB_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savcbdef", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savcbdef", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106106, 10, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106106, 10, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("column_state_id");
                                nvcCB_HSEG["column_state_id"] = sValue;
                                sValue = this.GetValue("engg_ctrl_state_id");
                                nvcCB_HSEG["engg_ctrl_state_id"] = sValue;
                                sValue = this.GetValue("engg_page_state_id");
                                nvcCB_HSEG["engg_page_state_id"] = sValue;
                                sValue = this.GetValue("engg_sec_state_id");
                                nvcCB_HSEG["engg_sec_state_id"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106106, 10, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS11()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 11;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 11
                // Starting to execute the BR - 1  under the process section - 11
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 11;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savhpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 11 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savhdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106107, 11, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106107, 11, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("column_state_descr");
                                nvc_HSEG["column_state_descr"] = sValue;
                                sValue = this.GetValue("column_state_id");
                                nvc_HSEG["column_state_id"] = sValue;
                                sValue = this.GetValue("ct_grd_fprowno");
                                nvc_HSEG["ct_grd_fprowno"] = sValue;
                                sValue = this.GetValue("engg___fprowno");
                                nvc_HSEG["engg___fprowno"] = sValue;
                                sValue = this.GetValue("engg_activity_descr");
                                nvc_HSEG["engg_activity_descr"] = sValue;
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                                sValue = this.GetValue("engg_column_control");
                                nvc_HSEG["engg_column_control"] = sValue;
                                sValue = this.GetValue("engg_component_descr");
                                nvc_HSEG["engg_component_descr"] = sValue;
                                sValue = this.GetValue("engg_ctrl_state_descr");
                                nvc_HSEG["engg_ctrl_state_descr"] = sValue;
                                sValue = this.GetValue("engg_ctrl_state_id");
                                nvc_HSEG["engg_ctrl_state_id"] = sValue;
                                sValue = this.GetValue("engg_customer_name");
                                nvc_HSEG["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_page_state_descr");
                                nvc_HSEG["engg_page_state_descr"] = sValue;
                                sValue = this.GetValue("engg_page_state_id");
                                nvc_HSEG["engg_page_state_id"] = sValue;
                                sValue = this.GetValue("engg_process_descr");
                                nvc_HSEG["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name");
                                nvc_HSEG["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_reqno");
                                nvc_HSEG["engg_reqno"] = sValue;
                                sValue = this.GetValue("engg_sec_state_descr");
                                nvc_HSEG["engg_sec_state_descr"] = sValue;
                                sValue = this.GetValue("engg_sec_state_id");
                                nvc_HSEG["engg_sec_state_id"] = sValue;
                                sValue = this.GetValue("engg_ui_descr");
                                nvc_HSEG["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("hdn_guid");
                                nvc_HSEG["hdn_guid"] = sValue;
                                sValue = this.GetValue("sc_grd_fprowno");
                                nvc_HSEG["sc_grd_fprowno"] = sValue;
                                sValue = this.GetValue("st_grd_fprowno");
                                nvc_HSEG["st_grd_fprowno"] = sValue;
                                sValue = this.GetValue("tk_grd_fprowno");
                                nvc_HSEG["tk_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 11 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106107, 11, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 11 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS12()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 12;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 12
                // Starting to execute the BR - 1  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savengg_cmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savengg_cspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106108, 12, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106108, 12, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_CMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("column_enable");
                                    nvcTmp["column_enable"] = sValue;
                                    sValue = this.GetValue("column_name");
                                    nvcTmp["column_name"] = sValue;
                                    sValue = this.GetValue("column_page_name");
                                    nvcTmp["column_page_name"] = sValue;
                                    sValue = this.GetValue("column_section_name");
                                    nvcTmp["column_section_name"] = sValue;
                                    sValue = this.GetValue("column_sequence");
                                    nvcTmp["column_sequence"] = sValue;
                                    sValue = this.GetValue("column_visible");
                                    nvcTmp["column_visible"] = sValue;
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htENGG_CMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106108, 12, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 2  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savengg__mto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savengg__spo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106109, 12, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106109, 12, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG__MLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("page_enable");
                                    nvcTmp["page_enable"] = sValue;
                                    sValue = this.GetValue("page_page_name");
                                    nvcTmp["page_page_name"] = sValue;
                                    sValue = this.GetValue("page_visible");
                                    nvcTmp["page_visible"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htENGG__MLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106109, 12, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 3  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savct_grdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savct_grdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106110, 12, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106110, 12, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_GRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("control_bt_synonym");
                                    nvcTmp["control_bt_synonym"] = sValue;
                                    sValue = this.GetValue("control_enable");
                                    nvcTmp["control_enable"] = sValue;
                                    sValue = this.GetValue("control_visible");
                                    nvcTmp["control_visible"] = sValue;
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("section_name");
                                    nvcTmp["section_name"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("stctr_page_name");
                                    nvcTmp["stctr_page_name"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htCT_GRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106110, 12, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 4  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savsc_grdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savsc_grdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106111, 12, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106111, 12, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_GRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("section_bt_synonym");
                                    nvcTmp["section_bt_synonym"] = sValue;
                                    sValue = this.GetValue("section_collapse");
                                    nvcTmp["section_collapse"] = sValue;
                                    sValue = this.GetValue("section_enable");
                                    nvcTmp["section_enable"] = sValue;
                                    sValue = this.GetValue("section_page");
                                    nvcTmp["section_page"] = sValue;
                                    sValue = this.GetValue("section_visible");
                                    nvcTmp["section_visible"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htSC_GRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106111, 12, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 5  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savtk_grdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savtk_grdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106112, 12, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106112, 12, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTK_GRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("default_task_state");
                                    nvcTmp["default_task_state"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("focus_control");
                                    nvcTmp["focus_control"] = sValue;
                                    sValue = this.GetValue("override_state");
                                    nvcTmp["override_state"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("sttas_page_name");
                                    nvcTmp["sttas_page_name"] = sValue;
                                    sValue = this.GetValue("task_description");
                                    nvcTmp["task_description"] = sValue;
                                    sValue = this.GetValue("task_name");
                                    nvcTmp["task_name"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htTK_GRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106112, 12, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 6  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savst_grdmto", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savst_grdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106113, 12, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106113, 12, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htST_GRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("ct_grd_fprowno");
                                    nvc_HSEG["ct_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("engg___fprowno");
                                    nvc_HSEG["engg___fprowno"] = sValue;
                                    sValue = this.GetValue("engg_c_fprowno");
                                    nvc_HSEG["engg_c_fprowno"] = sValue;
                                    sValue = this.GetValue("sc_grd_fprowno");
                                    nvc_HSEG["sc_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("st_grd_fprowno");
                                    nvc_HSEG["st_grd_fprowno"] = sValue;
                                    sValue = this.GetValue("state_description_ml");
                                    nvcTmp["state_description_ml"] = sValue;
                                    sValue = this.GetValue("state_id_ml");
                                    nvcTmp["state_id_ml"] = sValue;
                                    sValue = this.GetValue("stdef_hdncustomer");
                                    nvcTmp["stdef_hdncustomer"] = sValue;
                                    sValue = this.GetValue("tk_grd_fprowno");
                                    nvc_HSEG["tk_grd_fprowno"] = sValue;
                                    htST_GRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106113, 12, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htENGG_CML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savengg_c");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htENGG_CML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvcTmp["column_enable"];
                            base.Parameters("@column_enable", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["column_name"];
                            base.Parameters("@column_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["column_page_name"];
                            base.Parameters("@column_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["column_section_name"];
                            base.Parameters("@column_section_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["column_sequence"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sENGG_CMLcolumn_sequence = (Double.TryParse(sValue, out result) == true ? sValue : sENGG_CMLcolumn_sequence);
                            base.Parameters("@column_sequence", DBType.Int, 32, sENGG_CMLcolumn_sequence);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["column_visible"];
                            base.Parameters("@column_visible", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savengg_c", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savengg_c", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106094, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106094, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106094, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htENGG__ML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savengg__");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htENGG__ML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvcTmp["page_enable"];
                            base.Parameters("@page_enable", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["page_page_name"];
                            base.Parameters("@page_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["page_visible"];
                            base.Parameters("@page_visible", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savengg__", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savengg__", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106095, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106095, 3, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg___fprowno");
                                nvc_HSEG["engg___fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106095, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS4()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 4;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 4
                // Starting to execute the BR - 1  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htCT_GRDML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savct_grd");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htCT_GRDML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["control_bt_synonym"];
                            base.Parameters("@control_bt_synonym", DBType.NVarchar, 255, sValue);
                            sValue = nvcTmp["control_enable"];
                            base.Parameters("@control_enable", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["control_visible"];
                            base.Parameters("@control_visible", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvcTmp["section_name"];
                            base.Parameters("@section_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["stctr_page_name"];
                            base.Parameters("@stctr_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savct_grd", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savct_grd", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106096, 4, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106096, 4, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("ct_grd_fprowno");
                                nvc_HSEG["ct_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 4 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106096, 4, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS5()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 5;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 5
                // Starting to execute the BR - 1  under the process section - 5
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 5;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htSC_GRDML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savsc_grd");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htSC_GRDML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvcTmp["section_bt_synonym"];
                            base.Parameters("@section_bt_synonym", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["section_collapse"];
                            base.Parameters("@section_collapse", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["section_enable"];
                            base.Parameters("@section_enable", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["section_page"];
                            base.Parameters("@section_page", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["section_visible"];
                            base.Parameters("@section_visible", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 5 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savsc_grd", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savsc_grd", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106097, 5, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106097, 5, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("sc_grd_fprowno");
                                nvc_HSEG["sc_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 5 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106097, 5, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 5 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS6()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 6;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 6
                // Starting to execute the BR - 1  under the process section - 6
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 6;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htTK_GRDML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savtk_grd");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htTK_GRDML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["default_task_state"];
                            base.Parameters("@default_task_state", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["focus_control"];
                            base.Parameters("@focus_control", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvcTmp["override_state"];
                            base.Parameters("@override_state", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["sttas_page_name"];
                            base.Parameters("@sttas_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["task_description"];
                            base.Parameters("@task_description", DBType.NVarchar, 255, sValue);
                            sValue = nvcTmp["task_name"];
                            base.Parameters("@task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 6 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savtk_grd", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savtk_grd", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106098, 6, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106098, 6, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("tk_grd_fprowno");
                                nvc_HSEG["tk_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 6 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106098, 6, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 6 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS7()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 7;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 7
                // Starting to execute the BR - 1  under the process section - 7
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 7;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htST_GRDML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savst_grd");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htST_GRDML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvcTmp["state_description_ml"];
                            base.Parameters("@state_description_ml", DBType.NVarchar, 255, sValue);
                            sValue = nvcTmp["state_id_ml"];
                            base.Parameters("@state_id_ml", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["stdef_hdncustomer"];
                            base.Parameters("@stdef_hdncustomer", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 7 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savst_grd", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savst_grd", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106099, 7, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106099, 7, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("st_grd_fprowno");
                                nvc_HSEG["st_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 7 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106099, 7, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 7 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS8()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 8;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 8
                // Starting to execute the BR - 1  under the process section - 8
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 8;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savhdrchk");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HSEG["ct_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGct_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGct_grd_fprowno);
                            base.Parameters("@ct_grd_fprowno", DBType.Int, 32, s_HSEGct_grd_fprowno);
                            sValue = nvc_HSEG["engg_c_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_c_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_c_fprowno);
                            base.Parameters("@engg_c_fprowno", DBType.Int, 32, s_HSEGengg_c_fprowno);
                            sValue = nvc_HSEG["engg___fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg___fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg___fprowno);
                            base.Parameters("@engg___fprowno", DBType.Int, 32, s_HSEGengg___fprowno);
                            sValue = nvc_HSEG["sc_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGsc_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGsc_grd_fprowno);
                            base.Parameters("@sc_grd_fprowno", DBType.Int, 32, s_HSEGsc_grd_fprowno);
                            sValue = nvc_HSEG["st_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGst_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGst_grd_fprowno);
                            base.Parameters("@st_grd_fprowno", DBType.Int, 32, s_HSEGst_grd_fprowno);
                            sValue = nvc_HSEG["tk_grd_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGtk_grd_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGtk_grd_fprowno);
                            base.Parameters("@tk_grd_fprowno", DBType.Int, 32, s_HSEGtk_grd_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 8 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savhdrchk", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savhdrchk", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106100, 8, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106100, 8, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("ct_grd_fprowno");
                                nvc_HSEG["ct_grd_fprowno"] = sValue;
                                sValue = this.GetValue("engg___fprowno");
                                nvc_HSEG["engg___fprowno"] = sValue;
                                sValue = this.GetValue("engg_c_fprowno");
                                nvc_HSEG["engg_c_fprowno"] = sValue;
                                sValue = this.GetValue("sc_grd_fprowno");
                                nvc_HSEG["sc_grd_fprowno"] = sValue;
                                sValue = this.GetValue("st_grd_fprowno");
                                nvc_HSEG["st_grd_fprowno"] = sValue;
                                sValue = this.GetValue("tk_grd_fprowno");
                                nvc_HSEG["tk_grd_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 8 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106100, 8, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 8 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS9()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 9;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 9
                // Starting to execute the BR - 1  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savclstid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savclstid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106101, 9, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106101, 9, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCLSTIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("column_state_id");
                                    nvcTmp["column_state_id"] = sValue;
                                    htCLSTIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 9 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106101, 9, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 9
                // Starting to execute the BR - 2  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savct_sid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savct_sid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106102, 9, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106102, 9, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_SIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_ctrl_state_id");
                                    nvcTmp["engg_ctrl_state_id"] = sValue;
                                    htCT_SIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 9 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106102, 9, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 9
                // Starting to execute the BR - 3  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savpstis", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savpstis", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106103, 9, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106103, 9, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPSTISCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_page_state_id");
                                    nvcTmp["engg_page_state_id"] = sValue;
                                    htPSTISCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 9 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106103, 9, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 9
                // Starting to execute the BR - 4  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savsc_sid", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savsc_sid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106104, 9, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106104, 9, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSC_SIDCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sec_state_id");
                                    nvcTmp["engg_sec_state_id"] = sValue;
                                    htSC_SIDCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 9 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106104, 9, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 9
                // Starting to execute the BR - 5  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psst_savcbld");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["column_state_descr"];
                            base.Parameters("@column_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["column_state_id"];
                            base.Parameters("@column_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_descr"];
                            base.Parameters("@engg_activity_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_column_control"];
                            base.Parameters("@engg_column_control", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_component_descr"];
                            base.Parameters("@engg_component_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_descr"];
                            base.Parameters("@engg_ctrl_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ctrl_state_id"];
                            base.Parameters("@engg_ctrl_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_page_state_descr"];
                            base.Parameters("@engg_page_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_page_state_id"];
                            base.Parameters("@engg_page_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_reqno"];
                            base.Parameters("@engg_reqno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_sec_state_descr"];
                            base.Parameters("@engg_sec_state_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_sec_state_id"];
                            base.Parameters("@engg_sec_state_id", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["hdn_guid"];
                            base.Parameters("@hdn_guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_uista_mtst_savtk_def", nLoop, nMax));
                        base.Execute_SP(true, "ep_uista_spst_savtk_def", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106105, 9, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 106105, 9, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htTK_DEFMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("default_task_state");
                                    nvcTmp["default_task_state"] = sValue;
                                    htTK_DEFMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 9 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 106105, 9, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "clstidcbseg":
                            Localtable = (NameValueCollection)htCLSTIDCBSEG[lInstance];
                            break;
                        case "ct_sidcbseg":
                            Localtable = (NameValueCollection)htCT_SIDCBSEG[lInstance];
                            break;
                        case "pstiscbseg":
                            Localtable = (NameValueCollection)htPSTISCBSEG[lInstance];
                            break;
                        case "sc_sidcbseg":
                            Localtable = (NameValueCollection)htSC_SIDCBSEG[lInstance];
                            break;
                        case "tk_defmlcbsg":
                            Localtable = (NameValueCollection)htTK_DEFMLCBSG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "cb_hseg":
                            Localtable = nvcCB_HSEG;
                            break;
                        case "ct_grdml":
                            Localtable = (NameValueCollection)htCT_GRDML[lInstance];
                            break;
                        case "ct_grdmlout":
                            Localtable = (NameValueCollection)htCT_GRDMLOUT[lInstance];
                            break;
                        case "engg__ml":
                            Localtable = (NameValueCollection)htENGG__ML[lInstance];
                            break;
                        case "engg__mlout":
                            Localtable = (NameValueCollection)htENGG__MLOUT[lInstance];
                            break;
                        case "engg_cml":
                            Localtable = (NameValueCollection)htENGG_CML[lInstance];
                            break;
                        case "engg_cmlout":
                            Localtable = (NameValueCollection)htENGG_CMLOUT[lInstance];
                            break;
                        case "sc_grdml":
                            Localtable = (NameValueCollection)htSC_GRDML[lInstance];
                            break;
                        case "sc_grdmlout":
                            Localtable = (NameValueCollection)htSC_GRDMLOUT[lInstance];
                            break;
                        case "st_grdml":
                            Localtable = (NameValueCollection)htST_GRDML[lInstance];
                            break;
                        case "st_grdmlout":
                            Localtable = (NameValueCollection)htST_GRDMLOUT[lInstance];
                            break;
                        case "tk_grdml":
                            Localtable = (NameValueCollection)htTK_GRDML[lInstance];
                            break;
                        case "tk_grdmlout":
                            Localtable = (NameValueCollection)htTK_GRDMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_uista_srst_sav(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_uista_srst_sav(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_uista_srst_sav.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

