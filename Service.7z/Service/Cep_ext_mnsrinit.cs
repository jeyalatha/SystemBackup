/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_ext_mnsrinit.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_ext_mnsrinit : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htACTDESCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCTRLTYCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_CMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_FMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_RMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGG_WMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGATMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGCTCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGN_MLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGOLCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGSECBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGTLMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGTNMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGUPMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENGGVWMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htHDNCOMCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPAGECBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htUIDESCCBSEG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        private string modeFlagValue = string.Empty;
        public Cep_ext_mnsrinit()
        {
            base.iEDKESEngineInit("ep_ext_mnsrinit", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htACTDESCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("actdescbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("actdescbseg");
                    this.writer.WriteAttributeString("RecordCount", htACTDESCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htACTDESCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htACTDESCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvcTmp["engg_act_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("actdescbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCTRLTYCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ctrltycbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ctrltycbseg");
                    this.writer.WriteAttributeString("RecordCount", htCTRLTYCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCTRLTYCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCTRLTYCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_controltype", System.Convert.ToString(nvcTmp["engg_controltype"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ctrltycbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_CMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_cmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_cmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_CMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_CMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_CMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_sec_rvwtask", System.Convert.ToString(nvcTmp["engg_extn_sec_rvwtask"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_cmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_FMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_fmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_fmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_FMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_FMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_FMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_groupfun", System.Convert.ToString(nvcTmp["engg_seccol_groupfun"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_fmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_RMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_rmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_rmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_RMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_RMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_RMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_sec_scr_behavior", System.Convert.ToString(nvcTmp["engg_extn_sec_scr_behavior"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_rmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGG_WMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("engg_wmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("engg_wmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGG_WMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGG_WMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGG_WMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_ctl_rvwtask", System.Convert.ToString(nvcTmp["engg_extn_ctl_rvwtask"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("engg_wmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGATMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggatmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggatmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGATMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGATMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGATMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_datatype", System.Convert.ToString(nvcTmp["engg_seccol_datatype"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggatmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGCTCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggctcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggctcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGCTCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGCTCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGCTCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_ctl_section", System.Convert.ToString(nvcTmp["engg_extn_ctl_section"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggctcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGN_MLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggn_mlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggn_mlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGN_MLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGN_MLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGN_MLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_ctl_direction", System.Convert.ToString(nvcTmp["engg_extn_ctl_direction"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggn_mlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGOLCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggolcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggolcbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGOLCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGOLCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGOLCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_control", System.Convert.ToString(nvcTmp["engg_seccol_control"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggolcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGSECBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggsecbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggsecbseg");
                    this.writer.WriteAttributeString("RecordCount", htENGGSECBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGSECBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGSECBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_section", System.Convert.ToString(nvcTmp["engg_seccol_section"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggsecbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGTLMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggtlmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggtlmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGTLMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGTLMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGTLMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_ctl_fade_dir", System.Convert.ToString(nvcTmp["engg_extn_ctl_fade_dir"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggtlmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGTNMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggtnmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggtnmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGTNMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGTNMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGTNMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_extn_sec_typedir", System.Convert.ToString(nvcTmp["engg_extn_sec_typedir"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggtnmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGUPMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggupmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggupmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGUPMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGUPMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGUPMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_grouping", System.Convert.ToString(nvcTmp["engg_seccol_grouping"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggupmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENGGVWMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enggvwmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enggvwmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htENGGVWMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htENGGVWMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENGGVWMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_seccol_rvwtask", System.Convert.ToString(nvcTmp["engg_seccol_rvwtask"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enggvwmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htHDNCOMCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("hdncomcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("hdncomcbseg");
                    this.writer.WriteAttributeString("RecordCount", htHDNCOMCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htHDNCOMCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htHDNCOMCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("hdncombo", System.Convert.ToString(nvcTmp["hdncombo"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("hdncomcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPAGECBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pagecbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pagecbseg");
                    this.writer.WriteAttributeString("RecordCount", htPAGECBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPAGECBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPAGECBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_pagename", System.Convert.ToString(nvcTmp["engg_pagename"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pagecbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htUIDESCCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("uidesccbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("uidesccbseg");
                    this.writer.WriteAttributeString("RecordCount", htUIDESCCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htUIDESCCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htUIDESCCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvcTmp["engg_ui_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("uidesccbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    type = 1;
                    break;
                case "ctrltycbseg":
                    type = 1;
                    break;
                case "engg_cmlcbsg":
                    type = 1;
                    break;
                case "engg_fmlcbsg":
                    type = 1;
                    break;
                case "engg_rmlcbsg":
                    type = 1;
                    break;
                case "engg_wmlcbsg":
                    type = 1;
                    break;
                case "enggatmlcbsg":
                    type = 1;
                    break;
                case "enggctcbseg":
                    type = 1;
                    break;
                case "enggn_mlcbsg":
                    type = 1;
                    break;
                case "enggolcbseg":
                    type = 1;
                    break;
                case "enggsecbseg":
                    type = 1;
                    break;
                case "enggtlmlcbsg":
                    type = 1;
                    break;
                case "enggtnmlcbsg":
                    type = 1;
                    break;
                case "enggupmlcbsg":
                    type = 1;
                    break;
                case "enggvwmlcbsg":
                    type = 1;
                    break;
                case "hdncomcbseg":
                    type = 1;
                    break;
                case "pagecbseg":
                    type = 1;
                    break;
                case "uidesccbseg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    return htACTDESCBSEG.Count;
                    break;
                case "ctrltycbseg":
                    return htCTRLTYCBSEG.Count;
                    break;
                case "engg_cmlcbsg":
                    return htENGG_CMLCBSG.Count;
                    break;
                case "engg_fmlcbsg":
                    return htENGG_FMLCBSG.Count;
                    break;
                case "engg_rmlcbsg":
                    return htENGG_RMLCBSG.Count;
                    break;
                case "engg_wmlcbsg":
                    return htENGG_WMLCBSG.Count;
                    break;
                case "enggatmlcbsg":
                    return htENGGATMLCBSG.Count;
                    break;
                case "enggctcbseg":
                    return htENGGCTCBSEG.Count;
                    break;
                case "enggn_mlcbsg":
                    return htENGGN_MLCBSG.Count;
                    break;
                case "enggolcbseg":
                    return htENGGOLCBSEG.Count;
                    break;
                case "enggsecbseg":
                    return htENGGSECBSEG.Count;
                    break;
                case "enggtlmlcbsg":
                    return htENGGTLMLCBSG.Count;
                    break;
                case "enggtnmlcbsg":
                    return htENGGTNMLCBSG.Count;
                    break;
                case "enggupmlcbsg":
                    return htENGGUPMLCBSG.Count;
                    break;
                case "enggvwmlcbsg":
                    return htENGGVWMLCBSG.Count;
                    break;
                case "hdncomcbseg":
                    return htHDNCOMCBSEG.Count;
                    break;
                case "pagecbseg":
                    return htPAGECBSEG.Count;
                    break;
                case "uidesccbseg":
                    return htUIDESCCBSEG.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "actdescbseg":
                    return this.htACTDESCBSEG;
                case "ctrltycbseg":
                    return this.htCTRLTYCBSEG;
                case "engg_cmlcbsg":
                    return this.htENGG_CMLCBSG;
                case "engg_fmlcbsg":
                    return this.htENGG_FMLCBSG;
                case "engg_rmlcbsg":
                    return this.htENGG_RMLCBSG;
                case "engg_wmlcbsg":
                    return this.htENGG_WMLCBSG;
                case "enggatmlcbsg":
                    return this.htENGGATMLCBSG;
                case "enggctcbseg":
                    return this.htENGGCTCBSEG;
                case "enggn_mlcbsg":
                    return this.htENGGN_MLCBSG;
                case "enggolcbseg":
                    return this.htENGGOLCBSEG;
                case "enggsecbseg":
                    return this.htENGGSECBSEG;
                case "enggtlmlcbsg":
                    return this.htENGGTLMLCBSG;
                case "enggtnmlcbsg":
                    return this.htENGGTNMLCBSG;
                case "enggupmlcbsg":
                    return this.htENGGUPMLCBSG;
                case "enggvwmlcbsg":
                    return this.htENGGVWMLCBSG;
                case "hdncomcbseg":
                    return this.htHDNCOMCBSEG;
                case "pagecbseg":
                    return this.htPAGECBSEG;
                case "uidesccbseg":
                    return this.htUIDESCCBSEG;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "actdescbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpactdescbseg = (NameValueCollection)htACTDESCBSEG[lnInstNumber];
                        return nvcTmpactdescbseg[szDataItem];
                        break;
                    case "ctrltycbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpctrltycbseg = (NameValueCollection)htCTRLTYCBSEG[lnInstNumber];
                        return nvcTmpctrltycbseg[szDataItem];
                        break;
                    case "engg_cmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_cmlcbsg = (NameValueCollection)htENGG_CMLCBSG[lnInstNumber];
                        return nvcTmpengg_cmlcbsg[szDataItem];
                        break;
                    case "engg_fmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_fmlcbsg = (NameValueCollection)htENGG_FMLCBSG[lnInstNumber];
                        return nvcTmpengg_fmlcbsg[szDataItem];
                        break;
                    case "engg_rmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_rmlcbsg = (NameValueCollection)htENGG_RMLCBSG[lnInstNumber];
                        return nvcTmpengg_rmlcbsg[szDataItem];
                        break;
                    case "engg_wmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpengg_wmlcbsg = (NameValueCollection)htENGG_WMLCBSG[lnInstNumber];
                        return nvcTmpengg_wmlcbsg[szDataItem];
                        break;
                    case "enggatmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggatmlcbsg = (NameValueCollection)htENGGATMLCBSG[lnInstNumber];
                        return nvcTmpenggatmlcbsg[szDataItem];
                        break;
                    case "enggctcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggctcbseg = (NameValueCollection)htENGGCTCBSEG[lnInstNumber];
                        return nvcTmpenggctcbseg[szDataItem];
                        break;
                    case "enggn_mlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggn_mlcbsg = (NameValueCollection)htENGGN_MLCBSG[lnInstNumber];
                        return nvcTmpenggn_mlcbsg[szDataItem];
                        break;
                    case "enggolcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggolcbseg = (NameValueCollection)htENGGOLCBSEG[lnInstNumber];
                        return nvcTmpenggolcbseg[szDataItem];
                        break;
                    case "enggsecbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggsecbseg = (NameValueCollection)htENGGSECBSEG[lnInstNumber];
                        return nvcTmpenggsecbseg[szDataItem];
                        break;
                    case "enggtlmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggtlmlcbsg = (NameValueCollection)htENGGTLMLCBSG[lnInstNumber];
                        return nvcTmpenggtlmlcbsg[szDataItem];
                        break;
                    case "enggtnmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggtnmlcbsg = (NameValueCollection)htENGGTNMLCBSG[lnInstNumber];
                        return nvcTmpenggtnmlcbsg[szDataItem];
                        break;
                    case "enggupmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggupmlcbsg = (NameValueCollection)htENGGUPMLCBSG[lnInstNumber];
                        return nvcTmpenggupmlcbsg[szDataItem];
                        break;
                    case "enggvwmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmpenggvwmlcbsg = (NameValueCollection)htENGGVWMLCBSG[lnInstNumber];
                        return nvcTmpenggvwmlcbsg[szDataItem];
                        break;
                    case "hdncomcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmphdncomcbseg = (NameValueCollection)htHDNCOMCBSEG[lnInstNumber];
                        return nvcTmphdncomcbseg[szDataItem];
                        break;
                    case "pagecbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmppagecbseg = (NameValueCollection)htPAGECBSEG[lnInstNumber];
                        return nvcTmppagecbseg[szDataItem];
                        break;
                    case "uidesccbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpuidesccbseg = (NameValueCollection)htUIDESCCBSEG[lnInstNumber];
                        return nvcTmpuidesccbseg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_ext_mnsrinit Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_ext_mnsrinit Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitactdes", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitactdes", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94256, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94256, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htACTDESCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_act_descr");
                                    nvcTmp["engg_act_descr"] = sValue;
                                    htACTDESCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94256, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 2  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitctrlty", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitctrlty", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94257, 1, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94257, 1, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCTRLTYCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_controltype");
                                    nvcTmp["engg_controltype"] = sValue;
                                    htCTRLTYCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94257, 1, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 3  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggct", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggct", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94258, 1, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94258, 1, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGCTCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_ctl_section");
                                    nvcTmp["engg_extn_ctl_section"] = sValue;
                                    htENGGCTCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94258, 1, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 4  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitpage", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitpage", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94259, 1, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94259, 1, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPAGECBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_pagename");
                                    nvcTmp["engg_pagename"] = sValue;
                                    htPAGECBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94259, 1, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 5  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggol", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggol", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94260, 1, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94260, 1, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGOLCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_control");
                                    nvcTmp["engg_seccol_control"] = sValue;
                                    htENGGOLCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94260, 1, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 6  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggse", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggse", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94261, 1, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94261, 1, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGSECBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_section");
                                    nvcTmp["engg_seccol_section"] = sValue;
                                    htENGGSECBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94261, 1, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 7  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinituidesc", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinituidesc", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94262, 1, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94262, 1, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htUIDESCCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_ui_descr");
                                    nvcTmp["engg_ui_descr"] = sValue;
                                    htUIDESCCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94262, 1, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 8  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinithdncom", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinithdncom", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94263, 1, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94263, 1, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htHDNCOMCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("hdncombo");
                                    nvcTmp["hdncombo"] = sValue;
                                    htHDNCOMCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94263, 1, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 9  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggn_", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggn_", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94264, 1, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94264, 1, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGN_MLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_ctl_direction");
                                    nvcTmp["engg_extn_ctl_direction"] = sValue;
                                    htENGGN_MLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94264, 1, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 10  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggtl", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggtl", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94265, 1, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94265, 1, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGTLMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_ctl_fade_dir");
                                    nvcTmp["engg_extn_ctl_fade_dir"] = sValue;
                                    htENGGTLMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94265, 1, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 11  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitengg_w", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitengg_w", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94266, 1, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94266, 1, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_WMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_ctl_rvwtask");
                                    nvcTmp["engg_extn_ctl_rvwtask"] = sValue;
                                    htENGG_WMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94266, 1, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 12  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitengg_c", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitengg_c", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94267, 1, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94267, 1, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_CMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_sec_rvwtask");
                                    nvcTmp["engg_extn_sec_rvwtask"] = sValue;
                                    htENGG_CMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94267, 1, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 13  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitengg_r", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitengg_r", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94268, 1, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94268, 1, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_RMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_sec_scr_behavior");
                                    nvcTmp["engg_extn_sec_scr_behavior"] = sValue;
                                    htENGG_RMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94268, 1, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 14  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 14;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 14 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggtn", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggtn", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94269, 1, 14);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94269, 1, 14);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGTNMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_extn_sec_typedir");
                                    nvcTmp["engg_extn_sec_typedir"] = sValue;
                                    htENGGTNMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 14", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94269, 1, 14);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 14 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 15  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 15;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 15 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggat", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggat", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94270, 1, 15);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94270, 1, 15);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGATMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_datatype");
                                    nvcTmp["engg_seccol_datatype"] = sValue;
                                    htENGGATMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 15", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94270, 1, 15);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 15 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 16  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 16;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 16 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitengg_f", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitengg_f", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94271, 1, 16);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94271, 1, 16);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGG_FMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_groupfun");
                                    nvcTmp["engg_seccol_groupfun"] = sValue;
                                    htENGG_FMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 16", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94271, 1, 16);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 16 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 17  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 17;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 17 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggup", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggup", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94272, 1, 17);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94272, 1, 17);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGUPMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_grouping");
                                    nvcTmp["engg_seccol_grouping"] = sValue;
                                    htENGGUPMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 17", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94272, 1, 17);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 17 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 18  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 18;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 18 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_ext_mnmtinitenggvw", nLoop, nMax));
                        base.Execute_SP(true, "ep_ext_mnspinitenggvw", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94273, 1, 18);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 94273, 1, 18);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENGGVWMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_seccol_rvwtask");
                                    nvcTmp["engg_seccol_rvwtask"] = sValue;
                                    htENGGVWMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 18", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 94273, 1, 18);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 18 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "actdescbseg":
                            Localtable = (NameValueCollection)htACTDESCBSEG[lInstance];
                            break;
                        case "ctrltycbseg":
                            Localtable = (NameValueCollection)htCTRLTYCBSEG[lInstance];
                            break;
                        case "engg_cmlcbsg":
                            Localtable = (NameValueCollection)htENGG_CMLCBSG[lInstance];
                            break;
                        case "engg_fmlcbsg":
                            Localtable = (NameValueCollection)htENGG_FMLCBSG[lInstance];
                            break;
                        case "engg_rmlcbsg":
                            Localtable = (NameValueCollection)htENGG_RMLCBSG[lInstance];
                            break;
                        case "engg_wmlcbsg":
                            Localtable = (NameValueCollection)htENGG_WMLCBSG[lInstance];
                            break;
                        case "enggatmlcbsg":
                            Localtable = (NameValueCollection)htENGGATMLCBSG[lInstance];
                            break;
                        case "enggctcbseg":
                            Localtable = (NameValueCollection)htENGGCTCBSEG[lInstance];
                            break;
                        case "enggn_mlcbsg":
                            Localtable = (NameValueCollection)htENGGN_MLCBSG[lInstance];
                            break;
                        case "enggolcbseg":
                            Localtable = (NameValueCollection)htENGGOLCBSEG[lInstance];
                            break;
                        case "enggsecbseg":
                            Localtable = (NameValueCollection)htENGGSECBSEG[lInstance];
                            break;
                        case "enggtlmlcbsg":
                            Localtable = (NameValueCollection)htENGGTLMLCBSG[lInstance];
                            break;
                        case "enggtnmlcbsg":
                            Localtable = (NameValueCollection)htENGGTNMLCBSG[lInstance];
                            break;
                        case "enggupmlcbsg":
                            Localtable = (NameValueCollection)htENGGUPMLCBSG[lInstance];
                            break;
                        case "enggvwmlcbsg":
                            Localtable = (NameValueCollection)htENGGVWMLCBSG[lInstance];
                            break;
                        case "hdncomcbseg":
                            Localtable = (NameValueCollection)htHDNCOMCBSEG[lInstance];
                            break;
                        case "pagecbseg":
                            Localtable = (NameValueCollection)htPAGECBSEG[lInstance];
                            break;
                        case "uidesccbseg":
                            Localtable = (NameValueCollection)htUIDESCCBSEG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_ext_mnsrinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_ext_mnsrinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_ext_mnsrinit.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

