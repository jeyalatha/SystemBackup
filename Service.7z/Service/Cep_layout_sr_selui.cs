/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_layout_sr_selui.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_layout_sr_selui : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htCT_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htCT_SEC_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htEN_BTS_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htEN_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htEN_SEC_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htG_GRID_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGD_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGD_SEC_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGRPCT_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGRPGRP_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGRPPG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGRPSC_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLAY_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLNK_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPARSEC_MCB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRD_BTS_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRD_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRD_SEC_CB = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSEC_PG_CB = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcCB_HDR = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htCNML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htENML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGDML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htGRPML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLNKML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLYML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPGML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRDML_MLO = new System.Collections.Hashtable();
        public System.Collections.Hashtable htSCML_MLO = new System.Collections.Hashtable();
        private string s_HDRengg_tab_height = "0";
        private string sCB_HDRengg_tab_height = "0";
        private string s_HDRengg_group_seqno = "0";
        private string s_HDRengg_toptb = "0";
        private string s_HDRengg_bottomtb = "0";
        private string s_HDRengg_lefttb = "0";
        private string s_HDRengg_righttb = "0";
        private string s_HDRengg_att_sidebar = "0";
        private string s_HDRfprowno = "0";
        private string modeFlagValue = string.Empty;
        public Cep_layout_sr_selui()
        {
            base.iEDKESEngineInit("ep_layout_sr_selui", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htCT_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htCT_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvcTmp["engg_cont_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htCT_SEC_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("ct_sec_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("ct_sec_cb");
                    this.writer.WriteAttributeString("RecordCount", htCT_SEC_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htCT_SEC_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCT_SEC_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_cont_sec_bts", System.Convert.ToString(nvcTmp["engg_cont_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("ct_sec_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htEN_BTS_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("en_bts_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("en_bts_cb");
                    this.writer.WriteAttributeString("RecordCount", htEN_BTS_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htEN_BTS_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htEN_BTS_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_btsynname", System.Convert.ToString(nvcTmp["engg_enum_btsynname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("en_bts_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htEN_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("en_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("en_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htEN_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htEN_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htEN_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvcTmp["engg_enum_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("en_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htEN_SEC_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("en_sec_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("en_sec_cb");
                    this.writer.WriteAttributeString("RecordCount", htEN_SEC_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htEN_SEC_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htEN_SEC_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_enum_sec_bts", System.Convert.ToString(nvcTmp["engg_enum_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("en_sec_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htG_GRID_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("g_grid_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("g_grid_cb");
                    this.writer.WriteAttributeString("RecordCount", htG_GRID_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htG_GRID_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htG_GRID_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvcTmp["engg_grid_grid_code"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("g_grid_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGD_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("gd_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("gd_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htGD_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGD_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGD_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvcTmp["engg_grid_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("gd_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGD_SEC_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("gd_sec_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("gd_sec_cb");
                    this.writer.WriteAttributeString("RecordCount", htGD_SEC_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGD_SEC_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGD_SEC_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_grid_sec_bts", System.Convert.ToString(nvcTmp["engg_grid_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("gd_sec_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGRPCT_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("grpct_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("grpct_cb");
                    this.writer.WriteAttributeString("RecordCount", htGRPCT_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGRPCT_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGRPCT_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvcTmp["engg_control_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("grpct_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGRPGRP_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("grpgrp_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("grpgrp_cb");
                    this.writer.WriteAttributeString("RecordCount", htGRPGRP_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGRPGRP_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGRPGRP_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvcTmp["engg_group_caption"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("grpgrp_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGRPPG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("grppg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("grppg_cb");
                    this.writer.WriteAttributeString("RecordCount", htGRPPG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGRPPG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGRPPG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvcTmp["engg_page_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("grppg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGRPSC_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("grpsc_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("grpsc_cb");
                    this.writer.WriteAttributeString("RecordCount", htGRPSC_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htGRPSC_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGRPSC_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvcTmp["engg_sect_name"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("grpsc_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLAY_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lay_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lay_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htLAY_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLAY_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLAY_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvcTmp["engg_lay_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lay_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLNK_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lnk_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lnk_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htLNK_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLNK_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLNK_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvcTmp["engg_lnk_page_descr"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lnk_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPARSEC_MCB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("parsec_mcb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("parsec_mcb");
                    this.writer.WriteAttributeString("RecordCount", htPARSEC_MCB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPARSEC_MCB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPARSEC_MCB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_lay_parent_sec", System.Convert.ToString(nvcTmp["engg_lay_parent_sec"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("parsec_mcb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRD_BTS_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rd_bts_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rd_bts_cb");
                    this.writer.WriteAttributeString("RecordCount", htRD_BTS_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRD_BTS_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRD_BTS_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_btsynname", System.Convert.ToString(nvcTmp["engg_radio_btsynname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rd_bts_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRD_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rd_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rd_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htRD_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRD_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRD_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvcTmp["engg_radio_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rd_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRD_SEC_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rd_sec_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rd_sec_cb");
                    this.writer.WriteAttributeString("RecordCount", htRD_SEC_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRD_SEC_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRD_SEC_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_radio_sec_bts", System.Convert.ToString(nvcTmp["engg_radio_sec_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rd_sec_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSEC_PG_CB != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("sec_pg_cb", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("sec_pg_cb");
                    this.writer.WriteAttributeString("RecordCount", htSEC_PG_CB.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htSEC_PG_CB.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSEC_PG_CB[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvcTmp["engg_sec_page_bts"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("sec_pg_cb", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HDR != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hdr", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hdr");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("_txt_interfacecontrol", System.Convert.ToString(nvc_HDR["_txt_interfacecontrol"]));
                    this.writer.WriteAttributeString("engg_act_descr", System.Convert.ToString(nvc_HDR["engg_act_descr"]));
                    this.writer.WriteAttributeString("engg_att_docked", System.Convert.ToString(nvc_HDR["engg_att_docked"]));
                    this.writer.WriteAttributeString("engg_att_sidebar", System.Convert.ToString(nvc_HDR["engg_att_sidebar"]));
                    this.writer.WriteAttributeString("engg_att_ui_cap_align", System.Convert.ToString(nvc_HDR["engg_att_ui_cap_align"]));
                    this.writer.WriteAttributeString("engg_att_ui_format", System.Convert.ToString(nvc_HDR["engg_att_ui_format"]));
                    this.writer.WriteAttributeString("engg_att_ui_grid_type", System.Convert.ToString(nvc_HDR["engg_att_ui_grid_type"]));
                    this.writer.WriteAttributeString("engg_att_ui_trail_bar", System.Convert.ToString(nvc_HDR["engg_att_ui_trail_bar"]));
                    this.writer.WriteAttributeString("engg_att_ui_type", System.Convert.ToString(nvc_HDR["engg_att_ui_type"]));
                    this.writer.WriteAttributeString("engg_bottomtb", System.Convert.ToString(nvc_HDR["engg_bottomtb"]));
                    this.writer.WriteAttributeString("engg_callout_type", System.Convert.ToString(nvc_HDR["engg_callout_type"]));
                    this.writer.WriteAttributeString("engg_component", System.Convert.ToString(nvc_HDR["engg_component"]));
                    this.writer.WriteAttributeString("engg_cont_sec_type_bts", System.Convert.ToString(nvc_HDR["engg_cont_sec_type_bts"]));
                    this.writer.WriteAttributeString("engg_control_name", System.Convert.ToString(nvc_HDR["engg_control_name"]));
                    this.writer.WriteAttributeString("engg_customer_name", System.Convert.ToString(nvc_HDR["engg_customer_name"]));
                    this.writer.WriteAttributeString("engg_desk_brw", System.Convert.ToString(nvc_HDR["engg_desk_brw"]));
                    this.writer.WriteAttributeString("engg_grid_ctrl_type_bts", System.Convert.ToString(nvc_HDR["engg_grid_ctrl_type_bts"]));
                    this.writer.WriteAttributeString("engg_grid_sec_type_bts", System.Convert.ToString(nvc_HDR["engg_grid_sec_type_bts"]));
                    this.writer.WriteAttributeString("engg_group_caption", System.Convert.ToString(nvc_HDR["engg_group_caption"]));
                    this.writer.WriteAttributeString("engg_group_name", System.Convert.ToString(nvc_HDR["engg_group_name"]));
                    this.writer.WriteAttributeString("engg_group_seqno", System.Convert.ToString(nvc_HDR["engg_group_seqno"]));
                    this.writer.WriteAttributeString("engg_hdrpersonalisation", System.Convert.ToString(nvc_HDR["engg_hdrpersonalisation"]));
                    this.writer.WriteAttributeString("engg_hide_print", System.Convert.ToString(nvc_HDR["engg_hide_print"]));
                    this.writer.WriteAttributeString("engg_ilbotitle", System.Convert.ToString(nvc_HDR["engg_ilbotitle"]));
                    this.writer.WriteAttributeString("engg_impdefault", System.Convert.ToString(nvc_HDR["engg_impdefault"]));
                    this.writer.WriteAttributeString("engg_isdevice", System.Convert.ToString(nvc_HDR["engg_isdevice"]));
                    this.writer.WriteAttributeString("engg_lefttb", System.Convert.ToString(nvc_HDR["engg_lefttb"]));
                    this.writer.WriteAttributeString("engg_nativeapp", System.Convert.ToString(nvc_HDR["engg_nativeapp"]));
                    this.writer.WriteAttributeString("engg_page_name", System.Convert.ToString(nvc_HDR["engg_page_name"]));
                    this.writer.WriteAttributeString("engg_phone", System.Convert.ToString(nvc_HDR["engg_phone"]));
                    this.writer.WriteAttributeString("engg_popup_close", System.Convert.ToString(nvc_HDR["engg_popup_close"]));
                    this.writer.WriteAttributeString("engg_process_descr", System.Convert.ToString(nvc_HDR["engg_process_descr"]));
                    this.writer.WriteAttributeString("engg_project_name", System.Convert.ToString(nvc_HDR["engg_project_name"]));
                    this.writer.WriteAttributeString("engg_req_no", System.Convert.ToString(nvc_HDR["engg_req_no"]));
                    this.writer.WriteAttributeString("engg_rf_act", System.Convert.ToString(nvc_HDR["engg_rf_act"]));
                    this.writer.WriteAttributeString("engg_rf_comp", System.Convert.ToString(nvc_HDR["engg_rf_comp"]));
                    this.writer.WriteAttributeString("engg_rf_ui", System.Convert.ToString(nvc_HDR["engg_rf_ui"]));
                    this.writer.WriteAttributeString("engg_righttb", System.Convert.ToString(nvc_HDR["engg_righttb"]));
                    this.writer.WriteAttributeString("engg_sect_name", System.Convert.ToString(nvc_HDR["engg_sect_name"]));
                    this.writer.WriteAttributeString("engg_smarthide", System.Convert.ToString(nvc_HDR["engg_smarthide"]));
                    this.writer.WriteAttributeString("engg_syst_excl_tab_ind", System.Convert.ToString(nvc_HDR["engg_syst_excl_tab_ind"]));
                    this.writer.WriteAttributeString("engg_tab_hdr_pos", System.Convert.ToString(nvc_HDR["engg_tab_hdr_pos"]));
                    this.writer.WriteAttributeString("engg_tab_height", System.Convert.ToString(nvc_HDR["engg_tab_height"]));
                    this.writer.WriteAttributeString("engg_tab_rotate", System.Convert.ToString(nvc_HDR["engg_tab_rotate"]));
                    this.writer.WriteAttributeString("engg_tab_style", System.Convert.ToString(nvc_HDR["engg_tab_style"]));
                    this.writer.WriteAttributeString("engg_tab_type", System.Convert.ToString(nvc_HDR["engg_tab_type"]));
                    this.writer.WriteAttributeString("engg_tablet", System.Convert.ToString(nvc_HDR["engg_tablet"]));
                    this.writer.WriteAttributeString("engg_titlebar_search", System.Convert.ToString(nvc_HDR["engg_titlebar_search"]));
                    this.writer.WriteAttributeString("engg_toptb", System.Convert.ToString(nvc_HDR["engg_toptb"]));
                    this.writer.WriteAttributeString("engg_ui_descr", System.Convert.ToString(nvc_HDR["engg_ui_descr"]));
                    this.writer.WriteAttributeString("engg_ui_laycon", System.Convert.ToString(nvc_HDR["engg_ui_laycon"]));
                    this.writer.WriteAttributeString("engg_ui_layout", System.Convert.ToString(nvc_HDR["engg_ui_layout"]));
                    this.writer.WriteAttributeString("engg_ui_name", System.Convert.ToString(nvc_HDR["engg_ui_name"]));
                    this.writer.WriteAttributeString("engg_uisubtype", System.Convert.ToString(nvc_HDR["engg_uisubtype"]));
                    this.writer.WriteAttributeString("ezee_taskpane", System.Convert.ToString(nvc_HDR["ezee_taskpane"]));
                    this.writer.WriteAttributeString("guid", System.Convert.ToString(nvc_HDR["guid"]));
                    this.writer.WriteAttributeString("hdnrt_stcontrol", System.Convert.ToString(nvc_HDR["hdnrt_stcontrol"]));
                    this.writer.WriteAttributeString("state_processing", System.Convert.ToString(nvc_HDR["state_processing"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hdr", nvc_HDR);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.nvcCB_HDR != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cb_hdr", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cb_hdr");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_cont_page_bts", System.Convert.ToString(nvcCB_HDR["engg_cont_page_bts"]));
                    this.writer.WriteAttributeString("engg_cont_sec_bts", System.Convert.ToString(nvcCB_HDR["engg_cont_sec_bts"]));
                    this.writer.WriteAttributeString("engg_enum_btsynname", System.Convert.ToString(nvcCB_HDR["engg_enum_btsynname"]));
                    this.writer.WriteAttributeString("engg_enum_page_bts", System.Convert.ToString(nvcCB_HDR["engg_enum_page_bts"]));
                    this.writer.WriteAttributeString("engg_enum_sec_bts", System.Convert.ToString(nvcCB_HDR["engg_enum_sec_bts"]));
                    this.writer.WriteAttributeString("engg_grid_grid_code", System.Convert.ToString(nvcCB_HDR["engg_grid_grid_code"]));
                    this.writer.WriteAttributeString("engg_grid_page_bts", System.Convert.ToString(nvcCB_HDR["engg_grid_page_bts"]));
                    this.writer.WriteAttributeString("engg_grid_sec_bts", System.Convert.ToString(nvcCB_HDR["engg_grid_sec_bts"]));
                    this.writer.WriteAttributeString("engg_lay_page_bts", System.Convert.ToString(nvcCB_HDR["engg_lay_page_bts"]));
                    this.writer.WriteAttributeString("engg_lnk_page_descr", System.Convert.ToString(nvcCB_HDR["engg_lnk_page_descr"]));
                    this.writer.WriteAttributeString("engg_radio_btsynname", System.Convert.ToString(nvcCB_HDR["engg_radio_btsynname"]));
                    this.writer.WriteAttributeString("engg_radio_page_bts", System.Convert.ToString(nvcCB_HDR["engg_radio_page_bts"]));
                    this.writer.WriteAttributeString("engg_radio_sec_bts", System.Convert.ToString(nvcCB_HDR["engg_radio_sec_bts"]));
                    this.writer.WriteAttributeString("engg_sec_page_bts", System.Convert.ToString(nvcCB_HDR["engg_sec_page_bts"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("cb_hdr", nvcCB_HDR);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htCNML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("cnml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("cnml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htCNML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htCNML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htCNML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("accesskey", System.Convert.ToString(nvcTmp["accesskey"]));
                            this.writer.WriteAttributeString("cont_class_ext6", System.Convert.ToString(nvcTmp["cont_class_ext6"]));
                            this.writer.WriteAttributeString("ctrl_temp_cat", System.Convert.ToString(nvcTmp["ctrl_temp_cat"]));
                            this.writer.WriteAttributeString("ctrl_temp_specific", System.Convert.ToString(nvcTmp["ctrl_temp_specific"]));
                            this.writer.WriteAttributeString("engg_cont_btsynname", System.Convert.ToString(nvcTmp["engg_cont_btsynname"]));
                            this.writer.WriteAttributeString("engg_cont_colspan", System.Convert.ToString(nvcTmp["engg_cont_colspan"]));
                            this.writer.WriteAttributeString("engg_cont_control_format", System.Convert.ToString(nvcTmp["engg_cont_control_format"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlclass", System.Convert.ToString(nvcTmp["engg_cont_ctrlclass"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlimg", System.Convert.ToString(nvcTmp["engg_cont_ctrlimg"]));
                            this.writer.WriteAttributeString("engg_cont_ctrlimgclass", System.Convert.ToString(nvcTmp["engg_cont_ctrlimgclass"]));
                            this.writer.WriteAttributeString("engg_cont_customaction", System.Convert.ToString(nvcTmp["engg_cont_customaction"]));
                            this.writer.WriteAttributeString("engg_cont_customborder", System.Convert.ToString(nvcTmp["engg_cont_customborder"]));
                            this.writer.WriteAttributeString("engg_cont_datawidth", System.Convert.ToString(nvcTmp["engg_cont_datawidth"]));
                            this.writer.WriteAttributeString("engg_cont_descr", System.Convert.ToString(nvcTmp["engg_cont_descr"]));
                            this.writer.WriteAttributeString("engg_cont_doc", System.Convert.ToString(nvcTmp["engg_cont_doc"]));
                            this.writer.WriteAttributeString("engg_cont_elem_type", System.Convert.ToString(nvcTmp["engg_cont_elem_type"]));
                            this.writer.WriteAttributeString("engg_cont_forresponsive", System.Convert.ToString(nvcTmp["engg_cont_forresponsive"]));
                            this.writer.WriteAttributeString("engg_cont_helptabstop", System.Convert.ToString(nvcTmp["engg_cont_helptabstop"]));
                            this.writer.WriteAttributeString("engg_cont_horder", System.Convert.ToString(nvcTmp["engg_cont_horder"]));
                            this.writer.WriteAttributeString("engg_cont_labclass", System.Convert.ToString(nvcTmp["engg_cont_labclass"]));
                            this.writer.WriteAttributeString("engg_cont_labimgclass", System.Convert.ToString(nvcTmp["engg_cont_labimgclass"]));
                            this.writer.WriteAttributeString("engg_cont_labwidth", System.Convert.ToString(nvcTmp["engg_cont_labwidth"]));
                            this.writer.WriteAttributeString("engg_cont_rowspan", System.Convert.ToString(nvcTmp["engg_cont_rowspan"]));
                            this.writer.WriteAttributeString("engg_cont_samp_data", System.Convert.ToString(nvcTmp["engg_cont_samp_data"]));
                            this.writer.WriteAttributeString("engg_cont_sequence", System.Convert.ToString(nvcTmp["engg_cont_sequence"]));
                            this.writer.WriteAttributeString("engg_cont_tabseq", System.Convert.ToString(nvcTmp["engg_cont_tabseq"]));
                            this.writer.WriteAttributeString("engg_cont_tempid", System.Convert.ToString(nvcTmp["engg_cont_tempid"]));
                            this.writer.WriteAttributeString("engg_cont_tooltip", System.Convert.ToString(nvcTmp["engg_cont_tooltip"]));
                            this.writer.WriteAttributeString("engg_cont_vis_length", System.Convert.ToString(nvcTmp["engg_cont_vis_length"]));
                            this.writer.WriteAttributeString("engg_cont_vorder", System.Convert.ToString(nvcTmp["engg_cont_vorder"]));
                            this.writer.WriteAttributeString("engg_dynamicstyle", System.Convert.ToString(nvcTmp["engg_dynamicstyle"]));
                            this.writer.WriteAttributeString("engg_extension", System.Convert.ToString(nvcTmp["engg_extension"]));
                            this.writer.WriteAttributeString("engg_extnreqd", System.Convert.ToString(nvcTmp["engg_extnreqd"]));
                            this.writer.WriteAttributeString("engg_imageasdata", System.Convert.ToString(nvcTmp["engg_imageasdata"]));
                            this.writer.WriteAttributeString("engg_msc_ass_control", System.Convert.ToString(nvcTmp["engg_msc_ass_control"]));
                            this.writer.WriteAttributeString("freezecount", System.Convert.ToString(nvcTmp["freezecount"]));
                            this.writer.WriteAttributeString("icon_class", System.Convert.ToString(nvcTmp["icon_class"]));
                            this.writer.WriteAttributeString("icon_position", System.Convert.ToString(nvcTmp["icon_position"]));
                            this.writer.WriteAttributeString("set_user_pref", System.Convert.ToString(nvcTmp["set_user_pref"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("cnml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htENML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("enml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("enml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htENML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htENML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htENML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_enum_caption", System.Convert.ToString(nvcTmp["engg_enum_caption"]));
                            this.writer.WriteAttributeString("engg_enum_code", System.Convert.ToString(nvcTmp["engg_enum_code"]));
                            this.writer.WriteAttributeString("engg_enum_default", System.Convert.ToString(nvcTmp["engg_enum_default"]));
                            this.writer.WriteAttributeString("engg_enum_seq", System.Convert.ToString(nvcTmp["engg_enum_seq"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("enml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGDML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("gdml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("gdml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htGDML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htGDML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGDML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("col_associate_ctrl", System.Convert.ToString(nvcTmp["col_associate_ctrl"]));
                            this.writer.WriteAttributeString("col_class_ext6", System.Convert.ToString(nvcTmp["col_class_ext6"]));
                            this.writer.WriteAttributeString("col_compact_view", System.Convert.ToString(nvcTmp["col_compact_view"]));
                            this.writer.WriteAttributeString("col_icon_class", System.Convert.ToString(nvcTmp["col_icon_class"]));
                            this.writer.WriteAttributeString("col_icon_position", System.Convert.ToString(nvcTmp["col_icon_position"]));
                            this.writer.WriteAttributeString("col_temp_cat", System.Convert.ToString(nvcTmp["col_temp_cat"]));
                            this.writer.WriteAttributeString("col_temp_specific", System.Convert.ToString(nvcTmp["col_temp_specific"]));
                            this.writer.WriteAttributeString("col_transform_as", System.Convert.ToString(nvcTmp["col_transform_as"]));
                            this.writer.WriteAttributeString("columnclass", System.Convert.ToString(nvcTmp["columnclass"]));
                            this.writer.WriteAttributeString("engg_col_descr", System.Convert.ToString(nvcTmp["engg_col_descr"]));
                            this.writer.WriteAttributeString("engg_col_tempid", System.Convert.ToString(nvcTmp["engg_col_tempid"]));
                            this.writer.WriteAttributeString("engg_extensionorder", System.Convert.ToString(nvcTmp["engg_extensionorder"]));
                            this.writer.WriteAttributeString("engg_extensionreqd", System.Convert.ToString(nvcTmp["engg_extensionreqd"]));
                            this.writer.WriteAttributeString("engg_grd_visible", System.Convert.ToString(nvcTmp["engg_grd_visible"]));
                            this.writer.WriteAttributeString("engg_grid_btsynname", System.Convert.ToString(nvcTmp["engg_grid_btsynname"]));
                            this.writer.WriteAttributeString("engg_grid_colno", System.Convert.ToString(nvcTmp["engg_grid_colno"]));
                            this.writer.WriteAttributeString("engg_grid_default", System.Convert.ToString(nvcTmp["engg_grid_default"]));
                            this.writer.WriteAttributeString("engg_grid_doc", System.Convert.ToString(nvcTmp["engg_grid_doc"]));
                            this.writer.WriteAttributeString("engg_grid_elem_type", System.Convert.ToString(nvcTmp["engg_grid_elem_type"]));
                            this.writer.WriteAttributeString("engg_grid_samp_data", System.Convert.ToString(nvcTmp["engg_grid_samp_data"]));
                            this.writer.WriteAttributeString("engg_grid_tooltip", System.Convert.ToString(nvcTmp["engg_grid_tooltip"]));
                            this.writer.WriteAttributeString("engg_grid_vis_length", System.Convert.ToString(nvcTmp["engg_grid_vis_length"]));
                            this.writer.WriteAttributeString("engg_tree_column", System.Convert.ToString(nvcTmp["engg_tree_column"]));
                            this.writer.WriteAttributeString("forcefit", System.Convert.ToString(nvcTmp["forcefit"]));
                            this.writer.WriteAttributeString("formenabled", System.Convert.ToString(nvcTmp["formenabled"]));
                            this.writer.WriteAttributeString("rowexpander", System.Convert.ToString(nvcTmp["rowexpander"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("gdml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htGRPML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("grpml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("grpml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htGRPML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htGRPML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htGRPML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_col_or_group", System.Convert.ToString(nvcTmp["engg_col_or_group"]));
                            this.writer.WriteAttributeString("engg_map_seq", System.Convert.ToString(nvcTmp["engg_map_seq"]));
                            this.writer.WriteAttributeString("engg_mapped_entity", System.Convert.ToString(nvcTmp["engg_mapped_entity"]));
                            this.writer.WriteAttributeString("engg_ui_map", System.Convert.ToString(nvcTmp["engg_ui_map"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("grpml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLNKML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lnkml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lnkml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htLNKML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htLNKML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLNKML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_launch_type", System.Convert.ToString(nvcTmp["engg_launch_type"]));
                            this.writer.WriteAttributeString("engg_links_assoctrl", System.Convert.ToString(nvcTmp["engg_links_assoctrl"]));
                            this.writer.WriteAttributeString("engg_links_height", System.Convert.ToString(nvcTmp["engg_links_height"]));
                            this.writer.WriteAttributeString("engg_links_link_act", System.Convert.ToString(nvcTmp["engg_links_link_act"]));
                            this.writer.WriteAttributeString("engg_links_link_comp", System.Convert.ToString(nvcTmp["engg_links_link_comp"]));
                            this.writer.WriteAttributeString("engg_links_link_type", System.Convert.ToString(nvcTmp["engg_links_link_type"]));
                            this.writer.WriteAttributeString("engg_links_link_ui", System.Convert.ToString(nvcTmp["engg_links_link_ui"]));
                            this.writer.WriteAttributeString("engg_links_pcv_caption", System.Convert.ToString(nvcTmp["engg_links_pcv_caption"]));
                            this.writer.WriteAttributeString("engg_links_width", System.Convert.ToString(nvcTmp["engg_links_width"]));
                            this.writer.WriteAttributeString("engg_toolbar_notreq", System.Convert.ToString(nvcTmp["engg_toolbar_notreq"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lnkml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLYML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("lyml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("lyml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htLYML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htLYML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLYML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_lay_horder", System.Convert.ToString(nvcTmp["engg_lay_horder"]));
                            this.writer.WriteAttributeString("engg_lay_parent_sec", System.Convert.ToString(nvcTmp["engg_lay_parent_sec"]));
                            this.writer.WriteAttributeString("engg_lay_sec_name", System.Convert.ToString(nvcTmp["engg_lay_sec_name"]));
                            this.writer.WriteAttributeString("engg_lay_sec_position", System.Convert.ToString(nvcTmp["engg_lay_sec_position"]));
                            this.writer.WriteAttributeString("engg_lay_vorder", System.Convert.ToString(nvcTmp["engg_lay_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("lyml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPGML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pgml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pgml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htPGML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htPGML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPGML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_hdr_pos", System.Convert.ToString(nvcTmp["engg_hdr_pos"]));
                            this.writer.WriteAttributeString("engg_pag_lay_con", System.Convert.ToString(nvcTmp["engg_pag_lay_con"]));
                            this.writer.WriteAttributeString("engg_page_bottomtb", System.Convert.ToString(nvcTmp["engg_page_bottomtb"]));
                            this.writer.WriteAttributeString("engg_page_btsynname", System.Convert.ToString(nvcTmp["engg_page_btsynname"]));
                            this.writer.WriteAttributeString("engg_page_descr", System.Convert.ToString(nvcTmp["engg_page_descr"]));
                            this.writer.WriteAttributeString("engg_page_doc", System.Convert.ToString(nvcTmp["engg_page_doc"]));
                            this.writer.WriteAttributeString("engg_page_horder", System.Convert.ToString(nvcTmp["engg_page_horder"]));
                            this.writer.WriteAttributeString("engg_page_img", System.Convert.ToString(nvcTmp["engg_page_img"]));
                            this.writer.WriteAttributeString("engg_page_lay", System.Convert.ToString(nvcTmp["engg_page_lay"]));
                            this.writer.WriteAttributeString("engg_page_lefttb", System.Convert.ToString(nvcTmp["engg_page_lefttb"]));
                            this.writer.WriteAttributeString("engg_page_righttb", System.Convert.ToString(nvcTmp["engg_page_righttb"]));
                            this.writer.WriteAttributeString("engg_page_toptb", System.Convert.ToString(nvcTmp["engg_page_toptb"]));
                            this.writer.WriteAttributeString("engg_page_type", System.Convert.ToString(nvcTmp["engg_page_type"]));
                            this.writer.WriteAttributeString("engg_page_vorder", System.Convert.ToString(nvcTmp["engg_page_vorder"]));
                            this.writer.WriteAttributeString("engg_tab_icon_pos", System.Convert.ToString(nvcTmp["engg_tab_icon_pos"]));
                            this.writer.WriteAttributeString("engg_tab_rot", System.Convert.ToString(nvcTmp["engg_tab_rot"]));
                            this.writer.WriteAttributeString("engg_tab_title_st", System.Convert.ToString(nvcTmp["engg_tab_title_st"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pgml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRDML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rdml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rdml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htRDML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htRDML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRDML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_radio_caption", System.Convert.ToString(nvcTmp["engg_radio_caption"]));
                            this.writer.WriteAttributeString("engg_radio_code", System.Convert.ToString(nvcTmp["engg_radio_code"]));
                            this.writer.WriteAttributeString("engg_radio_default", System.Convert.ToString(nvcTmp["engg_radio_default"]));
                            this.writer.WriteAttributeString("engg_radio_horder", System.Convert.ToString(nvcTmp["engg_radio_horder"]));
                            this.writer.WriteAttributeString("engg_radio_seq", System.Convert.ToString(nvcTmp["engg_radio_seq"]));
                            this.writer.WriteAttributeString("engg_radio_vorder", System.Convert.ToString(nvcTmp["engg_radio_vorder"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rdml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htSCML_MLO != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("scml_mlo", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("scml_mlo");
                    this.writer.WriteAttributeString("RecordCount", htSCML_MLO.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htSCML_MLO.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htSCML_MLO[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_associatedcontrol", System.Convert.ToString(nvcTmp["engg_associatedcontrol"]));
                            this.writer.WriteAttributeString("engg_col_dir", System.Convert.ToString(nvcTmp["engg_col_dir"]));
                            this.writer.WriteAttributeString("engg_mob_fullview", System.Convert.ToString(nvcTmp["engg_mob_fullview"]));
                            this.writer.WriteAttributeString("engg_mob_responsive", System.Convert.ToString(nvcTmp["engg_mob_responsive"]));
                            this.writer.WriteAttributeString("engg_region", System.Convert.ToString(nvcTmp["engg_region"]));
                            this.writer.WriteAttributeString("engg_sec_bord_req", System.Convert.ToString(nvcTmp["engg_sec_bord_req"]));
                            this.writer.WriteAttributeString("engg_sec_bottomtb", System.Convert.ToString(nvcTmp["engg_sec_bottomtb"]));
                            this.writer.WriteAttributeString("engg_sec_btsynname", System.Convert.ToString(nvcTmp["engg_sec_btsynname"]));
                            this.writer.WriteAttributeString("engg_sec_cap_align", System.Convert.ToString(nvcTmp["engg_sec_cap_align"]));
                            this.writer.WriteAttributeString("engg_sec_cap_format", System.Convert.ToString(nvcTmp["engg_sec_cap_format"]));
                            this.writer.WriteAttributeString("engg_sec_customborder", System.Convert.ToString(nvcTmp["engg_sec_customborder"]));
                            this.writer.WriteAttributeString("engg_sec_descr", System.Convert.ToString(nvcTmp["engg_sec_descr"]));
                            this.writer.WriteAttributeString("engg_sec_lay_con", System.Convert.ToString(nvcTmp["engg_sec_lay_con"]));
                            this.writer.WriteAttributeString("engg_sec_lefttb", System.Convert.ToString(nvcTmp["engg_sec_lefttb"]));
                            this.writer.WriteAttributeString("engg_sec_minrows", System.Convert.ToString(nvcTmp["engg_sec_minrows"]));
                            this.writer.WriteAttributeString("engg_sec_righttb", System.Convert.ToString(nvcTmp["engg_sec_righttb"]));
                            this.writer.WriteAttributeString("engg_sec_secpreclass", System.Convert.ToString(nvcTmp["engg_sec_secpreclass"]));
                            this.writer.WriteAttributeString("engg_sec_title_align", System.Convert.ToString(nvcTmp["engg_sec_title_align"]));
                            this.writer.WriteAttributeString("engg_sec_title_req", System.Convert.ToString(nvcTmp["engg_sec_title_req"]));
                            this.writer.WriteAttributeString("engg_sec_titleaction", System.Convert.ToString(nvcTmp["engg_sec_titleaction"]));
                            this.writer.WriteAttributeString("engg_sec_titleicon", System.Convert.ToString(nvcTmp["engg_sec_titleicon"]));
                            this.writer.WriteAttributeString("engg_sec_toptb", System.Convert.ToString(nvcTmp["engg_sec_toptb"]));
                            this.writer.WriteAttributeString("engg_sec_type", System.Convert.ToString(nvcTmp["engg_sec_type"]));
                            this.writer.WriteAttributeString("engg_sec_visible", System.Convert.ToString(nvcTmp["engg_sec_visible"]));
                            this.writer.WriteAttributeString("engg_sec_vwmode", System.Convert.ToString(nvcTmp["engg_sec_vwmode"]));
                            this.writer.WriteAttributeString("engg_sect_doc", System.Convert.ToString(nvcTmp["engg_sect_doc"]));
                            this.writer.WriteAttributeString("engg_sect_forresponsive", System.Convert.ToString(nvcTmp["engg_sect_forresponsive"]));
                            this.writer.WriteAttributeString("engg_sect_lay", System.Convert.ToString(nvcTmp["engg_sect_lay"]));
                            this.writer.WriteAttributeString("engg_title_pos", System.Convert.ToString(nvcTmp["engg_title_pos"]));
                            this.writer.WriteAttributeString("sec_collapse", System.Convert.ToString(nvcTmp["sec_collapse"]));
                            this.writer.WriteAttributeString("sec_collapsemode", System.Convert.ToString(nvcTmp["sec_collapsemode"]));
                            this.writer.WriteAttributeString("section_colspan", System.Convert.ToString(nvcTmp["section_colspan"]));
                            this.writer.WriteAttributeString("section_rowspan", System.Convert.ToString(nvcTmp["section_rowspan"]));
                            this.writer.WriteAttributeString("sectionheight", System.Convert.ToString(nvcTmp["sectionheight"]));
                            this.writer.WriteAttributeString("sectionwidth", System.Convert.ToString(nvcTmp["sectionwidth"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("scml_mlo", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hdr":
                        switch (DataItem)
                        {
                            case "_txt_interfacecontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_docked":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_sidebar":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_att_ui_cap_align":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_format":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_grid_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_trail_bar":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_bottomtb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_callout_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_sec_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_control_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_desk_brw":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_ctrl_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_type_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_caption":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_group_seqno":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_hdrpersonalisation":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_hide_print":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ilbotitle":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_impdefault":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_isdevice":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lefttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_nativeapp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_page_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_phone":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_popup_close":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_righttb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_sect_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_smarthide":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_syst_excl_tab_ind":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_hdr_pos":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_height":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_tab_rotate":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_style":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tablet":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_titlebar_search":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_toptb":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_laycon":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_layout":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_uisubtype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ezee_taskpane":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "state_processing":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HDR[DataItem] = DIValue;
                        return 0;
                    case "cb_hdr":
                        switch (DataItem)
                        {
                            case "engg_act_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_cap_align":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_format":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_trail_bar":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_att_ui_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_component":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_cont_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_customer_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_btsynname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_enum_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_grid_code":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_grid_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lay_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_lnk_page_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_popup_close":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_process_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_project_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_btsynname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_radio_sec_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_req_no":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_act":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_comp":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_rf_ui":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_sec_page_bts":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_tab_height":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_ui_descr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcCB_HDR[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcCB_HDR[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    type = 1;
                    break;
                case "ct_sec_cb":
                    type = 1;
                    break;
                case "en_bts_cb":
                    type = 1;
                    break;
                case "en_pg_cb":
                    type = 1;
                    break;
                case "en_sec_cb":
                    type = 1;
                    break;
                case "g_grid_cb":
                    type = 1;
                    break;
                case "gd_pg_cb":
                    type = 1;
                    break;
                case "gd_sec_cb":
                    type = 1;
                    break;
                case "grpct_cb":
                    type = 1;
                    break;
                case "grpgrp_cb":
                    type = 1;
                    break;
                case "grppg_cb":
                    type = 1;
                    break;
                case "grpsc_cb":
                    type = 1;
                    break;
                case "lay_pg_cb":
                    type = 1;
                    break;
                case "lnk_pg_cb":
                    type = 1;
                    break;
                case "parsec_mcb":
                    type = 1;
                    break;
                case "rd_bts_cb":
                    type = 1;
                    break;
                case "rd_pg_cb":
                    type = 1;
                    break;
                case "rd_sec_cb":
                    type = 1;
                    break;
                case "sec_pg_cb":
                    type = 1;
                    break;
                case "_hdr":
                    type = 0;
                    break;
                case "cb_hdr":
                    type = 0;
                    break;
                case "cnml_mlo":
                    type = 1;
                    break;
                case "enml_mlo":
                    type = 1;
                    break;
                case "gdml_mlo":
                    type = 1;
                    break;
                case "grpml_mlo":
                    type = 1;
                    break;
                case "lnkml_mlo":
                    type = 1;
                    break;
                case "lyml_mlo":
                    type = 1;
                    break;
                case "pgml_mlo":
                    type = 1;
                    break;
                case "rdml_mlo":
                    type = 1;
                    break;
                case "scml_mlo":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    return htCT_PG_CB.Count;
                    break;
                case "ct_sec_cb":
                    return htCT_SEC_CB.Count;
                    break;
                case "en_bts_cb":
                    return htEN_BTS_CB.Count;
                    break;
                case "en_pg_cb":
                    return htEN_PG_CB.Count;
                    break;
                case "en_sec_cb":
                    return htEN_SEC_CB.Count;
                    break;
                case "g_grid_cb":
                    return htG_GRID_CB.Count;
                    break;
                case "gd_pg_cb":
                    return htGD_PG_CB.Count;
                    break;
                case "gd_sec_cb":
                    return htGD_SEC_CB.Count;
                    break;
                case "grpct_cb":
                    return htGRPCT_CB.Count;
                    break;
                case "grpgrp_cb":
                    return htGRPGRP_CB.Count;
                    break;
                case "grppg_cb":
                    return htGRPPG_CB.Count;
                    break;
                case "grpsc_cb":
                    return htGRPSC_CB.Count;
                    break;
                case "lay_pg_cb":
                    return htLAY_PG_CB.Count;
                    break;
                case "lnk_pg_cb":
                    return htLNK_PG_CB.Count;
                    break;
                case "parsec_mcb":
                    return htPARSEC_MCB.Count;
                    break;
                case "rd_bts_cb":
                    return htRD_BTS_CB.Count;
                    break;
                case "rd_pg_cb":
                    return htRD_PG_CB.Count;
                    break;
                case "rd_sec_cb":
                    return htRD_SEC_CB.Count;
                    break;
                case "sec_pg_cb":
                    return htSEC_PG_CB.Count;
                    break;
                case "cnml_mlo":
                    return htCNML_MLO.Count;
                    break;
                case "enml_mlo":
                    return htENML_MLO.Count;
                    break;
                case "gdml_mlo":
                    return htGDML_MLO.Count;
                    break;
                case "grpml_mlo":
                    return htGRPML_MLO.Count;
                    break;
                case "lnkml_mlo":
                    return htLNKML_MLO.Count;
                    break;
                case "lyml_mlo":
                    return htLYML_MLO.Count;
                    break;
                case "pgml_mlo":
                    return htPGML_MLO.Count;
                    break;
                case "rdml_mlo":
                    return htRDML_MLO.Count;
                    break;
                case "scml_mlo":
                    return htSCML_MLO.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "ct_pg_cb":
                    return this.htCT_PG_CB;
                case "ct_sec_cb":
                    return this.htCT_SEC_CB;
                case "en_bts_cb":
                    return this.htEN_BTS_CB;
                case "en_pg_cb":
                    return this.htEN_PG_CB;
                case "en_sec_cb":
                    return this.htEN_SEC_CB;
                case "g_grid_cb":
                    return this.htG_GRID_CB;
                case "gd_pg_cb":
                    return this.htGD_PG_CB;
                case "gd_sec_cb":
                    return this.htGD_SEC_CB;
                case "grpct_cb":
                    return this.htGRPCT_CB;
                case "grpgrp_cb":
                    return this.htGRPGRP_CB;
                case "grppg_cb":
                    return this.htGRPPG_CB;
                case "grpsc_cb":
                    return this.htGRPSC_CB;
                case "lay_pg_cb":
                    return this.htLAY_PG_CB;
                case "lnk_pg_cb":
                    return this.htLNK_PG_CB;
                case "parsec_mcb":
                    return this.htPARSEC_MCB;
                case "rd_bts_cb":
                    return this.htRD_BTS_CB;
                case "rd_pg_cb":
                    return this.htRD_PG_CB;
                case "rd_sec_cb":
                    return this.htRD_SEC_CB;
                case "sec_pg_cb":
                    return this.htSEC_PG_CB;
                case "cnml_mlo":
                    return this.htCNML_MLO;
                case "enml_mlo":
                    return this.htENML_MLO;
                case "gdml_mlo":
                    return this.htGDML_MLO;
                case "grpml_mlo":
                    return this.htGRPML_MLO;
                case "lnkml_mlo":
                    return this.htLNKML_MLO;
                case "lyml_mlo":
                    return this.htLYML_MLO;
                case "pgml_mlo":
                    return this.htPGML_MLO;
                case "rdml_mlo":
                    return this.htRDML_MLO;
                case "scml_mlo":
                    return this.htSCML_MLO;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hdr":
                    return this.nvc_HDR;
                case "cb_hdr":
                    return this.nvcCB_HDR;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "ct_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_pg_cb = (NameValueCollection)htCT_PG_CB[lnInstNumber];
                        return nvcTmpct_pg_cb[szDataItem];
                        break;
                    case "ct_sec_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpct_sec_cb = (NameValueCollection)htCT_SEC_CB[lnInstNumber];
                        return nvcTmpct_sec_cb[szDataItem];
                        break;
                    case "en_bts_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpen_bts_cb = (NameValueCollection)htEN_BTS_CB[lnInstNumber];
                        return nvcTmpen_bts_cb[szDataItem];
                        break;
                    case "en_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpen_pg_cb = (NameValueCollection)htEN_PG_CB[lnInstNumber];
                        return nvcTmpen_pg_cb[szDataItem];
                        break;
                    case "en_sec_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpen_sec_cb = (NameValueCollection)htEN_SEC_CB[lnInstNumber];
                        return nvcTmpen_sec_cb[szDataItem];
                        break;
                    case "g_grid_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpg_grid_cb = (NameValueCollection)htG_GRID_CB[lnInstNumber];
                        return nvcTmpg_grid_cb[szDataItem];
                        break;
                    case "gd_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgd_pg_cb = (NameValueCollection)htGD_PG_CB[lnInstNumber];
                        return nvcTmpgd_pg_cb[szDataItem];
                        break;
                    case "gd_sec_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgd_sec_cb = (NameValueCollection)htGD_SEC_CB[lnInstNumber];
                        return nvcTmpgd_sec_cb[szDataItem];
                        break;
                    case "grpct_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgrpct_cb = (NameValueCollection)htGRPCT_CB[lnInstNumber];
                        return nvcTmpgrpct_cb[szDataItem];
                        break;
                    case "grpgrp_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgrpgrp_cb = (NameValueCollection)htGRPGRP_CB[lnInstNumber];
                        return nvcTmpgrpgrp_cb[szDataItem];
                        break;
                    case "grppg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgrppg_cb = (NameValueCollection)htGRPPG_CB[lnInstNumber];
                        return nvcTmpgrppg_cb[szDataItem];
                        break;
                    case "grpsc_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpgrpsc_cb = (NameValueCollection)htGRPSC_CB[lnInstNumber];
                        return nvcTmpgrpsc_cb[szDataItem];
                        break;
                    case "lay_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmplay_pg_cb = (NameValueCollection)htLAY_PG_CB[lnInstNumber];
                        return nvcTmplay_pg_cb[szDataItem];
                        break;
                    case "lnk_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmplnk_pg_cb = (NameValueCollection)htLNK_PG_CB[lnInstNumber];
                        return nvcTmplnk_pg_cb[szDataItem];
                        break;
                    case "parsec_mcb":
                        System.Collections.Specialized.NameValueCollection nvcTmpparsec_mcb = (NameValueCollection)htPARSEC_MCB[lnInstNumber];
                        return nvcTmpparsec_mcb[szDataItem];
                        break;
                    case "rd_bts_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmprd_bts_cb = (NameValueCollection)htRD_BTS_CB[lnInstNumber];
                        return nvcTmprd_bts_cb[szDataItem];
                        break;
                    case "rd_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmprd_pg_cb = (NameValueCollection)htRD_PG_CB[lnInstNumber];
                        return nvcTmprd_pg_cb[szDataItem];
                        break;
                    case "rd_sec_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmprd_sec_cb = (NameValueCollection)htRD_SEC_CB[lnInstNumber];
                        return nvcTmprd_sec_cb[szDataItem];
                        break;
                    case "sec_pg_cb":
                        System.Collections.Specialized.NameValueCollection nvcTmpsec_pg_cb = (NameValueCollection)htSEC_PG_CB[lnInstNumber];
                        return nvcTmpsec_pg_cb[szDataItem];
                        break;
                    case "_hdr":
                        return nvc_HDR[szDataItem];
                        break;
                    case "cb_hdr":
                        return nvcCB_HDR[szDataItem];
                        break;
                    case "cnml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpcnml_mlo = (NameValueCollection)htCNML_MLO[lnInstNumber];
                        return nvcTmpcnml_mlo[szDataItem];
                        break;
                    case "enml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpenml_mlo = (NameValueCollection)htENML_MLO[lnInstNumber];
                        return nvcTmpenml_mlo[szDataItem];
                        break;
                    case "gdml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpgdml_mlo = (NameValueCollection)htGDML_MLO[lnInstNumber];
                        return nvcTmpgdml_mlo[szDataItem];
                        break;
                    case "grpml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpgrpml_mlo = (NameValueCollection)htGRPML_MLO[lnInstNumber];
                        return nvcTmpgrpml_mlo[szDataItem];
                        break;
                    case "lnkml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmplnkml_mlo = (NameValueCollection)htLNKML_MLO[lnInstNumber];
                        return nvcTmplnkml_mlo[szDataItem];
                        break;
                    case "lyml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmplyml_mlo = (NameValueCollection)htLYML_MLO[lnInstNumber];
                        return nvcTmplyml_mlo[szDataItem];
                        break;
                    case "pgml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmppgml_mlo = (NameValueCollection)htPGML_MLO[lnInstNumber];
                        return nvcTmppgml_mlo[szDataItem];
                        break;
                    case "rdml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmprdml_mlo = (NameValueCollection)htRDML_MLO[lnInstNumber];
                        return nvcTmprdml_mlo[szDataItem];
                        break;
                    case "scml_mlo":
                        System.Collections.Specialized.NameValueCollection nvcTmpscml_mlo = (NameValueCollection)htSCML_MLO[lnInstNumber];
                        return nvcTmpscml_mlo[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                nvcCB_HDR["engg_popup_close"] = (nvcCB_HDR["engg_popup_close"] == null) ? "~#~" : nvcCB_HDR["engg_popup_close"];
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_layout_sr_selui Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                this.ProcessPS4();
                this.ProcessPS5();
                this.ProcessPS6();
                this.ProcessPS7();
                this.ProcessPS8();
                this.ProcessPS9();
                this.ProcessPS10();
                this.ProcessPS11();
                this.ProcessPS12();
                this.ProcessPS13();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_layout_sr_selui Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluiuihdr", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluiuihdr", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61805, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61805, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("fprowno");
                                nvc_HDR["fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61805, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS10()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 10;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 10
                // Starting to execute the BR - 1  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluict_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluict_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61814, 10, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61814, 10, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_page_bts");
                                    nvcTmp["engg_cont_page_bts"] = sValue;
                                    htCT_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61814, 10, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 2  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluict_sec", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluict_sec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61815, 10, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61815, 10, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCT_SEC_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_cont_sec_bts");
                                    nvcTmp["engg_cont_sec_bts"] = sValue;
                                    htCT_SEC_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61815, 10, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 3  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluien_bts", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluien_bts", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61816, 10, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61816, 10, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htEN_BTS_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_btsynname");
                                    nvcTmp["engg_enum_btsynname"] = sValue;
                                    htEN_BTS_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61816, 10, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 4  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluien_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluien_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61817, 10, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61817, 10, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htEN_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_page_bts");
                                    nvcTmp["engg_enum_page_bts"] = sValue;
                                    htEN_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61817, 10, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 5  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluien_sec", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluien_sec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61818, 10, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61818, 10, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htEN_SEC_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_sec_bts");
                                    nvcTmp["engg_enum_sec_bts"] = sValue;
                                    htEN_SEC_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61818, 10, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 6  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluig_grid", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluig_grid", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61819, 10, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61819, 10, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htG_GRID_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_grid_code");
                                    nvcTmp["engg_grid_grid_code"] = sValue;
                                    htG_GRID_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61819, 10, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 7  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigd_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigd_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61820, 10, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61820, 10, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGD_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_page_bts");
                                    nvcTmp["engg_grid_page_bts"] = sValue;
                                    htGD_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61820, 10, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 8  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigd_sec", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigd_sec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61821, 10, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61821, 10, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGD_SEC_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_grid_sec_bts");
                                    nvcTmp["engg_grid_sec_bts"] = sValue;
                                    htGD_SEC_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61821, 10, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 9  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilay_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluilay_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61822, 10, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61822, 10, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLAY_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_page_bts");
                                    nvcTmp["engg_lay_page_bts"] = sValue;
                                    htLAY_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61822, 10, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 10  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 10;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 10 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluiparsec", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluiparsec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61823, 10, 10);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61823, 10, 10);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPARSEC_MCB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_parent_sec");
                                    nvcTmp["engg_lay_parent_sec"] = sValue;
                                    htPARSEC_MCB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 10", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61823, 10, 10);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 11  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 11;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 11 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilnk_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluilnk_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61824, 10, 11);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61824, 10, 11);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLNK_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lnk_page_descr");
                                    nvcTmp["engg_lnk_page_descr"] = sValue;
                                    htLNK_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 11", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61824, 10, 11);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 12  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 12;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 12 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluird_bts", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluird_bts", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61825, 10, 12);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61825, 10, 12);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRD_BTS_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_btsynname");
                                    nvcTmp["engg_radio_btsynname"] = sValue;
                                    htRD_BTS_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 12", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61825, 10, 12);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 13  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 13;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 13 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluird_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluird_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61826, 10, 13);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61826, 10, 13);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRD_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_page_bts");
                                    nvcTmp["engg_radio_page_bts"] = sValue;
                                    htRD_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 13", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61826, 10, 13);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 14  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 14;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 14 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluird_sec", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluird_sec", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61827, 10, 14);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61827, 10, 14);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRD_SEC_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_sec_bts");
                                    nvcTmp["engg_radio_sec_bts"] = sValue;
                                    htRD_SEC_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 14", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61827, 10, 14);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 14 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 15  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 15;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 15 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluisec_pg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluisec_pg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61828, 10, 15);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61828, 10, 15);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSEC_PG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sec_page_bts");
                                    nvcTmp["engg_sec_page_bts"] = sValue;
                                    htSEC_PG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 15", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61828, 10, 15);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 15 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 16  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 16;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 16 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigrppg", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_mt_seluigrppg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114814, 10, 16);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 114814, 10, 16);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGRPPG_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_page_name");
                                    nvcTmp["engg_page_name"] = sValue;
                                    htGRPPG_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 16", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114814, 10, 16);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 16 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 17  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 17;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 17 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigrpsc", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigrpsc", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114815, 10, 17);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 114815, 10, 17);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGRPSC_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_sect_name");
                                    nvcTmp["engg_sect_name"] = sValue;
                                    htGRPSC_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 17", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114815, 10, 17);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 17 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 18  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 18;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 18 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigrpct", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigrpct", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114816, 10, 18);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 114816, 10, 18);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGRPCT_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_control_name");
                                    nvcTmp["engg_control_name"] = sValue;
                                    htGRPCT_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 18", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114816, 10, 18);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 18 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 10
                // Starting to execute the BR - 19  under the process section - 10
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 10;
                brSeqNo = 19;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbfetch");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 10 BR - 19 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigrpgrp", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigrpgrp", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114817, 10, 19);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 114817, 10, 19);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGRPGRP_CB.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_group_caption");
                                    nvcTmp["engg_group_caption"] = sValue;
                                    htGRPGRP_CB[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 10 BR - 19", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114817, 10, 19);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 10 BR - 19 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 10 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS11()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 11;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 11
                // Starting to execute the BR - 1  under the process section - 11
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 11;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuicbdf");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvcCB_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvcCB_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sCB_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : sCB_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, sCB_HDRengg_tab_height);
                            sValue = nvcCB_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvcCB_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 11 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluiucdef", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluiucdef", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61829, 11, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61829, 11, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_cont_page_bts");
                                nvcCB_HDR["engg_cont_page_bts"] = sValue;
                                sValue = this.GetValue("engg_cont_sec_bts");
                                nvcCB_HDR["engg_cont_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_enum_btsynname");
                                nvcCB_HDR["engg_enum_btsynname"] = sValue;
                                sValue = this.GetValue("engg_enum_page_bts");
                                nvcCB_HDR["engg_enum_page_bts"] = sValue;
                                sValue = this.GetValue("engg_enum_sec_bts");
                                nvcCB_HDR["engg_enum_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_grid_code");
                                nvcCB_HDR["engg_grid_grid_code"] = sValue;
                                sValue = this.GetValue("engg_grid_page_bts");
                                nvcCB_HDR["engg_grid_page_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_bts");
                                nvcCB_HDR["engg_grid_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_lay_page_bts");
                                nvcCB_HDR["engg_lay_page_bts"] = sValue;
                                sValue = this.GetValue("engg_lnk_page_descr");
                                nvcCB_HDR["engg_lnk_page_descr"] = sValue;
                                sValue = this.GetValue("engg_radio_btsynname");
                                nvcCB_HDR["engg_radio_btsynname"] = sValue;
                                sValue = this.GetValue("engg_radio_page_bts");
                                nvcCB_HDR["engg_radio_page_bts"] = sValue;
                                sValue = this.GetValue("engg_radio_sec_bts");
                                nvcCB_HDR["engg_radio_sec_bts"] = sValue;
                                sValue = this.GetValue("engg_sec_page_bts");
                                nvcCB_HDR["engg_sec_page_bts"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 11 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61829, 11, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 11 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 11 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS12()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 12;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 12
                // Starting to execute the BR - 1  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuihref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_io", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_io", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_io", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_io", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HDR["engg_att_ui_grid_type"];
                            base.Parameters("@engg_att_ui_grid_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HDR["state_processing"];
                            base.Parameters("@state_processing", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_callout_type"];
                            base.Parameters("@engg_callout_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HDR["engg_ui_name"];
                            base.Parameters("@engg_ui_name", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HDR["_txt_interfacecontrol"];
                            base.Parameters("@_txt_interfacecontrol", DBType.NVarchar, 128, sValue);
                            sValue = nvc_HDR["engg_tab_type"];
                            base.Parameters("@engg_tab_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["ezee_taskpane"];
                            base.Parameters("@ezee_taskpane", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_isdevice"];
                            base.Parameters("@engg_isdevice", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_smarthide"];
                            base.Parameters("@engg_smarthide", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_ilbotitle"];
                            base.Parameters("@engg_ilbotitle", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_hdrpersonalisation"];
                            base.Parameters("@engg_hdrpersonalisation", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_syst_excl_tab_ind"];
                            base.Parameters("@engg_syst_excl_tab_ind", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_phone"];
                            base.Parameters("@engg_phone", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_tablet"];
                            base.Parameters("@engg_tablet", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_desk_brw"];
                            base.Parameters("@engg_desk_brw", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_tab_style"];
                            base.Parameters("@engg_tab_style", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_layout"];
                            base.Parameters("@engg_ui_layout", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_laycon"];
                            base.Parameters("@engg_ui_laycon", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_hdr_pos"];
                            base.Parameters("@engg_tab_hdr_pos", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_hide_print"];
                            base.Parameters("@engg_hide_print", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_page_name"];
                            base.Parameters("@engg_page_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_sect_name"];
                            base.Parameters("@engg_sect_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_control_name"];
                            base.Parameters("@engg_control_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_group_name"];
                            base.Parameters("@engg_group_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_group_caption"];
                            base.Parameters("@engg_group_caption", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_rotate"];
                            base.Parameters("@engg_tab_rotate", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_group_seqno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_group_seqno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_group_seqno);
                            base.Parameters("@engg_group_seqno", DBType.Int, 32, s_HDRengg_group_seqno);
                            sValue = nvc_HDR["engg_impdefault"];
                            base.Parameters("@engg_hide_default", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_uisubtype"];
                            base.Parameters("@engg_uisubtype", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_nativeapp"];
                            base.Parameters("@engg_nativeapp", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_popup_close"];
                            base.Parameters("@engg_popup_close", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_titlebar_search"];
                            base.Parameters("@engg_titlebar_search", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HDR["engg_toptb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_toptb = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_toptb);
                            base.Parameters("@engg_toptb", DBType.Int, 32, s_HDRengg_toptb);
                            sValue = nvc_HDR["engg_bottomtb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_bottomtb = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_bottomtb);
                            base.Parameters("@engg_bottomtb", DBType.Int, 32, s_HDRengg_bottomtb);
                            sValue = nvc_HDR["engg_lefttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_lefttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_lefttb);
                            base.Parameters("@engg_lefttb", DBType.Int, 32, s_HDRengg_lefttb);
                            sValue = nvc_HDR["engg_righttb"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_righttb = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_righttb);
                            base.Parameters("@engg_righttb", DBType.Int, 32, s_HDRengg_righttb);
                            sValue = nvc_HDR["engg_att_sidebar"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_att_sidebar = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_att_sidebar);
                            base.Parameters("@engg_att_sidebar", DBType.Int, 32, s_HDRengg_att_sidebar);
                            sValue = nvc_HDR["engg_att_docked"];
                            base.Parameters("@engg_att_docked", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_cont_sec_type_bts"];
                            base.Parameters("@engg_cont_sec_type_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_sec_type_bts"];
                            base.Parameters("@engg_grid_sec_type_bts", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_grid_ctrl_type_bts"];
                            base.Parameters("@engg_grid_ctrl_type_bts", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluihref", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluihref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61830, 12, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61830, 12, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("_txt_interfacecontrol");
                                nvc_HDR["_txt_interfacecontrol"] = sValue;
                                sValue = this.GetValue("engg_act_descr_io");
                                nvc_HDR["engg_act_descr"] = sValue;
                                sValue = this.GetValue("engg_att_docked");
                                nvc_HDR["engg_att_docked"] = sValue;
                                sValue = this.GetValue("engg_att_sidebar");
                                nvc_HDR["engg_att_sidebar"] = sValue;
                                sValue = this.GetValue("engg_att_ui_cap_align_io");
                                nvc_HDR["engg_att_ui_cap_align"] = sValue;
                                sValue = this.GetValue("engg_att_ui_format_io");
                                nvc_HDR["engg_att_ui_format"] = sValue;
                                sValue = this.GetValue("engg_att_ui_grid_type");
                                nvc_HDR["engg_att_ui_grid_type"] = sValue;
                                sValue = this.GetValue("engg_att_ui_trail_bar_io");
                                nvc_HDR["engg_att_ui_trail_bar"] = sValue;
                                sValue = this.GetValue("engg_att_ui_type_io");
                                nvc_HDR["engg_att_ui_type"] = sValue;
                                sValue = this.GetValue("engg_bottomtb");
                                nvc_HDR["engg_bottomtb"] = sValue;
                                sValue = this.GetValue("engg_callout_type");
                                nvc_HDR["engg_callout_type"] = sValue;
                                sValue = this.GetValue("engg_component_io");
                                nvc_HDR["engg_component"] = sValue;
                                sValue = this.GetValue("engg_cont_sec_type_bts");
                                nvc_HDR["engg_cont_sec_type_bts"] = sValue;
                                sValue = this.GetValue("engg_control_name");
                                nvc_HDR["engg_control_name"] = sValue;
                                sValue = this.GetValue("engg_customer_name_io");
                                nvc_HDR["engg_customer_name"] = sValue;
                                sValue = this.GetValue("engg_desk_brw");
                                nvc_HDR["engg_desk_brw"] = sValue;
                                sValue = this.GetValue("engg_grid_ctrl_type_bts");
                                nvc_HDR["engg_grid_ctrl_type_bts"] = sValue;
                                sValue = this.GetValue("engg_grid_sec_type_bts");
                                nvc_HDR["engg_grid_sec_type_bts"] = sValue;
                                sValue = this.GetValue("engg_group_caption");
                                nvc_HDR["engg_group_caption"] = sValue;
                                sValue = this.GetValue("engg_group_name");
                                nvc_HDR["engg_group_name"] = sValue;
                                sValue = this.GetValue("engg_group_seqno");
                                nvc_HDR["engg_group_seqno"] = sValue;
                                sValue = this.GetValue("engg_hdrpersonalisation");
                                nvc_HDR["engg_hdrpersonalisation"] = sValue;
                                sValue = this.GetValue("engg_hide_default");
                                nvc_HDR["engg_impdefault"] = sValue;
                                sValue = this.GetValue("engg_hide_print");
                                nvc_HDR["engg_hide_print"] = sValue;
                                sValue = this.GetValue("engg_ilbotitle");
                                nvc_HDR["engg_ilbotitle"] = sValue;
                                sValue = this.GetValue("engg_isdevice");
                                nvc_HDR["engg_isdevice"] = sValue;
                                sValue = this.GetValue("engg_lefttb");
                                nvc_HDR["engg_lefttb"] = sValue;
                                sValue = this.GetValue("engg_nativeapp");
                                nvc_HDR["engg_nativeapp"] = sValue;
                                sValue = this.GetValue("engg_page_name");
                                nvc_HDR["engg_page_name"] = sValue;
                                sValue = this.GetValue("engg_phone");
                                nvc_HDR["engg_phone"] = sValue;
                                sValue = this.GetValue("engg_popup_close");
                                nvc_HDR["engg_popup_close"] = sValue;
                                sValue = this.GetValue("engg_process_descr_io");
                                nvc_HDR["engg_process_descr"] = sValue;
                                sValue = this.GetValue("engg_project_name_io");
                                nvc_HDR["engg_project_name"] = sValue;
                                sValue = this.GetValue("engg_req_no_io");
                                nvc_HDR["engg_req_no"] = sValue;
                                sValue = this.GetValue("engg_rf_act_io");
                                nvc_HDR["engg_rf_act"] = sValue;
                                sValue = this.GetValue("engg_rf_comp_io");
                                nvc_HDR["engg_rf_comp"] = sValue;
                                sValue = this.GetValue("engg_rf_ui_io");
                                nvc_HDR["engg_rf_ui"] = sValue;
                                sValue = this.GetValue("engg_righttb");
                                nvc_HDR["engg_righttb"] = sValue;
                                sValue = this.GetValue("engg_sect_name");
                                nvc_HDR["engg_sect_name"] = sValue;
                                sValue = this.GetValue("engg_smarthide");
                                nvc_HDR["engg_smarthide"] = sValue;
                                sValue = this.GetValue("engg_syst_excl_tab_ind");
                                nvc_HDR["engg_syst_excl_tab_ind"] = sValue;
                                sValue = this.GetValue("engg_tab_hdr_pos");
                                nvc_HDR["engg_tab_hdr_pos"] = sValue;
                                sValue = this.GetValue("engg_tab_height_io");
                                nvc_HDR["engg_tab_height"] = sValue;
                                sValue = this.GetValue("engg_tab_rotate");
                                nvc_HDR["engg_tab_rotate"] = sValue;
                                sValue = this.GetValue("engg_tab_style");
                                nvc_HDR["engg_tab_style"] = sValue;
                                sValue = this.GetValue("engg_tab_type");
                                nvc_HDR["engg_tab_type"] = sValue;
                                sValue = this.GetValue("engg_tablet");
                                nvc_HDR["engg_tablet"] = sValue;
                                sValue = this.GetValue("engg_titlebar_search");
                                nvc_HDR["engg_titlebar_search"] = sValue;
                                sValue = this.GetValue("engg_toptb");
                                nvc_HDR["engg_toptb"] = sValue;
                                sValue = this.GetValue("engg_ui_descr_io");
                                nvc_HDR["engg_ui_descr"] = sValue;
                                sValue = this.GetValue("engg_ui_laycon");
                                nvc_HDR["engg_ui_laycon"] = sValue;
                                sValue = this.GetValue("engg_ui_layout");
                                nvc_HDR["engg_ui_layout"] = sValue;
                                sValue = this.GetValue("engg_ui_name");
                                nvc_HDR["engg_ui_name"] = sValue;
                                sValue = this.GetValue("engg_uisubtype");
                                nvc_HDR["engg_uisubtype"] = sValue;
                                sValue = this.GetValue("ezee_taskpane");
                                nvc_HDR["ezee_taskpane"] = sValue;
                                sValue = this.GetValue("fprowno");
                                nvc_HDR["fprowno"] = sValue;
                                sValue = this.GetValue("guid_io");
                                nvc_HDR["guid"] = sValue;
                                sValue = this.GetValue("state_processing");
                                nvc_HDR["state_processing"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61830, 12, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 12
                // Starting to execute the BR - 2  under the process section - 12
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 12;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_seluiuihref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_name", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 12 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_uistatemto", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_uistatespo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115323, 12, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 115323, 12, 2);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("hdnrt_stcontrol");
                                nvc_HDR["hdnrt_stcontrol"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 12 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 115323, 12, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 12 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 12 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS13()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 13;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 13
                // Starting to execute the BR - 1  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluicnml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluicnml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61831, 13, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61831, 13, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htCNML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("accesskey");
                                    nvcTmp["accesskey"] = sValue;
                                    sValue = this.GetValue("cont_class_ext6");
                                    nvcTmp["cont_class_ext6"] = sValue;
                                    sValue = this.GetValue("ctrl_temp_cat");
                                    nvcTmp["ctrl_temp_cat"] = sValue;
                                    sValue = this.GetValue("ctrl_temp_specific");
                                    nvcTmp["ctrl_temp_specific"] = sValue;
                                    sValue = this.GetValue("engg_cont_btsynname");
                                    nvcTmp["engg_cont_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_cont_colspan");
                                    nvcTmp["engg_cont_colspan"] = sValue;
                                    sValue = this.GetValue("engg_cont_control_format");
                                    nvcTmp["engg_cont_control_format"] = sValue;
                                    sValue = this.GetValue("engg_cont_ctrlimg");
                                    nvcTmp["engg_cont_ctrlimg"] = sValue;
                                    sValue = this.GetValue("engg_cont_customaction");
                                    nvcTmp["engg_cont_customaction"] = sValue;
                                    sValue = this.GetValue("engg_cont_customborder");
                                    nvcTmp["engg_cont_customborder"] = sValue;
                                    sValue = this.GetValue("engg_cont_datawidth");
                                    nvcTmp["engg_cont_datawidth"] = sValue;
                                    sValue = this.GetValue("engg_cont_descr");
                                    nvcTmp["engg_cont_descr"] = sValue;
                                    sValue = this.GetValue("engg_cont_doc");
                                    nvcTmp["engg_cont_doc"] = sValue;
                                    sValue = this.GetValue("engg_cont_elem_type");
                                    nvcTmp["engg_cont_elem_type"] = sValue;
                                    sValue = this.GetValue("engg_cont_forresponsive");
                                    nvcTmp["engg_cont_forresponsive"] = sValue;
                                    sValue = this.GetValue("engg_cont_horder");
                                    nvcTmp["engg_cont_horder"] = sValue;
                                    sValue = this.GetValue("engg_cont_labwidth");
                                    nvcTmp["engg_cont_labwidth"] = sValue;
                                    sValue = this.GetValue("engg_cont_rowspan");
                                    nvcTmp["engg_cont_rowspan"] = sValue;
                                    sValue = this.GetValue("engg_cont_samp_data");
                                    nvcTmp["engg_cont_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_cont_sequence");
                                    nvcTmp["engg_cont_sequence"] = sValue;
                                    sValue = this.GetValue("engg_cont_tempid");
                                    nvcTmp["engg_cont_tempid"] = sValue;
                                    sValue = this.GetValue("engg_cont_tooltip");
                                    nvcTmp["engg_cont_tooltip"] = sValue;
                                    sValue = this.GetValue("engg_cont_vis_length");
                                    nvcTmp["engg_cont_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_cont_vorder");
                                    nvcTmp["engg_cont_vorder"] = sValue;
                                    sValue = this.GetValue("engg_control_class");
                                    nvcTmp["engg_cont_ctrlclass"] = sValue;
                                    sValue = this.GetValue("engg_control_image_class");
                                    nvcTmp["engg_cont_ctrlimgclass"] = sValue;
                                    sValue = this.GetValue("engg_dynamicstyle");
                                    nvcTmp["engg_dynamicstyle"] = sValue;
                                    sValue = this.GetValue("engg_extension");
                                    nvcTmp["engg_extension"] = sValue;
                                    sValue = this.GetValue("engg_extnreqd");
                                    nvcTmp["engg_extnreqd"] = sValue;
                                    sValue = this.GetValue("engg_imageasdata");
                                    nvcTmp["engg_imageasdata"] = sValue;
                                    sValue = this.GetValue("engg_label_class");
                                    nvcTmp["engg_cont_labclass"] = sValue;
                                    sValue = this.GetValue("engg_label_image_class");
                                    nvcTmp["engg_cont_labimgclass"] = sValue;
                                    sValue = this.GetValue("engg_msc_ass_control");
                                    nvcTmp["engg_msc_ass_control"] = sValue;
                                    sValue = this.GetValue("engg_tab_sequence");
                                    nvcTmp["engg_cont_tabseq"] = sValue;
                                    sValue = this.GetValue("engg_tab_stopforhelp");
                                    nvcTmp["engg_cont_helptabstop"] = sValue;
                                    sValue = this.GetValue("freezecount");
                                    nvcTmp["freezecount"] = sValue;
                                    sValue = this.GetValue("icon_class");
                                    nvcTmp["icon_class"] = sValue;
                                    sValue = this.GetValue("icon_position");
                                    nvcTmp["icon_position"] = sValue;
                                    sValue = this.GetValue("set_user_pref");
                                    nvcTmp["set_user_pref"] = sValue;
                                    htCNML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61831, 13, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 2  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluienml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluienml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61832, 13, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61832, 13, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htENML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_enum_caption");
                                    nvcTmp["engg_enum_caption"] = sValue;
                                    sValue = this.GetValue("engg_enum_code");
                                    nvcTmp["engg_enum_code"] = sValue;
                                    sValue = this.GetValue("engg_enum_default");
                                    nvcTmp["engg_enum_default"] = sValue;
                                    sValue = this.GetValue("engg_enum_seq");
                                    nvcTmp["engg_enum_seq"] = sValue;
                                    htENML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61832, 13, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 3  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigdml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigdml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61833, 13, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61833, 13, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGDML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("col_associate_ctrl");
                                    nvcTmp["col_associate_ctrl"] = sValue;
                                    sValue = this.GetValue("col_class_ext6");
                                    nvcTmp["col_class_ext6"] = sValue;
                                    sValue = this.GetValue("col_compact_view");
                                    nvcTmp["col_compact_view"] = sValue;
                                    sValue = this.GetValue("col_icon_class");
                                    nvcTmp["col_icon_class"] = sValue;
                                    sValue = this.GetValue("col_icon_position");
                                    nvcTmp["col_icon_position"] = sValue;
                                    sValue = this.GetValue("col_temp_cat");
                                    nvcTmp["col_temp_cat"] = sValue;
                                    sValue = this.GetValue("col_temp_specific");
                                    nvcTmp["col_temp_specific"] = sValue;
                                    sValue = this.GetValue("col_transform_as");
                                    nvcTmp["col_transform_as"] = sValue;
                                    sValue = this.GetValue("columnclass");
                                    nvcTmp["columnclass"] = sValue;
                                    sValue = this.GetValue("engg_col_descr");
                                    nvcTmp["engg_col_descr"] = sValue;
                                    sValue = this.GetValue("engg_col_tempid");
                                    nvcTmp["engg_col_tempid"] = sValue;
                                    sValue = this.GetValue("engg_extensionorder");
                                    nvcTmp["engg_extensionorder"] = sValue;
                                    sValue = this.GetValue("engg_extensionreqd");
                                    nvcTmp["engg_extensionreqd"] = sValue;
                                    sValue = this.GetValue("engg_formenabled");
                                    nvcTmp["formenabled"] = sValue;
                                    sValue = this.GetValue("engg_grd_visible");
                                    nvcTmp["engg_grd_visible"] = sValue;
                                    sValue = this.GetValue("engg_grid_btsynname");
                                    nvcTmp["engg_grid_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_grid_colno");
                                    nvcTmp["engg_grid_colno"] = sValue;
                                    sValue = this.GetValue("engg_grid_default");
                                    nvcTmp["engg_grid_default"] = sValue;
                                    sValue = this.GetValue("engg_grid_doc");
                                    nvcTmp["engg_grid_doc"] = sValue;
                                    sValue = this.GetValue("engg_grid_elem_type");
                                    nvcTmp["engg_grid_elem_type"] = sValue;
                                    sValue = this.GetValue("engg_grid_samp_data");
                                    nvcTmp["engg_grid_samp_data"] = sValue;
                                    sValue = this.GetValue("engg_grid_tooltip");
                                    nvcTmp["engg_grid_tooltip"] = sValue;
                                    sValue = this.GetValue("engg_grid_vis_length");
                                    nvcTmp["engg_grid_vis_length"] = sValue;
                                    sValue = this.GetValue("engg_rowexpander");
                                    nvcTmp["rowexpander"] = sValue;
                                    sValue = this.GetValue("engg_tree_column");
                                    nvcTmp["engg_tree_column"] = sValue;
                                    sValue = this.GetValue("forcefit");
                                    nvcTmp["forcefit"] = sValue;
                                    htGDML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61833, 13, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 4  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilyml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluilyml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61834, 13, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61834, 13, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLYML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_lay_horder");
                                    nvcTmp["engg_lay_horder"] = sValue;
                                    sValue = this.GetValue("engg_lay_parent_sec");
                                    nvcTmp["engg_lay_parent_sec"] = sValue;
                                    sValue = this.GetValue("engg_lay_sec_name");
                                    nvcTmp["engg_lay_sec_name"] = sValue;
                                    sValue = this.GetValue("engg_lay_sec_position");
                                    nvcTmp["engg_lay_sec_position"] = sValue;
                                    sValue = this.GetValue("engg_lay_vorder");
                                    nvcTmp["engg_lay_vorder"] = sValue;
                                    htLYML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61834, 13, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 5  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilnkml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluilnkml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61835, 13, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61835, 13, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLNKML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_launch_type");
                                    nvcTmp["engg_launch_type"] = sValue;
                                    sValue = this.GetValue("engg_links_asso_ctrl");
                                    nvcTmp["engg_links_assoctrl"] = sValue;
                                    sValue = this.GetValue("engg_links_height");
                                    nvcTmp["engg_links_height"] = sValue;
                                    sValue = this.GetValue("engg_links_link_act");
                                    nvcTmp["engg_links_link_act"] = sValue;
                                    sValue = this.GetValue("engg_links_link_comp");
                                    nvcTmp["engg_links_link_comp"] = sValue;
                                    sValue = this.GetValue("engg_links_link_type");
                                    nvcTmp["engg_links_link_type"] = sValue;
                                    sValue = this.GetValue("engg_links_link_ui");
                                    nvcTmp["engg_links_link_ui"] = sValue;
                                    sValue = this.GetValue("engg_links_pcv_caption");
                                    nvcTmp["engg_links_pcv_caption"] = sValue;
                                    sValue = this.GetValue("engg_links_width");
                                    nvcTmp["engg_links_width"] = sValue;
                                    sValue = this.GetValue("engg_toolbar_notreq");
                                    nvcTmp["engg_toolbar_notreq"] = sValue;
                                    htLNKML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61835, 13, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 6  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluipgml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluipgml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61836, 13, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61836, 13, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPGML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_hdr_pos");
                                    nvcTmp["engg_hdr_pos"] = sValue;
                                    sValue = this.GetValue("engg_pag_lay_con");
                                    nvcTmp["engg_pag_lay_con"] = sValue;
                                    sValue = this.GetValue("engg_page_bottomtb");
                                    nvcTmp["engg_page_bottomtb"] = sValue;
                                    sValue = this.GetValue("engg_page_btsynname");
                                    nvcTmp["engg_page_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_page_descr");
                                    nvcTmp["engg_page_descr"] = sValue;
                                    sValue = this.GetValue("engg_page_doc");
                                    nvcTmp["engg_page_doc"] = sValue;
                                    sValue = this.GetValue("engg_page_horder");
                                    nvcTmp["engg_page_horder"] = sValue;
                                    sValue = this.GetValue("engg_page_img");
                                    nvcTmp["engg_page_img"] = sValue;
                                    sValue = this.GetValue("engg_page_lay");
                                    nvcTmp["engg_page_lay"] = sValue;
                                    sValue = this.GetValue("engg_page_lefttb");
                                    nvcTmp["engg_page_lefttb"] = sValue;
                                    sValue = this.GetValue("engg_page_righttb");
                                    nvcTmp["engg_page_righttb"] = sValue;
                                    sValue = this.GetValue("engg_page_toptb");
                                    nvcTmp["engg_page_toptb"] = sValue;
                                    sValue = this.GetValue("engg_page_type");
                                    nvcTmp["engg_page_type"] = sValue;
                                    sValue = this.GetValue("engg_page_vorder");
                                    nvcTmp["engg_page_vorder"] = sValue;
                                    sValue = this.GetValue("engg_tab_icon_pos");
                                    nvcTmp["engg_tab_icon_pos"] = sValue;
                                    sValue = this.GetValue("engg_tab_rot");
                                    nvcTmp["engg_tab_rot"] = sValue;
                                    sValue = this.GetValue("engg_tab_title_st");
                                    nvcTmp["engg_tab_title_st"] = sValue;
                                    htPGML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61836, 13, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 7  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluirdml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluirdml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61837, 13, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61837, 13, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRDML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_radio_caption");
                                    nvcTmp["engg_radio_caption"] = sValue;
                                    sValue = this.GetValue("engg_radio_code");
                                    nvcTmp["engg_radio_code"] = sValue;
                                    sValue = this.GetValue("engg_radio_default");
                                    nvcTmp["engg_radio_default"] = sValue;
                                    sValue = this.GetValue("engg_radio_horder");
                                    nvcTmp["engg_radio_horder"] = sValue;
                                    sValue = this.GetValue("engg_radio_seq");
                                    nvcTmp["engg_radio_seq"] = sValue;
                                    sValue = this.GetValue("engg_radio_vorder");
                                    nvcTmp["engg_radio_vorder"] = sValue;
                                    htRDML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61837, 13, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 8  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 8;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 8 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluiscml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluiscml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61838, 13, 8);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61838, 13, 8);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htSCML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_associatedcontrol");
                                    nvcTmp["engg_associatedcontrol"] = sValue;
                                    sValue = this.GetValue("engg_col_dir");
                                    nvcTmp["engg_col_dir"] = sValue;
                                    sValue = this.GetValue("engg_mob_fullview");
                                    nvcTmp["engg_mob_fullview"] = sValue;
                                    sValue = this.GetValue("engg_mob_responsive");
                                    nvcTmp["engg_mob_responsive"] = sValue;
                                    sValue = this.GetValue("engg_region");
                                    nvcTmp["engg_region"] = sValue;
                                    sValue = this.GetValue("engg_sec_bord_req");
                                    nvcTmp["engg_sec_bord_req"] = sValue;
                                    sValue = this.GetValue("engg_sec_bottomtb");
                                    nvcTmp["engg_sec_bottomtb"] = sValue;
                                    sValue = this.GetValue("engg_sec_btsynname");
                                    nvcTmp["engg_sec_btsynname"] = sValue;
                                    sValue = this.GetValue("engg_sec_cap_align");
                                    nvcTmp["engg_sec_cap_align"] = sValue;
                                    sValue = this.GetValue("engg_sec_cap_format");
                                    nvcTmp["engg_sec_cap_format"] = sValue;
                                    sValue = this.GetValue("engg_sec_customborder");
                                    nvcTmp["engg_sec_customborder"] = sValue;
                                    sValue = this.GetValue("engg_sec_descr");
                                    nvcTmp["engg_sec_descr"] = sValue;
                                    sValue = this.GetValue("engg_sec_height");
                                    nvcTmp["sectionheight"] = sValue;
                                    sValue = this.GetValue("engg_sec_lay_con");
                                    nvcTmp["engg_sec_lay_con"] = sValue;
                                    sValue = this.GetValue("engg_sec_lefttb");
                                    nvcTmp["engg_sec_lefttb"] = sValue;
                                    sValue = this.GetValue("engg_sec_minrows");
                                    nvcTmp["engg_sec_minrows"] = sValue;
                                    sValue = this.GetValue("engg_sec_prefix_class");
                                    nvcTmp["engg_sec_secpreclass"] = sValue;
                                    sValue = this.GetValue("engg_sec_righttb");
                                    nvcTmp["engg_sec_righttb"] = sValue;
                                    sValue = this.GetValue("engg_sec_title_align");
                                    nvcTmp["engg_sec_title_align"] = sValue;
                                    sValue = this.GetValue("engg_sec_title_req");
                                    nvcTmp["engg_sec_title_req"] = sValue;
                                    sValue = this.GetValue("engg_sec_titleaction");
                                    nvcTmp["engg_sec_titleaction"] = sValue;
                                    sValue = this.GetValue("engg_sec_titleicon");
                                    nvcTmp["engg_sec_titleicon"] = sValue;
                                    sValue = this.GetValue("engg_sec_toptb");
                                    nvcTmp["engg_sec_toptb"] = sValue;
                                    sValue = this.GetValue("engg_sec_type");
                                    nvcTmp["engg_sec_type"] = sValue;
                                    sValue = this.GetValue("engg_sec_visible");
                                    nvcTmp["engg_sec_visible"] = sValue;
                                    sValue = this.GetValue("engg_sec_vwmode");
                                    nvcTmp["engg_sec_vwmode"] = sValue;
                                    sValue = this.GetValue("engg_sec_width");
                                    nvcTmp["sectionwidth"] = sValue;
                                    sValue = this.GetValue("engg_sect_doc");
                                    nvcTmp["engg_sect_doc"] = sValue;
                                    sValue = this.GetValue("engg_sect_forresponsive");
                                    nvcTmp["engg_sect_forresponsive"] = sValue;
                                    sValue = this.GetValue("engg_sect_lay");
                                    nvcTmp["engg_sect_lay"] = sValue;
                                    sValue = this.GetValue("engg_title_pos");
                                    nvcTmp["engg_title_pos"] = sValue;
                                    sValue = this.GetValue("sec_collapse");
                                    nvcTmp["sec_collapse"] = sValue;
                                    sValue = this.GetValue("sec_collapsemode");
                                    nvcTmp["sec_collapsemode"] = sValue;
                                    sValue = this.GetValue("section_colspan");
                                    nvcTmp["section_colspan"] = sValue;
                                    sValue = this.GetValue("section_rowspan");
                                    nvcTmp["section_rowspan"] = sValue;
                                    htSCML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 8", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61838, 13, 8);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 13
                // Starting to execute the BR - 9  under the process section - 13
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 13;
                brSeqNo = 9;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_ref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr", DBType.NVarchar, 255, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 13 BR - 9 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigrpml_o", nLoop, nMax));
                        base.Execute_SP(true, "ep_layout_sp_seluigrpml_o", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114813, 13, 9);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 114813, 13, 9);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htGRPML_MLO.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_col_or_group");
                                    nvcTmp["engg_col_or_group"] = sValue;
                                    sValue = this.GetValue("engg_map_seq");
                                    nvcTmp["engg_map_seq"] = sValue;
                                    sValue = this.GetValue("engg_mapped_entity");
                                    nvcTmp["engg_mapped_entity"] = sValue;
                                    sValue = this.GetValue("engg_ui_map");
                                    nvcTmp["engg_ui_map"] = sValue;
                                    htGRPML_MLO[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 13 BR - 9", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 114813, 13, 9);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 13 BR - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 13 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_cnml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluicnml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluicnml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61806, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61806, 2, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_enml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluienml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluienml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61807, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61807, 3, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS4()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 4;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 4
                // Starting to execute the BR - 1  under the process section - 4
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 4;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_gdml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 4 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluigdml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluigdml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61808, 4, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61808, 4, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 4 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS5()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 5;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 5
                // Starting to execute the BR - 1  under the process section - 5
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 5;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_lyml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 5 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilyml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluilyml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61809, 5, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61809, 5, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 5 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS6()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 6;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 6
                // Starting to execute the BR - 1  under the process section - 6
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 6;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_lnkml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 6 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluilnkml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluilnkml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61810, 6, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61810, 6, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 6 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS7()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 7;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 7
                // Starting to execute the BR - 1  under the process section - 7
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 7;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_pgml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 7 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluipgml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluipgml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61811, 7, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61811, 7, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 7 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS8()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 8;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 8
                // Starting to execute the BR - 1  under the process section - 8
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 8;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_rdml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 8 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluirdml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluirdml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61812, 8, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61812, 8, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 8 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 8 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS9()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 9;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 9
                // Starting to execute the BR - 1  under the process section - 9
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 9;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_ps_selui_scml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_language_in", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_ouinstance_in", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_service_in", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_user_in", DBType.NVarchar, 30, szUser);
                            sValue = nvc_HDR["engg_act_descr"];
                            base.Parameters("@engg_act_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_cap_align"];
                            base.Parameters("@engg_att_ui_cap_align_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_format"];
                            base.Parameters("@engg_att_ui_format_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_att_ui_trail_bar"];
                            base.Parameters("@engg_att_ui_trail_bar_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_att_ui_type"];
                            base.Parameters("@engg_att_ui_type_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_component"];
                            base.Parameters("@engg_component_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_customer_name"];
                            base.Parameters("@engg_customer_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_process_descr"];
                            base.Parameters("@engg_process_descr_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_project_name"];
                            base.Parameters("@engg_project_name_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_req_no"];
                            base.Parameters("@engg_req_no_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["engg_rf_act"];
                            base.Parameters("@engg_rf_act_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_comp"];
                            base.Parameters("@engg_rf_comp_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_rf_ui"];
                            base.Parameters("@engg_rf_ui_in", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HDR["engg_tab_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRengg_tab_height = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRengg_tab_height);
                            base.Parameters("@engg_tab_height_in", DBType.Int, 32, s_HDRengg_tab_height);
                            sValue = nvc_HDR["engg_ui_descr"];
                            base.Parameters("@engg_ui_descr_in", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HDR["fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HDRfprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HDRfprowno);
                            base.Parameters("@fprowno_in", DBType.Int, 32, s_HDRfprowno);
                            sValue = nvc_HDR["guid"];
                            base.Parameters("@guid_in", DBType.NVarchar, 128, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 9 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_layout_mt_seluiscml", nLoop, nMax));
                        base.Execute_SP(false, "ep_layout_sp_seluiscml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 61813, 9, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 61813, 9, 1);
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 9 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 9 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "ct_pg_cb":
                            Localtable = (NameValueCollection)htCT_PG_CB[lInstance];
                            break;
                        case "ct_sec_cb":
                            Localtable = (NameValueCollection)htCT_SEC_CB[lInstance];
                            break;
                        case "en_bts_cb":
                            Localtable = (NameValueCollection)htEN_BTS_CB[lInstance];
                            break;
                        case "en_pg_cb":
                            Localtable = (NameValueCollection)htEN_PG_CB[lInstance];
                            break;
                        case "en_sec_cb":
                            Localtable = (NameValueCollection)htEN_SEC_CB[lInstance];
                            break;
                        case "g_grid_cb":
                            Localtable = (NameValueCollection)htG_GRID_CB[lInstance];
                            break;
                        case "gd_pg_cb":
                            Localtable = (NameValueCollection)htGD_PG_CB[lInstance];
                            break;
                        case "gd_sec_cb":
                            Localtable = (NameValueCollection)htGD_SEC_CB[lInstance];
                            break;
                        case "grpct_cb":
                            Localtable = (NameValueCollection)htGRPCT_CB[lInstance];
                            break;
                        case "grpgrp_cb":
                            Localtable = (NameValueCollection)htGRPGRP_CB[lInstance];
                            break;
                        case "grppg_cb":
                            Localtable = (NameValueCollection)htGRPPG_CB[lInstance];
                            break;
                        case "grpsc_cb":
                            Localtable = (NameValueCollection)htGRPSC_CB[lInstance];
                            break;
                        case "lay_pg_cb":
                            Localtable = (NameValueCollection)htLAY_PG_CB[lInstance];
                            break;
                        case "lnk_pg_cb":
                            Localtable = (NameValueCollection)htLNK_PG_CB[lInstance];
                            break;
                        case "parsec_mcb":
                            Localtable = (NameValueCollection)htPARSEC_MCB[lInstance];
                            break;
                        case "rd_bts_cb":
                            Localtable = (NameValueCollection)htRD_BTS_CB[lInstance];
                            break;
                        case "rd_pg_cb":
                            Localtable = (NameValueCollection)htRD_PG_CB[lInstance];
                            break;
                        case "rd_sec_cb":
                            Localtable = (NameValueCollection)htRD_SEC_CB[lInstance];
                            break;
                        case "sec_pg_cb":
                            Localtable = (NameValueCollection)htSEC_PG_CB[lInstance];
                            break;
                        case "_hdr":
                            Localtable = nvc_HDR;
                            break;
                        case "cb_hdr":
                            Localtable = nvcCB_HDR;
                            break;
                        case "cnml_mlo":
                            Localtable = (NameValueCollection)htCNML_MLO[lInstance];
                            break;
                        case "enml_mlo":
                            Localtable = (NameValueCollection)htENML_MLO[lInstance];
                            break;
                        case "gdml_mlo":
                            Localtable = (NameValueCollection)htGDML_MLO[lInstance];
                            break;
                        case "grpml_mlo":
                            Localtable = (NameValueCollection)htGRPML_MLO[lInstance];
                            break;
                        case "lnkml_mlo":
                            Localtable = (NameValueCollection)htLNKML_MLO[lInstance];
                            break;
                        case "lyml_mlo":
                            Localtable = (NameValueCollection)htLYML_MLO[lInstance];
                            break;
                        case "pgml_mlo":
                            Localtable = (NameValueCollection)htPGML_MLO[lInstance];
                            break;
                        case "rdml_mlo":
                            Localtable = (NameValueCollection)htRDML_MLO[lInstance];
                            break;
                        case "scml_mlo":
                            Localtable = (NameValueCollection)htSCML_MLO[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_layout_sr_selui(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_layout_sr_selui(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_layout_sr_selui.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

