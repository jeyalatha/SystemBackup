/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cep_laymngsrseclay.cs
Code Generated From      :   ramco\PLF\Prw_ECR_00383\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.preview.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.preview.ehs;

    public class Cep_laymngsrseclay : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Specialized.NameValueCollection nvcSECGRDUIML = new System.Collections.Specialized.NameValueCollection();
        private string sSECGRDUIMLep_lay_sec_height = "0";
        private string sSECGRDUIMLep_lay_sec_hord = "0";
        private string sSECGRDUIMLep_lay_sec_vord = "0";
        private string sSECGRDUIMLep_lay_sec_wid = "0";
        private string modeFlagValue = string.Empty;
        public Cep_laymngsrseclay()
        {
            base.iEDKESEngineInit("ep_laymngsrseclay", "preview");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("ep_lay_sec_page", System.Convert.ToString(nvc_HSEG["ep_lay_sec_page"]));
                    this.writer.WriteAttributeString("ep_lay_sect_def", System.Convert.ToString(nvc_HSEG["ep_lay_sect_def"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.nvcSECGRDUIML != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("secgrduiml", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("secgrduiml");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_sec_secpreclass", System.Convert.ToString(nvcSECGRDUIML["engg_sec_secpreclass"]));
                    this.writer.WriteAttributeString("ep_lay_cap_algn", System.Convert.ToString(nvcSECGRDUIML["ep_lay_cap_algn"]));
                    this.writer.WriteAttributeString("ep_lay_cap_for", System.Convert.ToString(nvcSECGRDUIML["ep_lay_cap_for"]));
                    this.writer.WriteAttributeString("ep_lay_region", System.Convert.ToString(nvcSECGRDUIML["ep_lay_region"]));
                    this.writer.WriteAttributeString("ep_lay_sec_bord", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_bord"]));
                    this.writer.WriteAttributeString("ep_lay_sec_coldir", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_coldir"]));
                    this.writer.WriteAttributeString("ep_lay_sec_height", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_height"]));
                    this.writer.WriteAttributeString("ep_lay_sec_hord", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_hord"]));
                    this.writer.WriteAttributeString("ep_lay_sec_lay", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_lay"]));
                    this.writer.WriteAttributeString("ep_lay_sec_map", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_map"]));
                    this.writer.WriteAttributeString("ep_lay_sec_nam", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_nam"]));
                    this.writer.WriteAttributeString("ep_lay_sec_titalgn", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_titalgn"]));
                    this.writer.WriteAttributeString("ep_lay_sec_titl", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_titl"]));
                    this.writer.WriteAttributeString("ep_lay_sec_titpos", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_titpos"]));
                    this.writer.WriteAttributeString("ep_lay_sec_titreq", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_titreq"]));
                    this.writer.WriteAttributeString("ep_lay_sec_typ", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_typ"]));
                    this.writer.WriteAttributeString("ep_lay_sec_vord", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_vord"]));
                    this.writer.WriteAttributeString("ep_lay_sec_wid", System.Convert.ToString(nvcSECGRDUIML["ep_lay_sec_wid"]));
                    this.writer.WriteAttributeString("ep_sec_lay_con", System.Convert.ToString(nvcSECGRDUIML["ep_sec_lay_con"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("secgrduiml", nvcSECGRDUIML);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "ep_lay_sec_page":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sect_def":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "secgrduiml":
                        switch (DataItem)
                        {
                            case "engg_sec_secpreclass":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_cap_algn":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_cap_for":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_region":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_bord":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_coldir":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_height":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_lay_sec_hord":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_lay_sec_lay":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_map":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_nam":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_titalgn":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_titl":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_titpos":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_titreq":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_typ":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ep_lay_sec_vord":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_lay_sec_wid":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "ep_sec_lay_con":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvcSECGRDUIML[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvcSECGRDUIML[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    type = 0;
                    break;
                case "secgrduiml":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                case "secgrduiml":
                    return this.nvcSECGRDUIML;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "secgrduiml":
                        return nvcSECGRDUIML[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                nvc_HSEG["ep_lay_sect_def"] = (nvc_HSEG["ep_lay_sect_def"] == null) ? "~#~" : nvc_HSEG["ep_lay_sect_def"];
                nvc_HSEG["ep_lay_sec_page"] = (nvc_HSEG["ep_lay_sec_page"] == null) ? "~#~" : nvc_HSEG["ep_lay_sec_page"];
                nvcSECGRDUIML["ep_lay_sec_map"] = (nvcSECGRDUIML["ep_lay_sec_map"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_map"];
                nvcSECGRDUIML["ep_lay_sec_lay"] = (nvcSECGRDUIML["ep_lay_sec_lay"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_lay"];
                nvcSECGRDUIML["ep_lay_sec_titl"] = (nvcSECGRDUIML["ep_lay_sec_titl"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_titl"];
                nvcSECGRDUIML["ep_lay_sec_coldir"] = (nvcSECGRDUIML["ep_lay_sec_coldir"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_coldir"];
                nvcSECGRDUIML["ep_lay_sec_wid"] = (nvcSECGRDUIML["ep_lay_sec_wid"] == null) ? "-915" : nvcSECGRDUIML["ep_lay_sec_wid"];
                nvcSECGRDUIML["engg_sec_secpreclass"] = (nvcSECGRDUIML["engg_sec_secpreclass"] == null) ? "~#~" : nvcSECGRDUIML["engg_sec_secpreclass"];
                nvcSECGRDUIML["ep_lay_sec_bord"] = (nvcSECGRDUIML["ep_lay_sec_bord"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_bord"];
                nvcSECGRDUIML["ep_lay_sec_typ"] = (nvcSECGRDUIML["ep_lay_sec_typ"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_typ"];
                nvcSECGRDUIML["ep_lay_sec_height"] = (nvcSECGRDUIML["ep_lay_sec_height"] == null) ? "-915" : nvcSECGRDUIML["ep_lay_sec_height"];
                nvcSECGRDUIML["ep_sec_lay_con"] = (nvcSECGRDUIML["ep_sec_lay_con"] == null) ? "~#~" : nvcSECGRDUIML["ep_sec_lay_con"];
                nvcSECGRDUIML["ep_lay_region"] = (nvcSECGRDUIML["ep_lay_region"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_region"];
                nvcSECGRDUIML["ep_lay_sec_hord"] = (nvcSECGRDUIML["ep_lay_sec_hord"] == null) ? "-915" : nvcSECGRDUIML["ep_lay_sec_hord"];
                nvcSECGRDUIML["ep_lay_sec_titpos"] = (nvcSECGRDUIML["ep_lay_sec_titpos"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_titpos"];
                nvcSECGRDUIML["ep_lay_cap_for"] = (nvcSECGRDUIML["ep_lay_cap_for"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_cap_for"];
                nvcSECGRDUIML["ep_lay_sec_vord"] = (nvcSECGRDUIML["ep_lay_sec_vord"] == null) ? "-915" : nvcSECGRDUIML["ep_lay_sec_vord"];
                nvcSECGRDUIML["ep_lay_sec_nam"] = (nvcSECGRDUIML["ep_lay_sec_nam"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_nam"];
                nvcSECGRDUIML["ep_lay_sec_titreq"] = (nvcSECGRDUIML["ep_lay_sec_titreq"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_titreq"];
                nvcSECGRDUIML["ep_lay_cap_algn"] = (nvcSECGRDUIML["ep_lay_cap_algn"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_cap_algn"];
                nvcSECGRDUIML["ep_lay_sec_titalgn"] = (nvcSECGRDUIML["ep_lay_sec_titalgn"] == null) ? "~#~" : nvcSECGRDUIML["ep_lay_sec_titalgn"];
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "Prw_ECR_00383", null);
                }
                base.WriteProfiler(String.Format("Service ep_laymngsrseclay Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service ep_laymngsrseclay Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psseclay");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["engg_sec_secpreclass"];
                            base.Parameters("@engg_sec_secpreclass", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_cap_algn"];
                            base.Parameters("@ep_lay_cap_algn", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_cap_for"];
                            base.Parameters("@ep_lay_cap_for", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_region"];
                            base.Parameters("@ep_lay_region", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_bord"];
                            base.Parameters("@ep_lay_sec_bord", DBType.NVarchar, 5, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_coldir"];
                            base.Parameters("@ep_lay_sec_coldir", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_height"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sSECGRDUIMLep_lay_sec_height = (Double.TryParse(sValue, out result) == true ? sValue : sSECGRDUIMLep_lay_sec_height);
                            base.Parameters("@ep_lay_sec_height", DBType.Int, 32, sSECGRDUIMLep_lay_sec_height);
                            sValue = nvcSECGRDUIML["ep_lay_sec_hord"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sSECGRDUIMLep_lay_sec_hord = (Double.TryParse(sValue, out result) == true ? sValue : sSECGRDUIMLep_lay_sec_hord);
                            base.Parameters("@ep_lay_sec_hord", DBType.Int, 32, sSECGRDUIMLep_lay_sec_hord);
                            sValue = nvcSECGRDUIML["ep_lay_sec_lay"];
                            base.Parameters("@ep_lay_sec_lay", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_map"];
                            base.Parameters("@ep_lay_sec_map", DBType.NVarchar, 5, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_nam"];
                            base.Parameters("@ep_lay_sec_nam", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_titalgn"];
                            base.Parameters("@ep_lay_sec_titalgn", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_titl"];
                            base.Parameters("@ep_lay_sec_titl", DBType.NVarchar, 255, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_titpos"];
                            base.Parameters("@ep_lay_sec_titpos", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_titreq"];
                            base.Parameters("@ep_lay_sec_titreq", DBType.NVarchar, 5, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_typ"];
                            base.Parameters("@ep_lay_sec_typ", DBType.NVarchar, 60, sValue);
                            sValue = nvcSECGRDUIML["ep_lay_sec_vord"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sSECGRDUIMLep_lay_sec_vord = (Double.TryParse(sValue, out result) == true ? sValue : sSECGRDUIMLep_lay_sec_vord);
                            base.Parameters("@ep_lay_sec_vord", DBType.Int, 32, sSECGRDUIMLep_lay_sec_vord);
                            sValue = nvcSECGRDUIML["ep_lay_sec_wid"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            sSECGRDUIMLep_lay_sec_wid = (Double.TryParse(sValue, out result) == true ? sValue : sSECGRDUIMLep_lay_sec_wid);
                            base.Parameters("@ep_lay_sec_wid", DBType.Int, 32, sSECGRDUIMLep_lay_sec_wid);
                            sValue = nvcSECGRDUIML["ep_sec_lay_con"];
                            base.Parameters("@ep_sec_lay_con", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtseclayumseclay", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspseclayumseclay", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 113497, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 113497, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_sec_secpreclass");
                                nvcSECGRDUIML["engg_sec_secpreclass"] = sValue;
                                sValue = this.GetValue("ep_lay_cap_algn");
                                nvcSECGRDUIML["ep_lay_cap_algn"] = sValue;
                                sValue = this.GetValue("ep_lay_cap_for");
                                nvcSECGRDUIML["ep_lay_cap_for"] = sValue;
                                sValue = this.GetValue("ep_lay_region");
                                nvcSECGRDUIML["ep_lay_region"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_bord");
                                nvcSECGRDUIML["ep_lay_sec_bord"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_coldir");
                                nvcSECGRDUIML["ep_lay_sec_coldir"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_height");
                                nvcSECGRDUIML["ep_lay_sec_height"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_hord");
                                nvcSECGRDUIML["ep_lay_sec_hord"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_lay");
                                nvcSECGRDUIML["ep_lay_sec_lay"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_map");
                                nvcSECGRDUIML["ep_lay_sec_map"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_nam");
                                nvcSECGRDUIML["ep_lay_sec_nam"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_titalgn");
                                nvcSECGRDUIML["ep_lay_sec_titalgn"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_titl");
                                nvcSECGRDUIML["ep_lay_sec_titl"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_titpos");
                                nvcSECGRDUIML["ep_lay_sec_titpos"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_titreq");
                                nvcSECGRDUIML["ep_lay_sec_titreq"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_typ");
                                nvcSECGRDUIML["ep_lay_sec_typ"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_vord");
                                nvcSECGRDUIML["ep_lay_sec_vord"] = sValue;
                                sValue = this.GetValue("ep_lay_sec_wid");
                                nvcSECGRDUIML["ep_lay_sec_wid"] = sValue;
                                sValue = this.GetValue("ep_sec_lay_con");
                                nvcSECGRDUIML["ep_sec_lay_con"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 113497, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("ep_psseclayhpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["ep_lay_sect_def"];
                            base.Parameters("@ep_lay_sect_def", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["ep_lay_sec_page"];
                            base.Parameters("@ep_lay_sec_page", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of ep_laymngmtseclayhdrref", nLoop, nMax));
                        base.Execute_SP(true, "ep_laymngspseclayhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 113496, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 113496, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("ep_lay_sec_page");
                                nvc_HSEG["ep_lay_sec_page"] = sValue;
                                sValue = this.GetValue("ep_lay_sect_def");
                                nvc_HSEG["ep_lay_sect_def"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 113496, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "secgrduiml":
                            Localtable = nvcSECGRDUIML;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSep_laymngsrseclay(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSep_laymngsrseclay(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\ep_laymngsrseclay.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

