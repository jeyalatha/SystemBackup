IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='re_ecr_sp_dnldecr' AND TYPE = 'P')
    Begin
        Drop PROC re_ecr_sp_dnldecr
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	27 Aug 2019
Purpose 		re_ecr_sp_dnldecr.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/*      V E R S I O N      :  PNR2.0_1403             */
/*      Released By        :  Development Team            */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/********************************************************************************/
/* procedure    : re_ecr_sp_dnldecr                   */
/* description  : Download ECR                                                  */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vijay kumar                                                   */
/* date         : 19/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* Modified by            Date                           Description            */
/* SriSaravanaKumar       28-Jul-2005                    PNR2.0_3393        */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3386                */
/* Modified on : 01/08/05                         */
/* Description : Add Component Description, Activity Description and Task Description in Glossary.*/
/* Modified by : Shriram V for callid PNR2.0_3616              */
/* Modified on : 22/08/05                         */
/* Description : Length of BT Synonym Caption should not Exceed 60 Characters-  */
/*Validation to be put in RCN download/Publish and ECR download/Publish     */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Sangeetha L                        */
/* Modified on : 20-Jan-2006                         */
/* Bug Id      : PNR2.0_5621                                                    */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Sangeetha L                        */
/* Modified on : 02-Feb-2006                         */
/* Bug Id      : PNR2.0_5941                                                    */
/********************************************************************************/
/* Modified by : Gowrisankar for PNR2.0_7343                */
/* Modified on : 20-Mar-2006                         */
/* Bug Id      : UI Description not updated for re_ui table          */
/********************************************************************************/
/* Modified by : Balaji S for PNR2.0_7379                  */
/* Modified on : 21-Mar-2006                         */
/* Bug Id      : While Downloading RCN,filler Controls & Image Control are getting
inserted in base Control tables                 */
/* SriSaravanaKumar : 21Apr2006  PNR2.0_8084          */
/********************************************************************************/
/* Modified By  : Date :   Description :             */
/* S K Mohamed Mohideen 15 Jun 2006 Task Confirmation Message changes    */
/********************************************************************************/
/* Modified by : kiruthika R                       */
/* Modified on : 08 Nov 2006                               */
/* Description : Bug Id : PNR2.0_10880                         */
/********************************************************************************/
/* Modified By  : Date :   Description :             */
/* S K Mohamed Mohideen 09 Nov 2006 Task Status Message changes      */
/********************************************************************************/
/* Modified by : Feroz                           */
/* Modified on : 08/11/06                         */
/* Description : State Processing                      */
/********************************************************************************/
/* Modified by : kiruthika R                       */
/* Modified on : 20 dec 2006                               */
/* Description : Bug Id : PNR2.0_11512                         */
/********************************************************************************/
/* Modified by : Balaji S                         */
/* Modified on : 01 mar 2007                               */
/* Description : Bug Id : PNR2.0_12429                         */
/********************************************************************************/
/* Modified by : Anuradha M                   */
/* Modified on : 28 mar 2007                            */
/* Description : Bug Id : PNR2.0_12845                      */
/********************************************************************************/
/* Modified by : Balaji S                         */
/* Modified on : 05 apr 2007                               */
/* Description : Bug Id : PNR2.0_12985                         */
/********************************************************************************/
/* Modified by : Arunn                         */
/* Modified on : 20 apr 2007                               */
/* Description : Bug Id : PNR2.0_13340                         */
/********************************************************************************/
/* Modified by : Gowrisankar for PNR2.0_13513         */
/* Modified on : 03-May-2007                               */
/* Description : Performance Tuning            */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 16-May-2007              */
/* BUG ID      : PNR2.0_13677             */
/********************************************************************************/
/* modified by  : Kiruthika R                                                   */
/* date         : 25-May-2007                                                   */
/* description  : PNR2.0_13817                                                  */
/********************************************************************************/
/* modified by  : Kiruthika R                                                   */
/* date         : 05-Jun-2007                                                   */
/* description  : PNR2.0_13973                                                  */
/********************************************************************************/
/* modified by  : Anuradha M                                                    */
/* date         : 26-Jul-2007                                                   */
/* description  : PNR2.0_14686                                                  */
/********************************************************************************/
/* modified by   : Chanheetha N A          */
/* date     : 17-nov-2007           */
/* BugId    : PNR2.0_16023            */
/********************************************************************************/
/* modified by  : Gowrisankar M                                                 */
/* date         : 22-Jan-2008                                                   */
/* description  : PNR2.0_16537                */
/********************************************************************************/
/* modified by  : Kiruthika R                                                  */
/* date         : 09-Apr-2008                                                   */
/* description  : PNR2.0_17551(@fprowno should be incremented and out it  for modeflag <> 'Z')                                                  */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 25-Apr-2008                                                   */
/* Bug Id  : PNR2.0_1476                      */
/********************************************************************************/
/* Modified by  : Gopinath S             */
/* Date         : 06-OCT-2008             */
/* Bug ID       : PNR2.0_19480             */
/********************************************************************************/
/* modified by   : Feroz             */
/* date     : 25-nov-2008           */
/* BugId    : PNR2.0_1790            */
/********************************************************************************/
/* modified by  : Sangeetha G                                           */
/* date         : 19-May-2009                                           */
/* Bug Id  : PNR2.0_22275       */
/* modified for : To include page focus in state processing  */
/************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description     : PNR2.0_23463          */
/******************************************************************************/
/* Modified By     : Chanheetha N A        */
/* Date      : 23-Oct-2009         */
/* Bug Id      : PNR2.0_24424         */
/* Description     : Pagename added for mapped controls to launch EzeeView Link from model  */
/*************************************************************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 08-Feb-2010         */
/* Description     : PNR2.0_25863          */
/******************************************************************************/
/* Modified By     :  Sangeetha G  */
/* Date      :  05-Apr-10  */
/* Bugid     :  PNR2.0_26335  */
/* Modified For     :  Traversal table schema change */
/**********************************************************************************************/
/* Modified By     : Sangeetha G                  */
/* Date      : 28-Apr-2010          */
/* Bug Id      : PNR2.0_26701           */
/* Description     : Column addition for ListEdit Resolve tables */
/***********************************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/************************************************************************************************/
/* Modified By      : Gowrisankar M                        */
/* Date            : 08-Jun-2010                      */
/* BugID       : PNR2.0_27106                       */
/* Modified For     : Resolved links deletion to be corrected                        */
/***********************************************************************************************/
/* Modified By       : Sangeetha G                  */
/* Date     : Sep 17 2010                  */
/* Bug Id    : PNR2.0_28333                                                            */
/* Description       : Ezee view page for Platform                                             */
/***********************************************************************************************/
/* modified by  : Jeyalatha K            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */
/****************************************************************************/
/* modified by   : Sangeetha G           */
/* date    : 11-Apr-2011           */
/* BugId   : PNR2.0_30869           */
/* modified for  : Feature Release          */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : May 18 2011           */
/* Bug ID  : PNR2.0_31403            */
/* Case Desc : Tree Grid Feature Enhancement.      */
/************************************************************************/
/* modified by : Gankan.G               */
/* modified on : 14-July-2011           */
/* Bug ID  : PNR2.0_32366            */
/* Case Desc : Script included to filter dataitems for header control*/
/*      of base controltype link        */
/************************************************************************/
/* modified by : Gankan.G               */
/* modified on : 05-AUG-2011           */
/* Bug ID  : PNR2.0_32794            */
/* Case Desc : Code addded to avoid duplication of task description */
/*      within a component         */
/************************************************************************/
/* Modified by  :    Balaji D           */
/* Date         :    05-Aug-2011                                        */
/* Bug ID  :    PNR2.0_32748                                       */
/* Description  :    Populate controls deletion to be corrected   */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : 15-Oct-2011           */
/* Bug ID  : PNR2.0_34035            */
/* Case Desc : Chart table schema change        */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : Dec 31 2011           */
/* Bug ID  : PNR2.0_35984            */
/* Case Desc : Modelling for Splitter Section.      */
/************************************************************************/
/* modified by  : Balaji D                                     */
/* date         : july 02 2012                                   */
/* BugId        : PLF2.0_00961                                    */
/* modified for : PopUpSection,Button Right Align,Page/Button/Link Images*/
/************************************************************************/
/* modified by   : Kiruthika R          */
/* date          : 06-Mar-2013          */
/* Bug ID  : PLF2.0_03710           */
/* Description : Customlist implementation for header edit controls. */
/************************************************************************/
/* Author      : Sangeetha G           */
/* Date        : Apr 18 2013           */
/* BugID       : PLF2.0_01359           */
/* Description : CSOU dataitem gets deleted on RCN dwld .    */
/************************************************************************/
/* modified by  : Gankan G           */
/* date         : 28-May-2013           */
/* Bug ID  : PLF2.0_04721           */
/* Description : Code modified to handle equal tabwidth   */
/************************************************************************/
/* modified by  :  Shakthi P                     */
/* date         : 12-Mar-2014                    */
/* Bug ID    : PLF2.0_07805                   */
/* Description  : Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan             */
/*********************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 28-Mar-2016                                                  */
/*Defect Id 	: PLF2.0_17570										*/
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 21-Nov-2017  Defect ID	:TECH-16126	*/
/********************************************************************************/
/* Modified by  : Jeya Latha K	Date: 30-Apr-2018  Defect ID : TECH-20897 */
/*****************************************************************************************/
/* Modified by  :  Venkatesan K                                                          */
/* Date         :  10_05_2018                                                            */
/* Description  :  Batch id table updation for batch track purpose.				         */
/* case id		:  TECH-20631													         */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018     Defect ID: TECH-28010  */
/* Modified By : Jeya Latha K		        Date: 08-Jan-2019     Defect ID: TECH-28436  */
/* Modified by : Jeya Latha K			    Date: 25-Jul-2019     Defect ID: TECH-36371  */
/*****************************************************************************************/
/* Modified by : Jeya Latha K               Date: 04-Dec-2019     Defect ID : TECH-40809 */
/* Modified by : Jeya Latha K  	            Date: 29-Jan-2020     Defect ID : TECH-42483 */
/* Modified by : Rajeswari M/Jeya Latha K   Date: 27-Feb-2020	  Defect ID : TECH-43307 */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021   Defect ID : TECH-60451 */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo		 */ 
/*************************************************************************************************/
/* Modified By	: Venkatesan K															         */
/* Defect ID	: TECH-66583																     */
/* Modified on	: 24Feb2022																         */
/* Description	: RVW 2.0 Model publish table implementation for control and task property.      */
/*************************************************************************************************/
/* Modified By	: Ponmalar A/Priyadharshini U													 */
/* Defect ID	: TECH-68066																     */
/* Modified on	: 13-Apr-2022																     */
/* Description	: Post and Pre Tasks for Attachment controls.									 */
/*************************************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	VimalKumar R												*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by : Priyadharshini U  												*/
/* Modified on : 27-July-2022                                                   */
/* Defect ID   : TECH-71262														*/
/* Description : Platform Features for the Month of July'22                     */
/********************************************************************************/
/* Created by  : Vimal Kumar R  												*/
/* Modified on : 27-July-2022                                                   */
/* Defect ID   : TECH-71262														*/
/* Description : Platform Features for the Month of July'22                     */
/********************************************************************************/
/* Modified by : Ponmalar A/Priyadharshini U									*/
/* Modified on : 23-Aug-2022                                                    */
/* Defect ID   : TECH-72114														*/
/* Description : Platform Release for the month of August'22					*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 30-Sep-2022		Defect ID  : TECH-73216 */
/****************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R												*/
/* Modified on : 27-Oct-2022															*/
/* Defect ID   : TECH-73996																*/
/* Description : Addition of attributes for control types in setup ui preferences screen*/
/****************************************************************************************/
/* Modified by : Priyadharshini U /Ponmalar A									*/
/* Modified on : 01-Dec-2022                                                    */
/* Defect ID   : TECH-75230														*/
/* Description : Platform Features for the Month of Nov'22                      */
/********************************************************************************/
CREATE PROCEDURE re_ecr_sp_dnldecr
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_customer_name_in engg_name,
	@engg_ecr_descr_in engg_description,
	@engg_ecr_no_in engg_name,
	@engg_ecr_status_in engg_name,
	@engg_project_name_in engg_name,
	@modeflag_in engg_modeflag,
	@fprowno_io engg_rowno,
	@m_errorid engg_seqno OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--declaration of temporary variables
	DECLARE @ctxt_language engg_ctxt_language
	DECLARE @ctxt_ouinstance engg_ctxt_ouinstance
	DECLARE @ctxt_service engg_ctxt_service
	DECLARE @ctxt_user engg_ctxt_user
	DECLARE @engg_customer_name engg_name
	DECLARE @engg_ecr_descr engg_description
	DECLARE @engg_ecr_no engg_name
	DECLARE @engg_ecr_status engg_name
	DECLARE @engg_project_name engg_name
	DECLARE @modeflag engg_modeflag
	DECLARE @fprowno engg_rowno
	DECLARE @getdate engg_date
	DECLARE @engg_ecr_no_temp engg_name
	DECLARE @msg engg_description
	DECLARE @workreqno_tmp engg_name
	DECLARE @bpid_tmp engg_name
	DECLARE @componentname_tmp engg_name
	DECLARE @activityid_tmp engg_name
	DECLARE @uiid_tmp engg_name
	DECLARE @modifieddate_tmp engg_date
	DECLARE @oldworkreq_tmp engg_name
	DECLARE @rcn_tmp engg_name

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language_in

	SELECT @ctxt_ouinstance = @ctxt_ouinstance_in

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service_in))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user_in))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name_in))

	SELECT @engg_ecr_descr = ltrim(rtrim(@engg_ecr_descr_in))

	SELECT @engg_ecr_no = ltrim(rtrim(@engg_ecr_no_in))

	SELECT @engg_ecr_status = ltrim(rtrim(@engg_ecr_status_in))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name_in))

	SELECT @modeflag = ltrim(rtrim(@modeflag_in))

	SELECT @fprowno = @fprowno_io

	SELECT @getdate = getdate()

	--code commented for bugid :PNR2.0_17551 starts here
	--  if @modeflag <> 'Z'
	--  return
	--code commented for bugid :PNR2.0_17551 ends here
	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		IF @ctxt_service = '~#~'
			SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_ecr_descr = '~#~'
		SELECT @engg_ecr_descr = NULL

	IF @engg_ecr_no = '~#~'
		SELECT @engg_ecr_no = NULL

	IF @engg_ecr_status = '~#~'
		SELECT @engg_ecr_status = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	SELECT @fprowno = @fprowno + 1

	DECLARE @timestamp_tmp engg_timestamp

	SET @timestamp_tmp = 1

	--code added for bugid :PNR2.0_17551 starts here
	IF @modeflag <> 'Z'
	BEGIN
		SELECT @fprowno 'fprowno'

		RETURN
	END

	--code added for bugid :PNR2.0_17551 ends here
	DECLARE @proc_name engg_name,
		@comp_name engg_name,
		@act_name engg_name,
		@ui_name engg_name,
		@rcr_no engg_name,
		@proc_descr engg_description,
		@comp_descr engg_description,
		@act_descr engg_description,
		@ui_descr engg_description,
		@ecr_descr_tmp engg_description,
		@functionid engg_name,
		@process_name engg_name,
		@component_name engg_name,
		@activity_name engg_name,
		@rcr_no_tmp engg_name,
		@rcn_no_tmp engg_name,
		@rcn_type engg_name,
		@page_bt_synonym_del engg_name,
		@task_name_del engg_name,
		@flowbr_name_del engg_name,
		@combo_bt_synonym engg_name,
		@control_id_tmp engg_name,
		@view_name_tmp engg_name,
		@combo_page_name engg_name

	--output parameters
	--  select  fprowno                       'fprowno'
	-- code modified by shafina on 30-Aug-2004 for ECENG203SYS_000111 (A direct RCN released from Release managment is not getting downloaded. It is neither throwing an error.)
	SELECT @rcn_type = rcntype
	FROM fw_rmt_rcn_vw(NOLOCK)
	WHERE customerid = @engg_customer_name
		AND projectid = @engg_project_name
		AND rcnnumber = @engg_ecr_no

	IF @rcn_type <> 'Dir'
	BEGIN
		-- code modified by shafina on 16-July-2004 for PREVIEWENG203ACC_000078
		DECLARE previewready_cur CURSOR
		FOR
		SELECT DISTINCT process_name,
			component_name,
			activity_name,
			rcr_no
		FROM re_rmt_ecr_ui_vw(NOLOCK)
		WHERE customer_name = (@engg_customer_name)
			AND project_name = (@engg_project_name)
			AND ecr_no = (@engg_ecr_no)

		OPEN previewready_cur

		WHILE 1 = 1
		BEGIN --1
			FETCH NEXT
			FROM previewready_cur
			INTO @process_name,
				@component_name,
				@activity_name,
				@rcr_no_tmp

			IF @@fetch_status <> 0
			BEGIN --2
				BREAK
			END --2

			-- code modified by shafina on 13-July-2004 for PREVIEWENG203ACC_000078
			SELECT @functionid = functionid
			FROM fw_bpt_function_component_vw(NOLOCK)
			WHERE customerid = @engg_customer_name
				AND projectid = @engg_project_name
				AND bpid = @process_name
				AND componentname = @component_name

			-- code modified by shafina on 19-July-2004 for ECENG203SYS_000091
			IF @rcr_no_tmp = 'BASE' /* PNR2.0_3423 */
			BEGIN
				EXEC bpt_download_rcn @engg_customer_name,
					@engg_project_name,
					@process_name,
					@functionid,
					@activity_name,
					@ctxt_language,
					@ctxt_user,
					@m_errorid OUTPUT

				IF @m_errorid = 624
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Please enter CustomerID',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 625
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Please enter ProjectID',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 626
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Please enter BPID',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 627
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Please enter FunctionID',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 945
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Activity ID cannot be blank.',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 648
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'CustomerID,ProjectID,BPID,FunctionID,ActivityName combination is Invalid.Please select another combination. ',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END

				IF @m_errorid = 1802
				BEGIN
					EXEC engg_error_sp 're_ecr_sp_dnldecr',
						1,
						'Preview is not published',
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE previewready_cur

					DEALLOCATE previewready_cur

					RETURN
				END
			END
		END

		CLOSE previewready_cur

		DEALLOCATE previewready_cur

		----  code moved by Gowrisankar for PNR2.0_13513 on 03-May-2007
		DECLARE ecr_cursor INSENSITIVE CURSOR
		FOR
		SELECT DISTINCT WorkReqID,
			BPID,
			Componentname,
			ActivityID,
			UIID
		FROM Fw_Rmt_Cmt_RCN_Details_Vw(NOLOCK)
		WHERE customerid = @engg_customer_name
			AND projectid = @engg_project_name
			AND RCNNumber = @engg_ecr_no

		OPEN ecr_cursor

		WHILE (1 = 1)
		BEGIN
			FETCH NEXT
			FROM ecr_cursor
			INTO @workreqno_tmp,
				@bpid_tmp,
				@componentname_tmp,
				@activityid_tmp,
				@uiid_tmp

			IF (@@FETCH_STATUS <> 0)
				BREAK

			SELECT TOP 1 @oldworkreq_tmp = req_no
			FROM ep_published_ui_mst a(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no <> @workreqno_tmp
				AND process_name = @bpid_tmp
				AND component_name = @componentname_tmp
				AND activity_name = @activityid_tmp
				AND ui_name = @uiid_tmp
				AND modifieddate < (
					SELECT b.modifieddate
					FROM ep_published_ui_mst b(NOLOCK)
					WHERE b.customer_name = @engg_customer_name
						AND b.project_name = @engg_project_name
						AND b.req_no = @workreqno_tmp
						AND b.process_name = @bpid_tmp
						AND b.component_name = @componentname_tmp
						AND b.activity_name = @activityid_tmp
						AND b.ui_name = @uiid_tmp
					)
			ORDER BY modifieddate DESC

			SELECT TOP 1 @rcn_tmp = RCNNumber
			FROM Fw_Rmt_Cmt_RCN_details_vw(NOLOCK)
			WHERE customerid = @engg_customer_name
				AND projectid = @engg_project_name
				AND WorkReqID = @oldworkreq_tmp
				AND ActivityID = @activityid_tmp
				AND UIID = @uiid_tmp -- 13340

			IF @rcn_tmp IS NOT NULL
			BEGIN
				IF NOT EXISTS (
						SELECT 'x'
						FROM re_ui_ecr(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND ecr_no = @rcn_tmp
							AND isnull(ecr_no, '') <> ''
						)
				BEGIN
					SELECT @msg = 'DownLoad the Previous RCN No.' + @rcn_tmp + '-Mapped To UI' + @uiid_tmp

					EXEC engg_error_sp 'de_dnld_sp_dnldico',
						1,
						@msg,
						@ctxt_language,
						@ctxt_ouinstance,
						@ctxt_service,
						@ctxt_user,
						'',
						'',
						'',
						'',
						@m_errorid OUTPUT

					CLOSE ecr_cursor

					DEALLOCATE ecr_cursor

					RETURN
				END
			END
		END

		CLOSE ecr_cursor

		DEALLOCATE ecr_cursor

		--  code moved by Gowrisankar for PNR2.0_13513 on 03-May-2007
		DECLARE mainui_cur CURSOR
		FOR
		SELECT process_name,
			component_name,
			activity_name,
			ui_name,
			rcr_no,
			process_descr,
			component_descr,
			activity_descr,
			ui_descr,
			ecr_descr
		FROM re_rmt_ecr_ui_vw(NOLOCK)
		WHERE customer_name = (@engg_customer_name)
			AND project_name = (@engg_project_name)
			AND ecr_no = (@engg_ecr_no)

		OPEN mainui_cur

		WHILE 1 = 1
		BEGIN --1
			FETCH NEXT
			FROM mainui_cur
			INTO @proc_name,
				@comp_name,
				@act_name,
				@ui_name,
				@rcr_no,
				@proc_descr,
				@comp_descr,
				@act_descr,
				@ui_descr,
				@ecr_descr_tmp

			IF @@fetch_status <> 0
			BEGIN --2
				BREAK
			END --2

			-- code commented by shafina on 02-Sep-2004 for ECENG203SYS_000112 ( RCN can not be downloaded since work request is not published The above error is displayed when trying to donwload the Direct RCN)
			-- Code added by Saravanan on 04/05/2005 for PNR2.0_2302
			IF NOT EXISTS (
					SELECT 'X'
					FROM ep_published_ui_mst(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND req_no = (@rcr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
					)
				AND @rcn_type <> 'Dir'
			BEGIN
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					1,
					'RCN can not be downloaded since work request is not published',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
				BEGIN
					CLOSE mainui_cur

					DEALLOCATE mainui_cur

					RETURN
				END
			END

			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND ecr_no = (@engg_ecr_no)
						AND rcr_no = (@rcr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND ui_status = 'C'
					)
			BEGIN --3
				/* Code  Added By Krishna priya on 7/5/04 for BugId :ECENG203ACC_000016 */
				-- code added by shafina on 01-Nov-2004 for ECENG203ACC_000016 (To change the error description)
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					1,
					'Selected RCN is already downloaded..',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					/* Code  Added By Krishna priya on 7/5/04 for BugId :ECENG203ACC_000016 */
					/* Code  Added By Krishna priya on 19/4/04 for BugId :ECENG203SYS_000002 */
				BEGIN
					CLOSE mainui_cur

					DEALLOCATE mainui_cur

					RETURN
				END
						/* Code  Added By Krishna priya on 19/4/04 for BugId :ECENG203SYS_000002 */
			END --3

			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND ecr_no = (@engg_ecr_no)
						AND rcr_no = (@rcr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND ui_status = 'P'
					)
			BEGIN --3
				/* Code  Added By Krishna priya on 7/5/04 for BugId :ECENG203ACC_000016 */
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					3,
					'RCN at rowno:<%1>  is Published.',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
					/* Code  Added By Krishna priya on 7/5/04 for BugId :ECENG203ACC_000016 */
				BEGIN
					CLOSE mainui_cur

					DEALLOCATE mainui_cur

					RETURN
				END
			END --3

			-- code added by shafina on 20-july-2004 for checking whether downloading ui is mapped to another rcn
			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						-- code modified by shafina on 30-Dec-2004 for ECPF204SYS_000058 (while trying to download a direct RCN 'Component already exists in downloaded status . Publish previous component RCN..' error message is raised.But other RCNs are already in published
						-- status.)
						AND ecr_no <> (@engg_ecr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND (ui_status) = 'C'
					)
			BEGIN --4
				--code added by Sangeetha L on 20-Jan-2006 for the BUG ID:PNR2.0_5621
				SELECT @engg_ecr_no_temp = ecr_no
				FROM re_ui_ecr(NOLOCK)
				WHERE customer_name = (@engg_customer_name)
					AND project_name = (@engg_project_name)
					AND ecr_no <> (@engg_ecr_no)
					AND process_name = (@proc_name)
					AND component_name = (@comp_name)
					AND activity_name = (@act_name)
					AND ui_name = (@ui_name)
					AND (ui_status) = 'C'

				SELECT @msg = 'The Component- ' + @comp_name + ' already exists in the RCN "' + @engg_ecr_no_temp + '".Publish the RCN "' + @engg_ecr_no_temp + '"  before downloading the RCN ' + '"' + @engg_ecr_no + '"'

				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					2,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				--code added by Sangeetha L on 20-Jan-2006 for the BUG ID:PNR2.0_5621
				IF @m_errorid > 0
				BEGIN
					CLOSE mainui_cur

					DEALLOCATE mainui_cur

					RETURN
				END
			END

			-- code added by shafina on 27-July-2004 for ECENG203ACC_000053
			-- When an rcn is downloaded , check whether the previous rcn is mapped to an ecr. if so download rcn must not be allowed.
			-- code added by shafina on 28-July-2004 to check all the previous rcns.
			-- code added by Sangeetha on 12-March-2005 for ECENG203SYS_000203
			-- First RCN is shortclosed. Second RCN is pending for download.
			DECLARE rcn_cur INSENSITIVE CURSOR
			FOR
			SELECT ecr_no
			FROM re_ui_ecr(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND ecr_no <> (@engg_ecr_no)
				--Commented by Shriram V on 28/03/05 for Bug Id :PNR2.0_1624
				--and  short_close   = 'Yes'
				--Added by Shriram V on 28/03/05 for Bug Id :PNR2.0_1624
				AND short_close <> 'Yes'

			OPEN rcn_cur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM rcn_cur
				INTO @rcn_no_tmp

				IF @@fetch_status <> 0
					BREAK

				IF isnull(@rcn_no_tmp, '') <> ''
				BEGIN
					IF NOT EXISTS (
							SELECT 'x'
							FROM de_rmt_rcn_ecr_vw(NOLOCK)
							WHERE customer_name = (@engg_customer_name)
								AND project_name = (@engg_project_name)
								AND ecr_no = (@rcn_no_tmp)
							)
					BEGIN
						--Added by Shriram V on 28/03/05 for bug Id : PNR2.0_1616
						--Commented by Shriram V on 28/03/05 for bug Id : PNR2.0_1624
						/*if exists(select 'x'
from fw_rmt_rcn_vw(nolock)
where  customerid  =(@engg_customer_name)
and  projectid  =(@engg_project_name)
and  rcnnumber  =(@rcn_no_tmp))
begin */
						--End of Addition by Shriram V on 28/03/05 for Bug ID : PNR2.0_1616
						-- End of Comment by Shriram V on 28/03/05 for bug Id : PNR2.0_1624
						EXEC engg_error_sp 're_ecr_sp_dnldecr',
							2,
							'Previous RCN is not mapped to an ECR.',
							@ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							'',
							'',
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid > 0
						BEGIN
							CLOSE rcn_cur

							DEALLOCATE rcn_cur

							CLOSE mainui_cur

							DEALLOCATE mainui_cur

							RETURN
						END
								-- end
								--PNR2.0_1624
					END
				END
			END

			CLOSE rcn_cur

			DEALLOCATE rcn_cur

			--Code Modified For BugId : PNR2.0_5941
			--    declare ecr_cursor insensitive Cursor For
			--    Select distinct WorkReqID,BPID,Componentname,ActivityID,UIID
			--    from Fw_Rmt_Cmt_RCN_Details_Vw(nolock)
			--    where RCNNumber   = @engg_ecr_no
			--
			--    open ecr_cursor
			--
			-- WHILE (1=1)
			--    BEGIN
			--
			--     fetch next from ecr_cursor
			--     into  @workreqno_tmp,@bpid_tmp,@componentname_tmp,@activityid_tmp,@uiid_tmp
			--
			--     if (@@FETCH_STATUS <> 0)
			--      break
			--
			--     Select @modifieddate_tmp = modifieddate
			--     --from ep_ui_req_dtl(nolock)
			--     from ep_published_ui_mst(nolock) --code modified by saravanan for bugid:PNR2.0_11512
			--     where req_no    =  @workreqno_tmp
			--     and  process_name  =  @bpid_tmp
			--     and  component_name = @componentname_tmp
			--     and  activity_name = @activityid_tmp
			--     and  ui_name   = @uiid_tmp
			--
			--     Select top 1
			--       @oldworkreq_tmp  = req_no
			--     from ep_published_ui_mst (nolock)
			--     where req_no    <>  @workreqno_tmp
			--     and  process_name  =  @bpid_tmp
			--     and  component_name = @componentname_tmp
			--     and  activity_name = @activityid_tmp
			--     and  ui_name   = @uiid_tmp
			--     and  modifieddate < @modifieddate_tmp
			--     order by modifieddate desc
			--
			--
			--
			--  select  top 1
			--       @rcn_tmp = RCNNumber
			--     from  Fw_Rmt_Cmt_RCN_details_vw(nolock)
			--     where  WorkReqID = @oldworkreq_tmp
			--     and    UIID = @uiid_tmp    -- 13340
			--
			--     if @rcn_tmp is not null
			--     begin
			--      if not exists ( Select 'x'
			--           from re_ui_ecr(nolock)
			--           where ecr_no = @rcn_tmp
			--           and  ecr_no is not null)
			--      begin
			--       select @msg = 'DownLoad the Previous RCN No.'+ @rcn_tmp+'-Mapped To UI'+@uiid_tmp
			--       exec engg_error_sp
			--        'de_dnld_sp_dnldico', 1, @msg, @ctxt_language,
			--        @ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out
			--        close ecr_cursor
			--       deallocate ecr_cursor
			--       return
			--      end
			--     end
			--
			--    end
			--
			--   close ecr_cursor
			--   deallocate ecr_cursor
			--Code Modified For BugId : PNR2.0_5941
			-- code added by DNR on 2/1/2004 for populating re_ui_ecr table
			/*   if exists (select 'x' from re_ui_ecr(nolock)
where customer_name  = (@engg_customer_name)
and  project_name  = (@engg_project_name)
and  ecr_no    = (@engg_ecr_no)
and  rcr_no    = (@rcr_no)
and  process_name = (@proc_name)
and  component_name = (@comp_name)
and  activity_name  = (@act_name)
and  ui_name   = (@ui_name)
)
begin

update  re_ui_ecr
set  ui_status  = 'C',
-- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)
modifiedby  = @ctxt_user,
modifieddate = @getdate
where customer_name = (@engg_customer_name)
and  project_name = (@engg_project_name)
and  ecr_no   = (@engg_ecr_no)
and  rcr_no   = (@rcr_no)
and  process_name = (@proc_name)
and  component_name = (@comp_name)
and  activity_name = (@act_name)
and  ui_name   = (@ui_name)

end
else
begin*/
			-- Code commented by Gowrisankar M for PNR2.0_16537 on 22-Jan-2008
			/* code changed by Yuvaraj to populate download tables start here */
			--     exec re_download_populate @engg_customer_name, @engg_project_name, @engg_ecr_no, @proc_name,
			--       @comp_name, @act_name, @ui_name, @rcr_no, @control_id_tmp,
			--       @view_name_tmp, @proc_descr, @comp_descr, @act_descr, @ui_descr,
			--       @ecr_descr_tmp
			/* code changed by Yuvaraj to populate download tables start here */
			-- Code commented by Gowrisankar M for PNR2.0_16537 on 22-Jan-2008
			DELETE
			FROM re_ui_ecr
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND ecr_no = (@engg_ecr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_ui_ecr (
				customer_name,
				project_name,
				ecr_no,
				rcr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_status,
				ecr_descr,
				process_descr,
				component_descr,
				activity_descr,
				ui_descr,
				ecr_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_ecr_no,
				@rcr_no,
				@proc_name,
				@comp_name,
				@act_name,
				@ui_name,
				'C',
				@ecr_descr_tmp,
				@proc_descr,
				@comp_descr,
				@act_descr,
				@ui_descr,
				newid(),
				1,
				@ctxt_user,
				@getdate,
				'',
				''
				)

			--   end
			IF EXISTS (
					SELECT 'x'
					FROM re_ui(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND (current_req_no) <> ''
						AND (current_req_no) <> @engg_ecr_no
					)
			BEGIN --4
				-- the error is modified by Ganesh on 3/6/04 for the bugid ECENG203SYS_000062
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					2,
					'Component alread exists in download status . Publish previous component RCN..',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
				BEGIN
					CLOSE mainui_cur

					DEALLOCATE mainui_cur

					RETURN
				END
			END --4
			ELSE
			BEGIN
				--CODE MODIFIED BY DNR  ON 04-JUNE-2004 FOR THE BUG ID ECENG203ACC_000032
				--WHILE DOWNLOADING RCN,UI PROPERTIES ARE NOT GETTING UPDATED .
				UPDATE re_ui
				SET current_req_no = (@engg_ecr_no),
					ui_descr = b.ui_descr, -- code modified by Gowrisankar on 20-Mar-2006 for PNR2.0_7343
					ui_type = b.ui_type,
					ui_format = b.ui_format,
					caption_alignment = b.caption_alignment,
					trail_bar = b.trail_bar,
					tab_height = b.tab_height,
					ui_doc = b.ui_doc,
					base_component_name = b.base_component_name,
					base_activity_name = b.base_activity_name,
					base_ui_name = b.base_ui_name,
					grid_type = b.grid_type,
					state_processing = b.state_processing,
					callout_type = b.callout_type, -- Column added for the BugId PNR2.0_1790
					taskpane_req = b.taskpane_req, -- Column added for the BugId PNR2.0_30127
					New_Line_Ui = b.New_Line_Ui,
					Tab_Type = b.Tab_Type,
					PostLaunchTask = b.PostLaunchTask,
					TabPosition = b.TabPosition,
					SmartHide = b.SmartHide,
					Is_device = b.Is_device,
					HideIlbotitlemenu_req = b.HideIlbotitlemenu_req,
					modifiedby = @ctxt_user,
					modifieddate = @getdate,
					personalization = b.personalization,
					Exclude_Systemtabindex = b.Exclude_Systemtabindex, -- PLF2.0_16291
					DeviceType = b.DeviceType, ---PLF2.0_17570
					TabStyle = b.TabStyle,
					IsDesktop = b.IsDesktop,
					Hide_Print = b.Hide_Print,
					Layout = b.Layout,
					XYCoordinates = b.XYCoordinates,
					ColumnLayWidth = b.ColumnLayWidth,
					TabHeaderPostion = b.TabHeaderPostion,
					TabRotation = b.TabRotation,
					hide_imp_defaults = b.hide_imp_defaults,
					ui_subtype = b.ui_subtype,
					DBName = b.DBName,
					IsGlance = b.IsGlance,
					NativeApplication = b.NativeApplication,
					Conditional_popupclose = b.Conditional_popupclose,
					Titlebar_Search        =b.Titlebar_Search,----added by 13852 on 24jan2020
					--Code added for TECH-70687 starts
					Sidebar					=	b.Sidebar,
					Docked					=	b.Docked,
					LeftToolbar				=	b.LeftToolbar,
					RightToolbar			=	b.RightToolbar,
					TopToolbar				=	b.TopToolbar,
					BottomToolbar			=	b.BottomToolbar,
					--Code added for TECH-70687 ends
					--Code added for TECH-72114 starts
					TemplateJSON			=	b.TemplateJSON,	
					StyleSheet				=	b.StyleSheet,
					ConfigurationXML		=	b.ConfigurationXML,	
					TemplateJSONDBC			=	b.TemplateJSONDBC,	
					StyleSheetDBC			=	b.StyleSheetDBC,	
					ConfigurationXMLDBC		=	b.ConfigurationXMLDBC,
					--Code added for TECH-72114 ends
					PullToRefresh			=	b.PullToRefresh	--TECH-75230
				FROM re_ui a(NOLOCK),
					ep_published_ui_mst_vw b(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND b.customer_name = (@engg_customer_name)
					AND b.project_name = (@engg_project_name)
					AND b.req_no = (@rcr_no)
					AND b.process_name = (@proc_name)
					AND b.component_name = (@comp_name)
					AND b.activity_name = (@act_name)
					AND b.ui_name = (@ui_name)
			END

			IF NOT EXISTS (
					SELECT 'x'
					FROM re_ui(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND current_req_no = (@engg_ecr_no)
					)
			BEGIN
				INSERT INTO re_ui (
					customer_name,
					project_name,
					process_name,
					component_name,
					activity_name,
					ui_name,
					ui_descr,
					ui_type,
					ui_format,
					caption_alignment,
					trail_bar,
					tab_height,
					ui_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					current_req_no,
					ui_doc,
					base_component_name,
					base_activity_name,
					base_ui_name,
					grid_type,
					state_processing,
					rcnno, --chan
					callout_type,
					taskpane_req,
					New_Line_Ui,
					Tab_Type,
					PostLaunchTask,
					TabPosition,
					SmartHide,
					Is_device,
					HideIlbotitlemenu_req,
					personalization,
					Exclude_Systemtabindex,
					DeviceType,
					TabStyle,
					IsDesktop,
					Hide_Print -- Column added for the BugId PNR2.0_1790, PNR2.0_30127, PLF2.0_16291,PLF2.0_17570
					,
					Layout,
					XYCoordinates,
					ColumnLayWidth,
					TabHeaderPostion,
					TabRotation,
					hide_imp_defaults,
					DBName,
					ui_subtype,
					NativeApplication,
					Conditional_popupclose,
					ISGlance,
					Titlebar_Search,---added by 13852 on 24jan2020
					--Code added for TECH-70687 starts
					Sidebar,
					Docked,
					LeftToolbar,
					RightToolbar,
					TopToolbar,
					BottomToolbar,
					--Code added for TECH-70687 ends
					--code added for TECH-72114 starts
					TemplateJSON,
					StyleSheet,
					ConfigurationXML,
					TemplateJSONDBC,
					StyleSheetDBC,
					ConfigurationXMLDBC,
					--code added for TECH-72114 ends
					PullToRefresh	--TECH-75230
					)
				SELECT customer_name,
					project_name,
					process_name,
					component_name,
					activity_name,
					ui_name,
					ui_descr,
					ui_type,
					ui_format,
					caption_alignment,
					trail_bar,
					tab_height,
					ui_sysid,
					1,
					@ctxt_user,
					@getdate,
					@ctxt_user,
					@getdate,
					@engg_ecr_no,
					ui_doc,
					base_component_name,
					base_activity_name,
					base_ui_name,
					grid_type,
					state_processing,
					@engg_ecr_no,
					callout_type,
					taskpane_req, -- Column added for the BugId PNR2.0_1790, PNR2.0_30127
					New_Line_Ui,
					Tab_Type,
					PostLaunchTask,
					TabPosition,
					SmartHide,
					Is_device,
					HideIlbotitlemenu_req,
					personalization,
					Exclude_Systemtabindex /*-- PLF2.0_16291*/,
					DeviceType,
					TabStyle,
					IsDesktop,
					Hide_Print --PLF2.0_17570
					,
					Layout,
					XYCoordinates,
					ColumnLayWidth,
					TabHeaderPostion,
					TabRotation,
					hide_imp_defaults,
					DBName,
					ui_subtype,
					NativeApplication,
					Conditional_popupclose,
					ISGlance,
					Titlebar_Search,
					--Code added for TECH-70687 starts
					Sidebar,
					Docked,
					LeftToolbar,
					RightToolbar,
					TopToolbar,
					BottomToolbar,
					--Code added for TECH-70687 ends
					--code added for TECH-72114 starts
					TemplateJSON,
					StyleSheet,
					ConfigurationXML,
					TemplateJSONDBC,
					StyleSheetDBC,
					ConfigurationXMLDBC,
					--code added for TECH-72114 ends
					PullToRefresh	--TECH-75230
				FROM ep_published_ui_mst_vw(NOLOCK)
				WHERE customer_name = (@engg_customer_name)
					AND project_name = (@engg_project_name)
					AND req_no = (@rcr_no)
					AND process_name = (@proc_name)
					AND component_name = (@comp_name)
					AND activity_name = (@act_name)
					AND ui_name = (@ui_name)
			END

			---------------------------------------------------------------------------------------------
			-- code commented by shafina on 06-Jan-2005 for ECENG203ACC_000092 (While downloading RCN , system hangs.)
			--   exec  re_enum_value_log @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--        @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--        @comp_name,@act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			---------------------------------------------------------------------------------------------
			--   if exists (select 'x' from re_enum_value(nolock)
			--      where customer_name  = (@engg_customer_name)
			--     and  project_name  = (@engg_project_name)
			--     and  process_name  = (@proc_name)
			--     and  component_name  = (@comp_name)
			--     and  activity_name  = (@act_name)
			--     and  ui_name    = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_enum_value
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_enum_value (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				enum_code,
				enum_caption,
				default_flag,
				enum_value_sysid,
				ui_page_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				seq_no,
				rcnno
				) --chan
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				enum_code,
				enum_caption,
				default_flag,
				enum_value_sysid,
				ui_page_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				seq_no,
				@engg_ecr_no
			FROM ep_published_enum_value_dtl_vw(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
			DELETE
			FROM re_enum_value_lng_extn
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_enum_value_lng_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				enum_code,
				enum_caption,
				default_flag,
				enum_value_sysid,
				ui_page_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				seq_no,
				languageid,
				rcnno
				) --chan
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				enum_code,
				enum_caption,
				default_flag,
				enum_value_sysid,
				ui_section_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				seq_no,
				languageid,
				@engg_ecr_no
			FROM ep_published_enum_value_dtl_lng_extn(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
			---------------------------------------------------------------------------------------------
			--   exec  re_action_section_map_log @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--                               @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--                               @comp_name,@act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close  mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_action_section_map(nolock)
			--        where customer_name  = (@engg_customer_name)
			--       and  project_name = (@engg_project_name)
			--       and  process_name = (@proc_name)
			--       and  component_name = (@comp_name)
			--       and  activity_name = (@act_name)
			--       and  ui_name   = (@ui_name)
			--      )
			--   begin--4
			DELETE
			FROM re_action_section_map
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_action_section_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				section_bt_synonym,
				task_section_sysid,
				task_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				section_page_bt_synonym,
				rcnno --chan --new column added by DNR on 31/03/2004
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				section_bt_synonym,
				task_section_sysid,
				task_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				section_page_bt_synonym,
				@engg_ecr_no
			FROM ep_published_action_section_map_vw(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			---------------------------------------------------------------------------------------------
			--   exec  re_action_log @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--                      @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--                     @comp_name,@act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--        end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_action(nolock)
			--      where customer_name  = (@engg_customer_name)
			--     and  project_name = (@engg_project_name)
			--     and  process_name = (@proc_name)
			--     and  component_name = (@comp_name)
			--     and  activity_name = (@act_name)
			--     and  ui_name   = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_action
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_action (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				primary_control_bts,
				task_sysid,
				ui_sysid,
				task_type,
				task_confirm_msg,
				task_status_msg,
				rcnno, --chan -- Column added by Mohideen on Jun 15, 2006
				usageid,
				ddt_page_bt_synonym,
				ddt_control_bt_synonym,
				ddt_control_id,
				ddt_view_name, -- Columns added for the BugId PNR2.0_1790
				task_process_msg,
				PopUp_page_bt_synonym,
				PopUp_section,
				PopUp_close --Column added  for PNR2.0_30869 ,PLF2.0_00961
				,
				iscallout,
				QR_sourceCtrl,
				QR_targetCtrl,
				Barcode_sourceCtrl,
				Barcode_targetCtrl,
				browse_control,
				QR_sourceCtrl_Page,
				QR_targetCtrl_Page,
				Barcode_sourceCtrl_Page,
				Barcode_targetCtrl_Page,
				browse_control_Page,
				group_name,
				Buttonbar_primary_section,
				Popup_onclick_close,
				Autoupload,
				sectionlaunchtype,
				QuickTask,
				SystemTaskType, -- Added for the Defect ID TECH-29822
				Systemgenerated	--TECH-73216
				) 
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				primary_control_bts,
				task_sysid,
				ui_sysid,
				task_type,
				task_confirm_msg,
				task_status_msg,
				@engg_ecr_no, -- Column added by Mohideen on Jun 15, 2006
				usageid,
				ddt_page_bt_synonym,
				ddt_control_bt_synonym,
				ddt_control_id,
				ddt_view_name, -- Columns added for the BugId PNR2.0_1790
				task_process_msg,
				PopUp_page_bt_synonym,
				PopUp_section,
				PopUp_close --Column added  for PNR2.0_30869 ,PLF2.0_00961
				,
				iscallout,
				QR_sourceCtrl,
				QR_targetCtrl,
				Barcode_sourceCtrl,
				Barcode_targetCtrl,
				browse_control,
				QR_sourceCtrl_Page,
				QR_targetCtrl_Page,
				Barcode_sourceCtrl_Page,
				Barcode_targetCtrl_Page,
				browse_control_Page,
				group_name,
				Buttonbar_primary_section,
				Popup_onclick_close,
				Autoupload,
				sectionlaunchtype,
				QuickTask,
				SystemTaskType, -- Added for the Defect ID TECH-29822
				Systemgenerated	--TECH-73216
			FROM ep_published_action_mst(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			-- Start for the Feature Context Menu(PNR2.0_1476) --Added by Jeya
			DELETE
			FROM re_ui_contextmenu_task_dtl
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_ui_contextmenu_task_dtl (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				control_id,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				task_type,
				rcn_no
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				control_id,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				task_type,
				@engg_ecr_no
			FROM ep_published_ui_contextmenu_task_dtl(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			-- End for the Feature Context Menu(PNR2.0_1476) --Added by Jeya
			-- Code added By Jeya Latha K for Contextual Links and Control Extensions Starts
			DELETE
			FROM re_contextual_links
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_contextual_links (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				contextual_link_name,
				contextual_link_seq,
				task_description,
				extend_as,
				source_from,
				tolltiptext,
				linked_componentname,
				linked_activityname,
				linked_uiname,
				subscription_name,
				task_name,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno,
				task_type
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				contextual_link_name,
				contextual_link_seq,
				task_description,
				extend_as,
				source_from,
				tolltiptext,
				linked_componentname,
				linked_activityname,
				linked_uiname,
				subscription_name,
				task_name,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no,
				task_type
			FROM ep_published_contextual_links(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_control_extensions
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_control_extensions (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				controlextension_name,
				controlextension_seq,
				task_description,
				extend_as,
				source_from,
				tooltiptext,
				linked_componentname,
				linked_activityname,
				linked_uiname,
				subscription_name,
				task_name,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno,
				task_type,
				image_path
				) -- Code Modified for the BugID PNR2.0_25863
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_name,
				control_bt_synonym,
				controlextension_name,
				controlextension_seq,
				task_description,
				extend_as,
				source_from,
				tooltiptext,
				linked_componentname,
				linked_activityname,
				linked_uiname,
				subscription_name,
				task_name,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no,
				task_type,
				image_path
			FROM ep_published_control_extensions(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added By Jeya Latha K for Contextual Links and Control Extensions  End
			DELETE
			FROM re_action_lng_extn
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05
			INSERT INTO re_action_lng_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				languageid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				primary_control_bts,
				task_sysid,
				ui_sysid,
				task_type,
				task_confirm_msg,
				task_status_msg,
				rcnno, --chan -- Column added by Mohideen on Jun 15, 2006
				usageid,
				ddt_page_bt_synonym,
				ddt_control_bt_synonym,
				ddt_control_id,
				ddt_view_name, -- Columns added for the BugId PNR2.0_1790
				task_process_msg,
				PopUp_page_bt_synonym,
				PopUp_section,
				PopUp_close,
				IsCallout, --Column added  for PNR2.0_30869,PLF2.0_00961,
				QR_sourceCtrl,
				QR_targetCtrl,
				Barcode_sourceCtrl,
				Barcode_targetCtrl,
				browse_control,
				QR_sourceCtrl_Page,
				QR_targetCtrl_Page,
				Barcode_sourceCtrl_Page,
				Barcode_targetCtrl_Page,
				browse_control_Page,
				group_name,
				Buttonbar_primary_section,
				Popup_onclick_close
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				task_name,
				task_descr,
				task_seq,
				task_pattern,
				languageid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				primary_control_bts,
				task_sysid,
				ui_sysid,
				task_type,
				task_confirm_msg,
				task_status_msg,
				@engg_ecr_no, -- Column added by Mohideen on Jun 15, 2006
				usageid,
				ddt_page_bt_synonym,
				ddt_control_bt_synonym,
				ddt_control_id,
				ddt_view_name, -- Columns added for the BugId PNR2.0_1790
				task_process_msg,
				PopUp_page_bt_synonym,
				PopUp_section,
				PopUp_close,
				IsCallout --Column added  for PNR2.0_30869,PLF2.0_00961
				,
				QR_sourceCtrl,
				QR_targetCtrl,
				Barcode_sourceCtrl,
				Barcode_targetCtrl,
				browse_control,
				QR_sourceCtrl_Page,
				QR_targetCtrl_Page,
				Barcode_sourceCtrl_Page,
				Barcode_targetCtrl_Page,
				browse_control_Page,
				group_name,
				Buttonbar_primary_section,
				Popup_onclick_close
			FROM ep_published_action_mst_lng_extn(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   code added for the Bug ID :: PNR2.0_12845
			UPDATE a
			SET a.task_descr = b.task_descr
			FROM re_action_lng_extn a(NOLOCK),
				ep_published_action_mst_lng_extn b(NOLOCK)
			WHERE b.customer_name = @engg_customer_name
				AND b.project_name = @engg_project_name
				AND b.req_no = @rcr_no
				AND b.process_name = @proc_name
				AND b.component_name = @comp_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.task_name = b.task_name
				AND a.task_descr <> b.task_descr
				AND a.languageid = b.languageid

			--   code added for the Bug ID :: PNR2.0_12845
			---------------------------------------------------------------------------------------------
			--   exec  re_ui_traversal_log   @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--                              @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--                           @comp_name,@act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--  end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_ui_traversal(nolock)
			--      where customer_name   = (@engg_customer_name)
			--     and  project_name = (@engg_project_name)
			--     and  process_name = (@proc_name)
			--     and  component_name = (@comp_name)
			--     and  activity_name = (@act_name)
			--     and  ui_name   = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_ui_traversal
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			--Code modification for PNR2.0_26335 starts
			INSERT INTO re_ui_traversal (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				link_type,
				treaversal_sysid,
				ui_page_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				linked_component,
				linked_activity,
				linked_ui,
				associated_ctrl_bt_synonym,
				rcnno, --chan
				trvsl_seq,
				Width,
				Height,
				Toolbar_notreq,
				LinkLaunchType
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				link_type,
				treaversal_sysid,
				ui_page_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				linked_component,
				linked_activity,
				linked_ui,
				associated_ctrl_bt_synonym,
				@engg_ecr_no,
				trvsl_seq,
				Width,
				Height,
				Toolbar_notreq,
				LinkLaunchType
			FROM ep_published_ui_traversal_dtl(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--Code modification for PNR2.0_26335 ends
			---------------------------------------------------------------------------------------------
			--   exec  re_ui_section_log   @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--                            @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--                            @comp_name,@act_name,@ui_name,@m_errorid output
			--   if @m_errorid > 0
			--   begin
			--    close  mainui_cur
			--    deallocate mainui_cur
			--    return
			--   end
			---------------------------------------------------------------------------------------------
			--   if exists (select 'x' from re_ui_section(nolock)
			--      where customer_name  = (@engg_customer_name)
			--      and project_name  = (@engg_project_name)
			--      and process_name  = (@proc_name)
			--      and component_name  = (@comp_name)
			--      and activity_name  = (@act_name)
			--      and ui_name    = (@ui_name)
			--     )
			--   begin--4
			--Code Modified for bugId : PNR2.0_12429
			--code moved for bugid:PNR2.0_13817
			DELETE
			FROM re_ui_state
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_state_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_state_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_state_task
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_state_task_mst
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added for the BugId PNR2.0_1790 Starts
			DELETE
			FROM re_ui_state_column
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_state_page
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added for the BugId PNR2.0_1790 Ends
			--- Delete device tables
			DELETE
			FROM re_ui_device_page
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_device_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_device_grid
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_device
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_device_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--     delete from re_ui_section
			--      where customer_name  = (@engg_customer_name)
			--     and  project_name  = (@engg_project_name)
			--     and  process_name  = (@proc_name)
			--     and  component_name  = (@comp_name)
			--     and  activity_name  = (@act_name)
			--     and  ui_name    = (@ui_name)
			--   end--4
			--Code Modified for BugId : PNR2.0_12985
			UPDATE a
			SET visisble_flag = b.visisble_flag,
				title_required = b.title_required,
				border_required = b.border_required,
				parent_section = b.parent_section,
				horder = b.horder,
				vorder = b.vorder,
				ui_section_sysid = b.ui_section_sysid,
				page_sysid = b.page_sysid,
				TIMESTAMP = b.TIMESTAMP,
				modifiedby = b.modifiedby,
				modifieddate = b.modifieddate,
				section_doc = b.section_doc,
				title_alignment = b.title_alignment,
				section_type = b.section_type,
				width = b.width,
				height = b.height,
				caption_Format = b.caption_Format,
				SectionPrefixClass = b.SectionPrefixClass,
				ctrl_caption_align = b.ctrl_caption_align,
				Setion_width_Scalemode = b.Section_width_Scalemode,
				Setion_height_Scalemode = b.Section_height_Scalemode,
				a.Associated_control = b.Associated_control, -- Code modified for  PNR2.0_31403
				a.splitter_pos = b.splitter_pos, --Code modified for  PNR2.0_35984
				a.NColSpan = b.NColSpan, --code Modified for the bugid : PLF2.0_07805  by shakthi P
				a.NRowSpan = b.NRowSpan,
				--,a.IsStatic = b.IsStatic
				a.section_collapse = b.section_collapse,
				a.section_collapsemode = b.section_collapsemode,
				a.CarouselNavigation = b.CarouselNavigation,
				a.cell_spacing = b.cell_spacing,
				a.cell_padding = b.cell_padding,
				a.Region = b.Region, --PLF2.0_17570
				a.TitlePosition = b.TitlePosition,
				a.CollapseDir = b.CollapseDir,
				a.SectionLayout = b.SectionLayout,
				a.XYCoordinates = b.XYCoordinates,
				a.ColumnLayWidth = b.ColumnLayWidth,
				a.IsPlatform = b.IsPlatform,
				a.IsResponsive = b.IsResponsive,
				a.mob_pop_fullview = b.mob_pop_fullview,
				a.BorderLeftWidth				=	b.BorderLeftWidth,
				a.BorderRightWidth				=	b.BorderRightWidth,
				a.BorderTopWidth				=	b.BorderTopWidth,
				a.BorderBottomWidth				=	b.BorderBottomWidth,
				a.BorderLeftColor				=	b.BorderLeftColor,
				a.BorderRightColor				=	b.BorderRightColor,
				a.BorderTopColor				=	b.BorderTopColor,
				a.BorderBottomColor				=	b.BorderBottomColor,
				a.BorderTopLeftRadius			=	b.BorderTopLeftRadius,
				a.BorderTopRightRadius			=	b.BorderTopRightRadius,
				a.BorderBottomLeftRadius		=	b.BorderBottomLeftRadius,
				a.BorderBottomRightRadius		=	b.BorderBottomRightRadius,
				a.BorderStyle					=	b.BorderStyle,
				a.ForResponsive					=	b.ForResponsive,			--Code added for TECH-69624
				--Code added for TECH-70687 starts 
				a.LeftToolbar					=	b.LeftToolbar,	
				a.RightToolbar					=	b.RightToolbar,	
				a.TopToolbar					=	b.TopToolbar,
				a.BottomToolbar					=	b.BottomToolbar,	
				a.MinimizedRows					=	b.MinimizedRows,
				a.ViewMode						=	b.ViewMode,
				a.HasTitleAction				=	b.HasTitleAction,
				--Code added for TECH-70687 ends
				a.TitleIcon						=	b.TitleIcon,  --TECH-72114
				a.Orientation					=	b.Orientation	--TECH-75230
			FROM re_ui_section a(NOLOCK),		
				ep_published_ui_section_dtl_vw b(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND b.req_no = (@rcr_no)
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.section_bt_synonym = b.section_bt_synonym

			--MODIFIED BY GIRI ON 15/01/2004 -- CHANGED UI_SYSID TO PAGE_SYSID
			INSERT INTO re_ui_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				visisble_flag,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				ui_section_sysid,
				page_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				section_doc,
				title_alignment,
				width,
				height,
				section_type,
				SectionPrefixClass,
				caption_Format,
				ctrl_caption_align,
				Setion_width_Scalemode,
				Setion_height_Scalemode,
				section_prefix, -- Column added for the BugId PNR2.0_1790
				rcnno,
				Associated_control,
				splitter_pos,
				NColSpan,
				NRowSpan,
				section_collapse,
				section_collapsemode,
				CarouselNavigation -- Code modified for  PNR2.0_31403,PNR2.0_35984,jesse,--code Modified for the bugid : PLF2.0_07805  by shakthi P
				,
				cell_spacing,
				cell_padding,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				IsPlatform,
				IsResponsive,
				mob_pop_fullview,
				--Code added for TECH-69624 Starts
				BorderLeftWidth,
				BorderRightWidth,
				BorderTopWidth,
				BorderBottomWidth,
				BorderLeftColor,
				BorderRightColor,
				BorderTopColor,
				BorderBottomColor,
				BorderTopLeftRadius,
				BorderTopRightRadius,
				BorderBottomLeftRadius,
				BorderBottomRightRadius,
				BorderStyle,	
				ForResponsive,
				--Code added for TECH-69624 ends
				--Code added for TECH-70687 starts
				LeftToolbar,
				RightToolbar,
				TopToolbar,
				BottomToolbar,
				MinimizedRows,
				ViewMode,
				HasTitleAction,
				--Code added for TECH-70687 ends
				TitleIcon,	--TECH-72114
				Orientation	--TECH-75230
				) --PLF2.0_17570
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				visisble_flag,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				ui_section_sysid,
				page_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				section_doc,
				title_alignment,
				width,
				height,
				section_type,
				SectionPrefixClass,
				caption_Format,
				ctrl_caption_align,
				Section_width_Scalemode,
				Section_height_Scalemode,
				section_prefix, -- Column added for the BugId PNR2.0_1790
				@engg_ecr_no,
				Associated_control,
				splitter_pos,
				NColSpan,
				NRowSpan,
				section_collapse,
				section_collapsemode,
				CarouselNavigation -- Code modified for  PNR2.0_31403  ,PNR2.0_35984,jesse,--code Modified for the bugid : PLF2.0_07805  by shakthi P
				,
				cell_spacing,
				cell_padding,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				IsPlatform, --PLF2.0_17570
				IsResponsive,
				mob_pop_fullview,
				--Code added for TECH-69624 starts
				BorderLeftWidth,
				BorderRightWidth,
				BorderTopWidth,
				BorderBottomWidth,
				BorderLeftColor,
				BorderRightColor,
				BorderTopColor,
				BorderBottomColor,
				BorderTopLeftRadius,
				BorderTopRightRadius,
				BorderBottomLeftRadius,
				BorderBottomRightRadius,
				BorderStyle,	
				ForResponsive,
				--Code added for TECH-69624 ends
				--Code added for TECH-70687 starts
				LeftToolbar,
				RightToolbar,
				TopToolbar,
				BottomToolbar,
				MinimizedRows,
				ViewMode, 
				HasTitleAction,
				--Code added for TECH-70687 ends
				TitleIcon,	--TECH-72114
				Orientation	--TECH-75230
			FROM ep_published_ui_section_dtl_vw a(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND NOT EXISTS (
					SELECT 'x'
					FROM re_ui_section b(NOLOCK)
					WHERE a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_bt_synonym = b.page_bt_synonym
						AND a.section_bt_synonym = b.section_bt_synonym
					)

			DELETE a
			FROM re_ui_section a(NOLOCK)
			WHERE NOT EXISTS (
					SELECT 'x'
					FROM ep_published_ui_section_dtl_vw b(NOLOCK)
					WHERE a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_bt_synonym = b.page_bt_synonym
						AND a.section_bt_synonym = b.section_bt_synonym
						AND b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.req_no = (@rcr_no)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
					)
				AND a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)

			--
			--  --MODIFIED BY GIRI ON 15/01/2004 -- CHANGED UI_SYSID TO PAGE_SYSID
			--   insert  into re_ui_section
			--   (customer_name,project_name,process_name,
			--   component_name,activity_name,ui_name,
			--   page_bt_synonym,section_bt_synonym,visisble_flag,
			--   title_required,border_required,parent_section,
			--  horder,vorder,ui_section_sysid,
			--   page_sysid,timestamp,createdby,
			--   createddate,modifiedby,modifieddate,
			--   section_doc,title_alignment ,width, height,section_type,
			--   SectionPrefixClass, caption_Format, ctrl_caption_align,Setion_width_Scalemode,Setion_height_Scalemode
			--   )
			--   select customer_name,project_name,process_name,
			--    component_name,activity_name,ui_name,
			--    page_bt_synonym,section_bt_synonym,visisble_flag,
			--    title_required,border_required,parent_section,
			--    horder,vorder,ui_section_sysid,
			--    page_sysid,1,@ctxt_user,
			-- @getdate,@ctxt_user,@getdate,
			--    section_doc,title_alignment,width, height, section_type,
			--    SectionPrefixClass, caption_Format, ctrl_caption_align,Section_width_Scalemode,Section_height_Scalemode
			--   from ep_published_ui_section_dtl_vw (nolock)
			--    where customer_name  = (@engg_customer_name)
			--   and  project_name  = (@engg_project_name)
			--   and  req_no    = (@rcr_no)
			--   and  process_name  = (@proc_name)
			--   and  component_name  = (@comp_name)
			--   and  activity_name  = (@act_name)
			--   and  ui_name    = (@ui_name)
			----------------------------------------------------------------------------------------------
			--   exec  re_ui_page_log @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--        @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--        @comp_name,@act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_ui_page(nolock)
			--       where customer_name  = (@engg_customer_name)
			--      and  project_name  = (@engg_project_name)
			--      and  process_name  = (@proc_name)
			--      and  component_name  = (@comp_name)
			--      and  activity_name  = (@act_name)
			--      and  ui_name    = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_ui_page
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_ui_page (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				ui_page_sysid,
				ui_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				page_doc,
				page_prefix,
				rcnno, --chan
				page_Type,
				pageimage -- Column added for the BugId PNR2.0_1790 ,PLF2.0_00961
				,
				width,
				PageClass --code modified for the bug id:PLF2.0_04721
				,
				HeaderPosition, --PLF2.0_17570
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				--Code added for TECH-70687 starts
				LeftToolbar,
				RightToolbar,
				TopToolbar,
				BottomToolbar
				--Code added for TECH-70687 ends
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				ui_page_sysid,
				ui_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				page_doc,
				page_prefix,
				@engg_ecr_no,
				page_Type,
				pageimage -- Column added for the BugId PNR2.0_1790,PLF2.0_00961
				,
				width,
				PageClass --code modified for the bug id:PLF2.0_04721
				,
				HeaderPosition, ---PLF2.0_17570
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				--Code added for TECH-70687 starts
				LeftToolbar,
				RightToolbar,
				TopToolbar,
				BottomToolbar
				--Code added for TECH-70687 ends
			FROM ep_published_ui_page_dtl_vw(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--Code Modification for PNR2.0_30869 starts
			DELETE
			FROM re_ui_pageevents
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_ui_pageevents (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				EventRequired,
				Task_Onclick,
				SystemGenerated,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				EventRequired,
				Task_Onclick,
				SystemGenerated,
				TIMESTAMP,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate
			FROM ep_published_ui_pageevents_dtl(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--Code Modification for PNR2.0_30869 ends
			-----------------------------------------------------------------------------------------------
			--   exec  re_ui_grid_log @ctxt_language,           @ctxt_ouinstance,        @ctxt_service,@ctxt_user,
			--          @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--          @comp_name,               @act_name,@ui_name,@m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_ui_grid(nolock)
			--       where customer_name  = (@engg_customer_name)
			--      and  project_name  = (@engg_project_name)
			--      and  process_name  = (@proc_name)
			--      and  component_name  = (@comp_name)
			--      and  activity_name  = (@act_name)
			--      and  ui_name    = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_ui_grid
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_ui_grid (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				grid_sysid,
				ui_control_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name,
				visible_length,
				proto_tooltip,
				sample_data,
				col_doc,
				column_prefix,
				rcnno, --chan
				Set_User_Pref, -- code Added by Gopinath S for the Call ID PNR2.0_19480
				default_required,
				ColumnClass --Column added  for PNR2.0_30869 ,--code Modified for the bugid : PLF2.0_07805  by shakthi P
				,/*ColumnHdrClass,*/
				visible,
				Forcefit,
				TemplateID,
				iskey,
				Kyseq_no,
				TemplateCategory,
				TemplateSpecific,
				Column_class_ext6,
				RowExpander,
				GridToForm,
				icon_position,
				icon_class,
				TreeColumn,
				column_Transformas,
				sensitivedata,
				IsPlatform,
				CompactView,
				IsExtension,
				ExtensionOrder, -- added for GridToForm TECH-12776 , TECH-20897,TECH-60451
				AssociateControl)	--Code Added for TECH-71262
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				grid_sysid,
				ui_control_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				control_id,
				view_name,
				visible_length,
				proto_tooltip,
				sample_data,
				col_doc,
				column_prefix,
				@engg_ecr_no,
				Set_User_Pref,
				default_required,
				ColumnClass --Column added  for PNR2.0_30869 ,--code Modified for the bugid : PLF2.0_07805  by shakthi P
				,/*ColumnHdrClass,*/
				visible,
				Forcefit,
				TemplateID,
				iskey,
				Kyseq_no,
				TemplateCategory,
				TemplateSpecific,
				Column_class_ext6,
				RowExpander,
				GridToForm,
				icon_position,
				icon_class,
				TreeColumn,
				column_Transformas,
				sensitivedata,
				IsPlatform,
				CompactView,
				IsExtension,
				ExtensionOrder, --Code added for TECH-60451
				AssociateControl	--Code Added for TECH-71262
			FROM ep_published_ui_grid_dtl(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			---------------------------------------------------------------------------------------------
			--   exec  re_ui_control_log @ctxt_language,      @ctxt_ouinstance,     @ctxt_service,  @ctxt_user,
			--           @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no, @proc_name,
			--           @comp_name,              @act_name,               @ui_name,       @m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_ui_control(nolock)
			--       where customer_name  = (@engg_customer_name)
			--      and  project_name  = (@engg_project_name)
			--      and  process_name  = (@proc_name)
			--      and  component_name  = (@comp_name)
			--      and  activity_name  = (@act_name)
			--      and  ui_name    = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_ui_control
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_ui_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				order_seq,
				data_column_scalemode,
				label_column_scalemode,
				tab_seq,
				help_tabstop,
				LabelClass,
				ControlClass,
				LabelImageClass,
				ControlImageClass,
				rcnno, --chan
				Set_User_Pref,
				freezecount, -- code Added by Gopinath S for the Call ID PNR2.0_19480 --added for PNR2.0_26860
				controlimage,
				colspan,
				rowspan,
				TemplateID -- code modified for the caseid: PLF2.0_00961
				,
				TemplateCategory,
				TemplateSpecific,
				Control_class_ext6,
				icon_position,
				icon_class,
				AccessKey,
				sensitivedata,
				IsPlatform,
				DynamicStyle,
				ImageAsData,
				ExtensionReqd,
				ExtensionLaunchMode,-- Added for TECH-20897,TECH-60451
				AssociateControl, --code added for TECH-63527
				--Code added for TECH-69624 starts
				BorderLeftWidth,
				BorderRightWidth,
				BorderTopWidth,
				BorderBottomWidth,
				BorderLeftColor,
				BorderRightColor,
				BorderTopColor,
				BorderBottomColor,
				BorderTopLeftRadius,
				BorderTopRightRadius,
				BorderBottomLeftRadius,
				BorderBottomRightRadius,
				BorderStyle,
				a.HasCustomAction,
				a.ForResponsive,	--Code added for TECH-69624 ends
				ControlFormat,
				a.ButtonNature,
				a.InlineStyle	--TECH-75230
				)	
			SELECT a.customer_name,
				a.project_name,
				a.process_name,
				a.component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				order_seq,
				data_column_scalemode,
				label_column_scalemode,
				tab_seq,
				help_tabstop,
				LabelClass,
				ControlClass,
				LabelImageClass,
				ControlImageClass,
				@engg_ecr_no,
				Set_User_Pref,
				freezecount, --added for PNR2.0_26860
				controlimage,
				colspan,
				rowspan,
				TemplateID -- code modified for the caseid: PLF2.0_00961
				,
				TemplateCategory,
				TemplateSpecific,
				Control_class_ext6,
				icon_position,
				icon_class,
				AccessKey,
				sensitivedata,
				IsPlatform,
				a.DynamicStyle,
				a.ImageAsData,
				a.ExtensionReqd,
				a.ExtensionLaunchMode, --Code added for TECH-60451
				a.AssociateControl, --code added for TECH-63527
				--Code added for TECH-69624 starts
				a.BorderLeftWidth,
				a.BorderRightWidth,
				a.BorderTopWidth,
				a.BorderBottomWidth,
				a.BorderLeftColor,
				a.BorderRightColor,
				a.BorderTopColor,
				a.BorderBottomColor,
				a.BorderTopLeftRadius,
				a.BorderTopRightRadius,
				a.BorderBottomLeftRadius,
				a.BorderBottomRightRadius,
				a.BorderStyle,	
				a.HasCustomAction,
				a.ForResponsive,
				a.ControlFormat,	
				--Code added for TECH-69624 ends
				a.ButtonNature,
				a.InlineStyle	--TECH-75230
			FROM ep_published_ui_control_dtl a(NOLOCK),
				es_comp_ctrl_type_mst_vw b(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.req_no = (@rcr_no)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				-- code modified by shafina on 20-Nov-2004 for PREVIEWENG203ACC_000109 (Filler2 control type must be added in control type metadata.)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name
				--Code Modified For BugId : PNR2.0_7379
				AND b.base_ctrl_type NOT IN (
					'Image',
					'Line'
					)
				AND a.control_type NOT IN (
					'Filler',
					'Filler2'
					)
			
			UNION
			
			SELECT a.customer_name,
				a.project_name,
				a.process_name,
				a.component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				order_seq,
				data_column_scalemode,
				label_column_scalemode,
				tab_seq,
				help_tabstop,
				LabelClass,
				ControlClass,
				LabelImageClass,
				ControlImageClass,
				@engg_ecr_no,
				Set_User_Pref,
				freezecount, --added for PNR2.0_26860
				controlimage,
				colspan,
				rowspan,
				TemplateID -- code modified for the caseid: PLF2.0_00961
				,
				TemplateCategory,
				TemplateSpecific,
				Control_class_ext6,
				icon_position,
				icon_class,
				accesskey,
				sensitivedata,
				IsPlatform,
				DynamicStyle,
				ImageAsData,
				a.ExtensionReqd,
				a.ExtensionLaunchMode,
				a.AssociateControl, --code added for TECH-63527
				--Code added for TECH-69624 starts
				a.BorderLeftWidth,
				a.BorderRightWidth,
				a.BorderTopWidth,
				a.BorderBottomWidth,
				a.BorderLeftColor,
				a.BorderRightColor,
				a.BorderTopColor,
				a.BorderBottomColor,
				a.BorderTopLeftRadius,
				a.BorderTopRightRadius,
				a.BorderBottomLeftRadius,
				a.BorderBottomRightRadius,
				a.BorderStyle,	
				a.HasCustomAction,
				a.ForResponsive,
				--Code added for TECH-69624 ends
				a.ControlFormat	,
				a.ButtonNature,
				a.InlineStyle		--TECH-75230
			FROM ep_published_ui_control_dtl a(NOLOCK),
				es_comp_stat_ctrl_type_mst b(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.req_no = (@rcr_no)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name

	------ Code added for TECH-60451 Starts

	DELETE
	FROM	re_ui_grid_extension
	WHERE	customer_name	= (@engg_customer_name)
	AND		project_name	= (@engg_project_name)
	AND		process_name	= (@proc_name)
	AND		component_name	= (@comp_name)
	AND		activity_name	= (@act_name)
	AND		ui_name			= (@ui_name)

	INSERT INTO re_ui_grid_extension (
				 Customer_Name,
			     Project_Name,
				 RcnNo,
				 Process_Name,
			     Component_Name,
                 Activity_Name,
                 UI_Name,
                 Page_BT_Synonym,
                 Section_BT_Synonym,
                 Control_ID,
                 View_Name,
                 ParameterName,
				 ParameterSequence,
                 MappedBTSynonym,
                 MappedField,
                 LaunchType,
                 CreatedBy,
                 CreatedDate,
                 ModifiedBy,
                 ModifiedDate)
		SELECT	
				Customer_Name,
				Project_Name,
				@engg_ecr_no,
				Process_Name,
				Component_Name,	
				Activity_Name,
				UI_Name,
				Page_BT_Synonym,
				Section_BT_Synonym,
				Control_ID,
				View_Name,
				ParameterName,
				ParameterSequence,
				MappedBTSynonym,
				MappedField,
				LaunchType,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate
	FROM  ep_published_ui_grid_extension AS extn WITH (NOLOCK)
	WHERE extn.customer_name	=	(@engg_customer_name)
	AND   extn.project_name		=	(@engg_project_name)
	AND   extn.req_no			=	(@rcr_no)
	AND   extn.process_name		=	(@proc_name)
    AND   extn.component_name	=	(@comp_name)
    AND   extn.activity_name	=	(@act_name)
	AND   extn.ui_name			=	(@ui_name)


	
	------Code added for TECH-60451 Ends


	----------13852 added on 21feb2020 Starts

	DELETE
	FROM	re_ui_section_refinement
	WHERE	customer_name	= (@engg_customer_name)
	AND		project_name	= (@engg_project_name)
	AND		process_name	= (@proc_name)
	AND		component_name	= (@comp_name)
	AND		activity_name	= (@act_name)
	AND		ui_name			= (@ui_name)

	Insert into re_ui_section_refinement(
	               customer_name,
                   project_name,
				   process_name,
                   component_name,
                   activity_name,
                   ui_name,
                   Formfactor,
                   page_bt_synonym,
                   section_bt_synonym,
                   rcnno,
                   visible_flag,
                   timestamp,
                   createdby,
                   createddate,
                   modifiedby,
                   modifieddate)
  Select Distinct  r.customer_name,
                   r.project_name,
                   r.process_name,
                   r.component_name,
                   r.activity_name,
                   r.ui_name,
                   r.Formfactor,
                   r.page_bt_synonym,
                   r.section_bt_synonym,
                   @engg_ecr_no,
                   r.visible_flag,
                   r.timestamp,
                   @ctxt_user,
                   @getdate,
                  @ctxt_user,
                  @getdate
	from ep_published_ui_section_refinement r(NOLOCK)
	WHERE r.customer_name = (@engg_customer_name)
				AND r.project_name = (@engg_project_name)
				AND r.req_no = (@rcr_no)
				AND r.process_name = (@proc_name)
				AND r.component_name = (@comp_name)
				AND r.activity_name = (@act_name)
				AND r.ui_name = (@ui_name)

	DELETE
	FROM	re_responsive_sec_weightage
	WHERE	customer_name	= (@engg_customer_name)
	AND		project_name	= (@engg_project_name)
	AND		process_name	= (@proc_name)
	AND		component_name	= (@comp_name)
	AND		activity_name	= (@act_name)
	AND		ui_name			= (@ui_name)

		Insert into  re_responsive_sec_weightage(
		             customer_name,
                     project_name,
                     process_name,
                     component_name,
                     activity_name,
                     ui_name,
                     Formfactor,
                     page_bt_synonym,
                     parent_section,
                     section_bt_synonym,
                     rcnno,
                     Weightage,
                     SectionWidth,
                     timestamp,
                     createdby,
                     createddate,
                     modifiedby,
                     modifieddate)
	 Select Distinct w.customer_name,
                     w.project_name,
                     w.process_name,
                     w.component_name,
                     w.activity_name,
                     w.ui_name,
                     w.Formfactor,
                     w.page_bt_synonym,
                     w.parent_section,
                     w.section_bt_synonym,
                     @engg_ecr_no,
                     w.Weightage,
                     w.SectionWidth,
                     w.timestamp,
                     @ctxt_user,
                     @getdate,
                     @ctxt_user,
                     @getdate
	from ep_published_responsive_sec_weightage w(NOLOCK)
	WHERE w.customer_name = (@engg_customer_name)
				AND w.project_name = (@engg_project_name)
				AND w.req_no = (@rcr_no)
				AND w.process_name = (@proc_name)
				AND w.component_name = (@comp_name)
				AND w.activity_name = (@act_name)
				AND w.ui_name = (@ui_name)
				
        		

   ------13852 added on 21feb2020 End

   ----------13852 added on 13apr2020 Starts

	DELETE
	FROM	re_els_query_listedit_map
	WHERE	customername	= (@engg_customer_name)
	AND		projectname		= (@engg_project_name)
	AND		processname		= (@proc_name)
	AND		componentname	= (@comp_name)
	AND		activityname	= (@act_name)
	AND		uiname			= (@ui_name)

	Insert into re_els_query_listedit_map(
	               customername,
                   projectname,
				   Rcnno,
                   processname,
                   componentname,
                   activityname,
                   uiname,
                   ListControlSynonym,
                   ListControlID,
				   ListViewname,
				   QueryID,
				   SearchIndex,
				   Pagesize,
				   Createdby,
                   Createddate,
                   Modifedby,
                   Modifieddate)
  Select Distinct  m.customername,
                   m.projectname,
				   @engg_ecr_no,
                   m.processname,
                   m.componentname,
                   m.activityname,
                   m.uiname,
                   m.ListControlSynonym,
                   m.ListControlID,
                   m.ListViewname,
                   m.QueryID,
                   m.SearchIndex,
                   m.Pagesize,
                   @ctxt_user,
                   @getdate,
                   @ctxt_user,
                   @getdate
	from ep_published_els_query_listedit_map m(NOLOCK)
	WHERE m.customername = (@engg_customer_name)
				AND m.projectname = (@engg_project_name)
				AND m.Reqno = (@rcr_no)
				AND m.processname = (@proc_name)
				AND m.componentname = (@comp_name)
				AND m.activityname = (@act_name)
				AND m.uiname = (@ui_name)

	DELETE
	FROM	re_els_query_listedit_input
	WHERE	customername	= (@engg_customer_name)
	AND		projectname		= (@engg_project_name)
	AND		processname		= (@proc_name)
	AND		componentname	= (@comp_name)
	AND		activityname	= (@act_name)
	AND		uiname			= (@ui_name)

	Insert into re_els_query_listedit_input(
	               customername,
                   projectname,
				   Rcnno,
                   processname,
                   componentname,
                   activityname,
                   uiname,
                   ListControlSynonym,
                   ListControlID,
				   ListViewname,
                   QueryID,
				   ParameterName,
				   MappedSynonym,
				   MappedControlID,
				   MappedViewName,
				   Createdby,
                   Createddate,
                   Modifedby,
                   Modifieddate)
  Select Distinct  i.customername,
                   i.projectname,
				   @engg_ecr_no,
                   i.processname,
                   i.componentname,
                   i.activityname,
                   i.uiname,
                   i.ListControlSynonym,
                   i.ListControlID,
                   i.ListViewname,
                   i.QueryID,
                   i.ParameterName,
                   i.MappedSynonym,
				   i.MappedControlID,
				   i.MappedViewName,
                   @ctxt_user,
                   @getdate,
                   @ctxt_user,
                   @getdate
	from ep_published_els_query_listedit_input i(NOLOCK)
	WHERE i.customername = (@engg_customer_name)
				AND i.projectname = (@engg_project_name)
				AND i.Reqno = (@rcr_no)
				AND i.processname = (@proc_name)
				AND i.componentname = (@comp_name)
				AND i.activityname = (@act_name)
				AND i.uiname = (@ui_name)

	DELETE
	FROM	re_els_query_listedit_result
	WHERE	customername	= (@engg_customer_name)
	AND		projectname		= (@engg_project_name)
	AND		processname		= (@proc_name)
	AND		componentname	= (@comp_name)
	AND		activityname	= (@act_name)
	AND		uiname			= (@ui_name)

	Insert into re_els_query_listedit_result(
	               customername,
                   projectname,
				   Rcnno,
                   processname,
                   componentname,
                   activityname,
                   uiname,
                   ListControlSynonym,
                   ListControlID,
				   ListViewname,
                   QueryID,
				   ResultColumnName,
				   MappedSynonym,
				   MappedControlID,
				   MappedViewName,
				   ParameterCaption,
				   Width,
				   IsVisible,
				   Createdby,
                   Createddate,
                   Modifedby,
                   Modifieddate,
				   Seqno)
  Select Distinct  r.customername,
                   r.projectname,
				   @engg_ecr_no,
                   r.processname,
                   r.componentname,
				   r.activityname,
                   r.uiname,
                   r.ListControlSynonym,
                   r.ListControlID,
                   r.ListViewname,
                   r.QueryID,
                   r.ResultColumnName,
                   r.MappedSynonym,
				   r.MappedControlID,
				   r.MappedViewName,
				   r.ParameterCaption,
				   r.Width,
				   r.IsVisible,
                    @ctxt_user,
                    @getdate,
                    @ctxt_user,
                    @getdate,
				   r.Seqno
	from ep_published_els_query_listedit_result r(NOLOCK)
	WHERE r.customername = (@engg_customer_name)
				AND r.projectname = (@engg_project_name)
				AND r.Reqno = (@rcr_no)
				AND r.processname = (@proc_name)
				AND r.componentname = (@comp_name)
				AND r.activityname = (@act_name)
				AND r.uiname = (@ui_name)
   ------13852 added on 13apr2020 End

	--Code added for TECH-69624 starts
	DELETE
	FROM	re_ui_control_customaction
	WHERE	customer_name	= (@engg_customer_name)
	AND		project_name	= (@engg_project_name)
	AND		process_name	= (@proc_name)
	AND		component_name	= (@comp_name)
	AND		activity_name	= (@act_name)
	AND		ui_name			= (@ui_name)

	INSERT INTO re_ui_control_customaction (
					customer_name,
					project_name,
					req_no,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					ActionControlBTSynonym,
					Control_ID,
					View_Name,
					ActionType,
					ActionSequence,
					IconClass,
					IconPosition,
					Width,
					ToolTip,
					ActionName,
					ActionDescription,
					ActionControlID,
					ActionViewName,
					Createdby,
					Createddate,
					Modifiedby,
					Modifieddate)
		SELECT
					customer_name,
					project_name,
					@engg_ecr_no,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					control_bt_synonym,
					ActionControlBTSynonym,
					Control_ID,
					View_Name,
					ActionType,
					ActionSequence,
					IconClass,
					IconPosition,
					Width,
					ToolTip,
					ActionName,
					ActionDescription,
					ActionControlID,
					ActionViewName,
					@ctxt_user,
					@getdate,
					@ctxt_user,
					@getdate
		FROM  ep_published_ui_control_customaction AS cust WITH (NOLOCK)
		WHERE cust.customer_name	=	(@engg_customer_name)
		AND   cust.project_name		=	(@engg_project_name)
		AND   cust.req_no			=	(@rcr_no)
		AND   cust.process_name		=	(@proc_name)
		AND   cust.component_name	=	(@comp_name)
		AND   cust.activity_name	=	(@act_name)
		AND   cust.ui_name			=	(@ui_name)

	--Code added for TECH-69624 ends
 
 --Code added for TECH-70687 starts
	DELETE
	FROM	re_ui_section_titleaction
	WHERE	customer_name	= (@engg_customer_name)
	AND		project_name	= (@engg_project_name)
	AND		process_name	= (@proc_name)
	AND		component_name	= (@comp_name)
	AND		activity_name	= (@act_name)
	AND		ui_name			= (@ui_name)

	INSERT INTO re_ui_section_titleaction (
					customer_name,
					project_name,
					rcnno,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					TitleControlBTSynonym,
					ActionType,
					ActionSequence,
					IconClass,
					IconPosition,
					Width,
					ToolTip,
					ActionName,
					ActionDescription,
					ActionControlID,
					ActionViewName,
					Createdby,
					Createddate,
					Modifiedby,
					Modifieddate,
					Titleaction)
		SELECT
					customer_name,
					project_name,
					@engg_ecr_no,
					process_name,
					component_name,
					activity_name,
					ui_name,
					page_bt_synonym,
					section_bt_synonym,
					TitleControlBTSynonym,
					ActionType,
					ActionSequence,
					IconClass,
					IconPosition,
					Width,
					ToolTip,
					ActionName,
					ActionDescription,
					ActionControlID,
					ActionViewName,
					@ctxt_user,
					@getdate,
					@ctxt_user,
					@getdate,
					Titleaction
		FROM  ep_published_ui_section_titleaction AS title WITH (NOLOCK)
		WHERE title.customer_name	=	(@engg_customer_name)
		AND   title.project_name	=	(@engg_project_name)
		AND   title.req_no			=	(@rcr_no)
		AND   title.process_name	=	(@proc_name)
		AND   title.component_name	=	(@comp_name)
		AND   title.activity_name	=	(@act_name)
		AND   title.ui_name			=	(@ui_name)

	--Code added for TECH-70687 ends

			------------code added for combolink and qrcode
			--delete from re_ui_qrcode
			--where  customer_name  = @engg_customer_name
			--and   project_name    = @engg_project_name
			--and   process_name    = @proc_name
			--and   component_name  = @comp_name
			--and   activity_name   = @act_name
			--and   ui_name    = @ui_name
			DELETE
			FROM re_ui_combolink
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--Insert into re_ui_qrcode
			--(customer_name ,project_name ,process_name ,component_name ,activity_name ,ui_name ,task_name ,qr_image ,control_bt_synonym ,seqno,createdby ,createddate ,
			-- modifiedby ,modifieddate ,rcnno)
			--select 
			--customer_name , project_name   ,process_name  ,component_name  ,activity_name  ,ui_name  ,task_name  ,
			--qr_image  ,control_bt_synonym  ,seqno  ,@ctxt_user ,GETDATE() ,@ctxt_user ,GETDATE(),@engg_ecr_no
			--from  ep_published_ui_qrcode_dtl (nolock)
			--where customer_name=@engg_customer_name
			--and project_name	= @engg_project_name
			--and process_name	= @proc_name
			--and req_no			= @rcr_no
			--and component_name	= @comp_name
			--and activity_name	= @act_name
			--and ui_name			= @ui_name
			INSERT INTO re_ui_combolink (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Combo_control_bt_synonym,
				link_control_bt_synonym,
				link_control_caption,
				Display_seqno,
				separatelink_req,
				map,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Combo_control_bt_synonym,
				link_control_bt_synonym,
				link_control_caption,
				Display_seqno,
				separatelink_req,
				map,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				@engg_ecr_no
			FROM ep_published_ui_combolink_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-----
			--- Insert Into re_user_section
			DELETE
			FROM re_user_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_user_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				type,
				include_text,
				include_value,
				languageid,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				type,
				include_text,
				include_value,
				languageid,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_user_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND reqno = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--------------Column Group
			--
			DELETE
			FROM re_ui_columngroup
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_calendar_configure
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_column_group_mapping
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone_columngroup
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone_column_group_mapping
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_columngroup
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_column_group_mapping
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_columngroup (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
			FROM ep_published_ui_columngroup(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_calendar_configure (
				Customer_name,
				Project_name,
				Process_name,
				Component_name,
				Activity_name,
				ui_name,
				page_name,
				section_name,
				rcno,
				monthview_cal,
				weekview_cal,
				editable,
				detailspane,
				listview_req,
				DefaultTemplate,
				eventstyle,
				month_nav_req,
				week_nav_req,
				tap_req,
				doubletap_req,
				drag_req,
				month_nav_event,
				week_nav_event,
				tapevent,
				doubletap_event,
				dragevent,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT Customer_name,
				Project_name,
				Process_name,
				Component_name,
				Activity_name,
				ui_name,
				page_name,
				section_name,
				@engg_ecr_no,
				monthview_cal,
				weekview_cal,
				editable,
				detailspane,
				listview_req,
				DefaultTemplate,
				eventstyle,
				month_nav_req,
				week_nav_req,
				tap_req,
				doubletap_req,
				drag_req,
				month_nav_event,
				week_nav_event,
				tapevent,
				doubletap_event,
				dragevent,
				TIMESTAMP,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_calendar_configure(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_columngroup (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
			FROM ep_published_phone_columngroup(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_columngroup (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				Group_caption,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				grouplevel,
				groupseqno,
				parentgroup,
				parentgroupseq
			FROM ep_published_phone_columngroup(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_column_group_mapping (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_column_group_mapping(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_column_group_mapping (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_phone_column_group_mapping(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_column_group_mapping (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				Page_bt_synonym,
				section_bt_synonym,
				grid_control_bt_synonym,
				Group_name,
				column_bt_synonym,
				SequenceNo,
				mapped_entity,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_phone_column_group_mapping(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			---Insertion for device table starts
			INSERT INTO re_ui_device_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				attributename,
				attributevalue,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				attributename,
				attributevalue,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				controlid,
				viewname
			FROM ep_published_ui_device_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_device_grid (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				attributename,
				attributevalue,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				attributename,
				attributevalue,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				controlid,
				viewname
			FROM ep_published_ui_device_grid_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_device_page (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				attributename,
				attributevalue,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				attributename,
				attributevalue,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_device_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_device_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				attributename,
				attributevalue,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				attributename,
				attributevalue,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_device_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_device (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				attributename,
				attributevalue,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				attributename,
				attributevalue,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_device_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			/*
---Insertion for device table ends
delete from re_ui_section_control_map
where  customer_name  = @engg_customer_name
and   project_name    = @engg_project_name
and   process_name    = @proc_name
and   component_name  = @comp_name
and   activity_name   = @act_name
and   ui_name    = @ui_name

insert into re_ui_section_control_map
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
control_id,view_name,rcnno,createdby,createddate,modifiedby,modifieddate)
Select 
customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
control_id,view_name,@engg_ecr_no,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from ep_published_ui_section_control_map_dtl(nolock)
where customer_name=@engg_customer_name
and project_name	= @engg_project_name
and process_name	= @proc_name
and req_no			= @rcr_no
and component_name	= @comp_name
and activity_name	= @act_name
and ui_name			= @ui_name*/
			--Insertion for placeholder and tooltip
			DELETE
			FROM re_ui_tooltip_lng_extn
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_tooltip_lng_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				control_id,
				view_name,
				languageid,
				rcnno,
				tooltip,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				control_id,
				view_name,
				languageid,
				@engg_ecr_no,
				tooltip,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_tooltip_dtl_lng_extn(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_placeholder_lng_extn
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_placeholder_lng_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				control_bt_synonym,
				control_id,
				view_name,
				languageid,
				rcnno,
				placeholder,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				control_bt_synonym,
				control_id,
				view_name,
				languageid,
				@engg_ecr_no,
				placeholder,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_placeholder_dtl_lng_extn(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			------ QlikLink  PLF2.0_16291
			DELETE
			FROM re_ui_control_association_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_control_association_map (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				Control_id,
				view_name,
				propertyname,
				propertycontrol,
				property_controlid,
				property_viewname,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				Control_id,
				view_name,
				propertyname,
				propertycontrol,
				property_controlid,
				property_viewname,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_ui_control_association_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			---QlikLink  PLF2.0_16291
			------ code added for PLF2.0_16291 (Pivot tables )starts
			DELETE
			FROM re_pivot_configure
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_pivot_configure (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				configpan_pos,
				rowgrandtot_pos,
				rowsubtot_pos,
				colgrandtot_pos,
				colsubtot_pos,
				rowgrandtot_text,
				colgrandtot_text,
				rowsubtot_text,
				colsubtot_text,
				TIMESTAMP,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				configpan_pos,
				rowgrandtot_pos,
				rowsubtot_pos,
				colgrandtot_pos,
				colsubtot_pos,
				rowgrandtot_text,
				colgrandtot_text,
				rowsubtot_text,
				colsubtot_text,
				TIMESTAMP,
				@engg_ecr_no,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_pivot_configure(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_pivot_fields
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_pivot_fields (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				column_bt_synonym,
				rowlabel,
				columnlabel,
				fieldValue,
				rowlabelseq,
				columnlabelseq,
				valueseq,
				ValueFunction,
				rowlabelsorting,
				columnlabelsorting,
				rcnno,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				column_bt_synonym,
				rowlabel,
				columnlabel,
				fieldValue,
				rowlabelseq,
				columnlabelseq,
				valueseq,
				ValueFunction,
				rowlabelsorting,
				columnlabelsorting,
				@engg_ecr_no,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_pivot_fields(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_pivot_lang_extn
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_pivot_lang_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				DisplayField,
				Languageid,
				DisplayText,
				rcnno,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				Control_bt_synonym,
				DisplayField,
				Languageid,
				DisplayText,
				@engg_ecr_no,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_pivot_lang_extn(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			------ code added for PLF2.0_16291 (Pivot tables )Ends 
			---phone and tablet tables starts PLF2.0_17570
			DELETE
			FROM re_phone_grid
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone_page
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_phone
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_grid
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet_page
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_tablet
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_descr,
				ui_type,
				ui_format,
				tab_height,
				rcnno,
				TabStyle,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				Layout,
				XYCoordinates,
				ColumnLayWidth,
				TabHeaderPostion,
				TabRotation
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_descr,
				ui_type,
				ui_format,
				tab_height,
				@engg_ecr_no,
				TabStyle,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				Layout,
				XYCoordinates,
				ColumnLayWidth,
				TabHeaderPostion,
				TabRotation
			FROM ep_published_phone_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_descr,
				ui_type,
				ui_format,
				tab_height,
				rcnno,
				TabStyle,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				Layout,
				XYCoordinates,
				ColumnLayWidth,
				TabHeaderPostion,
				TabRotation
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_descr,
				ui_type,
				ui_format,
				tab_height,
				@engg_ecr_no,
				TabStyle,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				Layout,
				XYCoordinates,
				ColumnLayWidth,
				TabHeaderPostion,
				TabRotation
			FROM ep_published_tablet_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_page (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				HeaderPosition,
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				rcnno,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				PageClass
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				HeaderPosition,
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				@engg_ecr_no,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				PageClass
			FROM ep_published_phone_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_page (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				HeaderPosition,
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				rcnno,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				PageClass
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				horder,
				vorder,
				HeaderPosition,
				TabRotation,
				TabTitleStyle,
				TabIconPosition,
				PageLayout,
				XYCoordinates,
				ColumnLayWidth,
				@engg_ecr_no,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				PageClass
			FROM ep_published_tablet_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				title_alignment,
				width,
				height,
				caption_Format,
				ctrl_caption_align,
				Section_width_Scalemode,
				Section_height_Scalemode,
				SectionPrefixClass,
				rcnno,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				title_alignment,
				width,
				height,
				caption_Format,
				ctrl_caption_align,
				Section_width_Scalemode,
				Section_height_Scalemode,
				SectionPrefixClass,
				@engg_ecr_no,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_phone_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				title_alignment,
				width,
				height,
				caption_Format,
				ctrl_caption_align,
				Section_width_Scalemode,
				Section_height_Scalemode,
				SectionPrefixClass,
				rcnno,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				title_required,
				border_required,
				parent_section,
				horder,
				vorder,
				title_alignment,
				width,
				height,
				caption_Format,
				ctrl_caption_align,
				Section_width_Scalemode,
				Section_height_Scalemode,
				SectionPrefixClass,
				@engg_ecr_no,
				Region,
				TitlePosition,
				CollapseDir,
				SectionLayout,
				XYCoordinates,
				ColumnLayWidth,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE()
			FROM ep_published_tablet_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				label_column_scalemode,
				data_column_scalemode,
				control_id,
				view_name,
				visible_length,
				sample_data,
				order_seq,
				LabelClass,
				ControlClass,
				rcnno,
				freezecount,
				TemplateID,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				TemplateCategory,
				TemplateSpecific
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				label_column_scalemode,
				data_column_scalemode,
				control_id,
				view_name,
				visible_length,
				sample_data,
				order_seq,
				LabelClass,
				ControlClass,
				@engg_ecr_no,
				freezecount,
				TemplateID,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				TemplateCategory,
				TemplateSpecific
			FROM ep_published_phone_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				control_id,
				view_name,
				visible_length,
				sample_data,
				order_seq,
				LabelClass,
				ControlClass,
				rcnno,
				freezecount,
				TemplateID,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				label_column_scalemode,
				data_column_scalemode,
				TemplateCategory,
				TemplateSpecific
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				control_id,
				view_name,
				visible_length,
				sample_data,
				order_seq,
				LabelClass,
				ControlClass,
				@engg_ecr_no,
				freezecount,
				TemplateID,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				label_column_scalemode,
				data_column_scalemode,
				TemplateCategory,
				TemplateSpecific
			FROM ep_published_tablet_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_phone_grid (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				control_id,
				view_name,
				visible_length,
				sample_data,
				rcnno,
				ColumnClass,
				TemplateID,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				TemplateCategory,
				TemplateSpecific
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				control_id,
				view_name,
				visible_length,
				sample_data,
				@engg_ecr_no,
				ColumnClass,
				TemplateID,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				TemplateCategory,
				TemplateSpecific
			FROM ep_published_phone_grid_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_tablet_grid (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				control_id,
				view_name,
				visible_length,
				sample_data,
				rcnno,
				ColumnClass,
				TemplateID,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				TemplateCategory,
				TemplateSpecific
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_type,
				column_no,
				control_id,
				view_name,
				visible_length,
				sample_data,
				@engg_ecr_no,
				ColumnClass,
				TemplateID,
				TIMESTAMP,
				@ctxt_user,
				GETDATE(),
				@ctxt_user,
				GETDATE(),
				TemplateCategory,
				TemplateSpecific
			FROM ep_published_tablet_grid_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			---phone and tablet tables ends PLF2.0_17570
			DELETE
			FROM re_non_ui_control
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_non_ui_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				order_seq,
				data_column_scalemode,
				label_column_scalemode
				)
			SELECT a.customer_name,
				a.project_name,
				a.process_name,
				a.component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				horder,
				vorder,
				data_column_width,
				label_column_width,
				ui_control_sysid,
				ui_section_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				control_id,
				view_name,
				visisble_length,
				proto_tooltip,
				sample_data,
				control_doc,
				control_prefix,
				order_seq,
				data_column_scalemode,
				label_column_scalemode
			FROM ep_published_ui_control_dtl_vw A(NOLOCK),
				es_comp_ctrl_type_mst_vw B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.req_no = (@rcr_no)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name
				AND (
					b.base_ctrl_type IN (
						'Image',
						'Line'
						)
					OR a.control_type IN (
						'Filler',
						'Filler2'
						)
					)

			-- REMOVING NON-EXISTENT DATA
			-- code modified by shafina on 26-july-2004 for ECENG203ACC_000054
			-- When an rcn is downloaded , if data gets deleted in traversal table , check whether the link is resolved, if so delete the details from corresponding resolved link table.
			-- code modified by shafina on 04-Aug-2004 for REENG203ACC_000090
			-- code modified by shafina on 19-Aug-2004 for ECENG203ACC_000062 (subscription , subscription dataitem , publication , publication dataitem , flowbr tables must be checked for control/task existence else data must be deleted.)
			DELETE a
			FROM re_resolved_link_dataitem A,
				re_subscription C
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.subscription_name = c.subscription_name
				AND c.control_bt_synonym NOT IN (
					SELECT b.control_bt_synonym
					FROM re_ui_traversal B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = c.page_bt_synonym
						-- code modified by shafina on 14-Sep-2004 for ECENG203ACC_000062 (resolved link details must be deleted even if the link details are modified)
						AND b.linked_component = a.publication_comp_name
						AND b.linked_activity = a.publication_act_name
						AND b.linked_ui = a.publication_ui_name
					)

			DELETE a
			FROM re_resolved_link A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.subscription_name NOT IN (
					SELECT b.subscription_name
					FROM re_resolved_link_dataitem B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						-- code modified for PNR2.0_27106 on 08-Jun-2010 by Gowrisankar M
						--and  b.publication_name  = b.publication_name)
						AND b.publication_name = a.publication_name
					)

			--- Code modified by Saravanan on 25/04/2005 for PNR2.0-2144
			--- Delete Publication DataItem, Subcription DataItem excluding BT's in DE_HIDDEN_VIEW
			--- while download of RCN.
			DELETE a
			FROM re_subscription_dataitem A,
				re_subscription C
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.subscription_name = c.subscription_name
				AND c.control_bt_synonym NOT IN (
					SELECT b.control_bt_synonym
					FROM re_ui_traversal B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = c.page_bt_synonym
					)

			DELETE a
			FROM re_subscription A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.control_bt_synonym NOT IN (
					SELECT b.control_bt_synonym
					FROM re_ui_traversal B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = a.page_bt_synonym
					)

			--- Code modified by Saravanan on 25/04/2005 for PNR2.0-2144
			--- Delete Publication DataItem, Subcription DataItem excluding BT's in DE_HIDDEN_VIEW
			--- while download of RCN.
			DELETE a
			FROM re_subscription_dataitem A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND subscribed_bt_synonym NOT IN (
					SELECT b.control_bt_synonym
					FROM re_ui_control B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = a.page_bt_synonym
					
					UNION
					
					-- code modified by shafina on 26-Aug-2004 for ECENG203ACC_000062 (subscription , subscription dataitem , publication , publication dataitem , flowbr tables must be checked for control/task existence else data must be deleted.)
					SELECT g.column_bt_synonym
					FROM re_ui_grid G(NOLOCK)
					WHERE g.customer_name = (@engg_customer_name)
						AND g.project_name = (@engg_project_name)
						AND g.process_name = (@proc_name)
						AND g.component_name = (@comp_name)
						AND g.activity_name = (@act_name)
						AND g.ui_name = (@ui_name)
						AND g.page_bt_synonym = a.page_bt_synonym
					
					UNION
					
					SELECT hidden_view_bt_synonym
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND page_name = a.page_bt_synonym
					)

			--- Code modified by Saravanan on 25/04/2005 for PNR2.0-2144
			--- Delete Publication DataItem, Subcription DataItem excluding BT's in DE_HIDDEN_VIEW
			--- while download of RCN.
			DELETE a
			FROM re_publication_dataitem A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND published_bt_synonym NOT IN (
					SELECT b.control_bt_synonym
					FROM re_ui_control B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = a.page_bt_synonym
					
					UNION
					
					SELECT g.column_bt_synonym
					FROM re_ui_grid G(NOLOCK)
					WHERE g.customer_name = (@engg_customer_name)
						AND g.project_name = (@engg_project_name)
						AND g.process_name = (@proc_name)
						AND g.component_name = (@comp_name)
						AND g.activity_name = (@act_name)
						AND g.ui_name = (@ui_name)
						AND g.page_bt_synonym = a.page_bt_synonym
					
					UNION
					
					SELECT quick_code_value
					FROM re_quick_code_mst(NOLOCK)
					WHERE quick_code_type = 'RE_CONTEXT'
					
					UNION
					
					SELECT hidden_view_bt_synonym
					FROM de_hidden_view(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND page_name = a.page_bt_synonym
					)

			DELETE a
			FROM re_resolved_link_dataitem A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.subscribed_bt_synonym NOT IN (
					SELECT b.subscribed_bt_synonym
					FROM re_subscription_dataitem B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.page_bt_synonym = a.page_bt_synonym
					)

			/*Code added by Gankan.G for the CaseId:PNR2.0_32366 to filter dataitems to handle link issue starts*/
			DELETE a
			FROM re_subscription_dataitem a,
				ep_ui_control_dtl b,
				es_comp_ctrl_type_mst c(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.subscribed_bt_synonym = b.control_bt_synonym
				AND a.subscribed_control_name = b.control_id
				AND a.subscribed_view_name = b.view_name
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND b.control_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'Link'

			DELETE a
			FROM re_publication_dataitem a,
				ep_ui_control_dtl b,
				es_comp_ctrl_type_mst c(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.published_bt_synonym = b.control_bt_synonym
				AND a.published_control_name = b.control_id
				AND a.published_view_name = b.view_name
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND b.control_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'Link'

			DELETE a
			FROM re_resolved_link_dataitem a
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND NOT EXISTS (
					SELECT 'x'
					FROM re_subscription_dataitem b(NOLOCK)
					WHERE a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.subscription_name = b.subscription_name
						AND a.subscribed_bt_synonym = b.subscribed_bt_synonym
						AND a.subscribed_control_name = b.subscribed_control_name
						AND a.subscribed_view_name = b.subscribed_view_name
					)

			DELETE a
			FROM re_resolved_link_dataitem a
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.publication_comp_name = (@comp_name)
				AND NOT EXISTS (
					SELECT 'x'
					FROM re_publication_dataitem b(NOLOCK)
					WHERE a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.publication_comp_name = b.component_name
						AND a.publication_act_name = b.activity_name
						AND a.publication_ui_name = b.ui_name
						AND a.publication_name = b.publication_name
						--and   a.published_bt_synonym  = b.published_bt_synonym  --Code modifications for PLF2.0_01359 starts
						--and   a.published_control_name = b.published_control_name
						--and   a.published_view_name  = b.published_view_name
						AND isnull(a.published_control_name, '') = isnull(b.published_control_name, '')
						AND isnull(a.published_view_name, '') = isnull(b.published_view_name, '')
					) --Code modifications for PLF2.0_01359 ends

			/*Code added by Gankan.G for the CaseId:PNR2.0_32366 to filter dataitems to handle link issue ends*/
			-- code commented and modified for PNR2.0_27106 on 08-Jun-2010  - Begins
			-- delete a
			-- from re_resolved_link_dataitem A
			-- where a.customer_name   = (@engg_customer_name)
			-- and  a.project_name   = (@engg_project_name)
			-- and  a.publication_comp_name = (@comp_name)
			-- and  a.publication_act_name = (@act_name)
			-- and  a.publication_ui_name = (@ui_name)
			-- and  a.published_bt_synonym not in
			-- (select b.published_bt_synonym
			-- -- code modified by shafina on 23-Aug-2004 for ECENG203ACC_000063 (While downloading RCN , Invalid Object Name 'ep_published_dataitem' error is thrown.)
			-- from re_publication_dataitem B(nolock)
			-- where b.customer_name   = (@engg_customer_name)
			-- and  b.project_name   = (@engg_project_name)
			-- and  b.process_name   = (@proc_name)
			-- and  b.component_name  = (@comp_name)
			-- and  b.activity_name   = (@act_name)
			-- and  b.ui_name    = (@ui_name)
			-- and  b.dataitemname   = a.dataitemname)
			--
			DELETE a
			FROM re_resolved_link_dataitem A
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.publication_comp_name = (@comp_name)
				AND a.publication_act_name = (@act_name)
				AND a.publication_ui_name = (@ui_name)
				AND a.dataitemname NOT IN (
					SELECT b.dataitemname
					FROM re_publication_dataitem B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND b.publication_name = a.publication_name
					)

			-- code commented and modified for PNR2.0_27106 on 08-Jun-2010  - Ends
			DECLARE del_cursor INSENSITIVE CURSOR
			FOR
			SELECT page_bt_synonym,
				task_name,
				flowbr_name,
				combo_bt_synonym,
				combo_page_name
			FROM re_flowbr_combo A(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND combo_bt_synonym NOT IN (
					SELECT control_bt_synonym
					FROM re_ui_control B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND a.combo_page_name = b.page_bt_synonym
					
					UNION
					
					SELECT column_bt_synonym
					FROM re_ui_grid B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
						AND a.combo_page_name = b.page_bt_synonym
					)

			OPEN del_cursor

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM del_cursor
				INTO @page_bt_synonym_del,
					@task_name_del,
					@flowbr_name_del,
					@combo_bt_synonym,
					@combo_page_name

				-- code added by shafina on 24-sep-2004 for ECENG203ACC_000063 (system got hanged on dnld of ecr)
				IF @@fetch_status <> 0
					BREAK

				DELETE re_flowbr_combo
				WHERE customer_name = (@engg_customer_name)
					AND project_name = (@engg_project_name)
					AND process_name = (@proc_name)
					AND component_name = (@comp_name)
					AND activity_name = (@act_name)
					AND ui_name = (@ui_name)
					AND page_bt_synonym = (@page_bt_synonym_del)
					AND task_name = (@task_name_del)
					AND combo_bt_synonym = (@combo_bt_synonym)
					AND combo_page_name = (@combo_page_name)

				-- code added by shafina on 25-sep-2004 for ECENG203ACC_000063 (In Re_flowbr_combo table , records got deleted)
				SELECT @control_id_tmp = control_id,
					@view_name_tmp = view_name
				FROM re_ui_control(NOLOCK)
				WHERE customer_name = (@engg_customer_name)
					AND project_name = (@engg_project_name)
					AND process_name = (@proc_name)
					AND component_name = (@comp_name)
					AND activity_name = (@act_name)
					AND ui_name = (@ui_name)
					AND page_bt_synonym = (@page_bt_synonym_del)
					AND control_bt_synonym = (@combo_bt_synonym)

				IF isnull(@control_id_tmp, '') = ''
				BEGIN
					SELECT @control_id_tmp = control_id,
						@view_name_tmp = view_name
					FROM re_ui_grid(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND page_bt_synonym = (@page_bt_synonym_del)
						AND column_bt_synonym = (@combo_bt_synonym)
				END

				DELETE a
				FROM re_flowbr_br_error A,
					re_flowbr B
				WHERE a.customer_name = (@engg_customer_name)
					AND a.project_name = (@engg_project_name)
					AND a.process_name = (@proc_name)
					AND a.component_name = (@comp_name)
					AND a.activity_name = (@act_name)
					AND a.ui_name = (@ui_name)
					AND a.page_bt_synonym = (@page_bt_synonym_del)
					AND a.task_name = (@task_name_del)
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.task_name = b.task_name
					AND a.flowbr_name = b.flowbr_name
					AND b.control_id = @control_id_tmp
					AND b.view_name = @view_name_tmp

				DELETE a
				FROM re_flowbr_rule_map A,
					re_flowbr B
				WHERE a.customer_name = (@engg_customer_name)
					AND a.project_name = (@engg_project_name)
					AND a.process_name = (@proc_name)
					AND a.component_name = (@comp_name)
					AND a.activity_name = (@act_name)
					AND a.ui_name = (@ui_name)
					AND a.page_bt_synonym = (@page_bt_synonym_del)
					AND a.task_name = (@task_name_del)
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_bt_synonym = b.page_bt_synonym
					AND a.task_name = b.task_name
					AND a.flowbr_name = b.flowbr_name
					AND b.control_id = @control_id_tmp
					AND b.view_name = @view_name_tmp

				DELETE a
				FROM re_flowbr A
				WHERE a.customer_name = (@engg_customer_name)
					AND a.project_name = (@engg_project_name)
					AND a.process_name = (@proc_name)
					AND a.component_name = (@comp_name)
					AND a.activity_name = (@act_name)
					AND a.ui_name = (@ui_name)
					AND a.page_bt_synonym = (@page_bt_synonym_del)
					AND a.task_name = (@task_name_del)
					AND a.control_id = @control_id_tmp
					AND a.view_name = @view_name_tmp
			END

			CLOSE del_cursor

			DEALLOCATE del_cursor

			DELETE a
			FROM re_flowbr_combo A
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND task_name NOT IN (
					SELECT task_name
					FROM re_action B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
					)

			DELETE re_flowbr_br_error
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND task_name NOT IN (
					SELECT task_name
					FROM re_action B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
					)

			DELETE re_flowbr_rule_map
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND task_name NOT IN (
					SELECT task_name
					FROM re_action B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
					)

			DELETE re_flowbr
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND task_name NOT IN (
					SELECT task_name
					FROM re_action B(NOLOCK)
					WHERE b.customer_name = (@engg_customer_name)
						AND b.project_name = (@engg_project_name)
						AND b.process_name = (@proc_name)
						AND b.component_name = (@comp_name)
						AND b.activity_name = (@act_name)
						AND b.ui_name = (@ui_name)
					)

			--Code added for the Bug ID : PNR2.0_32748 starts
			DELETE a
			FROM re_flowbr_combo a(NOLOCK),
				re_ui_control b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK),
				re_ui_section sec(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.combo_page_name = b.page_bt_synonym
				AND a.combo_bt_synonym = b.control_bt_synonym
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.control_type = c.ctrl_type_name
				AND c.base_ctrl_type <> 'combo'
				AND isnull(c.is_extjs_control, 'N') = 'N'
				AND sec.customer_name = b.customer_name
				AND sec.project_name = b.project_name
				AND sec.process_name = b.process_name
				AND sec.component_name = b.component_name
				AND sec.activity_name = b.activity_name
				AND sec.ui_name = b.ui_name
				AND sec.page_bt_synonym = b.page_bt_synonym
				AND sec.section_bt_synonym = b.section_bt_synonym
				AND sec.section_type = 'Main'

			DELETE a
			FROM re_flowbr_combo a(NOLOCK),
				re_ui_grid b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK),
				re_ui_section sec(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.combo_page_name = b.page_bt_synonym
				AND a.combo_bt_synonym = b.column_bt_synonym
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.column_type = c.ctrl_type_name
				AND c.base_ctrl_type <> 'combo'
				AND isnull(c.is_extjs_control, 'N') = 'N'
				AND sec.customer_name = b.customer_name
				AND sec.project_name = b.project_name
				AND sec.process_name = b.process_name
				AND sec.component_name = b.component_name
				AND sec.activity_name = b.activity_name
				AND sec.ui_name = b.ui_name
				AND sec.page_bt_synonym = b.page_bt_synonym
				AND sec.section_bt_synonym = b.section_bt_synonym
				AND sec.section_type = 'Main'

			--Code added for Bug ID: PNR2.0_32748 ends
			UPDATE a
			SET a.subscribed_control_name = control_id,
				a.subscribed_view_name = view_name
			FROM re_subscription_dataitem A(NOLOCK),
				re_ui_control B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.subscribed_bt_synonym = b.control_bt_synonym

			UPDATE a
			SET a.subscribed_control_name = control_id,
				a.subscribed_view_name = view_name
			FROM re_subscription_dataitem A(NOLOCK),
				re_ui_grid B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.subscribed_bt_synonym = b.column_bt_synonym

			UPDATE a
			SET a.published_control_name = control_id,
				a.published_view_name = view_name
			FROM re_publication_dataitem A(NOLOCK),
				re_ui_control B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.published_bt_synonym = b.control_bt_synonym

			UPDATE a
			SET a.published_control_name = control_id,
				a.published_view_name = view_name
			FROM re_publication_dataitem A(NOLOCK),
				re_ui_grid B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.published_bt_synonym = b.column_bt_synonym

			UPDATE a
			SET a.subscribed_control_name = b.subscribed_control_name,
				a.subscribed_view_name = b.subscribed_view_name
			FROM re_resolved_link_dataitem A(NOLOCK),
				re_subscription_dataitem B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.subscription_name = b.subscription_name
				-- code modified by shafina on 08-Sep-2004 for ECENG203ACC_000062 (to modify the join)
				AND a.subscribed_bt_synonym = b.subscribed_bt_synonym

			UPDATE a
			SET a.published_control_name = b.published_control_name,
				a.published_view_name = b.published_view_name
			FROM re_resolved_link_dataitem A(NOLOCK),
				re_publication_dataitem B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.publication_comp_name = b.component_name
				AND a.publication_act_name = b.activity_name
				AND a.publication_ui_name = b.ui_name
				AND a.publication_name = b.publication_name
				AND a.dataitemname = b.dataitemname
				AND a.published_bt_synonym = b.published_bt_synonym

			-- code modified by shafina on 25-Oct-2004 for ECENG203ACC_000083 (When a control is changed from link to help or vice versa, it's link type in subscription table must also be changed )
			UPDATE a
			SET a.link_type = b.link_type
			FROM re_subscription A(NOLOCK),
				re_ui_traversal B(NOLOCK)
			WHERE a.customer_name = (@engg_customer_name)
				AND a.project_name = (@engg_project_name)
				AND a.process_name = (@proc_name)
				AND a.component_name = (@comp_name)
				AND a.activity_name = (@act_name)
				AND a.ui_name = (@ui_name)
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.control_bt_synonym = b.control_bt_synonym

			-- code added for the BUG ID :: PNR2.0_14686 - start
			IF EXISTS (
					SELECT 'x'
					FROM re_subscription A(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @proc_name
						AND a.component_name = @comp_name
						AND a.activity_name = @act_name
						AND a.ui_name = @ui_name
						AND a.post_task NOT IN (
							SELECT DISTINCT b.task_name
							FROM re_action b(NOLOCK)
							WHERE b.customer_name = @engg_customer_name
								AND b.project_name = @engg_project_name
								AND b.process_name = @proc_name
								AND b.component_name = @comp_name
								AND b.activity_name = @act_name
								AND b.ui_name = @ui_name
							)
					)
			BEGIN
				UPDATE a
				SET post_task = NULL
				FROM re_subscription a(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @proc_name
					AND a.component_name = @comp_name
					AND a.activity_name = @act_name
					AND a.ui_name = @ui_name
					AND a.post_task NOT IN (
						SELECT DISTINCT b.task_name
						FROM re_action b(NOLOCK)
						WHERE b.customer_name = @engg_customer_name
							AND b.project_name = @engg_project_name
							AND b.process_name = @proc_name
							AND b.component_name = @comp_name
							AND b.activity_name = @act_name
							AND b.ui_name = @ui_name
						)
			END

			-- code added for the BUG ID :: PNR2.0_14686 - End
			---------------------------------------------------------------------------------------------
			--   exec  re_radio_button_log @ctxt_language,            @ctxt_ouinstance,      @ctxt_service, @ctxt_user,
			--                             @engg_customer_name,@engg_project_name, @rcr_no,@engg_ecr_no,@proc_name,
			--                             @comp_name,              @act_name,                @ui_name,      @m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--                              close mainui_cur
			--                         deallocate mainui_cur
			--     return
			--        end
			---------------------------------------------------------------------------------------------
			--   if exists ( select 'x' from re_radio_button (nolock)
			--       where customer_name   = (@engg_customer_name)
			--      and  project_name   = (@engg_project_name)
			--      and  process_name   = (@proc_name)
			--      and  component_name   = (@comp_name)
			--      and  activity_name   = (@act_name)
			--      and  ui_name     = (@ui_name)
			--     )
			--   begin--4
			DELETE
			FROM re_radio_button
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--   end--4
			INSERT INTO re_radio_button (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				button_code,
				seq_no,
				button_caption,
				default_flag,
				radio_button_sysid,
				ui_control_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				horder,
				vorder,
				rcnno --chan
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				button_code,
				seq_no,
				button_caption,
				default_flag,
				radio_button_sysid,
				ui_control_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				horder,
				vorder,
				@engg_ecr_no
			FROM ep_published_radio_button_dtl_vw(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			---------------------------------------------------------------------------------------
			--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
			DELETE
			FROM re_radio_button_lng_extn
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_radio_button_lng_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				button_code,
				seq_no,
				button_caption,
				default_flag,
				radio_button_sysid,
				ui_control_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				horder,
				vorder,
				languageid,
				rcnno --chan
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				button_code,
				seq_no,
				button_caption,
				default_flag,
				radio_button_sysid,
				ui_control_sysid,
				1,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				horder,
				vorder,
				languageid,
				@engg_ecr_no
			FROM ep_published_radio_button_dtl_lng_extn(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
			---------------------------------------------------------------------------------
			--Added by Feroz for 203_2
			--  re_tree_dtl
			DELETE
			FROM re_tree_dtl
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_tree_dtl (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_type,
				node_description,
				event_req,
				mapped_task,
				open_img_name,
				not_exp_img_name,
				expendable_img_name,
				expended_img_name,
				close_img_name,
				chkbox_chk_img,
				chkbox_unchk_img,
				chkbox_parial_chkimg,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno --chan
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_type,
				node_description,
				event_req,
				mapped_task,
				open_img_name,
				not_exp_img_name,
				expendable_img_name,
				expended_img_name,
				close_img_name,
				chkbox_chk_img,
				chkbox_unchk_img,
				chkbox_parial_chkimg,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no
			FROM ep_published_tree_dtl(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			-- re_tree_sample_data
			DELETE
			FROM re_tree_sample_data
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_tree_sample_data (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_type,
				node_description,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				Node_id,
				rcnno --chan
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_type,
				node_description,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				Node_id,
				@engg_ecr_no
			FROM ep_published_tree_sample_data(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			-- re_tree_sample_data_map
			DELETE
			FROM re_tree_sample_data_map
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_tree_sample_data_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_id,
				parent_node_id,
				node_type,
				node_description,
				parent_node_type,
				parent_node_descr,
				mapped_flag,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno --chan
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				node_id,
				parent_node_id,
				node_type,
				node_description,
				parent_node_type,
				parent_node_descr,
				mapped_flag,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no
			FROM ep_published_tree_sample_data_map(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--Added by Feroz for 203_3
			--------------------------------------------------------------------------------------------
			DELETE
			FROM re_chart_header
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_chart_header (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				chart_type,
				chart_desc,
				chart_title,
				tooltip,
				datagrid,
				datagrid_type,
				legend_title,
				width,
				height,
				font,
				font_size,
				font_color,
				series_legend,
				background_color,
				graphicsmode,
				legend_font,
				legend_font_size,
				legend_font_color,
				x_axis_title,
				x_series_elements,
				x_error_band_type,
				x_error_marker_type,
				x_error_marker_size,
				x_error_marker_val,
				y_axis_title,
				x_auto_scale,
				x_divisions_min,
				x_divisions_max,
				x_units,
				x_cal_err_value,
				y_units,
				x_showvalue,
				X_showname,
				x_font,
				x_font_size,
				x_font_color,
				x_con_type,
				x_con_color,
				x_con_style,
				x_con_weight,
				x_con_wt_val,
				x_marker_type,
				x_marker_size,
				x_marker_color,
				x_marker_size_val,
				y_series_elements,
				y_error_band_type,
				y_error_marker_type,
				y_error_marker_size,
				y_error_marker_value,
				y_auto_scale,
				y_divisions_min,
				y_divisions_max,
				y_secondary_axis,
				y_cal_err_value,
				y_font,
				y_font_size,
				y_font_color,
				y_con_type,
				y_connector_color,
				y_connector_style,
				y_con_weight,
				y_con_wt_val,
				y_marker_type,
				y_marker_size,
				y_marker_color,
				y_marker_size_val,
				background_image,
				override_chart_type,
				x_show_err_band,
				y_show_err_band,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno,
				x_numdivlines,
				y_numdivlines,
				canvas_color,
				divline_color
				) --Code Modified for the Bug ID: PNR2.0_34035
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				chart_type,
				chart_desc,
				chart_title,
				tooltip,
				datagrid,
				datagrid_type,
				legend_title,
				width,
				height,
				font,
				font_size,
				font_color,
				series_legend,
				background_color,
				graphicsmode,
				legend_font,
				legend_font_size,
				legend_font_color,
				x_axis_title,
				x_series_elements,
				x_error_band_type,
				x_error_marker_type,
				x_error_marker_size,
				x_error_marker_val,
				y_axis_title,
				x_auto_scale,
				x_divisions_min,
				x_divisions_max,
				x_units,
				x_cal_err_value,
				y_units,
				x_showvalue,
				X_showname,
				x_font,
				x_font_size,
				x_font_color,
				x_con_type,
				x_con_color,
				x_con_style,
				x_con_weight,
				x_con_wt_val,
				x_marker_type,
				x_marker_size,
				x_marker_color,
				x_marker_size_val,
				y_series_elements,
				y_error_band_type,
				y_error_marker_type,
				y_error_marker_size,
				y_error_marker_value,
				y_auto_scale,
				y_divisions_min,
				y_divisions_max,
				y_secondary_axis,
				y_cal_err_value,
				y_font,
				y_font_size,
				y_font_color,
				y_con_type,
				y_connector_color,
				y_connector_style,
				y_con_weight,
				y_con_wt_val,
				y_marker_type,
				y_marker_size,
				y_marker_color,
				y_marker_size_val,
				background,
				override_chart_type,
				x_show_err_band,
				y_show_err_band,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no,
				x_numdivlines,
				y_numdivlines,
				canvas_color,
				divline_color --Code Modified for the Bug ID: PNR2.0_34035
			FROM ep_published_chart_header(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--------------------------------------------------------------------------------------------
			DELETE
			FROM re_chart_sample_data
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_chart_sample_data (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				x_series_data,
				y_series_id,
				y_value,
				y_error_value,
				tooltip_text,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				) --chan
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				x_series_data,
				y_series_id,
				y_value,
				y_error_value,
				tooltip_text,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no
			FROM ep_published_chart_sample_data(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			--------------------------------------------------------------------------------------------
			DELETE
			FROM re_chart_series
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_chart_series (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				axis_id,
				series_id,
				series_name,
				con_type,
				con_color,
				con_style,
				con_weight,
				con_wt_val,
				marker_type,
				marker_size,
				marker_size_val,
				mark_color,
				error_band_type,
				error_marker_type,
				error_marker_size,
				err_mark_size_val,
				auto_scale,
				divisions_min,
				divisions_max,
				units,
				x_showvalue,
				x_showname,
				sequence,
				y_secondary_axis,
				Y_legend_caption,
				cal_err_value,
				error_bands,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				chart_type,
				rcnno
				) --chan
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				axis_id,
				series_id,
				series_name,
				con_type,
				con_color,
				con_style,
				con_weight,
				con_wt_val,
				marker_type,
				marker_size,
				marker_size_val,
				mark_color,
				error_band_type,
				error_marker_type,
				error_marker_size,
				err_mark_size_val,
				auto_scale,
				divisions_min,
				divisions_max,
				units,
				x_showvalue,
				x_showname,
				sequence,
				y_secondary_axis,
				Y_legend_caption,
				cal_err_value,
				error_bands,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				chart_type,
				@engg_ecr_no
			FROM ep_published_chart_series(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND req_no = (@rcr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			------------------------------------------------------------------------------------------------------
			--Added by Feroz for spin
			DELETE
			FROM re_spin_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_spin_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				spin_control_bt_synonym,
				spincontrol_section,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				) --chan
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				control_type,
				spin_control_bt_synonym,
				spincontrol_section,
				@ctxt_user,
				@getdate,
				@ctxt_user,
				@getdate,
				@engg_ecr_no
			FROM ep_published_spin_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			------------------------------------------------------------------------------------------------------
			-- code added for state processing by feroz starts
			INSERT INTO re_ui_state (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				state_id,
				state_descr,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				system_state,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				state_id,
				state_descr,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				system_state,
				@engg_ecr_no --chan
			FROM ep_published_ui_state_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_state_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				collapse,
				visible,
				enable,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				collapse,
				visible,
				enable,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_ui_state_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_state_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				control_bt_synonym,
				visible,
				enable,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				control_bt_synonym,
				visible,
				enable,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_ui_state_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_state_task (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				task_name,
				rt_state,
				focus_control,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				task_name,
				rt_state,
				focus_control,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_ui_state_task_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_state_task_mst (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				task_name,
				task_descr,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				task_name,
				task_descr,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_ui_state_task_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added for the BugId PNR2.0_1790 Starts
			INSERT INTO re_ui_state_column (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_no,
				visible,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcn_no,
				enable
				) -- column enable added on 1 april
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				section_bt_synonym,
				control_bt_synonym,
				column_bt_synonym,
				column_no,
				visible,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no,
				enable
			FROM ep_published_ui_state_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code modification  for  PNR2.0_22275 starts
			INSERT INTO re_ui_state_page (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				visible,
				enable,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcn_no,
				focus
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				state_id,
				visible,
				enable,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no,
				focus
			FROM ep_published_ui_state_page_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code modification  for  PNR2.0_22275 ends
			-- Code added for the BugId PNR2.0_1790 Ends
			-- code added for state processing by feroz ends
			--------------------------------------------------------------------------------------------------------
			-- Code added for the BugId PNR2.0_1790 Starts
			DELETE
			FROM re_ezeeview_sp
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ezeeview_sp (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Link_ControlName,
				Target_SPName,
				Link_Caption,
				Linked_Component,
				Linked_Activity,
				Linked_ui,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				Linked_Task
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Link_ControlName,
				Target_SPName,
				Link_Caption,
				Linked_Component,
				Linked_Activity,
				Linked_ui,
				TIMESTAMP,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				Linked_Task
			FROM ep_published_ezeeview_sp(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ezeeview_spparamlist
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ezeeview_spparamlist (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Link_ControlName,
				Target_SPName,
				ParameterName,
				Mapped_Control,
				Link_Caption,
				--code modified for the caseid :PNR2.0_24424 starts
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_page_name
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Link_ControlName,
				Target_SPName,
				ParameterName,
				Mapped_Control,
				Link_Caption,
				TIMESTAMP,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				control_page_name
			--code modified for the caseid :PNR2.0_24424 ends
			FROM ep_published_ezeeview_spparamlist(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added for the BugId PNR2.0_1790 ends
			-- Code added for the BugId PNR2.0_1790 Starts
			DELETE
			FROM re_ext_js_section
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ext_js_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				Section_Width,
				Section_Height,
				Section_Class,
				RVW_Task,
				Callout_Task,
				Direction,
				Scroll_Behaviour,
				Scroll_Delay,
				Fade_Delay,
				No_Of_Columns,
				Report_Item_Class,
				Property_Class,
				Value_Class,
				sample_data,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				Section_Width,
				Section_Height,
				Section_Class,
				RVW_Task,
				Callout_Task,
				Direction,
				Scroll_Behaviour,
				Scroll_Delay,
				Fade_Delay,
				No_Of_Columns,
				Report_Item_Class,
				Property_Class,
				Value_Class,
				sample_data,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_ext_js_section_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ext_js_control
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ext_js_control (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				Extjs_Ctrl_type,
				Ctrl_height,
				ctrl_width,
				Control_Class,
				RVW_Task,
				Callout_Task,
				Type_Delay,
				Type_Direction,
				Fade_Delay,
				Fade_Direction,
				Loop_Count,
				sample_data,
				feature_name,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				Extjs_Ctrl_type,
				Ctrl_height,
				ctrl_width,
				Control_Class,
				RVW_Task,
				Callout_Task,
				Type_Delay,
				Type_Direction,
				Fade_Delay,
				Fade_Direction,
				Loop_Count,
				sample_data,
				feature_name,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_ext_js_control_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ext_js_section_column
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ext_js_section_column (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				control_bt_synonym,
				column_sequence,
				column_bt_synonym,
				is_key,
				datatype,
				grouping,
				grouping_function,
				grouping_synonym,
				rvw_task,
				callout_task,
				label_class,
				control_class,
				sample_data,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				FieldList,
				Default_Dragoption,
				column_type,
				pivot_sequence,
				visible_length,
				image_column
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				section_type,
				control_bt_synonym,
				column_sequence,
				column_bt_synonym,
				is_key,
				datatype,
				grouping,
				grouping_function,
				grouping_synonym,
				rvw_task,
				callout_task,
				label_class,
				control_class,
				sample_data,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				FieldList,
				Default_Dragoption,
				column_type,
				pivot_sequence,
				visible_length,
				image_column
			FROM ep_published_ext_js_section_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added for the BugId PNR2.0_1790 Ends
			----------------------------------------------------------------------------------------------
			-- code added by feroz for listedit Start
			DELETE
			FROM re_listedit_column
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_listedit_control_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_resolvelist_data_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_listedit_column (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				listedit_synonym,
				listedit_column_synonym,
				listedit_column_seqno,
				listedit_controlid,
				listedit_viewname,
				rcnno,
				column_prefix,
				createdby,
				createddate,
				visible_length
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				listedit_synonym,
				listedit_column_synonym,
				listedit_column_seqno,
				listedit_controlid,
				listedit_viewname,
				@engg_ecr_no,
				column_prefix,
				@ctxt_user,
				getdate(),
				visible_length
			FROM ep_published_listedit_column_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_listedit_control_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				mapped_bt_synonym,
				listedit_synonym,
				rcnno,
				control_id,
				view_name,
				createdby,
				createddate,
				listedit_controlid,
				listedit_viewname
				) -- Modified By feroz for bug id :PNR2.0_23463
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				mapped_bt_synonym,
				listedit_synonym,
				@engg_ecr_no,
				control_id,
				view_name,
				@ctxt_user,
				getdate(),
				listedit_controlid,
				listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
			FROM ep_published_listedit_control_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--Modification for the defect id: TECH-16126
			INSERT INTO re_resolvelist_data_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				listedit_synonym,
				mapped_bt_synonym,
				listedit_column_synonym,
				data_mapped_synonym,
				primary_search_column,
				list_index_search,
				control_id,
				view_name,
				visible,
				rcnno,
				createdby,
				createddate,
				mapped_bt_syn_page,
				map_listdata
				) --Modified for  PNR2.0_26701
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				listedit_synonym,
				mapped_bt_synonym,
				listedit_column_synonym,
				data_mapped_synonym,
				primary_search_column,
				list_index_search,
				control_id,
				view_name,
				visible,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				mapped_bt_syn_page,
				map_listdata --Modified for  PNR2.0_26701
			FROM ep_published_resolvelist_data_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--Modification for the defect id: TECH-16126
			DELETE
			FROM re_date_highlight_control_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_date_highlight_control_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				listedit_synonym,
				control_bt_synonym,
				controlid,
				viewname,
				listedit_controlid,
				listedit_viewname,
				createdby,
				createddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				listedit_synonym,
				control_bt_synonym,
				controlid,
				viewname,
				listedit_controlid,
				listedit_viewname,
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_date_highlight_control_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			---- specify temaplate changes
			DELETE
			FROM re_ui_Temp_placeholders
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_template_controlmap
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_Temp_placeholders (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Control_bt_synonym,
				section_bt_synonym,
				templateid,
				control_id,
				view_name,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				rcnno,
				placeholder,
				associatedColumn,
				associatedevent
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				Control_bt_synonym,
				section_bt_synonym,
				templateid,
				control_id,
				view_name,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ecr_no,
				placeholder,
				associatedColumn,
				associatedevent
			FROM ep_published_ui_Temp_placeholders(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_template_controlmap (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				templateid,
				control_id,
				view_name,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				@engg_ecr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				templateid,
				control_id,
				view_name,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_ui_template_controlmap(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- code added by feroz for listedit End
			-- Code added By Feroz for UI ToolBar Start
			DELETE
			FROM re_ui_toolbar_group
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_toolbar
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_displaytext_lang_extn
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			DELETE
			FROM re_ui_toolbar_mapping
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_toolbar_group (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_name,
				group_descr,
				createddate,
				createdby,
				modifieddate,
				modifiedby,
				rcnno,
				Orientation
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_name,
				group_descr,
				getdate(),
				@ctxt_user,
				getdate(),
				@ctxt_user,
				@engg_ecr_no,
				Orientation
			FROM ep_published_ui_toolbar_group_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_toolbar (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_name,
				group_task_name,
				task_seqno,
				class_name,
				display_text,
				group_task_desc,
				createddate,
				createdby,
				modifieddate,
				modifiedby,
				rcnno,
				group_node_task
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_name,
				group_task_name,
				task_seqno,
				class_name,
				display_text,
				group_task_desc,
				getdate(),
				@ctxt_user,
				getdate(),
				@ctxt_user,
				@engg_ecr_no,
				group_node_task
			FROM ep_published_ui_toolbar_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_displaytext_lang_extn (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_task_name,
				display_text,
				lang_id,
				createddate,
				createdby,
				rcnno,
				group_name
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				group_task_name,
				display_text,
				lang_id,
				getdate(),
				@ctxt_user,
				@engg_ecr_no,
				group_name
			FROM ep_published_ui_displaytext_lang_extn(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_ui_toolbar_mapping (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				toolbar_id,
				group_task_name,
				display_seqno,
				class_name,
				display_text,
				caption_req,
				control_req,
				createddate,
				createdby,
				modifieddate,
				modifiedby,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				toolbar_id,
				group_task_name,
				display_seqno,
				class_name,
				display_text,
				caption_req,
				control_req,
				getdate(),
				@ctxt_user,
				getdate(),
				@ctxt_user,
				@engg_ecr_no
			FROM ep_published_ui_toolbar_mapping_dtl(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- Code added By Feroz for UI ToolBar End
			-- code added by  Jeya for Dynamic SectionEnd
			DELETE
			FROM re_dynamic_sec_control_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_dynamic_sec_control_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				controlid,
				viewname,
				createdby,
				createddate,
				rcnno
				)
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				controlid,
				viewname,
				@ctxt_user,
				getdate(),
				@engg_ecr_no
			FROM ep_published_dynamic_sec_control_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- code added by Jeya for Dynamic Section End
			--code added by kiruthika for bugid:PLF2.0_03710
			DELETE
			FROM re_custom_listedit
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_custom_listedit (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				listedit_synonym,
				list_search_id,
				list_search_context,
				list_index_search,
				list_recurrent_search,
				list_search_delay,
				list_select_column,
				list_result_column,
				list_width,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT DISTINCT customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				listedit_synonym,
				list_search_id,
				list_search_context,
				list_index_search,
				list_recurrent_search,
				list_search_delay,
				list_select_column,
				list_result_column,
				list_width,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_custom_listedit(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			--code added by kiruthika for bugid:PLF2.0_03710
			----------------------------------------------------------------------------------------------
			--- Below code added for Sync View by Ganesh Prabhu
			DELETE
			FROM re_sync_view
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				--and   rcnno     = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_sync_view (
				Customer_name,
				Project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				legrid_control_bt_syonym,
				legrid_control_id,
				legrid_view_name,
				map_le_synonym,
				map_le_column_synonym,
				map_le_controlid,
				map_le_viewname,
				map_legrid_view_name,
				rcnno,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				legrid_column_bt_synonym,
				map_legrid_column_bt_synonym
				)
			SELECT Customer_name,
				Project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				legrid_control_bt_syonym,
				legrid_control_id,
				legrid_view_name,
				map_le_synonym,
				map_le_column_synonym,
				map_le_controlid,
				map_le_viewname,
				map_legrid_view_name,
				@engg_ecr_no,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				legrid_column_bt_synonym,
				map_legrid_column_bt_synonym
			FROM ep_published_sync_view(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND req_no = @rcr_no
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			-- COde modified Ends by Ganesh Prabhu 
			-- Added for TECH-36371
			DELETE
			FROM re_nativeapp_mapping
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			INSERT INTO re_nativeapp_mapping (
				customer_name,
				project_name,
				rcnno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_Hidden_bt_synonym,
				MappedGridColumnSynonym,
				control_hiddenview,
				control_id,
				view_name,
				GridControlID,
				GridViewName,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_Hidden_bt_synonym,
				MappedGridColumnSynonym,
				control_hiddenview,
				control_id,
				view_name,
				GridControlID,
				GridViewName,
				@timestamp_tmp,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM ep_published_nativeapp_mapping WITH (NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND req_no = @rcr_no
				AND process_name = @proc_name
				AND component_name = @comp_name
				AND activity_name = @act_name
				AND ui_name = @ui_name

			---------------------------------------------------------------------------------------------
			--   exec  re_flowbr_log      @ctxt_language,            @ctxt_ouinstance,     @ctxt_service, @ctxt_user,
			--                         @engg_customer_name,@engg_project_name,@rcr_no,@engg_ecr_no,@proc_name,
			--                         @comp_name,              @act_name,              @ui_name,       @m_errorid output
			--     if @m_errorid > 0
			--                    begin
			--            close  mainui_cur
			--                         deallocate mainui_cur
			--     return
			--                    end
			--------------------------------------------------------------------------------------------
			--code added by DNR on 02/01/2004 for populating the glossary tables
			--   exec re_glossary_insert @ctxt_language,            @ctxt_ouinstance, @ctxt_service, @ctxt_user,
			--          @engg_customer_name,@rcr_no,@engg_ecr_descr,@engg_ecr_no,@engg_ecr_status,
			--          @engg_project_name,    @proc_name,        @comp_name, @act_name,
			--          @ui_name,                    @m_errorid output
			INSERT INTO re_glossary (
				customer_name,
				project_name,
				bt_synonym_name,
				process_name,
				component_name,
				data_type,
				length,
				bt_synonym_caption,
				glossary_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				ref_bt_synonym_name,
				bt_synonym_doc,
				bt_name,
				synonym_status,
				singleinst_sample_data,
				multiinst_sample_data,
				rcnno,
				IsGlance
				)
			SELECT customer_name,
				project_name,
				bt_synonym_name,
				process_name,
				component_name,
				data_type,
				length,
				bt_synonym_caption,
				newid(),
				TIMESTAMP,
				createdby,
				createddate,
				ref_bt_synonym_name,
				bt_synonym_doc,
				bt_name,
				synonym_status,
				singleinst_sample_data,
				multiinst_sample_data,
				@engg_ecr_no,
				IsGlance
			FROM ep_published_comp_glossary_mst A(NOLOCK)
			WHERE A.customer_name = @engg_customer_name
				AND A.Project_name = @engg_project_name
				AND A.req_no = @rcr_no
				AND A.process_name = @proc_name
				AND A.component_name = @comp_name
				AND A.bt_synonym_name NOT IN (
					SELECT B.bt_synonym_name
					FROM re_glossary B(NOLOCK)
					WHERE A.customer_name = B.customer_name
						AND A.Project_name = B.Project_name
						AND A.process_name = B.process_name
						AND A.component_name = B.component_name
					)

		--Added by 11536 for the case ID TECH-66583 control Type and task type property History

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.ctrl_type_descr		         =	a.ctrl_type_descr,		
					b.base_ctrl_type                 =	a.base_ctrl_type,
					b.mandatory_flag				 =	a.mandatory_flag,				
					b.visisble_flag				     =	a.visisble_flag,				
					b.editable_flag			         =	a.editable_flag,			
					b.caption_req                    =	a.caption_req,
					b.select_flag				     =	a.select_flag,				
					b.zoom_req					     =	a.zoom_req,					
					b.insert_req				     =	a.insert_req,				
					b.delete_req                     =	a.delete_req,
					b.help_req					     =	a.help_req,					
					b.event_handling_req			 =	a.event_handling_req,			
					b.ellipses_req			         =	a.ellipses_req,			
					b.comp_ctrl_type_sysid           =	a.comp_ctrl_type_sysid,
					b.caption_alignment			     =	a.caption_alignment,			
					b.caption_position			     =	a.caption_position,			
					b.caption_wrap			         =	a.caption_wrap,			
					b.visisble_rows                  =	a.visisble_rows,
					b.ctrl_type_doc				     =	a.ctrl_type_doc,				
					b.ctrl_position				     =	a.ctrl_position,				
					b.label_class			         =	a.label_class,			
					b.ctrl_class                     =	a.ctrl_class,
					b.password_char				     =	a.password_char,				
					b.tskimg_class				     =	a.tskimg_class,				
					b.hlpimg_class			         =	a.hlpimg_class,			
					b.disponlycmb_req                =	a.disponlycmb_req,
					b.html_txt_area				     =	a.html_txt_area,				
					b.report_req					 =	a.report_req,					
					b.Auto_tab_stop			         =	a.Auto_tab_stop,			
					b.Spin_required                  =	a.Spin_required,
					b.Spin_up_image				     =	a.Spin_up_image,				
					b.Spin_down_image			     =	a.Spin_down_image,			
					b.InPlace_Calendar		         =	a.InPlace_Calendar,		
					b.EditMask                       =	a.EditMask,
					b.NoofLinesPerRow			     =	a.NoofLinesPerRow,			
					b.RowHeight					     =	a.RowHeight,					
					b.Vscrollbar_Req			     =	a.Vscrollbar_Req,			
					b.Is_Extjs_Control               =	a.Is_Extjs_Control,
					b.Extjs_Ctrl_type			     =	a.Extjs_Ctrl_type,			
					b.gridlite_req				     =	a.gridlite_req,				
					b.bulletlink_req			     =	a.bulletlink_req,			
					b.buttoncombo_req                =	a.buttoncombo_req,
					b.associatedlist_req			 =	a.associatedlist_req,			
					b.onfocustask_req			     =	a.onfocustask_req,			
					b.listrefilltask_req		     =	a.listrefilltask_req,		
					b.attach_document                =	a.attach_document,
					b.image_upload				     =	a.image_upload,				
					b.inplace_image				     =	a.inplace_image,				
					b.listedit_noofcolumns	         =	a.listedit_noofcolumns,	
					b.image_row_height               =	a.image_row_height,
					b.relative_url_path			     =	a.relative_url_path,			
					b.relative_document_path		 =	a.relative_document_path,		
					b.relative_image_path	         =	a.relative_image_path,	
					b.save_doc_content_to_db         =	a.save_doc_content_to_db,
					b.save_image_content_to_db	     =	a.save_image_content_to_db,	
					b.dataascaption				     =	a.dataascaption,				
					b.image_icon				     =	a.image_icon,				
					b.Date_highlight                 =	a.Date_highlight,
					b.ezee_report				     =	a.ezee_report,				
					b.Lite_Attach_Document		     =	a.Lite_Attach_Document,		
					b.Browse_Button_Enable	         =	a.Browse_Button_Enable,	
					b.Delete_Button_Enable           =	a.Delete_Button_Enable,
					b.image_row_width			     =	a.image_row_width,			
					b.image_preview_height		     =	a.image_preview_height,		
					b.image_preview_width	         =	a.image_preview_width,	
					b.image_preview_req              =	a.image_preview_req,
					b.Lite_Attach_Image			     =	a.Lite_Attach_Image,			
					b.timezone					     =	a.timezone,					
					b.autoexpand				     =	a.autoexpand,				
					b.Disp_Only_Apply_Len            =	a.Disp_Only_Apply_Len,
					b.editcombo_req				     =	a.editcombo_req,				
					b.Label_Link					 =	a.Label_Link,					
					b.captiontype			         =	a.captiontype,			
					b.controlstyle                   =	a.controlstyle,
					b.IsListBox					     =	a.IsListBox,					
					b.Toolbar_Not_Req			     =	a.Toolbar_Not_Req,			
					b.ColumnBorder_Not_Req	         =	a.ColumnBorder_Not_Req,	
					b.RowBorder_Not_Req              =	a.RowBorder_Not_Req,
					b.PagenavigationOnly			 =	a.PagenavigationOnly,			
					b.RowNO_Not_Req				     =	a.RowNO_Not_Req,				
					b.ButtonHome_Req			     =	a.ButtonHome_Req,			
					b.ButtonPrevious_Req             =	a.ButtonPrevious_Req,
					b.Accpet_Type				     =	a.Accpet_Type,				
					b.combo_link					 =	a.combo_link,					
					b.QR_Image				         =	a.QR_Image,				
					b.Tooltip_Not_Req                =	a.Tooltip_Not_Req,
					b.Forcefit					     =	a.Forcefit,					
					b.columncaption_Not_Req		     =	a.columncaption_Not_Req	,	
					b.Border_Not_Req			     =	a.Border_Not_Req,			
					b.IsModal                        =	a.IsModal,
					b.Alternate_Color_Req		     =	a.Alternate_Color_Req,		
					b.Map_In_Req					 =	a.Map_In_Req,					
					b.Map_Out_Req			         =	a.Map_Out_Req,			
					b.Barcode_Image                  =	a.Barcode_Image,
					b.Isfallback					 =	a.Isfallback,					
					b.config_parameter			     =	a.config_parameter,			
					b.config_value			         =	a.config_value,			
					b.upload                         =	a.upload,
					b.Is_Varbinary				     =	a.Is_Varbinary,				
					b.FileSize					     =	a.FileSize,					
					b.EMail					         =	a.EMail,					
					b.Phone                          =	a.Phone,
					b.StaticCaption				     =	a.StaticCaption,				
					b.Datagrid					     =	a.Datagrid,					
					b.MoveFirst				         =	a.MoveFirst,			
					b.Move_PrevSet                   =	a.Move_PrevSet,
					b.Move_Previous				     =	a.Move_Previous,				
					b.Move_Next					     =	a.Move_Next,					
					b.Move_NextSet			         =	a.Move_NextSet,			
					b.Move_Last                      =	a.Move_Last,
					b.Carousel_Req				     =	a.Carousel_Req,				
					b.Orientation				     =	a.Orientation,				
					b.WrapCount				         =	a.WrapCount,				
					b.Box_Type                       =	a.Box_Type,
					b.ISDeviceInfo				     =	a.ISDeviceInfo,				
					b.ListControl				     =	a.ListControl,				
					b.col_caption_align		         =	a.col_caption_align,		
					b.Gridheaderstyle                =	a.Gridheaderstyle,
					b.Gridtoolbarstyle			     =	a.Gridtoolbarstyle,			
					b.preevent					     =	a.preevent,					
					b.postevent				         =	a.postevent,				
					b.norowstodisplay_notreq         =	a.norowstodisplay_notreq,
					b.col_data_align				 =	a.col_data_align,				
					b.avn_download				     =	a.avn_download,				
					b.PreventDownload		         =	a.PreventDownload,		
					b.ishijri                        =	a.ishijri,
					b.slider_type				     =	a.slider_type,				
					b.max_value					     =	a.max_value,					
					b.min_value				         =	a.min_value,				
					b.step_value                     =	a.step_value,
					b.spin_system_task			     =	a.spin_system_task,			
					b.enabledefault				     =	a.enabledefault,				
					b.hideinsert				     =	a.hideinsert,				
					b.hidedelete                     =	a.hidedelete,
					b.hidecopy					     =	a.hidecopy,					
					b.hidecut					     =	a.hidecut,					
					b.hidefilterdata			     =	a.hidefilterdata,			
					b.hidepdf                        =	a.hidepdf,
					b.hidereport					 =	a.hidereport,					
					b.hidehtml					     =	a.hidehtml,					
					b.hideexportexcel		         =	a.hideexportexcel,		
					b.hideexportcsv                  =	a.hideexportcsv,
					b.hideexporttext				 =	a.hideexporttext,				
					b.hideimportdata				 =	a.hideimportdata,				
					b.hidechart				         =	a.hidechart,				
					b.hideexportopenoffice           =	a.hideexportopenoffice,
					b.hidepersonalize			     =	a.hidepersonalize,			
					b.hidefiltercolumn			     =	a.hidefiltercolumn,			
					b.searchhide				     =	a.searchhide,				
					b.autolist_not_req               =	a.autolist_not_req,
					b.hideselect					 =	a.hideselect,					
					b.AutoHeight					 =	a.AutoHeight,					
					b.IsPivot				         =	a.IsPivot,				
					b.QlikLink                       =	a.QlikLink,
					b.RangeMinimum				     =	a.RangeMinimum,				
					b.RangeMaximum				     =	a.RangeMaximum,				
					b.RangeStartValue		         =	a.RangeStartValue,		
					b.RangeEndValue                  =	a.RangeEndValue,
					b.RangeStep					     =	a.RangeStep,					
					b.RangeLabel					 =	a.RangeLabel,					
					b.RangeSelect			         =	a.RangeSelect,			
					b.ValueShown                     =	a.ValueShown,
					b.Style						     =	a.Style,						
					b.SystemGeneratedFileId		     =	a.SystemGeneratedFileId,		
					b.IsMarquee				         =	a.IsMarquee,				
					b.IsAssorted                     =	a.IsAssorted,
					b.RatingType					 =	a.RatingType,					
					b.CaptchaData				     =	a.CaptchaData,				
					b.rangetype				         =	a.rangetype,				
					b.RenderAs                       =	a.RenderAs,
					b.noofrowsselected_req		     =	a.noofrowsselected_req,		
					b.AttachmentWithDesc			 =	a.AttachmentWithDesc,			
					b.preserve_gridposition	         =	a.preserve_gridposition,	
					b.Image_Accept_Type              =	a.Image_Accept_Type,
					b.Accept_Type				     =	a.Accept_Type,				
					b.file_Accept_Type			     =	a.file_Accept_Type,			
					b.MlsearchOnly			         =	a.MlsearchOnly,			
					b.hidecolumnchooser              =	a.hidecolumnchooser
			FROM	ep_published_comp_ctrl_type_mst a,
					re_comp_ctrl_type_mst b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.ctrl_type_name	=	a.ctrl_type_name 
			
			AND		a.Customer_Name		=	@engg_customer_name
			AND		a.Project_Name		=	@engg_project_name
			AND		a.Process_Name		=	@proc_name
			AND		a.Component_Name	=	@comp_name
			AND		a.req_no			=	@rcr_no	

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.ctrl_type_descr                =	a.ctrl_type_descr,
					b.base_ctrl_type                 =	a.base_ctrl_type,
					b.Configuration                  =	a.Configuration,
					b.SliderType                     =	a.SliderType,
					b.SliderBehaviour                =	a.SliderBehaviour,
					b.RenderType                     =	a.RenderType,
					b.Orientation                    =	a.Orientation,
					b.Startvalue                     =	a.Startvalue,
					b.Endvalue                       =	a.Endvalue,
					b.Minvalue                       =	a.Minvalue,
					b.Maxvalue                       =	a.Maxvalue,
					b.Stepvalue                      =	a.Stepvalue,
					b.SliderValue                    =	a.SliderValue,
					b.Showvalue                      =	a.Showvalue,
					b.ShowTooltip                    =	a.ShowTooltip,
					b.Rangelabel                     =	a.Rangelabel,
					b.Rangevalue                     =	a.Rangevalue,
					b.Rangetooltip                   =	a.Rangetooltip,
					b.RangeSelect                    =	a.RangeSelect,
					b.ValueShown                     =	a.ValueShown,
					b.ExpandEvent                    =	a.ExpandEvent,
					b.ExpandAllEvent                 =	a.ExpandAllEvent,
					b.CollapseEvent                  =	a.CollapseEvent,
					b.CollapseAllEvent               =	a.CollapseAllEvent,
					b.ClickEvent                     =	a.ClickEvent,
					b.DDToolTip                      =	a.DDToolTip,
					b.ZoomMin                        =	a.ZoomMin,
					b.ZoomMax                        =	a.ZoomMax,
					b.DefaultZoom                    =	a.DefaultZoom,
					b.ZoomStep                       =	a.ZoomStep,
					b.NodeWidth                      =	a.NodeWidth,
					b.NodeHeight                     =	a.NodeHeight,
					b.DefaultFile                    =	a.DefaultFile,
					b.IsOrgChart                     =	a.IsOrgChart,
					b.checkevent                     =	a.checkevent,
					b.bufferedrows                   =	a.bufferedrows,
					b.SparkChartType                 =	a.SparkChartType,
					b.ChartType                      =	a.ChartType,
					b.Delayedpwdmask                 =	a.Delayedpwdmask,
					b.preserve_gridposition          =	a.preserve_gridposition,
					b.Dynamicfileupload              =	a.Dynamicfileupload,
					b.ServerSidePrint                =	a.ServerSidePrint,
					b.MultiFileSelect                =	a.MultiFileSelect,
					b.NoofCtrlPerLine                =	a.NoofCtrlPerLine,
					b.FormWidth                      =	a.FormWidth,
					b.ControlWidth                   =	a.ControlWidth,
					b.LabelWidth                     =	a.LabelWidth,
					b.MetaDataBasedLink              =	a.MetaDataBasedLink,
					b.LabelAlignment                 =	a.LabelAlignment,
					b.Scan                           =	a.Scan,
					b.Autoselect                     =	a.Autoselect,
					b.IsList                         =	a.IsList,
					b.MultiSelect                    =	a.MultiSelect,
					b.SelectedRowcount               =	a.SelectedRowcount,
					b.DockedItem                     =	a.DockedItem,
					b.NFCEnabled                     =	a.NFCEnabled,
					b.AutoScan                       =	a.AutoScan,
					b.IsToggle                       =	a.IsToggle,
					b.NodeIconReqd                   =	a.NodeIconReqd,
					b.NodeCustomClass                =	a.NodeCustomClass,
					b.IsDocked                       =	a.IsDocked,
					b.RuleBuilder                    =	a.RuleBuilder,
					b.MultiSelectComboforRB          =	a.MultiSelectComboforRB,
					b.CalendarControl                =	a.CalendarControl,
					b.Setfocusevent                  =	a.Setfocusevent,
					b.Leavefocusevent                =	a.Leavefocusevent,
					b.GanttControl                   =	a.GanttControl,
					b.AutoSync                       =	a.AutoSync,
					b.SetFocusEventOccurence         =	a.SetFocusEventOccurence,
					b.LeaveFocusEventOccurence       =	a.LeaveFocusEventOccurence,
					b.IsChips                        =	a.IsChips,
					b.IsSpellcheck                   =	a.IsSpellcheck,
					b.DirectPrint                    =	a.DirectPrint,
					b.ListItemExpander               =	a.ListItemExpander,
					b.ReadOnly                       =	a.ReadOnly,
					b.ShowTodayLine                  =	a.ShowTodayLine,
					b.ShowRollupTasks                =	a.ShowRollupTasks,
					b.ShowProjectLines               =	a.ShowProjectLines,
					b.SkipWeekendsDuringDragDrop     =	a.SkipWeekendsDuringDragDrop,
					b.LockedGridWidth                =	a.LockedGridWidth,
					b.RowHeight                      =	a.RowHeight,
					b.BottomLabelField               =	a.BottomLabelField,
					b.TopLabelField                  =	a.TopLabelField,
					b.LeftLabelField                 =	a.LeftLabelField,
					b.RightLabelField                =	a.RightLabelField,
					b.RollupLabelField               =	a.RollupLabelField,
					b.Baseline                       =	a.Baseline,
					b.ScrollToDateCentered           =	a.ScrollToDateCentered,
					b.Zoom                           =	a.Zoom,
					b.Fit                            =	a.Fit,
					b.Export                         =	a.Export,
					b.Highlight                      =	a.Highlight,
					b.Indent                         =	a.Indent,
					b.ContextMenu                    =	a.ContextMenu,
					b.PopupTaskEditor                =	a.PopupTaskEditor,
					b.GanttShift                     =	a.GanttShift,
					b.GanttExpand                    =	a.GanttExpand,
					b.GanttInsert                    =	a.GanttInsert,
					b.GanttDelete                    =	a.GanttDelete,
					b.Calendar                       =	a.Calendar,
					b.IsScheduler                    =	a.IsScheduler,
					b.ListItemType                   =	a.ListItemType,
					b.IsSelectionReqdList            =	a.IsSelectionReqdList,
					b.RowAlwaysExpanded              =	a.RowAlwaysExpanded,
					b.IsMobile                       =	a.IsMobile,
					b.PaginationReqd                 =	a.PaginationReqd,
					b.UpdateTaskReqd                 =	a.UpdateTaskReqd,
					b.DeleteTaskReqd                 =	a.DeleteTaskReqd,
					b.ShowLines						 =	a.ShowLines,	--TECH-68066
					b.PreTask						 =	a.PreTask,		--TECH-68066
					b.PostTask						 =	a.PostTask,		--TECH-68066
					--Code added for TECH-69624 starts
					b.HideRuleHeader				 =	a.HideRuleHeader,
					b.HideANDOperator				 =	a.HideANDOperator,
					b.HideOROperator				 =	a.HideOROperator,
					b.HideNOTOperator				 =	a.HideNOTOperator,
					b.HideGroupOperator				 =	a.HideGroupOperator,
					b.HideRuleOperator				 =	a.HideRuleOperator ,
					b.SelectOnlyListValues			 =	a.SelectOnlyListValues,					
					--Code added for TECH-69624 ends
					--Code added for TECH-71262 on 14July22 starts
					b.BrowsePreTask					 =	a.BrowsePreTask,
					b.BrowsePostTask				 =	a.BrowsePostTask,
					b.DeletePreTask					 =	a.DeletePreTask,
					b.DeletePostTask				 =	a.DeletePostTask,
					b.ButtonStyle					 =	a.ButtonStyle,
					--Code added for TECH-71262 on 14July22 ends
					b.BadgeText						=	a.BadgeText,	--code added for TECH-72114
					b.AutoHeight					=	a.AutoHeight,	--code added for TECH-72114
					--code added for TECH-73996 starts			
					b.EyeIconForPassword		 =	  a.EyeIconForPassword,		
					b.Signature					 =	  a.Signature,					
					b.KeyupSearch				 =	  a.KeyupSearch,				
					b.Stepper					 =	  a.Stepper,					
					b.LiveClock					 =	  a.LiveClock,					
					b.ClearTask					 =	  a.ClearTask,					
					b.ShowAnimation				 =	  a.ShowAnimation,				
					b.PreventMultipleRowSelection=	  a.PreventMultipleRowSelection,	
					b.PreviousCount				 =	  a.PreviousCount				
					--code added for TECH-73996 ends	
			FROM	ep_published_comp_ctrl_type_mst_extn a,
					re_comp_ctrl_type_mst_extn b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.ctrl_type_name	=	a.ctrl_type_name 
			
			AND		a.Customer_Name		=	@engg_customer_name
			AND		a.Project_Name		=	@engg_project_name
			AND		a.Process_Name		=	@proc_name
			AND		a.Component_Name	=	@comp_name
			AND		a.req_no			=	@rcr_no	

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.task_type_descr	             =	a.task_type_descr,	                     
					b.default_for                    =	a.default_for,                        
					b.refresh_on_save			     =	a.refresh_on_save,			             
					b.valid_on_init				     =	a.valid_on_init,				     
					b.err_handle_method	             =	a.err_handle_method,             
					b.incl_place_holder              =	a.incl_place_holder,                  
					b.cond_ml_fetch				     =	a.cond_ml_fetch,				     
					b.clr_on_page_save			     =	a.clr_on_page_save,			     
					b.hdr_fetch_req		             =	a.hdr_fetch_req,		             
					b.ml_fet_req                     =	a.ml_fet_req,                         
					b.hdr_ref_req				     =	a.hdr_ref_req,				             
					b.hdr_check_req				     =	a.hdr_check_req,				     
					b.proc_sel_rows		             =	a.proc_sel_rows,		             
					b.usr_role_map                   =	a.usr_role_map,                       
					b.trn_scope_req				     =	a.trn_scope_req,				     
					b.comp_task_type_sysid		     =	a.comp_task_type_sysid,		     
					b.task_type_doc		             =	a.task_type_doc,		             
					b.hdr_save_req                   =	a.hdr_save_req,                       
					b.ml_save_req				     =	a.ml_save_req,				             
					b.fprowno_req				     =	a.fprowno_req,				             
					b.cbdef_req			             =	a.cbdef_req,			             
					b.no_placeholder                 =	a.no_placeholder,                     
					b.data_save_req				     =	a.data_save_req,				     
					b.print_req					     =	a.print_req,					     
					b.task_confirmation	             =	a.task_confirmation,	             
					b.Logic_Extensions               =	a.Logic_Extensions,                   
					b.process_updrows			     =	a.process_updrows,			             
					b.alternate_db				     =	a.alternate_db,				     
					b.sys_proc_sel_rows	             =	a.sys_proc_sel_rows,             
					b.sys_process_updrows            =	a.sys_process_updrows,                
					b.Linkasui					     =	a.Linkasui,					     
					b.Uiastrans					     =	a.Uiastrans,					     
					b.MLSaveSinglesegment            =	a.MLSaveSinglesegment,              
					b.sys_proc_selupd_rows           =	a.sys_proc_selupd_rows,
					b.CurrentContextInformation	     =	a.CurrentContextInformation,	
					b.ParentContextInformation	     =	a.ParentContextInformation,	
					b.ModeflagEnabled	             =	a.ModeflagEnabled,	
					b.BulkValidation                 =	a.BulkValidation,
					b.BubbleMessage					 =	a.BubbleMessage	--TECH-75230
			FROM	ep_published_comp_task_type_mst a,
					re_comp_task_type_mst b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.task_type_name	=	a.task_type_name 
			
			AND		a.Customer_Name		=	@engg_customer_name
			AND		a.Project_Name		=	@engg_project_name
			AND		a.Process_Name		=	@proc_name
			AND		a.Component_Name	=	@comp_name
			AND		a.req_no			=	@rcr_no	

		INSERT INTO re_comp_ctrl_type_mst
			(	customer_name,				project_name,				rcnno,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					createddate,				modifiedby,				modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@engg_ecr_no,			process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				@ctxt_user,					GETDATE(),					@ctxt_user,				GETDATE()
		FROM	ep_published_comp_ctrl_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@engg_customer_name
		AND		Project_Name		=	@engg_project_name
		AND		Process_Name		=	@proc_name
		AND		Component_Name		=	@comp_name
		AND		req_no				=	@rcr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	re_comp_ctrl_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.ctrl_type_name	=	a.ctrl_type_name  )

		INSERT INTO re_comp_ctrl_type_mst_extn
			(	customer_name,				project_name,				rcnno,				process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
				Configuration,				SliderType,					SliderBehaviour,	RenderType,
				Orientation,				Startvalue,					Endvalue,			Minvalue,
				Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
				ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
				RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
				CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
				ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
				NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
				checkevent,					bufferedrows,				SparkChartType,		ChartType,
				Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
				MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
				LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
				Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
				DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
				NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
				MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
				GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
				IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
				ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
				SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
				TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
				Baseline,					ScrollToDateCentered,		Zoom,				Fit,
				Export,						Highlight,					Indent,				ContextMenu,
				PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
				GanttDelete,				Calendar,					IsScheduler,		ListItemType,
				IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
				UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
				createdby,					createddate,				modifiedby,			modifieddate,
				ShowLines,					PreTask,					PostTask,			BulkDownload,--TECH-68066
				HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
				HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues,	--Code added for TECH-69624 
				BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
				ButtonStyle,				BadgeText,					AutoHeight,	--Code added for TECH-71262 on 14July22 ends	--code added for TECH-72114
				--code added for defect id Tech-73996 starts
				EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
				LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
				PreviousCount)	
				--code added for defect id Tech-73996 ends
		SELECT DISTINCT
				customer_name,				project_name,				@engg_ecr_no,		process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
				Configuration,				SliderType,					SliderBehaviour,	RenderType,
				Orientation,				Startvalue,					Endvalue,			Minvalue,
				Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
				ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
				RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
				CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
				ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
				NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
				checkevent,					bufferedrows,				SparkChartType,		ChartType,
				Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
				MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
				LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
				Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
				DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
				NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
				MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
				GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
				IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
				ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
				SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
				TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
				Baseline,					ScrollToDateCentered,		Zoom,				Fit,
				Export,						Highlight,					Indent,				ContextMenu,
				PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
				GanttDelete,				Calendar,					IsScheduler,		ListItemType,
				IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
				UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE(),
				ShowLines,					PreTask,					PostTask,			BulkDownload,---TECH-68066
				HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
				HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues,--Code added for TECH-69624 
				BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
				ButtonStyle,				BadgeText,					AutoHeight, --Code added for TECH-71262 on 14July22 ends --code added for TECH-72114
				--code added for defect id Tech-73996 starts
				EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
				LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
				PreviousCount	
				--code added for defect id Tech-73996 ends
		FROM	ep_published_comp_ctrl_type_mst_extn a (NOLOCK)
		WHERE	Customer_Name		=	@engg_customer_name
		AND		Project_Name		=	@engg_project_name
		AND		Process_Name		=	@proc_name
		AND		Component_Name		=	@comp_name
		AND		req_no				=	@rcr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	re_comp_ctrl_type_mst_extn b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.ctrl_type_name	=	a.ctrl_type_name )

		INSERT INTO re_comp_task_type_mst
			(	customer_name,				project_name,				rcnno,				process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				createdby,					createddate,				modifiedby,			modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@engg_ecr_no,		process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE()
		FROM	ep_published_comp_task_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@engg_customer_name
		AND		Project_Name		=	@engg_project_name
		AND		Process_Name		=	@proc_name
		AND		Component_Name		=	@comp_name
		AND		req_no				=	@rcr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	re_comp_task_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.task_type_name	=	a.task_type_name  )


		--case ID TECH-66583 Ends

			-- code modified by shafina on 29-Oct-2004 for DEENG203ACC_000113(Length and Datatype must not get updated)
			--   insert into re_download_log
			--   (timestamp,createdby,createddate,modifiedby,modifieddate,customer_name,project_name,
			--   doc_no,process_name,component_name,activity_name,ui_name,seq_no,table_name,
			--   l1,l2,l3,l4,log_type,logged_by,logged_date)
			--   select 1,@ctxt_user,@getdate,'','',@engg_customer_name,@engg_project_name,
			--   @rcr_no,@proc_name,@comp_name,'','',1,'re_glossary',
			--   COALESCE(a.bt_synonym_name , b.bt_synonym_name ),null,null,null,
			--   case isnull(a.bt_synonym_name,'')
			--   when '' then 'D'
			--   else ( case isnull(b.bt_synonym_name,'') when '' then 'I' else 'U' end )
			--   end,@ctxt_user,@getdate
			--   from  ep_published_comp_glossary_mst a (nolock) full join  re_glossary b (nolock)
			--   on  a.customer_name  =  b.customer_name
			--   and  a.project_name  = b.project_name
			--   and  a.bt_synonym_name =  b.bt_synonym_name
			--   and     a.component_name   = b.component_name
			--   and     a.process_name      =  b.process_name
			--   where  isnull(a.customer_name,b.customer_name)  = @engg_customer_name
			--   and  isnull(a.project_name,b.project_name)  = @engg_project_name
			--   and  isnull(a.process_name,b.process_name)  = @proc_name
			--   and  isnull(a.component_name,b.component_name) = @comp_name
			--   and  isnull(a.req_no,@rcr_no)     = @rcr_no
			-- code modified by shafina on 17-June-2004 for PREVIEWENG203ACC_000073
			-- code commented by DNR for on 18-June-2004 for the bug id DEENG203SYS_000208
			UPDATE b
			SET b.bt_synonym_caption = a.bt_synonym_caption,
				b.modifiedby = a.modifiedby,
				b.modifieddate = a.modifieddate,
				b.ref_bt_synonym_name = a.ref_bt_synonym_name,
				b.bt_synonym_doc = a.bt_synonym_doc,
				b.synonym_status = a.synonym_status,
				b.singleinst_sample_data = a.singleinst_sample_data,
				b.multiinst_sample_data = a.multiinst_sample_data,
				b.IsGlance = a.IsGlance
			--     b.data_type   = a.data_type,   /* PNR2.0_8084 */ --PNR2.0_13677
			--     b.length   = a.length,
			--     b.bt_name   = a.bt_name /* PNR2.0_10880 */
			FROM ep_published_comp_glossary_mst A,
				re_glossary B
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.bt_synonym_name = b.bt_synonym_name
				AND a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.req_no = @rcr_no
				AND a.process_name = @proc_name
				AND a.component_name = @comp_name

			-- code added by shafina on 04-nov-2004 for ECENG203ACC_000086 (While downloading RCN , glossary_lang_extn table must also be populated.)
			--Code Commented for bugId : PNR2.0_13973
			-- Code added by Shriram V on 22/08.2005 for Bug Id :PNR2.0_3616
			--   if exists( select 'x' from
			--     ep_published_comp_glossary_mst_lng_extn A (nolock)
			--     where A.customer_name  = @engg_customer_name
			--     and A.Project_name  = @engg_project_name
			--     and A.req_no  = @rcr_no
			--     and A.process_name  = @proc_name
			--     and A.component_name = @comp_name
			--     and  len(a.bt_synonym_caption) > 60
			--    )
			--   begin
			--     exec engg_error_sp 're_ecr_sp_dnldecr',1,'BT Synonym Caption(S) Length Cannot Exceed 60 Characters',
			--       @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
			--       '','','','',@m_errorid output
			--     if @m_errorid > 0
			--     begin
			--      close main_ui_cur
			--      deallocate main_ui_cur
			--      return
			--                end
			--   end
			-- End of Code Addition by  Shriram V on 22/08.2005 for Bug Id :PNR2.0_3616
			--INSERT INTO re_glossary_lng_extn (
			--	customer_name,
			--	project_name,
			--	bt_synonym_name,
			--	process_name,
			--	component_name,
			--	data_type,
			--	length,
			--	bt_synonym_caption,
			--	glossary_sysid,
			--	TIMESTAMP,
			--	createdby,
			--	createddate,
			--	ref_bt_synonym_name,
			--	bt_synonym_doc,
			--	bt_name,
			--	synonym_status,
			--	singleinst_sample_data,
			--	multiinst_sample_data,
			--	languageid,
			--	rcnno
			--	)
			--SELECT customer_name,
			--	project_name,
			--	bt_synonym_name,
			--	process_name,
			--	component_name,
			--	data_type,
			--	length,
			--	bt_synonym_caption,
			--	newid(),
			--	TIMESTAMP,
			--	createdby,
			--	createddate,
			--	ref_bt_synonym_name,
			--	bt_synonym_doc,
			--	bt_name,
			--	synonym_status,
			--	singleinst_sample_data,
			--	multiinst_sample_data,
			--	languageid,
			--	@engg_ecr_no
			--FROM ep_published_comp_glossary_mst_lng_extn A(NOLOCK)
			--WHERE A.customer_name = @engg_customer_name
			--	AND A.Project_name = @engg_project_name
			--	AND A.req_no = @rcr_no
			--	AND A.process_name = @proc_name
			--	AND A.component_name = @comp_name
			--	AND A.bt_synonym_name NOT IN (
			--		SELECT B.bt_synonym_name
			--		FROM re_glossary_lng_extn B(NOLOCK)
			--		WHERE A.customer_name = B.customer_name
			--			AND A.Project_name = B.Project_name
			--			AND A.process_name = B.process_name
			--			AND A.component_name = B.component_name
			--			AND A.languageid = B.languageid
			--		)

			UPDATE b
			SET b.bt_synonym_caption = a.bt_synonym_caption,
				b.modifiedby = a.modifiedby,
				b.modifieddate = a.modifieddate,
				b.ref_bt_synonym_name = a.ref_bt_synonym_name,
				b.bt_synonym_doc = a.bt_synonym_doc,
				b.synonym_status = a.synonym_status,
				b.singleinst_sample_data = a.singleinst_sample_data,
				b.multiinst_sample_data = a.multiinst_sample_data
			--     b.data_type   = a.data_type,  /* PNR2.0_8084 */--PNR2.0_13677
			--     b.length   = a.length,
			--     b.bt_name   = a.bt_name /* PNR2.0_10880 */
			FROM ep_published_comp_glossary_mst_lng_extn A,
				re_glossary_lng_extn B
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.bt_synonym_name = b.bt_synonym_name
				AND a.languageid = b.languageid
				AND a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.req_no = @rcr_no
				AND a.process_name = @proc_name
				AND a.component_name = @comp_name

			IF @m_errorid > 0
			BEGIN
				CLOSE mainui_cur

				DEALLOCATE mainui_cur

				RETURN
			END
		END

		-- code added by shafina on 22-April-2004 for ECENG203ACC_000009
		CLOSE mainui_cur

		DEALLOCATE mainui_cur
	END
	ELSE
	BEGIN
		DECLARE main_ui_cur CURSOR
		FOR
		SELECT process_name,
			component_name,
			activity_name,
			ui_name,
			rcr_no,
			process_descr,
			component_descr,
			activity_descr,
			ui_descr,
			ecr_descr
		FROM re_rmt_ecr_ui_vw(NOLOCK)
		WHERE customer_name = (@engg_customer_name)
			AND project_name = (@engg_project_name)
			AND ecr_no = (@engg_ecr_no)

		OPEN main_ui_cur

		WHILE 1 = 1
		BEGIN --1
			FETCH NEXT
			FROM main_ui_cur
			INTO @proc_name,
				@comp_name,
				@act_name,
				@ui_name,
				@rcr_no,
				@proc_descr,
				@comp_descr,
				@act_descr,
				@ui_descr,
				@ecr_descr_tmp

			IF @@fetch_status <> 0
			BEGIN --2
				BREAK
			END --2

			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND ecr_no = (@engg_ecr_no)
						AND rcr_no = (@rcr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND ui_status = 'C'
					)
			BEGIN --3
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					1,
					'Selected RCN is already downloaded...',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
				BEGIN
					CLOSE main_ui_cur

					DEALLOCATE main_ui_cur

					RETURN
				END
			END --3

			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND ecr_no = (@engg_ecr_no)
						AND rcr_no = (@rcr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND ui_status = 'P'
					)
			BEGIN --3
				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					3,
					'RCN at rowno:<%1>  is Published.',
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
				BEGIN
					CLOSE main_ui_cur

					DEALLOCATE main_ui_cur

					RETURN
				END
			END --3

			IF EXISTS (
					SELECT 'x'
					FROM re_ui_ecr(NOLOCK)
					WHERE customer_name = (@engg_customer_name)
						AND project_name = (@engg_project_name)
						AND ecr_no <> (@engg_ecr_no)
						AND process_name = (@proc_name)
						AND component_name = (@comp_name)
						AND activity_name = (@act_name)
						AND ui_name = (@ui_name)
						AND (ui_status) = 'C'
					)
			BEGIN --4
				--code added by Sangeetha L on 20-Jan-2006 for the BUG ID:PNR2.0_5621
				SELECT @engg_ecr_no_temp = ecr_no
				FROM re_ui_ecr(NOLOCK)
				WHERE customer_name = (@engg_customer_name)
					AND project_name = (@engg_project_name)
					AND ecr_no <> (@engg_ecr_no)
					AND process_name = (@proc_name)
					AND component_name = (@comp_name)
					AND activity_name = (@act_name)
					AND ui_name = (@ui_name)
					AND (ui_status) = 'C'

				SELECT @msg = 'The Component- ' + @comp_name + ' already exists in the RCN "' + @engg_ecr_no_temp + '".Publish the RCN "' + @engg_ecr_no_temp + '"  before downloading the RCN ' + '"' + @engg_ecr_no + '"'

				EXEC engg_error_sp 're_ecr_sp_dnldecr',
					2,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid > 0
				BEGIN
					CLOSE main_ui_cur

					DEALLOCATE main_ui_cur

					RETURN
				END
			END

			DECLARE dir_rcn_cur INSENSITIVE CURSOR
			FOR
			SELECT ecr_no
			FROM re_ui_ecr(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
				AND ecr_no <> (@engg_ecr_no)
				--Added and Modified by Shriram V on 28/03/05 for Bug Id :PNR2.0_1624
				AND short_close <> 'Yes'

			OPEN dir_rcn_cur

			WHILE (1 = 1)
			BEGIN
				FETCH NEXT
				FROM dir_rcn_cur
				INTO @rcn_no_tmp

				IF @@fetch_status <> 0
					BREAK

				IF isnull(@rcn_no_tmp, '') <> ''
				BEGIN
					IF NOT EXISTS (
							SELECT 'x'
							FROM de_rmt_rcn_ecr_vw(NOLOCK)
							WHERE customer_name = (@engg_customer_name)
								AND project_name = (@engg_project_name)
								AND ecr_no = (@rcn_no_tmp)
							)
					BEGIN
						--Added by Shriram V on 25/03/05 for bug Id : PNR2.0_1594
						--Commented by Shriram V on 28/03/05 for Bug ID :1624
						/*if exists(select 'x'
from fw_rmt_rcn_vw(nolock)
where  customerid  =(@engg_customer_name)
and  projectid  =(@engg_project_name)
and  rcnnumber  =(@rcn_no_tmp))
begin */
						--End if Addition by Shriram V on 25/03/05 for Bug ID : PNR2.0_1594
						--Commented by Shriram V on 28/03/05 for Bug ID :1624
						EXEC engg_error_sp 're_ecr_sp_dnldecr',
							2,
							'Previous RCN is not mapped to an ECR.',
							@ctxt_language,
							@ctxt_ouinstance,
							@ctxt_service,
							@ctxt_user,
							'',
							'',
							'',
							'',
							@m_errorid OUTPUT

						IF @m_errorid > 0
						BEGIN
							CLOSE dir_rcn_cur

							DEALLOCATE dir_rcn_cur

							CLOSE main_ui_cur

							DEALLOCATE main_ui_cur

							RETURN
						END
								--end
								--PNR2.0_1624
					END
				END
			END

			CLOSE dir_rcn_cur

			DEALLOCATE dir_rcn_cur

			-- code added by DNR on 2/1/2004 for populating re_ui_ecr table
			/*   if exists (select 'x' from re_ui_ecr(nolock)
where customer_name  = (@engg_customer_name)
and  project_name  = (@engg_project_name)
and  ecr_no    = (@engg_ecr_no)
and  rcr_no    = (@rcr_no)
and  process_name  = (@proc_name)
and  component_name  = (@comp_name)
and  activity_name  = (@act_name)
and  ui_name    = (@ui_name)
)
begin
update  re_ui_ecr
set  ui_status  = 'C',
modifiedby  =  @ctxt_user,
modifieddate =  @getdate
where customer_name = (@engg_customer_name)
and  project_name = (@engg_project_name)
and  ecr_no   = (@engg_ecr_no)
and  rcr_no   = (@rcr_no)
and  process_name = (@proc_name)
and  component_name = (@comp_name)
and  activity_name = (@act_name)
and  ui_name   = (@ui_name)

end
else
begin*/
			-- Code commented by Gowrisankar M for PNR2.0_16537 on 22-Jan-2008
			/* CODE ADDED BY YUVARAJ FOR POPULATING RE DOWNLOAD TABLES STARTS HERE */
			--   insert into re_dwd_ui_ecr (
			--   customer_name,project_name,ecr_no,rcr_no,process_name,component_name,activity_name,ui_name,
			--   ui_status,ecr_descr,process_descr,component_descr,activity_descr,ui_descr,ecr_sysid,
			--   timestamp,createdby,createddate,modifiedby,modifieddate
			--   )
			--   Select customer_name,project_name,ecr_no,rcr_no,process_name,component_name,activity_name,ui_name,
			--   ui_status,ecr_descr,process_descr,component_descr,activity_descr,ui_descr,ecr_sysid,
			--   1, @ctxt_user, @getdate , @ctxt_user, @getdate
			--   from re_ui_ecr (nolock)
			--   where customer_name  = (@engg_customer_name)
			--   and  project_name  = (@engg_project_name)
			--   and  ecr_no    = (@engg_ecr_no)
			--   and  process_name  = (@proc_name)
			--   and  component_name  = (@comp_name)
			--   and  activity_name  = (@act_name)
			--   and  ui_name    = (@ui_name)
			/* CODE ADDED BY YUVARAJ FOR POPULATING RE DOWNLOAD TABLES ENDS HERE */
			-- Code commented by Gowrisankar M for PNR2.0_16537 on 22-Jan-2008
			DELETE
			FROM re_ui_ecr
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND ecr_no = (@engg_ecr_no)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)

			INSERT INTO re_ui_ecr (
				customer_name,
				project_name,
				ecr_no,
				rcr_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				ui_status,
				ecr_descr,
				process_descr,
				component_descr,
				activity_descr,
				ui_descr,
				ecr_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			VALUES (
				@engg_customer_name,
				@engg_project_name,
				@engg_ecr_no,
				@rcr_no,
				@proc_name,
				@comp_name,
				@act_name,
				@ui_name,
				'C',
				@ecr_descr_tmp,
				@proc_descr,
				@comp_descr,
				@act_descr,
				@ui_descr,
				newid(),
				1,
				@ctxt_user,
				@getdate,
				'',
				''
				)

			--   end
			UPDATE re_ui
			SET current_req_no = (@engg_ecr_no),
				modifiedby = @ctxt_user,
				modifieddate = @getdate
			FROM re_ui(NOLOCK)
			WHERE customer_name = (@engg_customer_name)
				AND project_name = (@engg_project_name)
				AND process_name = (@proc_name)
				AND component_name = (@comp_name)
				AND activity_name = (@act_name)
				AND ui_name = (@ui_name)
		END

		CLOSE main_ui_cur

		DEALLOCATE main_ui_cur
	END

	IF @engg_ecr_status NOT IN ('dwldezeeview') --Code added for PNR2.0_28333
		SELECT @fprowno 'fprowno_io' /* DOTNET Migration Tool Changes */

	/*Code added by Gankan.G for CaseID: PNR2.0_32794  starts*/
	SELECT DISTINCT @proc_name = process_name,
		@comp_name = component_name
	FROM re_rmt_ecr_ui_vw(NOLOCK)
	WHERE customer_name = (@engg_customer_name)
		AND project_name = (@engg_project_name)
		AND ecr_no = (@engg_ecr_no)

	UPDATE a
	SET a.task_descr = b.task_descr,
		a.task_confirm_msg = b.task_confirm_msg,
		a.task_status_msg = b.task_status_msg,
		a.Autoupload = b.Autoupload,
		a.sectionlaunchtype = b.sectionlaunchtype, -- added for SectionLaunch Type TECH-12776 \
		a.QuickTask = b.QuickTask, -- Added for the Defect ID TECH-29822
		a.SystemTaskType = b.SystemTaskType
	FROM re_action a(NOLOCK),
		ep_action_mst b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @proc_name
		AND a.component_name = @comp_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name

	UPDATE a
	SET a.task_descr = b.task_descr,
		a.task_confirm_msg = b.task_confirm_msg,
		a.task_status_msg = b.task_status_msg
	FROM re_action_lng_extn a(NOLOCK),
		ep_action_mst_lng_extn b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @proc_name
		AND a.component_name = @comp_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.languageid = b.languageid

	-- NGPLF Changes Starts
	DECLARE @tmp_rcn engg_name,
		@tmp_pwrq engg_name,
		@tmp_prc engg_name,
		@tmp_cmp engg_name,
		@tmp_act engg_name,
		@tmp_ui engg_name,
		@ctxt_role engg_name

	DECLARE getrcn INSENSITIVE CURSOR
	FOR
	SELECT DISTINCT ecr_no,
		rcr_no,
		process_name,
		component_name,
		activity_name,
		ui_name
	FROM re_ui_ecr(NOLOCK)
	WHERE ecr_no = @engg_ecr_no

	OPEN getrcn

	FETCH NEXT
	FROM getrcn
	INTO @tmp_rcn,
		@tmp_pwrq,
		@tmp_prc,
		@tmp_cmp,
		@tmp_act,
		@tmp_ui

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC ngplf_rcn_download @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_user,
			@ctxt_role,
			@engg_customer_name,
			@engg_project_name,
			@tmp_prc,
			@tmp_cmp,
			@tmp_rcn,
			@tmp_pwrq,
			@tmp_act,
			@tmp_ui

		FETCH NEXT
		FROM getrcn
		INTO @tmp_rcn,
			@tmp_pwrq,
			@tmp_prc,
			@tmp_cmp,
			@tmp_act,
			@tmp_ui
	END

	CLOSE getrcn

	DEALLOCATE getrcn

	-- NGPLF Changes Ends
	/*Code added by Gankan.G for CaseID: PNR2.0_32794  ends*/
	IF EXISTS (
			SELECT 'x' -- code added by 11536 for the case id TECH-20631
			FROM re_ui_ecr(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND ecr_no = rtrim(@engg_ecr_no)
				AND ui_status = 'c'
			)
	BEGIN
		UPDATE FW_NIA_GenDoc_Rcn_Ecr_ICO_temp
		SET doc_status = 'RCNDW'
		WHERE Customerid = @engg_customer_name
			AND Projectid = @engg_project_name
			AND RCNNumber = rtrim(@engg_ecr_no)
	END

	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 're_ecr_sp_dnldecr' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON re_ecr_sp_dnldecr TO PUBLIC
END
GO

