IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='re_published_insert' AND TYPE = 'P')
    Begin
        Drop PROC re_published_insert
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Sep 2019
Purpose 		re_published_insert.sql
********************************************************************************/
/* V E R S I O N      :            */
/* Released By        :             */
/* Release Comments   :            */
/********************************************************************************/
/* procedure    : re_published_insert                                           */
/* description  : Insert sp for Workflow tables                          */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : Sangeetha L                                                   */
/* date         : 01/ 09/ 2005                                                  */
/********************************************************************************/
/* modification history                                                         */
/**************************************************************************************/
/* modified by          : Sangeetha L For BugId :PNR2.0_8466                     */
/* date                 : 15/05/2006                                            */
/* description          : On download of ECR, Workflow Controls to be added for the UI for which workflow inputs have been given.           */
/**************************************************************************************/
/* modified by          : Gowrisankar                              */
/* date                 : 13-Nov-2006                                                */
/* description          : PNR2.0_10942              */
/**************************************************************************************/
/* modified by          : Kirthika                              */
/* date                 : 25-Sep-2008                                                */
/* description          : PNR2.0_19436             */
/**************************************************************************************/
/* modified by          : Praveen kumar.A                              */
/* date                 : 6-Oct-2008                                                */
/* description          : PNR2.0_19516          */
/**************************************************************************************/
/* modified by          : Praveen kumar.A                              */
/* date                 : 23-Oct-2008                                                */
/* description          : PNR2.0_19781          */
/**********************************************************************************************/
/* Modified By	: Venkatesan K																  */
/* Defect ID	: TECH-66583																  */
/* Modified on	: 24Feb2022																      */
/* Description	: RVW 2.0 Model publish table implementation for control and task property.   */
/**********************************************************************************************/
/* Modified By	: Ponmalar A/Priyadharshini U												  */
/* Defect ID	: TECH-68066																  */
/* Modified on	: 13-Apr-2022																  */
/* Description	: Post and Pre Tasks for Attachment controls.								  */
/**********************************************************************************************/
/* Modified by	:	Priyadharshini U 														  */
/* Modified on	:	08/06/22				 												  */
/* Defect ID	:	TECH-69624																  */
/* Description	:	Custom border, Custom actions and Responsive layout						  */
/**********************************************************************************************/
/* Modified by : Vimal Kumar R  															  */
/* Modified on : 27-July-2022																  */
/* Defect ID   : TECH-71262																	  */
/* Description : Platform Features for the Month of July'22									  */
/**********************************************************************************************/
/* Modified by : Priyadharshini U  															  */
/* Modified on : 23-Aug-2022																  */
/* Defect ID   : Tech-72114																	  */
/* Description : BadgeText Property for DataHyperLink Controls/Columns						  */
/**********************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R													  */
/* Modified on : 27-Oct-2022																  */
/* Defect ID   : TECH-73996																	  */
/* Description : Addition of attributes for control types in setup ui preferences screen	  */
/**********************************************************************************************/
/* Modified by : Priyadharshini U  															  */
/* Modified on : 01-Dec-2022																  */
/* Defect ID   : TECH-75230																	  */
/* Description : Platform Features for the Month of Nov'22									  */
/**********************************************************************************************/
CREATE PROCEDURE re_published_insert
	@customer_name engg_name,
	@project_name engg_name,
	@rcn_no engg_name
AS
SET NOCOUNT ON

BEGIN
	-- Not exists added for all table insertion for PNR2.0_10942 on 13-Nov-2006
	---re_published_wsinp_rcn_dtl
	INSERT INTO re_published_wsinp_rcn_dtl (
		customer_code,
		project_code,
		TIMESTAMP,
		rcn_no,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		TIMESTAMP,
		rcn_no,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_rcn_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_rcn_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_area_hdr
	INSERT INTO re_published_wsinp_area_hdr (
		customer_code,
		project_code,
		area_code,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_area_hdr a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_area_hdr b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_cat_hdr
	INSERT INTO re_published_wsinp_cat_hdr (
		customer_code,
		project_code,
		area_code,
		cat_key,
		TIMESTAMP,
		component_name,
		activity_name,
		task_name,
		user_configurable_task,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		TIMESTAMP,
		component_name,
		activity_name,
		task_name,
		user_configurable_task,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_cat_hdr a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				--and a.component_name = d.component_name -- code commented for bugid : PNR2.0_19781
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_cat_hdr b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.rcnno = @rcn_no
			)

	-- re_published_wsinp_appvw_dtl
	INSERT INTO re_published_wsinp_appvw_dtl (
		customer_code,
		project_code,
		area_code,
		notification_type,
		TIMESTAMP,
		appview_name,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		notification_type,
		TIMESTAMP,
		appview_name,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_appvw_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_appvw_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.notification_type = a.notification_type
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_area_desc
	INSERT INTO re_published_wsinp_area_desc (
		customer_code,
		project_code,
		area_code,
		language_code,
		TIMESTAMP,
		area_description,
		area_description_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		language_code,
		TIMESTAMP,
		area_description,
		area_description_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_area_desc a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_area_desc b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_area_dtl
	INSERT INTO re_published_wsinp_area_dtl (
		customer_code,
		project_code,
		area_code,
		component_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		component_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_area_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_area_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.component_name = a.component_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_cat_desc_hdr
	INSERT INTO re_published_wsinp_cat_desc_hdr (
		customer_code,
		project_code,
		area_code,
		cat_key,
		language_code,
		TIMESTAMP,
		task_description_mypage,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		language_code,
		TIMESTAMP,
		task_description_mypage,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_cat_desc_hdr a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)   -- Code modification for PNR2.0_19516  starts / commented for bugid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		-- code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key   -- Code modification for PNR2.0_19516  ends
		--)  -- code  added for bugid : PNR2.0_19436 ends / code commented for budid : PNR2.0_19781 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_cat_desc_hdr b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_def_wf_setup
	INSERT INTO re_published_wsinp_def_wf_setup (
		customer_code,
		project_code,
		area_code,
		TIMESTAMP,
		approval_con_on,
		approval_con_off,
		approval_not_req,
		notification_req,
		default_setup,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		TIMESTAMP,
		approval_con_on,
		approval_con_off,
		approval_not_req,
		notification_req,
		default_setup,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_def_wf_setup a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_def_wf_setup b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_cat_parameters
	INSERT INTO re_published_wsinp_cat_parameters (
		customer_code,
		project_code,
		area_code,
		parameter_name,
		TIMESTAMP,
		parameter_description,
		bt_name,
		data_type,
		data_length,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		parameter_name,
		TIMESTAMP,
		parameter_description,
		bt_name,
		data_type,
		data_length,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_cat_parameters a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)  code commented for budid : PNR2.0_19781 starts
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_cat_parameters b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.parameter_name = a.parameter_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_con_security
	INSERT INTO re_published_wsinp_con_security (
		consider_security,
		customer_code,
		project_code,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT consider_security,
		customer_code,
		project_code,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_con_security a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_con_security b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_task_dtl
	INSERT INTO re_published_wsinp_task_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		TIMESTAMP,
		container_page_ilbo_code,
		detail_page_ilbo_code,
		workflow_action,
		container_page_publish_id,
		detail_page_publish_id,
		initiated_task,
		sp_name,
		user_config,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		TIMESTAMP,
		container_page_ilbo_code,
		detail_page_ilbo_code,
		workflow_action,
		container_page_publish_id,
		detail_page_publish_id,
		initiated_task,
		sp_name,
		user_config,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_task_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)    -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		-- code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key   -- Code modification for PNR2.0_19516  ends
		--)  -- code  added for bugid : PNR2.0_19436 ends /code commented for budid : PNR2.0_19781 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_task_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_tsk_state_dtl
	INSERT INTO re_published_wsinp_tsk_state_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		TIMESTAMP,
		flow_direction,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		TIMESTAMP,
		flow_direction,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_tsk_state_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)   -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key)   -- Code modification for PNR2.0_19516  ends / code commented for budid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_tsk_state_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.state_name = a.state_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_def_msg_dtl
	INSERT INTO re_published_wsinp_def_msg_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		notification_type,
		language_code,
		TIMESTAMP,
		message_description,
		msg_subject,
		msg_body,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		notification_type,
		language_code,
		TIMESTAMP,
		message_description,
		msg_subject,
		msg_body,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_def_msg_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)  -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key                        -- Code modification for PNR2.0_19516  ends
		--)   -- code  added for bugid : PNR2.0_19436 ends / code commented for budid : PNR2.0_19781 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_def_msg_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.state_name = a.state_name
				AND b.notification_type = a.notification_type
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_doc_flow_dtl
	INSERT INTO re_published_wsinp_doc_flow_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		to_cat_key,
		TIMESTAMP,
		execution_type,
		default_path,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		to_cat_key,
		TIMESTAMP,
		execution_type,
		default_path,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_doc_flow_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)   -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key                -- Code modification for PNR2.0_19516  ends
		--)   -- code  added for bugid : PNR2.0_19436 ends / code commented for budid : PNR2.0_19781 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_doc_flow_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.to_cat_key = a.to_cat_key
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_docflow_msg_dtl
	INSERT INTO re_published_wsinp_docflow_msg_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		to_cat_key,
		notification_type,
		language_code,
		TIMESTAMP,
		message_description,
		msg_subject,
		msg_body,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		to_cat_key,
		notification_type,
		language_code,
		TIMESTAMP,
		message_description,
		msg_subject,
		msg_body,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_docflow_msg_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)         -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key
		--)             -- Code modification for PNR2.0_19516  ends / code commented for budid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_docflow_msg_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.to_cat_key = a.to_cat_key
				AND b.notification_type = a.notification_type
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_compcode
	INSERT INTO re_published_wsinp_nonrvw_compcode (
		customer_code,
		project_code,
		component_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_compcode a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_compcode b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_compdesc
	INSERT INTO re_published_wsinp_nonrvw_compdesc (
		customer_code,
		project_code,
		component_name,
		language_code,
		TIMESTAMP,
		component_desc,
		component_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		language_code,
		TIMESTAMP,
		component_desc,
		component_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_compdesc a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_compdesc b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_actcode
	INSERT INTO re_published_wsinp_nonrvw_actcode (
		customer_code,
		project_code,
		component_name,
		activity_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		activity_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_actcode a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_actcode b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_actdesc
	INSERT INTO re_published_wsinp_nonrvw_actdesc (
		customer_code,
		project_code,
		component_name,
		activity_name,
		language_code,
		TIMESTAMP,
		activity_desc,
		activity_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		activity_name,
		language_code,
		TIMESTAMP,
		activity_desc,
		activity_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_actdesc a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_actdesc b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_taskcode
	INSERT INTO re_published_wsinp_nonrvw_taskcode (
		customer_code,
		project_code,
		component_name,
		activity_name,
		task_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		activity_name,
		task_name,
		TIMESTAMP,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_taskcode a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_taskcode b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.task_name = a.task_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_nonrvw_taskdesc
	INSERT INTO re_published_wsinp_nonrvw_taskdesc (
		customer_code,
		project_code,
		component_name,
		activity_name,
		task_name,
		language_code,
		TIMESTAMP,
		task_desc,
		task_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		component_name,
		activity_name,
		task_name,
		language_code,
		TIMESTAMP,
		task_desc,
		task_desc_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_nonrvw_taskdesc a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_nonrvw_taskdesc b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.task_name = a.task_name
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	--  insert into re_published_wsinp_qc_dtl
	--  (wf_quick_code, wf_quick_code_type, timestamp, wf_quick_code_flag, createddate, modifieddate, createdby, modifiedby, rcnno)
	--  select wf_quick_code, wf_quick_code_type, timestamp, wf_quick_code_flag, createddate, modifieddate, createdby, modifiedby, @rcn_no
	--  from re_wsinp_qc_dtl (nolock)
	--  where customer_code = @customer_name
	--  and project_code = @project_name
	--  insert into re_published_wsinp_qc_hdr
	--  (wf_quick_code_type, timestamp, wf_type_description, createddate, modifieddate, createdby, modifiedby, rcnno)
	--  select wf_quick_code_type, timestamp, wf_type_description, createddate, modifieddate, createdby, modifiedby, @rcn_no
	--  from re_wsinp_qc_hdr (nolock)
	--  where customer_code = @customer_name
	--  and project_code = @project_name
	--
	--  insert into re_published_wsinp_qc_lang_dtl
	--  (wf_quick_code_type, wf_quick_code, language_code, timestamp, wf_code_description, createddate, modifieddate, createdby, modifiedby, rcnno)
	--  select wf_quick_code_type, wf_quick_code, language_code, timestamp, wf_code_description, createddate, modifieddate, createdby, modifiedby, @rcn_no
	--  from re_wsinp_qc_lang_dtl (nolock)
	--  where customer_code = @customer_name
	--  and project_code = @project_name
	--
	---re_published_wsinp_secusr_dtl
	INSERT INTO re_published_wsinp_secusr_dtl (
		customer_code,
		project_code,
		permitted_user,
		TIMESTAMP,
		enable_security,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		permitted_user,
		TIMESTAMP,
		enable_security,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_secusr_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_secusr_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.permitted_user = a.permitted_user
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_security_dtl
	INSERT INTO re_published_wsinp_security_dtl (
		customer_code,
		project_code,
		permitted_user,
		component_name,
		TIMESTAMP,
		active_flag,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		permitted_user,
		component_name,
		TIMESTAMP,
		active_flag,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_security_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK)
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND a.component_name = c.component_name
			) -- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_security_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.permitted_user = a.permitted_user
				AND b.component_name = a.component_name
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_service_dtl
	INSERT INTO re_published_wsinp_service_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		sequence_no,
		TIMESTAMP,
		service_name,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		sequence_no,
		TIMESTAMP,
		service_name,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_service_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)           -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key
		--)    -- Code modification for PNR2.0_19516  ends / code commented for budid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_service_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.sequence_no = a.sequence_no
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_state_desc_dtl
	INSERT INTO re_published_wsinp_state_desc_dtl (
		customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		language_code,
		TIMESTAMP,
		state_description,
		state_description_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		state_name,
		language_code,
		TIMESTAMP,
		state_description,
		state_description_u,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_state_desc_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)               -- Code modification for PNR2.0_19516  starts / code commented for budid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for budid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key
		--)    -- Code modification for PNR2.0_19516  ends / code commented for budid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_state_desc_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.state_name = a.state_name
				AND b.language_code = a.language_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_tsk_stflow_dtl
	INSERT INTO re_published_wsinp_tsk_stflow_dtl (
		cat_key,
		state_name,
		to_cat_key,
		to_state,
		area_code,
		customer_code,
		project_code,
		TIMESTAMP,
		active_flag,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT cat_key,
		state_name,
		to_cat_key,
		to_state,
		area_code,
		customer_code,
		project_code,
		TIMESTAMP,
		active_flag,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_tsk_stflow_dtl a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)            -- Code modification for PNR2.0_19516  starts / Code modification for PNR2.0_19516 / --code commented for bugid : PNR2.0_19781
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--code commented for bugid : PNR2.0_19781 starts
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key
		--)    -- Code modification for PNR2.0_19516  ends / code commented for bugid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_tsk_stflow_dtl b(NOLOCK)
			WHERE b.cat_key = a.cat_key
				AND b.state_name = a.state_name
				AND b.to_cat_key = a.to_cat_key
				AND b.to_state = a.to_state
				AND b.area_code = a.area_code
				AND b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.rcnno = @rcn_no
			)

	---re_published_wsinp_usr_noncon_task
	INSERT INTO re_published_wsinp_usr_noncon_task (
		customer_code,
		project_code,
		area_code,
		cat_key,
		calling_catkey,
		TIMESTAMP,
		workflow_action,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		rcnno
		)
	SELECT customer_code,
		project_code,
		area_code,
		cat_key,
		calling_catkey,
		TIMESTAMP,
		workflow_action,
		createddate,
		modifieddate,
		createdby,
		modifiedby,
		@rcn_no
	FROM re_wsinp_usr_noncon_task a(NOLOCK)
	WHERE customer_code = @customer_name
		AND project_code = @project_name
		AND EXISTS (
			SELECT 'x' -- code  added for bugid : PNR2.0_19436 starts
			FROM re_ui_ecr c(NOLOCK),
				re_wsinp_area_dtl d(NOLOCK)
			--re_wsinp_cat_hdr  e (nolock)             -- Code modification for PNR2.0_19516  starts/ --code commented for bugid : PNR2.0_19781 starts
			WHERE a.customer_code = c.customer_name
				AND a.project_code = c.project_name
				AND c.ecr_no = @rcn_no
				AND c.customer_name = d.customer_code
				AND c.project_name = d.project_code
				AND c.component_name = d.component_name
				AND a.area_code = d.area_code
			)
		--and    c.customer_name = e.customer_code
		--and    c.project_name  = e.project_code
		--and    c.component_name= e.component_name
		--
		--
		--and    a.customer_code =  e.customer_code
		--and    a.project_code =  e.project_code
		--and    a.area_code      =  e.area_code
		--and    a.cat_key =  e.cat_key)    -- Code modification for PNR2.0_19516  ends
		--code commented for bugid : PNR2.0_19781 ends
		-- code  added for bugid : PNR2.0_19436 ends
		AND NOT EXISTS (
			SELECT 'x'
			FROM re_published_wsinp_usr_noncon_task b(NOLOCK)
			WHERE b.customer_code = a.customer_code
				AND b.project_code = a.project_code
				AND b.area_code = a.area_code
				AND b.cat_key = a.cat_key
				AND b.calling_catkey = a.calling_catkey
				AND b.rcnno = @rcn_no
			)

	--Added by 11536 for the case ID TECH-66583 control Type and task type property History

	DECLARE		@ProcessName		ENGG_NAME,
				@ComponentName		ENGG_NAME

	SELECT		@ProcessName		=	Process_Name,
				@ComponentName		=	Component_Name
		FROM	re_ui_ecr (NOLOCK)
		WHERE	customer_name		=	@customer_name
		AND		project_name		=	@project_name
		AND		ecr_no				=	@rcn_no

	INSERT INTO re_published_comp_ctrl_type_mst
			(	customer_name,				project_name,				rcnno,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					createddate,				modifiedby,				modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@rcn_no,			process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					GETDATE(),					modifiedby,				GETDATE()
		FROM	re_comp_ctrl_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name
		AND		Project_Name		=	@project_name
		AND		Process_Name		=	@ProcessName
		AND		Component_Name		=	@ComponentName
		AND NOT EXISTS (	SELECT 'X'
								FROM	re_published_comp_ctrl_type_mst b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@customer_name
								AND		b.Project_Name		=	@project_name
								AND		b.Process_Name		=	@ProcessName
								AND		b.Component_Name	=	@ComponentName
								AND		b.rcnno				=	@rcn_no )

	INSERT INTO re_published_comp_ctrl_type_mst_extn
				(	customer_name,				project_name,				rcnno,				process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					createdby,					createddate,				modifiedby,			modifieddate,
					ShowLines,					PreTask,					PostTask,			BulkDownload,	--TECH-68066
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, --Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight,				--Code added for TECH-71262 on 14July22 --Code Added for the DefectId Tech-72114
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					--code added for defect id Tech-73996 starts
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
					PreviousCount)																									--code added for defect id Tech-73996 ends

	SELECT DISTINCT
					customer_name,				project_name,				@rcn_no,		process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					createdby,					GETDATE(),					modifiedby,			GETDATE(),
					ShowLines,					PreTask,					PostTask,			BulkDownload,	--TECH-68066
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, 	--Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight,	--Code added for TECH-71262 on 14July22 --Code Added for the DefectId Tech-72114
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,									--code added for defect id Tech-73996 starts
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection,
					PreviousCount	--code added for defect id Tech-73996 ends


			FROM	re_comp_ctrl_type_mst_extn a (NOLOCK)
			WHERE	Customer_Name		=	@customer_name
			AND		Project_Name		=	@project_name
			AND		Process_Name		=	@ProcessName
			AND		Component_Name		=	@ComponentName
			AND NOT EXISTS (	SELECT 'X'
								FROM	re_published_comp_ctrl_type_mst_extn b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@customer_name
								AND		b.Project_Name		=	@project_name
								AND		b.Process_Name		=	@ProcessName
								AND		b.Component_Name	=	@ComponentName
								AND		b.rcnno				=	@rcn_no )

	INSERT INTO re_published_comp_task_type_mst
			(	customer_name,				project_name,				rcnno,				process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				createdby,					createddate,				modifiedby,					modifieddate )					



	SELECT DISTINCT
				customer_name,				project_name,				@rcn_no,		process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,		--TECH-75230
				createdby,					GETDATE(),					modifiedby,			GETDATE()
		FROM	re_comp_task_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name
		AND		Project_Name		=	@project_name
		AND		Process_Name		=	@ProcessName
		AND		Component_Name		=	@ComponentName
		AND NOT EXISTS (	SELECT 'X'
							FROM	re_published_comp_task_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.task_type_name	=	a.task_type_name 
							
							AND		b.Customer_Name		=	@customer_name
							AND		b.Project_Name		=	@project_name
							AND		b.Process_Name		=	@ProcessName
							AND		b.Component_Name	=	@ComponentName
							AND		b.rcnno				=	@rcn_no )

	--case ID TECH-66583 Ends	

	SET NOCOUNT OFF
END

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 're_published_insert' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON re_published_insert TO PUBLIC
END
GO