IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='re_publ_sp_publcrml' AND TYPE = 'P')
    Begin
        Drop PROC re_publ_sp_publcrml
    End
GO
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 08/02/2005 (Patch Release 2)    */
/********************************************************************************/
/* procedure    : re_publ_sp_publcrml                                           */
/* description  : Multiline SP on Publishing requirements                       */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vijaykumar                                                    */
/* date         : 4/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 03/03/2005                                                    */
/* description  : Validation For One Control More than one Susbcription  */
/* BugID  : PNR2.0_2717       */
/* Modified by : Shriram V for callid PNR2.0_3616    */
/* Modified on : 22/08/05        */
/* Description : Length of BT Synonym Caption should not Exceed 60 Characters- */
/*Validation to be put in RCN download/Publish and ECR download/Publish  */
/* Modified by : SriSaravanaKumar V for callid PNR2.0_3672   */
/* Modified on : 29/08/05        */
/* Description : Unable to Publish RCN- RCN-2_412_RCN_0400. The following message */
/* come up "RCN Already exists.Choose another RCN".  */
/********************************************************************************/
/* modification history                                                             */
/* Modified by : Gowrisankar for callid PNR2.0_4079            */
/* Modified on : 03/09/05                   */
/* Description : Modification of the Enumerated Caption based on the language extension*/
/***************************************************************************************/
/* Modified By  : Date :   Description :    */
/* S K Mohamed Mohideen 15 Jun 2006 Task Confirmation Message changes */
/********************************************************************************/
/* Modified by : kiruthika R                  */
/* Modified on : 12/07/06                   */
/* Description : PNR2.0_9417               */
/***************************************************************************************/
/* Modified By  : Date :   Description :    */
/* S K Mohamed Mohideen 09 Nov 2006 Task Status Message changes  */
/********************************************************************************/
/* Modified by : Feroz                */
/* Modified on : 08/11/06               */
/* Description : State Processing             */
/********************************************************************************/
/* Modified by : Balaji S               */
/* Modified on : 04/06/07               */
/* Description : PNR2.0_13940             */
/********************************************************************************/
/* Modified by : Balaji S               */
/* Modified on : 04/06/07     */
/* Description : PNR2.0_13947             */
/********************************************************************************/
/* Modified by : Chanheetha N A              */
/* Modified on : 24-Jul-2005              */
/* Description : PNR2.0_14640             */
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 25-Apr-2008                                                  */
/* Bug Id    : PNR2.0_1476                */
/************************************************************************/
/* Modified by  : Gopinath S              */
/* Date         : 06-OCT-2008              */
/* Bug ID       : PNR2.0_19480              */
/*************************************************************************************/
/* modified by   : Feroz              */
/* date     : 25-nov-2008            */
/* BugId    : PNR2.0_1790             */
/************************************************************************************/
/* Modified by   : Feroz           */
/* Date     : 09-Jan-2008         */
/* BugId    : PNR2.0_20589          */
/************************************************************************************/
/* Modified by  : Gopinath S              */
/* Call ID  : PNR2.0_21334               */
/* Date         : 03-Mar-2009              */
/* Description  :   while publishing rcn the error Violation of PRIMARY KEY   */
/*     constraint re_published_ui_contextmenu_task_dtl_pk    */
/*************************************************************************************/
/* modified by  : Sangeetha G                                           */
/* date         : 19-May-2009                                           */
/* Bug Id  : PNR2.0_22275       */
/* modified for : To include page focus in state processing  */
/************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description     : PNR2.0_23463          */
/******************************************************************************/
/* Modified By     : Chanheetha N A        */
/* Date      : 23-Oct-2009         */
/* Bug Id      : PNR2.0_24424         */
/* Description     : Pagename added for mapped controls to launch EzeeView Link from model  */
/*************************************************************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 08-Feb-2010         */
/* Description     : PNR2.0_25863          */
/******************************************************************************/
/* Modified By     :  Sangeetha G  */
/* Date      :  05-Apr-10  */
/* Bugid     :  PNR2.0_26335  */
/* Modified For     :  Traversal table schema change */
/**********************************************************************************************/
/* Modified By     : Sangeetha G                  */
/* Date      : 28-Apr-2010          */
/* Bug Id      : PNR2.0_26701           */
/* Description     : Column addition for ListEdit Resolve tables */
/***********************************************************************************************/
/* Modified By     : Chanheetha N A                */
/* Date      : 19-May-2010          */
/* Bug Id      : PNR2.0_26860           */
/* Description     : Column addition for freezecount             */
/***********************************************************************************************/
/* Modified By       : Sangeetha G															   */
/* Date				 : Sep 17 2010															   */
/* Bug Id			 : PNR2.0_28333	                                                           */
/* Description       : Ezee view page for Platform                                             */
/***********************************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/**********************************************************************************************/
/* modified by   : Sangeetha G											*/  
/* date			 : 11-Apr-2011											*/  
/* BugId		 : PNR2.0_30869											*/  
/* modified for	 : Feature Release										*/  
/************************************************************************/ 
/* modified by	: Balaji D											   	*/
/* modified on	: May 18 2011											*/
/* Bug ID		: PNR2.0_31403 											*/
/* Case Desc	: Tree Grid Feature Enhancement.						*/
/************************************************************************/ 
/* modified by	: Balaji D											   	*/
/* modified on	: 15-Oct-2011											*/
/* Bug ID		: PNR2.0_34035 												*/
/* Case Desc	: Chart table schema change								*/
/********************************************************************************/
/* modified by  :	Muthupandi S												*/
/* date         :	01-December-2011											*/
/* Bug ID		:	PNR2.0_34596 												*/
/* Description	:	Validation added to avoid adding a new section with the existing */
/*					section name across UI										 */
/*********************************************************************************/
/* modified by	: Balaji D											   	*/
/* modified on	: Dec 31 2011											*/
/* Bug ID		: PNR2.0_35984 											*/
/* Case Desc	: Modelling for Splitter Section.						*/
/************************************************************************/
/* modified by  : Balaji D  			                                */
/* date         : July 02 2012			                                */
/* BugId        : PLF2.0_00961 			                                */
/* Case Desc    : PopUpSection,Button Right Align,Page/Button/Link Images*/
/************************************************************************/  
/* modified by  :	Kiruthika R											*/
/* date         :	06-Mar-2013											*/
/* Bug ID		:	PLF2.0_03710 										*/
/* Description	:	Customlist implementation for header edit controls.	*/
/************************************************************************/
/* modified by  :	Gankan G											*/
/* date         :	28-May-2013											*/
/* Bug ID		:	PLF2.0_04721 										*/
/* Description	:	Code modified to handle equal	tabwidth			*/
/************************************************************************/ 
/* modified by  :	 Shakthi P             															*/
/* date         : 12-Mar-2014            														*/
/* Bug ID  		: PLF2.0_07805           														  */
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan        			  */
/*********************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/  
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
 /* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/ 
/* Created by  	: Veena U                                                */
/* Date         : 28-Mar-2016                                                  */
/*Defect Id 	: PLF2.0_17570										*/
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/  
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 21-Nov-2017  Defect ID	:TECH-16126	*/  
/********************************************************************************/
/* Modified by  : Ranjitha R		Date: 2-Mar-2018  Defect ID	:TECH-19425	*/  
/********************************************************************************/ 
/* Modified by  : Jeya Latha K		Date: 30-Apr-2018  Defect ID	: TECH-20897 */  
/***************************************************************************************/
/* Modified by  :  Venkatesan K														   */
/* Date         :  10_05_2018														   */
/* Description  :  Batch id table updation for batch track purpose.					   */
/* case id		:  TECH-20631														   */
/***************************************************************************************/
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019  Defect ID: TECH-34971   */
/***************************************************************************************/
/* Modified by : Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809  */
/* Modified by : Jeya Latha K  	            Date: 29-Jan-2020  Defect ID : TECH-42483  */
/* Modified by : Rajeswari M/Jeya Latha K   Date: 27-Feb-2020  Defect ID : TECH-43307  */
/***************************************************************************************/
/* Modified by : Srikanth S                 Date: 03-MAR-2021  Defect ID : TECH-55955  */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451*/
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer*/
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo	   */ 
/***************************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	VimalKumar R												*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by : Priyadharshini U  												*/
/* Modified on : 27-July-2022                                                   */
/* Defect ID   : TECH-71262														*/
/* Description : Platform Features for the Month of July'22                     */
/********************************************************************************/
/* Modified by : Priyadharshini U /Ponmalar A									*/
/* Modified on : 23-Aug-2022                                                    */
/* Defect ID   : TECH-72114														*/
/* Description : Provision to upload mobility config xml, template and CSS into */
/*				 model and integrating with mobility code generator,			*/
/*				 Platform Modeling for Section Title Icon						*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 30-Sep-2022		Defect ID  : TECH-73216 */
/********************************************************************************/
/* Modified by : Priyadharshini U /Ponmalar A									*/
/* Modified on : 01-Dec-2022                                                    */
/* Defect ID   : TECH-75230														*/
/* Description : Platform Features for the Month of Nov'22                      */
/********************************************************************************/
CREATE PROCEDURE re_publ_sp_publcrml
@ctxt_language_in             engg_ctxt_language,
@ctxt_ouinstance_in           engg_ctxt_ouinstance,
@ctxt_service_in              engg_ctxt_service,
@ctxt_user_in                 engg_ctxt_user,
@engg_customer_name_in        engg_name,
@engg_ecr_descr_in            engg_description,
@engg_ecr_no_in               engg_name,
@engg_project_name_in         engg_name,
@modeflag_in                  engg_modeflag,
@engg_autocomplete            engg_name,
@fprowno_io                   engg_rowno,
@m_errorid                    engg_seqno output
as
begin

set nocount on

--declaration of temporary variables
declare @ctxt_language    engg_ctxt_language
declare @ctxt_ouinstance              engg_ctxt_ouinstance
declare @ctxt_service engg_ctxt_service
declare @ctxt_user                    engg_ctxt_user
declare @engg_customer_name           engg_name
declare @engg_ecr_descr               engg_description
declare @engg_ecr_no                  engg_name
declare @engg_project_name            engg_name
declare @modeflag                     engg_modeflag
declare @fprowno                      engg_rowno
declare @control_name   engg_name
declare @date    engg_date
declare @engg_ico_status  engg_name--kiruthika
declare @msg    engg_description
declare @depstatereq engg_name /*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
declare @act_depstate engg_name
declare @ui_depstate engg_name
declare @sec_depstate engg_name/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/



select @date = getdate()

--temporary and formal parameters mapping
select @ctxt_language                 = @ctxt_language_in
select @ctxt_ouinstance               = @ctxt_ouinstance_in
select @ctxt_service                  = ltrim(rtrim(@ctxt_service_in))
select @ctxt_user                     = ltrim(rtrim(@ctxt_user_in))
select @engg_customer_name            = ltrim(rtrim(@engg_customer_name_in))
select @engg_ecr_descr                = ltrim(rtrim(@engg_ecr_descr_in))
select @engg_ecr_no                   = ltrim(rtrim(@engg_ecr_no_in))
select @engg_project_name			  = ltrim(rtrim(@engg_project_name_in))
select @modeflag                      = ltrim(rtrim(@modeflag_in))
select @fprowno                       = @fprowno_io

-- if @modeflag <> 'Z'
if @modeflag  not in ( 'Z' , 'Y')
return

--null checking
if @ctxt_language = -915
select @ctxt_language = null

if @ctxt_ouinstance = -915
select @ctxt_ouinstance = null

if @ctxt_service = '~#~'
select @ctxt_service = null

if @ctxt_user = '~#~'
select @ctxt_user = null

if @engg_customer_name = '~#~'
select @engg_customer_name = null

if @engg_ecr_descr = '~#~'
select @engg_ecr_descr = null

if @engg_ecr_no = '~#~'
select @engg_ecr_no = null

if @engg_project_name = '~#~'
select @engg_project_name = null

if @modeflag = '~#~'
select @modeflag = null

if @fprowno = -915
select @fprowno = null
--errors mapped
--output parameters

SELECT @fprowno = @fprowno + 1

declare @proc_name    engg_name,
@comp_name          engg_name,
@act_name          engg_name,
@ui_name          engg_name,
@flow_page              engg_name,
@flow_task_name         engg_name,
@flowbr_name            engg_name,
@flowbr_descr           engg_description,
@flowbr_sequence        engg_seqno,
@control_id             engg_name,
@view_name              engg_name,
@event_name             engg_name,
@map_flag               engg_flag,

@prev_ecr               engg_name,
@ecr     engg_name,
@ecr_descr    engg_description

if(@engg_autocomplete='ECR')
begin
if exists (select 's' from fw_nia_activity_ui_task_temp(nolock)
where  CustomerID = @engg_customer_name
and   ProjectID  = @engg_project_name
and   rcnnumber  = @engg_ecr_no)
begin

select @ecr =  a.ECRNumber ,@ecr_descr=b.ECRDescription,@comp_name = c.ComponentName,@proc_name=a.BPID
from   fw_nia_activity_ui_task_temp a(nolock),
fw_rmt_ecr b(nolock),
fw_bpt_function_component c(nolock)
where  a.CustomerID    = @engg_customer_name
and    a.ProjectID    = @engg_project_name
and    a.rcnnumber     = @engg_ecr_no
and    a.CustomerID    = b.CustomerID
and    a.ProjectID    = b.ProjectID
and    a.ECRNumber     = b.ECRNumber
and    a.CustomerID    = c.CustomerID
and    a.ProjectID     = c.ProjectID
and    a.BPID          = c.BPID
and    a.FunctionID    = c.FunctionID


end

if exists (  select 's' from fw_nia_gendoc_dtltemp(nolock)
where  CustomerID = @engg_customer_name
and   ProjectID  = @engg_project_name
and   rcnnumber  = @engg_ecr_no
)

begin
select @ecr =  a.ECRNumber ,@ecr_descr=b.ECRDescription,@proc_name=a.BPID,
@comp_name = c.ComponentName
from   fw_nia_gendoc_dtltemp a(nolock),
fw_rmt_ecr b(nolock),
fw_bpt_function_component c(nolock)
where  a.CustomerID    = @engg_customer_name
and    a.ProjectID    = @engg_project_name
and    a.rcnnumber     = @engg_ecr_no
and    a.CustomerID    = b.CustomerID
and    a.ProjectID    = b.ProjectID
and    a.ECRNumber     = b.ECRNumber
and    a.CustomerID    = c.CustomerID
and    a.ProjectID     = c.ProjectID
and    a.BPID          = c.BPID
and    a.FunctionID    = c.FunctionID

end

if exists (
select 'x'
from de_ui_ico (nolock)
where customer_name  = @engg_customer_name
and  project_name  = @engg_project_name
and     process_name    = @proc_name
and   component_name  = @comp_name
and   ico_no      <> @ecr
and  ico_status  = 'C'
)
begin
select @prev_ecr  = ico_no
from de_ui_ico (nolock)
where customer_name  = @engg_customer_name
and  project_name  = @engg_project_name
and     process_name    = @proc_name
and   component_name  = @comp_name
and   ico_no      <> @ecr
and  ico_status  = 'C'
exec   engg_error_sp 'de_publ_sp_publico', 1, 'Publish the previous ECR Number <%1> first..',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@prev_ecr, '', '', '', @m_errorid
end

end  -- 'ecr'



if exists( select 'x'
from re_published_ui(nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  ecr_no   = @engg_ecr_no)
begin
/*  Code modified by Krishna Priya on 1205/2004 for bug id  : ECENG203ACC_000019  */
exec engg_error_sp 're_publ_sp_publcrml',1,'RCN Already published', /* PNR2.0_3672 */
--  exec engg_error_sp 're_publ_sp_publcrml',1,'RCN Already exists.Choose another RCN',
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
'','','','',@m_errorid output
if @m_errorid > 0
return
end

--code modified by Gopinath.S for bug id:PNR2.0_17048 on 28/02/2008
if exists( select 'x'
from re_ui_ecr(nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  ecr_no   = @engg_ecr_no
and  ui_status  = 'P'
and short_close = 'Yes')
begin--3
exec engg_error_sp 're_publ_sp_publcrml',2,'The RCN "<%1>" was Short-Closed',
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
@engg_ecr_no,'','','',@m_errorid output
if @m_errorid > 0
return
end --3

if exists( select 'x'
from re_ui_ecr(nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  ecr_no   = @engg_ecr_no
and  ui_status  = 'P')
begin--3
/*  Code modified by Krishna Priya on 1205/2004 for bug id  : ECENG203ACC_000019  */
--code modified by Gopinath.S for bug id:PNR2.0_17048 on 28/02/2008
exec engg_error_sp 're_publ_sp_publcrml',2,'RCN "<%1>" was already Published.',

@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
@engg_ecr_no,'','','',@m_errorid output
if @m_errorid > 0
return
end --3

-- code modified by shafina on 27-July-2004 to change the viewname for  ECENG203ACC_000053
if exists ( select 'X' from de_rmt_rcn_ecr_vw(nolock)
where customer_name  = @engg_customer_name
and  project_name  = @engg_project_name
and  ecr_no    = @engg_ecr_no
)
begin
exec engg_error_sp 're_publ_sp_publcrml',3,'Selected RCN number <%1> cannot be published as it is already mapped to an ECR.',
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
@engg_ecr_no,'','','',@m_errorid output
if @m_errorid > 0
return
end

/*  Code Added By Balaji S on 03/06/2005 For BugID : PNR2.0_2717
Validation For A Control With more than one Subscription */
Select @control_name = ''

Select @control_name  = control_bt_synonym
from re_subscription a(nolock),
re_ui_ecr  b(nolock)
where  a.customer_name  = @engg_customer_name
and   a.project_name   = @engg_project_name
and  b.ecr_no   = @engg_ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
GROUP BY  a.customer_name, a.project_name,
a.process_name,  a.component_name,
a.activity_name, a.ui_name,
a.page_bt_synonym, a.control_bt_synonym
HAVING COUNT(*) > 1

if isnull(@control_name, '') <> ''
begin
exec   engg_error_sp 're_publ_sp_publcrml',
1, 'One or more Subscription exists For Control <%1>',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@control_name, '', '', '', @m_errorid
return
end
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
select @depstatereq = current_value from es_project_param_mst (nolock)
						where customer_name = @engg_customer_name
						and project_name = @engg_project_name
						and param_category = 'DEPSTATEREQ' 
if @modeflag = 'Z'
begin

 -- 11537 starts
declare	@getdate	engg_date
select @getdate = getdate()

-- code modified by shafina on 26-Oct-2004 for ECENG203ACC_000084 (ECR for a component must be published in downloaded order)
select @date   = createddate,
@proc_name  = process_name,
@comp_name  = component_name
from re_ui_ecr (nolock)
where customer_name = @engg_customer_name
and  project_name	= @engg_project_name
and   ecr_no		= @engg_ecr_no
/*
-- Code added by Saravanan on 09/06/2005 for PNR2.0_2889 - To avoid multiple ECR publish - START
If exists (Select 'x' from re_rcn_publish_chk (nolock)
where work_flag in ('P', 'U')
and   customer_name = @engg_customer_name
and   project_name  = @engg_project_name)
begin
--- Code modified for Platform_2.0.3.X_468
-- Code Modified For Bug_id PNR2.0_17729 Starts Here
Select @msg = rcn_no +  ' is being published / unpublished by ' + publ_username +  ' from ' + cast(datepart (hh,start_time) as varchar(2)) + ':'+ cast(datepart (mi,start_time)as varchar(2))
+ ':'+ cast(datepart (ss,start_time)as varchar(2)) + ' onwards. Please try after some time...'
from re_rcn_publish_chk (nolock)
where work_flag in ('P', 'U')
exec   engg_error_sp 're_publ_sp_publcrml', 1, @msg ,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
'', '', '', '', @m_errorid
return
end
-- 11537 Ends
*/
	if @depstatereq = 'Y'
	begin 
	select  @act_depstate = a.activity_name,
	@ui_depstate =  a.ui_name,
	@sec_depstate = a.section_bt_synonym
	from  re_ui_section  a(nolock),
	re_ui_ecr b (nolock)
	where  a.customer_name =  b.customer_name
	and a.project_name =  b.project_name
	and a.process_name =  b.process_name
	and a.component_name= b.component_name
	and a.activity_name =  b.activity_name
	and a.ui_name		=  b.ui_name
	and b.customer_name =  @engg_customer_name
	and b.project_name	=  @engg_project_name
	and b.ecr_no = @engg_ecr_no
	group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name,a.section_bt_synonym
	having count(*) > 1


	if isnull(@ui_depstate,'') <> ''
	begin
	select @msg = 'In an UI :'+'"'+@ui_depstate+'"'+' under the activity '+'"'+@act_depstate+'"'+', section'+ '"'+@sec_depstate+ '"'+' is defined more than once' 
	exec engg_error_sp 're_publ_sp_publcrml',
	1, @msg,@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
	@control_name, '', '', '', @m_errorid
	return
end
end
end
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/
/*
Insert into re_rcn_publish_chk
(customer_name,     project_name,   rcn_no,   publ_username,   start_time,  host_mcname,  work_flag)
values
(@engg_customer_name,     @engg_project_name, @engg_ecr_no,    @ctxt_user,    getdate(),  host_name(),  'P')

if exists (
select 'x'
from re_ui_ecr (nolock)
where customer_name		=	@engg_customer_name
and  project_name		=	@engg_project_name
and   process_name		=	@proc_name
and   component_name	=	@comp_name
and   ecr_no			<>	@engg_ecr_no
and  ui_status			=	'C'
and  createddate		<	@date
)
*/
--  UI Table
insert into re_published_ui(
customer_name,project_name,process_name,
ecr_no,component_name,activity_name,
ui_name,ui_descr,ui_type,ui_format,caption_alignment,trail_bar,
tab_height,ui_sysid,createdby,createddate,
modifiedby,modifieddate,timestamp, state_processing,callout_type, taskpane_req
,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req,
personalization,Exclude_Systemtabindex-- PLF2.0_16291
,DeviceType,TabStyle,IsDesktop----PLF2.0_17570
,Hide_Print,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,ui_subtype,DBName,
IsGlance,Titlebar_Search, -- Column added for the BugId PNR2.0_1790,PNR2.0_30127
Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,	--Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --TECH-72114
PullToRefresh)	--TECH-75230
select @engg_customer_name,@engg_project_name,b.process_name,
@engg_ecr_no,b.component_name,b.activity_name,
b.ui_name,b.ui_descr,b.ui_type,b.ui_format,b.caption_alignment,b.trail_bar,
b.tab_height,newid(),@ctxt_user,@date,@ctxt_user,@date,1, state_processing,callout_type, taskpane_req,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req-- Column added for the BugId PNR2.0_1790,PNR2.0_30127
,personalization,Exclude_Systemtabindex,DeviceType,TabStyle,IsDesktop,Hide_Print-- PLF2.0_16291,PLF2.0_17570
,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults ,b.ui_subtype,b.DBName,
b.IsGlance,b.Titlebar_Search,
Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,	--Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --TECH-72114
PullToRefresh	--TECH-75230
from re_ui_ecr a(nolock),
re_ui b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
and  b.current_req_no =  a.ecr_no

------ NGPLF Changes Starts
----Declare @tmp_prc	engg_name,
----		@tmp_cmp	engg_name,
----		@tmp_act	engg_name,
----		@tmp_ui		engg_name,
----		@ctxt_role	engg_name 
		
----DECLARE getui CURSOR FOR
----select  a.component_name, a.process_name,  a.activity_name,  a.ui_name	
----from	re_ui_ecr a(nolock),
----		re_ui b(nolock)
----where	a.customer_name		= @engg_customer_name
----and		a.project_name		= @engg_project_name
----and		a.ecr_no			= @engg_ecr_no

----and		b.customer_name		= a.customer_name
----and		b.project_name		= a.project_name
----and		b.process_name		= a.process_name
----and		b.component_name	= a.component_name
----and		b.activity_name		= a.activity_name
----and		b.ui_name			= a.ui_name
----and		b.current_req_no	= a.ecr_no

----OPEN getui
----FETCH NEXT FROM getui into 	@tmp_cmp, @tmp_prc,	 @tmp_act, @tmp_ui
							
			
----WHILE @@FETCH_STATUS = 0
----BEGIN
				
----		Exec ngplf_rcn_publish 
----						@ctxt_language,			@ctxt_ouinstance,			@ctxt_user,				@ctxt_role,			
----						@engg_customer_name,	@engg_project_name,			@tmp_prc,				@tmp_cmp,				
----						@engg_ecr_no,			@tmp_act ,					@tmp_ui

----		FETCH NEXT FROM getui into 	@tmp_cmp, @tmp_prc,	 @tmp_act, @tmp_ui
----END
----CLOSE getui
----DEALLOCATE getui

------ NGPLF Changes Ends	

--UI PAGE--starts
insert into re_published_ui_page(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,horder,
vorder,ui_page_sysid,ui_sysid,
timestamp,createdby,createddate,
modifiedby,modifieddate,page_doc,
page_prefix, page_Type, pageimage--)-- Column added for the BugId PNR2.0_1790,PLF2.0_00961 --code modified for bugid:PLF2.0_04721
,width,PageClass --code added for bugid:PLF2.0_04721
,HeaderPosition,---PLF2.0_17570
TabRotation,TabTitleStyle,TabIconPosition,
PageLayout,XYCoordinates,ColumnLayWidth,
LeftToolbar,RightToolbar,TopToolbar,BottomToolbar)	--Code added for TECH-70687
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.horder,
b.vorder,newid(),newid(),1,@ctxt_user,@date,
@ctxt_user,@date,b.page_doc,b.page_prefix, b.page_Type, b.pageimage -- Column added for the BugId PNR2.0_1790,PLF2.0_00961
,width,PageClass --code added for bugid:PLF2.0_04721
,HeaderPosition,---PLF2.0_17570
TabRotation,TabTitleStyle,TabIconPosition,
PageLayout,XYCoordinates,ColumnLayWidth,
LeftToolbar,RightToolbar,TopToolbar,BottomToolbar	--Code added for TECH-70687
from re_ui_ecr a(nolock),
re_ui_page b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--Code Modification for PNR2.0_30869 starts

insert into re_published_ui_pageevents
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,horder,vorder,EventRequired,Task_Onclick,SystemGenerated,
timestamp,createdby,createddate,modifiedby,modifieddate)

select @engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,b.component_name,b.activity_name,b.ui_name,
b.page_bt_synonym,b.horder,b.vorder,EventRequired,Task_Onclick,SystemGenerated,
1,@ctxt_user,@date,@ctxt_user,@date
from re_ui_ecr a(nolock),
re_ui_pageevents b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--Code Modification for PNR2.0_30869 ends

--  UI SECTION
-- NEW COLUMN(TITLE_ALIGNMENT) ADDED BY DNR ON 31/03/2004
--code modified by kiruthika for bug id:PNR2.0_9417
insert into re_published_ui_section(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
visisble_flag,title_required,border_required,
parent_section,horder,vorder,
ui_section_sysid,page_sysid,timestamp,
createdby,createddate,modifiedby,
modifieddate,section_doc,title_alignment,width, height,section_type,
SectionPrefixClass, caption_Format, ctrl_caption_align, Setion_width_Scalemode,
Setion_height_Scalemode, section_prefix, Associated_control, splitter_pos, NColSpan, NRowSpan/*,IsStatic */,section_collapse,section_collapsemode,CarouselNavigation    -- Code modified for  PNR2.0_31403,PNR2.0_35984,jesse,--code Modified for the bugid : PLF2.0_07805  by
,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,---PLF2.0_17570
IsPlatform,	IsResponsive, mob_pop_fullview, 
BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor,BorderTopColor, 
BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, ForResponsive,  	--Code added for TECH-69624
LeftToolbar, RightToolbar,TopToolbar, BottomToolbar, MinimizedRows, ViewMode,HasTitleAction,  --Code added for TECH-70687
TitleIcon,Orientation )--TECH-72114 --TECH-75230
-- shakthi P 
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.visisble_flag,b.title_required,b.border_required,
b.parent_section,b.horder,b.vorder,
newid(),newid(),1,
@ctxt_user,@date,@ctxt_user,
@date,b.section_doc,b.title_alignment,b.width, b.height, b.section_type,
b.SectionPrefixClass, b.caption_Format, b.ctrl_caption_align, b.Setion_width_Scalemode,
b.Setion_height_Scalemode, b.section_prefix, b.Associated_control, splitter_pos,  -- Code modified for PNR2.0_31403,PNR2.0_35984
b.NColSpan, b.NRowSpan/*,IsStatic*/ ,section_collapse,section_collapsemode,CarouselNavigation--code Modified for the bugid : PLF2.0_07805  by shakthi P 
,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,---PLF2.0_17570
IsPlatform,	IsResponsive, mob_pop_fullview,
b.BorderLeftWidth, b.BorderRightWidth, b.BorderTopWidth, b.BorderBottomWidth, b.BorderLeftColor, b.BorderRightColor,b.BorderTopColor, 
b.BorderBottomColor, b.BorderTopLeftRadius, b.BorderTopRightRadius, b.BorderBottomLeftRadius, b.BorderBottomRightRadius, b.BorderStyle, b.ForResponsive,  	--Code added for TECH-69624
b.LeftToolbar, b.RightToolbar, b.TopToolbar, b.BottomToolbar, b.MinimizedRows, b.ViewMode,b.HasTitleAction,  --Code added for TECH-70687
b.TitleIcon, b.Orientation	--TECH-72114 --TECH-75230
from re_ui_ecr a(nolock),
re_ui_section b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--  UI CONTROL
--NEW COLUMN (ORDER_SEQ) ADDED BY DNR ON 31/03/2004
insert into re_published_ui_control(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,control_type,horder,
vorder,ui_control_sysid,ui_section_sysid,
timestamp,createdby,createddate,
modifiedby,modifieddate,control_id,
view_name,visisble_length,proto_tooltip,
sample_data,control_doc,control_prefix,order_seq,
data_column_width,label_column_width,
data_column_scalemode, label_column_scalemode,tab_seq, help_tabstop,
LabelClass, ControlClass, LabelImageClass, ControlImageClass, Set_User_Pref,freezecount,-- code Added by Gopinath S for the Call ID PNR2.0_19480) -- code modified for the caseid: PNR2.0_26860
controlimage, colspan, rowspan,TemplateID-- code modified for the caseid: PLF2.0_00961
,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,AccessKey,
SensitiveData, IsPlatform,-- added for DefectID: TECH-20897
PRESERVE_VISIBLE_LENGTH,Auto_width_column,DynamicStyle,ImageAsData 
,MoreEventEnabled,UpeSetFocusEnabled,-- added by 13705 for TECH-55955
ExtensionReqd ,ExtensionLaunchMode, ---Code added for TECH-60451
AssociateControl,--code added for TECH-63527
BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor,
BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, HasCustomAction,
ForResponsive,	--Code added for TECH-69624
ControlFormat,	--code added by 15228 on 08 aug 2022
ButtonNature, InlineStyle )	--TECH-75230
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.control_bt_synonym,b.control_type,b.horder,
b.vorder,newid(),newid(),1,@ctxt_user,@date,
@ctxt_user,@date,b.control_id,
b.view_name,b.visisble_length,b.proto_tooltip,
b.sample_data,b.control_doc,b.control_prefix,b.order_seq,
b.data_column_width,b.label_column_width,
b.data_column_scalemode, b.label_column_scalemode, b.tab_seq, b.help_tabstop,
b.LabelClass, b.ControlClass, b.LabelImageClass, b.ControlImageClass,b.Set_User_Pref,b.freezecount, -- code modified for the caseid: PNR2.0_26860
controlimage, colspan, rowspan,TemplateID -- code modified for the caseid: PLF2.0_00961
,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,AccessKey,
SensitiveData, IsPlatform,  -- added for DefectID: TECH-20897
PRESERVE_VISIBLE_LENGTH,Auto_width_column,DynamicStyle,ImageAsData
,MoreEventEnabled,UpeSetFocusEnabled,-- added by 13705 for TECH-55955
ExtensionReqd ,ExtensionLaunchMode ,---Code added for TECH-60451
AssociateControl, --code added for TECH-63527
BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor,
BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle,HasCustomAction,
ForResponsive, --Code added for TECH-69624
b.ControlFormat, -- Code added by 15228 on 08 aug 2022
b.ButtonNature, b.InlineStyle	--TECH-75230
from re_ui_ecr a(nolock),
re_ui_control b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--Code added for TECH-69624 starts
INSERT INTO re_published_ui_control_customaction(
				customer_name,					project_name,			rcnno,					process_name,		component_name,
				activity_name,					ui_name,				page_bt_synonym,		section_bt_synonym,	control_bt_synonym,
				ActionControlBTSynonym,			Control_ID,				View_Name,				ActionType,			ActionSequence,
				IconClass,						IconPosition,			Width,					ToolTip,			ActionName,
				ActionDescription,				ActionControlID,		ActionViewName,			
				Createdby,						Createddate,			Modifiedby,				Modifieddate)
		SELECT  @engg_customer_name,			@engg_project_name,		@engg_ecr_no,			cust.Process_Name,			cust.component_name,
				cust.activity_name,				cust.ui_name,			cust.page_bt_synonym,	cust.section_bt_synonym,	cust.control_bt_synonym,
				cust.ActionControlBTSynonym,	cust.Control_ID,		cust.View_Name,			cust.ActionType,			cust.ActionSequence,
				cust.IconClass,					cust.IconPosition,		cust.Width,				cust.ToolTip,				cust.ActionName,
				cust.ActionDescription,			cust.ActionControlID,	cust.ActionViewName,		
				@ctxt_user,						@date,					@ctxt_user,				@date
FROM re_ui_ecr  AS a (NOLOCK),
re_ui_control_customaction AS cust(NOLOCK)
WHERE a.customer_name		=	@engg_customer_name
AND   a.project_name		=	@engg_project_name
AND   a.ecr_no				=	@engg_ecr_no
AND  cust.customer_name		=	a.customer_name
AND  cust.project_name		=	a.project_name
AND  cust.process_name		=	a.process_name
AND  cust.component_name	=	a.component_name
AND  cust.activity_name		=	a.activity_name
AND  cust.ui_name			=	a.ui_name
--Code added for TECH-69624 ends

--Code added for TECH-70687 starts
INSERT INTO re_published_ui_section_Titleaction(
				customer_name,					project_name,			rcnno,					process_name,		component_name,
				activity_name,					ui_name,				page_bt_synonym,		section_bt_synonym,	TitleControlBTSynonym,
				ActionType,						ActionSequence,
				IconClass,						IconPosition,			Width,					ToolTip,			ActionName,
				ActionDescription,				ActionControlID,		ActionViewName,			
				Createdby,						Createddate,			Modifiedby,				Modifieddate,		Titleaction)
		SELECT  @engg_customer_name,			@engg_project_name,		@engg_ecr_no,			title.Process_Name,			title.component_name,
				title.activity_name,			title.ui_name,			title.page_bt_synonym,	title.section_bt_synonym,	title.TitleControlBTSynonym,
				title.ActionType,				title.ActionSequence,
				title.IconClass,				title.IconPosition,		title.Width,			title.ToolTip,				title.ActionName,
				title.ActionDescription,		title.ActionControlID,	title.ActionViewName,		
				@ctxt_user,						@date,					@ctxt_user,				@date,						title.Titleaction
FROM re_ui_ecr  AS a (NOLOCK),
re_ui_section_Titleaction AS title(NOLOCK)
WHERE a.customer_name		=	@engg_customer_name
AND   a.project_name		=	@engg_project_name
AND   a.ecr_no				=	@engg_ecr_no
AND  title.customer_name		=	a.customer_name
AND  title.project_name		=	a.project_name
AND  title.process_name		=	a.process_name
AND  title.component_name	=	a.component_name
AND  title.activity_name		=	a.activity_name
AND  title.ui_name			=	a.ui_name
--Code added for TECH-70687 ends


   ---Code added for TECH-60451 Starts


INSERT INTO re_published_ui_grid_Extension(
					Customer_Name,				Project_Name,			RcnNo,				Process_Name,
					Component_Name,				Activity_Name,			UI_Name,			Page_BT_Synonym,		
					Section_BT_Synonym,			Control_ID,				View_Name,			ParameterName,	
					ParameterSequence,			MappedBTSynonym,		MappedField,		
					createdby,					createddate,			modifiedby,			modifieddate)
			SELECT  @engg_customer_name,		@engg_project_name,		@engg_ecr_no,		extn.Process_Name,	
					extn.Component_Name,		extn.Activity_Name,		extn.UI_Name,		extn.Page_BT_Synonym,
					extn.Section_BT_Synonym,	extn.Control_ID,		extn.View_Name,		extn.ParameterName, 
					extn.ParameterSequence,		extn.MappedBTSynonym,	extn.MappedField,   
					@ctxt_user,					@date,					@ctxt_user,			@date
FROM re_ui_ecr  AS a (NOLOCK),
re_ui_grid_Extension AS extn(NOLOCK)
WHERE a.customer_name		=	@engg_customer_name
AND   a.project_name		=	@engg_project_name
AND   a.ecr_no				=	@engg_ecr_no
AND  extn.customer_name		=	a.customer_name
AND  extn.project_name		=	a.project_name
AND  extn.process_name		=	a.process_name
AND  extn.component_name	=	a.component_name
AND  extn.activity_name		=	a.activity_name
AND  extn.ui_name			=	a.ui_name

 ------Code added for TECH-60451 ends

-----13852 added on 20feb2020 Starts

insert into re_published_ui_section_refinement(
customer_name,	project_name,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,	page_bt_synonym,
section_bt_synonym,	rcnno,	visible_flag,	timestamp,	createdby,	createddate,	modifiedby,modifieddate)
select @engg_customer_name,	@engg_project_name,	r.process_name,	r.component_name,	r.activity_name,	r.ui_name,	r.Formfactor,	r.page_bt_synonym,
r.section_bt_synonym,	@engg_ecr_no,	r.visible_flag,	r.timestamp,	@ctxt_user,@date,	@ctxt_user,	@date
from re_ui_ecr a(nolock),
re_ui_section_refinement r(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  r.customer_name  = a.customer_name
and  r.project_name  = a.project_name
and  r.process_name  = a.process_name
and  r.component_name = a.component_name
and  r.activity_name  = a.activity_name
and  r.ui_name   = a.ui_name




insert into re_published_responsive_sec_weightage(
customer_name,	project_name,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,	page_bt_synonym,	parent_section,
section_bt_synonym,	rcnno,	Weightage,	SectionWidth,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
select @engg_customer_name,	@engg_project_name,	w.process_name,	w.component_name,	w.activity_name,	w.ui_name,	w.Formfactor,	w.page_bt_synonym,	w.parent_section,
w.section_bt_synonym,	@engg_ecr_no,	w.Weightage,	w.SectionWidth,	w.timestamp,	@ctxt_user,	@date,	@ctxt_user,		@date
from re_ui_ecr a(nolock),
re_responsive_sec_weightage w(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  w.customer_name  = a.customer_name
and  w.project_name  = a.project_name
and  w.process_name  = a.process_name
and  w.component_name = a.component_name
and  w.activity_name  = a.activity_name
and  w.ui_name   = a.ui_name

--13852 added on 20feb2020 End

-----13852 added on 13apr2020 Starts

insert into re_published_els_query_listedit_map(
customername,	projectname,	Rcnno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	SearchIndex,	Pagesize, createdby,	createddate,	Modifedby,modifieddate)
select @engg_customer_name,	@engg_project_name,		@engg_ecr_no,m.processname,	m.componentname,	m.activityname,	m.uiname,	m.ListControlSynonym,
m.ListControlID, m.ListViewname,	m.QueryID,	m.SearchIndex,	m.Pagesize,@ctxt_user,	@date,	@ctxt_user,	@date
from re_ui_ecr a(nolock),
re_els_query_listedit_map m(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  m.customername  = a.customer_name
and  m.projectname  = a.project_name
and  m.processname  = a.process_name
and  m.componentname = a.component_name
and  m.activityname  = a.activity_name
and  m.uiname   = a.ui_name

insert into re_published_els_query_listedit_input(
customername,	projectname,	Rcnno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	ParameterName,	MappedSynonym, MappedControlID,	MappedViewName,	createdby,	createddate,	Modifedby,modifieddate)
select @engg_customer_name,	@engg_project_name,		@engg_ecr_no,i.processname,	i.componentname,	i.activityname,	i.uiname,	i.ListControlSynonym,
i.ListControlID, i.ListViewname,	i.QueryID,i.ParameterName,	i.MappedSynonym,	i.MappedControlID,i.MappedViewName,	@ctxt_user,	@date,	@ctxt_user,	@date
from re_ui_ecr a(nolock),
re_els_query_listedit_input i(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  i.customername  = a.customer_name
and  i.projectname  = a.project_name
and  i.processname  = a.process_name
and  i.componentname = a.component_name
and  i.activityname  = a.activity_name
and  i.uiname   = a.ui_name


insert into re_published_els_query_listedit_result(
customername,	projectname,	Rcnno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	ListControlID,
ListViewname,	QueryID,	ResultColumnName,	MappedSynonym, MappedControlID,	MappedViewName,	ParameterCaption,Width,
IsVisible,	createdby,	createddate,	Modifedby,	modifieddate,seqno)
select @engg_customer_name,	@engg_project_name,		@engg_ecr_no,r.processname,	r.componentname,	r.activityname,	r.uiname,	r.ListControlSynonym,
r.ListControlID, r.ListViewname,	r.QueryID,	r.ResultColumnName,	r.MappedSynonym,	r.MappedControlID,r.MappedViewName,r.ParameterCaption,r.Width,
r.IsVisible,	@ctxt_user,	@date,	@ctxt_user,	@date,r.seqno
from re_ui_ecr a(nolock),
re_els_query_listedit_result r(nolock)
where a.customer_name  =	@engg_customer_name
and  a.project_name    =	@engg_project_name
and  a.ecr_no         =		@engg_ecr_no

and  r.customername  = a.customer_name
and  r.projectname  = a.project_name
and  r.processname  = a.process_name
and  r.componentname = a.component_name
and  r.activityname  = a.activity_name
and  r.uiname   = a.ui_name

--13852 added on 13apr2020 End

insert into re_published_non_ui_control(
customer_name,   project_name,   ecr_no,
process_name,   component_name,   activity_name,
ui_name,    page_bt_synonym,  section_bt_synonym,
control_bt_synonym,  control_type,   horder,
vorder,     ui_control_sysid,  ui_section_sysid,
timestamp,    createdby,    createddate,
modifiedby,    modifieddate,   control_id,
view_name,    visisble_length,  proto_tooltip,
sample_data,   control_doc,   control_prefix,
order_seq,    data_column_width,  label_column_width,
data_column_scalemode, label_column_scalemode )

select @engg_customer_name, @engg_project_name,  @engg_ecr_no,
b.process_name,   b.component_name,  b.activity_name,
b.ui_name,    b.page_bt_synonym,  b.section_bt_synonym,
b.control_bt_synonym, b.control_type,   b.horder,
b.vorder,    newid(),    newid(),
1,      @ctxt_user,    @date,
@ctxt_user,    @date,     b.control_id,
b.view_name,   b.visisble_length,  b.proto_tooltip,
b.sample_data,   b.control_doc,   b.control_prefix,
b.order_seq,   b.data_column_width, b.label_column_width,
data_column_scalemode, label_column_scalemode
from re_ui_ecr a(nolock),
re_non_ui_control b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name


--  GRID
insert into re_published_ui_grid(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,column_bt_synonym,column_type,
column_no,grid_sysid,ui_control_sysid,
timestamp,createdby,createddate,
modifiedby,modifieddate,control_id,
view_name,visible_length,proto_tooltip,
sample_data,col_doc,column_prefix, Set_User_Pref,-- code Added by Gopinath S for the Call ID PNR2.0_19480 --gridefault
default_required,visible,ColumnClass --Column added  for PNR2.0_30869 
/*,ColumnHdrClass*/,Forcefit,TemplateID,iskey,Kyseq_no
,TemplateCategory,TemplateSpecific,Column_class_ext6,RowExpander, GridToForm,icon_position,icon_class,TreeColumn,
column_Transformas,sensitivedata, IsPlatform,
CompactView,   -- added for GridToForm TECH-12776, TECH-20897
IsExtension, ExtensionOrder, --Code added for TECH-60451
AssociateControl)	--Code Added for TECH-71262
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.control_bt_synonym,b.column_bt_synonym,b.column_type,
b.column_no,newid(),newid(),1,@ctxt_user,@date,
@ctxt_user,@date,b.control_id,b.view_name,b.visible_length,b.proto_tooltip,
b.sample_data,b.col_doc,b.column_prefix, b.Set_User_Pref,b.default_required,b.visible,b.ColumnClass	--Column added  for PNR2.0_30869 
/*,b.ColumnHdrClass*/,b.Forcefit,TemplateID,iskey,Kyseq_no
,TemplateCategory,TemplateSpecific,Column_class_ext6,RowExpander, GridToForm,icon_position,icon_class,TreeColumn,
column_Transformas, sensitivedata, IsPlatform, CompactView, 
IsExtension, ExtensionOrder, --Code added for TECH-60451
AssociateControl	--Code Added for TECH-71262
from re_ui_ecr a(nolock),
re_ui_grid b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name


--------Column Grouping
Insert into re_published_ui_columngroup
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate,modifiedby,modifieddate,
grouplevel, groupseqno, parentgroup, parentgroupseq)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,b.activity_name,b.ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,b.timestamp,@ctxt_user,@date,@ctxt_user,@date,
grouplevel, groupseqno, parentgroup, parentgroupseq
from re_ui_ecr a(nolock),
re_ui_columngroup b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

Insert into re_published_calendar_configure
(Customer_name,Project_name,ecr_no,Process_name,Component_name,Activity_name,ui_name,page_name,section_name,monthview_cal,weekview_cal,editable,detailspane,listview_req,DefaultTemplate,
eventstyle,month_nav_req,week_nav_req,tap_req,doubletap_req,drag_req,month_nav_event,week_nav_event,tapevent,doubletap_event,dragevent,timestamp,createdby,createddate,
modifiedby,modifieddate)
Select 
a.Customer_name,a.Project_name,ecr_no,a.Process_name,a.Component_name,b.Activity_name,b.ui_name,b.page_name,b.section_name,b.monthview_cal,b.weekview_cal,b.editable,
b.detailspane,b.listview_req,b.DefaultTemplate,b.eventstyle,b.month_nav_req,b.week_nav_req,b.tap_req,b.doubletap_req,b.drag_req,b.month_nav_event,b.week_nav_event,
b.tapevent,b.doubletap_event,b.dragevent,b.timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
from re_ui_ecr a(nolock),
re_calendar_configure b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

Insert into re_published_tablet_columngroup
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate,modifiedby,modifieddate,
grouplevel, groupseqno, parentgroup, parentgroupseq)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,b.activity_name,b.ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,Group_caption,b.timestamp,@ctxt_user,@date,@ctxt_user,@date,
grouplevel, groupseqno, parentgroup, parentgroupseq
from re_ui_ecr a(nolock),
re_tablet_columngroup b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name


Insert into re_published_ui_column_group_mapping
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,
modifieddate)	
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,b.activity_name,b.ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,b.timestamp,@ctxt_user,@date,@ctxt_user,
@date
from re_ui_ecr a(nolock),
re_ui_column_group_mapping b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

Insert into re_published_phone_column_group_mapping
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,
modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,b.activity_name,b.ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,b.timestamp,@ctxt_user,@date,@ctxt_user,
@date
from re_ui_ecr a(nolock),
re_phone_column_group_mapping b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

Insert into re_published_tablet_column_group_mapping
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,
modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,b.activity_name,b.ui_name,Page_bt_synonym,section_bt_synonym,
grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,b.timestamp,@ctxt_user,@date,@ctxt_user,
@date
from re_ui_ecr a(nolock),
re_tablet_column_group_mapping b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name






--  Radio_Button

insert into re_published_radio_button(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,button_code,seq_no,
button_caption,default_flag,radio_button_sysid,
ui_control_sysid,timestamp,createdby,
createddate,modifiedby,modifieddate,horder,vorder)

select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.control_bt_synonym,b.button_code,b.seq_no,
b.button_caption,b.default_flag,
newid(),newid(),1,@ctxt_user,
@date,@ctxt_user,@date,horder,vorder
from re_ui_ecr   a (nolock),
re_radio_button b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

/*4085*/
insert into re_published_radio_button_lng_extn(
customer_name,  project_name, ecr_no,
process_name,  component_name, activity_name,
ui_name,   page_bt_synonym,section_bt_synonym,
control_bt_synonym, button_code, seq_no,
button_caption,  default_flag, radio_button_sysid,
ui_control_sysid, timestamp,  createdby,
createddate,  modifiedby,  modifieddate,
horder,    vorder,   languageid)

select @engg_customer_name, @engg_project_name, @engg_ecr_no,
b.process_name,   b.component_name, b.activity_name,
b.ui_name,    b.page_bt_synonym, b.section_bt_synonym,
b.control_bt_synonym, b.button_code,  b.seq_no,
b.button_caption,  b.default_flag,  newid(),
newid(),    1,     @ctxt_user,
@date,     @ctxt_user,   @date,
horder,     vorder,    languageid
from re_ui_ecr   a (nolock),
re_radio_button_lng_extn b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--  ENUM Value
insert into re_published_enum_value(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,enum_code,enum_caption,
default_flag,enum_value_sysid,ui_page_sysid,
timestamp,createdby,createddate,
modifiedby,modifieddate,seq_no)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.control_bt_synonym,b.enum_code,b.enum_caption,
b.default_flag, newid(),newid(),1,@ctxt_user,@date,
@ctxt_user,@date,seq_no
from re_ui_ecr a(nolock),
re_enum_value b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079

insert into re_published_enum_value_lng_extn(
customer_name,  project_name,  ecr_no,
process_name,  component_name,  activity_name,
ui_name,   page_bt_synonym, section_bt_synonym,
control_bt_synonym, enum_code,   enum_caption,
default_flag,  enum_value_sysid, ui_page_sysid,
timestamp,   createdby,   createddate,
modifiedby,   modifieddate,  seq_no,
languageid )
select @engg_customer_name, @engg_project_name, @engg_ecr_no,
b.process_name,   b.component_name, b.activity_name,
b.ui_name,    b.page_bt_synonym, b.section_bt_synonym,
b.control_bt_synonym, b.enum_code,  b.enum_caption,
b.default_flag,   newid(),   newid(),
1,      @ctxt_user,   @date,
@ctxt_user,    @date,    seq_no,
languageid
from re_ui_ecr a(nolock),
re_enum_value_lng_extn b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--  UI TRAVERSAL
--Code modification for PNR2.0_26335 starts

insert into re_published_ui_traversal(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,link_type,treaversal_sysid,
ui_page_sysid,timestamp,createdby,
createddate,modifiedby,modifieddate,
linked_component,linked_activity,linked_ui, associated_ctrl_bt_synonym,trvsl_seq
,Width,Height,Toolbar_notreq,LinkLaunchType)

select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.section_bt_synonym,
b.control_bt_synonym,b.link_type,
newid(),newid(),1,@ctxt_user,
@date,@ctxt_user,@date,
b.linked_component,b.linked_activity,b.linked_ui, b.associated_ctrl_bt_synonym,b.trvsl_seq
,Width,Height,Toolbar_notreq,LinkLaunchType
from re_ui_ecr a(nolock),
re_ui_traversal b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--Code modification for PNR2.0_26335 ends

--  re_action
insert into re_published_action(
customer_name,   project_name,   ecr_no,    process_name,
component_name,   activity_name,   ui_name,   page_bt_synonym,
task_name,    task_descr,    task_seq,   task_pattern,
timestamp,    createdby,    createddate,  modifiedby,
modifieddate,   primary_control_bts, task_sysid,   ui_sysid,
task_type,    task_confirm_msg,  task_status_msg, -- Column added by Mohideen on Jun 15, 2006
usageid ,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name, -- Columns added for the BugId PNR2.0_1790
task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close,Iscallout -- Code Added for PNR2.0_30869,PLF2.0_00234 
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,Autoupload,sectionlaunchtype,QuickTask,SystemTaskType, 	-- added for SectionLaunch Type TECH-12776 
Systemgenerated)	--TECH-73216
select @engg_customer_name, @engg_project_name,  @engg_ecr_no,  b.process_name,
b.component_name,  b.activity_name,  b.ui_name,   b.page_bt_synonym,
b.task_name,   b.task_descr,   b.task_seq,   b.task_pattern,
1,      @ctxt_user,    @date,    @ctxt_user,
@date,     b.primary_control_bts, newid(),   newid(),
b.task_type,   b.task_confirm_msg,  task_status_msg ,-- Column added by Mohideen on Jun 15, 2006
usageid ,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,-- Columns added for the BugId PNR2.0_1790
task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close ,b.IsCallout -- Code Added for PNR2.0_30869,PLF2.0_00234 
,b.QR_sourceCtrl,b.QR_targetCtrl,b.Barcode_sourceCtrl,b.Barcode_targetCtrl,b.browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,b.Autoupload,sectionlaunchtype,QuickTask,SystemTaskType,
Systemgenerated	--TECH-73216
from re_ui_ecr a(nolock),
re_action b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

insert into re_published_action_lng_extn(
customer_name,   project_name,   ecr_no,    process_name,
component_name,   activity_name,   ui_name,   page_bt_synonym,
task_name,    task_descr,    task_seq,   task_pattern,
timestamp,    createdby,    createddate,  modifiedby,
modifieddate,   primary_control_bts, task_sysid,   ui_sysid,
task_type,    languageid,    task_confirm_msg, task_status_msg, -- Column added by Mohideen on Jun 15, 2006
usageid ,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name, -- Columns added for the BugId PNR2.0_1790
task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close,Iscallout -- Code Added for PNR2.0_30869,PLF2.0_00234
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,autoupload)
select @engg_customer_name, @engg_project_name,  @engg_ecr_no,  b.process_name,
b.component_name,  b.activity_name,  b.ui_name,   b.page_bt_synonym,
b.task_name,   b.task_descr,   b.task_seq,   b.task_pattern,
1,      @ctxt_user,    @date,    @ctxt_user,
@date,     b.primary_control_bts, newid(),   newid(),
b.task_type,   b.languageid,   b.task_confirm_msg, task_status_msg ,-- Column added by Mohideen on Jun 15, 2006
usageid ,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,-- Columns added for the BugId PNR2.0_1790
task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close, Iscallout -- Code Added for PNR2.0_30869,PLF2.0_00234 
,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,
Buttonbar_primary_section,Popup_onclick_close,b.autoupload
from re_ui_ecr a(nolock),
re_action_lng_extn b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

-- Start for the Feature Context Menu(PNR2.0_1476) --Added by Jeya
Delete
from re_published_ui_contextmenu_task_dtl
where  customer_name = @engg_customer_name
and project_name = @engg_project_name
and    rcn_no   =  @engg_ecr_no

INSERT INTO re_published_ui_contextmenu_task_dtl(
CUSTOMER_NAME,  PROJECT_NAME,  PROCESS_NAME, COMPONENT_NAME,  ACTIVITY_NAME,  UI_NAME,
PAGE_BT_SYNONYM, section_name,  control_bt_synonym, control_id,  TASK_NAME, TASK_DESCR,  TASK_TYPE,
TASK_SEQ,  TASK_PATTERN,  TIMESTAMP,  CREATEDBY, CREATEDDATE,  MODIFIEDBY,
MODIFIEDDATE,  rcn_no )
-- Code modified by Gopinath S for the Call ID PNR2.0_21334 begins
select
b.customer_name,  b.project_name,  b.process_name, b.component_name,  b.activity_name,  b.ui_name,
b.page_bt_synonym, b.section_name,  b.control_bt_synonym, b.control_id,  b.task_name, b.task_descr,  b.task_type,
b.task_seq,  b.task_pattern,  b.timestamp,  b.createdby, b.createddate,  b.modifiedby,
b.modifieddate,  @engg_ecr_no
from re_ui_ecr a(nolock),
re_ui_contextmenu_task_dtl b(nolock)
where  a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name   = b.project_name
and  a.process_name   = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
-- Code modified by Gopinath S for the Call ID PNR2.0_21334 ends

-- End for the Feature Context Menu(PNR2.0_1476) --Added by Jeya

-- Added By Jeya Latha K for Contextual Links and Control Extensions Starts
insert into re_published_contextual_links
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name,
contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name,
task_name, createdby, createddate, modifiedby, modifieddate, task_type)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_name, b.control_bt_synonym,
contextual_link_name, contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname, linked_uiname,
subscription_name, task_name, @ctxt_user, @date, @ctxt_user, @date, task_type
from re_ui_ecr    a (nolock),
re_contextual_links b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name

insert into re_published_control_extensions
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name,
controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name,
task_name, createdby, createddate, modifiedby, modifieddate, task_type, image_path) -- Code Modified for the BugID PNR2.0_25863
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_name, b.control_bt_synonym,
controlextension_name, controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname, linked_uiname,
subscription_name, task_name, @ctxt_user, @date, @ctxt_user, @date, task_type, image_path
from re_ui_ecr    a (nolock),
re_control_extensions b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name

-- Added By Jeya Latha K for Contextual Links and Control Extensions End

-- added by feroz
insert into re_published_action_reuse_info
(customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name,
page_bt_synonym, task_name, task_descr, task_seq, task_pattern, reuse_activity, reuse_ui,
reuse_page, reuse_task, timestamp, createdby, createddate, modifiedby, modifieddate, primary_control_bts,
task_sysid, ui_sysid, task_type)
select
@engg_customer_name,@engg_project_name,@engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name,
b.page_bt_synonym, b.task_name, b.task_descr, b.task_seq, b.task_pattern, b.reuse_activity, b.reuse_ui,
b.reuse_page, b.reuse_task, 1, @ctxt_user, @date, @ctxt_user, @date, b.primary_control_bts,
b.task_sysid, b.ui_sysid, b.task_type
from re_ui_ecr   a (nolock),
re_action_reuse_info  b (nolock)
where a.customer_name  = @engg_customer_name
and a.project_name  = @engg_project_name
and a.ecr_no  = @engg_ecr_no
and b.customer_name  = a.customer_name
and b.project_name  = a.project_name
and b.process_name  = a.process_name
and b.component_name = a.component_name
and b.activity_name  = a.activity_name
and b.ui_name  = a.ui_name


insert into re_published_report_action_dataset
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name,
action_name, dataset_name, dataset_description, timestamp, createddate, createdby, modifieddate, modifeidby)
select
@engg_customer_name,@engg_project_name,@engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name,
b.action_name, b.dataset_name, b.dataset_description, 1, @date, @ctxt_user, @date, @ctxt_user
from re_ui_ecr     a (nolock),
re_report_action_dataset b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--added by  Muthu

insert into re_published_tree_dtl
(customer_name, project_name,ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
section_bt_synonym,node_type,node_description,event_req,mapped_task,open_img_name,not_exp_img_name,
expendable_img_name,expended_img_name,close_img_name,chkbox_chk_img,chkbox_unchk_img,chkbox_parial_chkimg,
createdby,createddate,modifiedby, modifieddate)
select  @engg_customer_name,@engg_project_name,@engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.section_bt_synonym,b.node_type,b.node_description,b.event_req,b.mapped_task,b.open_img_name,b.not_exp_img_name,
b.expendable_img_name,b.expended_img_name,b.close_img_name,b.chkbox_chk_img,b.chkbox_unchk_img,b.chkbox_parial_chkimg,
@ctxt_user,@date, @ctxt_user, @date
from  re_ui_ecr    a (nolock),
re_tree_dtl    b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name


insert into re_published_tree_sample_data
(customer_name, project_name,ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
section_bt_synonym,node_type,node_description,createdby,createddate,modifiedby, modifieddate, Node_id)
select  @engg_customer_name,@engg_project_name,@engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.section_bt_synonym,b.node_type,b.node_description,@ctxt_user,@date, @ctxt_user, @date, b.Node_id
from  re_ui_ecr     a (nolock),
re_tree_sample_data   b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name



insert into re_published_tree_sample_data_map
(customer_name, project_name,ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
section_bt_synonym, node_id, parent_node_id, node_type, node_description, parent_node_type, parent_node_descr, mapped_flag,
createdby,createddate,modifiedby, modifieddate)
select  @engg_customer_name,@engg_project_name,@engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.section_bt_synonym, b.node_id, b.parent_node_id, b.node_type, b.node_description, b.parent_node_type, b.parent_node_descr, b.mapped_flag,
@ctxt_user,@date, @ctxt_user, @date
from  re_ui_ecr           a (nolock),
re_tree_sample_data_map   b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- added by feroz for 203_3 for chart
insert into re_published_chart_header
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, chart_type,
chart_desc, chart_title, tooltip, datagrid, datagrid_type, legend_title, width, height, font, font_size, font_color, series_legend,
background_color, graphicsmode, legend_font, legend_font_size, legend_font_color, x_axis_title, x_series_elements, x_error_band_type,
x_error_marker_type, x_error_marker_size, x_error_marker_val, y_axis_title, x_auto_scale, x_divisions_min, x_divisions_max, x_units,
x_cal_err_value, y_units, x_showvalue, X_showname, x_font, x_font_size, x_font_color, x_con_type, x_con_color, x_con_style, x_con_weight,
x_con_wt_val, x_marker_type, x_marker_size, x_marker_color, x_marker_size_val, y_series_elements, y_error_band_type, y_error_marker_type,
y_error_marker_size, y_error_marker_value, y_auto_scale, y_divisions_min, y_divisions_max, y_secondary_axis, y_cal_err_value, y_font, y_font_size,
y_font_color, y_con_type, y_connector_color, y_connector_style, y_con_weight, y_con_wt_val, y_marker_type, y_marker_size, y_marker_color,
y_marker_size_val, background_image, override_chart_type, x_show_err_band, y_show_err_band, createdby, createddate, modifiedby, modifieddate,x_numdivlines,y_numdivlines,canvas_color,divline_color) --Code Modified for the Bug ID: PNR2.0_34035
select
@engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.chart_type,
b.chart_desc, b.chart_title, b.tooltip, b.datagrid, b.datagrid_type, b.legend_title, b.width, b.height, b.font, b.font_size, b.font_color, b.series_legend,
b.background_color, b.graphicsmode, b.legend_font, b.legend_font_size, b.legend_font_color, b.x_axis_title, b.x_series_elements, b.x_error_band_type,
b.x_error_marker_type, b.x_error_marker_size, b.x_error_marker_val, b.y_axis_title, b.x_auto_scale, b.x_divisions_min, b.x_divisions_max, b.x_units,
b.x_cal_err_value, b.y_units, b.x_showvalue, b.X_showname, b.x_font, b.x_font_size, b.x_font_color, b.x_con_type, b.x_con_color, b.x_con_style, b.x_con_weight,
b.x_con_wt_val, b.x_marker_type, b.x_marker_size, b.x_marker_color, b.x_marker_size_val, b.y_series_elements, b.y_error_band_type, b.y_error_marker_type,
b.y_error_marker_size, b.y_error_marker_value, b.y_auto_scale, b.y_divisions_min, b.y_divisions_max, b.y_secondary_axis, b.y_cal_err_value, b.y_font, b.y_font_size,
b.y_font_color, b.y_con_type, b.y_connector_color, b.y_connector_style, b.y_con_weight, b.y_con_wt_val, b.y_marker_type, b.y_marker_size, b.y_marker_color,
b.y_marker_size_val, b.background_image, b.override_chart_type, b.x_show_err_band, b.y_show_err_band,  @ctxt_user, @date, @ctxt_user, @date,x_numdivlines,y_numdivlines,canvas_color,divline_color --Code Modified for the Bug ID: PNR2.0_34035
from  re_ui_ecr            a (nolock),
re_chart_header     b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

insert into re_published_chart_sample_data
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data,
y_series_id, y_value, y_error_value, tooltip_text, createdby, createddate, modifiedby, modifieddate)
select
@engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.x_series_data,
b.y_series_id, b.y_value, b.y_error_value, b.tooltip_text,  @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr            a (nolock),
re_chart_sample_data  b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
insert into re_published_chart_series
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name,
con_type, con_color, con_style, con_weight, con_wt_val, marker_type, marker_size, marker_size_val, mark_color, error_band_type, error_marker_type, error_marker_size,
err_mark_size_val, auto_scale, divisions_min, divisions_max, units, x_showvalue, x_showname, sequence, y_secondary_axis, Y_Legend_Caption, cal_err_value, error_bands,
createdby, createddate, modifiedby, modifieddate, chart_type)
select
@engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.axis_id, b.series_id, b.series_name,
b.con_type, b.con_color, b.con_style, b.con_weight, b.con_wt_val, b.marker_type, b.marker_size, b.marker_size_val, b.mark_color, b.error_band_type, b.error_marker_type, b.error_marker_size,
b.err_mark_size_val, b.auto_scale, b.divisions_min, b.divisions_max, b.units, b.x_showvalue, b.x_showname, b.sequence, b.y_secondary_axis, b.Y_Legend_Caption, b.cal_err_value, b.error_bands,
@ctxt_user, @date, @ctxt_user, @date, b.chart_type
from  re_ui_ecr            a (nolock),
re_chart_series    b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- added by feroz for spin control

insert into re_published_spin_control
( customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym,
control_type, spin_control_bt_synonym, spincontrol_section, createdby, createddate, modifiedby, modifieddate)
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.control_bt_synonym,
b.control_type, b.spin_control_bt_synonym, b.spincontrol_section, @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr            a (nolock),
re_spin_control    b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- code added for state processing by feroz starts
insert into re_published_ui_state
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name,
state_id, state_descr, createdby, createddate, modifiedby, modifieddate, system_state)
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name,
b.state_id, b.state_descr, @ctxt_user, @date, @ctxt_user, @date, system_state
from  re_ui_ecr  a (nolock),
re_ui_state  b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

insert into re_published_ui_state_section
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, collapse, visible, enable, createdby, createddate, modifiedby, modifieddate )
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.section_bt_synonym, b.collapse, b.visible, b.enable, @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr     a (nolock),
re_ui_state_section  b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

insert into re_published_ui_state_control
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, control_bt_synonym, visible, enable, createdby, createddate, modifiedby, modifieddate)
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.section_bt_synonym, b.control_bt_synonym, b.visible, b.enable, @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr    a (nolock),
re_ui_state_control b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

insert into re_published_ui_state_task
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, rt_state, focus_control, createdby, createddate, modifiedby, modifieddate )
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.task_name, b.rt_state, b.focus_control, @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr    a (nolock),
re_ui_state_task b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

insert into re_published_ui_state_task_mst
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, task_name, task_descr, createdby, createddate, modifiedby, modifieddate )
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.task_name, b.task_descr, @ctxt_user, @date, @ctxt_user, @date
from  re_ui_ecr    a (nolock),
re_ui_state_task_mst b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

-- Code added for the BugId PNR2.0_1790 Starts
insert into re_published_ui_state_column
(customer_name, project_name, rcn_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, section_bt_synonym, control_bt_synonym,column_bt_synonym, column_no, visible, createdby, createddate, modifiedby, modifieddate,enable  )
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.section_bt_synonym, b.control_bt_synonym, b.column_bt_synonym, b.column_no, b.visible, @ctxt_user, @date, @ctxt_user, @date,b.enable
from  re_ui_ecr    a (nolock),
re_ui_state_column b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name


-- Code modification  for  PNR2.0_22275 starts

insert into re_published_ui_state_page
(customer_name, project_name, rcn_no, process_name, component_name, activity_name, ui_name, page_bt_synonym,
state_id, visible, enable, createdby, createddate, modifiedby, modifieddate ,focus)
select @engg_customer_name, @engg_project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.state_id, b.visible, b.enable, @ctxt_user, @date, @ctxt_user, @date,b.focus
from  re_ui_ecr    a (nolock),
re_ui_state_page b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

-- Code modification  for  PNR2.0_22275 ends

-- Code added for the BugId PNR2.0_1790 Ends

----   Code added for the BugId : PLF2.0_13289    Starts      
insert into re_published_ezwiz_wizard(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,wizard_desc,wizard_type,subscription_level,
timestamp,created_by,created_date,modified_by,modified_date,wizard_code)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.wizard_desc,b.wizard_type,B.subscription_level,
B.timestamp,@ctxt_user,@date,@ctxt_user,@date,wizard_code
from re_ui_ecr a(nolock),
re_ezwiz_wizard b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name

insert into re_published_ezwiz_wizard_local_info(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,lang_id,wizard_desc,timestamp,created_by,
created_date,modified_by,modified_date)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.lang_id,b.wizard_desc,B.timestamp,@ctxt_user,
@date,@ctxt_user,@date
from re_ui_ecr a(nolock),
re_ezwiz_wizard_local_info b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name

insert into re_published_ezwiz_wizard_step(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,step_desc,step_seqno,target_ilboname,target_activityname,
target_componentname,timestamp,created_by,created_date,modified_by,modified_date,subscription_level,
target_componentdesc,target_activitydesc,target_ilbodesc)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.step_desc,b.step_seqno,b.target_ilboname,b.target_activityname,
b.target_componentname,B.timestamp,@ctxt_user,@date,@ctxt_user,@date,subscription_level,
target_componentdesc,target_activitydesc,target_ilbodesc
from re_ui_ecr a(nolock),
re_ezwiz_wizard_step b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name

insert into re_published_ezwiz_wizard_step_local_info(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,lang_id,step_desc,timestamp,created_by,created_date,
modified_by,modified_date,step_seqno)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.lang_id,b.step_desc,B.timestamp,@ctxt_user,@date,
@ctxt_user,@date,step_seqno
from re_ui_ecr a(nolock),
re_ezwiz_wizard_step_local_info b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name

insert into re_published_ezwiz_res_step_dataitem(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,parent_step_desc,child_step_desc,parent_bt_synonym,child_bt_synonym,
parent_controlID,parent_viewname,child_controlID,child_viewname,
timestamp,created_by,created_date,modified_by,modified_date,parent_step_seqno,child_step_seqno)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.parent_step_desc,b.child_step_desc,b.parent_bt_synonym,b.child_bt_synonym,
b.parent_controlID,b.parent_viewname,b.child_controlID,b.child_viewname,
b.timestamp,@ctxt_user,@date,@ctxt_user,@date,parent_step_seqno,child_step_seqno
from re_ui_ecr a(nolock),
re_ezwiz_res_step_dataitem b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name

insert into re_published_ezwiz_res_ilbo_dataitem(customer_name,project_name,process_name,
component_name,ecr_no,wizard_name,parent_ilbo_desc,child_ilbo_desc,parent_ilbo_name,
child_ilbo_name,parent_comp_desc,child_comp_desc,parent_act_desc,child_act_desc,
parent_bt_synonym,child_bt_synonym,parent_controlID,parent_viewname,child_controlID,
child_viewname,timestamp,created_by,created_date,modified_by,modified_date,step_seqno,step_desc)
select distinct @engg_customer_name,@engg_project_name,b.process_name,
b.component_name,@engg_ecr_no,b.wizard_name,b.parent_ilbo_desc,child_ilbo_desc,parent_ilbo_name,
child_ilbo_name,parent_comp_desc,child_comp_desc,parent_act_desc,child_act_desc,
parent_bt_synonym,child_bt_synonym,parent_controlID,parent_viewname,child_controlID,
child_viewname,B.timestamp,@ctxt_user,@date,@ctxt_user,@date,step_seqno,step_desc
from re_ui_ecr a(nolock),
re_ezwiz_res_ilbo_dataitem b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
----   Code added for the BugId : PLF2.0_13289    Ends      

-- Code added for the BugId PNR2.0_1790 Starts
-- modified by bug id : PNR2.0_20589
insert into re_published_ezeeview_sp (customer_name,project_name,rcnno,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,
timestamp,createdby,createddate,modifiedby,modifieddate ,Linked_Task)
select a.customer_name, a.project_name,@engg_ecr_no, a.process_name, a.component_name, a.activity_name,
a.ui_name, page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,
a.timestamp,@ctxt_user,@date,@ctxt_user,@date, Linked_Task
from   re_ui_ecr       a (nolock),
re_ezeeview_sp   b (nolock)
where  a.customer_name = @engg_customer_name
and   a.project_name  = @engg_project_name
and   a.ecr_no     = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name  = a.project_name
and   b.process_name  = a.process_name
and   b.component_name= a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name    = a.ui_name

insert into re_published_ezeeview_spparamlist (customer_name,project_name,rcnno,process_name,component_name,activity_name,
ui_name,page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,
--code modified for the caseid :PNR2.0_24424 starts
timestamp,createdby,createddate,modifiedby,modifieddate,control_page_name )
select a.customer_name, a.project_name,@engg_ecr_no, a.process_name, a.component_name, a.activity_name,
a.ui_name, page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,
a.timestamp,@ctxt_user,@date,@ctxt_user,@date,control_page_name
--code modified for the caseid :PNR2.0_24424 ends
from   re_ui_ecr       a (nolock),
re_ezeeview_spparamlist   b (nolock)
where  a.customer_name = @engg_customer_name
and   a.project_name  = @engg_project_name
and   a.ecr_no     = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name  = a.project_name
and   b.process_name  = a.process_name
and   b.component_name= a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name    = a.ui_name
-- modified by bug id : PNR2.0_20589
-- Code added for the BugId PNR2.0_1790 Ends

-- code added for state processing by feroz ends

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Code added for the BugId PNR2.0_1790 Starts
insert into re_published_ext_js_section
(customer_name,  project_name,   ecr_no,   process_name,   component_name,  activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, section_type,  Section_Width,   Section_Height,  Section_Class,  RVW_Task,
Callout_Task,   Direction,    Scroll_Behaviour,Scroll_Delay,   Fade_Delay,   No_Of_Columns,   Report_Item_Class,
Property_Class,  Value_Class,   sample_data,  createdby,    createddate,   modifiedby,   modifieddate)
select
b.customer_name,  b.project_name,  @engg_ecr_no,  b.process_name,  b.component_name,  b.activity_name,  b.ui_name,
b.page_bt_synonym,  b.section_bt_synonym,b.section_type, b.Section_Width,  b.Section_Height,  b.Section_Class, b.RVW_Task,
b.Callout_Task,  b.Direction,   b.Scroll_Behaviour,b.Scroll_Delay,  b.Fade_Delay,   b.No_Of_Columns,  b.Report_Item_Class,
b.Property_Class,  b.Value_Class,   b.sample_data,   @ctxt_user,   @date,     @ctxt_user,   @date
from   re_ui_ecr       a (nolock),
re_ext_js_section   b (nolock)
where  a.customer_name = @engg_customer_name
and   a.project_name  = @engg_project_name
and   a.ecr_no     = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name  = a.project_name
and   b.process_name  = a.process_name
and   b.component_name= a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name    = a.ui_name

insert into re_published_ext_js_control
(customer_name,  project_name,   ecr_no,    process_name,   component_name,  activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, control_bt_synonym, Extjs_Ctrl_type,  Ctrl_height,   ctrl_width,   Control_Class,
RVW_Task,    Callout_Task,   Type_Delay,   Type_Direction, Fade_Delay,   Fade_Direction,  Loop_Count,
sample_data,   feature_name,  createdby,    createddate,   modifiedby,   modifieddate)
select
b.customer_name,  b.project_name,  @engg_ecr_no,   b.process_name,  b.component_name,  b.activity_name,  b.ui_name,
b.page_bt_synonym,  b.section_bt_synonym, b.control_bt_synonym, b.Extjs_Ctrl_type, b.Ctrl_height,  b.ctrl_width,   b.Control_Class,
b.RVW_Task,   b.Callout_Task,  b.Type_Delay,   b.Type_Direction,  b.Fade_Delay,   b.Fade_Direction,  b.Loop_Count,
b.sample_data,   b.feature_name,  @ctxt_user,   @date,     @ctxt_user,   @date
from   re_ui_ecr       a (nolock),
re_ext_js_control   b (nolock)
where  a.customer_name = @engg_customer_name
and   a.project_name  = @engg_project_name
and   a.ecr_no     = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name  = a.project_name
and   b.process_name  = a.process_name
and   b.component_name= a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name    = a.ui_name


insert into re_published_ext_js_section_column
(customer_name,  project_name,   ecr_no,    process_name,   component_name,  activity_name,   ui_name,
page_bt_synonym,  section_bt_synonym, section_type,   control_bt_synonym, column_sequence,  column_bt_synonym,  is_key,
datatype,    grouping,    grouping_function,  grouping_synonym,  rvw_task,  callout_task,   label_class,
control_class,   sample_data,   createdby,   createddate,   modifiedby,   modifieddate,  FieldList,
Default_Dragoption, column_type,  pivot_sequence
,visible_length,image_column)
select
b.customer_name,  b.project_name,  @engg_ecr_no,   b.process_name,  b.component_name,  b.activity_name,  b.ui_name,
b.page_bt_synonym,  b.section_bt_synonym, b.section_type,  b.control_bt_synonym,b.column_sequence, b.column_bt_synonym,b.is_key,
b.datatype,   b.grouping,   b.grouping_function,b.grouping_synonym, b.rvw_task,   b.callout_task,  b.label_class,
b.control_class,  b.sample_data,   @ctxt_user,   @date,     @ctxt_user,   @date ,    b.FieldList,
b.Default_Dragoption, b.column_type,  b.pivot_sequence
,visible_length,image_column
from   re_ui_ecr         a (nolock),
re_ext_js_section_column   b (nolock)
where  a.customer_name = @engg_customer_name
and   a.project_name  = @engg_project_name
and   a.ecr_no     = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name  = a.project_name
and   b.process_name  = a.process_name
and   b.component_name= a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name    = a.ui_name


-- Code added for the BugId PNR2.0_1790 Ends
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- code added by feroz for ListEdit Start
insert into re_published_listedit_column
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym,
listedit_column_seqno, listedit_controlid, listedit_viewname, column_prefix, createdby, createddate,visible_length)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.listedit_synonym, b.listedit_column_synonym,
b.listedit_column_seqno, b.listedit_controlid, b.listedit_viewname, b.column_prefix, @ctxt_user,   @date,b.visible_length
from re_ui_ecr   a (nolock),
re_listedit_column  b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

insert into re_published_listedit_control_map
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym,
listedit_synonym, control_id, view_name, createdby, createddate, listedit_controlid, listedit_viewname) -- Modified By feroz for bug id :PNR2.0_23463
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.mapped_bt_synonym,
b.listedit_synonym, b.control_id, b.view_name, @ctxt_user, @date, listedit_controlid, listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
from re_ui_ecr    a (nolock),
re_listedit_control_map b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

-- Modification for the defect id:TECH-16126
insert into re_published_resolvelist_data_map
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, listedit_synonym,
mapped_bt_synonym, listedit_column_synonym, data_mapped_synonym, primary_search_column, list_index_search, control_id, view_name, visible,
createdby, createddate ,mapped_bt_syn_page,map_listdata)   --Modified for  PNR2.0_26701
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.listedit_synonym,
b.mapped_bt_synonym, b.listedit_column_synonym, b.data_mapped_synonym, b.primary_search_column, b.list_index_search, b.control_id, b.view_name, b.visible,
@ctxt_user, @date ,mapped_bt_syn_page,map_listdata    --Modified for  PNR2.0_26701
from re_ui_ecr    a (nolock),
re_resolvelist_data_map b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name
-- Modification for the defect id: TECH-16126
--code added by kiruthika for bugid:PLF2.0_03710
	

insert into re_published_ui_combolink
(customer_name	,project_name		,process_name	,component_name, activity_name	,ui_name,
Combo_control_bt_synonym	,link_control_bt_synonym	,link_control_caption	,Display_seqno,
separatelink_req	,map	,createdby	,createddate	,modifiedby	,modifieddate,rcno	)
select
@engg_customer_name,@engg_project_name,a.process_name,a.component_name,a.activity_name,
a.ui_name,a.Combo_control_bt_synonym	,a.link_control_bt_synonym	,a.link_control_caption	,a.Display_seqno,
a.separatelink_req	,a.map	,@ctxt_user	,GETDATE(),@ctxt_user	,GETDATE(),@engg_ecr_no	
from re_ui_combolink a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

---insert into re_published_user_section
insert into re_published_user_section
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,rcnno,createdby,createddate,modifiedby,modifieddate)
Select 
@engg_customer_name,@engg_project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,@engg_ecr_no,@ctxt_user,getdate(),@ctxt_user,getdate()  
from re_user_section a (nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

-----Insertion for device table starts

insert into re_published_ui_device_control
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,
a.attributename,a.attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),a.control_id,a.view_name
from re_ui_device_control a(nolock) ,
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

insert into re_published_ui_device_grid
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,a.column_bt_synonym,
a.attributename,a.attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),control_id,view_name
from re_ui_device_grid a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

insert into re_published_ui_device_page
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,
a.attributename,a.attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_device_page a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

insert into re_published_ui_device_section
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.attributename,a.attributevalue,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_device_section a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name


insert into re_published_ui_device
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,attributename,attributevalue,
createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.attributename,a.attributevalue
,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_device a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name


-----Insertion for device table ends
/*
insert into re_published_ui_section_control_map
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
control_id,view_name,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,
a.control_id,a.view_name,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_section_control_map a(nolock),
re_ui_ecr b(nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and	 b.ECR_no		 = 	@engg_ecr_no
and	 a.rcnno		=	b.ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name*/

---insertion for placeholder and tooltip starts
insert into re_published_ui_tooltip_lng_extn
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,control_id,
view_name,languageid,tooltip,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,
a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,a.column_bt_synonym,a.control_id,
a.view_name,languageid,tooltip,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_tooltip_lng_extn a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_ui_placeholder_lng_extn
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,
control_bt_synonym,control_id,view_name,languageid,placeholder,timestamp
,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,
a.control_bt_synonym,a.control_id,a.view_name,languageid,placeholder,a.timestamp,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_placeholder_lng_extn a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name
--insertion for placeholder and tooltip ends


------ QlikLink PLF2.0_16291

insert into re_published_ui_control_association_map
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,section_bt_synonym,Control_id,view_name,propertyname,propertycontrol,property_controlid,
property_viewname,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,
a.page_bt_synonym,a.section_bt_synonym,a.Control_id,a.view_name,a.propertyname,a.propertycontrol,a.property_controlid,
a.property_viewname,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_ui_control_association_map a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name
--QlikLink PLF2.0_16291


------ code added for PLF2.0_16291 (Pivot tables )Starts 

insert into re_published_pivot_configure
(customer_name,project_name,process_name,component_name,activity_name,ui_name,
page_name,Control_bt_synonym,configpan_pos,rowgrandtot_pos,rowsubtot_pos,colgrandtot_pos,
colsubtot_pos,rowgrandtot_text,colgrandtot_text,rowsubtot_text,colsubtot_text,timestamp,
createdby,createddate,modifiedby,modifieddate,ecr_no)
Select 
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,
a.page_name,a.Control_bt_synonym,a.configpan_pos,a.rowgrandtot_pos,a.rowsubtot_pos,a.colgrandtot_pos,
a.colsubtot_pos,a.rowgrandtot_text,a.colgrandtot_text,a.rowsubtot_text,a.colsubtot_text,a.timestamp,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),@engg_ecr_no
from re_pivot_configure a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_pivot_fields
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,column_bt_synonym
,rowlabel,columnlabel,fieldValue,rowlabelseq,columnlabelseq,valueseq,ValueFunction,rowlabelsorting,columnlabelsorting,timestamp,createdby
,createddate,modifiedby,modifieddate,ecr_no)
Select 
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_name,a.Control_bt_synonym,a.column_bt_synonym
,a.rowlabel,a.columnlabel,a.fieldValue,a.rowlabelseq,a.columnlabelseq,a.valueseq,a.ValueFunction,a.rowlabelsorting,a.columnlabelsorting,a.timestamp,@ctxt_user,
GETDATE(),@ctxt_user,GETDATE(),@engg_ecr_no
from re_pivot_fields a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
--and	 a.rcnno			= b.ecr_no -- commented for Defect Id:TECH-19425 
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_pivot_lang_extn
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,DisplayField,
Languageid,DisplayText,timestamp,createdby,createddate,modifiedby,modifieddate,ecr_no)
Select 
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_name,a.Control_bt_synonym,a.DisplayField,
a.Languageid,a.DisplayText,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),@engg_ecr_no
from re_pivot_lang_extn a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

------ code added for PLF2.0_16291 (Pivot tables )Ends '
----Phone and Tablet tables start PLF2.0_17570
insert into re_published_phone
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,
timestamp,createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation )
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.ui_descr,a.ui_type,a.ui_format,a.tab_height,a.TabStyle,
a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation 
from re_phone a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_tablet
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,
timestamp,createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation )
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.ui_descr,a.ui_type,a.ui_format,a.tab_height,a.TabStyle,
a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation 
from re_tablet a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_phone_page
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,
TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.horder,a.vorder,a.HeaderPosition,
a.TabRotation,a.TabTitleStyle,a.TabIconPosition,a.PageLayout,a.XYCoordinates,a.ColumnLayWidth,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),PageClass
from re_phone_page a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_tablet_page
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,
TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.horder,a.vorder,a.HeaderPosition,
a.TabRotation,a.TabTitleStyle,a.TabIconPosition,a.PageLayout,a.XYCoordinates,a.ColumnLayWidth,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),PageClass
from re_tablet_page a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_phone_section
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
section_type,title_required,border_required,parent_section,horder,vorder,title_alignment,width,height,caption_Format,
ctrl_caption_align,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,
SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.section_type,a.title_required,a.border_required,a.parent_section,a.horder,a.vorder,a.title_alignment,a.width,a.height,a.caption_Format,
a.ctrl_caption_align,a.Section_width_Scalemode,a.Section_height_Scalemode,a.SectionPrefixClass,a.Region,a.TitlePosition,a.CollapseDir,
a.SectionLayout,a.XYCoordinates,a.ColumnLayWidth,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_phone_section a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_tablet_section
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
section_type,title_required,border_required,parent_section,horder,vorder,title_alignment,width,height,caption_Format,
ctrl_caption_align,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,
SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.section_type,a.title_required,a.border_required,a.parent_section,a.horder,a.vorder,a.title_alignment,a.width,a.height,a.caption_Format,
a.ctrl_caption_align,a.Section_width_Scalemode,a.Section_height_Scalemode,a.SectionPrefixClass,a.Region,a.TitlePosition,a.CollapseDir,
a.SectionLayout,a.XYCoordinates,a.ColumnLayWidth,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_tablet_section a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_phone_control
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,control_type,horder,vorder,order_seq,data_column_width,label_column_width,label_column_scalemode,data_column_scalemode,control_id,view_name,visible_length,
sample_data,LabelClass,ControlClass,freezecount,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.control_bt_synonym,a.control_type,a.horder,a.vorder,a.order_seq,a.data_column_width,a.label_column_width,label_column_scalemode,data_column_scalemode,a.control_id,a.view_name,a.visible_length,
a.sample_data,a.LabelClass,a.ControlClass,a.freezecount,TemplateID,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),TemplateCategory,TemplateSpecific
from re_phone_control a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_tablet_control
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,control_type,horder,vorder,order_seq,data_column_width,label_column_width,control_id,view_name,visible_length,
sample_data,LabelClass,ControlClass,freezecount,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,label_column_scalemode,data_column_scalemode
,TemplateCategory,TemplateSpecific)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.control_bt_synonym,a.control_type,a.horder,a.vorder,a.order_seq,a.data_column_width,a.label_column_width,a.control_id,a.view_name,a.visible_length,
a.sample_data,a.LabelClass,a.ControlClass,a.freezecount,TemplateID,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),label_column_scalemode,data_column_scalemode
,TemplateCategory,TemplateSpecific
from re_tablet_control a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name

insert into re_published_phone_grid
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,
TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.control_bt_synonym,a.column_bt_synonym,a.column_type,a.column_no,a.control_id,a.view_name,a.visible_length,a.sample_data,a.ColumnClass,
a.TemplateID,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),TemplateCategory,TemplateSpecific
from re_phone_grid a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name


insert into re_published_tablet_grid
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
control_bt_synonym,column_bt_synonym,column_type,column_no,control_id,view_name,visible_length,sample_data,ColumnClass,
TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,
a.control_bt_synonym,a.column_bt_synonym,a.column_type,a.column_no,a.control_id,a.view_name,a.visible_length,a.sample_data,a.ColumnClass,
a.TemplateID,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),TemplateCategory,TemplateSpecific
from re_tablet_grid a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and	 a.rcnno			= b.ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name


----Phone and Tablet Tables End PLF2.0_17570

			insert into re_published_custom_listedit
			(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym, list_search_id,
			 list_search_context, list_index_search, list_recurrent_search, list_search_delay, list_select_column, list_result_column, list_width,
			 createdby, createddate, modifiedby, modifieddate)
			select distinct
			 b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.listedit_synonym, b.list_search_id,
			 b.list_search_context, b.list_index_search, b.list_recurrent_search, b.list_search_delay, b.list_select_column, b.list_result_column, b.list_width,
			 @ctxt_user, @date, @ctxt_user, @date
			from re_ui_ecr    a (nolock),
				 re_custom_listedit b (nolock)
			where a.customer_name = @engg_customer_name
			and  a.project_name   = @engg_project_name
			and  a.ecr_no		  = @engg_ecr_no
			and  b.customer_name  = a.customer_name
			and  b.project_name   = a.project_name
			and  b.process_name   = a.process_name
			and  b.component_name = a.component_name
			and  b.activity_name  = a.activity_name
			and  b.ui_name		  = a.ui_name
--code added by kiruthika for bugid:PLF2.0_03710

insert into re_published_date_highlight_control_map
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, listedit_synonym, control_bt_synonym,
controlid, viewname, listedit_controlid, listedit_viewname, createdby, createddate)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym, b.section_bt_synonym, b.listedit_synonym, b.control_bt_synonym,
b.controlid, b.viewname, b.listedit_controlid, b.listedit_viewname, @ctxt_user, @date
from re_ui_ecr    a (nolock),
re_date_highlight_control_map b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

-- specify template changes--

insert into re_published_ui_Temp_placeholders
(activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,createdby,createddate,modifiedby,modifieddate,rcnno,placeholder,associatedColumn,associatedevent)
select
b.activity_name,b.customer_name,b.project_name,b.process_name,b.component_name,b.ui_name,b.page_bt_synonym,
b.Control_bt_synonym,b.section_bt_synonym,b.templateid,b.control_id,b.view_name,@ctxt_user,getdate(),@ctxt_user,getdate(),@engg_ecr_no,b.placeholder,b.associatedColumn,b.associatedevent
from re_ui_ecr    a (nolock),
re_ui_Temp_placeholders b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

insert into re_published_ui_template_controlmap
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,createdby,createddate,modifiedby,modifieddate,rcnno)
select
b.customer_name,b.project_name,b.process_name,b.component_name,b.activity_name,b.ui_name,b.page_bt_synonym,b.Control_bt_synonym,b.section_bt_synonym,b.templateid,b.control_id,b.view_name
,@ctxt_user,getdate(),@ctxt_user,getdate(),@engg_ecr_no
from re_ui_ecr    a (nolock),
re_ui_template_controlmap b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

-- specify template ends--

-- code added by feroz for ListEdit End
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Added By Feroz for UI Toolbar -- Start
insert into re_published_ui_toolbar_group
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_name, group_descr, createddate, createdby, modifieddate, modifiedby,Orientation)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, group_name, group_descr, @date, @ctxt_user, @date, @ctxt_user,Orientation
from re_ui_ecr     a (nolock),
re_ui_toolbar_group  b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name

insert into re_published_ui_toolbar
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name, task_seqno, class_name, display_text,
group_task_desc, createddate, createdby, modifieddate, modifiedby,group_node_task)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, group_name, group_task_name, task_seqno, class_name, display_text,
group_task_desc, @date, @ctxt_user, @date, @ctxt_user,group_node_task
from re_ui_ecr     a (nolock),
re_ui_toolbar    b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name

insert into re_published_ui_displaytext_lang_extn
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_task_name, display_text, lang_id, createddate, createdby,group_name)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, group_task_name, display_text, lang_id, @date, @ctxt_user,group_name
from re_ui_ecr      a (nolock),
re_ui_displaytext_lang_extn b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name


insert into re_published_ui_toolbar_mapping
(customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name, display_seqno, class_name, display_text,
caption_req, control_req, createddate, createdby, modifieddate, modifiedby)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, toolbar_id, group_task_name, display_seqno, class_name, display_text,
caption_req, control_req, @date, @ctxt_user, @date, @ctxt_user
from re_ui_ecr    a (nolock),
re_ui_toolbar_mapping b (nolock)
where a.customer_name = @engg_customer_name
and   a.project_name = @engg_project_name
and   a.ecr_no   = @engg_ecr_no
and   b.customer_name = a.customer_name
and   b.project_name = a.project_name
and   b.process_name = a.process_name
and   b.component_name = a.component_name
and   b.activity_name = a.activity_name
and   b.ui_name   = a.ui_name


-- Added By Feroz for UI Toolbar -- End
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- code added by Jeya  for Dynamic Section Start
insert into re_published_dynamic_sec_control_map
(customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name,  page_bt_synonym,
section_bt_synonym, control_bt_synonym, controlid, viewname, createdby, createddate)
select
b.customer_name, b.project_name, @engg_ecr_no, b.process_name, b.component_name, b.activity_name, b.ui_name, b.page_bt_synonym,
b.section_bt_synonym,  b.control_bt_synonym, b.controlid, b.viewname, @ctxt_user,   @date
from re_ui_ecr   a (nolock),
re_dynamic_sec_control_map   b (nolock)
where a.customer_name = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no  = @engg_ecr_no
and  b.customer_name = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name= a.component_name
and  b.activity_name = a.activity_name
and  b.ui_name  = a.ui_name

-- code added by Jeya  for Dynamic Section End
--PUBLISHED ACTION MAP
--NEW COLUMN(SECTION_PAGE_BT_SYNONYM) ADDED BY DNR ON 31/03/2004
insert into re_published_action_section_map(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,task_name,section_bt_synonym,
task_section_sysid,task_sysid,timestamp,
createdby,createddate,modifiedby,modifieddate,section_page_bt_synonym)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.task_name,b.section_bt_synonym,
newid(),newid(),1,
@ctxt_user,@date,@ctxt_user,@date,section_page_bt_synonym
from re_ui_ecr a(nolock),
re_action_section_map b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--  FLOW BR RULE MAP
insert into re_published_flowbr_rule_map(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,task_name,
flowbr_name,br_id,br_name,
br_type,seq_no,br_sysid,
flowbr_sysid,timestamp,createdby,createddate,
modifiedby,modifieddate,br_component_name)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.task_name,
b.flowbr_name,b.br_id,b.br_name,
b.br_type,b.seq_no,
newid(),newid(),1,@ctxt_user,
@date,@ctxt_user,@date,b.br_component_name
from re_ui_ecr    a(nolock),
re_flowbr_rule_map  b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--code added for focus control by kiruthika R
if exists ( select 'x'
from es_CodeGen_Used (nolock)
where   Customer_Name = rtrim(@engg_customer_name)
and     Project_Name    = rtrim(@engg_project_name) )
begin
declare @count engg_name
set @count = ''
if exists ( select 'x'
from re_ui_ecr a(nolock),
re_flowbr_br_error b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
and     isnull(b.error_context, '') <> '')
begin
select @count =
case
when  a.MS_Dev_Required  ='Yes'and b.MS_Dev_Available     = 'No' then 'Ms Dev console'
when  a.MS_LP_Required   ='Yes'and b.MS_LP_Available      = 'No' then 'Ms Launch Pad'
when  a.Java_Dev_Required ='Yes'and b.Java_Dev_Available   = 'No' then 'Java Dev console'
when  a.Java_LP_Required  ='Yes'and b.Java_LP_Available    = 'No' then 'Java Launch Pad'
when  a.DotNet_Dev_Required ='Yes'and b.DotNet_Dev_Available = 'No' then 'DotNet Dev console'
when  a.DotNet_LP_Required ='Yes'and b.DotNet_LP_Available  = 'No' then 'DotNet Launch Pad'
else  'No error'
end
from    es_CodeGen_Used    a (nolock),
es_Feature_Available  b (nolock)
where   a.Customer_Name  = rtrim(@engg_customer_name)
and     a.Project_Name    = rtrim(@engg_project_name)
and  a.Feature_List  = 'Focus Control'
and  a.Feature_List  = b.Feature_List

if @count <> 'No error'
begin
select @msg = 'Focus Control does not support in the '+@count
exec engg_error_sp
'ep_validation_sp',  8,     @msg,
@ctxt_language,   @ctxt_ouinstance, @ctxt_service,
@ctxt_user,    '',     '',
'',      '',     @m_errorid output

if @m_errorid <> 0
return
end
end
end


--  FLOW BR ERROR
insert into re_published_flowbr_br_error(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,task_name,
flowbr_name,br_id,message_id,
message_descr,default_flag,msg_sysid,
br_sysid,timestamp,createdby,createddate,
modifiedby,modifieddate,msg_severity, error_context)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.task_name,
b.flowbr_name,b.br_id,b.message_id,
b.message_descr,b.default_flag,
newid(),newid(),1,@ctxt_user,@date,
@ctxt_user,@date,b.msg_severity,b.error_context
from re_ui_ecr a(nolock),
re_flowbr_br_error b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

-- code modified by shafina on 28-May-2004 for REENG203ACC_000067
--FLOWBR_COMBO
insert into re_published_flowbr_combo(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,task_name,flowbr_name,
combo_bt_synonym,combo_sysid,
flowbr_sysid,timestamp,createdby,createddate,
modifiedby,modifieddate,combo_page_name,clear_tree_before_population)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.task_name,b.flowbr_name,
b.combo_bt_synonym,
newid(),newid(),1,@ctxt_user,
@date,@ctxt_user,@date,b.combo_page_name,b.clear_tree_before_population
from re_ui_ecr a(nolock),
re_flowbr_combo b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
/*PNR2.0_14640*/
--  update b
--  set  data_type    = c.data_type,
--    length     = c.length,
--    bt_synonym_caption  = c.bt_synonym_caption,
--    modifiedby    = @ctxt_user,
--    modifieddate   = @date ,
--    ref_bt_synonym_name  = c.ref_bt_synonym_name ,
--    bt_synonym_doc   = c.bt_synonym_doc,
--    bt_name     = c.bt_name ,
--    synonym_status   = c.synonym_status,
--    singleinst_sample_data = c.singleinst_sample_data,
--    multiinst_sample_data = c.multiinst_sample_data
--  from re_ui_ecr    a (nolock),
--    re_published_glossary  b (nolock),
--    re_glossary    c (nolock)
--  where a.customer_name  = @engg_customer_name
--  and  a.project_name  = @engg_project_name
--  and  a.ecr_no   = @engg_ecr_no
--
--  and  b.customer_name  = a.customer_name
--  and  b.project_name  = a.project_name
--  and  b.ecr_no   = a.ecr_no
--  and  b.component_name = a.component_name
--
--  and  c.customer_name  = b.customer_name
--  and  c.project_name  = b.project_name
--  and  c.process_name  = b.process_name
--  and  c.component_name = b.component_name
--  and  c.bt_synonym_name = b.bt_synonym_name
/*PNR2.0_14640*/
-- GLOSSARY
--NEW COLUMNS (PROCESS_NAME,COMPONENT_NAME) ADDED BY DNR ON 31/03/2004
insert into re_published_glossary(
customer_name,project_name,ecr_no,process_name,component_name,
bt_synonym_name,data_type,length,bt_synonym_caption,glossary_sysid,timestamp,
createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,
bt_name,synonym_status, singleinst_sample_data , multiinst_sample_data, IsGlance)
select distinct
@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,b.component_name,
b.bt_synonym_name,b.data_type,length,b.bt_synonym_caption,
left(a.ecr_no+b.bt_synonym_name+a.component_name,40), 1, @ctxt_user,@date,@ctxt_user,@date,b.ref_bt_synonym_name,b.bt_synonym_doc,
b.bt_name,b.synonym_status, singleinst_sample_data , multiinst_sample_data, IsGlance
from re_ui_ecr  a (nolock),
re_glossary   b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  not exists ( select 's'
from re_published_glossary c (nolock)
where c.customer_name  = b.customer_name
and  c.project_name  = b.project_name
and  c.process_name = b.process_name
and  c.component_name = b.component_name
and  c.ecr_no   = @engg_ecr_no
and  c.bt_synonym_name = b.bt_synonym_name)


--Added by Shriram V on 22/08/05 for  Bug Id : PNR2.0_3616
--Code Modified for bugId : PNR2.0_13940
--Code Commented for bugId : PNR2.0_13947
--  if exists (  select 'x'
--       from re_ui_control  a(nolock),
--         es_comp_ctrl_type_mst b(nolock),
--         re_ui_ecr    c(nolock),
--         re_glossary_lng_extn d(nolock)
--       where a.customer_name   = b.customer_name
--       and  a.project_name   = b.project_name
--       and  a.process_name   = b.process_name
--       and  a.component_name  = b.component_name
--       and  a.control_type   = b.ctrl_type_name
--       and  b.base_ctrl_type  <> 'label'
--       and  a.customer_name   = c.customer_name
--       and  a.project_name   = c.project_name
--       and  a.process_name   = c.process_name
--       and  a.component_name  = c.component_name
--       and  a.customer_name   = d.customer_name
--       and  a.project_name   = d.project_name
--       and  a.process_name   = d.process_name
--       and  a.component_name  = d.component_name
--       and  a.control_bt_synonym = d.bt_synonym_name
--       and  c.customer_name   = @engg_customer_name
--       and  c.project_name   = @engg_project_name
--       and  c.ecr_no    = @engg_ecr_no
--       and  len(a.bt_synonym_caption) > 60)
--  begin
--
-- --  if exists( select 'x' from
-- --    re_glossary_lng_extn A (nolock)
-- --    where a.customer_name  = @engg_customer_name
-- --    and a.project_name  = @engg_project_name
-- --    and  a.process_name+a.component_name in (select distinct process_name+component_name
-- --     from  re_ui_ecr(nolock)
-- --     where customer_name = @engg_customer_name
-- --     and project_name = @engg_project_name
-- --     and  ecr_no  = @engg_ecr_no)
-- --    and  len(a.bt_synonym_caption) > 60
-- --
-- --   )
-- --
-- --  begin
--   exec engg_error_sp 're_publ_sp_publcrml',1,'BT Synonym Caption Length Cannot Exceed 60 Characters',
--      @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
--      '','','','',@m_errorid output
--   return
-- -- end
--  end

--End of Addition by Shriram V on 22/08/05 for Bug ID : PNR2.0_3616
/*PNR2.0_14640*/
--  update b
--  set  data_type   = c.data_type,
--    length    = c.length,
--    bt_synonym_caption  = c.bt_synonym_caption,
--    modifiedby   = @ctxt_user,
--    modifieddate   = @date ,
--    ref_bt_synonym_name  = c.ref_bt_synonym_name ,
--    bt_synonym_doc   = c.bt_synonym_doc,
--    bt_name    = c.bt_name ,
--    synonym_status   = c.synonym_status,
--    singleinst_sample_data = c.singleinst_sample_data,
--    multiinst_sample_data = c.multiinst_sample_data
--  from re_ui_ecr      a (nolock),
--    re_published_glossary_lng_extn  b (nolock),
--    re_glossary_lng_extn   c (nolock)
--  where a.customer_name  = @engg_customer_name
--  and  a.project_name  = @engg_project_name
--  and  a.ecr_no   = @engg_ecr_no
--
--  and  b.customer_name  = a.customer_name
--  and  b.project_name  = a.project_name
--  and  b.ecr_no   = a.ecr_no
--  and  b.component_name = a.component_name
--
--  and  c.customer_name  = b.customer_name
--  and  c.project_name  = b.project_name
--  and  c.process_name  = b.process_name
--  and  c.component_name = b.component_name
--  and  c.bt_synonym_name = b.bt_synonym_name
--  and  c.languageid  = b.languageid
/*PNR2.0_14640*/
--Commented for Multilang testing starts --13578
--insert into re_published_glossary_lng_extn(
--customer_name,project_name,ecr_no,process_name,component_name,
--bt_synonym_name,data_type,length,bt_synonym_caption,glossary_sysid,timestamp,
--createdby,createddate,modifiedby,modifieddate,ref_bt_synonym_name,bt_synonym_doc,
--bt_name,synonym_status, singleinst_sample_data , multiinst_sample_data,languageid)
--select distinct
--@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,b.component_name,
--b.bt_synonym_name,b.data_type,length,b.bt_synonym_caption,left(a.ecr_no+b.bt_synonym_name+a.component_name,40),
--1,@ctxt_user,@date,@ctxt_user,@date,b.ref_bt_synonym_name,b.bt_synonym_doc,
--b.bt_name,b.synonym_status, singleinst_sample_data , multiinst_sample_data , languageid
--from  re_ui_ecr    a (nolock),
--re_glossary_lng_extn     b (nolock)
--where  a.customer_name  = @engg_customer_name
--and  a.project_name  = @engg_project_name
--and  a.ecr_no  = @engg_ecr_no

--and  b.customer_name  = a.customer_name
--and  b.project_name  = a.project_name
--and  b.process_name  = a.process_name
--and  b.component_name = a.component_name
--and  not exists ( select 's'
--from re_published_glossary_lng_extn c (nolock)
--where c.customer_name  = b.customer_name
--and  c.project_name  = b.project_name
--and  c.ecr_no   = @engg_ecr_no
--and  c.process_name  = b.process_name
--and  c.component_name = b.component_name
--and  c.bt_synonym_name = b.bt_synonym_name
--and  c.languageid  = b.languageid)  --Commented for Multilang testing ends


--MESSAGE
insert into re_published_message(
customer_name,project_name,ecr_no,
process_name,component_name,error_id,
error_descr,message_sysid,timestamp,
createdby,createddate,modifiedby,
modifieddate,error_serverity)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.error_id,
b.error_descr,
newid(),
1,
@ctxt_user,@date,@ctxt_user,
@date,b.error_serverity
from re_message b(nolock)
where b.customer_name  = rtrim(@engg_customer_name)
and  b.project_name  = rtrim(@engg_project_name)
and     b.component_name in ( select component_name
from re_ui_ecr(nolock)
where customer_name = rtrim(@engg_customer_name)
and project_name = rtrim(@engg_project_name)
and ecr_no  = rtrim(@engg_ecr_no)
)

--BUSINESS RULE
insert into re_published_business_rule(
customer_name,project_name,ecr_no,
process_name,component_name,br_name,
br_descr,rule_sysid,timestamp,
createdby,createddate,modifiedby,
modifieddate,br_doc)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.br_name,
b.br_descr,
newid(),
1,
@ctxt_user,@date,@ctxt_user,
@date,b.br_doc
from re_business_rule b(nolock)
where b.customer_name  = rtrim(@engg_customer_name)
and  b.project_name  = rtrim(@engg_project_name)
and     b.component_name        in ( select component_name
from re_ui_ecr(nolock)
where customer_name = rtrim(@engg_customer_name)
and project_name = rtrim(@engg_project_name)
and ecr_no  = rtrim(@engg_ecr_no)
)

--RULE GROUP
insert into re_published_rulegroup(
customer_name,project_name,ecr_no,
process_name,component_name,brgroup_name,
brgroup_descr,exposed_flag,brgroup_sysid,
timestamp,createdby,createddate,
modifiedby,modifieddate,ref_brgroup_name,
brgroup_doc)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.brgroup_name,
b.brgroup_descr,b.exposed_flag,
newid(),
1,@ctxt_user,@date,
@ctxt_user,@date,b.ref_brgroup_name,
b.brgroup_doc
from re_rulegroup b(nolock)
where b.customer_name  = rtrim(@engg_customer_name)
and  b.project_name  = rtrim(@engg_project_name)
and  component_name in ( select component_name
from re_ui_ecr(nolock)
where customer_name = rtrim(@engg_customer_name)
and project_name = rtrim(@engg_project_name)
and ecr_no  = rtrim(@engg_ecr_no)
)


--RULEGROUP STEP
insert into re_published_rulegroup_step(
customer_name,project_name,ecr_no,
process_name,component_name,brgroup_name,
step_id,br_name,step_no,
step_sysid,brgroup_sysid,timestamp,
createdby,createddate,modifiedby,
modifieddate)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.brgroup_name,
b.step_id,b.br_name,b.step_no,
newid(),newid(),
1,
@ctxt_user,@date,@ctxt_user,
@date
from re_rulegroup_step b(nolock)
where b.customer_name  = rtrim(@engg_customer_name)
and  b.project_name  = rtrim(@engg_project_name)
and  b.component_name in  ( select component_name
from re_ui_ecr(nolock)
where customer_name = rtrim(@engg_customer_name)
and project_name = rtrim(@engg_project_name)
and ecr_no  = rtrim(@engg_ecr_no)
)

-- RULEGROUP_STEP_MSG
insert into re_published_rulegroup_step_msg(
customer_name,project_name,ecr_no,
process_name,component_name,brgroup_name,
step_id,message_id,message_descr,
msg_severity,default_flag,msg_sysid,
step_sysid,timestamp,createdby,
createddate,modifiedby,modifieddate)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.brgroup_name,
b.step_id,b.message_id,b.message_descr,
b.msg_severity,b.default_flag,
newid(),newid(),
1,@ctxt_user,
@date,@ctxt_user,@date
from re_rulegroup_step_msg b(nolock)
where b.customer_name  = rtrim(@engg_customer_name)
and  b.project_name  = rtrim(@engg_project_name)
and  b.component_name in  ( select component_name
from re_ui_ecr(nolock)
where customer_name = rtrim(@engg_customer_name)
and project_name = rtrim(@engg_project_name)
and ecr_no  = rtrim(@engg_ecr_no)
)

--PUBLICATION DATAITEM
insert into re_published_publication_dataitem(
customer_name,project_name,ecr_no,
process_name,component_name,activity_name,
ui_name,page_bt_synonym,publication_name,
published_bt_synonym,published_control_name,published_view_name,
published_flow_direction,publication_dataitem_sysid,
publication_sysid,createdby,createddate,
modifiedby,modifieddate,timestamp,dataitemname)

select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,
b.ui_name,b.page_bt_synonym,b.publication_name,
b.published_bt_synonym,b.published_control_name,b.published_view_name,
b.published_flow_direction,
newid(),newid(),@ctxt_user,@date,
@ctxt_user,@date,1,dataitemname
from re_ui_ecr a(nolock),
re_publication_dataitem b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--PUBLICATION
insert into re_published_publication(
customer_name,project_name,ecr_no,process_name,
component_name,activity_name,ui_name,
publication_name,publication_descr,publication_doc,
publication_sysid,createdby,createddate,
modifiedby,modifieddate,timestamp)
select @engg_customer_name,@engg_project_name,@engg_ecr_no,
b.process_name,b.component_name,b.activity_name,b.ui_name,
b.publication_name,b.publication_descr,b.publication_doc,
newid(),@ctxt_user,@date,
@ctxt_user,@date,1
from re_ui_ecr a(nolock),
re_publication b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

-- code removed by shafina on 08-Feb-2005 for ECENG203ACC_000097 (To remove unwanted tables from code.)
--RESOLVED LINK
insert into re_published_resolved_link_dataitem(
customer_name,project_name,ecr_no,process_name,
component_name,activity_name,ui_name,page_bt_synonym,
subscription_name,subscribed_bt_synonym,publication_comp_name,
publication_act_name,publication_ui_name,publication_name,
published_bt_synonym,subscribed_control_name,subscribed_view_name,
subscribed_flow_direction,published_control_name,published_view_name,
published_flow_direction,resolved_link_dataitem_sysid,
resolved_link_sysid,createdby,createddate,
modifiedby,modifieddate,timestamp,dataitemname)

select
@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,
b.component_name,b.activity_name,b.ui_name,page_bt_synonym,
b.subscription_name,b.subscribed_bt_synonym,b.publication_comp_name,
b.publication_act_name,b.publication_ui_name,b.publication_name,
b.published_bt_synonym,b.subscribed_control_name,b.subscribed_view_name,
b.subscribed_flow_direction,b.published_control_name,b.published_view_name,
b.published_flow_direction,
newid(),newid(),@ctxt_user,@date,
@ctxt_user,@date,1,dataitemname
from re_ui_ecr a(nolock),
re_resolved_link_dataitem b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--RESOLVED LINK
insert into re_published_resolved_link
(customer_name,project_name,ecr_no,process_name,
component_name,activity_name,ui_name,subscription_name,
publication_comp_name,publication_act_name,publication_ui_name,
publication_name,resolved_link_sysid,createdby,createddate,modifiedby,
modifieddate,timestamp,post_task,post_linktask)   --Column added  for PNR2.0_30869 
select
@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,
b.component_name,b.activity_name,b.ui_name,b.subscription_name,
b.publication_comp_name,b.publication_act_name,b.publication_ui_name,
b.publication_name, newid(),@ctxt_user,@date,@ctxt_user,
@date,1,post_task,b.post_linktask				--Column added  for PNR2.0_30869 
from re_ui_ecr   a (nolock),
re_resolved_link b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--SUBSCRIPTION DATAITEM
insert into re_published_subscription_dataitem
(customer_name,project_name,ecr_no,process_name,
component_name,activity_name,ui_name,page_bt_synonym,
subscription_name,subscribed_bt_synonym,subscribed_control_name,
subscribed_view_name,subscribed_flow_direction,subscription_dataitem_sysid,
subscription_sysid,createdby,createddate,
modifiedby,modifieddate,timestamp,Qlik_dataitem)--vwqlik_change
select
@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,
b.component_name,b.activity_name,b.ui_name,b.page_bt_synonym,
b.subscription_name,b.subscribed_bt_synonym,b.subscribed_control_name,
b.subscribed_view_name,b.subscribed_flow_direction,
newid(),newid(),@ctxt_user,@date,@ctxt_user,@date,1,Qlik_dataitem--vwqlik_change
from re_ui_ecr a(nolock),
re_subscription_dataitem b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name

--SUBSCRIPTION
insert into re_published_subscription
(customer_name,project_name,ecr_no,process_name,
component_name,activity_name,ui_name,page_bt_synonym,
subscription_name,subscription_descr,control_bt_synonym,
link_type,sugg_publishing_comp_name,sugg_publishing_act_name,
sugg_publishing_ui_name,subscription_doc,subscription_sysid,
createdby,createddate,modifiedby,modifieddate,timestamp,post_task,
post_linktask)				--Column added  for PNR2.0_30869 
select
@engg_customer_name,@engg_project_name,@engg_ecr_no,b.process_name,
b.component_name,b.activity_name,b.ui_name,page_bt_synonym,
b.subscription_name,b.subscription_descr,b.control_bt_synonym,
b.link_type,b.sugg_publishing_comp_name,b.sugg_publishing_act_name,
b.sugg_publishing_ui_name,b.subscription_doc,
newid(), @ctxt_user,@date,@ctxt_user,@date,1,post_task,
post_linktask					--Column added  for PNR2.0_30869 
from re_ui_ecr a(nolock),
re_subscription b(nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name



insert into re_published_sync_view
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
legrid_control_bt_syonym,legrid_control_id,legrid_view_name,map_le_synonym,map_le_column_synonym,map_le_controlid,map_le_viewname,map_legrid_view_name,
createdby,created_date,modifiedby,modifieddate,legrid_column_bt_synonym,map_legrid_column_bt_synonym)
Select 
a.customer_name,a.project_name,@engg_ecr_no,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.legrid_control_bt_syonym,
a.legrid_control_id,a.legrid_view_name,a.map_le_synonym,a.map_le_column_synonym,a.map_le_controlid,a.map_le_viewname,a.map_legrid_view_name,
@ctxt_user,GETDATE(),@ctxt_user,GETDATE(),legrid_column_bt_synonym,map_legrid_column_bt_synonym
from re_sync_view a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name


insert into re_published_nativeapp_mapping (customer_name,project_name,process_name,component_name,
activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_Hidden_bt_synonym,MappedGridColumnSynonym,
rcnno,control_id,View_name,GridControlID,GridViewName,control_hiddenview,timestamp,createdby,createddate,modifiedby,modifieddate)

select a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,a.page_bt_synonym,
a.section_bt_synonym,a.control_Hidden_bt_synonym,a.MappedGridColumnSynonym,@engg_ecr_no,a.control_id,a.View_name,
a.GridControlID,a.GridViewName,a.control_hiddenview,a.timestamp,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()
from re_nativeapp_mapping a(nolock),
re_ui_ecr b(nolock)
where b.customer_name	= @engg_customer_name
and  b.project_name		= @engg_project_name
and	 b.ECR_no			= @engg_ecr_no
and  a.customer_name	= b.customer_name
and  a.project_name		= b.project_name
and  a.process_name		= b.process_name
and  a.component_name	= b.component_name
and  a.activity_name	= b.activity_name
and  a.ui_name			= b.ui_name



--NEW COLUMNS (CONTROL_ID,VIEW_NAME,EVENT_NAME,MAP_FLAG) ADDED BY DNR ON 31/03/2004
/* insert into re_published_flowbr
(customer_name,project_name,ecr_no,process_name,component_name,activity_name,ui_name,
page_bt_synonym,task_name,flowbr_name,flowbr_descr,flowbr_sequence,flowbr_sysid,task_sysid,timestamp,
createdby,createddate,modifiedby,modifieddate,control_id,view_name,event_name,map_flag)
select
b.customer_name,b.project_name,@engg_ecr_no,b.process_name,b.component_name,b.activity_name,b.ui_name,
b.page_bt_synonym,b.task_name,b.flowbr_name,b.flowbr_descr,b.flowbr_sequence,b.flowbr_sysid,b.task_sysid,b.timestamp,
b.createdby,b.createddate,b.modifiedby,b.modifieddate,b.control_id,b.view_name,b.event_name,b.map_flag
from re_ui_ecr a ,re_flowbr b( nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name */


/* CODE MODIFIED BY KRISHNA PRIYA  ON 16/4/04  FOR
BUG ID   ECENG203SYS_000001  &  ECENG203ACC_000004  */


/* code modified by padmapriya on 18/04/04 for bugid :REENG203ACC_000060
datas are not properly inserted in re_published_flowbr table  */


--  declare  flowbr_cur
--  insensitive cursor
--  for
--  select a.process_name,   a.component_name,   a.activity_name,   a.ui_name ,
--    a.page_bt_synonym,  a.task_name,    a.flowbr_name,    a.flowbr_descr,
--    a.flowbr_sequence,  a.map_flag,     a.control_id,    a. view_name,
--    a.event_name
--  from re_flowbr  a (nolock),
--    re_ui_ecr  b (nolock)
--  where a.customer_name  = @engg_customer_name
--  and  a.project_name  = @engg_project_name
--   and  b.ecr_no   = @engg_ecr_no
--     and  a.customer_name  = b.customer_name
--  and  a.project_name  = b.project_name
--  and  a.process_name  = b.process_name
--  and  a.component_name = b.component_name
--  and  a.activity_name  = b.activity_name
--  and  a.ui_name   = b.ui_name
--
--      open flowbr_cur
--
--      while 1 = 1
--      begin
--
--   fetch next
--   from flowbr_cur
--   into @proc_name,   @comp_name,   @act_name,   @ui_name,
--     @flow_page,   @flow_task_name, @flowbr_name,  @flowbr_descr,
--     @flowbr_sequence, @control_id,  @view_name,   @event_name,
--     @map_flag
--
--   if @@fetch_status <> 0
--    break
--
--      if exists (
--       select 'x'
--      from     re_published_flowbr (nolock)
--      where  customer_name       = @engg_customer_name
--  and     project_name  =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--       and     component_name      =   @comp_name
--       and     activity_name          =    @act_name
--       and     ui_name                  =   @ui_name
--       and     page_bt_synonym    =   @flow_page
--       and     task_name             =    @flow_task_name
--       and     flowbr_name           =   @flowbr_name
--       and     flowbr_descr           =   @flowbr_descr
--       and     flowbr_sequence      =  @flowbr_sequence
--       and     control_id               =   @control_id
--       and     view_name              =  @view_name
--       and     event_name            =   @event_name
--       and     map_flag                =   @map_flag
--        )
--     begin
--      update re_published_flowbr
--      set   status_flag = 'S',
-- -- code added by shafina on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)
--    modifiedby = @ctxt_user,
--    modifieddate= @date
--      where  customer_name = @engg_customer_name
--  and     project_name        =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--       and     component_name      =   @comp_name
--       and     activity_name          =    @act_name
--       and     ui_name                  =   @ui_name
--       and     page_bt_synonym     =   @flow_page
--       and     task_name               =    @flow_task_name
--       and     flowbr_name             =   @flowbr_name
--    end
--     else if exists (
--      select 'x'
--      from re_published_flowbr (nolock)
--      where  customer_name       = @engg_customer_name
--  and     project_name        =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--     and     component_name      =   @comp_name
--       and     activity_name          =    @act_name
--       and     ui_name                  =   @ui_name
--       and     page_bt_synonym     =   @flow_page
--       and     task_name               =    @flow_task_name
--       and     flowbr_name             =   @flowbr_name
--       and  (isnull(flowbr_descr,'')    <>  isnull(@flowbr_descr,'')
--        or  isnull(flowbr_sequence,'') <>  isnull(@flowbr_sequence,'')
--        or  isnull(control_id,'')          <>  isnull(@control_id,'')
--   or  isnull(view_name,'')         <>  isnull(@view_name,'')
--        or  isnull(event_name,'')       <>  isnull(@event_name,'')
--        or  isnull(map_flag,'')           <>  isnull(@map_flag,''))
--        )
--        begin
--        update re_published_flowbr
--        set  status_flag   = 'U',
--        flowbr_descr  = @flowbr_descr,
--        flowbr_sequence  = @flowbr_sequence,
--        control_id   = @control_id,
--        view_name   = @view_name,
--        event_name   = @event_name,
--        map_flag   = @map_flag ,
--     modifiedby = @ctxt_user,
--     modifieddate = @date
--       where  customer_name       = @engg_customer_name
--  and     project_name        =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--       and     component_name      =   @comp_name
--       and     activity_name          =    @act_name
--       and     ui_name                  =   @ui_name
--       and     page_bt_synonym     =   @flow_page
--       and     task_name               =    @flow_task_name
--       and     flowbr_name             =   @flowbr_name
--      end
--        else if not exists (
--        select 'x'
--        from re_published_flowbr (nolock)
--        where  customer_name       = @engg_customer_name
--  and     project_name        =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--       and     component_name      =   @comp_name
--       and     activity_name          =    @act_name
--       and     ui_name                  =   @ui_name
--       and     page_bt_synonym     =  @flow_page
--       and     task_name               =    @flow_task_name
--       and     flowbr_name             =   @flowbr_name
--       )
--       begin
--
--      insert into re_published_flowbr
--  ( customer_name,project_name,ecr_no,process_name,
--        component_name,activity_name,ui_name,page_bt_synonym,
--        task_name,flowbr_name,flowbr_descr,flowbr_sequence,
--        flowbr_sysid,
--   task_sysid,timestamp, createdby,createddate,
--        modifiedby,modifieddate,control_id,view_name,event_name,map_flag,status_flag)
--  select
--    customer_name,project_name,@engg_ecr_no,process_name,
--        component_name,  activity_name,ui_name,page_bt_synonym,
--        task_name,flowbr_name,  flowbr_descr,  flowbr_sequence,
--       newid(),
-- --  task_sysid,
-- /*code changed by vijay on 11 may 04for the Bug id ECENG203ACC_000017*/
--  newid(),
--  1,@ctxt_user, @date,@ctxt_user,
--       @date,control_id,view_name,
--       event_name, map_flag,'I'
--      from re_flowbr (nolock)
--      where  customer_name       = @engg_customer_name
--  and     project_name        =  @engg_project_name
-- --  and     ecr_no               = @engg_ecr_no
--       and     process_name          =    @proc_name
--       and     component_name      =   @comp_name
--       and     activity_name           =    @act_name
--       and     ui_name                   =   @ui_name
--       and     page_bt_synonym  =   @flow_page
--       and     task_name               =    @flow_task_name
--       and     flowbr_name             =   @flowbr_name
--        end
--        end
--         close flowbr_cur
--        deallocate flowbr_cur
--
--
--       update re_published_flowbr
--       set    status_flag = 'D'  ,
--    modifiedby  = @ctxt_user,
--    modifieddate = @date
--        where  customer_name       = @engg_customer_name
--  and     project_name        =  @engg_project_name
--  and     ecr_no               = @engg_ecr_no
--
--       and     flowbr_name     not in (select flowbr_name
--                                       from re_flowbr (nolock)
--                                       where  customer_name       = @engg_customer_name
--        and     project_name        =  @engg_project_name
--        )

/* CODE MODIFIED BY KRISHNA PRIYA  ON 16/4/04  FOR
BUG ID   ECENG203SYS_000001  &  ECENG203ACC_000004  */

update  a
set     status_flag  =  'D'  ,
modifiedby   =  @ctxt_user,
modifieddate  =  @date
from re_published_flowbr  a (nolock)
where   customer_name = @engg_customer_name
and     project_name =  @engg_project_name
and     ecr_no         = @engg_ecr_no
and  not exists ( select 's'
from  re_flowbr c(nolock)
where c.customer_name      = a.customer_name
and     c.project_name     =   a.project_name
and     c.process_name     =   a.process_name
and     c.component_name  =   a.component_name
and     c.activity_name      =   a.activity_name
and     c.ui_name            =   a.ui_name
and     c.page_bt_synonym  = a.page_bt_synonym
and     c.task_name    =   a.task_name
and  c.flowbr_name   =  a.flowbr_name)

update a
set  flowbr_descr  = b.flowbr_descr,
flowbr_sequence  = b.flowbr_sequence,
map_flag   = b.map_flag,
control_id   = b.control_id,
view_name   = b.view_name,
event_name   = b.event_name,
modifiedby   = @ctxt_user,
modifieddate  = @date,
status_flag   = 'U'
from re_published_flowbr a (nolock),
re_flowbr   b (nolock)
where a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.ecr_no   = @engg_ecr_no

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
and  b.page_bt_synonym = a.page_bt_synonym
and  b.task_name   = a.task_name
and  b.flowbr_name  = a.flowbr_name

and  ( a.flowbr_descr <> b.flowbr_descr  or
a.flowbr_sequence <> b.flowbr_sequence or
a.map_flag   <> b.map_flag   or
a.control_id  <> b.control_id   or
a.view_name   <> b.view_name   or
a.event_name  <> b.event_name )

insert into re_published_flowbr
(customer_name,   project_name, ecr_no,   process_name, component_name,
activity_name,   ui_name,  page_bt_synonym,task_name,  flowbr_name,
flowbr_descr,   flowbr_sequence,flowbr_sysid, task_sysid,  timestamp,
createdby,    createddate, modifiedby,  modifieddate, map_flag,
control_id,    view_name,  event_name,  status_flag)
select  a.customer_name,  a.project_name, @engg_ecr_no,  a.process_name, a.component_name,
a.activity_name,  a.ui_name,  a.page_bt_synonym,a.task_name, a.flowbr_name,
a.flowbr_descr,   a.flowbr_sequence,newid(),  a.task_sysid, 1,
@ctxt_user,    @date,   @ctxt_user,  @date,   a.map_flag,
a.control_id,   a.view_name, a.event_name, 'I'
from    re_flowbr a (nolock),
re_ui_ecr b (nolock)
where b.customer_name  = @engg_customer_name
and  b.project_name  = @engg_project_name
and  b.ecr_no   = @engg_ecr_no

and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

and  not exists ( select 's'
from  re_published_flowbr c(nolock)
where c.customer_name      = a.customer_name
and     c.project_name     =   a.project_name
and  c.ecr_no    = @engg_ecr_no
and     c.process_name     =   a.process_name
and     c.component_name  =   a.component_name
and     c.activity_name      =   a.activity_name
and     c.ui_name            =   a.ui_name
and     c.page_bt_synonym    =   a.page_bt_synonym
and     c.task_name    =   a.task_name
and  c.flowbr_name   = a.flowbr_name)

update  re_published_flowbr
set     status_flag  =  'S'  ,
modifiedby   =  @ctxt_user,
modifieddate  =  @date
where   customer_name = @engg_customer_name
and     project_name =  @engg_project_name
and     ecr_no         = @engg_ecr_no
and  status_flag  not in ('D'  , 'U', 'I')


update re_ui
set  current_req_no = '',
modifiedby  =  @ctxt_user,
modifieddate =  @date
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  current_req_no = @engg_ecr_no

update re_ui_ecr
set  ui_status  =  'P' ,
modifiedby  =  @ctxt_user,
modifieddate =  @date
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  ecr_no   = @engg_ecr_no

-- code added by shafina on 22-April-2004 for ECENG203ACC_000010
select @m_errorid = 0
exec Rmt_RCN_Publish @engg_customer_name,@engg_project_name,@engg_ecr_no,@m_errorid output


if @m_errorid <> 0
begin
exec engg_error_sp 're_publ_sp_publcrml',1,'Customer ID/Project ID/RCNNumber is blank',
@ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,
'','','','',@m_errorid output
return
end

/*
Delete from re_rcn_publish_chk
where rcn_no		= @engg_ecr_no
and   work_flag		= 'P'
and   customer_name = @engg_customer_name
and   project_name  = @engg_project_name
*/

--code added Savitha on 01-Sep-2005
exec re_published_insert @engg_customer_name,@engg_project_name,@engg_ecr_no


if(@engg_autocomplete='ECR')
begin


exec de_dnld_sp_dnldico @Ctxt_Language,@ctxt_OUInstance,@Ctxt_Service,@ctxt_User,@engg_customer_name,
@ecr_descr,@ecr,@engg_ico_status,@engg_project_name,'Z',
@fprowno,@m_errorid output


exec de_publ_sp_publico @ctxt_language,@ctxt_ouinstance,@ctxt_service,@ctxt_user,@engg_customer_name,
@ecr_descr,@ecr,@engg_project_name,'Z',@fprowno,@m_errorid output

end

			if exists ( select  'x'  -- code added by 11536 for the case id TECH-20631
					from	re_ui_ecr(nolock)  
					where	customer_name		=	@engg_customer_name  
					and		project_name		=	@engg_project_name  
					and		ecr_no				=	rtrim(@engg_ecr_no)  
					and		ui_status			=	'p'
					)  
					begin 
					
						Update	FW_NIA_GenDoc_Rcn_Ecr_ICO_temp 
						set		doc_status			=	'RCNPUB'
						where	Customerid			=	@engg_customer_name
						and		Projectid			=	@engg_project_name
						and		RCNNumber			=	rtrim(@engg_ecr_no) 

					End

if  @engg_ecr_descr not  in ('pubezeeview')     --Code added for PNR2.0_28333
SELECT @fprowno 'fprowno_io'        /* DOTNET Migration Tool Changes */

set nocount off
end
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 're_publ_sp_publcrml' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON re_publ_sp_publcrml TO PUBLIC
END
GO



