/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - de_published_ui_section
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'de_published_ui_section' and type = 'u')
begin
	create table de_published_ui_section
	(activity_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'border_required')
begin
	alter table de_published_ui_section add border_required engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'component_name')
begin
	alter table de_published_ui_section add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'createdby')
begin
	alter table de_published_ui_section add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'createddate')
begin
	alter table de_published_ui_section add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'customer_name')
begin
	alter table de_published_ui_section add customer_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'ecrno')
begin
	alter table de_published_ui_section add ecrno engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'horder')
begin
	alter table de_published_ui_section add horder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'modifiedby')
begin
	alter table de_published_ui_section add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'modifieddate')
begin
	alter table de_published_ui_section add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'page_bt_synonym')
begin
	alter table de_published_ui_section add page_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'page_sysid')
begin
	alter table de_published_ui_section add page_sysid engg_sysid  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'parent_section')
begin
	alter table de_published_ui_section add parent_section engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'process_name')
begin
	alter table de_published_ui_section add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'project_name')
begin
	alter table de_published_ui_section add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_bt_synonym')
begin
	alter table de_published_ui_section add section_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_doc')
begin
	alter table de_published_ui_section add section_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'timestamp')
begin
	alter table de_published_ui_section add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'title_alignment')
begin
	alter table de_published_ui_section add title_alignment engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'title_required')
begin
	alter table de_published_ui_section add title_required engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'ui_name')
begin
	alter table de_published_ui_section add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'ui_section_sysid')
begin
	alter table de_published_ui_section add ui_section_sysid engg_sysid  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'visisble_flag')
begin
	alter table de_published_ui_section add visisble_flag engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'vorder')
begin
	alter table de_published_ui_section add vorder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'width')
begin
	alter table de_published_ui_section add width engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'height')
begin
	alter table de_published_ui_section add height engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_type')
begin
	alter table de_published_ui_section add section_type engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'sectionprefixclass')
begin
	alter table de_published_ui_section add SectionPrefixClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'caption_format')
begin
	alter table de_published_ui_section add caption_Format engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'ctrl_caption_align')
begin
	alter table de_published_ui_section add ctrl_caption_align engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'setion_width_scalemode')
begin
	alter table de_published_ui_section add Setion_width_Scalemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'setion_height_scalemode')
begin
	alter table de_published_ui_section add Setion_height_Scalemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_prefix')
begin
	alter table de_published_ui_section add section_prefix engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'req_no')
begin
	alter table de_published_ui_section add req_no engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'associated_control')
begin
	alter table de_published_ui_section add Associated_control engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'splitter_pos')
begin
	alter table de_published_ui_section add splitter_pos engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'ncolspan')
begin
	alter table de_published_ui_section add NColSpan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'nrowspan')
begin
	alter table de_published_ui_section add NRowSpan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'isstatic')
begin
	alter table de_published_ui_section add IsStatic engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_collapse')
begin
	alter table de_published_ui_section add section_collapse engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'section_collapsemode')
begin
	alter table de_published_ui_section add section_collapsemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'carouselnavigation')
begin
	alter table de_published_ui_section add CarouselNavigation engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'cell_spacing')
begin
	alter table de_published_ui_section add cell_spacing engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'cell_padding')
begin
	alter table de_published_ui_section add cell_padding engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'region')
begin
	alter table de_published_ui_section add Region engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'titleposition')
begin
	alter table de_published_ui_section add TitlePosition engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'collapsedir')
begin
	alter table de_published_ui_section add CollapseDir engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'sectionlayout')
begin
	--alter table de_published_ui_section add SectionLayout engg_flag null
	alter table de_published_ui_section add SectionLayout engg_name null	--TECH-69624
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'xycoordinates')
begin
	alter table de_published_ui_section add XYCoordinates engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'columnlaywidth')
begin
	alter table de_published_ui_section add ColumnLayWidth engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'slidingbar_height')
begin
	alter table de_published_ui_section add Slidingbar_height engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_published_ui_section' and name = 'isplatform')
begin
	alter table de_published_ui_section add IsPlatform engg_flag null
end
go


--Code Added for the Defect id TECH-69624 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderLeftWidth' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderLeftWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderRightWidth' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderRightWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderTopWidth' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderTopWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderBottomWidth' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderBottomWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderLeftColor' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderLeftColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderRightColor' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderRightColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderTopColor' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderTopColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderBottomColor' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderBottomColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderTopLeftRadius' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderTopLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderTopRightRadius' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderTopRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderBottomLeftRadius' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderBottomLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderBottomRightRadius' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderBottomRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BorderStyle' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BorderStyle engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'ForResponsive' )
BEGIN
	ALTER TABLE de_published_ui_section ADD ForResponsive engg_seqno NULL
END
GO
--Code Added for the Defect id TECH-69624 ends

--Tech-70687
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'LeftToolbar' )
BEGIN
	ALTER TABLE de_published_ui_section ADD LeftToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'RightToolbar' )
BEGIN
	ALTER TABLE de_published_ui_section ADD RightToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'TopToolbar' )
BEGIN
	ALTER TABLE de_published_ui_section ADD TopToolbar engg_flag NULL
END
GO


IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'BottomToolbar' )
BEGIN
	ALTER TABLE de_published_ui_section ADD BottomToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'MinimizedRows' )
BEGIN
	ALTER TABLE de_published_ui_section ADD MinimizedRows engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'ViewMode' )
BEGIN
	ALTER TABLE de_published_ui_section ADD ViewMode engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'HasTitleAction' )
BEGIN
	ALTER TABLE de_published_ui_section ADD HasTitleAction engg_flag NULL
END
GO
--Tech-70687

--code added for defectid Tech-72114 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_section' AND NAME = 'TitleIcon' )
BEGIN
	ALTER TABLE de_published_ui_section ADD TitleIcon engg_name NULL
END
GO
--code added for defectid Tech-72114 ends

--Code Added for TECH-75230 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_ui_Section' AND NAME = 'Orientation' )
BEGIN
	ALTER TABLE de_published_ui_Section ADD Orientation engg_name NULL
END
GO
--Code Added for TECH-75230 ends
