/********************************************************************************
Created By 		Ponmalar A
Created Date 	17 Aug 2022
********************************************************************************/

IF NOT EXISTS ( SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_task_gql_report_param' AND TYPE = 'U' )
BEGIN
	CREATE TABLE de_published_task_gql_report_param 	(CustomerName engg_name  NOT  NULL )
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ProjectName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ProjectName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'DocNo' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD DocNo engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ProcessName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ProcessName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ComponentName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ComponentName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ActivityName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ActivityName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'UIName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD UIName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'TaskName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD TaskName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ReportName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ReportName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ParameterName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ParameterName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'BTSynonym' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD BTSynonym engg_name  NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ControlID' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ControlID engg_name  NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ViewName' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ViewName engg_name  NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'DefaultValue' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD DefaultValue engg_name  NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'TimeStamp' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD TimeStamp engg_timestamp NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'CreatedBy' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD CreatedBy engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'CreatedDate' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD CreatedDate engg_date NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ModifiedBy' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ModifiedBy engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_published_task_gql_report_param' AND NAME = 'ModifiedDate' )
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD ModifiedDate engg_date NOT NULL
END
GO