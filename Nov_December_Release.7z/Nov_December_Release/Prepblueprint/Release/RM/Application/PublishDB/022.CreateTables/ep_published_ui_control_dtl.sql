/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - ep_published_ui_control_dtl
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'ep_published_ui_control_dtl' and type = 'u')
begin
	create table ep_published_ui_control_dtl
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'project_name')
begin
	alter table ep_published_ui_control_dtl add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'req_no')
begin
	alter table ep_published_ui_control_dtl add req_no engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'process_name')
begin
	alter table ep_published_ui_control_dtl add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'component_name')
begin
	alter table ep_published_ui_control_dtl add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'activity_name')
begin
	alter table ep_published_ui_control_dtl add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'ui_name')
begin
	alter table ep_published_ui_control_dtl add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'page_bt_synonym')
begin
	alter table ep_published_ui_control_dtl add page_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'section_bt_synonym')
begin
	alter table ep_published_ui_control_dtl add section_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_bt_synonym')
begin
	alter table ep_published_ui_control_dtl add control_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_type')
begin
	alter table ep_published_ui_control_dtl add control_type engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'horder')
begin
	alter table ep_published_ui_control_dtl add horder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'vorder')
begin
	alter table ep_published_ui_control_dtl add vorder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'order_seq')
begin
	alter table ep_published_ui_control_dtl add order_seq engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'data_column_width')
begin
	alter table ep_published_ui_control_dtl add data_column_width engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'label_column_width')
begin
	alter table ep_published_ui_control_dtl add label_column_width engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'ui_control_sysid')
begin
	alter table ep_published_ui_control_dtl add ui_control_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'ui_section_sysid')
begin
	alter table ep_published_ui_control_dtl add ui_section_sysid engg_sysid  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'timestamp')
begin
	alter table ep_published_ui_control_dtl add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'createdby')
begin
	alter table ep_published_ui_control_dtl add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'createddate')
begin
	alter table ep_published_ui_control_dtl add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'modifiedby')
begin
	alter table ep_published_ui_control_dtl add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'modifieddate')
begin
	alter table ep_published_ui_control_dtl add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_id')
begin
	alter table ep_published_ui_control_dtl add control_id engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'view_name')
begin
	alter table ep_published_ui_control_dtl add view_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'visisble_length')
begin
	alter table ep_published_ui_control_dtl add visisble_length engg_length null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'proto_tooltip')
begin
	alter table ep_published_ui_control_dtl add proto_tooltip engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'sample_data')
begin
	alter table ep_published_ui_control_dtl add sample_data engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_doc')
begin
	alter table ep_published_ui_control_dtl add control_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_prefix')
begin
	alter table ep_published_ui_control_dtl add control_prefix engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'label_column_scalemode')
begin
	alter table ep_published_ui_control_dtl add label_column_scalemode engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'data_column_scalemode')
begin
	alter table ep_published_ui_control_dtl add data_column_scalemode engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'tab_seq')
begin
	alter table ep_published_ui_control_dtl add tab_seq engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'help_tabstop')
begin
	alter table ep_published_ui_control_dtl add help_tabstop engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'labelclass')
begin
	alter table ep_published_ui_control_dtl add LabelClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'controlclass')
begin
	alter table ep_published_ui_control_dtl add ControlClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'labelimageclass')
begin
	alter table ep_published_ui_control_dtl add LabelImageClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'controlimageclass')
begin
	alter table ep_published_ui_control_dtl add ControlImageClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'accesskey')
begin
	alter table ep_published_ui_control_dtl add AccessKey engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'set_user_pref')
begin
	alter table ep_published_ui_control_dtl add Set_User_Pref engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'freezecount')
begin
	alter table ep_published_ui_control_dtl add freezecount engg_rowno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'controlimage')
begin
	alter table ep_published_ui_control_dtl add controlimage engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'colspan')
begin
	alter table ep_published_ui_control_dtl add colspan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'rowspan')
begin
	alter table ep_published_ui_control_dtl add rowspan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'templateid')
begin
	alter table ep_published_ui_control_dtl add TemplateID engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'preserve_visible_length')
begin
	alter table ep_published_ui_control_dtl add Preserve_visible_length engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'auto_width_column')
begin
	alter table ep_published_ui_control_dtl add Auto_width_column engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'templatecategory')
begin
	alter table ep_published_ui_control_dtl add TemplateCategory engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'templatespecific')
begin
	alter table ep_published_ui_control_dtl add TemplateSpecific engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'control_class_ext6')
begin
	alter table ep_published_ui_control_dtl add Control_class_ext6 engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'icon_position')
begin
	alter table ep_published_ui_control_dtl add icon_position engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'icon_class')
begin
	alter table ep_published_ui_control_dtl add icon_class engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'sensitivedata')
begin
	alter table ep_published_ui_control_dtl add sensitivedata engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'isplatform')
begin
	alter table ep_published_ui_control_dtl add IsPlatform engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'dynamicstyle')
begin
	alter table ep_published_ui_control_dtl add DynamicStyle engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_published_ui_control_dtl' and name = 'imageasdata')
begin
	alter table ep_published_ui_control_dtl add ImageAsData engg_flag null
end
go


IF NOT EXISTS(SELECT 'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 'ep_published_ui_control_dtl' AND NAME = 'MoreEventEnabled')
BEGIN
ALTER TABLE ep_published_ui_control_dtl ADD MoreEventEnabled engg_flag null
end
go

IF NOT EXISTS(SELECT 'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 'ep_published_ui_control_dtl' AND NAME = 'UpeSetFocusEnabled')
BEGIN
ALTER TABLE ep_published_ui_control_dtl ADD UpeSetFocusEnabled engg_flag null
end
go

--Code added against the DefectId-TECH-60451 Starts
IF NOT EXISTS(SELECT 'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 'ep_published_ui_control_dtl' AND NAME = 'ExtensionReqd')
BEGIN
ALTER TABLE ep_published_ui_control_dtl ADD ExtensionReqd engg_flag NULL
END
GO

IF NOT EXISTS(SELECT 'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 'ep_published_ui_control_dtl' AND NAME = 'ExtensionLaunchMode')
BEGIN
ALTER TABLE ep_published_ui_control_dtl ADD ExtensionLaunchMode engg_name NULL
END
GO
--Code added against the DefectId-TECH-60451 Ends

--code added for the defect id : TECH-63527 starts

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'AssociateControl' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl  ADD AssociateControl  engg_name   NULL
END
GO

--code added for the defect id : TECH-63527 ends

--Code Added for the Defect id TECH-69624 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderLeftWidth' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderLeftWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderRightWidth' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderRightWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderTopWidth' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderTopWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderBottomWidth' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderBottomWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderLeftColor' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderLeftColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderRightColor' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderRightColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderTopColor' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderTopColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderBottomColor' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderBottomColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderTopLeftRadius' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderTopLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderTopRightRadius' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderTopRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderBottomLeftRadius' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderBottomLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderBottomRightRadius' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderBottomRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'BorderStyle' )
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD BorderStyle engg_name NULL
END
GO

--Code Added for the Defect id TECH-69624 ends

--Code Added for the Defect Id TECH-72114 Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_published_ui_control_dtl' AND NAME = 'ControlFormat')
BEGIN
	ALTER TABLE ep_published_ui_control_dtl ADD ControlFormat engg_flag NULL
END
GO
--Code Added for the Defect Id TECH-72114 Ends

--Code Added for TECH-75230 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_Published_ui_Control_dtl' AND NAME = 'ButtonNature' )
BEGIN
	ALTER TABLE ep_Published_ui_Control_dtl ADD ButtonNature engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_Published_ui_Control_dtl' AND NAME = 'InlineStyle' )
BEGIN
	ALTER TABLE ep_Published_ui_Control_dtl ADD InlineStyle Engg_Nvarchar_Max NULL
END
GO
--Code Added for TECH-75230 ends