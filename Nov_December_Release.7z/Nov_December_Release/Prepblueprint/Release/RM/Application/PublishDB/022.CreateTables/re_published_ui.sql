/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - re_published_ui
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 're_published_ui' and type = 'u')
begin
	create table re_published_ui
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'project_name')
begin
	alter table re_published_ui add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ecr_no')
begin
	alter table re_published_ui add ecr_no engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'process_name')
begin
	alter table re_published_ui add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'component_name')
begin
	alter table re_published_ui add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'activity_name')
begin
	alter table re_published_ui add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_name')
begin
	alter table re_published_ui add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_descr')
begin
	alter table re_published_ui add ui_descr engg_description  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_type')
begin
	alter table re_published_ui add ui_type engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_format')
begin
	alter table re_published_ui add ui_format engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'caption_alignment')
begin
	alter table re_published_ui add caption_alignment engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'trail_bar')
begin
	alter table re_published_ui add trail_bar engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tab_height')
begin
	alter table re_published_ui add tab_height engg_length  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_sysid')
begin
	alter table re_published_ui add ui_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'timestamp')
begin
	alter table re_published_ui add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'createdby')
begin
	alter table re_published_ui add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'createddate')
begin
	alter table re_published_ui add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'modifiedby')
begin
	alter table re_published_ui add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'modifieddate')
begin
	alter table re_published_ui add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_doc')
begin
	alter table re_published_ui add ui_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'base_component_name')
begin
	alter table re_published_ui add base_component_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'base_activity_name')
begin
	alter table re_published_ui add base_activity_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'base_ui_name')
begin
	alter table re_published_ui add base_ui_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'grid_type')
begin
	alter table re_published_ui add grid_type engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'state_processing')
begin
	alter table re_published_ui add state_processing engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'callout_type')
begin
	alter table re_published_ui add callout_type engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'taskpane_req')
begin
	alter table re_published_ui add taskpane_req engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'new_line_ui')
begin
	alter table re_published_ui add New_Line_Ui engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tab_type')
begin
	alter table re_published_ui add Tab_Type engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tabposition')
begin
	alter table re_published_ui add TabPosition engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'postlaunchtask')
begin
	alter table re_published_ui add PostLaunchTask engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'smarthide')
begin
	alter table re_published_ui add SmartHide engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'is_device')
begin
	alter table re_published_ui add Is_device engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'hideilbotitlemenu_req')
begin
	alter table re_published_ui add HideIlbotitlemenu_req engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'personalization')
begin
	alter table re_published_ui add personalization engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'exclude_systemtabindex')
begin
	alter table re_published_ui add Exclude_Systemtabindex engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'devicetype')
begin
	alter table re_published_ui add DeviceType engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tabstyle')
begin
	alter table re_published_ui add TabStyle engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'isdesktop')
begin
	alter table re_published_ui add IsDesktop engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'hide_print')
begin
	alter table re_published_ui add Hide_Print engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'layout')
begin
	alter table re_published_ui add Layout engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'xycoordinates')
begin
	alter table re_published_ui add XYCoordinates engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'columnlaywidth')
begin
	alter table re_published_ui add ColumnLayWidth engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tabheaderpostion')
begin
	alter table re_published_ui add TabHeaderPostion engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'tabrotation')
begin
	alter table re_published_ui add TabRotation engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'hide_imp_defaults')
begin
	alter table re_published_ui add hide_imp_defaults engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'ui_subtype')
begin
	alter table re_published_ui add ui_subtype engg_doc_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'dbname')
begin
	alter table re_published_ui add DBName engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'isglance')
begin
	alter table re_published_ui add IsGlance engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'nativeapplication')
begin
	alter table re_published_ui add NativeApplication engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'conditional_popupclose')
begin
	alter table re_published_ui add Conditional_popupclose engg_flag null
end
go

if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_published_ui' and name = 'Titlebar_Search')
begin
	alter table re_published_ui add Titlebar_Search engg_flag null
end
go

---Code added for DefectId TECH-70687 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'Sidebar' )
BEGIN
	ALTER TABLE re_published_ui ADD Sidebar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'Docked' )
BEGIN
	ALTER TABLE re_published_ui ADD Docked engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'LeftToolbar' )
BEGIN
	ALTER TABLE re_published_ui ADD LeftToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'RightToolbar' )
BEGIN
	ALTER TABLE re_published_ui ADD RightToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'TopToolbar' )
BEGIN
	ALTER TABLE re_published_ui ADD TopToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'BottomToolbar' )
BEGIN
	ALTER TABLE re_published_ui ADD BottomToolbar engg_flag NULL
END
GO
---Code added for DefectId TECH-70687 ends

--Code Added for the Defect Id Tech-72114 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'TemplateJSON')
BEGIN
	ALTER TABLE re_published_ui ADD TemplateJSON ENGG_NVARCHAR_MAX NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'StyleSheet')
BEGIN
	ALTER TABLE re_published_ui ADD StyleSheet ENGG_NVARCHAR_MAX NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'ConfigurationXML')
BEGIN
	ALTER TABLE re_published_ui ADD ConfigurationXML ENGG_NVARCHAR_MAX NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'TemplateJSONDBC')
BEGIN
	ALTER TABLE re_published_ui ADD TemplateJSONDBC ENGG_NVARCHAR_MAX NULL
END

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'StyleSheetDBC')
BEGIN
	ALTER TABLE re_published_ui ADD StyleSheetDBC ENGG_NVARCHAR_MAX NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'ConfigurationXMLDBC')
BEGIN
	ALTER TABLE re_published_ui ADD ConfigurationXMLDBC ENGG_NVARCHAR_MAX NULL
END
GO
--Code Added for the Defect Id Tech-72114 ends

--Code Added for TECH-75230 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_published_ui' AND NAME = 'PullToRefresh')
BEGIN
	ALTER TABLE re_published_ui ADD PullToRefresh engg_flag NULL
END
GO
--Code Added for TECH-75230 ends