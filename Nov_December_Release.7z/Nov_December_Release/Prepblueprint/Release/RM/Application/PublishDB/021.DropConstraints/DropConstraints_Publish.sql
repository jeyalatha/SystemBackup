/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		For Droping Constraints
********************************************************************************/

if exists(select 'x' from sysobjects where name = 'avs_published_comp_bt_val_pkey')
begin
	alter table avs_published_comp_bt_val drop constraint avs_published_comp_bt_val_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_published_message_pkey')
begin
	alter table avs_published_message drop constraint avs_published_message_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_published_msg_lng_extn_pkey')
begin
	alter table avs_published_msg_lng_extn drop constraint avs_published_msg_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_published_service_validation_dtl_pkey')
begin
	alter table avs_published_service_validation_dtl drop constraint avs_published_service_validation_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'cvs_published_control_validation_pkey')
begin
	alter table cvs_published_control_validation drop constraint cvs_published_control_validation_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_cvs_published_message')
begin
	alter table cvs_published_message drop constraint PK_cvs_published_message
end

if exists(select 'x' from sysobjects where name = 'PK_cvs_published_message_lng_extn')
begin
	alter table cvs_published_message_lng_extn drop constraint PK_cvs_published_message_lng_extn
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_br_logical_parameter')
begin
	alter table de_fw_des_publish_be_placeholder drop constraint de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_br_logical_parameter
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_brerror')
begin
	alter table de_fw_des_publish_be_placeholder drop constraint de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_brerror
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_be_placeholder drop constraint de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_error_placeholder')
begin
	alter table de_fw_des_publish_be_placeholder drop constraint de_fw_des_publish_be_placeholder_fkey_de_fw_des_publish_error_placeholder
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_be_placeholder_pkey')
begin
	alter table de_fw_des_publish_be_placeholder drop constraint de_fw_des_publish_be_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_bo_pkey')
begin
	alter table de_fw_des_publish_bo drop constraint de_fw_des_publish_bo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_bo_documentation_pkey')
begin
	alter table de_fw_des_publish_bo_documentation drop constraint de_fw_des_publish_bo_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_br_documentation_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_br_documentation drop constraint de_fw_des_publish_br_documentation_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_br_documentation_pkey')
begin
	alter table de_fw_des_publish_br_documentation drop constraint de_fw_des_publish_br_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_br_logical_parameter_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_br_logical_parameter drop constraint de_fw_des_publish_br_logical_parameter_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_br_logical_parameter_fkey_de_fw_req_publish_bterm')
begin
	alter table de_fw_des_publish_br_logical_parameter drop constraint de_fw_des_publish_br_logical_parameter_fkey_de_fw_req_publish_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_br_logical_parameter_pkey')
begin
	alter table de_fw_des_publish_br_logical_parameter drop constraint de_fw_des_publish_br_logical_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_brerror_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_brerror drop constraint de_fw_des_publish_brerror_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_brerror_fkey_de_fw_des_publish_error')
begin
	alter table de_fw_des_publish_brerror drop constraint de_fw_des_publish_brerror_fkey_de_fw_des_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_brerror_pkey')
begin
	alter table de_fw_des_publish_brerror drop constraint de_fw_des_publish_brerror_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_bro_pkey')
begin
	alter table de_fw_des_publish_bro drop constraint de_fw_des_publish_bro_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_businessrule_accessesdatabase')
begin
	alter table de_fw_des_publish_businessrule drop constraint Chk_de_fw_des_publish_businessrule_accessesdatabase
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_businessrule_operationtype')
begin
	alter table de_fw_des_publish_businessrule drop constraint Chk_de_fw_des_publish_businessrule_operationtype
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_businessrule_systemgenerated')
begin
	alter table de_fw_des_publish_businessrule drop constraint Chk_de_fw_des_publish_businessrule_systemgenerated
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_businessrule_fkey_de_fw_des_publish_bro')
begin
	alter table de_fw_des_publish_businessrule drop constraint de_fw_des_publish_businessrule_fkey_de_fw_des_publish_bro
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_businessrule_pkey')
begin
	alter table de_fw_des_publish_businessrule drop constraint de_fw_des_publish_businessrule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_chart_service_dataitem_pkey')
begin
	alter table de_fw_des_publish_chart_service_dataitem drop constraint de_fw_des_publish_chart_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_chart_service_segment_pkey')
begin
	alter table de_fw_des_publish_chart_service_segment drop constraint de_fw_des_publish_chart_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_context_fkey_de_fw_des_publish_error')
begin
	alter table de_fw_des_publish_context drop constraint de_fw_des_publish_context_fkey_de_fw_des_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_context_pkey')
begin
	alter table de_fw_des_publish_context drop constraint de_fw_des_publish_context_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_corr_action_local_info_fkey_de_fw_des_publish_context')
begin
	alter table de_fw_des_publish_corr_action_local_info drop constraint de_fw_des_publish_corr_action_local_info_fkey_de_fw_des_publish_context
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_corr_action_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_des_publish_corr_action_local_info drop constraint de_fw_des_publish_corr_action_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_corr_action_local_info_pkey')
begin
	alter table de_fw_des_publish_corr_action_local_info drop constraint de_fw_des_publish_corr_action_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_dataitem_ispartofkey')
begin
	alter table de_fw_des_publish_dataitem drop constraint Chk_de_fw_des_publish_dataitem_ispartofkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_dataitem_mandatoryflag')
begin
	alter table de_fw_des_publish_dataitem drop constraint Chk_de_fw_des_publish_dataitem_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_dataitem_fkey_de_fw_des_publish_dataitem')
begin
	alter table de_fw_des_publish_dataitem drop constraint de_fw_des_publish_dataitem_fkey_de_fw_des_publish_dataitem
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_dataitem_fkey_de_fw_des_publish_segment')
begin
	alter table de_fw_des_publish_dataitem drop constraint de_fw_des_publish_dataitem_fkey_de_fw_des_publish_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_dataitem_fkey_de_fw_req_publish_bterm_synonym')
begin
	alter table de_fw_des_publish_dataitem drop constraint de_fw_des_publish_dataitem_fkey_de_fw_req_publish_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_dataitem_pkey')
begin
	alter table de_fw_des_publish_dataitem drop constraint de_fw_des_publish_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_parameter_fkey_de_fw_des_publish_br_logical_parameter')
begin
	alter table de_fw_des_publish_di_parameter drop constraint de_fw_des_publish_di_parameter_fkey_de_fw_des_publish_br_logical_parameter
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_parameter_fkey_de_fw_des_publish_processsection_br_is')
begin
	alter table de_fw_des_publish_di_parameter drop constraint de_fw_des_publish_di_parameter_fkey_de_fw_des_publish_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_parameter_pkey')
begin
	alter table de_fw_des_publish_di_parameter drop constraint de_fw_des_publish_di_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_brerror')
begin
	alter table de_fw_des_publish_di_placeholder drop constraint de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_brerror
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_error_placeholder')
begin
	alter table de_fw_des_publish_di_placeholder drop constraint de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_error_placeholder
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_processsection_br_is')
begin
	alter table de_fw_des_publish_di_placeholder drop constraint de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_service_dataitem')
begin
	alter table de_fw_des_publish_di_placeholder drop constraint de_fw_des_publish_di_placeholder_fkey_de_fw_des_publish_service_dataitem
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_di_placeholder_pkey')
begin
	alter table de_fw_des_publish_di_placeholder drop constraint de_fw_des_publish_di_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_err_det_local_info_fkey_de_fw_des_publish_error')
begin
	alter table de_fw_des_publish_err_det_local_info drop constraint de_fw_des_publish_err_det_local_info_fkey_de_fw_des_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_err_det_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_des_publish_err_det_local_info drop constraint de_fw_des_publish_err_det_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_err_det_local_info_pkey')
begin
	alter table de_fw_des_publish_err_det_local_info drop constraint de_fw_des_publish_err_det_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_errbtn_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_des_publish_errbtn_local_info drop constraint de_fw_des_publish_errbtn_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_errbtn_local_info_pkey')
begin
	alter table de_fw_des_publish_errbtn_local_info drop constraint de_fw_des_publish_errbtn_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_error_displaytype')
begin
	alter table de_fw_des_publish_error drop constraint Chk_de_fw_des_publish_error_displaytype
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_error_errorsource')
begin
	alter table de_fw_des_publish_error drop constraint Chk_de_fw_des_publish_error_errorsource
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_error_pkey')
begin
	alter table de_fw_des_publish_error drop constraint de_fw_des_publish_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_error_lookup_pk')
begin
	alter table de_fw_des_publish_error_lookup drop constraint de_fw_des_publish_error_lookup_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_error_lookup_dataitem_pk')
begin
	alter table de_fw_des_publish_error_lookup_dataitem drop constraint de_fw_des_publish_error_lookup_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_error_placeholder_fkey_de_fw_des_publish_error')
begin
	alter table de_fw_des_publish_error_placeholder drop constraint de_fw_des_publish_error_placeholder_fkey_de_fw_des_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_error_placeholder_pkey')
begin
	alter table de_fw_des_publish_error_placeholder drop constraint de_fw_des_publish_error_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_focus_control_pkey')
begin
	alter table de_fw_des_publish_focus_control drop constraint de_fw_des_publish_focus_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_followup_tasks_pk')
begin
	alter table de_fw_des_publish_followup_tasks drop constraint de_fw_des_publish_followup_tasks_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_action_group_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_des_publish_ilbo_action_group drop constraint de_fw_des_publish_ilbo_action_group_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_action_group_pkey')
begin
	alter table de_fw_des_publish_ilbo_action_group drop constraint de_fw_des_publish_ilbo_action_group_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_des_publish_ilbo_action_group')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_event drop constraint de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_des_publish_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_des_publish_ilbo_ctrl_event')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_event drop constraint de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_des_publish_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_req_publish_activity_ilbo')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_event drop constraint de_fw_des_publish_ilbo_actiongrp_event_fkey_de_fw_req_publish_activity_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_event_pkey')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_event drop constraint de_fw_des_publish_ilbo_actiongrp_event_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_des_publish_ilbo_action_group')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_task drop constraint de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_des_publish_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_req_publish_activity_ilbo')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_task drop constraint de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_req_publish_activity_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_req_publish_activity_task')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_task drop constraint de_fw_des_publish_ilbo_actiongrp_task_fkey_de_fw_req_publish_activity_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actiongrp_task_pkey')
begin
	alter table de_fw_des_publish_ilbo_actiongrp_task drop constraint de_fw_des_publish_ilbo_actiongrp_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actions_fkey_de_fw_des_publish_ilbo_action_group')
begin
	alter table de_fw_des_publish_ilbo_actions drop constraint de_fw_des_publish_ilbo_actions_fkey_de_fw_des_publish_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actions_fkey_de_fw_req_publish_businessrule')
begin
	alter table de_fw_des_publish_ilbo_actions drop constraint de_fw_des_publish_ilbo_actions_fkey_de_fw_req_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_actions_pkey')
begin
	alter table de_fw_des_publish_ilbo_actions drop constraint de_fw_des_publish_ilbo_actions_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_controlvalue_pkey')
begin
	alter table de_fw_des_publish_ilbo_controlvalue drop constraint de_fw_des_publish_ilbo_controlvalue_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_ctrl_event_pkey')
begin
	alter table de_fw_des_publish_ilbo_ctrl_event drop constraint de_fw_des_publish_ilbo_ctrl_event_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_placeholder_fkey_de_fw_des_publish_ilbo_ctrl_event')
begin
	alter table de_fw_des_publish_ilbo_placeholder drop constraint de_fw_des_publish_ilbo_placeholder_fkey_de_fw_des_publish_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_placeholder_pkey')
begin
	alter table de_fw_des_publish_ilbo_placeholder drop constraint de_fw_des_publish_ilbo_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_service_view_attributemap_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_des_publish_ilbo_service_view_attributemap drop constraint de_fw_des_publish_ilbo_service_view_attributemap_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_service_view_attributemap_pkey')
begin
	alter table de_fw_des_publish_ilbo_service_view_attributemap drop constraint de_fw_des_publish_ilbo_service_view_attributemap_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_service_view_datamap_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_des_publish_ilbo_service_view_datamap drop constraint de_fw_des_publish_ilbo_service_view_datamap_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_service_view_datamap_pkey')
begin
	alter table de_fw_des_publish_ilbo_service_view_datamap drop constraint de_fw_des_publish_ilbo_service_view_datamap_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_services_fkey_de_fw_des_publish_service')
begin
	alter table de_fw_des_publish_ilbo_services drop constraint de_fw_des_publish_ilbo_services_fkey_de_fw_des_publish_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_services_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_des_publish_ilbo_services drop constraint de_fw_des_publish_ilbo_services_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilbo_services_pkey')
begin
	alter table de_fw_des_publish_ilbo_services drop constraint de_fw_des_publish_ilbo_services_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilerror_fkey_de_fw_des_publish_error')
begin
	alter table de_fw_des_publish_ilerror drop constraint de_fw_des_publish_ilerror_fkey_de_fw_des_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilerror_fkey_de_fw_des_publish_ilbo_ctrl_event')
begin
	alter table de_fw_des_publish_ilerror drop constraint de_fw_des_publish_ilerror_fkey_de_fw_des_publish_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_ilerror_pkey')
begin
	alter table de_fw_des_publish_ilerror drop constraint de_fw_des_publish_ilerror_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_integ_serv_map_fkey_de_fw_des_publish_processsection_br_is')
begin
	alter table de_fw_des_publish_integ_serv_map drop constraint de_fw_des_publish_integ_serv_map_fkey_de_fw_des_publish_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_integ_serv_map_pkey')
begin
	alter table de_fw_des_publish_integ_serv_map drop constraint de_fw_des_publish_integ_serv_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_processsection_sectiontype')
begin
	alter table de_fw_des_publish_processsection drop constraint Chk_de_fw_des_publish_processsection_sectiontype
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_fkey_de_fw_des_publish_service')
begin
	alter table de_fw_des_publish_processsection drop constraint de_fw_des_publish_processsection_fkey_de_fw_des_publish_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_pkey')
begin
	alter table de_fw_des_publish_processsection drop constraint de_fw_des_publish_processsection_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_processsection')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_processsection
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_br_is_pkey')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint de_fw_des_publish_processsection_br_is_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_reqbr_desbr_pkey')
begin
	alter table de_fw_des_publish_reqbr_desbr drop constraint de_fw_des_publish_reqbr_desbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_segment_instanceflag')
begin
	alter table de_fw_des_publish_segment drop constraint Chk_de_fw_des_publish_segment_instanceflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_segment_pkey')
begin
	alter table de_fw_des_publish_segment drop constraint de_fw_des_publish_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_isintegser')
begin
	alter table de_fw_des_publish_service drop constraint Chk_de_fw_des_publish_service_isintegser
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_servicetype')
begin
	alter table de_fw_des_publish_service drop constraint Chk_de_fw_des_publish_service_servicetype
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_fkey_de_fw_des_publish_svco')
begin
	alter table de_fw_des_publish_service drop constraint de_fw_des_publish_service_fkey_de_fw_des_publish_svco
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_des_publish_service drop constraint de_fw_des_publish_service_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_pkey')
begin
	alter table de_fw_des_publish_service drop constraint de_fw_des_publish_service_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_dataitem_flowattribute')
begin
	alter table de_fw_des_publish_service_dataitem drop constraint Chk_de_fw_des_publish_service_dataitem_flowattribute
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_dataitem_ispartofkey')
begin
	alter table de_fw_des_publish_service_dataitem drop constraint Chk_de_fw_des_publish_service_dataitem_ispartofkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_dataitem_mandatoryflag')
begin
	alter table de_fw_des_publish_service_dataitem drop constraint Chk_de_fw_des_publish_service_dataitem_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_dataitem_fkey_de_fw_des_publish_service_segment')
begin
	alter table de_fw_des_publish_service_dataitem drop constraint de_fw_des_publish_service_dataitem_fkey_de_fw_des_publish_service_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_dataitem_pkey')
begin
	alter table de_fw_des_publish_service_dataitem drop constraint de_fw_des_publish_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_documentation_fkey_de_fw_des_publish_service')
begin
	alter table de_fw_des_publish_service_documentation drop constraint de_fw_des_publish_service_documentation_fkey_de_fw_des_publish_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_documentation_pkey')
begin
	alter table de_fw_des_publish_service_documentation drop constraint de_fw_des_publish_service_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_segment_instanceflag')
begin
	alter table de_fw_des_publish_service_segment drop constraint Chk_de_fw_des_publish_service_segment_instanceflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_service_segment_mandatoryflag')
begin
	alter table de_fw_des_publish_service_segment drop constraint Chk_de_fw_des_publish_service_segment_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_segment_fkey_de_fw_des_publish_segment')
begin
	alter table de_fw_des_publish_service_segment drop constraint de_fw_des_publish_service_segment_fkey_de_fw_des_publish_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_segment_fkey_de_fw_des_publish_service')
begin
	alter table de_fw_des_publish_service_segment drop constraint de_fw_des_publish_service_segment_fkey_de_fw_des_publish_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_service_segment_pkey')
begin
	alter table de_fw_des_publish_service_segment drop constraint de_fw_des_publish_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_sp_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_sp drop constraint de_fw_des_publish_sp_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_sp_pkey')
begin
	alter table de_fw_des_publish_sp drop constraint de_fw_des_publish_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_svco_pkey')
begin
	alter table de_fw_des_publish_svco drop constraint de_fw_des_publish_svco_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_task_segment_attribs_pkey')
begin
	alter table de_fw_des_publish_task_segment_attribs drop constraint de_fw_des_publish_task_segment_attribs_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_publish_activity_iswfenabled')
begin
	alter table de_fw_req_publish_activity drop constraint Chk_de_fw_req_publish_activity_iswfenabled
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_pkey')
begin
	alter table de_fw_req_publish_activity drop constraint de_fw_req_publish_activity_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_documentation_fkey_de_fw_req_publish_activity')
begin
	alter table de_fw_req_publish_activity_documentation drop constraint de_fw_req_publish_activity_documentation_fkey_de_fw_req_publish_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_activity_documentation drop constraint de_fw_req_publish_activity_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_documentation_pkey')
begin
	alter table de_fw_req_publish_activity_documentation drop constraint de_fw_req_publish_activity_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_fkey_de_fw_req_publish_activity')
begin
	alter table de_fw_req_publish_activity_ilbo drop constraint de_fw_req_publish_activity_ilbo_fkey_de_fw_req_publish_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_activity_ilbo drop constraint de_fw_req_publish_activity_ilbo_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_pkey')
begin
	alter table de_fw_req_publish_activity_ilbo drop constraint de_fw_req_publish_activity_ilbo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_task_fkey_de_fw_req_publish_activity_ilbo')
begin
	alter table de_fw_req_publish_activity_ilbo_task drop constraint de_fw_req_publish_activity_ilbo_task_fkey_de_fw_req_publish_activity_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_task_fkey_de_fw_req_publish_activity_task')
begin
	alter table de_fw_req_publish_activity_ilbo_task drop constraint de_fw_req_publish_activity_ilbo_task_fkey_de_fw_req_publish_activity_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_task_pkey')
begin
	alter table de_fw_req_publish_activity_ilbo_task drop constraint de_fw_req_publish_activity_ilbo_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_ilbo_task_extension_map_pkey')
begin
	alter table de_fw_req_publish_activity_ilbo_task_extension_map drop constraint de_fw_req_publish_activity_ilbo_task_extension_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_local_info_fkey_de_fw_req_publish_activity')
begin
	alter table de_fw_req_publish_activity_local_info drop constraint de_fw_req_publish_activity_local_info_fkey_de_fw_req_publish_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_activity_local_info drop constraint de_fw_req_publish_activity_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_local_info_pkey')
begin
	alter table de_fw_req_publish_activity_local_info drop constraint de_fw_req_publish_activity_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_task_fkey_de_fw_req_publish_activity')
begin
	alter table de_fw_req_publish_activity_task drop constraint de_fw_req_publish_activity_task_fkey_de_fw_req_publish_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_task_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_req_publish_activity_task drop constraint de_fw_req_publish_activity_task_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_activity_task_pkey')
begin
	alter table de_fw_req_publish_activity_task drop constraint de_fw_req_publish_activity_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_bterm')
begin
	alter table de_fw_req_publish_br_bterm drop constraint de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_bterm_synonym')
begin
	alter table de_fw_req_publish_br_bterm drop constraint de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_businessrule')
begin
	alter table de_fw_req_publish_br_bterm drop constraint de_fw_req_publish_br_bterm_fkey_de_fw_req_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_bterm_pkey')
begin
	alter table de_fw_req_publish_br_bterm drop constraint de_fw_req_publish_br_bterm_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_documentation_fkey_de_fw_req_publish_businessrule')
begin
	alter table de_fw_req_publish_br_documentation drop constraint de_fw_req_publish_br_documentation_fkey_de_fw_req_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_documentation_pkey')
begin
	alter table de_fw_req_publish_br_documentation drop constraint de_fw_req_publish_br_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_fkey_de_fw_req_publish_businessrule')
begin
	alter table de_fw_req_publish_br_error drop constraint de_fw_req_publish_br_error_fkey_de_fw_req_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_fkey_de_fw_req_publish_error')
begin
	alter table de_fw_req_publish_br_error drop constraint de_fw_req_publish_br_error_fkey_de_fw_req_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_pkey')
begin
	alter table de_fw_req_publish_br_error drop constraint de_fw_req_publish_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_placeholder_fkey_de_fw_req_publish_task_br_error_context')
begin
	alter table de_fw_req_publish_br_error_placeholder drop constraint de_fw_req_publish_br_error_placeholder_fkey_de_fw_req_publish_task_br_error_context
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_placeholder_fkey_de_fw_req_publish_taskrulesynonym_map')
begin
	alter table de_fw_req_publish_br_error_placeholder drop constraint de_fw_req_publish_br_error_placeholder_fkey_de_fw_req_publish_taskrulesynonym_map
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_br_error_placeholder_pkey')
begin
	alter table de_fw_req_publish_br_error_placeholder drop constraint de_fw_req_publish_br_error_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_fkey_de_fw_req_publish_precision')
begin
	alter table de_fw_req_publish_bterm drop constraint de_fw_req_publish_bterm_fkey_de_fw_req_publish_precision
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_pkey')
begin
	alter table de_fw_req_publish_bterm drop constraint de_fw_req_publish_bterm_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_enumerated_option_fkey_de_fw_req_publish_bterm')
begin
	alter table de_fw_req_publish_bterm_enumerated_option drop constraint de_fw_req_publish_bterm_enumerated_option_fkey_de_fw_req_publish_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_enumerated_option_pkey')
begin
	alter table de_fw_req_publish_bterm_enumerated_option drop constraint de_fw_req_publish_bterm_enumerated_option_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_group_fkey_de_fw_req_publish_bterm')
begin
	alter table de_fw_req_publish_bterm_group drop constraint de_fw_req_publish_bterm_group_fkey_de_fw_req_publish_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_group_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_bterm_group drop constraint de_fw_req_publish_bterm_group_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_group_pkey')
begin
	alter table de_fw_req_publish_bterm_group drop constraint de_fw_req_publish_bterm_group_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_synonym_fkey_de_fw_req_publish_bterm')
begin
	alter table de_fw_req_publish_bterm_synonym drop constraint de_fw_req_publish_bterm_synonym_fkey_de_fw_req_publish_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_bterm_synonym_pkey')
begin
	alter table de_fw_req_publish_bterm_synonym drop constraint de_fw_req_publish_bterm_synonym_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_businessrule_pkey')
begin
	alter table de_fw_req_publish_businessrule drop constraint de_fw_req_publish_businessrule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_component_documentation drop constraint de_fw_req_publish_component_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_documentation_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_component_documentation drop constraint de_fw_req_publish_component_documentation_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_documentation_pkey')
begin
	alter table de_fw_req_publish_component_documentation drop constraint de_fw_req_publish_component_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_component_local_info drop constraint de_fw_req_publish_component_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_local_info_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_component_local_info drop constraint de_fw_req_publish_component_local_info_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_component_local_info_pkey')
begin
	alter table de_fw_req_publish_component_local_info drop constraint de_fw_req_publish_component_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_publish_error_severity')
begin
	alter table de_fw_req_publish_error drop constraint Chk_de_fw_req_publish_error_severity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_error_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_error drop constraint de_fw_req_publish_error_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_error_pkey')
begin
	alter table de_fw_req_publish_error drop constraint de_fw_req_publish_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_error_local_info_fkey_de_fw_req_publish_error')
begin
	alter table de_fw_req_publish_error_local_info drop constraint de_fw_req_publish_error_local_info_fkey_de_fw_req_publish_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_error_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_error_local_info drop constraint de_fw_req_publish_error_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_error_local_info_pkey')
begin
	alter table de_fw_req_publish_error_local_info drop constraint de_fw_req_publish_error_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_pkey')
begin
	alter table de_fw_req_publish_ilbo drop constraint de_fw_req_publish_ilbo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_control_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_control drop constraint de_fw_req_publish_ilbo_control_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_control_pkey')
begin
	alter table de_fw_req_publish_ilbo_control drop constraint de_fw_req_publish_ilbo_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_control_property_pkey')
begin
	alter table de_fw_req_publish_ilbo_control_property drop constraint de_fw_req_publish_ilbo_control_property_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_data_publish_fkey_de_fw_req_publish_ilbo_link_publish')
begin
	alter table de_fw_req_publish_ilbo_data_publish drop constraint de_fw_req_publish_ilbo_data_publish_fkey_de_fw_req_publish_ilbo_link_publish
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_data_publish_pkey')
begin
	alter table de_fw_req_publish_ilbo_data_publish drop constraint de_fw_req_publish_ilbo_data_publish_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_data_use_pkey')
begin
	alter table de_fw_req_publish_ilbo_data_use drop constraint de_fw_req_publish_ilbo_data_use_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_documentation_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_documentation drop constraint de_fw_req_publish_ilbo_documentation_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_ilbo_documentation drop constraint de_fw_req_publish_ilbo_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_documentation_pkey')
begin
	alter table de_fw_req_publish_ilbo_documentation drop constraint de_fw_req_publish_ilbo_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_local_info_fkey_de_fw_req_publish_ilbo_link_publish')
begin
	alter table de_fw_req_publish_ilbo_link_local_info drop constraint de_fw_req_publish_ilbo_link_local_info_fkey_de_fw_req_publish_ilbo_link_publish
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_local_info_pkey')
begin
	alter table de_fw_req_publish_ilbo_link_local_info drop constraint de_fw_req_publish_ilbo_link_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_publish_fkey_de_fw_req_publish_ilbo_link_publish')
begin
	alter table de_fw_req_publish_ilbo_link_publish drop constraint de_fw_req_publish_ilbo_link_publish_fkey_de_fw_req_publish_ilbo_link_publish
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_publish_pkey')
begin
	alter table de_fw_req_publish_ilbo_link_publish drop constraint de_fw_req_publish_ilbo_link_publish_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_use_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_ilbo_link_use_documentation drop constraint de_fw_req_publish_ilbo_link_use_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_link_use_documentation_pkey')
begin
	alter table de_fw_req_publish_ilbo_link_use_documentation drop constraint de_fw_req_publish_ilbo_link_use_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_linkuse_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_linkuse drop constraint de_fw_req_publish_ilbo_linkuse_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_linkuse_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_req_publish_ilbo_linkuse drop constraint de_fw_req_publish_ilbo_linkuse_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_linkuse_pkey')
begin
	alter table de_fw_req_publish_ilbo_linkuse drop constraint de_fw_req_publish_ilbo_linkuse_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_local_info_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_local_info drop constraint de_fw_req_publish_ilbo_local_info_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_ilbo_local_info drop constraint de_fw_req_publish_ilbo_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_local_info_pkey')
begin
	alter table de_fw_req_publish_ilbo_local_info drop constraint de_fw_req_publish_ilbo_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_project_details_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_project_details drop constraint de_fw_req_publish_ilbo_project_details_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_project_details_pkey')
begin
	alter table de_fw_req_publish_ilbo_project_details drop constraint de_fw_req_publish_ilbo_project_details_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_tab_properties_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_tab_properties drop constraint de_fw_req_publish_ilbo_tab_properties_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_tab_properties_pkey')
begin
	alter table de_fw_req_publish_ilbo_tab_properties drop constraint de_fw_req_publish_ilbo_tab_properties_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_tabs_fkey_de_fw_req_publish_ilbo')
begin
	alter table de_fw_req_publish_ilbo_tabs drop constraint de_fw_req_publish_ilbo_tabs_fkey_de_fw_req_publish_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_tabs_pkey')
begin
	alter table de_fw_req_publish_ilbo_tabs drop constraint de_fw_req_publish_ilbo_tabs_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_task_rpt_PK')
begin
	alter table de_fw_req_publish_ilbo_task_rpt drop constraint de_fw_req_publish_ilbo_task_rpt_PK
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_fkey_de_fw_req_publish_bterm_synonym')
begin
	alter table de_fw_req_publish_ilbo_view drop constraint de_fw_req_publish_ilbo_view_fkey_de_fw_req_publish_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_fkey_de_fw_req_publish_ilbo_control')
begin
	alter table de_fw_req_publish_ilbo_view drop constraint de_fw_req_publish_ilbo_view_fkey_de_fw_req_publish_ilbo_control
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_pkey')
begin
	alter table de_fw_req_publish_ilbo_view drop constraint de_fw_req_publish_ilbo_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_documentation_fkey_de_fw_req_publish_ilbo_view')
begin
	alter table de_fw_req_publish_ilbo_view_documentation drop constraint de_fw_req_publish_ilbo_view_documentation_fkey_de_fw_req_publish_ilbo_view
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_ilbo_view_documentation drop constraint de_fw_req_publish_ilbo_view_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_local_info_fkey_de_fw_req_publish_ilbo_view')
begin
	alter table de_fw_req_publish_ilbo_view_local_info drop constraint de_fw_req_publish_ilbo_view_local_info_fkey_de_fw_req_publish_ilbo_view
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_ilbo_view_local_info drop constraint de_fw_req_publish_ilbo_view_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilbo_view_local_info_pkey')
begin
	alter table de_fw_req_publish_ilbo_view_local_info drop constraint de_fw_req_publish_ilbo_view_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_ilboctrl_initval_pkey')
begin
	alter table de_fw_req_publish_ilboctrl_initval drop constraint de_fw_req_publish_ilboctrl_initval_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_lang_bterm_synonym_fkey_de_fw_req_publish_bterm_synonym')
begin
	alter table de_fw_req_publish_lang_bterm_synonym drop constraint de_fw_req_publish_lang_bterm_synonym_fkey_de_fw_req_publish_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_lang_bterm_synonym_pkey')
begin
	alter table de_fw_req_publish_lang_bterm_synonym drop constraint de_fw_req_publish_lang_bterm_synonym_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_language_pkey')
begin
	alter table de_fw_req_publish_language drop constraint de_fw_req_publish_language_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_precision_pkey')
begin
	alter table de_fw_req_publish_precision drop constraint de_fw_req_publish_precision_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_fkey_de_fw_req_publish_process')
begin
	alter table de_fw_req_publish_process drop constraint de_fw_req_publish_process_fkey_de_fw_req_publish_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_pkey')
begin
	alter table de_fw_req_publish_process drop constraint de_fw_req_publish_process_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_component_fkey_de_fw_req_publish_process')
begin
	alter table de_fw_req_publish_process_component drop constraint de_fw_req_publish_process_component_fkey_de_fw_req_publish_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_component_pkey')
begin
	alter table de_fw_req_publish_process_component drop constraint de_fw_req_publish_process_component_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_process_documentation drop constraint de_fw_req_publish_process_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_documentation_fkey_de_fw_req_publish_process')
begin
	alter table de_fw_req_publish_process_documentation drop constraint de_fw_req_publish_process_documentation_fkey_de_fw_req_publish_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_process_documentation_pkey')
begin
	alter table de_fw_req_publish_process_documentation drop constraint de_fw_req_publish_process_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_reference_value_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_reference_value drop constraint de_fw_req_publish_reference_value_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_reference_value_pkey')
begin
	alter table de_fw_req_publish_reference_value drop constraint de_fw_req_publish_reference_value_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_pkey')
begin
	alter table de_fw_req_publish_state drop constraint de_fw_req_publish_state_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_activity_fkey_de_fw_req_publish_activity')
begin
	alter table de_fw_req_publish_state_activity drop constraint de_fw_req_publish_state_activity_fkey_de_fw_req_publish_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_activity_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_state_activity drop constraint de_fw_req_publish_state_activity_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_activity_fkey_de_fw_req_publish_state')
begin
	alter table de_fw_req_publish_state_activity drop constraint de_fw_req_publish_state_activity_fkey_de_fw_req_publish_state
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_activity_pkey')
begin
	alter table de_fw_req_publish_state_activity drop constraint de_fw_req_publish_state_activity_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_component_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_state_component drop constraint de_fw_req_publish_state_component_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_component_fkey_de_fw_req_publish_state')
begin
	alter table de_fw_req_publish_state_component drop constraint de_fw_req_publish_state_component_fkey_de_fw_req_publish_state
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_component_fkey_de_fw_req_publish_value_chain')
begin
	alter table de_fw_req_publish_state_component drop constraint de_fw_req_publish_state_component_fkey_de_fw_req_publish_value_chain
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_state_component_pkey')
begin
	alter table de_fw_req_publish_state_component drop constraint de_fw_req_publish_state_component_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_publish_task_tasktype')
begin
	alter table de_fw_req_publish_task drop constraint Chk_de_fw_req_publish_task_tasktype
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_pkey')
begin
	alter table de_fw_req_publish_task drop constraint de_fw_req_publish_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_br_error_context_fkey_de_fw_req_publish_br_error')
begin
	alter table de_fw_req_publish_task_br_error_context drop constraint de_fw_req_publish_task_br_error_context_fkey_de_fw_req_publish_br_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_br_error_context_fkey_de_fw_req_publish_task_rule')
begin
	alter table de_fw_req_publish_task_br_error_context drop constraint de_fw_req_publish_task_br_error_context_fkey_de_fw_req_publish_task_rule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_br_error_context_pkey')
begin
	alter table de_fw_req_publish_task_br_error_context drop constraint de_fw_req_publish_task_br_error_context_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_task_documentation drop constraint de_fw_req_publish_task_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_documentation_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_req_publish_task_documentation drop constraint de_fw_req_publish_task_documentation_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_documentation_pkey')
begin
	alter table de_fw_req_publish_task_documentation drop constraint de_fw_req_publish_task_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_local_info_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_task_local_info drop constraint de_fw_req_publish_task_local_info_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_local_info_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_req_publish_task_local_info drop constraint de_fw_req_publish_task_local_info_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_local_info_pkey')
begin
	alter table de_fw_req_publish_task_local_info drop constraint de_fw_req_publish_task_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_rule_fkey_de_fw_req_publish_businessrule')
begin
	alter table de_fw_req_publish_task_rule drop constraint de_fw_req_publish_task_rule_fkey_de_fw_req_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_rule_fkey_de_fw_req_publish_task')
begin
	alter table de_fw_req_publish_task_rule drop constraint de_fw_req_publish_task_rule_fkey_de_fw_req_publish_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_task_rule_pkey')
begin
	alter table de_fw_req_publish_task_rule drop constraint de_fw_req_publish_task_rule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_taskrulesynonym_map_fkey_de_fw_req_publish_task_rule')
begin
	alter table de_fw_req_publish_taskrulesynonym_map drop constraint de_fw_req_publish_taskrulesynonym_map_fkey_de_fw_req_publish_task_rule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_taskrulesynonym_map_pkey')
begin
	alter table de_fw_req_publish_taskrulesynonym_map drop constraint de_fw_req_publish_taskrulesynonym_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_value_chain_fkey_de_fw_req_publish_process_component')
begin
	alter table de_fw_req_publish_value_chain drop constraint de_fw_req_publish_value_chain_fkey_de_fw_req_publish_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_value_chain_pkey')
begin
	alter table de_fw_req_publish_value_chain drop constraint de_fw_req_publish_value_chain_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_vc_documentation_fkey_de_fw_req_publish_language')
begin
	alter table de_fw_req_publish_vc_documentation drop constraint de_fw_req_publish_vc_documentation_fkey_de_fw_req_publish_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_vc_documentation_fkey_de_fw_req_publish_value_chain')
begin
	alter table de_fw_req_publish_vc_documentation drop constraint de_fw_req_publish_vc_documentation_fkey_de_fw_req_publish_value_chain
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_publish_vc_documentation_pkey')
begin
	alter table de_fw_req_publish_vc_documentation drop constraint de_fw_req_publish_vc_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_action_pkey')
begin
	alter table de_published_action drop constraint de_published_action_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_action_lng_extn_pkey')
begin
	alter table de_published_action_lng_extn drop constraint de_published_action_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_action_section_map_pkey')
begin
	alter table de_published_action_section_map drop constraint de_published_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_fkey_de_published_business_object')
begin
	alter table de_published_bo_segment drop constraint de_published_bo_segment_fkey_de_published_business_object
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_pkey')
begin
	alter table de_published_bo_segment drop constraint de_published_bo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_dataitem_fkey_de_published_bo_segment')
begin
	alter table de_published_bo_segment_dataitem drop constraint de_published_bo_segment_dataitem_fkey_de_published_bo_segment
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_dataitem_pkey')
begin
	alter table de_published_bo_segment_dataitem drop constraint de_published_bo_segment_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_dataitem_lng_extn_fkey_de_published_bo_segment')
begin
	alter table de_published_bo_segment_dataitem_lng_extn drop constraint de_published_bo_segment_dataitem_lng_extn_fkey_de_published_bo_segment
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_dataitem_lng_extn_pkey')
begin
	alter table de_published_bo_segment_dataitem_lng_extn drop constraint de_published_bo_segment_dataitem_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_lng_extn_fkey_de_published_business_object')
begin
	alter table de_published_bo_segment_lng_extn drop constraint de_published_bo_segment_lng_extn_fkey_de_published_business_object
end

if exists(select 'x' from sysobjects where name = 'de_published_bo_segment_lng_extn_pkey')
begin
	alter table de_published_bo_segment_lng_extn drop constraint de_published_bo_segment_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_object_pkey')
begin
	alter table de_published_business_object drop constraint de_published_business_object_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_object_lng_extn_pkey')
begin
	alter table de_published_business_object_lng_extn drop constraint de_published_business_object_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_rule_pkey')
begin
	alter table de_published_business_rule drop constraint de_published_business_rule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_rule_lng_extn_pkey')
begin
	alter table de_published_business_rule_lng_extn drop constraint de_published_business_rule_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_term_pkey')
begin
	alter table de_published_business_term drop constraint de_published_business_term_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_business_term_lng_extn_pkey')
begin
	alter table de_published_business_term_lng_extn drop constraint de_published_business_term_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_chart_header_pkey')
begin
	alter table de_published_chart_header drop constraint de_published_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_chart_sample_data_pkey')
begin
	alter table de_published_chart_sample_data drop constraint de_published_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_chart_series_pkey')
begin
	alter table de_published_chart_series drop constraint de_published_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_chm_service_datatitem_PK')
begin
	alter table de_published_chm_service_datatitem drop constraint de_published_chm_service_datatitem_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_contextual_links_pkey')
begin
	alter table de_published_contextual_links drop constraint de_published_contextual_links_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_control_extensions_pkey')
begin
	alter table de_published_control_extensions drop constraint de_published_control_extensions_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_custom_listedit_pkey')
begin
	alter table de_published_custom_listedit drop constraint de_published_custom_listedit_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_enum_value_default_flag')
begin
	alter table de_published_enum_value drop constraint Chk_de_published_enum_value_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_enum_value_pkey')
begin
	alter table de_published_enum_value drop constraint de_published_enum_value_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_enum_value_lng_extn_default_flag')
begin
	alter table de_published_enum_value_lng_extn drop constraint Chk_de_published_enum_value_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_enum_value_lng_extn_pkey')
begin
	alter table de_published_enum_value_lng_extn drop constraint de_published_enum_value_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_dtl_layout_pkey')
begin
	alter table de_published_exrep_dtl_layout drop constraint de_published_exrep_dtl_layout_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_hdr_layout_pkey')
begin
	alter table de_published_exrep_hdr_layout drop constraint de_published_exrep_hdr_layout_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_sections_pkey')
begin
	alter table de_published_exrep_sections drop constraint de_published_exrep_sections_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_task_temp_map_pkey')
begin
	alter table de_published_exrep_task_temp_map drop constraint de_published_exrep_task_temp_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_temp_dtl_pkey')
begin
	alter table de_published_exrep_temp_dtl drop constraint de_published_exrep_temp_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_exrep_temp_hdr_pkey')
begin
	alter table de_published_exrep_temp_hdr drop constraint de_published_exrep_temp_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ext_js_control_PK')
begin
	alter table de_published_ext_js_control drop constraint de_published_ext_js_control_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_ext_js_section_PK')
begin
	alter table de_published_ext_js_section drop constraint de_published_ext_js_section_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_ext_js_section_column_PK')
begin
	alter table de_published_ext_js_section_column drop constraint de_published_ext_js_section_column_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_ezeeview_sp_PK')
begin
	alter table de_published_ezeeview_sp drop constraint de_published_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_ezeeview_spparamlist_PK')
begin
	alter table de_published_ezeeview_spparamlist drop constraint de_published_ezeeview_spparamlist_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_res_ilbo_dataitem_pk')
begin
	alter table de_published_ezwiz_res_ilbo_dataitem drop constraint de_published_ezwiz_res_ilbo_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_res_step_dataitem_pk')
begin
	alter table de_published_ezwiz_res_step_dataitem drop constraint de_published_ezwiz_res_step_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_wizard_pk')
begin
	alter table de_published_ezwiz_wizard drop constraint de_published_ezwiz_wizard_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_wizard_local_info_pk')
begin
	alter table de_published_ezwiz_wizard_local_info drop constraint de_published_ezwiz_wizard_local_info_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_wizard_step_pk')
begin
	alter table de_published_ezwiz_wizard_step drop constraint de_published_ezwiz_wizard_step_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ezwiz_wizard_step_local_info_pk')
begin
	alter table de_published_ezwiz_wizard_step_local_info drop constraint de_published_ezwiz_wizard_step_local_info_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_pkey')
begin
	alter table de_published_flowbr drop constraint de_published_flowbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_flowbr_br_error_default_flag')
begin
	alter table de_published_flowbr_br_error drop constraint Chk_de_published_flowbr_br_error_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_br_error_pkey')
begin
	alter table de_published_flowbr_br_error drop constraint de_published_flowbr_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_flowbr_br_error_lng_extn_default_flag')
begin
	alter table de_published_flowbr_br_error_lng_extn drop constraint Chk_de_published_flowbr_br_error_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_br_error_lng_extn_pkey')
begin
	alter table de_published_flowbr_br_error_lng_extn drop constraint de_published_flowbr_br_error_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_combo_pkey')
begin
	alter table de_published_flowbr_combo drop constraint de_published_flowbr_combo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_lng_extn_pkey')
begin
	alter table de_published_flowbr_lng_extn drop constraint de_published_flowbr_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_method_map_pkey')
begin
	alter table de_published_flowbr_method_map drop constraint de_published_flowbr_method_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_flowbr_rule_map_br_type')
begin
	alter table de_published_flowbr_rule_map drop constraint Chk_de_published_flowbr_rule_map_br_type
end

if exists(select 'x' from sysobjects where name = 'de_published_flowbr_rule_map_pkey')
begin
	alter table de_published_flowbr_rule_map drop constraint de_published_flowbr_rule_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_data_type')
begin
	alter table de_published_glossary drop constraint Chk_de_published_glossary_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_length')
begin
	alter table de_published_glossary drop constraint Chk_de_published_glossary_length
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_synonym_status')
begin
	alter table de_published_glossary drop constraint Chk_de_published_glossary_synonym_status
end

if exists(select 'x' from sysobjects where name = 'de_published_glossary_pkey')
begin
	alter table de_published_glossary drop constraint de_published_glossary_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_lng_extn_data_type')
begin
	alter table de_published_glossary_lng_extn drop constraint Chk_de_published_glossary_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_lng_extn_length')
begin
	alter table de_published_glossary_lng_extn drop constraint Chk_de_published_glossary_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_glossary_lng_extn_synonym_status')
begin
	alter table de_published_glossary_lng_extn drop constraint Chk_de_published_glossary_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'de_published_glossary_lng_extn_pkey')
begin
	alter table de_published_glossary_lng_extn drop constraint de_published_glossary_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_hidden_view_transfer_flag')
begin
	alter table de_published_hidden_view drop constraint Chk_de_published_hidden_view_transfer_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_hidden_view_pkey')
begin
	alter table de_published_hidden_view drop constraint de_published_hidden_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_hidden_view_usage_pkey')
begin
	alter table de_published_hidden_view_usage drop constraint de_published_hidden_view_usage_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ibo_segment_pkey')
begin
	alter table de_published_ibo_segment drop constraint de_published_ibo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ibo_segment_dataitem_pkey')
begin
	alter table de_published_ibo_segment_dataitem drop constraint de_published_ibo_segment_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ibo_segment_dataitem_lng_extn_pkey')
begin
	alter table de_published_ibo_segment_dataitem_lng_extn drop constraint de_published_ibo_segment_dataitem_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ibo_segment_lng_extn_pkey')
begin
	alter table de_published_ibo_segment_lng_extn drop constraint de_published_ibo_segment_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_interaction_bo_pkey')
begin
	alter table de_published_interaction_bo drop constraint de_published_interaction_bo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_interaction_bo_lng_extn_pkey')
begin
	alter table de_published_interaction_bo_lng_extn drop constraint de_published_interaction_bo_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_is_dataitem_map_pkey')
begin
	alter table de_published_is_dataitem_map drop constraint de_published_is_dataitem_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_is_interaction_pkey')
begin
	alter table de_published_is_interaction drop constraint de_published_is_interaction_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_listedit_column_pkey')
begin
	alter table de_published_listedit_column drop constraint de_published_listedit_column_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_listedit_control_map_pkey')
begin
	alter table de_published_listedit_control_map drop constraint de_published_listedit_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_LogicExt_ui_control_dtl_pkey')
begin
	alter table de_published_LogicExt_ui_control_dtl drop constraint de_published_LogicExt_ui_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_LogicExt_ui_grid_dtl_fkey_de_published_ui')
begin
	alter table de_published_LogicExt_ui_grid_dtl drop constraint de_published_LogicExt_ui_grid_dtl_fkey_de_published_ui
end

if exists(select 'x' from sysobjects where name = 'de_published_LogicExt_ui_grid_dtl_pkey')
begin
	alter table de_published_LogicExt_ui_grid_dtl drop constraint de_published_LogicExt_ui_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_message_pkey')
begin
	alter table de_published_message drop constraint de_published_message_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_message_lng_extn_pkey')
begin
	alter table de_published_message_lng_extn drop constraint de_published_message_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_method_doc_pkey')
begin
	alter table de_published_method_doc drop constraint de_published_method_doc_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_method_doc_lng_extn_pkey')
begin
	alter table de_published_method_doc_lng_extn drop constraint de_published_method_doc_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_method_message_map_pkey')
begin
	alter table de_published_method_message_map drop constraint de_published_method_message_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_method_message_map_lng_extn_pkey')
begin
	alter table de_published_method_message_map_lng_extn drop constraint de_published_method_message_map_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_nativeapp_mapping_PK')
begin
	alter table de_published_nativeapp_mapping drop constraint de_published_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_non_ui_control_pkey')
begin
	alter table de_published_non_ui_control drop constraint de_published_non_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_pkey')
begin
	alter table de_published_phone drop constraint de_published_phone_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_columngroup_pkey')
begin
	alter table de_published_phone_columngroup drop constraint de_published_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_control_pkey')
begin
	alter table de_published_phone_control drop constraint de_published_phone_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_grid_pkey')
begin
	alter table de_published_phone_grid drop constraint de_published_phone_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_page_pkey')
begin
	alter table de_published_phone_page drop constraint de_published_phone_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_phone_section_pkey')
begin
	alter table de_published_phone_section drop constraint de_published_phone_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_pivot_fields_pkey')
begin
	alter table de_published_pivot_fields drop constraint de_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_precision_type_pkey')
begin
	alter table de_published_precision_type drop constraint de_published_precision_type_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_publication_pkey')
begin
	alter table de_published_publication drop constraint de_published_publication_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_publication_dataitem_published_flow_direction')
begin
	alter table de_published_publication_dataitem drop constraint Chk_de_published_publication_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_published_publication_dataitem_pkey')
begin
	alter table de_published_publication_dataitem drop constraint de_published_publication_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_publication_lng_extn_pkey')
begin
	alter table de_published_publication_lng_extn drop constraint de_published_publication_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_radio_button_default_flag')
begin
	alter table de_published_radio_button drop constraint Chk_de_published_radio_button_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_radio_button_pkey')
begin
	alter table de_published_radio_button drop constraint de_published_radio_button_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_radio_button_lng_extn_default_flag')
begin
	alter table de_published_radio_button_lng_extn drop constraint Chk_de_published_radio_button_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_radio_button_lng_extn_pkey')
begin
	alter table de_published_radio_button_lng_extn drop constraint de_published_radio_button_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_chart_service_dataitem_pkey')
begin
	alter table de_published_refine_chart_service_dataitem drop constraint de_published_refine_chart_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_chart_service_segment_pkey')
begin
	alter table de_published_refine_chart_service_segment drop constraint de_published_refine_chart_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_method_documentation_pkey')
begin
	alter table de_published_refine_method_documentation drop constraint de_published_refine_method_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_method_error_map_pkey')
begin
	alter table de_published_refine_method_error_map drop constraint de_published_refine_method_error_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_methods_pkey')
begin
	alter table de_published_refine_methods drop constraint de_published_refine_methods_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_parameter_pkey')
begin
	alter table de_published_refine_parameter drop constraint de_published_refine_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_refine_process_section_pkey')
begin
	alter table de_published_refine_process_section drop constraint de_published_refine_process_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_report_action_dataset_dataitem_PK')
begin
	alter table de_published_report_action_dataset_dataitem drop constraint de_published_report_action_dataset_dataitem_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_report_action_dataset_segment_PK')
begin
	alter table de_published_report_action_dataset_segment drop constraint de_published_report_action_dataset_segment_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_report_attributes_PK')
begin
	alter table de_published_report_attributes drop constraint de_published_report_attributes_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_report_dataset_dataitem_map_PK')
begin
	alter table de_published_report_dataset_dataitem_map drop constraint de_published_report_dataset_dataitem_map_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_report_dataset_segment_map_PK')
begin
	alter table de_published_report_dataset_segment_map drop constraint de_published_report_dataset_segment_map_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_resolved_link_pkey')
begin
	alter table de_published_resolved_link drop constraint de_published_resolved_link_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_resolved_link_dataitem_published_flow_direction')
begin
	alter table de_published_resolved_link_dataitem drop constraint Chk_de_published_resolved_link_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_resolved_link_dataitem_subscribed_flow_direction')
begin
	alter table de_published_resolved_link_dataitem drop constraint Chk_de_published_resolved_link_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_published_resolved_link_dataitem_pkey')
begin
	alter table de_published_resolved_link_dataitem drop constraint de_published_resolved_link_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_resolvelist_data_map_pkey')
begin
	alter table de_published_resolvelist_data_map drop constraint de_published_resolvelist_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_rmt_ico_ui_pkey')
begin
	alter table de_published_rmt_ico_ui drop constraint de_published_rmt_ico_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_rulegroup_exposed_flag')
begin
	alter table de_published_rulegroup drop constraint Chk_de_published_rulegroup_exposed_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_rulegroup_pkey')
begin
	alter table de_published_rulegroup drop constraint de_published_rulegroup_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_rulegroup_lng_extn_exposed_flag')
begin
	alter table de_published_rulegroup_lng_extn drop constraint Chk_de_published_rulegroup_lng_extn_exposed_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_rulegroup_lng_extn_pkey')
begin
	alter table de_published_rulegroup_lng_extn drop constraint de_published_rulegroup_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_rulegroup_step_pkey')
begin
	alter table de_published_rulegroup_step drop constraint de_published_rulegroup_step_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_rulegroup_step_msg_default_flag')
begin
	alter table de_published_rulegroup_step_msg drop constraint Chk_de_published_rulegroup_step_msg_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_rulegroup_step_msg_pkey')
begin
	alter table de_published_rulegroup_step_msg drop constraint de_published_rulegroup_step_msg_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_rulegroup_step_msg_lng_extn_default_flag')
begin
	alter table de_published_rulegroup_step_msg_lng_extn drop constraint Chk_de_published_rulegroup_step_msg_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_rulegroup_step_msg_lng_extn_pkey')
begin
	alter table de_published_rulegroup_step_msg_lng_extn drop constraint de_published_rulegroup_step_msg_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_column_pkey')
begin
	alter table de_published_schema_column drop constraint de_published_schema_column_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_dependentobj_pkey')
begin
	alter table de_published_schema_dependentobj drop constraint de_published_schema_dependentobj_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_function_pkey')
begin
	alter table de_published_schema_function drop constraint de_published_schema_function_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_function_param_pkey')
begin
	alter table de_published_schema_function_param drop constraint de_published_schema_function_param_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_index_pkey')
begin
	alter table de_published_schema_index drop constraint de_published_schema_index_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_index_columns_pkey')
begin
	alter table de_published_schema_index_columns drop constraint de_published_schema_index_columns_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_option_pkey')
begin
	alter table de_published_schema_option drop constraint de_published_schema_option_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_preference_pkey')
begin
	alter table de_published_schema_preference drop constraint de_published_schema_preference_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_relation_pkey')
begin
	alter table de_published_schema_relation drop constraint de_published_schema_relation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_relation_det_pkey')
begin
	alter table de_published_schema_relation_det drop constraint de_published_schema_relation_det_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_scripts_pkey')
begin
	alter table de_published_schema_scripts drop constraint de_published_schema_scripts_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_sp_pkey')
begin
	alter table de_published_schema_sp drop constraint de_published_schema_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_sp_param_pkey')
begin
	alter table de_published_schema_sp_param drop constraint de_published_schema_sp_param_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_table_pkey')
begin
	alter table de_published_schema_table drop constraint de_published_schema_table_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_udd_pkey')
begin
	alter table de_published_schema_udd drop constraint de_published_schema_udd_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_validation_log_pkey')
begin
	alter table de_published_schema_validation_log drop constraint de_published_schema_validation_log_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_view_pkey')
begin
	alter table de_published_schema_view drop constraint de_published_schema_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_schema_view_column_pkey')
begin
	alter table de_published_schema_view_column drop constraint de_published_schema_view_column_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_scratch_variables_sys_pkey')
begin
	alter table de_published_scratch_variables_sys drop constraint de_published_scratch_variables_sys_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_service_gen_log_pkey')
begin
	alter table de_published_service_gen_log drop constraint de_published_service_gen_log_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_service_gen_log_dtl_pkey')
begin
	alter table de_published_service_gen_log_dtl drop constraint de_published_service_gen_log_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_Published_service_logic_extn_dtl_pk')
begin
	alter table de_Published_service_logic_extn_dtl drop constraint de_Published_service_logic_extn_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_service_logic_extn_pattern_pk')
begin
	alter table de_published_service_logic_extn_pattern drop constraint de_published_service_logic_extn_pattern_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_sp_report_action_dataitem_PK')
begin
	alter table de_published_sp_report_action_dataitem drop constraint de_published_sp_report_action_dataitem_PK
end

if exists(select 'x' from sysobjects where name = 'de_published_sp_report_action_segment_PK')
begin
	alter table de_published_sp_report_action_segment drop constraint de_published_sp_report_action_segment_PK
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_subscription_link_type')
begin
	alter table de_published_subscription drop constraint Chk_de_published_subscription_link_type
end

if exists(select 'x' from sysobjects where name = 'de_published_subscription_pkey')
begin
	alter table de_published_subscription drop constraint de_published_subscription_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_subscription_dataitem_subscribed_flow_direction')
begin
	alter table de_published_subscription_dataitem drop constraint Chk_de_published_subscription_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_published_subscription_dataitem_pkey')
begin
	alter table de_published_subscription_dataitem drop constraint de_published_subscription_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_subscription_lng_extn_link_type')
begin
	alter table de_published_subscription_lng_extn drop constraint Chk_de_published_subscription_lng_extn_link_type
end

if exists(select 'x' from sysobjects where name = 'de_published_subscription_lng_extn_pkey')
begin
	alter table de_published_subscription_lng_extn drop constraint de_published_subscription_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_pkey')
begin
	alter table de_published_tablet drop constraint de_published_tablet_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_columngroup_pkey')
begin
	alter table de_published_tablet_columngroup drop constraint de_published_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_control_pkey')
begin
	alter table de_published_tablet_control drop constraint de_published_tablet_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_grid_pkey')
begin
	alter table de_published_tablet_grid drop constraint de_published_tablet_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_page_pkey')
begin
	alter table de_published_tablet_page drop constraint de_published_tablet_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_tablet_section_pkey')
begin
	alter table de_published_tablet_section drop constraint de_published_tablet_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_task_control_attributemap_pkey')
begin
	alter table de_published_task_control_attributemap drop constraint de_published_task_control_attributemap_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_task_control_map_map_flag')
begin
	alter table de_published_task_control_map drop constraint Chk_de_published_task_control_map_map_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_task_control_map_map_ml_flag')
begin
	alter table de_published_task_control_map drop constraint Chk_de_published_task_control_map_map_ml_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_task_control_map_pkey')
begin
	alter table de_published_task_control_map drop constraint de_published_task_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_task_service_map_pkey')
begin
	alter table de_published_task_service_map drop constraint de_published_task_service_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_caption_alignment')
begin
	alter table de_published_ui drop constraint Chk_de_published_ui_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_trail_bar')
begin
	alter table de_published_ui drop constraint Chk_de_published_ui_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_ui_format')
begin
	alter table de_published_ui drop constraint Chk_de_published_ui_ui_format
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_pkey')
begin
	alter table de_published_ui drop constraint de_published_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_columngroup_pkey')
begin
	alter table de_published_ui_columngroup drop constraint de_published_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_combolink_pkey')
begin
	alter table de_published_ui_combolink drop constraint de_published_ui_combolink_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_contextmenu_task_dtl_pk')
begin
	alter table de_published_ui_contextmenu_task_dtl drop constraint de_published_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_control_pkey')
begin
	alter table de_published_ui_control drop constraint de_published_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_control_lng_extn_pkey')
begin
	alter table de_published_ui_control_lng_extn drop constraint de_published_ui_control_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_device_pkey')
begin
	alter table de_published_ui_device drop constraint de_published_ui_device_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_device_control_pkey')
begin
	alter table de_published_ui_device_control drop constraint de_published_ui_device_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_device_grid_pkey')
begin
	alter table de_published_ui_device_grid drop constraint de_published_ui_device_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_device_page_pkey')
begin
	alter table de_published_ui_device_page drop constraint de_published_ui_device_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_device_section_pkey')
begin
	alter table de_published_ui_device_section drop constraint de_published_ui_device_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_displaytext_lang_extn_pkey')
begin
	alter table de_published_ui_displaytext_lang_extn drop constraint de_published_ui_displaytext_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_grid_pkey')
begin
	alter table de_published_ui_grid drop constraint de_published_ui_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_grid_lng_extn_pkey')
begin
	alter table de_published_ui_grid_lng_extn drop constraint de_published_ui_grid_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_ico_pkey')
begin
	alter table de_published_ui_ico drop constraint de_published_ui_ico_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_lng_extn_caption_alignment')
begin
	alter table de_published_ui_lng_extn drop constraint Chk_de_published_ui_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_lng_extn_trail_bar')
begin
	alter table de_published_ui_lng_extn drop constraint Chk_de_published_ui_lng_extn_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_lng_extn_ui_format')
begin
	alter table de_published_ui_lng_extn drop constraint Chk_de_published_ui_lng_extn_ui_format
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_lng_extn_pkey')
begin
	alter table de_published_ui_lng_extn drop constraint de_published_ui_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_page_pkey')
begin
	alter table de_published_ui_page drop constraint de_published_ui_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_page_lng_extn_pkey')
begin
	alter table de_published_ui_page_lng_extn drop constraint de_published_ui_page_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_pageevents_pk')
begin
	alter table de_published_ui_pageevents drop constraint de_published_ui_pageevents_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_placeholder_lng_extn_pk')
begin
	alter table de_published_ui_placeholder_lng_extn drop constraint de_published_ui_placeholder_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_border_required')
begin
	alter table de_published_ui_section drop constraint Chk_de_published_ui_section_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_title_alignment')
begin
	alter table de_published_ui_section drop constraint Chk_de_published_ui_section_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_title_required')
begin
	alter table de_published_ui_section drop constraint Chk_de_published_ui_section_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_visisble_flag')
begin
	alter table de_published_ui_section drop constraint Chk_de_published_ui_section_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_section_pkey')
begin
	alter table de_published_ui_section drop constraint de_published_ui_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_section_control_map_pkey')
begin
	alter table de_published_ui_section_control_map drop constraint de_published_ui_section_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_lng_extn_border_required')
begin
	alter table de_published_ui_section_lng_extn drop constraint Chk_de_published_ui_section_lng_extn_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_lng_extn_title_alignment')
begin
	alter table de_published_ui_section_lng_extn drop constraint Chk_de_published_ui_section_lng_extn_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_lng_extn_title_required')
begin
	alter table de_published_ui_section_lng_extn drop constraint Chk_de_published_ui_section_lng_extn_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_section_lng_extn_visisble_flag')
begin
	alter table de_published_ui_section_lng_extn drop constraint Chk_de_published_ui_section_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_section_lng_extn_pkey')
begin
	alter table de_published_ui_section_lng_extn drop constraint de_published_ui_section_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_pkey')
begin
	alter table de_published_ui_state drop constraint de_published_ui_state_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_control_Fkey_de_published_ui_control')
begin
	alter table de_published_ui_state_control drop constraint de_published_ui_state_control_Fkey_de_published_ui_control
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_control_pkey')
begin
	alter table de_published_ui_state_control drop constraint de_published_ui_state_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_section_Fkey_de_published_ui_section')
begin
	alter table de_published_ui_state_section drop constraint de_published_ui_state_section_Fkey_de_published_ui_section
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_section_pkey')
begin
	alter table de_published_ui_state_section drop constraint de_published_ui_state_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_task_pkey')
begin
	alter table de_published_ui_state_task drop constraint de_published_ui_state_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_state_task_mst_pkey')
begin
	alter table de_published_ui_state_task_mst drop constraint de_published_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_taskpane_pk')
begin
	alter table de_published_ui_taskpane drop constraint de_published_ui_taskpane_pk
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_toolbar_pkey')
begin
	alter table de_published_ui_toolbar drop constraint de_published_ui_toolbar_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_toolbar_group_pkey')
begin
	alter table de_published_ui_toolbar_group drop constraint de_published_ui_toolbar_group_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_toolbar_mapping_pkey')
begin
	alter table de_published_ui_toolbar_mapping drop constraint de_published_ui_toolbar_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_tooltip_lng_extn_pk')
begin
	alter table de_published_ui_tooltip_lng_extn drop constraint de_published_ui_tooltip_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_ui_traversal_link_type')
begin
	alter table de_published_ui_traversal drop constraint Chk_de_published_ui_traversal_link_type
end

if exists(select 'x' from sysobjects where name = 'de_published_ui_traversal_pkey')
begin
	alter table de_published_ui_traversal drop constraint de_published_ui_traversal_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_user_section_pkey')
begin
	alter table de_published_user_section drop constraint de_published_user_section_pkey
end

if exists(select 'x' from sysobjects where name = 'pk_de_published_wsinp_ecn_dtl')
begin
	alter table de_published_wsinp_ecn_dtl drop constraint pk_de_published_wsinp_ecn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_published_wsinp_is_control_dtl')
begin
	alter table de_published_wsinp_is_control_dtl drop constraint pk_de_published_wsinp_is_control_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_published_wsinp_mypage_control_dtl')
begin
	alter table de_published_wsinp_mypage_control_dtl drop constraint pk_de_published_wsinp_mypage_control_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_published_wsinp_service_dtl')
begin
	alter table de_published_wsinp_service_dtl drop constraint pk_de_published_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_published_wsinp_task_dtl')
begin
	alter table de_published_wsinp_task_dtl drop constraint pk_de_published_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_appvw_dtl')
begin
	alter table de_re_published_wsinp_appvw_dtl drop constraint pk_de_re_published_wsinp_appvw_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_area_desc')
begin
	alter table de_re_published_wsinp_area_desc drop constraint pk_de_re_published_wsinp_area_desc
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_area_dtl')
begin
	alter table de_re_published_wsinp_area_dtl drop constraint pk_de_re_published_wsinp_area_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_area_hdr')
begin
	alter table de_re_published_wsinp_area_hdr drop constraint pk_de_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_cat_desc_hdr')
begin
	alter table de_re_published_wsinp_cat_desc_hdr drop constraint pk_de_re_published_wsinp_cat_desc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_cat_hdr')
begin
	alter table de_re_published_wsinp_cat_hdr drop constraint pk_de_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_cat_parameters')
begin
	alter table de_re_published_wsinp_cat_parameters drop constraint pk_de_re_published_wsinp_cat_parameters
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_con_security')
begin
	alter table de_re_published_wsinp_con_security drop constraint pk_de_re_published_wsinp_con_security
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_def_msg_dtl')
begin
	alter table de_re_published_wsinp_def_msg_dtl drop constraint pk_de_re_published_wsinp_def_msg_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_def_wf_setup')
begin
	alter table de_re_published_wsinp_def_wf_setup drop constraint pk_de_re_published_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_doc_flow_dtl')
begin
	alter table de_re_published_wsinp_doc_flow_dtl drop constraint pk_de_re_published_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_docflow_msg_dtl')
begin
	alter table de_re_published_wsinp_docflow_msg_dtl drop constraint pk_de_re_published_wsinp_docflow_msg_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_actcode')
begin
	alter table de_re_published_wsinp_nonrvw_actcode drop constraint pk_de_re_published_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_actdesc')
begin
	alter table de_re_published_wsinp_nonrvw_actdesc drop constraint pk_de_re_published_wsinp_nonrvw_actdesc
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_compcode')
begin
	alter table de_re_published_wsinp_nonrvw_compcode drop constraint pk_de_re_published_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_compdesc')
begin
	alter table de_re_published_wsinp_nonrvw_compdesc drop constraint pk_de_re_published_wsinp_nonrvw_compdesc
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_taskcode')
begin
	alter table de_re_published_wsinp_nonrvw_taskcode drop constraint pk_de_re_published_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_nonrvw_taskdesc')
begin
	alter table de_re_published_wsinp_nonrvw_taskdesc drop constraint pk_de_re_published_wsinp_nonrvw_taskdesc
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_qc_dtl')
begin
	alter table de_re_published_wsinp_qc_dtl drop constraint pk_de_re_published_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_qc_hdr')
begin
	alter table de_re_published_wsinp_qc_hdr drop constraint pk_de_re_published_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_qc_lang_dtl')
begin
	alter table de_re_published_wsinp_qc_lang_dtl drop constraint pk_de_re_published_wsinp_qc_lang_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_rcn_dtl')
begin
	alter table de_re_published_wsinp_rcn_dtl drop constraint pk_de_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_security_dtl')
begin
	alter table de_re_published_wsinp_security_dtl drop constraint pk_de_re_published_wsinp_security_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_secusr_dtl')
begin
	alter table de_re_published_wsinp_secusr_dtl drop constraint pk_de_re_published_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_service_dtl')
begin
	alter table de_re_published_wsinp_service_dtl drop constraint pk_de_re_published_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_state_desc_dtl')
begin
	alter table de_re_published_wsinp_state_desc_dtl drop constraint pk_de_re_published_wsinp_state_desc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_task_dtl')
begin
	alter table de_re_published_wsinp_task_dtl drop constraint pk_de_re_published_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_tsk_state_dtl')
begin
	alter table de_re_published_wsinp_tsk_state_dtl drop constraint pk_de_re_published_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_tsk_stflow_dtl')
begin
	alter table de_re_published_wsinp_tsk_stflow_dtl drop constraint pk_de_re_published_wsinp_tsk_stflow_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_published_wsinp_usr_noncon_task')
begin
	alter table de_re_published_wsinp_usr_noncon_task drop constraint pk_de_re_published_wsinp_usr_noncon_task
end

if exists(select 'x' from sysobjects where name = 'pk_dtproperties')
begin
	alter table dtproperties drop constraint pk_dtproperties
end

if exists(select 'x' from sysobjects where name = 'ep_published_action_mst_pkey')
begin
	alter table ep_published_action_mst drop constraint ep_published_action_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_action_mst_lng_extn_pkey')
begin
	alter table ep_published_action_mst_lng_extn drop constraint ep_published_action_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_action_section_map_pkey')
begin
	alter table ep_published_action_section_map drop constraint ep_published_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_chart_header_pkey')
begin
	alter table ep_published_chart_header drop constraint ep_published_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_chart_sample_data_pkey')
begin
	alter table ep_published_chart_sample_data drop constraint ep_published_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_chart_series_pkey')
begin
	alter table ep_published_chart_series drop constraint ep_published_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_data_type')
begin
	alter table ep_published_comp_glossary_mst drop constraint Chk_ep_published_comp_glossary_mst_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_length')
begin
	alter table ep_published_comp_glossary_mst drop constraint Chk_ep_published_comp_glossary_mst_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_synonym_status')
begin
	alter table ep_published_comp_glossary_mst drop constraint Chk_ep_published_comp_glossary_mst_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_published_comp_glossary_mst_pkey')
begin
	alter table ep_published_comp_glossary_mst drop constraint ep_published_comp_glossary_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_lng_extn_data_type')
begin
	alter table ep_published_comp_glossary_mst_lng_extn drop constraint Chk_ep_published_comp_glossary_mst_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_lng_extn_length')
begin
	alter table ep_published_comp_glossary_mst_lng_extn drop constraint Chk_ep_published_comp_glossary_mst_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_glossary_mst_lng_extn_synonym_status')
begin
	alter table ep_published_comp_glossary_mst_lng_extn drop constraint Chk_ep_published_comp_glossary_mst_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_published_comp_glossary_mst_lng_extn_pkey')
begin
	alter table ep_published_comp_glossary_mst_lng_extn drop constraint ep_published_comp_glossary_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_contextual_links_pkey')
begin
	alter table ep_published_contextual_links drop constraint ep_published_contextual_links_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_control_extensions_pkey')
begin
	alter table ep_published_control_extensions drop constraint ep_published_control_extensions_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_custom_listedit_pkey')
begin
	alter table ep_published_custom_listedit drop constraint ep_published_custom_listedit_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_enum_value_dtl_default_flag')
begin
	alter table ep_published_enum_value_dtl drop constraint Chk_ep_published_enum_value_dtl_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_enum_value_dtl_pkey')
begin
	alter table ep_published_enum_value_dtl drop constraint ep_published_enum_value_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_enum_value_dtl_lng_extn_default_flag')
begin
	alter table ep_published_enum_value_dtl_lng_extn drop constraint Chk_ep_published_enum_value_dtl_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_enum_value_dtl_lng_extn_pkey')
begin
	alter table ep_published_enum_value_dtl_lng_extn drop constraint ep_published_enum_value_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ext_js_control_dtl_PK')
begin
	alter table ep_published_ext_js_control_dtl drop constraint ep_published_ext_js_control_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_ext_js_section_column_dtl_PK')
begin
	alter table ep_published_ext_js_section_column_dtl drop constraint ep_published_ext_js_section_column_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_ext_js_section_dtl_PK')
begin
	alter table ep_published_ext_js_section_dtl drop constraint ep_published_ext_js_section_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_ezeeview_sp_PK')
begin
	alter table ep_published_ezeeview_sp drop constraint ep_published_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_ezeeview_spparamlist_PK')
begin
	alter table ep_published_ezeeview_spparamlist drop constraint ep_published_ezeeview_spparamlist_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_flowbr_mst_pkey')
begin
	alter table ep_published_flowbr_mst drop constraint ep_published_flowbr_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_data_type')
begin
	alter table ep_published_glossary_mst drop constraint Chk_ep_published_glossary_mst_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_length')
begin
	alter table ep_published_glossary_mst drop constraint Chk_ep_published_glossary_mst_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_synonym_status')
begin
	alter table ep_published_glossary_mst drop constraint Chk_ep_published_glossary_mst_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_published_glossary_mst_pkey')
begin
	alter table ep_published_glossary_mst drop constraint ep_published_glossary_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_lng_extn_data_type')
begin
	alter table ep_published_glossary_mst_lng_extn drop constraint Chk_ep_published_glossary_mst_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_lng_extn_length')
begin
	alter table ep_published_glossary_mst_lng_extn drop constraint Chk_ep_published_glossary_mst_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_glossary_mst_lng_extn_synonym_status')
begin
	alter table ep_published_glossary_mst_lng_extn drop constraint Chk_ep_published_glossary_mst_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_published_glossary_mst_lng_extn_pkey')
begin
	alter table ep_published_glossary_mst_lng_extn drop constraint ep_published_glossary_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_listedit_column_dtl_pkey')
begin
	alter table ep_published_listedit_column_dtl drop constraint ep_published_listedit_column_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_listedit_control_map_pkey')
begin
	alter table ep_published_listedit_control_map drop constraint ep_published_listedit_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_nativeapp_mapping_PK')
begin
	alter table ep_published_nativeapp_mapping drop constraint ep_published_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_columngroup_pkey')
begin
	alter table ep_published_phone_columngroup drop constraint ep_published_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_control_dtl_pkey')
begin
	alter table ep_published_phone_control_dtl drop constraint ep_published_phone_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_grid_dtl_pkey')
begin
	alter table ep_published_phone_grid_dtl drop constraint ep_published_phone_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_mst_pkey')
begin
	alter table ep_published_phone_mst drop constraint ep_published_phone_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_page_dtl_pkey')
begin
	alter table ep_published_phone_page_dtl drop constraint ep_published_phone_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_phone_section_dtl_pkey')
begin
	alter table ep_published_phone_section_dtl drop constraint ep_published_phone_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_pivot_fields_pkey')
begin
	alter table ep_published_pivot_fields drop constraint ep_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_radio_button_dtl_default_flag')
begin
	alter table ep_published_radio_button_dtl drop constraint Chk_ep_published_radio_button_dtl_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_radio_button_dtl_pkey')
begin
	alter table ep_published_radio_button_dtl drop constraint ep_published_radio_button_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_radio_button_dtl_lng_extn_default_flag')
begin
	alter table ep_published_radio_button_dtl_lng_extn drop constraint Chk_ep_published_radio_button_dtl_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_radio_button_dtl_lng_extn_pkey')
begin
	alter table ep_published_radio_button_dtl_lng_extn drop constraint ep_published_radio_button_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_resolvelist_data_map_pkey')
begin
	alter table ep_published_resolvelist_data_map drop constraint ep_published_resolvelist_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_columngroup_pkey')
begin
	alter table ep_published_tablet_columngroup drop constraint ep_published_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_control_dtl_pkey')
begin
	alter table ep_published_tablet_control_dtl drop constraint ep_published_tablet_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_grid_dtl_pkey')
begin
	alter table ep_published_tablet_grid_dtl drop constraint ep_published_tablet_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_mst_pkey')
begin
	alter table ep_published_tablet_mst drop constraint ep_published_tablet_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_page_dtl_pkey')
begin
	alter table ep_published_tablet_page_dtl drop constraint ep_published_tablet_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tablet_section_dtl_pkey')
begin
	alter table ep_published_tablet_section_dtl drop constraint ep_published_tablet_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tree_sample_data_pkey')
begin
	alter table ep_published_tree_sample_data drop constraint ep_published_tree_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_tree_sample_data_map_fkey_ep_published_tree_sample_data')
begin
	alter table ep_published_tree_sample_data_map drop constraint ep_published_tree_sample_data_map_fkey_ep_published_tree_sample_data
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_columngroup_pkey')
begin
	alter table ep_published_ui_columngroup drop constraint ep_published_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_combolink_dtl_pkey')
begin
	alter table ep_published_ui_combolink_dtl drop constraint ep_published_ui_combolink_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_contextmenu_task_dtl_pk')
begin
	alter table ep_published_ui_contextmenu_task_dtl drop constraint ep_published_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_control_dtl_pkey')
begin
	alter table ep_published_ui_control_dtl drop constraint ep_published_ui_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_control_dtl_lng_extn_pkey')
begin
	alter table ep_published_ui_control_dtl_lng_extn drop constraint ep_published_ui_control_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_device_control_dtl_pkey')
begin
	alter table ep_published_ui_device_control_dtl drop constraint ep_published_ui_device_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_device_dtl_pkey')
begin
	alter table ep_published_ui_device_dtl drop constraint ep_published_ui_device_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_device_grid_dtl_pkey')
begin
	alter table ep_published_ui_device_grid_dtl drop constraint ep_published_ui_device_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_device_page_dtl_pkey')
begin
	alter table ep_published_ui_device_page_dtl drop constraint ep_published_ui_device_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_device_section_dtl_pkey')
begin
	alter table ep_published_ui_device_section_dtl drop constraint ep_published_ui_device_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_displaytext_lang_extn_pkey')
begin
	alter table ep_published_ui_displaytext_lang_extn drop constraint ep_published_ui_displaytext_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_grid_dtl_pkey')
begin
	alter table ep_published_ui_grid_dtl drop constraint ep_published_ui_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_grid_dtl_lng_extn_pkey')
begin
	alter table ep_published_ui_grid_dtl_lng_extn drop constraint ep_published_ui_grid_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_caption_alignment')
begin
	alter table ep_published_ui_mst drop constraint Chk_ep_published_ui_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_trail_bar')
begin
	alter table ep_published_ui_mst drop constraint Chk_ep_published_ui_mst_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_ui_format')
begin
	alter table ep_published_ui_mst drop constraint Chk_ep_published_ui_mst_ui_format
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_mst_pkey')
begin
	alter table ep_published_ui_mst drop constraint ep_published_ui_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_lng_extn_caption_alignment')
begin
	alter table ep_published_ui_mst_lng_extn drop constraint Chk_ep_published_ui_mst_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_lng_extn_trail_bar')
begin
	alter table ep_published_ui_mst_lng_extn drop constraint Chk_ep_published_ui_mst_lng_extn_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_mst_lng_extn_ui_format')
begin
	alter table ep_published_ui_mst_lng_extn drop constraint Chk_ep_published_ui_mst_lng_extn_ui_format
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_mst_lng_extn_pkey')
begin
	alter table ep_published_ui_mst_lng_extn drop constraint ep_published_ui_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_page_dtl_pkey')
begin
	alter table ep_published_ui_page_dtl drop constraint ep_published_ui_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_page_dtl_lng_extn_pkey')
begin
	alter table ep_published_ui_page_dtl_lng_extn drop constraint ep_published_ui_page_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_pageevents_dtl_pk')
begin
	alter table ep_published_ui_pageevents_dtl drop constraint ep_published_ui_pageevents_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_placeholder_dtl_lng_extn_pk')
begin
	alter table ep_published_ui_placeholder_dtl_lng_extn drop constraint ep_published_ui_placeholder_dtl_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_section_control_map_dtl_pkey')
begin
	alter table ep_published_ui_section_control_map_dtl drop constraint ep_published_ui_section_control_map_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_border_required')
begin
	alter table ep_published_ui_section_dtl drop constraint Chk_ep_published_ui_section_dtl_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_title_alignment')
begin
	alter table ep_published_ui_section_dtl drop constraint Chk_ep_published_ui_section_dtl_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_title_required')
begin
	alter table ep_published_ui_section_dtl drop constraint Chk_ep_published_ui_section_dtl_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_visisble_flag')
begin
	alter table ep_published_ui_section_dtl drop constraint Chk_ep_published_ui_section_dtl_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_section_dtl_pkey')
begin
	alter table ep_published_ui_section_dtl drop constraint ep_published_ui_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_lng_extn_border_required')
begin
	alter table ep_published_ui_section_dtl_lng_extn drop constraint Chk_ep_published_ui_section_dtl_lng_extn_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_lng_extn_title_alignment')
begin
	alter table ep_published_ui_section_dtl_lng_extn drop constraint Chk_ep_published_ui_section_dtl_lng_extn_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_lng_extn_title_required')
begin
	alter table ep_published_ui_section_dtl_lng_extn drop constraint Chk_ep_published_ui_section_dtl_lng_extn_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_section_dtl_lng_extn_visisble_flag')
begin
	alter table ep_published_ui_section_dtl_lng_extn drop constraint Chk_ep_published_ui_section_dtl_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_section_dtl_lng_extn_pkey')
begin
	alter table ep_published_ui_section_dtl_lng_extn drop constraint ep_published_ui_section_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_control_dtl_Fkey_ep_published_ui_control_dtl')
begin
	alter table ep_published_ui_state_control_dtl drop constraint ep_published_ui_state_control_dtl_Fkey_ep_published_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_control_dtl_pkey')
begin
	alter table ep_published_ui_state_control_dtl drop constraint ep_published_ui_state_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_dtl_pkey')
begin
	alter table ep_published_ui_state_dtl drop constraint ep_published_ui_state_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_section_dtl_Fkey_ep_published_ui_section_dtl')
begin
	alter table ep_published_ui_state_section_dtl drop constraint ep_published_ui_state_section_dtl_Fkey_ep_published_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_section_dtl_pkey')
begin
	alter table ep_published_ui_state_section_dtl drop constraint ep_published_ui_state_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_task_dtl_pkey')
begin
	alter table ep_published_ui_state_task_dtl drop constraint ep_published_ui_state_task_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_state_task_mst_pkey')
begin
	alter table ep_published_ui_state_task_mst drop constraint ep_published_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_toolbar_dtl_pkey')
begin
	alter table ep_published_ui_toolbar_dtl drop constraint ep_published_ui_toolbar_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_toolbar_group_dtl_pkey')
begin
	alter table ep_published_ui_toolbar_group_dtl drop constraint ep_published_ui_toolbar_group_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_toolbar_mapping_dtl_pkey')
begin
	alter table ep_published_ui_toolbar_mapping_dtl drop constraint ep_published_ui_toolbar_mapping_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_tooltip_dtl_lng_extn_pk')
begin
	alter table ep_published_ui_tooltip_dtl_lng_extn drop constraint ep_published_ui_tooltip_dtl_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_ui_traversal_dtl_link_type')
begin
	alter table ep_published_ui_traversal_dtl drop constraint Chk_ep_published_ui_traversal_dtl_link_type
end

if exists(select 'x' from sysobjects where name = 'ep_published_ui_traversal_dtl_pkey')
begin
	alter table ep_published_ui_traversal_dtl drop constraint ep_published_ui_traversal_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_user_section_dtl_pkey')
begin
	alter table ep_published_user_section_dtl drop constraint ep_published_user_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_action_pkey')
begin
	alter table re_published_action drop constraint re_published_action_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_action_lng_extn_pkey')
begin
	alter table re_published_action_lng_extn drop constraint re_published_action_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_action_section_map_pkey')
begin
	alter table re_published_action_section_map drop constraint re_published_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_business_rule_pkey')
begin
	alter table re_published_business_rule drop constraint re_published_business_rule_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_business_rule_lng_extn_pkey')
begin
	alter table re_published_business_rule_lng_extn drop constraint re_published_business_rule_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_chart_header_pkey')
begin
	alter table re_published_chart_header drop constraint re_published_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_chart_sample_data_pkey')
begin
	alter table re_published_chart_sample_data drop constraint re_published_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_chart_series_pkey')
begin
	alter table re_published_chart_series drop constraint re_published_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_contextual_links_pkey')
begin
	alter table re_published_contextual_links drop constraint re_published_contextual_links_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_control_extensions_pkey')
begin
	alter table re_published_control_extensions drop constraint re_published_control_extensions_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_custom_listedit_pkey')
begin
	alter table re_published_custom_listedit drop constraint re_published_custom_listedit_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_enum_value_default_flag')
begin
	alter table re_published_enum_value drop constraint Chk_re_published_enum_value_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_enum_value_pkey')
begin
	alter table re_published_enum_value drop constraint re_published_enum_value_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_enum_value_lng_extn_default_flag')
begin
	alter table re_published_enum_value_lng_extn drop constraint Chk_re_published_enum_value_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_enum_value_lng_extn_pkey')
begin
	alter table re_published_enum_value_lng_extn drop constraint re_published_enum_value_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ext_js_control_PK')
begin
	alter table re_published_ext_js_control drop constraint re_published_ext_js_control_PK
end

if exists(select 'x' from sysobjects where name = 're_published_ext_js_section_PK')
begin
	alter table re_published_ext_js_section drop constraint re_published_ext_js_section_PK
end

if exists(select 'x' from sysobjects where name = 're_published_ext_js_section_column_PK')
begin
	alter table re_published_ext_js_section_column drop constraint re_published_ext_js_section_column_PK
end

if exists(select 'x' from sysobjects where name = 're_published_ezeeview_sp_PK')
begin
	alter table re_published_ezeeview_sp drop constraint re_published_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 're_published_ezeeview_spparamlist_PK')
begin
	alter table re_published_ezeeview_spparamlist drop constraint re_published_ezeeview_spparamlist_PK
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_res_ilbo_dataitem_pk')
begin
	alter table re_published_ezwiz_res_ilbo_dataitem drop constraint re_published_ezwiz_res_ilbo_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_res_step_dataitem_pk')
begin
	alter table re_published_ezwiz_res_step_dataitem drop constraint re_published_ezwiz_res_step_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_wizard_pk')
begin
	alter table re_published_ezwiz_wizard drop constraint re_published_ezwiz_wizard_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_wizard_local_info_pk')
begin
	alter table re_published_ezwiz_wizard_local_info drop constraint re_published_ezwiz_wizard_local_info_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_wizard_step_pk')
begin
	alter table re_published_ezwiz_wizard_step drop constraint re_published_ezwiz_wizard_step_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ezwiz_wizard_step_local_info_pk')
begin
	alter table re_published_ezwiz_wizard_step_local_info drop constraint re_published_ezwiz_wizard_step_local_info_pk
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_pkey')
begin
	alter table re_published_flowbr drop constraint re_published_flowbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_flowbr_br_error_default_flag')
begin
	alter table re_published_flowbr_br_error drop constraint Chk_re_published_flowbr_br_error_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_br_error_pkey')
begin
	alter table re_published_flowbr_br_error drop constraint re_published_flowbr_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_flowbr_br_error_lng_extn_default_flag')
begin
	alter table re_published_flowbr_br_error_lng_extn drop constraint Chk_re_published_flowbr_br_error_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_br_error_lng_extn_pkey')
begin
	alter table re_published_flowbr_br_error_lng_extn drop constraint re_published_flowbr_br_error_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_combo_pkey')
begin
	alter table re_published_flowbr_combo drop constraint re_published_flowbr_combo_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_lng_extn_pkey')
begin
	alter table re_published_flowbr_lng_extn drop constraint re_published_flowbr_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_flowbr_rule_map_br_type')
begin
	alter table re_published_flowbr_rule_map drop constraint Chk_re_published_flowbr_rule_map_br_type
end

if exists(select 'x' from sysobjects where name = 're_published_flowbr_rule_map_pkey')
begin
	alter table re_published_flowbr_rule_map drop constraint re_published_flowbr_rule_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_data_type')
begin
	alter table re_published_glossary drop constraint Chk_re_published_glossary_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_length')
begin
	alter table re_published_glossary drop constraint Chk_re_published_glossary_length
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_synonym_status')
begin
	alter table re_published_glossary drop constraint Chk_re_published_glossary_synonym_status
end

if exists(select 'x' from sysobjects where name = 're_published_glossary_pkey')
begin
	alter table re_published_glossary drop constraint re_published_glossary_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_lng_extn_data_type')
begin
	alter table re_published_glossary_lng_extn drop constraint Chk_re_published_glossary_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_lng_extn_length')
begin
	alter table re_published_glossary_lng_extn drop constraint Chk_re_published_glossary_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_glossary_lng_extn_synonym_status')
begin
	alter table re_published_glossary_lng_extn drop constraint Chk_re_published_glossary_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 're_published_glossary_lng_extn_pkey')
begin
	alter table re_published_glossary_lng_extn drop constraint re_published_glossary_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_listedit_column_pkey')
begin
	alter table re_published_listedit_column drop constraint re_published_listedit_column_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_listedit_control_map_pkey')
begin
	alter table re_published_listedit_control_map drop constraint re_published_listedit_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_message_pkey')
begin
	alter table re_published_message drop constraint re_published_message_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_message_lng_extn_pkey')
begin
	alter table re_published_message_lng_extn drop constraint re_published_message_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_nativeapp_mapping_PK')
begin
	alter table re_published_nativeapp_mapping drop constraint re_published_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 're_published_non_ui_control_pkey')
begin
	alter table re_published_non_ui_control drop constraint re_published_non_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_pkey')
begin
	alter table re_published_phone drop constraint re_published_phone_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_columngroup_pkey')
begin
	alter table re_published_phone_columngroup drop constraint re_published_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_control_pkey')
begin
	alter table re_published_phone_control drop constraint re_published_phone_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_grid_pkey')
begin
	alter table re_published_phone_grid drop constraint re_published_phone_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_page_pkey')
begin
	alter table re_published_phone_page drop constraint re_published_phone_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_phone_section_pkey')
begin
	alter table re_published_phone_section drop constraint re_published_phone_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_pivot_fields_pkey')
begin
	alter table re_published_pivot_fields drop constraint re_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_publication_pkey')
begin
	alter table re_published_publication drop constraint re_published_publication_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_publication_dataitem_published_flow_direction')
begin
	alter table re_published_publication_dataitem drop constraint Chk_re_published_publication_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 're_published_publication_dataitem_pkey')
begin
	alter table re_published_publication_dataitem drop constraint re_published_publication_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_publication_lng_extn_pkey')
begin
	alter table re_published_publication_lng_extn drop constraint re_published_publication_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_radio_button_default_flag')
begin
	alter table re_published_radio_button drop constraint Chk_re_published_radio_button_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_radio_button_pkey')
begin
	alter table re_published_radio_button drop constraint re_published_radio_button_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_radio_button_lng_extn_default_flag')
begin
	alter table re_published_radio_button_lng_extn drop constraint Chk_re_published_radio_button_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_radio_button_lng_extn_pkey')
begin
	alter table re_published_radio_button_lng_extn drop constraint re_published_radio_button_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_report_action_dataset_pkey')
begin
	alter table re_published_report_action_dataset drop constraint re_published_report_action_dataset_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_resolved_link_pkey')
begin
	alter table re_published_resolved_link drop constraint re_published_resolved_link_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_resolved_link_dataitem_published_flow_direction')
begin
	alter table re_published_resolved_link_dataitem drop constraint Chk_re_published_resolved_link_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_resolved_link_dataitem_subscribed_flow_direction')
begin
	alter table re_published_resolved_link_dataitem drop constraint Chk_re_published_resolved_link_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 're_published_resolved_link_dataitem_pkey')
begin
	alter table re_published_resolved_link_dataitem drop constraint re_published_resolved_link_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_resolvelist_data_map_pkey')
begin
	alter table re_published_resolvelist_data_map drop constraint re_published_resolvelist_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_rulegroup_exposed_flag')
begin
	alter table re_published_rulegroup drop constraint Chk_re_published_rulegroup_exposed_flag
end

if exists(select 'x' from sysobjects where name = 're_published_rulegroup_pkey')
begin
	alter table re_published_rulegroup drop constraint re_published_rulegroup_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_rulegroup_lng_extn_exposed_flag')
begin
	alter table re_published_rulegroup_lng_extn drop constraint Chk_re_published_rulegroup_lng_extn_exposed_flag
end

if exists(select 'x' from sysobjects where name = 're_published_rulegroup_lng_extn_pkey')
begin
	alter table re_published_rulegroup_lng_extn drop constraint re_published_rulegroup_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_rulegroup_step_pkey')
begin
	alter table re_published_rulegroup_step drop constraint re_published_rulegroup_step_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_rulegroup_step_msg_default_flag')
begin
	alter table re_published_rulegroup_step_msg drop constraint Chk_re_published_rulegroup_step_msg_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_rulegroup_step_msg_pkey')
begin
	alter table re_published_rulegroup_step_msg drop constraint re_published_rulegroup_step_msg_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_rulegroup_step_msg_lng_extn_default_flag')
begin
	alter table re_published_rulegroup_step_msg_lng_extn drop constraint Chk_re_published_rulegroup_step_msg_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_published_rulegroup_step_msg_lng_extn_pkey')
begin
	alter table re_published_rulegroup_step_msg_lng_extn drop constraint re_published_rulegroup_step_msg_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_subscription_link_type')
begin
	alter table re_published_subscription drop constraint Chk_re_published_subscription_link_type
end

if exists(select 'x' from sysobjects where name = 're_published_subscription_pkey')
begin
	alter table re_published_subscription drop constraint re_published_subscription_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_subscription_dataitem_subscribed_flow_direction')
begin
	alter table re_published_subscription_dataitem drop constraint Chk_re_published_subscription_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 're_published_subscription_dataitem_pkey')
begin
	alter table re_published_subscription_dataitem drop constraint re_published_subscription_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_subscription_lng_extn_link_type')
begin
	alter table re_published_subscription_lng_extn drop constraint Chk_re_published_subscription_lng_extn_link_type
end

if exists(select 'x' from sysobjects where name = 're_published_subscription_lng_extn_pkey')
begin
	alter table re_published_subscription_lng_extn drop constraint re_published_subscription_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_pkey')
begin
	alter table re_published_tablet drop constraint re_published_tablet_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_columngroup_pkey')
begin
	alter table re_published_tablet_columngroup drop constraint re_published_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_control_pkey')
begin
	alter table re_published_tablet_control drop constraint re_published_tablet_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_grid_pkey')
begin
	alter table re_published_tablet_grid drop constraint re_published_tablet_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_page_pkey')
begin
	alter table re_published_tablet_page drop constraint re_published_tablet_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_tablet_section_pkey')
begin
	alter table re_published_tablet_section drop constraint re_published_tablet_section_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_caption_alignment')
begin
	alter table re_published_ui drop constraint Chk_re_published_ui_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_trail_bar')
begin
	alter table re_published_ui drop constraint Chk_re_published_ui_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_ui_format')
begin
	alter table re_published_ui drop constraint Chk_re_published_ui_ui_format
end

if exists(select 'x' from sysobjects where name = 're_published_ui_pkey')
begin
	alter table re_published_ui drop constraint re_published_ui_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_columngroup_pkey')
begin
	alter table re_published_ui_columngroup drop constraint re_published_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_combolink_pkey')
begin
	alter table re_published_ui_combolink drop constraint re_published_ui_combolink_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_contextmenu_task_dtl_pk')
begin
	alter table re_published_ui_contextmenu_task_dtl drop constraint re_published_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ui_control_pkey')
begin
	alter table re_published_ui_control drop constraint re_published_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_control_lng_extn_pkey')
begin
	alter table re_published_ui_control_lng_extn drop constraint re_published_ui_control_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_device_pkey')
begin
	alter table re_published_ui_device drop constraint re_published_ui_device_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_device_control_pkey')
begin
	alter table re_published_ui_device_control drop constraint re_published_ui_device_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_device_grid_pkey')
begin
	alter table re_published_ui_device_grid drop constraint re_published_ui_device_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_device_page_pkey')
begin
	alter table re_published_ui_device_page drop constraint re_published_ui_device_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_device_section_pkey')
begin
	alter table re_published_ui_device_section drop constraint re_published_ui_device_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_displaytext_lang_extn_pkey')
begin
	alter table re_published_ui_displaytext_lang_extn drop constraint re_published_ui_displaytext_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_grid_pkey')
begin
	alter table re_published_ui_grid drop constraint re_published_ui_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_grid_lng_extn_pkey')
begin
	alter table re_published_ui_grid_lng_extn drop constraint re_published_ui_grid_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_lng_extn_caption_alignment')
begin
	alter table re_published_ui_lng_extn drop constraint Chk_re_published_ui_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_lng_extn_trail_bar')
begin
	alter table re_published_ui_lng_extn drop constraint Chk_re_published_ui_lng_extn_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_lng_extn_ui_format')
begin
	alter table re_published_ui_lng_extn drop constraint Chk_re_published_ui_lng_extn_ui_format
end

if exists(select 'x' from sysobjects where name = 're_published_ui_lng_extn_pkey')
begin
	alter table re_published_ui_lng_extn drop constraint re_published_ui_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_page_pkey')
begin
	alter table re_published_ui_page drop constraint re_published_ui_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_page_lng_extn_pkey')
begin
	alter table re_published_ui_page_lng_extn drop constraint re_published_ui_page_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_pageevents_pk')
begin
	alter table re_published_ui_pageevents drop constraint re_published_ui_pageevents_pk
end

if exists(select 'x' from sysobjects where name = 're_published_ui_placeholder_lng_extn_pk')
begin
	alter table re_published_ui_placeholder_lng_extn drop constraint re_published_ui_placeholder_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_border_required')
begin
	alter table re_published_ui_section drop constraint Chk_re_published_ui_section_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_title_required')
begin
	alter table re_published_ui_section drop constraint Chk_re_published_ui_section_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_visisble_flag')
begin
	alter table re_published_ui_section drop constraint Chk_re_published_ui_section_visisble_flag
end

if exists(select 'x' from sysobjects where name = 're_published_ui_section_pkey')
begin
	alter table re_published_ui_section drop constraint re_published_ui_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_section_control_map_pkey')
begin
	alter table re_published_ui_section_control_map drop constraint re_published_ui_section_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_lng_extn_border_required')
begin
	alter table re_published_ui_section_lng_extn drop constraint Chk_re_published_ui_section_lng_extn_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_lng_extn_title_required')
begin
	alter table re_published_ui_section_lng_extn drop constraint Chk_re_published_ui_section_lng_extn_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_section_lng_extn_visisble_flag')
begin
	alter table re_published_ui_section_lng_extn drop constraint Chk_re_published_ui_section_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 're_published_ui_section_lng_extn_pkey')
begin
	alter table re_published_ui_section_lng_extn drop constraint re_published_ui_section_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_pkey')
begin
	alter table re_published_ui_state drop constraint re_published_ui_state_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_control_Fkey_re_published_ui_control')
begin
	alter table re_published_ui_state_control drop constraint re_published_ui_state_control_Fkey_re_published_ui_control
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_control_pkey')
begin
	alter table re_published_ui_state_control drop constraint re_published_ui_state_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_section_Fkey_re_published_ui_section')
begin
	alter table re_published_ui_state_section drop constraint re_published_ui_state_section_Fkey_re_published_ui_section
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_section_pkey')
begin
	alter table re_published_ui_state_section drop constraint re_published_ui_state_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_task_pkey')
begin
	alter table re_published_ui_state_task drop constraint re_published_ui_state_task_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_state_task_mst_pkey')
begin
	alter table re_published_ui_state_task_mst drop constraint re_published_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_toolbar_pkey')
begin
	alter table re_published_ui_toolbar drop constraint re_published_ui_toolbar_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_toolbar_group_pkey')
begin
	alter table re_published_ui_toolbar_group drop constraint re_published_ui_toolbar_group_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_toolbar_mapping_pkey')
begin
	alter table re_published_ui_toolbar_mapping drop constraint re_published_ui_toolbar_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_ui_tooltip_lng_extn_pk')
begin
	alter table re_published_ui_tooltip_lng_extn drop constraint re_published_ui_tooltip_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_ui_traversal_link_type')
begin
	alter table re_published_ui_traversal drop constraint Chk_re_published_ui_traversal_link_type
end

if exists(select 'x' from sysobjects where name = 're_published_ui_traversal_pkey')
begin
	alter table re_published_ui_traversal drop constraint re_published_ui_traversal_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_user_section_pkey')
begin
	alter table re_published_user_section drop constraint re_published_user_section_pkey
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_appvw_dtl')
begin
	alter table re_published_wsinp_appvw_dtl drop constraint pk_re_published_wsinp_appvw_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_appvw_dtl_fkey_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_appvw_dtl drop constraint re_published_wsinp_appvw_dtl_fkey_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_area_desc')
begin
	alter table re_published_wsinp_area_desc drop constraint pk_re_published_wsinp_area_desc
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_area_desc_fkey_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_area_desc drop constraint re_published_wsinp_area_desc_fkey_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_area_dtl')
begin
	alter table re_published_wsinp_area_dtl drop constraint pk_re_published_wsinp_area_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_area_dtl_fkey_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_area_dtl drop constraint re_published_wsinp_area_dtl_fkey_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_area_hdr drop constraint pk_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_area_hdr_fkey_re_published_wsinp_rcn_dtl')
begin
	alter table re_published_wsinp_area_hdr drop constraint re_published_wsinp_area_hdr_fkey_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_cat_desc_hdr')
begin
	alter table re_published_wsinp_cat_desc_hdr drop constraint pk_re_published_wsinp_cat_desc_hdr
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_cat_desc_hdr_fkey_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_cat_desc_hdr drop constraint re_published_wsinp_cat_desc_hdr_fkey_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_cat_hdr drop constraint pk_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_cat_hdr_fkey_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_cat_hdr drop constraint re_published_wsinp_cat_hdr_fkey_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_cat_parameters')
begin
	alter table re_published_wsinp_cat_parameters drop constraint pk_re_published_wsinp_cat_parameters
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_cat_parameters_fkey_re_published_wsinp_def_wf_setup')
begin
	alter table re_published_wsinp_cat_parameters drop constraint re_published_wsinp_cat_parameters_fkey_re_published_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_con_security')
begin
	alter table re_published_wsinp_con_security drop constraint pk_re_published_wsinp_con_security
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_con_security_fkey_re_published_wsinp_rcn_dtl')
begin
	alter table re_published_wsinp_con_security drop constraint re_published_wsinp_con_security_fkey_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_def_msg_dtl')
begin
	alter table re_published_wsinp_def_msg_dtl drop constraint pk_re_published_wsinp_def_msg_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_def_msg_dtl_fkey_re_published_wsinp_tsk_state_dtl')
begin
	alter table re_published_wsinp_def_msg_dtl drop constraint re_published_wsinp_def_msg_dtl_fkey_re_published_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_def_wf_setup')
begin
	alter table re_published_wsinp_def_wf_setup drop constraint pk_re_published_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_def_wf_setup_fkey_re_published_wsinp_area_hdr')
begin
	alter table re_published_wsinp_def_wf_setup drop constraint re_published_wsinp_def_wf_setup_fkey_re_published_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_doc_flow_dtl')
begin
	alter table re_published_wsinp_doc_flow_dtl drop constraint pk_re_published_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_doc_flow_dtl_fkey_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_doc_flow_dtl drop constraint re_published_wsinp_doc_flow_dtl_fkey_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_docflow_msg_dtl')
begin
	alter table re_published_wsinp_docflow_msg_dtl drop constraint pk_re_published_wsinp_docflow_msg_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_docflow_msg_dtl_fkey_re_published_wsinp_doc_flow_dtl')
begin
	alter table re_published_wsinp_docflow_msg_dtl drop constraint re_published_wsinp_docflow_msg_dtl_fkey_re_published_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_actcode')
begin
	alter table re_published_wsinp_nonrvw_actcode drop constraint pk_re_published_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_actcode_fkey_re_published_wsinp_nonrvw_compcode')
begin
	alter table re_published_wsinp_nonrvw_actcode drop constraint re_published_wsinp_nonrvw_actcode_fkey_re_published_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_actdesc')
begin
	alter table re_published_wsinp_nonrvw_actdesc drop constraint pk_re_published_wsinp_nonrvw_actdesc
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_actdesc_fkey_re_published_wsinp_nonrvw_actcode')
begin
	alter table re_published_wsinp_nonrvw_actdesc drop constraint re_published_wsinp_nonrvw_actdesc_fkey_re_published_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_compcode')
begin
	alter table re_published_wsinp_nonrvw_compcode drop constraint pk_re_published_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_compcode_fkey_re_published_wsinp_rcn_dtl')
begin
	alter table re_published_wsinp_nonrvw_compcode drop constraint re_published_wsinp_nonrvw_compcode_fkey_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_compdesc')
begin
	alter table re_published_wsinp_nonrvw_compdesc drop constraint pk_re_published_wsinp_nonrvw_compdesc
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_compdesc_fkey_re_published_wsinp_nonrvw_compcode')
begin
	alter table re_published_wsinp_nonrvw_compdesc drop constraint re_published_wsinp_nonrvw_compdesc_fkey_re_published_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_taskcode')
begin
	alter table re_published_wsinp_nonrvw_taskcode drop constraint pk_re_published_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_taskcode_fkey_re_published_wsinp_nonrvw_actcode')
begin
	alter table re_published_wsinp_nonrvw_taskcode drop constraint re_published_wsinp_nonrvw_taskcode_fkey_re_published_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_nonrvw_taskdesc')
begin
	alter table re_published_wsinp_nonrvw_taskdesc drop constraint pk_re_published_wsinp_nonrvw_taskdesc
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_nonrvw_taskdesc_fkey_re_published_wsinp_nonrvw_taskcode')
begin
	alter table re_published_wsinp_nonrvw_taskdesc drop constraint re_published_wsinp_nonrvw_taskdesc_fkey_re_published_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_qc_dtl')
begin
	alter table re_published_wsinp_qc_dtl drop constraint pk_re_published_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_qc_dtl_fkey_re_published_wsinp_qc_hdr')
begin
	alter table re_published_wsinp_qc_dtl drop constraint re_published_wsinp_qc_dtl_fkey_re_published_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_qc_hdr')
begin
	alter table re_published_wsinp_qc_hdr drop constraint pk_re_published_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_qc_lang_dtl')
begin
	alter table re_published_wsinp_qc_lang_dtl drop constraint pk_re_published_wsinp_qc_lang_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_qc_lang_dtl_fkey_re_published_wsinp_qc_dtl')
begin
	alter table re_published_wsinp_qc_lang_dtl drop constraint re_published_wsinp_qc_lang_dtl_fkey_re_published_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_rcn_dtl')
begin
	alter table re_published_wsinp_rcn_dtl drop constraint pk_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_security_dtl')
begin
	alter table re_published_wsinp_security_dtl drop constraint pk_re_published_wsinp_security_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_security_dtl_fkey_re_published_wsinp_secusr_dtl')
begin
	alter table re_published_wsinp_security_dtl drop constraint re_published_wsinp_security_dtl_fkey_re_published_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_secusr_dtl')
begin
	alter table re_published_wsinp_secusr_dtl drop constraint pk_re_published_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_secusr_dtl_fkey_re_published_wsinp_rcn_dtl')
begin
	alter table re_published_wsinp_secusr_dtl drop constraint re_published_wsinp_secusr_dtl_fkey_re_published_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_service_dtl')
begin
	alter table re_published_wsinp_service_dtl drop constraint pk_re_published_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_service_dtl_fkey_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_service_dtl drop constraint re_published_wsinp_service_dtl_fkey_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_state_desc_dtl')
begin
	alter table re_published_wsinp_state_desc_dtl drop constraint pk_re_published_wsinp_state_desc_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_state_desc_dtl_fkey_re_published_wsinp_tsk_state_dtl')
begin
	alter table re_published_wsinp_state_desc_dtl drop constraint re_published_wsinp_state_desc_dtl_fkey_re_published_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_task_dtl')
begin
	alter table re_published_wsinp_task_dtl drop constraint pk_re_published_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_task_dtl_fkey_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_task_dtl drop constraint re_published_wsinp_task_dtl_fkey_re_published_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_tsk_state_dtl')
begin
	alter table re_published_wsinp_tsk_state_dtl drop constraint pk_re_published_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_tsk_state_dtl_fkey_re_published_wsinp_task_dtl')
begin
	alter table re_published_wsinp_tsk_state_dtl drop constraint re_published_wsinp_tsk_state_dtl_fkey_re_published_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_tsk_stflow_dtl')
begin
	alter table re_published_wsinp_tsk_stflow_dtl drop constraint pk_re_published_wsinp_tsk_stflow_dtl
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_tsk_stflow_dtl_fkey_re_published_wsinp_tsk_state_dtl')
begin
	alter table re_published_wsinp_tsk_stflow_dtl drop constraint re_published_wsinp_tsk_stflow_dtl_fkey_re_published_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_published_wsinp_usr_noncon_task')
begin
	alter table re_published_wsinp_usr_noncon_task drop constraint pk_re_published_wsinp_usr_noncon_task
end

if exists(select 'x' from sysobjects where name = 're_published_wsinp_usr_noncon_task_fkey_re_published_wsinp_cat_hdr')
begin
	alter table re_published_wsinp_usr_noncon_task drop constraint re_published_wsinp_usr_noncon_task_fkey_re_published_wsinp_cat_hdr
end

-- Added on 31st Dec Starts

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_mdcf_glossary_lng_extn_fkey_de_published_glossary')
BEGIN
	ALTER TABLE de_published_mdcf_glossary_lng_extn DROP CONSTRAINT de_published_mdcf_glossary_lng_extn_fde_published_glossary
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_mdcf_template_taskcontrol_map_fkey_de_published_mdcf_template_task')
BEGIN
	ALTER TABLE de_published_mdcf_template_taskcontrol_map DROP CONSTRAINT de_published_mdcf_template_taskcontrol_map_fkey_de_published_mdcf_template_task
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_mdcf_template_task_fkey_de_published_mdcf_template_ilbo')
BEGIN
	ALTER TABLE de_published_mdcf_template_task DROP CONSTRAINT de_published_mdcf_template_task_fkey_de_published_mdcf_template_ilbo
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_mdcf_template_ilbo_fkey_de_published_mdcf_template')
BEGIN
	ALTER TABLE de_published_mdcf_template_ilbo DROP CONSTRAINT de_published_mdcf_template_ilbo_fkey_de_published_mdcf_template
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_glossary_lng_extn'))
BEGIN
	ALTER TABLE  de_published_mdcf_glossary_lng_extn DROP CONSTRAINT PK_de_published_mdcf_glossary_lng_extn
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_template_taskcontrol_map'))
BEGIN
	ALTER TABLE  de_published_mdcf_template_taskcontrol_map DROP CONSTRAINT PK_de_published_mdcf_template_taskcontrol_map
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_template_taskseq'))
BEGIN
	ALTER TABLE  de_published_mdcf_template_taskseq DROP CONSTRAINT PK_de_published_mdcf_template_taskseq
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_template_task'))
BEGIN
	ALTER TABLE  de_published_mdcf_template_task DROP CONSTRAINT PK_de_published_mdcf_template_task
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_template_ilbo'))
BEGIN
	ALTER TABLE  de_published_mdcf_template_ilbo DROP CONSTRAINT PK_de_published_mdcf_template_ilbo
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_mdcf_template'))
BEGIN
	ALTER TABLE  de_published_mdcf_template DROP CONSTRAINT PK_de_published_mdcf_template
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_up_defaulting_dtl'))
BEGIN
	ALTER TABLE  de_published_up_defaulting_dtl DROP CONSTRAINT PK_de_published_up_defaulting_dtl
END
GO

-- Added on 31st Dec Ends


-- Added for the Request TECH-43307 Starts
IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_published_ui_section_refinement')
BEGIN
	ALTER table ep_published_ui_section_refinement DROP CONSTRAINT PK_ep_published_ui_section_refinement 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_published_responsive_sec_weightage')
BEGIN
	ALTER table ep_published_responsive_sec_weightage DROP CONSTRAINT PK_ep_published_responsive_sec_weightage 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_published_ui_section_refinement')
BEGIN
	ALTER table re_published_ui_section_refinement DROP CONSTRAINT PK_re_published_ui_section_refinement
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_published_responsive_sec_weightage')
BEGIN
	ALTER table re_published_responsive_sec_weightage DROP CONSTRAINT PK_re_published_responsive_sec_weightage 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_ui_section_refinement')
BEGIN
	ALTER table de_published_ui_section_refinement DROP CONSTRAINT PK_de_published_ui_section_refinement
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_responsive_sec_weightage')
BEGIN
	ALTER table de_published_responsive_sec_weightage DROP CONSTRAINT PK_de_published_responsive_sec_weightage 
END
GO
-- Added for the Request TECH-43307 Ends

/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Feb 2020
Purpose 		For Droping Constraints
********************************************************************************/

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_processsection_br_is_executionflag')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint Chk_de_fw_des_publish_processsection_br_is_executionflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_publish_processsection_br_is_isbr')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint Chk_de_fw_des_publish_processsection_br_is_isbr
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_businessrule')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_processsection')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint de_fw_des_publish_processsection_br_is_fkey_de_fw_des_publish_processsection
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_pathoperationparameter_serv_map')
begin
	alter table fw_des_publish_api_pathoperationparameter_serv_map drop constraint PK_fw_des_publish_api_pathoperationparameter_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_pathoperationparameter_task_map')
begin
	alter table fw_des_publish_api_pathoperationparameter_task_map drop constraint PK_fw_des_publish_api_pathoperationparameter_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_pathparameter_serv_map')
begin
	alter table fw_des_publish_api_pathparameter_serv_map drop constraint PK_fw_des_publish_api_pathparameter_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_pathparameter_task_map')
begin
	alter table fw_des_publish_api_pathparameter_task_map drop constraint PK_fw_des_publish_api_pathparameter_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_request_serv_map')
begin
	alter table fw_des_publish_api_request_serv_map drop constraint PK_fw_des_publish_api_request_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_request_task_map')
begin
	alter table fw_des_publish_api_request_task_map drop constraint PK_fw_des_publish_api_request_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_response_serv_map')
begin
	alter table fw_des_publish_api_response_serv_map drop constraint PK_fw_des_publish_api_response_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_publish_api_response_task_map')
begin
	alter table fw_des_publish_api_response_task_map drop constraint PK_fw_des_publish_api_response_task_map
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_publish_processsection_br_is_createddate')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint def_de_fw_des_publish_processsection_br_is_createddate
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_publish_processsection_br_is_executionflag')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint def_de_fw_des_publish_processsection_br_is_executionflag
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_publish_processsection_br_is_isbr')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint def_de_fw_des_publish_processsection_br_is_isbr
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_publish_processsection_br_is_modifieddate')
begin
	alter table de_fw_des_publish_processsection_br_is drop constraint def_de_fw_des_publish_processsection_br_is_modifieddate
end

-- Added for Elastic search & UPE

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ListEdit_map')
BEGIN
       ALTER table de_published_els_query_listedit_map DROP CONSTRAINT PK_de_published_els_query_ListEdit_map
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ListEdit_input')
BEGIN
       ALTER table de_published_els_query_listedit_input DROP CONSTRAINT PK_de_published_els_query_ListEdit_input
END
GO



IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ListEdit_result')
BEGIN
       ALTER table de_published_els_query_listedit_result DROP CONSTRAINT PK_de_published_els_query_ListEdit_result
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ps_map')
BEGIN
       ALTER table de_published_els_query_ps_map DROP CONSTRAINT PK_de_published_els_query_ps_map
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ps_input')
BEGIN
       ALTER table de_published_els_query_ps_input DROP CONSTRAINT PK_de_published_els_query_ps_input
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_els_query_ps_result')
BEGIN
       ALTER table de_published_els_query_ps_result DROP CONSTRAINT PK_de_published_els_query_ps_result
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_published_els_query_ListEdit_map')
BEGIN
       ALTER table ep_published_els_query_listedit_map DROP CONSTRAINT PK_ep_published_els_query_ListEdit_map
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_published_els_query_ListEdit_input')
BEGIN
       ALTER table ep_published_els_query_listedit_input DROP CONSTRAINT PK_ep_published_els_query_ListEdit_input
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_published_els_query_ListEdit_result')
BEGIN
       ALTER table ep_published_els_query_listedit_result DROP CONSTRAINT PK_ep_published_els_query_ListEdit_result
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_published_els_query_ListEdit_map')
BEGIN
       ALTER table re_published_els_query_listedit_map DROP CONSTRAINT PK_re_published_els_query_ListEdit_map
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_re_published_els_query_ListEdit_input')
BEGIN
       ALTER table re_published_els_query_listedit_input DROP CONSTRAINT PK_re_published_els_query_ListEdit_input
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_re_published_els_query_ListEdit_result')
BEGIN
       ALTER table re_published_els_query_listedit_result DROP CONSTRAINT PK_re_published_els_query_ListEdit_result
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_upe_control')
BEGIN
       ALTER table de_published_upe_control DROP CONSTRAINT PK_de_published_upe_control
END
GO



IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_upe_control_parameters')
BEGIN
       ALTER table de_published_upe_control_parameters DROP CONSTRAINT PK_de_published_upe_control_parameters
END
GO



IF EXISTS(select 'x' from sysobjects where name = 'PK_de_published_upe_control_task_detail')
BEGIN
       ALTER table de_published_upe_control_task_detail DROP CONSTRAINT PK_de_published_upe_control_task_detail
END
GO

/******************************TECH-60451  starts **************************************************************/

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_ep_published_ui_grid_extension')
BEGIN
       ALTER TABLE ep_published_ui_grid_extension DROP CONSTRAINT PK_ep_published_ui_grid_extension
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_re_published_ui_grid_extension')
BEGIN
       ALTER TABLE re_published_ui_grid_extension DROP CONSTRAINT PK_re_published_ui_grid_extension
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_ui_grid_Extension')
BEGIN
       ALTER TABLE de_published_ui_grid_Extension DROP CONSTRAINT PK_de_published_ui_grid_Extension
END
GO

/******************************TECH-60451  starts **************************************************************/

-----Code Added For New Feature-Task API Mapping  TECH-61144  Starts
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_api_mapping')
BEGIN
       ALTER TABLE de_published_task_api_mapping DROP CONSTRAINT PK_de_published_task_api_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_subtask')
BEGIN
       ALTER TABLE de_published_subtask DROP CONSTRAINT PK_de_published_subtask
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_api_parameter_map')
BEGIN
       ALTER TABLE de_published_task_api_parameter_map DROP CONSTRAINT PK_de_published_task_api_parameter_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_api_request_map')
BEGIN
       ALTER TABLE de_published_task_api_request_map DROP CONSTRAINT PK_de_published_task_api_request_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_api_response_map')
BEGIN
       ALTER TABLE de_published_task_api_response_map DROP CONSTRAINT PK_de_published_task_api_response_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_api_subtask')
BEGIN
       ALTER TABLE de_published_task_api_subtask DROP CONSTRAINT PK_de_published_task_api_subtask
END
GO
-----Code Added For New Feature-Task API Mapping  TECH-61144  Ends

-----Code Added For Task API Mapping  TECH-61907  Starts
IF NOT EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_service_api_parameter_map')
BEGIN
	ALTER TABLE de_published_service_api_parameter_map DROP CONSTRAINT PK_de_published_service_api_parameter_map
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_service_api_request_map')
BEGIN
	ALTER TABLE de_published_service_api_request_map DROP CONSTRAINT PK_de_published_service_api_request_map
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_service_api_response_map')
BEGIN
	ALTER TABLE de_published_service_api_response_map DROP CONSTRAINT PK_de_published_service_api_response_map
END
GO
-----Code Added For Task API Mapping  TECH-61907  Ends


-----Code Added For Gql operation  TECH-63474 Starts

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_published_graphql_query')
BEGIN
       ALTER TABLE fw_published_graphql_query DROP CONSTRAINT PK_fw_published_graphql_query
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_published_graphql_arguments')
BEGIN
       ALTER TABLE fw_published_graphql_arguments DROP CONSTRAINT fw_published_graphql_arguments
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_published_graphql_fields')
BEGIN
       ALTER TABLE fw_published_graphql_fields DROP CONSTRAINT fw_published_graphql_fields
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_gql_argument_mapping')
BEGIN
       ALTER TABLE de_published_task_gql_argument_mapping DROP CONSTRAINT de_published_task_gql_argument_mapping
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_gql_mapping')
BEGIN
       ALTER TABLE de_published_task_gql_mapping DROP CONSTRAINT de_published_task_gql_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_task_gql_field_mapping')
BEGIN
       ALTER TABLE de_published_task_gql_field_mapping DROP CONSTRAINT de_published_task_gql_field_mapping
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_published_gql_Schema')
BEGIN
       ALTER TABLE de_published_gql_Schema DROP CONSTRAINT de_published_gql_Schema
END
GO


-----Code Added For Gql operation  TECH-63474 Ends

--Code added for the defect id : TECH-64197 starts

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_published_graphql_arg_fields')
BEGIN
       ALTER TABLE fw_published_graphql_arg_fields DROP CONSTRAINT PK_fw_published_graphql_arg_fields
END
GO

--Code added for the defect id : TECH-64197 ends

/* Code Added for the Defect-Id TECH-66778 Starts */

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_caption_alignment')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_caption_position')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_caption_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_caption_wrap')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_ctrl_position')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_delete_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_editable_flag')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_ellipses_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_event_handling_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_help_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_insert_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_password_char')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_select_flag')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_visisble_flag')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_ctrl_type_mst_zoom_req')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint Chk_ep_published_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 'ep_published_comp_ctrl_type_mst_pkey')
begin
	alter table ep_published_comp_ctrl_type_mst drop constraint ep_published_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_published_comp_ctrl_type_mst_extn_pkey')
begin
	alter table ep_published_comp_ctrl_type_mst_extn drop constraint ep_published_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_clr_on_page_save')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_cond_ml_fetch')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_data_save_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_default_for')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_err_handle_method')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_hdr_check_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_hdr_fetch_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_hdr_ref_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_incl_place_holder')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_ml_fet_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_print_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_proc_sel_rows')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_refresh_on_save')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_task_confirmation')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_trn_scope_req')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_usr_role_map')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_published_comp_task_type_mst_valid_on_init')
begin
	alter table ep_published_comp_task_type_mst drop constraint Chk_ep_published_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'ep_published_comp_task_type_mst_pkey')
begin
	alter table ep_published_comp_task_type_mst drop constraint ep_published_comp_task_type_mst_pkey
end

-----------------------------------------------------------------------------------------------------------------------
if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_caption_alignment')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_caption_position')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_caption_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_caption_wrap')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_ctrl_position')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_delete_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_editable_flag')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_ellipses_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_event_handling_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_help_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_insert_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_password_char')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_select_flag')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_visisble_flag')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_ctrl_type_mst_zoom_req')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint Chk_re_published_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 're_published_comp_ctrl_type_mst_pkey')
begin
	alter table re_published_comp_ctrl_type_mst drop constraint re_published_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 're_published_comp_ctrl_type_mst_extn_pkey')
begin
	alter table re_published_comp_ctrl_type_mst_extn drop constraint re_published_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_clr_on_page_save')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_cond_ml_fetch')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_data_save_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_default_for')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_err_handle_method')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_hdr_check_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_hdr_fetch_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_hdr_ref_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_incl_place_holder')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_ml_fet_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_print_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_proc_sel_rows')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_refresh_on_save')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_task_confirmation')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_trn_scope_req')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_usr_role_map')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_re_published_comp_task_type_mst_valid_on_init')
begin
	alter table re_published_comp_task_type_mst drop constraint Chk_re_published_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 're_published_comp_task_type_mst_pkey')
begin
	alter table re_published_comp_task_type_mst drop constraint re_published_comp_task_type_mst_pkey
end

-----------------------------------------------------------------------------------------------------------------------

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_caption_alignment')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_caption_position')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_caption_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_caption_wrap')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_ctrl_position')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_delete_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_editable_flag')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_ellipses_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_event_handling_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_help_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_insert_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_password_char')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_select_flag')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_visisble_flag')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_ctrl_type_mst_zoom_req')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint Chk_de_published_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 'de_published_comp_ctrl_type_mst_pkey')
begin
	alter table de_published_comp_ctrl_type_mst drop constraint de_published_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'de_published_comp_ctrl_type_mst_extn_pkey')
begin
	alter table de_published_comp_ctrl_type_mst_extn drop constraint de_published_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_clr_on_page_save')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_cond_ml_fetch')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_data_save_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_default_for')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_err_handle_method')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_hdr_check_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_hdr_fetch_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_hdr_ref_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_incl_place_holder')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_ml_fet_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_print_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_proc_sel_rows')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_refresh_on_save')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_task_confirmation')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_trn_scope_req')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_usr_role_map')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_de_published_comp_task_type_mst_valid_on_init')
begin
	alter table de_published_comp_task_type_mst drop constraint Chk_de_published_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'de_published_comp_task_type_mst_pkey')
begin
	alter table de_published_comp_task_type_mst drop constraint de_published_comp_task_type_mst_pkey
end

/* Code Added for the Defect-Id TECH-66778 Ends */

/* Code Added for the Defect-Id TECH-69624 Starts */
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ep_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  ep_published_ui_control_customaction DROP CONSTRAINT ep_published_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('re_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  re_published_ui_control_customaction DROP CONSTRAINT re_published_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  de_published_ui_control_customaction DROP CONSTRAINT de_published_ui_control_customaction_pk
END
GO
/* Code Added for the Defect-Id TECH-69624 Ends */

/* Code Added for the Defect-Id TECH-69624 Starts */
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ep_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  ep_published_ui_control_customaction DROP CONSTRAINT ep_published_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('re_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  re_published_ui_control_customaction DROP CONSTRAINT re_published_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  de_published_ui_control_customaction DROP CONSTRAINT de_published_ui_control_customaction_pk
END
GO
/* Code Added for the Defect-Id TECH-69624 Ends */

--Code Added for the DefectId TECH-70687 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ep_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE  ep_published_ui_section_titleaction DROP CONSTRAINT ep_published_ui_section_Titleaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('re_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE  re_published_ui_section_titleaction DROP CONSTRAINT re_published_ui_section_Titleaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE de_published_ui_section_titleaction DROP CONSTRAINT de_published_ui_section_Titleaction_pk
END
GO
--Code Added for the DefectId TECH-70687 Ends

--Code added for TECH-72114 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report'))
BEGIN
	ALTER TABLE  de_published_task_gql_report DROP CONSTRAINT PK_de_published_task_gql_report
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report_param'))
BEGIN
	ALTER TABLE  de_published_task_gql_report_param DROP CONSTRAINT PK_de_published_task_gql_report_param
END
GO

--Code added for TECH-72114 ends