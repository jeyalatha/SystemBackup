/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		For Creating Primary Key Constraints
********************************************************************************/

if not exists (select 'x' from sysconstraints where id = object_id('avs_published_comp_bt_val') and constid = object_id('avs_published_comp_bt_val_pkey'))
begin
	alter table avs_published_comp_bt_val add constraint avs_published_comp_bt_val_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bt_name, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_published_message') and constid = object_id('avs_published_message_pkey'))
begin
	alter table avs_published_message add constraint avs_published_message_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_published_msg_lng_extn') and constid = object_id('avs_published_msg_lng_extn_pkey'))
begin
	alter table avs_published_msg_lng_extn add constraint avs_published_msg_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_published_service_validation_dtl') and constid = object_id('avs_published_service_validation_dtl_pkey'))
begin
	alter table avs_published_service_validation_dtl add constraint avs_published_service_validation_dtl_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_published_control_validation') and constid = object_id('cvs_published_control_validation_pkey'))
begin
	alter table cvs_published_control_validation add constraint cvs_published_control_validation_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_published_message') and constid = object_id('PK_cvs_published_message'))
begin
	alter table cvs_published_message add constraint PK_cvs_published_message primary key clustered (customer_name, Project_name, ecrno, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code, message_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_published_message_lng_extn') and constid = object_id('PK_cvs_published_message_lng_extn'))
begin
	alter table cvs_published_message_lng_extn add constraint PK_cvs_published_message_lng_extn primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code, message_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_be_placeholder') and constid = object_id('de_fw_des_publish_be_placeholder_pkey'))
begin
	alter table de_fw_des_publish_be_placeholder add constraint de_fw_des_publish_be_placeholder_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid, placeholdername, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_bo') and constid = object_id('de_fw_des_publish_bo_pkey'))
begin
	alter table de_fw_des_publish_bo add constraint de_fw_des_publish_bo_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, bocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_bo_documentation') and constid = object_id('de_fw_des_publish_bo_documentation_pkey'))
begin
	alter table de_fw_des_publish_bo_documentation add constraint de_fw_des_publish_bo_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, bocode, serialno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_br_documentation') and constid = object_id('de_fw_des_publish_br_documentation_pkey'))
begin
	alter table de_fw_des_publish_br_documentation add constraint de_fw_des_publish_br_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid, serialno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_br_logical_parameter') and constid = object_id('de_fw_des_publish_br_logical_parameter_pkey'))
begin
	alter table de_fw_des_publish_br_logical_parameter add constraint de_fw_des_publish_br_logical_parameter_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid, logicalparametername)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_brerror') and constid = object_id('de_fw_des_publish_brerror_pkey'))
begin
	alter table de_fw_des_publish_brerror add constraint de_fw_des_publish_brerror_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_bro') and constid = object_id('de_fw_des_publish_bro_pkey'))
begin
	alter table de_fw_des_publish_bro add constraint de_fw_des_publish_bro_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, broname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_businessrule') and constid = object_id('de_fw_des_publish_businessrule_pkey'))
begin
	alter table de_fw_des_publish_businessrule add constraint de_fw_des_publish_businessrule_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_chart_service_dataitem') and constid = object_id('de_fw_des_publish_chart_service_dataitem_pkey'))
begin
	alter table de_fw_des_publish_chart_service_dataitem add constraint de_fw_des_publish_chart_service_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_chart_service_segment') and constid = object_id('de_fw_des_publish_chart_service_segment_pkey'))
begin
	alter table de_fw_des_publish_chart_service_segment add constraint de_fw_des_publish_chart_service_segment_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_context') and constid = object_id('de_fw_des_publish_context_pkey'))
begin
	alter table de_fw_des_publish_context add constraint de_fw_des_publish_context_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorid, errorcontext)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_corr_action_local_info') and constid = object_id('de_fw_des_publish_corr_action_local_info_pkey'))
begin
	alter table de_fw_des_publish_corr_action_local_info add constraint de_fw_des_publish_corr_action_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorid, errorcontext, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_dataitem') and constid = object_id('de_fw_des_publish_dataitem_pkey'))
begin
	alter table de_fw_des_publish_dataitem add constraint de_fw_des_publish_dataitem_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, bocode, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_di_parameter') and constid = object_id('de_fw_des_publish_di_parameter_pkey'))
begin
	alter table de_fw_des_publish_di_parameter add constraint de_fw_des_publish_di_parameter_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, sectionname, sequenceno, parametername)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_di_placeholder') and constid = object_id('de_fw_des_publish_di_placeholder_pkey'))
begin
	alter table de_fw_des_publish_di_placeholder add constraint de_fw_des_publish_di_placeholder_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, sectionname, sequenceno, methodid, placeholdername, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_err_det_local_info') and constid = object_id('de_fw_des_publish_err_det_local_info_pkey'))
begin
	alter table de_fw_des_publish_err_det_local_info add constraint de_fw_des_publish_err_det_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_errbtn_local_info') and constid = object_id('de_fw_des_publish_errbtn_local_info_pkey'))
begin
	alter table de_fw_des_publish_errbtn_local_info add constraint de_fw_des_publish_errbtn_local_info_pkey primary key clustered (customername, projectname, ecrno, severityid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_error') and constid = object_id('de_fw_des_publish_error_pkey'))
begin
	alter table de_fw_des_publish_error add constraint de_fw_des_publish_error_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_error_lookup') and constid = object_id('de_fw_des_publish_error_lookup_pk'))
begin
	alter table de_fw_des_publish_error_lookup add constraint de_fw_des_publish_error_lookup_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, ecrno, service_name, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_error_lookup_dataitem') and constid = object_id('de_fw_des_publish_error_lookup_dataitem_pk'))
begin
	alter table de_fw_des_publish_error_lookup_dataitem add constraint de_fw_des_publish_error_lookup_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, service_name, errorid, pub_name, pub_page, pub_dataitemname, sub_page, sub_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_error_placeholder') and constid = object_id('de_fw_des_publish_error_placeholder_pkey'))
begin
	alter table de_fw_des_publish_error_placeholder add constraint de_fw_des_publish_error_placeholder_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorid, placeholdername)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_focus_control') and constid = object_id('de_fw_des_publish_focus_control_pkey'))
begin
	alter table de_fw_des_publish_focus_control add constraint de_fw_des_publish_focus_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, errorcontext, errorid, segmentname, focusdataitem, controlid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_followup_tasks') and constid = object_id('de_fw_des_publish_followup_tasks_pk'))
begin
	alter table de_fw_des_publish_followup_tasks add constraint de_fw_des_publish_followup_tasks_pk primary key clustered (customer_name, project_name, process_name, ecrno, component_name, activity_name, ui_name, task_name, success_errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_action_group') and constid = object_id('de_fw_des_publish_ilbo_action_group_pkey'))
begin
	alter table de_fw_des_publish_ilbo_action_group add constraint de_fw_des_publish_ilbo_action_group_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, groupcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_actiongrp_event') and constid = object_id('de_fw_des_publish_ilbo_actiongrp_event_pkey'))
begin
	alter table de_fw_des_publish_ilbo_actiongrp_event add constraint de_fw_des_publish_ilbo_actiongrp_event_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, activityid, groupcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_actiongrp_task') and constid = object_id('de_fw_des_publish_ilbo_actiongrp_task_pkey'))
begin
	alter table de_fw_des_publish_ilbo_actiongrp_task add constraint de_fw_des_publish_ilbo_actiongrp_task_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, taskname, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_actions') and constid = object_id('de_fw_des_publish_ilbo_actions_pkey'))
begin
	alter table de_fw_des_publish_ilbo_actions add constraint de_fw_des_publish_ilbo_actions_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, groupcode, actionsequence)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_controlvalue') and constid = object_id('de_fw_des_publish_ilbo_controlvalue_pkey'))
begin
	alter table de_fw_des_publish_ilbo_controlvalue add constraint de_fw_des_publish_ilbo_controlvalue_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_ctrl_event') and constid = object_id('de_fw_des_publish_ilbo_ctrl_event_pkey'))
begin
	alter table de_fw_des_publish_ilbo_ctrl_event add constraint de_fw_des_publish_ilbo_ctrl_event_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, controlid, eventname, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_placeholder') and constid = object_id('de_fw_des_publish_ilbo_placeholder_pkey'))
begin
	alter table de_fw_des_publish_ilbo_placeholder add constraint de_fw_des_publish_ilbo_placeholder_pkey primary key clustered (customername, projectname, ecrno, processname, componentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_service_view_attributemap') and constid = object_id('de_fw_des_publish_ilbo_service_view_attributemap_pkey'))
begin
	alter table de_fw_des_publish_ilbo_service_view_attributemap add constraint de_fw_des_publish_ilbo_service_view_attributemap_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, servicename, activityid, taskname, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_service_view_datamap') and constid = object_id('de_fw_des_publish_ilbo_service_view_datamap_pkey'))
begin
	alter table de_fw_des_publish_ilbo_service_view_datamap add constraint de_fw_des_publish_ilbo_service_view_datamap_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, servicename, activityid, taskname, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilbo_services') and constid = object_id('de_fw_des_publish_ilbo_services_pkey'))
begin
	alter table de_fw_des_publish_ilbo_services add constraint de_fw_des_publish_ilbo_services_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, servicename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_ilerror') and constid = object_id('de_fw_des_publish_ilerror_pkey'))
begin
	alter table de_fw_des_publish_ilerror add constraint de_fw_des_publish_ilerror_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_integ_serv_map') and constid = object_id('de_fw_des_publish_integ_serv_map_pkey'))
begin
	alter table de_fw_des_publish_integ_serv_map add constraint de_fw_des_publish_integ_serv_map_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, callingservicename, sectionname, sequenceno, integservicename, integsegment, integdataitem)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_processsection') and constid = object_id('de_fw_des_publish_processsection_pkey'))
begin
	alter table de_fw_des_publish_processsection add constraint de_fw_des_publish_processsection_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, sectionname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_processsection_br_is') and constid = object_id('de_fw_des_publish_processsection_br_is_pkey'))
begin
	alter table de_fw_des_publish_processsection_br_is add constraint de_fw_des_publish_processsection_br_is_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, sectionname, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_reqbr_desbr') and constid = object_id('de_fw_des_publish_reqbr_desbr_pkey'))
begin
	alter table de_fw_des_publish_reqbr_desbr add constraint de_fw_des_publish_reqbr_desbr_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, reqbrname, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_segment') and constid = object_id('de_fw_des_publish_segment_pkey'))
begin
	alter table de_fw_des_publish_segment add constraint de_fw_des_publish_segment_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, bocode, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_service') and constid = object_id('de_fw_des_publish_service_pkey'))
begin
	alter table de_fw_des_publish_service add constraint de_fw_des_publish_service_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_service_dataitem') and constid = object_id('de_fw_des_publish_service_dataitem_pkey'))
begin
	alter table de_fw_des_publish_service_dataitem add constraint de_fw_des_publish_service_dataitem_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_service_documentation') and constid = object_id('de_fw_des_publish_service_documentation_pkey'))
begin
	alter table de_fw_des_publish_service_documentation add constraint de_fw_des_publish_service_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, serialno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_service_segment') and constid = object_id('de_fw_des_publish_service_segment_pkey'))
begin
	alter table de_fw_des_publish_service_segment add constraint de_fw_des_publish_service_segment_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_sp') and constid = object_id('de_fw_des_publish_sp_pkey'))
begin
	alter table de_fw_des_publish_sp add constraint de_fw_des_publish_sp_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_svco') and constid = object_id('de_fw_des_publish_svco_pkey'))
begin
	alter table de_fw_des_publish_svco add constraint de_fw_des_publish_svco_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, svconame)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_task_segment_attribs') and constid = object_id('de_fw_des_publish_task_segment_attribs_pkey'))
begin
	alter table de_fw_des_publish_task_segment_attribs add constraint de_fw_des_publish_task_segment_attribs_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, ilbocode, taskname, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity') and constid = object_id('de_fw_req_publish_activity_pkey'))
begin
	alter table de_fw_req_publish_activity add constraint de_fw_req_publish_activity_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_documentation') and constid = object_id('de_fw_req_publish_activity_documentation_pkey'))
begin
	alter table de_fw_req_publish_activity_documentation add constraint de_fw_req_publish_activity_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_ilbo') and constid = object_id('de_fw_req_publish_activity_ilbo_pkey'))
begin
	alter table de_fw_req_publish_activity_ilbo add constraint de_fw_req_publish_activity_ilbo_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_ilbo_task') and constid = object_id('de_fw_req_publish_activity_ilbo_task_pkey'))
begin
	alter table de_fw_req_publish_activity_ilbo_task add constraint de_fw_req_publish_activity_ilbo_task_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_ilbo_task_extension_map') and constid = object_id('de_fw_req_publish_activity_ilbo_task_extension_map_pkey'))
begin
	alter table de_fw_req_publish_activity_ilbo_task_extension_map add constraint de_fw_req_publish_activity_ilbo_task_extension_map_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_local_info') and constid = object_id('de_fw_req_publish_activity_local_info_pkey'))
begin
	alter table de_fw_req_publish_activity_local_info add constraint de_fw_req_publish_activity_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_activity_task') and constid = object_id('de_fw_req_publish_activity_task_pkey'))
begin
	alter table de_fw_req_publish_activity_task add constraint de_fw_req_publish_activity_task_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_br_bterm') and constid = object_id('de_fw_req_publish_br_bterm_pkey'))
begin
	alter table de_fw_req_publish_br_bterm add constraint de_fw_req_publish_br_bterm_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, paramno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_br_documentation') and constid = object_id('de_fw_req_publish_br_documentation_pkey'))
begin
	alter table de_fw_req_publish_br_documentation add constraint de_fw_req_publish_br_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_br_error') and constid = object_id('de_fw_req_publish_br_error_pkey'))
begin
	alter table de_fw_req_publish_br_error add constraint de_fw_req_publish_br_error_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, errorcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_br_error_placeholder') and constid = object_id('de_fw_req_publish_br_error_placeholder_pkey'))
begin
	alter table de_fw_req_publish_br_error_placeholder add constraint de_fw_req_publish_br_error_placeholder_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, brsequence, errorcode, placeholdersequence, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_bterm') and constid = object_id('de_fw_req_publish_bterm_pkey'))
begin
	alter table de_fw_req_publish_bterm add constraint de_fw_req_publish_bterm_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, btname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_bterm_enumerated_option') and constid = object_id('de_fw_req_publish_bterm_enumerated_option_pkey'))
begin
	alter table de_fw_req_publish_bterm_enumerated_option add constraint de_fw_req_publish_bterm_enumerated_option_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, btname, langid, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_bterm_group') and constid = object_id('de_fw_req_publish_bterm_group_pkey'))
begin
	alter table de_fw_req_publish_bterm_group add constraint de_fw_req_publish_bterm_group_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, btname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_bterm_synonym') and constid = object_id('de_fw_req_publish_bterm_synonym_pkey'))
begin
	alter table de_fw_req_publish_bterm_synonym add constraint de_fw_req_publish_bterm_synonym_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_businessrule') and constid = object_id('de_fw_req_publish_businessrule_pkey'))
begin
	alter table de_fw_req_publish_businessrule add constraint de_fw_req_publish_businessrule_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_component_documentation') and constid = object_id('de_fw_req_publish_component_documentation_pkey'))
begin
	alter table de_fw_req_publish_component_documentation add constraint de_fw_req_publish_component_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_component_local_info') and constid = object_id('de_fw_req_publish_component_local_info_pkey'))
begin
	alter table de_fw_req_publish_component_local_info add constraint de_fw_req_publish_component_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_error') and constid = object_id('de_fw_req_publish_error_pkey'))
begin
	alter table de_fw_req_publish_error add constraint de_fw_req_publish_error_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_error_local_info') and constid = object_id('de_fw_req_publish_error_local_info_pkey'))
begin
	alter table de_fw_req_publish_error_local_info add constraint de_fw_req_publish_error_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, errorcode, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo') and constid = object_id('de_fw_req_publish_ilbo_pkey'))
begin
	alter table de_fw_req_publish_ilbo add constraint de_fw_req_publish_ilbo_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_control') and constid = object_id('de_fw_req_publish_ilbo_control_pkey'))
begin
	alter table de_fw_req_publish_ilbo_control add constraint de_fw_req_publish_ilbo_control_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_control_property') and constid = object_id('de_fw_req_publish_ilbo_control_property_pkey'))
begin
	alter table de_fw_req_publish_ilbo_control_property add constraint de_fw_req_publish_ilbo_control_property_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, ilbocode, propertyname, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_data_publish') and constid = object_id('de_fw_req_publish_ilbo_data_publish_pkey'))
begin
	alter table de_fw_req_publish_ilbo_data_publish add constraint de_fw_req_publish_ilbo_data_publish_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, dataitemname, ilbocode, linkid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_data_use') and constid = object_id('de_fw_req_publish_ilbo_data_use_pkey'))
begin
	alter table de_fw_req_publish_ilbo_data_use add constraint de_fw_req_publish_ilbo_data_use_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, dataitemname, linkid, parentilbocode, taskname, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_documentation') and constid = object_id('de_fw_req_publish_ilbo_documentation_pkey'))
begin
	alter table de_fw_req_publish_ilbo_documentation add constraint de_fw_req_publish_ilbo_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, paragraphname, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_link_local_info') and constid = object_id('de_fw_req_publish_ilbo_link_local_info_pkey'))
begin
	alter table de_fw_req_publish_ilbo_link_local_info add constraint de_fw_req_publish_ilbo_link_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, langid, linkid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_link_publish') and constid = object_id('de_fw_req_publish_ilbo_link_publish_pkey'))
begin
	alter table de_fw_req_publish_ilbo_link_publish add constraint de_fw_req_publish_ilbo_link_publish_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, linkid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_link_use_documentation') and constid = object_id('de_fw_req_publish_ilbo_link_use_documentation_pkey'))
begin
	alter table de_fw_req_publish_ilbo_link_use_documentation add constraint de_fw_req_publish_ilbo_link_use_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, linkid, paragraphno, parentilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_linkuse') and constid = object_id('de_fw_req_publish_ilbo_linkuse_pkey'))
begin
	alter table de_fw_req_publish_ilbo_linkuse add constraint de_fw_req_publish_ilbo_linkuse_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, parentilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_local_info') and constid = object_id('de_fw_req_publish_ilbo_local_info_pkey'))
begin
	alter table de_fw_req_publish_ilbo_local_info add constraint de_fw_req_publish_ilbo_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_project_details') and constid = object_id('de_fw_req_publish_ilbo_project_details_pkey'))
begin
	alter table de_fw_req_publish_ilbo_project_details add constraint de_fw_req_publish_ilbo_project_details_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_tab_properties') and constid = object_id('de_fw_req_publish_ilbo_tab_properties_pkey'))
begin
	alter table de_fw_req_publish_ilbo_tab_properties add constraint de_fw_req_publish_ilbo_tab_properties_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, propertyname, tabname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_tabs') and constid = object_id('de_fw_req_publish_ilbo_tabs_pkey'))
begin
	alter table de_fw_req_publish_ilbo_tabs add constraint de_fw_req_publish_ilbo_tabs_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, ilbocode, tabname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_task_rpt') and constid = object_id('de_fw_req_publish_ilbo_task_rpt_PK'))
begin
	alter table de_fw_req_publish_ilbo_task_rpt add constraint de_fw_req_publish_ilbo_task_rpt_PK primary key clustered (customername, projectname, ecrno, processname, componentname, activity_name, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_view') and constid = object_id('de_fw_req_publish_ilbo_view_pkey'))
begin
	alter table de_fw_req_publish_ilbo_view add constraint de_fw_req_publish_ilbo_view_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, ilbocode, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilbo_view_local_info') and constid = object_id('de_fw_req_publish_ilbo_view_local_info_pkey'))
begin
	alter table de_fw_req_publish_ilbo_view_local_info add constraint de_fw_req_publish_ilbo_view_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, ilbocode, langid, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_ilboctrl_initval') and constid = object_id('de_fw_req_publish_ilboctrl_initval_pkey'))
begin
	alter table de_fw_req_publish_ilboctrl_initval add constraint de_fw_req_publish_ilboctrl_initval_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, controlid, ilbocode, viewname, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_lang_bterm_synonym') and constid = object_id('de_fw_req_publish_lang_bterm_synonym_pkey'))
begin
	alter table de_fw_req_publish_lang_bterm_synonym add constraint de_fw_req_publish_lang_bterm_synonym_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, btsynonym, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_language') and constid = object_id('de_fw_req_publish_language_pkey'))
begin
	alter table de_fw_req_publish_language add constraint de_fw_req_publish_language_pkey primary key clustered (customername, projectname, ecrno, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_precision') and constid = object_id('de_fw_req_publish_precision_pkey'))
begin
	alter table de_fw_req_publish_precision add constraint de_fw_req_publish_precision_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, precisiontype)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_process') and constid = object_id('de_fw_req_publish_process_pkey'))
begin
	alter table de_fw_req_publish_process add constraint de_fw_req_publish_process_pkey primary key clustered (customername, projectname, ecrno, processname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_process_component') and constid = object_id('de_fw_req_publish_process_component_pkey'))
begin
	alter table de_fw_req_publish_process_component add constraint de_fw_req_publish_process_component_pkey primary key clustered (customername, projectname, ecrno, parentprocess, componentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_process_documentation') and constid = object_id('de_fw_req_publish_process_documentation_pkey'))
begin
	alter table de_fw_req_publish_process_documentation add constraint de_fw_req_publish_process_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_reference_value') and constid = object_id('de_fw_req_publish_reference_value_pkey'))
begin
	alter table de_fw_req_publish_reference_value add constraint de_fw_req_publish_reference_value_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid, referencetype, referencevalue)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_state') and constid = object_id('de_fw_req_publish_state_pkey'))
begin
	alter table de_fw_req_publish_state add constraint de_fw_req_publish_state_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, statename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_state_activity') and constid = object_id('de_fw_req_publish_state_activity_pkey'))
begin
	alter table de_fw_req_publish_state_activity add constraint de_fw_req_publish_state_activity_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, activityid, statename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_state_component') and constid = object_id('de_fw_req_publish_state_component_pkey'))
begin
	alter table de_fw_req_publish_state_component add constraint de_fw_req_publish_state_component_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, statename, vcname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_task') and constid = object_id('de_fw_req_publish_task_pkey'))
begin
	alter table de_fw_req_publish_task add constraint de_fw_req_publish_task_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_task_br_error_context') and constid = object_id('de_fw_req_publish_task_br_error_context_pkey'))
begin
	alter table de_fw_req_publish_task_br_error_context add constraint de_fw_req_publish_task_br_error_context_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, brsequence, errorcode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_task_documentation') and constid = object_id('de_fw_req_publish_task_documentation_pkey'))
begin
	alter table de_fw_req_publish_task_documentation add constraint de_fw_req_publish_task_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid, paragraphno, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_task_local_info') and constid = object_id('de_fw_req_publish_task_local_info_pkey'))
begin
	alter table de_fw_req_publish_task_local_info add constraint de_fw_req_publish_task_local_info_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_task_rule') and constid = object_id('de_fw_req_publish_task_rule_pkey'))
begin
	alter table de_fw_req_publish_task_rule add constraint de_fw_req_publish_task_rule_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, brsequence, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_taskrulesynonym_map') and constid = object_id('de_fw_req_publish_taskrulesynonym_map_pkey'))
begin
	alter table de_fw_req_publish_taskrulesynonym_map add constraint de_fw_req_publish_taskrulesynonym_map_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, brname, brsequence, paramno, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_value_chain') and constid = object_id('de_fw_req_publish_value_chain_pkey'))
begin
	alter table de_fw_req_publish_value_chain add constraint de_fw_req_publish_value_chain_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, vcname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_publish_vc_documentation') and constid = object_id('de_fw_req_publish_vc_documentation_pkey'))
begin
	alter table de_fw_req_publish_vc_documentation add constraint de_fw_req_publish_vc_documentation_pkey primary key clustered (customername, projectname, ecrno, processname, componentname, langid, paragraphno, vcname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_action') and constid = object_id('de_published_action_pkey'))
begin
	alter table de_published_action add constraint de_published_action_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_action_lng_extn') and constid = object_id('de_published_action_lng_extn_pkey'))
begin
	alter table de_published_action_lng_extn add constraint de_published_action_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_action_section_map') and constid = object_id('de_published_action_section_map_pkey'))
begin
	alter table de_published_action_section_map add constraint de_published_action_section_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, section_page_bt_synonym, task_name, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_bo_segment') and constid = object_id('de_published_bo_segment_pkey'))
begin
	alter table de_published_bo_segment add constraint de_published_bo_segment_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, bo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_bo_segment_dataitem') and constid = object_id('de_published_bo_segment_dataitem_pkey'))
begin
	alter table de_published_bo_segment_dataitem add constraint de_published_bo_segment_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, bo_segment_name, bo_segment_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_bo_segment_dataitem_lng_extn') and constid = object_id('de_published_bo_segment_dataitem_lng_extn_pkey'))
begin
	alter table de_published_bo_segment_dataitem_lng_extn add constraint de_published_bo_segment_dataitem_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, bo_segment_name, bo_segment_dataitem_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_bo_segment_lng_extn') and constid = object_id('de_published_bo_segment_lng_extn_pkey'))
begin
	alter table de_published_bo_segment_lng_extn add constraint de_published_bo_segment_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, bo_segment_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_object') and constid = object_id('de_published_business_object_pkey'))
begin
	alter table de_published_business_object add constraint de_published_business_object_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_object_lng_extn') and constid = object_id('de_published_business_object_lng_extn_pkey'))
begin
	alter table de_published_business_object_lng_extn add constraint de_published_business_object_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_rule') and constid = object_id('de_published_business_rule_pkey'))
begin
	alter table de_published_business_rule add constraint de_published_business_rule_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_rule_lng_extn') and constid = object_id('de_published_business_rule_lng_extn_pkey'))
begin
	alter table de_published_business_rule_lng_extn add constraint de_published_business_rule_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, br_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_term') and constid = object_id('de_published_business_term_pkey'))
begin
	alter table de_published_business_term add constraint de_published_business_term_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_business_term_lng_extn') and constid = object_id('de_published_business_term_lng_extn_pkey'))
begin
	alter table de_published_business_term_lng_extn add constraint de_published_business_term_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bt_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_chart_header') and constid = object_id('de_published_chart_header_pkey'))
begin
	alter table de_published_chart_header add constraint de_published_chart_header_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_chart_sample_data') and constid = object_id('de_published_chart_sample_data_pkey'))
begin
	alter table de_published_chart_sample_data add constraint de_published_chart_sample_data_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_chart_series') and constid = object_id('de_published_chart_series_pkey'))
begin
	alter table de_published_chart_series add constraint de_published_chart_series_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_chm_service_datatitem') and constid = object_id('de_published_chm_service_datatitem_PK'))
begin
	alter table de_published_chm_service_datatitem add constraint de_published_chm_service_datatitem_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_contextual_links') and constid = object_id('de_published_contextual_links_pkey'))
begin
	alter table de_published_contextual_links add constraint de_published_contextual_links_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_control_extensions') and constid = object_id('de_published_control_extensions_pkey'))
begin
	alter table de_published_control_extensions add constraint de_published_control_extensions_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_custom_listedit') and constid = object_id('de_published_custom_listedit_pkey'))
begin
	alter table de_published_custom_listedit add constraint de_published_custom_listedit_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_enum_value') and constid = object_id('de_published_enum_value_pkey'))
begin
	alter table de_published_enum_value add constraint de_published_enum_value_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_enum_value_lng_extn') and constid = object_id('de_published_enum_value_lng_extn_pkey'))
begin
	alter table de_published_enum_value_lng_extn add constraint de_published_enum_value_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_dtl_layout') and constid = object_id('de_published_exrep_dtl_layout_pkey'))
begin
	alter table de_published_exrep_dtl_layout add constraint de_published_exrep_dtl_layout_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, template_id, sheet_id, section_name, field_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_hdr_layout') and constid = object_id('de_published_exrep_hdr_layout_pkey'))
begin
	alter table de_published_exrep_hdr_layout add constraint de_published_exrep_hdr_layout_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, template_id, sheet_id, section_name, field_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_sections') and constid = object_id('de_published_exrep_sections_pkey'))
begin
	alter table de_published_exrep_sections add constraint de_published_exrep_sections_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, template_id, sheet_id, section_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_task_temp_map') and constid = object_id('de_published_exrep_task_temp_map_pkey'))
begin
	alter table de_published_exrep_task_temp_map add constraint de_published_exrep_task_temp_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, page_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_temp_dtl') and constid = object_id('de_published_exrep_temp_dtl_pkey'))
begin
	alter table de_published_exrep_temp_dtl add constraint de_published_exrep_temp_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, template_id, sheet_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_exrep_temp_hdr') and constid = object_id('de_published_exrep_temp_hdr_pkey'))
begin
	alter table de_published_exrep_temp_hdr add constraint de_published_exrep_temp_hdr_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecrno, activity_name, ui_name, template_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ext_js_control') and constid = object_id('de_published_ext_js_control_PK'))
begin
	alter table de_published_ext_js_control add constraint de_published_ext_js_control_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ext_js_section') and constid = object_id('de_published_ext_js_section_PK'))
begin
	alter table de_published_ext_js_section add constraint de_published_ext_js_section_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ext_js_section_column') and constid = object_id('de_published_ext_js_section_column_PK'))
begin
	alter table de_published_ext_js_section_column add constraint de_published_ext_js_section_column_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezeeview_sp') and constid = object_id('de_published_ezeeview_sp_PK'))
begin
	alter table de_published_ezeeview_sp add constraint de_published_ezeeview_sp_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezeeview_spparamlist') and constid = object_id('de_published_ezeeview_spparamlist_PK'))
begin
	alter table de_published_ezeeview_spparamlist add constraint de_published_ezeeview_spparamlist_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_res_ilbo_dataitem') and constid = object_id('de_published_ezwiz_res_ilbo_dataitem_pk'))
begin
	alter table de_published_ezwiz_res_ilbo_dataitem add constraint de_published_ezwiz_res_ilbo_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name, step_seqno, parent_ilbo_name, child_ilbo_name, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_res_step_dataitem') and constid = object_id('de_published_ezwiz_res_step_dataitem_pk'))
begin
	alter table de_published_ezwiz_res_step_dataitem add constraint de_published_ezwiz_res_step_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name, parent_step_seqno, child_step_seqno, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_wizard') and constid = object_id('de_published_ezwiz_wizard_pk'))
begin
	alter table de_published_ezwiz_wizard add constraint de_published_ezwiz_wizard_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_wizard_local_info') and constid = object_id('de_published_ezwiz_wizard_local_info_pk'))
begin
	alter table de_published_ezwiz_wizard_local_info add constraint de_published_ezwiz_wizard_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_wizard_step') and constid = object_id('de_published_ezwiz_wizard_step_pk'))
begin
	alter table de_published_ezwiz_wizard_step add constraint de_published_ezwiz_wizard_step_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name, step_seqno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ezwiz_wizard_step_local_info') and constid = object_id('de_published_ezwiz_wizard_step_local_info_pk'))
begin
	alter table de_published_ezwiz_wizard_step_local_info add constraint de_published_ezwiz_wizard_step_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, ecrno, wizard_name, step_seqno, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr') and constid = object_id('de_published_flowbr_pkey'))
begin
	alter table de_published_flowbr add constraint de_published_flowbr_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_br_error') and constid = object_id('de_published_flowbr_br_error_pkey'))
begin
	alter table de_published_flowbr_br_error add constraint de_published_flowbr_br_error_pkey primary key clustered (customer_name, project_name, process_name, ecrno, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_br_error_lng_extn') and constid = object_id('de_published_flowbr_br_error_lng_extn_pkey'))
begin
	alter table de_published_flowbr_br_error_lng_extn add constraint de_published_flowbr_br_error_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_combo') and constid = object_id('de_published_flowbr_combo_pkey'))
begin
	alter table de_published_flowbr_combo add constraint de_published_flowbr_combo_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_lng_extn') and constid = object_id('de_published_flowbr_lng_extn_pkey'))
begin
	alter table de_published_flowbr_lng_extn add constraint de_published_flowbr_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_method_map') and constid = object_id('de_published_flowbr_method_map_pkey'))
begin
	alter table de_published_flowbr_method_map add constraint de_published_flowbr_method_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_flowbr_rule_map') and constid = object_id('de_published_flowbr_rule_map_pkey'))
begin
	alter table de_published_flowbr_rule_map add constraint de_published_flowbr_rule_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_glossary') and constid = object_id('de_published_glossary_pkey'))
begin
	alter table de_published_glossary add constraint de_published_glossary_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_glossary_lng_extn') and constid = object_id('de_published_glossary_lng_extn_pkey'))
begin
	alter table de_published_glossary_lng_extn add constraint de_published_glossary_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_hidden_view') and constid = object_id('de_published_hidden_view_pkey'))
begin
	alter table de_published_hidden_view add constraint de_published_hidden_view_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_name, section_name, control_bt_synonym, hidden_view_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_hidden_view_usage') and constid = object_id('de_published_hidden_view_usage_pkey'))
begin
	alter table de_published_hidden_view_usage add constraint de_published_hidden_view_usage_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, control_page_name, control_bt_sysnonym, hidden_view_bt_sysnonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ibo_segment') and constid = object_id('de_published_ibo_segment_pkey'))
begin
	alter table de_published_ibo_segment add constraint de_published_ibo_segment_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, ibo_name, ibo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ibo_segment_dataitem') and constid = object_id('de_published_ibo_segment_dataitem_pkey'))
begin
	alter table de_published_ibo_segment_dataitem add constraint de_published_ibo_segment_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, ibo_name, ibo_segment_name, ibo_segment_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ibo_segment_dataitem_lng_extn') and constid = object_id('de_published_ibo_segment_dataitem_lng_extn_pkey'))
begin
	alter table de_published_ibo_segment_dataitem_lng_extn add constraint de_published_ibo_segment_dataitem_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, ibo_name, ibo_segment_name, ibo_segment_dataitem_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ibo_segment_lng_extn') and constid = object_id('de_published_ibo_segment_lng_extn_pkey'))
begin
	alter table de_published_ibo_segment_lng_extn add constraint de_published_ibo_segment_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, ibo_name, ibo_segment_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_interaction_bo') and constid = object_id('de_published_interaction_bo_pkey'))
begin
	alter table de_published_interaction_bo add constraint de_published_interaction_bo_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_interaction_bo_lng_extn') and constid = object_id('de_published_interaction_bo_lng_extn_pkey'))
begin
	alter table de_published_interaction_bo_lng_extn add constraint de_published_interaction_bo_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, bo_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_is_dataitem_map') and constid = object_id('de_published_is_dataitem_map_pkey'))
begin
	alter table de_published_is_dataitem_map add constraint de_published_is_dataitem_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, ps_name, is_name, called_segment_name, called_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_is_interaction') and constid = object_id('de_published_is_interaction_pkey'))
begin
	alter table de_published_is_interaction add constraint de_published_is_interaction_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, ps_name, is_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_listedit_column') and constid = object_id('de_published_listedit_column_pkey'))
begin
	alter table de_published_listedit_column add constraint de_published_listedit_column_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_listedit_control_map') and constid = object_id('de_published_listedit_control_map_pkey'))
begin
	alter table de_published_listedit_control_map add constraint de_published_listedit_control_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_LogicExt_ui_control_dtl') and constid = object_id('de_published_LogicExt_ui_control_dtl_pkey'))
begin
	alter table de_published_LogicExt_ui_control_dtl add constraint de_published_LogicExt_ui_control_dtl_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_LogicExt_ui_grid_dtl') and constid = object_id('de_published_LogicExt_ui_grid_dtl_pkey'))
begin
	alter table de_published_LogicExt_ui_grid_dtl add constraint de_published_LogicExt_ui_grid_dtl_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_message') and constid = object_id('de_published_message_pkey'))
begin
	alter table de_published_message add constraint de_published_message_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, error_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_message_lng_extn') and constid = object_id('de_published_message_lng_extn_pkey'))
begin
	alter table de_published_message_lng_extn add constraint de_published_message_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, error_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_method_doc') and constid = object_id('de_published_method_doc_pkey'))
begin
	alter table de_published_method_doc add constraint de_published_method_doc_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_method_doc_lng_extn') and constid = object_id('de_published_method_doc_lng_extn_pkey'))
begin
	alter table de_published_method_doc_lng_extn add constraint de_published_method_doc_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_method_message_map') and constid = object_id('de_published_method_message_map_pkey'))
begin
	alter table de_published_method_message_map add constraint de_published_method_message_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_method_message_map_lng_extn') and constid = object_id('de_published_method_message_map_lng_extn_pkey'))
begin
	alter table de_published_method_message_map_lng_extn add constraint de_published_method_message_map_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_nativeapp_mapping') and constid = object_id('de_published_nativeapp_mapping_PK'))
begin
	alter table de_published_nativeapp_mapping add constraint de_published_nativeapp_mapping_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_non_ui_control') and constid = object_id('de_published_non_ui_control_pkey'))
begin
	alter table de_published_non_ui_control add constraint de_published_non_ui_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone') and constid = object_id('de_published_phone_pkey'))
begin
	alter table de_published_phone add constraint de_published_phone_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone_columngroup') and constid = object_id('de_published_phone_columngroup_pkey'))
begin
	alter table de_published_phone_columngroup add constraint de_published_phone_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone_control') and constid = object_id('de_published_phone_control_pkey'))
begin
	alter table de_published_phone_control add constraint de_published_phone_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone_grid') and constid = object_id('de_published_phone_grid_pkey'))
begin
	alter table de_published_phone_grid add constraint de_published_phone_grid_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone_page') and constid = object_id('de_published_phone_page_pkey'))
begin
	alter table de_published_phone_page add constraint de_published_phone_page_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_phone_section') and constid = object_id('de_published_phone_section_pkey'))
begin
	alter table de_published_phone_section add constraint de_published_phone_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_pivot_fields') and constid = object_id('de_pivot_fields_pkey'))
begin
	alter table de_published_pivot_fields add constraint de_pivot_fields_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_precision_type') and constid = object_id('de_published_precision_type_pkey'))
begin
	alter table de_published_precision_type add constraint de_published_precision_type_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, pt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_publication') and constid = object_id('de_published_publication_pkey'))
begin
	alter table de_published_publication add constraint de_published_publication_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_publication_dataitem') and constid = object_id('de_published_publication_dataitem_pkey'))
begin
	alter table de_published_publication_dataitem add constraint de_published_publication_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_publication_lng_extn') and constid = object_id('de_published_publication_lng_extn_pkey'))
begin
	alter table de_published_publication_lng_extn add constraint de_published_publication_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, publication_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_radio_button') and constid = object_id('de_published_radio_button_pkey'))
begin
	alter table de_published_radio_button add constraint de_published_radio_button_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_radio_button_lng_extn') and constid = object_id('de_published_radio_button_lng_extn_pkey'))
begin
	alter table de_published_radio_button_lng_extn add constraint de_published_radio_button_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_chart_service_dataitem') and constid = object_id('de_published_refine_chart_service_dataitem_pkey'))
begin
	alter table de_published_refine_chart_service_dataitem add constraint de_published_refine_chart_service_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_chart_service_segment') and constid = object_id('de_published_refine_chart_service_segment_pkey'))
begin
	alter table de_published_refine_chart_service_segment add constraint de_published_refine_chart_service_segment_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_method_documentation') and constid = object_id('de_published_refine_method_documentation_pkey'))
begin
	alter table de_published_refine_method_documentation add constraint de_published_refine_method_documentation_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_method_error_map') and constid = object_id('de_published_refine_method_error_map_pkey'))
begin
	alter table de_published_refine_method_error_map add constraint de_published_refine_method_error_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, req_errorno, des_errorno, sp_errorno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_methods') and constid = object_id('de_published_refine_methods_pkey'))
begin
	alter table de_published_refine_methods add constraint de_published_refine_methods_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, ps_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_parameter') and constid = object_id('de_published_refine_parameter_pkey'))
begin
	alter table de_published_refine_parameter add constraint de_published_refine_parameter_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_refine_process_section') and constid = object_id('de_published_refine_process_section_pkey'))
begin
	alter table de_published_refine_process_section add constraint de_published_refine_process_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, service_name, ps_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_report_action_dataset_dataitem') and constid = object_id('de_published_report_action_dataset_dataitem_PK'))
begin
	alter table de_published_report_action_dataset_dataitem add constraint de_published_report_action_dataset_dataitem_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_report_action_dataset_segment') and constid = object_id('de_published_report_action_dataset_segment_PK'))
begin
	alter table de_published_report_action_dataset_segment add constraint de_published_report_action_dataset_segment_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_report_attributes') and constid = object_id('de_published_report_attributes_PK'))
begin
	alter table de_published_report_attributes add constraint de_published_report_attributes_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_report_dataset_dataitem_map') and constid = object_id('de_published_report_dataset_dataitem_map_PK'))
begin
	alter table de_published_report_dataset_dataitem_map add constraint de_published_report_dataset_dataitem_map_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name, dataset_dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_report_dataset_segment_map') and constid = object_id('de_published_report_dataset_segment_map_PK'))
begin
	alter table de_published_report_dataset_segment_map add constraint de_published_report_dataset_segment_map_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_resolved_link') and constid = object_id('de_published_resolved_link_pkey'))
begin
	alter table de_published_resolved_link add constraint de_published_resolved_link_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, subscription_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_resolved_link_dataitem') and constid = object_id('de_published_resolved_link_dataitem_pkey'))
begin
	alter table de_published_resolved_link_dataitem add constraint de_published_resolved_link_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, subscription_name, subscribed_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_resolvelist_data_map') and constid = object_id('de_published_resolvelist_data_map_pkey'))
begin
	alter table de_published_resolvelist_data_map add constraint de_published_resolvelist_data_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rmt_ico_ui') and constid = object_id('de_published_rmt_ico_ui_pkey'))
begin
	alter table de_published_rmt_ico_ui add constraint de_published_rmt_ico_ui_pkey primary key clustered (customer_name, project_name, ecrno, ico_no, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rulegroup') and constid = object_id('de_published_rulegroup_pkey'))
begin
	alter table de_published_rulegroup add constraint de_published_rulegroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rulegroup_lng_extn') and constid = object_id('de_published_rulegroup_lng_extn_pkey'))
begin
	alter table de_published_rulegroup_lng_extn add constraint de_published_rulegroup_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, brgroup_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rulegroup_step') and constid = object_id('de_published_rulegroup_step_pkey'))
begin
	alter table de_published_rulegroup_step add constraint de_published_rulegroup_step_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rulegroup_step_msg') and constid = object_id('de_published_rulegroup_step_msg_pkey'))
begin
	alter table de_published_rulegroup_step_msg add constraint de_published_rulegroup_step_msg_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_rulegroup_step_msg_lng_extn') and constid = object_id('de_published_rulegroup_step_msg_lng_extn_pkey'))
begin
	alter table de_published_rulegroup_step_msg_lng_extn add constraint de_published_rulegroup_step_msg_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, brgroup_name, step_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_column') and constid = object_id('de_published_schema_column_pkey'))
begin
	alter table de_published_schema_column add constraint de_published_schema_column_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, table_name, column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_dependentobj') and constid = object_id('de_published_schema_dependentobj_pkey'))
begin
	alter table de_published_schema_dependentobj add constraint de_published_schema_dependentobj_pkey primary key clustered (db_name, sp_name, dep_object_type, dep_object_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_function') and constid = object_id('de_published_schema_function_pkey'))
begin
	alter table de_published_schema_function add constraint de_published_schema_function_pkey primary key clustered (db_name, function_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_function_param') and constid = object_id('de_published_schema_function_param_pkey'))
begin
	alter table de_published_schema_function_param add constraint de_published_schema_function_param_pkey primary key clustered (db_name, function_name, parameter_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_index') and constid = object_id('de_published_schema_index_pkey'))
begin
	alter table de_published_schema_index add constraint de_published_schema_index_pkey primary key clustered (db_name, Index_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_index_columns') and constid = object_id('de_published_schema_index_columns_pkey'))
begin
	alter table de_published_schema_index_columns add constraint de_published_schema_index_columns_pkey primary key clustered (db_name, Index_name, Table_name, Column_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_option') and constid = object_id('de_published_schema_option_pkey'))
begin
	alter table de_published_schema_option add constraint de_published_schema_option_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, option_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_preference') and constid = object_id('de_published_schema_preference_pkey'))
begin
	alter table de_published_schema_preference add constraint de_published_schema_preference_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, entity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_relation') and constid = object_id('de_published_schema_relation_pkey'))
begin
	alter table de_published_schema_relation add constraint de_published_schema_relation_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_relation_det') and constid = object_id('de_published_schema_relation_det_pkey'))
begin
	alter table de_published_schema_relation_det add constraint de_published_schema_relation_det_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, parent_column_name, child_column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_scripts') and constid = object_id('de_published_schema_scripts_pkey'))
begin
	alter table de_published_schema_scripts add constraint de_published_schema_scripts_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, object_type, object_name, script_option)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_sp') and constid = object_id('de_published_schema_sp_pkey'))
begin
	alter table de_published_schema_sp add constraint de_published_schema_sp_pkey primary key clustered (db_name, sp_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_sp_param') and constid = object_id('de_published_schema_sp_param_pkey'))
begin
	alter table de_published_schema_sp_param add constraint de_published_schema_sp_param_pkey primary key clustered (db_name, sp_name, parameter_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_table') and constid = object_id('de_published_schema_table_pkey'))
begin
	alter table de_published_schema_table add constraint de_published_schema_table_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, table_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_udd') and constid = object_id('de_published_schema_udd_pkey'))
begin
	alter table de_published_schema_udd add constraint de_published_schema_udd_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, udd_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_validation_log') and constid = object_id('de_published_schema_validation_log_pkey'))
begin
	alter table de_published_schema_validation_log add constraint de_published_schema_validation_log_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, guid, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_view') and constid = object_id('de_published_schema_view_pkey'))
begin
	alter table de_published_schema_view add constraint de_published_schema_view_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, view_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_schema_view_column') and constid = object_id('de_published_schema_view_column_pkey'))
begin
	alter table de_published_schema_view_column add constraint de_published_schema_view_column_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, db_name, view_name, column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_scratch_variables_sys') and constid = object_id('de_published_scratch_variables_sys_pkey'))
begin
	alter table de_published_scratch_variables_sys add constraint de_published_scratch_variables_sys_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_service_gen_log') and constid = object_id('de_published_service_gen_log_pkey'))
begin
	alter table de_published_service_gen_log add constraint de_published_service_gen_log_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_service_gen_log_dtl') and constid = object_id('de_published_service_gen_log_dtl_pkey'))
begin
	alter table de_published_service_gen_log_dtl add constraint de_published_service_gen_log_dtl_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name, sequence_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_Published_service_logic_extn_dtl') and constid = object_id('de_Published_service_logic_extn_dtl_pk'))
begin
	alter table de_Published_service_logic_extn_dtl add constraint de_Published_service_logic_extn_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, ecr_no, servicename, section_name, methodid, methodname, BR_sequence, RDBMS_Type, ext_before)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_service_logic_extn_pattern') and constid = object_id('de_published_service_logic_extn_pattern_pk'))
begin
	alter table de_published_service_logic_extn_pattern add constraint de_published_service_logic_extn_pattern_pk primary key clustered (customer_name, project_name, process_name, component_name, Ecrno, RDBMS_Type, method_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_sp_report_action_dataitem') and constid = object_id('de_published_sp_report_action_dataitem_PK'))
begin
	alter table de_published_sp_report_action_dataitem add constraint de_published_sp_report_action_dataitem_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name, report_name, segment_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_sp_report_action_segment') and constid = object_id('de_published_sp_report_action_segment_PK'))
begin
	alter table de_published_sp_report_action_segment add constraint de_published_sp_report_action_segment_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name, report_name, segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_subscription') and constid = object_id('de_published_subscription_pkey'))
begin
	alter table de_published_subscription add constraint de_published_subscription_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, subscription_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_subscription_dataitem') and constid = object_id('de_published_subscription_dataitem_pkey'))
begin
	alter table de_published_subscription_dataitem add constraint de_published_subscription_dataitem_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, subscription_name, subscribed_bt_synonym, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_subscription_lng_extn') and constid = object_id('de_published_subscription_lng_extn_pkey'))
begin
	alter table de_published_subscription_lng_extn add constraint de_published_subscription_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, subscription_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet') and constid = object_id('de_published_tablet_pkey'))
begin
	alter table de_published_tablet add constraint de_published_tablet_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet_columngroup') and constid = object_id('de_published_tablet_columngroup_pkey'))
begin
	alter table de_published_tablet_columngroup add constraint de_published_tablet_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet_control') and constid = object_id('de_published_tablet_control_pkey'))
begin
	alter table de_published_tablet_control add constraint de_published_tablet_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet_grid') and constid = object_id('de_published_tablet_grid_pkey'))
begin
	alter table de_published_tablet_grid add constraint de_published_tablet_grid_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet_page') and constid = object_id('de_published_tablet_page_pkey'))
begin
	alter table de_published_tablet_page add constraint de_published_tablet_page_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_tablet_section') and constid = object_id('de_published_tablet_section_pkey'))
begin
	alter table de_published_tablet_section add constraint de_published_tablet_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_task_control_attributemap') and constid = object_id('de_published_task_control_attributemap_pkey'))
begin
	alter table de_published_task_control_attributemap add constraint de_published_task_control_attributemap_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, page_name, control_bt_synonym, propertytype, propertyname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_task_control_map') and constid = object_id('de_published_task_control_map_pkey'))
begin
	alter table de_published_task_control_map add constraint de_published_task_control_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, action_name, page_name, section_name, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_task_service_map') and constid = object_id('de_published_task_service_map_pkey'))
begin
	alter table de_published_task_service_map add constraint de_published_task_service_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui') and constid = object_id('de_published_ui_pkey'))
begin
	alter table de_published_ui add constraint de_published_ui_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_columngroup') and constid = object_id('de_published_ui_columngroup_pkey'))
begin
	alter table de_published_ui_columngroup add constraint de_published_ui_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_combolink') and constid = object_id('de_published_ui_combolink_pkey'))
begin
	alter table de_published_ui_combolink add constraint de_published_ui_combolink_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_contextmenu_task_dtl') and constid = object_id('de_published_ui_contextmenu_task_dtl_pk'))
begin
	alter table de_published_ui_contextmenu_task_dtl add constraint de_published_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, section_name, control_bt_synonym, task_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_control') and constid = object_id('de_published_ui_control_pkey'))
begin
	alter table de_published_ui_control add constraint de_published_ui_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_control_lng_extn') and constid = object_id('de_published_ui_control_lng_extn_pkey'))
begin
	alter table de_published_ui_control_lng_extn add constraint de_published_ui_control_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_device') and constid = object_id('de_published_ui_device_pkey'))
begin
	alter table de_published_ui_device add constraint de_published_ui_device_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_device_control') and constid = object_id('de_published_ui_device_control_pkey'))
begin
	alter table de_published_ui_device_control add constraint de_published_ui_device_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_device_grid') and constid = object_id('de_published_ui_device_grid_pkey'))
begin
	alter table de_published_ui_device_grid add constraint de_published_ui_device_grid_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_device_page') and constid = object_id('de_published_ui_device_page_pkey'))
begin
	alter table de_published_ui_device_page add constraint de_published_ui_device_page_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_device_section') and constid = object_id('de_published_ui_device_section_pkey'))
begin
	alter table de_published_ui_device_section add constraint de_published_ui_device_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_displaytext_lang_extn') and constid = object_id('de_published_ui_displaytext_lang_extn_pkey'))
begin
	alter table de_published_ui_displaytext_lang_extn add constraint de_published_ui_displaytext_lang_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_task_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_grid') and constid = object_id('de_published_ui_grid_pkey'))
begin
	alter table de_published_ui_grid add constraint de_published_ui_grid_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_grid_lng_extn') and constid = object_id('de_published_ui_grid_lng_extn_pkey'))
begin
	alter table de_published_ui_grid_lng_extn add constraint de_published_ui_grid_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_ico') and constid = object_id('de_published_ui_ico_pkey'))
begin
	alter table de_published_ui_ico add constraint de_published_ui_ico_pkey primary key clustered (customer_name, project_name, ecrno, ico_no, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_lng_extn') and constid = object_id('de_published_ui_lng_extn_pkey'))
begin
	alter table de_published_ui_lng_extn add constraint de_published_ui_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_page') and constid = object_id('de_published_ui_page_pkey'))
begin
	alter table de_published_ui_page add constraint de_published_ui_page_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_page_lng_extn') and constid = object_id('de_published_ui_page_lng_extn_pkey'))
begin
	alter table de_published_ui_page_lng_extn add constraint de_published_ui_page_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_pageevents') and constid = object_id('de_published_ui_pageevents_pk'))
begin
	alter table de_published_ui_pageevents add constraint de_published_ui_pageevents_pk primary key clustered (customer_name, project_name, process_name, ecrno, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_placeholder_lng_extn') and constid = object_id('de_published_ui_placeholder_lng_extn_pk'))
begin
	alter table de_published_ui_placeholder_lng_extn add constraint de_published_ui_placeholder_lng_extn_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_section') and constid = object_id('de_published_ui_section_pkey'))
begin
	alter table de_published_ui_section add constraint de_published_ui_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_section_control_map') and constid = object_id('de_published_ui_section_control_map_pkey'))
begin
	alter table de_published_ui_section_control_map add constraint de_published_ui_section_control_map_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_section_lng_extn') and constid = object_id('de_published_ui_section_lng_extn_pkey'))
begin
	alter table de_published_ui_section_lng_extn add constraint de_published_ui_section_lng_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_state') and constid = object_id('de_published_ui_state_pkey'))
begin
	alter table de_published_ui_state add constraint de_published_ui_state_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_state_control') and constid = object_id('de_published_ui_state_control_pkey'))
begin
	alter table de_published_ui_state_control add constraint de_published_ui_state_control_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_state_section') and constid = object_id('de_published_ui_state_section_pkey'))
begin
	alter table de_published_ui_state_section add constraint de_published_ui_state_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_state_task') and constid = object_id('de_published_ui_state_task_pkey'))
begin
	alter table de_published_ui_state_task add constraint de_published_ui_state_task_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_state_task_mst') and constid = object_id('de_published_ui_state_task_mst_pkey'))
begin
	alter table de_published_ui_state_task_mst add constraint de_published_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_taskpane') and constid = object_id('de_published_ui_taskpane_pk'))
begin
	alter table de_published_ui_taskpane add constraint de_published_ui_taskpane_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_toolbar') and constid = object_id('de_published_ui_toolbar_pkey'))
begin
	alter table de_published_ui_toolbar add constraint de_published_ui_toolbar_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_toolbar_group') and constid = object_id('de_published_ui_toolbar_group_pkey'))
begin
	alter table de_published_ui_toolbar_group add constraint de_published_ui_toolbar_group_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_toolbar_mapping') and constid = object_id('de_published_ui_toolbar_mapping_pkey'))
begin
	alter table de_published_ui_toolbar_mapping add constraint de_published_ui_toolbar_mapping_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_tooltip_lng_extn') and constid = object_id('de_published_ui_tooltip_lng_extn_pk'))
begin
	alter table de_published_ui_tooltip_lng_extn add constraint de_published_ui_tooltip_lng_extn_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_ui_traversal') and constid = object_id('de_published_ui_traversal_pkey'))
begin
	alter table de_published_ui_traversal add constraint de_published_ui_traversal_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_user_section') and constid = object_id('de_published_user_section_pkey'))
begin
	alter table de_published_user_section add constraint de_published_user_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_wsinp_ecn_dtl') and constid = object_id('pk_de_published_wsinp_ecn_dtl'))
begin
	alter table de_published_wsinp_ecn_dtl add constraint pk_de_published_wsinp_ecn_dtl primary key clustered (customer_code, project_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_wsinp_is_control_dtl') and constid = object_id('pk_de_published_wsinp_is_control_dtl'))
begin
	alter table de_published_wsinp_is_control_dtl add constraint pk_de_published_wsinp_is_control_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, page_code, control_name, view_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_wsinp_mypage_control_dtl') and constid = object_id('pk_de_published_wsinp_mypage_control_dtl'))
begin
	alter table de_published_wsinp_mypage_control_dtl add constraint pk_de_published_wsinp_mypage_control_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, page_code, control_name, view_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_wsinp_service_dtl') and constid = object_id('pk_de_published_wsinp_service_dtl'))
begin
	alter table de_published_wsinp_service_dtl add constraint pk_de_published_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, sequence_no, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_wsinp_task_dtl') and constid = object_id('pk_de_published_wsinp_task_dtl'))
begin
	alter table de_published_wsinp_task_dtl add constraint pk_de_published_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_appvw_dtl') and constid = object_id('pk_de_re_published_wsinp_appvw_dtl'))
begin
	alter table de_re_published_wsinp_appvw_dtl add constraint pk_de_re_published_wsinp_appvw_dtl primary key clustered (customer_code, project_code, area_code, notification_type, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_area_desc') and constid = object_id('pk_de_re_published_wsinp_area_desc'))
begin
	alter table de_re_published_wsinp_area_desc add constraint pk_de_re_published_wsinp_area_desc primary key clustered (customer_code, project_code, area_code, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_area_dtl') and constid = object_id('pk_de_re_published_wsinp_area_dtl'))
begin
	alter table de_re_published_wsinp_area_dtl add constraint pk_de_re_published_wsinp_area_dtl primary key clustered (customer_code, project_code, area_code, component_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_area_hdr') and constid = object_id('pk_de_re_published_wsinp_area_hdr'))
begin
	alter table de_re_published_wsinp_area_hdr add constraint pk_de_re_published_wsinp_area_hdr primary key clustered (customer_code, project_code, area_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_cat_desc_hdr') and constid = object_id('pk_de_re_published_wsinp_cat_desc_hdr'))
begin
	alter table de_re_published_wsinp_cat_desc_hdr add constraint pk_de_re_published_wsinp_cat_desc_hdr primary key clustered (customer_code, project_code, area_code, cat_key, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_cat_hdr') and constid = object_id('pk_de_re_published_wsinp_cat_hdr'))
begin
	alter table de_re_published_wsinp_cat_hdr add constraint pk_de_re_published_wsinp_cat_hdr primary key clustered (customer_code, project_code, area_code, cat_key, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_cat_parameters') and constid = object_id('pk_de_re_published_wsinp_cat_parameters'))
begin
	alter table de_re_published_wsinp_cat_parameters add constraint pk_de_re_published_wsinp_cat_parameters primary key clustered (customer_code, project_code, area_code, parameter_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_con_security') and constid = object_id('pk_de_re_published_wsinp_con_security'))
begin
	alter table de_re_published_wsinp_con_security add constraint pk_de_re_published_wsinp_con_security primary key clustered (consider_security, customer_code, project_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_def_msg_dtl') and constid = object_id('pk_de_re_published_wsinp_def_msg_dtl'))
begin
	alter table de_re_published_wsinp_def_msg_dtl add constraint pk_de_re_published_wsinp_def_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, notification_type, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_def_wf_setup') and constid = object_id('pk_de_re_published_wsinp_def_wf_setup'))
begin
	alter table de_re_published_wsinp_def_wf_setup add constraint pk_de_re_published_wsinp_def_wf_setup primary key clustered (customer_code, project_code, area_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_doc_flow_dtl') and constid = object_id('pk_de_re_published_wsinp_doc_flow_dtl'))
begin
	alter table de_re_published_wsinp_doc_flow_dtl add constraint pk_de_re_published_wsinp_doc_flow_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_docflow_msg_dtl') and constid = object_id('pk_de_re_published_wsinp_docflow_msg_dtl'))
begin
	alter table de_re_published_wsinp_docflow_msg_dtl add constraint pk_de_re_published_wsinp_docflow_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, notification_type, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_actcode') and constid = object_id('pk_de_re_published_wsinp_nonrvw_actcode'))
begin
	alter table de_re_published_wsinp_nonrvw_actcode add constraint pk_de_re_published_wsinp_nonrvw_actcode primary key clustered (customer_code, project_code, component_name, activity_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_actdesc') and constid = object_id('pk_de_re_published_wsinp_nonrvw_actdesc'))
begin
	alter table de_re_published_wsinp_nonrvw_actdesc add constraint pk_de_re_published_wsinp_nonrvw_actdesc primary key clustered (customer_code, project_code, component_name, activity_name, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_compcode') and constid = object_id('pk_de_re_published_wsinp_nonrvw_compcode'))
begin
	alter table de_re_published_wsinp_nonrvw_compcode add constraint pk_de_re_published_wsinp_nonrvw_compcode primary key clustered (customer_code, project_code, component_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_compdesc') and constid = object_id('pk_de_re_published_wsinp_nonrvw_compdesc'))
begin
	alter table de_re_published_wsinp_nonrvw_compdesc add constraint pk_de_re_published_wsinp_nonrvw_compdesc primary key clustered (customer_code, project_code, component_name, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_taskcode') and constid = object_id('pk_de_re_published_wsinp_nonrvw_taskcode'))
begin
	alter table de_re_published_wsinp_nonrvw_taskcode add constraint pk_de_re_published_wsinp_nonrvw_taskcode primary key clustered (customer_code, project_code, component_name, activity_name, task_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_nonrvw_taskdesc') and constid = object_id('pk_de_re_published_wsinp_nonrvw_taskdesc'))
begin
	alter table de_re_published_wsinp_nonrvw_taskdesc add constraint pk_de_re_published_wsinp_nonrvw_taskdesc primary key clustered (customer_code, project_code, component_name, activity_name, task_name, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_qc_dtl') and constid = object_id('pk_de_re_published_wsinp_qc_dtl'))
begin
	alter table de_re_published_wsinp_qc_dtl add constraint pk_de_re_published_wsinp_qc_dtl primary key clustered (wf_quick_code, wf_quick_code_type, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_qc_hdr') and constid = object_id('pk_de_re_published_wsinp_qc_hdr'))
begin
	alter table de_re_published_wsinp_qc_hdr add constraint pk_de_re_published_wsinp_qc_hdr primary key clustered (wf_quick_code_type, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_qc_lang_dtl') and constid = object_id('pk_de_re_published_wsinp_qc_lang_dtl'))
begin
	alter table de_re_published_wsinp_qc_lang_dtl add constraint pk_de_re_published_wsinp_qc_lang_dtl primary key clustered (wf_quick_code_type, wf_quick_code, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_rcn_dtl') and constid = object_id('pk_de_re_published_wsinp_rcn_dtl'))
begin
	alter table de_re_published_wsinp_rcn_dtl add constraint pk_de_re_published_wsinp_rcn_dtl primary key clustered (customer_code, project_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_security_dtl') and constid = object_id('pk_de_re_published_wsinp_security_dtl'))
begin
	alter table de_re_published_wsinp_security_dtl add constraint pk_de_re_published_wsinp_security_dtl primary key clustered (customer_code, project_code, permitted_user, component_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_secusr_dtl') and constid = object_id('pk_de_re_published_wsinp_secusr_dtl'))
begin
	alter table de_re_published_wsinp_secusr_dtl add constraint pk_de_re_published_wsinp_secusr_dtl primary key clustered (customer_code, project_code, permitted_user, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_service_dtl') and constid = object_id('pk_de_re_published_wsinp_service_dtl'))
begin
	alter table de_re_published_wsinp_service_dtl add constraint pk_de_re_published_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, cat_key, sequence_no, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_state_desc_dtl') and constid = object_id('pk_de_re_published_wsinp_state_desc_dtl'))
begin
	alter table de_re_published_wsinp_state_desc_dtl add constraint pk_de_re_published_wsinp_state_desc_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, language_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_task_dtl') and constid = object_id('pk_de_re_published_wsinp_task_dtl'))
begin
	alter table de_re_published_wsinp_task_dtl add constraint pk_de_re_published_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, cat_key, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_tsk_state_dtl') and constid = object_id('pk_de_re_published_wsinp_tsk_state_dtl'))
begin
	alter table de_re_published_wsinp_tsk_state_dtl add constraint pk_de_re_published_wsinp_tsk_state_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_tsk_stflow_dtl') and constid = object_id('pk_de_re_published_wsinp_tsk_stflow_dtl'))
begin
	alter table de_re_published_wsinp_tsk_stflow_dtl add constraint pk_de_re_published_wsinp_tsk_stflow_dtl primary key clustered (cat_key, state_name, to_cat_key, to_state, area_code, customer_code, project_code, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_published_wsinp_usr_noncon_task') and constid = object_id('pk_de_re_published_wsinp_usr_noncon_task'))
begin
	alter table de_re_published_wsinp_usr_noncon_task add constraint pk_de_re_published_wsinp_usr_noncon_task primary key clustered (customer_code, project_code, area_code, cat_key, calling_catkey, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('dtproperties') and constid = object_id('pk_dtproperties'))
begin
	alter table dtproperties add constraint pk_dtproperties primary key clustered (id, property)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_action_mst') and constid = object_id('ep_published_action_mst_pkey'))
begin
	alter table ep_published_action_mst add constraint ep_published_action_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_action_mst_lng_extn') and constid = object_id('ep_published_action_mst_lng_extn_pkey'))
begin
	alter table ep_published_action_mst_lng_extn add constraint ep_published_action_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_action_section_map') and constid = object_id('ep_published_action_section_map_pkey'))
begin
	alter table ep_published_action_section_map add constraint ep_published_action_section_map_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, section_page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_chart_header') and constid = object_id('ep_published_chart_header_pkey'))
begin
	alter table ep_published_chart_header add constraint ep_published_chart_header_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, req_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_chart_sample_data') and constid = object_id('ep_published_chart_sample_data_pkey'))
begin
	alter table ep_published_chart_sample_data add constraint ep_published_chart_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, req_no, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_chart_series') and constid = object_id('ep_published_chart_series_pkey'))
begin
	alter table ep_published_chart_series add constraint ep_published_chart_series_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, req_no, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_comp_glossary_mst') and constid = object_id('ep_published_comp_glossary_mst_pkey'))
begin
	alter table ep_published_comp_glossary_mst add constraint ep_published_comp_glossary_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_comp_glossary_mst_lng_extn') and constid = object_id('ep_published_comp_glossary_mst_lng_extn_pkey'))
begin
	alter table ep_published_comp_glossary_mst_lng_extn add constraint ep_published_comp_glossary_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_contextual_links') and constid = object_id('ep_published_contextual_links_pkey'))
begin
	alter table ep_published_contextual_links add constraint ep_published_contextual_links_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_control_extensions') and constid = object_id('ep_published_control_extensions_pkey'))
begin
	alter table ep_published_control_extensions add constraint ep_published_control_extensions_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_custom_listedit') and constid = object_id('ep_published_custom_listedit_pkey'))
begin
	alter table ep_published_custom_listedit add constraint ep_published_custom_listedit_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_enum_value_dtl') and constid = object_id('ep_published_enum_value_dtl_pkey'))
begin
	alter table ep_published_enum_value_dtl add constraint ep_published_enum_value_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_enum_value_dtl_lng_extn') and constid = object_id('ep_published_enum_value_dtl_lng_extn_pkey'))
begin
	alter table ep_published_enum_value_dtl_lng_extn add constraint ep_published_enum_value_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ext_js_control_dtl') and constid = object_id('ep_published_ext_js_control_dtl_PK'))
begin
	alter table ep_published_ext_js_control_dtl add constraint ep_published_ext_js_control_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ext_js_section_column_dtl') and constid = object_id('ep_published_ext_js_section_column_dtl_PK'))
begin
	alter table ep_published_ext_js_section_column_dtl add constraint ep_published_ext_js_section_column_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ext_js_section_dtl') and constid = object_id('ep_published_ext_js_section_dtl_PK'))
begin
	alter table ep_published_ext_js_section_dtl add constraint ep_published_ext_js_section_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ezeeview_sp') and constid = object_id('ep_published_ezeeview_sp_PK'))
begin
	alter table ep_published_ezeeview_sp add constraint ep_published_ezeeview_sp_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ezeeview_spparamlist') and constid = object_id('ep_published_ezeeview_spparamlist_PK'))
begin
	alter table ep_published_ezeeview_spparamlist add constraint ep_published_ezeeview_spparamlist_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_flowbr_mst') and constid = object_id('ep_published_flowbr_mst_pkey'))
begin
	alter table ep_published_flowbr_mst add constraint ep_published_flowbr_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_glossary_mst') and constid = object_id('ep_published_glossary_mst_pkey'))
begin
	alter table ep_published_glossary_mst add constraint ep_published_glossary_mst_pkey primary key clustered (customer_name, project_name, req_no, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_glossary_mst_lng_extn') and constid = object_id('ep_published_glossary_mst_lng_extn_pkey'))
begin
	alter table ep_published_glossary_mst_lng_extn add constraint ep_published_glossary_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_listedit_column_dtl') and constid = object_id('ep_published_listedit_column_dtl_pkey'))
begin
	alter table ep_published_listedit_column_dtl add constraint ep_published_listedit_column_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_listedit_control_map') and constid = object_id('ep_published_listedit_control_map_pkey'))
begin
	alter table ep_published_listedit_control_map add constraint ep_published_listedit_control_map_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_nativeapp_mapping') and constid = object_id('ep_published_nativeapp_mapping_PK'))
begin
	alter table ep_published_nativeapp_mapping add constraint ep_published_nativeapp_mapping_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_columngroup') and constid = object_id('ep_published_phone_columngroup_pkey'))
begin
	alter table ep_published_phone_columngroup add constraint ep_published_phone_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_control_dtl') and constid = object_id('ep_published_phone_control_dtl_pkey'))
begin
	alter table ep_published_phone_control_dtl add constraint ep_published_phone_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_grid_dtl') and constid = object_id('ep_published_phone_grid_dtl_pkey'))
begin
	alter table ep_published_phone_grid_dtl add constraint ep_published_phone_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_mst') and constid = object_id('ep_published_phone_mst_pkey'))
begin
	alter table ep_published_phone_mst add constraint ep_published_phone_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_page_dtl') and constid = object_id('ep_published_phone_page_dtl_pkey'))
begin
	alter table ep_published_phone_page_dtl add constraint ep_published_phone_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_phone_section_dtl') and constid = object_id('ep_published_phone_section_dtl_pkey'))
begin
	alter table ep_published_phone_section_dtl add constraint ep_published_phone_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_pivot_fields') and constid = object_id('ep_pivot_fields_pkey'))
begin
	alter table ep_published_pivot_fields add constraint ep_pivot_fields_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_radio_button_dtl') and constid = object_id('ep_published_radio_button_dtl_pkey'))
begin
	alter table ep_published_radio_button_dtl add constraint ep_published_radio_button_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_radio_button_dtl_lng_extn') and constid = object_id('ep_published_radio_button_dtl_lng_extn_pkey'))
begin
	alter table ep_published_radio_button_dtl_lng_extn add constraint ep_published_radio_button_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_resolvelist_data_map') and constid = object_id('ep_published_resolvelist_data_map_pkey'))
begin
	alter table ep_published_resolvelist_data_map add constraint ep_published_resolvelist_data_map_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_columngroup') and constid = object_id('ep_published_tablet_columngroup_pkey'))
begin
	alter table ep_published_tablet_columngroup add constraint ep_published_tablet_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_control_dtl') and constid = object_id('ep_published_tablet_control_dtl_pkey'))
begin
	alter table ep_published_tablet_control_dtl add constraint ep_published_tablet_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_grid_dtl') and constid = object_id('ep_published_tablet_grid_dtl_pkey'))
begin
	alter table ep_published_tablet_grid_dtl add constraint ep_published_tablet_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_mst') and constid = object_id('ep_published_tablet_mst_pkey'))
begin
	alter table ep_published_tablet_mst add constraint ep_published_tablet_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_page_dtl') and constid = object_id('ep_published_tablet_page_dtl_pkey'))
begin
	alter table ep_published_tablet_page_dtl add constraint ep_published_tablet_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tablet_section_dtl') and constid = object_id('ep_published_tablet_section_dtl_pkey'))
begin
	alter table ep_published_tablet_section_dtl add constraint ep_published_tablet_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_tree_sample_data') and constid = object_id('ep_published_tree_sample_data_pkey'))
begin
	alter table ep_published_tree_sample_data add constraint ep_published_tree_sample_data_pkey primary key clustered (customer_name, project_name, process_name, req_no, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, Node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_columngroup') and constid = object_id('ep_published_ui_columngroup_pkey'))
begin
	alter table ep_published_ui_columngroup add constraint ep_published_ui_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_combolink_dtl') and constid = object_id('ep_published_ui_combolink_dtl_pkey'))
begin
	alter table ep_published_ui_combolink_dtl add constraint ep_published_ui_combolink_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_contextmenu_task_dtl') and constid = object_id('ep_published_ui_contextmenu_task_dtl_pk'))
begin
	alter table ep_published_ui_contextmenu_task_dtl add constraint ep_published_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_control_dtl') and constid = object_id('ep_published_ui_control_dtl_pkey'))
begin
	alter table ep_published_ui_control_dtl add constraint ep_published_ui_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_control_dtl_lng_extn') and constid = object_id('ep_published_ui_control_dtl_lng_extn_pkey'))
begin
	alter table ep_published_ui_control_dtl_lng_extn add constraint ep_published_ui_control_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_device_control_dtl') and constid = object_id('ep_published_ui_device_control_dtl_pkey'))
begin
	alter table ep_published_ui_device_control_dtl add constraint ep_published_ui_device_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_device_dtl') and constid = object_id('ep_published_ui_device_dtl_pkey'))
begin
	alter table ep_published_ui_device_dtl add constraint ep_published_ui_device_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_device_grid_dtl') and constid = object_id('ep_published_ui_device_grid_dtl_pkey'))
begin
	alter table ep_published_ui_device_grid_dtl add constraint ep_published_ui_device_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_device_page_dtl') and constid = object_id('ep_published_ui_device_page_dtl_pkey'))
begin
	alter table ep_published_ui_device_page_dtl add constraint ep_published_ui_device_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_device_section_dtl') and constid = object_id('ep_published_ui_device_section_dtl_pkey'))
begin
	alter table ep_published_ui_device_section_dtl add constraint ep_published_ui_device_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_displaytext_lang_extn') and constid = object_id('ep_published_ui_displaytext_lang_extn_pkey'))
begin
	alter table ep_published_ui_displaytext_lang_extn add constraint ep_published_ui_displaytext_lang_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_task_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_grid_dtl') and constid = object_id('ep_published_ui_grid_dtl_pkey'))
begin
	alter table ep_published_ui_grid_dtl add constraint ep_published_ui_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_grid_dtl_lng_extn') and constid = object_id('ep_published_ui_grid_dtl_lng_extn_pkey'))
begin
	alter table ep_published_ui_grid_dtl_lng_extn add constraint ep_published_ui_grid_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_mst') and constid = object_id('ep_published_ui_mst_pkey'))
begin
	alter table ep_published_ui_mst add constraint ep_published_ui_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_mst_lng_extn') and constid = object_id('ep_published_ui_mst_lng_extn_pkey'))
begin
	alter table ep_published_ui_mst_lng_extn add constraint ep_published_ui_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_page_dtl') and constid = object_id('ep_published_ui_page_dtl_pkey'))
begin
	alter table ep_published_ui_page_dtl add constraint ep_published_ui_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_page_dtl_lng_extn') and constid = object_id('ep_published_ui_page_dtl_lng_extn_pkey'))
begin
	alter table ep_published_ui_page_dtl_lng_extn add constraint ep_published_ui_page_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_pageevents_dtl') and constid = object_id('ep_published_ui_pageevents_dtl_pk'))
begin
	alter table ep_published_ui_pageevents_dtl add constraint ep_published_ui_pageevents_dtl_pk primary key clustered (customer_name, project_name, process_name, req_no, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_placeholder_dtl_lng_extn') and constid = object_id('ep_published_ui_placeholder_dtl_lng_extn_pk'))
begin
	alter table ep_published_ui_placeholder_dtl_lng_extn add constraint ep_published_ui_placeholder_dtl_lng_extn_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_section_control_map_dtl') and constid = object_id('ep_published_ui_section_control_map_dtl_pkey'))
begin
	alter table ep_published_ui_section_control_map_dtl add constraint ep_published_ui_section_control_map_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_section_dtl') and constid = object_id('ep_published_ui_section_dtl_pkey'))
begin
	alter table ep_published_ui_section_dtl add constraint ep_published_ui_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_section_dtl_lng_extn') and constid = object_id('ep_published_ui_section_dtl_lng_extn_pkey'))
begin
	alter table ep_published_ui_section_dtl_lng_extn add constraint ep_published_ui_section_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_state_control_dtl') and constid = object_id('ep_published_ui_state_control_dtl_pkey'))
begin
	alter table ep_published_ui_state_control_dtl add constraint ep_published_ui_state_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_state_dtl') and constid = object_id('ep_published_ui_state_dtl_pkey'))
begin
	alter table ep_published_ui_state_dtl add constraint ep_published_ui_state_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_state_section_dtl') and constid = object_id('ep_published_ui_state_section_dtl_pkey'))
begin
	alter table ep_published_ui_state_section_dtl add constraint ep_published_ui_state_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_state_task_dtl') and constid = object_id('ep_published_ui_state_task_dtl_pkey'))
begin
	alter table ep_published_ui_state_task_dtl add constraint ep_published_ui_state_task_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_state_task_mst') and constid = object_id('ep_published_ui_state_task_mst_pkey'))
begin
	alter table ep_published_ui_state_task_mst add constraint ep_published_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_toolbar_dtl') and constid = object_id('ep_published_ui_toolbar_dtl_pkey'))
begin
	alter table ep_published_ui_toolbar_dtl add constraint ep_published_ui_toolbar_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_toolbar_group_dtl') and constid = object_id('ep_published_ui_toolbar_group_dtl_pkey'))
begin
	alter table ep_published_ui_toolbar_group_dtl add constraint ep_published_ui_toolbar_group_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_toolbar_mapping_dtl') and constid = object_id('ep_published_ui_toolbar_mapping_dtl_pkey'))
begin
	alter table ep_published_ui_toolbar_mapping_dtl add constraint ep_published_ui_toolbar_mapping_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_tooltip_dtl_lng_extn') and constid = object_id('ep_published_ui_tooltip_dtl_lng_extn_pk'))
begin
	alter table ep_published_ui_tooltip_dtl_lng_extn add constraint ep_published_ui_tooltip_dtl_lng_extn_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_ui_traversal_dtl') and constid = object_id('ep_published_ui_traversal_dtl_pkey'))
begin
	alter table ep_published_ui_traversal_dtl add constraint ep_published_ui_traversal_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_user_section_dtl') and constid = object_id('ep_published_user_section_dtl_pkey'))
begin
	alter table ep_published_user_section_dtl add constraint ep_published_user_section_dtl_pkey primary key clustered (customer_name, project_name, reqno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_action') and constid = object_id('re_published_action_pkey'))
begin
	alter table re_published_action add constraint re_published_action_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_action_lng_extn') and constid = object_id('re_published_action_lng_extn_pkey'))
begin
	alter table re_published_action_lng_extn add constraint re_published_action_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_action_section_map') and constid = object_id('re_published_action_section_map_pkey'))
begin
	alter table re_published_action_section_map add constraint re_published_action_section_map_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, section_page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_business_rule') and constid = object_id('re_published_business_rule_pkey'))
begin
	alter table re_published_business_rule add constraint re_published_business_rule_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_business_rule_lng_extn') and constid = object_id('re_published_business_rule_lng_extn_pkey'))
begin
	alter table re_published_business_rule_lng_extn add constraint re_published_business_rule_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, br_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_chart_header') and constid = object_id('re_published_chart_header_pkey'))
begin
	alter table re_published_chart_header add constraint re_published_chart_header_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_chart_sample_data') and constid = object_id('re_published_chart_sample_data_pkey'))
begin
	alter table re_published_chart_sample_data add constraint re_published_chart_sample_data_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_chart_series') and constid = object_id('re_published_chart_series_pkey'))
begin
	alter table re_published_chart_series add constraint re_published_chart_series_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_contextual_links') and constid = object_id('re_published_contextual_links_pkey'))
begin
	alter table re_published_contextual_links add constraint re_published_contextual_links_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_control_extensions') and constid = object_id('re_published_control_extensions_pkey'))
begin
	alter table re_published_control_extensions add constraint re_published_control_extensions_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_custom_listedit') and constid = object_id('re_published_custom_listedit_pkey'))
begin
	alter table re_published_custom_listedit add constraint re_published_custom_listedit_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_enum_value') and constid = object_id('re_published_enum_value_pkey'))
begin
	alter table re_published_enum_value add constraint re_published_enum_value_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_enum_value_lng_extn') and constid = object_id('re_published_enum_value_lng_extn_pkey'))
begin
	alter table re_published_enum_value_lng_extn add constraint re_published_enum_value_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ext_js_control') and constid = object_id('re_published_ext_js_control_PK'))
begin
	alter table re_published_ext_js_control add constraint re_published_ext_js_control_PK primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ext_js_section') and constid = object_id('re_published_ext_js_section_PK'))
begin
	alter table re_published_ext_js_section add constraint re_published_ext_js_section_PK primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ext_js_section_column') and constid = object_id('re_published_ext_js_section_column_PK'))
begin
	alter table re_published_ext_js_section_column add constraint re_published_ext_js_section_column_PK primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezeeview_sp') and constid = object_id('re_published_ezeeview_sp_PK'))
begin
	alter table re_published_ezeeview_sp add constraint re_published_ezeeview_sp_PK primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezeeview_spparamlist') and constid = object_id('re_published_ezeeview_spparamlist_PK'))
begin
	alter table re_published_ezeeview_spparamlist add constraint re_published_ezeeview_spparamlist_PK primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_res_ilbo_dataitem') and constid = object_id('re_published_ezwiz_res_ilbo_dataitem_pk'))
begin
	alter table re_published_ezwiz_res_ilbo_dataitem add constraint re_published_ezwiz_res_ilbo_dataitem_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name, step_seqno, parent_ilbo_name, child_ilbo_name, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_res_step_dataitem') and constid = object_id('re_published_ezwiz_res_step_dataitem_pk'))
begin
	alter table re_published_ezwiz_res_step_dataitem add constraint re_published_ezwiz_res_step_dataitem_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name, parent_step_seqno, child_step_seqno, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_wizard') and constid = object_id('re_published_ezwiz_wizard_pk'))
begin
	alter table re_published_ezwiz_wizard add constraint re_published_ezwiz_wizard_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_wizard_local_info') and constid = object_id('re_published_ezwiz_wizard_local_info_pk'))
begin
	alter table re_published_ezwiz_wizard_local_info add constraint re_published_ezwiz_wizard_local_info_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_wizard_step') and constid = object_id('re_published_ezwiz_wizard_step_pk'))
begin
	alter table re_published_ezwiz_wizard_step add constraint re_published_ezwiz_wizard_step_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name, step_seqno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ezwiz_wizard_step_local_info') and constid = object_id('re_published_ezwiz_wizard_step_local_info_pk'))
begin
	alter table re_published_ezwiz_wizard_step_local_info add constraint re_published_ezwiz_wizard_step_local_info_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, wizard_name, step_seqno, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr') and constid = object_id('re_published_flowbr_pkey'))
begin
	alter table re_published_flowbr add constraint re_published_flowbr_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr_br_error') and constid = object_id('re_published_flowbr_br_error_pkey'))
begin
	alter table re_published_flowbr_br_error add constraint re_published_flowbr_br_error_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr_br_error_lng_extn') and constid = object_id('re_published_flowbr_br_error_lng_extn_pkey'))
begin
	alter table re_published_flowbr_br_error_lng_extn add constraint re_published_flowbr_br_error_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr_combo') and constid = object_id('re_published_flowbr_combo_pkey'))
begin
	alter table re_published_flowbr_combo add constraint re_published_flowbr_combo_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr_lng_extn') and constid = object_id('re_published_flowbr_lng_extn_pkey'))
begin
	alter table re_published_flowbr_lng_extn add constraint re_published_flowbr_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_flowbr_rule_map') and constid = object_id('re_published_flowbr_rule_map_pkey'))
begin
	alter table re_published_flowbr_rule_map add constraint re_published_flowbr_rule_map_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_glossary') and constid = object_id('re_published_glossary_pkey'))
begin
	alter table re_published_glossary add constraint re_published_glossary_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecr_no, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_glossary_lng_extn') and constid = object_id('re_published_glossary_lng_extn_pkey'))
begin
	alter table re_published_glossary_lng_extn add constraint re_published_glossary_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, ecr_no, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_listedit_column') and constid = object_id('re_published_listedit_column_pkey'))
begin
	alter table re_published_listedit_column add constraint re_published_listedit_column_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_listedit_control_map') and constid = object_id('re_published_listedit_control_map_pkey'))
begin
	alter table re_published_listedit_control_map add constraint re_published_listedit_control_map_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_message') and constid = object_id('re_published_message_pkey'))
begin
	alter table re_published_message add constraint re_published_message_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, error_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_message_lng_extn') and constid = object_id('re_published_message_lng_extn_pkey'))
begin
	alter table re_published_message_lng_extn add constraint re_published_message_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, error_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_nativeapp_mapping') and constid = object_id('re_published_nativeapp_mapping_PK'))
begin
	alter table re_published_nativeapp_mapping add constraint re_published_nativeapp_mapping_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_non_ui_control') and constid = object_id('re_published_non_ui_control_pkey'))
begin
	alter table re_published_non_ui_control add constraint re_published_non_ui_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone') and constid = object_id('re_published_phone_pkey'))
begin
	alter table re_published_phone add constraint re_published_phone_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone_columngroup') and constid = object_id('re_published_phone_columngroup_pkey'))
begin
	alter table re_published_phone_columngroup add constraint re_published_phone_columngroup_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone_control') and constid = object_id('re_published_phone_control_pkey'))
begin
	alter table re_published_phone_control add constraint re_published_phone_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone_grid') and constid = object_id('re_published_phone_grid_pkey'))
begin
	alter table re_published_phone_grid add constraint re_published_phone_grid_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone_page') and constid = object_id('re_published_phone_page_pkey'))
begin
	alter table re_published_phone_page add constraint re_published_phone_page_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_phone_section') and constid = object_id('re_published_phone_section_pkey'))
begin
	alter table re_published_phone_section add constraint re_published_phone_section_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_pivot_fields') and constid = object_id('re_pivot_fields_pkey'))
begin
	alter table re_published_pivot_fields add constraint re_pivot_fields_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_publication') and constid = object_id('re_published_publication_pkey'))
begin
	alter table re_published_publication add constraint re_published_publication_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_publication_dataitem') and constid = object_id('re_published_publication_dataitem_pkey'))
begin
	alter table re_published_publication_dataitem add constraint re_published_publication_dataitem_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_publication_lng_extn') and constid = object_id('re_published_publication_lng_extn_pkey'))
begin
	alter table re_published_publication_lng_extn add constraint re_published_publication_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, publication_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_radio_button') and constid = object_id('re_published_radio_button_pkey'))
begin
	alter table re_published_radio_button add constraint re_published_radio_button_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_radio_button_lng_extn') and constid = object_id('re_published_radio_button_lng_extn_pkey'))
begin
	alter table re_published_radio_button_lng_extn add constraint re_published_radio_button_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_report_action_dataset') and constid = object_id('re_published_report_action_dataset_pkey'))
begin
	alter table re_published_report_action_dataset add constraint re_published_report_action_dataset_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, action_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_resolved_link') and constid = object_id('re_published_resolved_link_pkey'))
begin
	alter table re_published_resolved_link add constraint re_published_resolved_link_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, subscription_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_resolved_link_dataitem') and constid = object_id('re_published_resolved_link_dataitem_pkey'))
begin
	alter table re_published_resolved_link_dataitem add constraint re_published_resolved_link_dataitem_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, subscription_name, subscribed_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_resolvelist_data_map') and constid = object_id('re_published_resolvelist_data_map_pkey'))
begin
	alter table re_published_resolvelist_data_map add constraint re_published_resolvelist_data_map_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_rulegroup') and constid = object_id('re_published_rulegroup_pkey'))
begin
	alter table re_published_rulegroup add constraint re_published_rulegroup_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_rulegroup_lng_extn') and constid = object_id('re_published_rulegroup_lng_extn_pkey'))
begin
	alter table re_published_rulegroup_lng_extn add constraint re_published_rulegroup_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, brgroup_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_rulegroup_step') and constid = object_id('re_published_rulegroup_step_pkey'))
begin
	alter table re_published_rulegroup_step add constraint re_published_rulegroup_step_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_rulegroup_step_msg') and constid = object_id('re_published_rulegroup_step_msg_pkey'))
begin
	alter table re_published_rulegroup_step_msg add constraint re_published_rulegroup_step_msg_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_rulegroup_step_msg_lng_extn') and constid = object_id('re_published_rulegroup_step_msg_lng_extn_pkey'))
begin
	alter table re_published_rulegroup_step_msg_lng_extn add constraint re_published_rulegroup_step_msg_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, brgroup_name, step_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_subscription') and constid = object_id('re_published_subscription_pkey'))
begin
	alter table re_published_subscription add constraint re_published_subscription_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, subscription_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_subscription_dataitem') and constid = object_id('re_published_subscription_dataitem_pkey'))
begin
	alter table re_published_subscription_dataitem add constraint re_published_subscription_dataitem_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, subscription_name, subscribed_bt_synonym, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_subscription_lng_extn') and constid = object_id('re_published_subscription_lng_extn_pkey'))
begin
	alter table re_published_subscription_lng_extn add constraint re_published_subscription_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, subscription_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet') and constid = object_id('re_published_tablet_pkey'))
begin
	alter table re_published_tablet add constraint re_published_tablet_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet_columngroup') and constid = object_id('re_published_tablet_columngroup_pkey'))
begin
	alter table re_published_tablet_columngroup add constraint re_published_tablet_columngroup_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet_control') and constid = object_id('re_published_tablet_control_pkey'))
begin
	alter table re_published_tablet_control add constraint re_published_tablet_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet_grid') and constid = object_id('re_published_tablet_grid_pkey'))
begin
	alter table re_published_tablet_grid add constraint re_published_tablet_grid_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet_page') and constid = object_id('re_published_tablet_page_pkey'))
begin
	alter table re_published_tablet_page add constraint re_published_tablet_page_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_tablet_section') and constid = object_id('re_published_tablet_section_pkey'))
begin
	alter table re_published_tablet_section add constraint re_published_tablet_section_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui') and constid = object_id('re_published_ui_pkey'))
begin
	alter table re_published_ui add constraint re_published_ui_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_columngroup') and constid = object_id('re_published_ui_columngroup_pkey'))
begin
	alter table re_published_ui_columngroup add constraint re_published_ui_columngroup_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_combolink') and constid = object_id('re_published_ui_combolink_pkey'))
begin
	alter table re_published_ui_combolink add constraint re_published_ui_combolink_pkey primary key clustered (customer_name, project_name, rcno, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_contextmenu_task_dtl') and constid = object_id('re_published_ui_contextmenu_task_dtl_pk'))
begin
	alter table re_published_ui_contextmenu_task_dtl add constraint re_published_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, task_name, rcn_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_control') and constid = object_id('re_published_ui_control_pkey'))
begin
	alter table re_published_ui_control add constraint re_published_ui_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_control_lng_extn') and constid = object_id('re_published_ui_control_lng_extn_pkey'))
begin
	alter table re_published_ui_control_lng_extn add constraint re_published_ui_control_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_device') and constid = object_id('re_published_ui_device_pkey'))
begin
	alter table re_published_ui_device add constraint re_published_ui_device_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_device_control') and constid = object_id('re_published_ui_device_control_pkey'))
begin
	alter table re_published_ui_device_control add constraint re_published_ui_device_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_device_grid') and constid = object_id('re_published_ui_device_grid_pkey'))
begin
	alter table re_published_ui_device_grid add constraint re_published_ui_device_grid_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_device_page') and constid = object_id('re_published_ui_device_page_pkey'))
begin
	alter table re_published_ui_device_page add constraint re_published_ui_device_page_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_device_section') and constid = object_id('re_published_ui_device_section_pkey'))
begin
	alter table re_published_ui_device_section add constraint re_published_ui_device_section_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_displaytext_lang_extn') and constid = object_id('re_published_ui_displaytext_lang_extn_pkey'))
begin
	alter table re_published_ui_displaytext_lang_extn add constraint re_published_ui_displaytext_lang_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_task_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_grid') and constid = object_id('re_published_ui_grid_pkey'))
begin
	alter table re_published_ui_grid add constraint re_published_ui_grid_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_grid_lng_extn') and constid = object_id('re_published_ui_grid_lng_extn_pkey'))
begin
	alter table re_published_ui_grid_lng_extn add constraint re_published_ui_grid_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_lng_extn') and constid = object_id('re_published_ui_lng_extn_pkey'))
begin
	alter table re_published_ui_lng_extn add constraint re_published_ui_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_page') and constid = object_id('re_published_ui_page_pkey'))
begin
	alter table re_published_ui_page add constraint re_published_ui_page_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_page_lng_extn') and constid = object_id('re_published_ui_page_lng_extn_pkey'))
begin
	alter table re_published_ui_page_lng_extn add constraint re_published_ui_page_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_pageevents') and constid = object_id('re_published_ui_pageevents_pk'))
begin
	alter table re_published_ui_pageevents add constraint re_published_ui_pageevents_pk primary key clustered (customer_name, project_name, process_name, ecr_no, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_placeholder_lng_extn') and constid = object_id('re_published_ui_placeholder_lng_extn_pk'))
begin
	alter table re_published_ui_placeholder_lng_extn add constraint re_published_ui_placeholder_lng_extn_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_section') and constid = object_id('re_published_ui_section_pkey'))
begin
	alter table re_published_ui_section add constraint re_published_ui_section_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_section_control_map') and constid = object_id('re_published_ui_section_control_map_pkey'))
begin
	alter table re_published_ui_section_control_map add constraint re_published_ui_section_control_map_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_section_lng_extn') and constid = object_id('re_published_ui_section_lng_extn_pkey'))
begin
	alter table re_published_ui_section_lng_extn add constraint re_published_ui_section_lng_extn_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_state') and constid = object_id('re_published_ui_state_pkey'))
begin
	alter table re_published_ui_state add constraint re_published_ui_state_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_state_control') and constid = object_id('re_published_ui_state_control_pkey'))
begin
	alter table re_published_ui_state_control add constraint re_published_ui_state_control_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_state_section') and constid = object_id('re_published_ui_state_section_pkey'))
begin
	alter table re_published_ui_state_section add constraint re_published_ui_state_section_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_state_task') and constid = object_id('re_published_ui_state_task_pkey'))
begin
	alter table re_published_ui_state_task add constraint re_published_ui_state_task_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_state_task_mst') and constid = object_id('re_published_ui_state_task_mst_pkey'))
begin
	alter table re_published_ui_state_task_mst add constraint re_published_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_toolbar') and constid = object_id('re_published_ui_toolbar_pkey'))
begin
	alter table re_published_ui_toolbar add constraint re_published_ui_toolbar_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_toolbar_group') and constid = object_id('re_published_ui_toolbar_group_pkey'))
begin
	alter table re_published_ui_toolbar_group add constraint re_published_ui_toolbar_group_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_toolbar_mapping') and constid = object_id('re_published_ui_toolbar_mapping_pkey'))
begin
	alter table re_published_ui_toolbar_mapping add constraint re_published_ui_toolbar_mapping_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_tooltip_lng_extn') and constid = object_id('re_published_ui_tooltip_lng_extn_pk'))
begin
	alter table re_published_ui_tooltip_lng_extn add constraint re_published_ui_tooltip_lng_extn_pk primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_ui_traversal') and constid = object_id('re_published_ui_traversal_pkey'))
begin
	alter table re_published_ui_traversal add constraint re_published_ui_traversal_pkey primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_user_section') and constid = object_id('re_published_user_section_pkey'))
begin
	alter table re_published_user_section add constraint re_published_user_section_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_appvw_dtl') and constid = object_id('pk_re_published_wsinp_appvw_dtl'))
begin
	alter table re_published_wsinp_appvw_dtl add constraint pk_re_published_wsinp_appvw_dtl primary key clustered (customer_code, project_code, area_code, notification_type, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_area_desc') and constid = object_id('pk_re_published_wsinp_area_desc'))
begin
	alter table re_published_wsinp_area_desc add constraint pk_re_published_wsinp_area_desc primary key clustered (customer_code, project_code, area_code, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_area_dtl') and constid = object_id('pk_re_published_wsinp_area_dtl'))
begin
	alter table re_published_wsinp_area_dtl add constraint pk_re_published_wsinp_area_dtl primary key clustered (customer_code, project_code, area_code, component_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_area_hdr') and constid = object_id('pk_re_published_wsinp_area_hdr'))
begin
	alter table re_published_wsinp_area_hdr add constraint pk_re_published_wsinp_area_hdr primary key clustered (customer_code, project_code, area_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_cat_desc_hdr') and constid = object_id('pk_re_published_wsinp_cat_desc_hdr'))
begin
	alter table re_published_wsinp_cat_desc_hdr add constraint pk_re_published_wsinp_cat_desc_hdr primary key clustered (customer_code, project_code, area_code, cat_key, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_cat_hdr') and constid = object_id('pk_re_published_wsinp_cat_hdr'))
begin
	alter table re_published_wsinp_cat_hdr add constraint pk_re_published_wsinp_cat_hdr primary key clustered (customer_code, project_code, area_code, cat_key, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_cat_parameters') and constid = object_id('pk_re_published_wsinp_cat_parameters'))
begin
	alter table re_published_wsinp_cat_parameters add constraint pk_re_published_wsinp_cat_parameters primary key clustered (customer_code, project_code, area_code, parameter_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_con_security') and constid = object_id('pk_re_published_wsinp_con_security'))
begin
	alter table re_published_wsinp_con_security add constraint pk_re_published_wsinp_con_security primary key clustered (consider_security, customer_code, project_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_def_msg_dtl') and constid = object_id('pk_re_published_wsinp_def_msg_dtl'))
begin
	alter table re_published_wsinp_def_msg_dtl add constraint pk_re_published_wsinp_def_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, notification_type, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_def_wf_setup') and constid = object_id('pk_re_published_wsinp_def_wf_setup'))
begin
	alter table re_published_wsinp_def_wf_setup add constraint pk_re_published_wsinp_def_wf_setup primary key clustered (customer_code, project_code, area_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_doc_flow_dtl') and constid = object_id('pk_re_published_wsinp_doc_flow_dtl'))
begin
	alter table re_published_wsinp_doc_flow_dtl add constraint pk_re_published_wsinp_doc_flow_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_docflow_msg_dtl') and constid = object_id('pk_re_published_wsinp_docflow_msg_dtl'))
begin
	alter table re_published_wsinp_docflow_msg_dtl add constraint pk_re_published_wsinp_docflow_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, notification_type, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_actcode') and constid = object_id('pk_re_published_wsinp_nonrvw_actcode'))
begin
	alter table re_published_wsinp_nonrvw_actcode add constraint pk_re_published_wsinp_nonrvw_actcode primary key clustered (customer_code, project_code, component_name, activity_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_actdesc') and constid = object_id('pk_re_published_wsinp_nonrvw_actdesc'))
begin
	alter table re_published_wsinp_nonrvw_actdesc add constraint pk_re_published_wsinp_nonrvw_actdesc primary key clustered (customer_code, project_code, component_name, activity_name, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_compcode') and constid = object_id('pk_re_published_wsinp_nonrvw_compcode'))
begin
	alter table re_published_wsinp_nonrvw_compcode add constraint pk_re_published_wsinp_nonrvw_compcode primary key clustered (customer_code, project_code, component_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_compdesc') and constid = object_id('pk_re_published_wsinp_nonrvw_compdesc'))
begin
	alter table re_published_wsinp_nonrvw_compdesc add constraint pk_re_published_wsinp_nonrvw_compdesc primary key clustered (customer_code, project_code, component_name, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_taskcode') and constid = object_id('pk_re_published_wsinp_nonrvw_taskcode'))
begin
	alter table re_published_wsinp_nonrvw_taskcode add constraint pk_re_published_wsinp_nonrvw_taskcode primary key clustered (customer_code, project_code, component_name, activity_name, task_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_nonrvw_taskdesc') and constid = object_id('pk_re_published_wsinp_nonrvw_taskdesc'))
begin
	alter table re_published_wsinp_nonrvw_taskdesc add constraint pk_re_published_wsinp_nonrvw_taskdesc primary key clustered (customer_code, project_code, component_name, activity_name, task_name, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_qc_dtl') and constid = object_id('pk_re_published_wsinp_qc_dtl'))
begin
	alter table re_published_wsinp_qc_dtl add constraint pk_re_published_wsinp_qc_dtl primary key clustered (wf_quick_code, wf_quick_code_type, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_qc_hdr') and constid = object_id('pk_re_published_wsinp_qc_hdr'))
begin
	alter table re_published_wsinp_qc_hdr add constraint pk_re_published_wsinp_qc_hdr primary key clustered (wf_quick_code_type, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_qc_lang_dtl') and constid = object_id('pk_re_published_wsinp_qc_lang_dtl'))
begin
	alter table re_published_wsinp_qc_lang_dtl add constraint pk_re_published_wsinp_qc_lang_dtl primary key clustered (wf_quick_code_type, wf_quick_code, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_rcn_dtl') and constid = object_id('pk_re_published_wsinp_rcn_dtl'))
begin
	alter table re_published_wsinp_rcn_dtl add constraint pk_re_published_wsinp_rcn_dtl primary key clustered (customer_code, project_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_security_dtl') and constid = object_id('pk_re_published_wsinp_security_dtl'))
begin
	alter table re_published_wsinp_security_dtl add constraint pk_re_published_wsinp_security_dtl primary key clustered (customer_code, project_code, permitted_user, component_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_secusr_dtl') and constid = object_id('pk_re_published_wsinp_secusr_dtl'))
begin
	alter table re_published_wsinp_secusr_dtl add constraint pk_re_published_wsinp_secusr_dtl primary key clustered (customer_code, project_code, permitted_user, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_service_dtl') and constid = object_id('pk_re_published_wsinp_service_dtl'))
begin
	alter table re_published_wsinp_service_dtl add constraint pk_re_published_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, cat_key, sequence_no, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_state_desc_dtl') and constid = object_id('pk_re_published_wsinp_state_desc_dtl'))
begin
	alter table re_published_wsinp_state_desc_dtl add constraint pk_re_published_wsinp_state_desc_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, language_code, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_task_dtl') and constid = object_id('pk_re_published_wsinp_task_dtl'))
begin
	alter table re_published_wsinp_task_dtl add constraint pk_re_published_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, cat_key, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_tsk_state_dtl') and constid = object_id('pk_re_published_wsinp_tsk_state_dtl'))
begin
	alter table re_published_wsinp_tsk_state_dtl add constraint pk_re_published_wsinp_tsk_state_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, rcnno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_wsinp_tsk_stflow_dtl') and constid = object_id('pk_re_published_wsinp_tsk_stflow_dtl'))
begin
	alter table re_published_wsinp_tsk_stflow_dtl add constraint pk_re_published_wsinp_tsk_stflow_dtl primary key clustered (cat_key, state_name, to_cat_key, to_state, area_code, customer_code, project_code, rcnno)
end

-- Added on 31st Dec Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_template') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_template'))
BEGIN
	ALTER TABLE de_published_mdcf_template ADD CONSTRAINT PK_de_published_mdcf_template 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID,ecrno)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_template_ilbo') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_template_ilbo'))
BEGIN
	ALTER TABLE de_published_mdcf_template_ilbo ADD CONSTRAINT PK_de_published_mdcf_template_ilbo
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name,ecrno)
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_template_task') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_template_task'))
BEGIN
	ALTER TABLE de_published_mdcf_template_task ADD CONSTRAINT PK_de_published_mdcf_template_task 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name,ecrno)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_template_taskseq') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_template_taskseq'))
BEGIN
	ALTER TABLE de_published_mdcf_template_taskseq ADD CONSTRAINT PK_de_published_mdcf_template_taskseq 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name, Task_Description,ecrno)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_template_taskcontrol_map') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_template_taskcontrol_map'))
BEGIN
	ALTER TABLE de_published_mdcf_template_taskcontrol_map ADD CONSTRAINT PK_de_published_mdcf_template_taskcontrol_map
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name, BT_synonym_name,ecrno)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_mdcf_glossary_lng_extn') AND CONSTID = OBJECT_ID('PK_de_published_mdcf_glossary_lng_extn'))
BEGIN
	ALTER TABLE de_published_mdcf_glossary_lng_extn ADD CONSTRAINT PK_de_published_mdcf_glossary_lng_extn
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, bt_synonym_name, languageid,ecrno)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_up_defaulting_dtl') AND CONSTID = OBJECT_ID('PK_de_published_up_defaulting_dtl'))
BEGIN
	ALTER TABLE de_published_up_defaulting_dtl ADD CONSTRAINT PK_de_published_up_defaulting_dtl
	PRIMARY KEY CLUSTERED (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, control_bt_synonym)
END
GO

-- Added on 31st Dec Ends

-- Added for Request TECH-43307 Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('ep_published_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_ep_published_ui_section_refinement'))
	BEGIN
		ALTER TABLE ep_published_ui_section_refinement ADD CONSTRAINT PK_ep_published_ui_section_refinement
		PRIMARY KEY (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('ep_published_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_ep_published_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE ep_published_responsive_sec_weightage ADD CONSTRAINT PK_ep_published_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('re_published_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_re_published_ui_section_refinement'))
	BEGIN
		ALTER TABLE re_published_ui_section_refinement ADD CONSTRAINT PK_re_published_ui_section_refinement 
		PRIMARY KEY (customer_name, project_name,  rcnno, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('re_published_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_re_published_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE re_published_responsive_sec_weightage ADD CONSTRAINT PK_re_published_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_de_published_ui_section_refinement'))
	BEGIN
		ALTER TABLE de_published_ui_section_refinement ADD CONSTRAINT PK_de_published_ui_section_refinement
		 PRIMARY KEY (customer_name, project_name,  ecrno, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_de_published_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE de_published_responsive_sec_weightage ADD CONSTRAINT PK_de_published_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO
-- Added for Request TECH-43307 Ends

/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Feb 2020
Purpose 		For Creating Primary Key Constraints
********************************************************************************/

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_publish_processsection_br_is') and constid = object_id('de_fw_des_publish_processsection_br_is_pkey'))
begin
	alter table de_fw_des_publish_processsection_br_is add constraint de_fw_des_publish_processsection_br_is_pkey primary key clustered (customer_name, project_name, process_name, component_name, ServiceName, SectionName, SequenceNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_pathoperationparameter_serv_map') and constid = object_id('PK_fw_des_publish_api_pathoperationparameter_serv_map'))
begin
	alter table fw_des_publish_api_pathoperationparameter_serv_map add constraint PK_fw_des_publish_api_pathoperationparameter_serv_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_pathoperationparameter_task_map') and constid = object_id('PK_fw_des_publish_api_pathoperationparameter_task_map'))
begin
	alter table fw_des_publish_api_pathoperationparameter_task_map add constraint PK_fw_des_publish_api_pathoperationparameter_task_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_pathparameter_serv_map') and constid = object_id('PK_fw_des_publish_api_pathparameter_serv_map'))
begin
	alter table fw_des_publish_api_pathparameter_serv_map add constraint PK_fw_des_publish_api_pathparameter_serv_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_pathparameter_task_map') and constid = object_id('PK_fw_des_publish_api_pathparameter_task_map'))
begin
	alter table fw_des_publish_api_pathparameter_task_map add constraint PK_fw_des_publish_api_pathparameter_task_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_request_serv_map') and constid = object_id('PK_fw_des_publish_api_request_serv_map'))
begin
	alter table fw_des_publish_api_request_serv_map add constraint PK_fw_des_publish_api_request_serv_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_request_task_map') and constid = object_id('PK_fw_des_publish_api_request_task_map'))
begin
	alter table fw_des_publish_api_request_task_map add constraint PK_fw_des_publish_api_request_task_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_response_serv_map') and constid = object_id('PK_fw_des_publish_api_response_serv_map'))
begin
	alter table fw_des_publish_api_response_serv_map add constraint PK_fw_des_publish_api_response_serv_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ResponseCode, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_publish_api_response_task_map') and constid = object_id('PK_fw_des_publish_api_response_task_map'))
begin
	alter table fw_des_publish_api_response_task_map add constraint PK_fw_des_publish_api_response_task_map primary key clustered (CustomerName, ProjectName, DocNo, ComponentName, ActivityName, UIName, TaskName, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ResponseCode, ParentSchemaName, SchemaName)
end

-- Added for Elastic search & UPE

IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ListEdit_map'))
BEGIN
	ALTER TABLE  de_published_els_query_listedit_map ADD  CONSTRAINT  PK_de_published_els_query_ListEdit_map   PRIMARY KEY (CustomerName, ProjectName,Ecrno,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 

IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  de_published_els_query_listedit_input ADD  CONSTRAINT    PK_de_published_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName,Ecrno, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ParameterName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  de_published_els_query_listedit_result ADD  CONSTRAINT    PK_de_published_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,Ecrno, 
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ps_map'))
BEGIN
	ALTER TABLE  de_published_els_query_ps_map ADD  CONSTRAINT    PK_de_published_els_query_ps_map PRIMARY KEY (CustomerName, ProjectName,ECRNumber,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ps_input'))
BEGIN
	ALTER TABLE  de_published_els_query_ps_input  ADD  CONSTRAINT    PK_de_published_els_query_ps_input PRIMARY KEY (CustomerName, ProjectName,ECRNumber,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq,ParameterName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_els_query_ps_result'))
BEGIN
	ALTER TABLE  de_published_els_query_ps_result    ADD  CONSTRAINT    PK_de_published_els_query_ps_result PRIMARY KEY (CustomerName, ProjectName,ECRNumber,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq,ResultColumn)
END


IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_published_els_query_ListEdit_map'))
BEGIN
	ALTER TABLE  ep_published_els_query_listedit_map ADD  CONSTRAINT  PK_ep_published_els_query_ListEdit_map   PRIMARY KEY (CustomerName, ProjectName,Reqno,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 

IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_published_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  ep_published_els_query_listedit_input ADD  CONSTRAINT    PK_ep_published_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName,Reqno, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ParameterName)
END
GO 



IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_published_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  ep_published_els_query_listedit_result ADD  CONSTRAINT    PK_ep_published_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,Reqno, 
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 


IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_published_els_query_ListEdit_map'))
BEGIN
	ALTER TABLE  re_published_els_query_listedit_map ADD  CONSTRAINT  PK_re_published_els_query_ListEdit_map   PRIMARY KEY (CustomerName, ProjectName,Rcnno,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 

IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_published_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  re_published_els_query_listedit_input ADD  CONSTRAINT    PK_re_published_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName,Rcnno, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ParameterName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_published_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  re_published_els_query_listedit_result ADD  CONSTRAINT    PK_re_published_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,Rcnno, 
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 

IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_upe_control'))
BEGIN
	ALTER TABLE  de_published_upe_control ADD  CONSTRAINT    PK_de_published_upe_control PRIMARY KEY (CustomerName, ProjectName, ECRNumber,
	ProcessName, ComponentName, ActivityName,UIName, PageName, SectionName, ControlID, ViewName)
END
GO 



IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_published_upe_control_parameters'))
BEGIN
	ALTER TABLE  de_published_upe_control_parameters  ADD  CONSTRAINT    PK_de_published_upe_control_parameters PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName,UIName, PageName, SectionName, ControlID, ViewName,ECRNumber,ParameterType,ParameterName)
END
GO 

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_published_upe_control_task_detail') AND CONSTID = OBJECT_ID('PK_de_published_upe_control_task_detail'))
	BEGIN
		ALTER TABLE de_published_upe_control_task_detail ADD CONSTRAINT PK_de_published_upe_control_task_detail
		PRIMARY KEY (CustomerName, ProjectName, ECRNumber, ProcessName, ComponentName, ActivityName, UIName, PageName, SectionName, ControlID, ViewName, TaskName, ServiceName, MethodID, MethodName, ParameterName)
	END
GO

/***********************************TECH-60451 starts***************************************************************************/

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_published_ui_grid_extension') AND CONSTID = OBJECT_ID('PK_ep_published_ui_grid_extension'))
BEGIN
	ALTER TABLE ep_published_ui_grid_extension ADD CONSTRAINT PK_ep_published_ui_grid_extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,Req_No,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_published_ui_grid_extension') AND CONSTID = OBJECT_ID('PK_re_published_ui_grid_extension'))
BEGIN
	ALTER TABLE re_published_ui_grid_extension ADD CONSTRAINT PK_re_published_ui_grid_extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,RcnNo,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_de_published_ui_grid_Extension') AND CONSTID = OBJECT_ID('PK_de_published_ui_grid_Extension'))
BEGIN
	ALTER TABLE de_published_ui_grid_Extension ADD CONSTRAINT PK_de_published_ui_grid_Extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,EcrNo,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

/***********************************TECH-60451 ends***************************************************************************/

-----Code Added For New Feature-Task API Mapping  TECH-61144  Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_api_mapping') AND CONSTID = OBJECT_ID('PK_de_published_task_api_mapping'))
BEGIN
	ALTER TABLE de_published_task_api_mapping ADD CONSTRAINT PK_de_published_task_api_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo,	ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_subtask') AND CONSTID = OBJECT_ID('PK_de_published_subtask'))
BEGIN
	ALTER TABLE de_published_subtask ADD CONSTRAINT PK_de_published_subtask PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, SubTaskName )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_api_parameter_map') AND CONSTID = OBJECT_ID('PK_de_published_task_api_parameter_map'))
BEGIN
	ALTER TABLE de_published_task_api_parameter_map ADD CONSTRAINT PK_de_published_task_api_parameter_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ParameterLocation, ParameterName, NodeID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_api_request_map') AND CONSTID = OBJECT_ID('PK_de_published_task_api_request_map'))
BEGIN
	ALTER TABLE de_published_task_api_request_map ADD CONSTRAINT PK_de_published_task_api_request_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName, FlattenedSchemaName, NodeID )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_api_response_map') AND CONSTID = OBJECT_ID('PK_de_published_task_api_response_map'))
BEGIN
	ALTER TABLE de_published_task_api_response_map ADD CONSTRAINT PK_de_published_task_api_response_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName,DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, 
	ApiExecSequence, ApiSpecID, ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ControlID, ViewName, NodeID )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_api_subtask') AND CONSTID = OBJECT_ID('PK_de_published_task_api_subtask'))
BEGIN
	ALTER TABLE de_published_task_api_subtask ADD CONSTRAINT PK_de_published_task_api_subtask PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, SubTaskName, SubTaskSequence )
END
GO
-----Code Added For New Feature-Task API Mapping  TECH-61144  Ends

-----Code Added For Task API Mapping  TECH-61907  Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_service_api_parameter_map') AND CONSTID = OBJECT_ID('PK_de_published_service_api_parameter_map'))
BEGIN
	ALTER TABLE de_published_service_api_parameter_map ADD CONSTRAINT PK_de_published_service_api_parameter_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID,
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ParameterName,	ParameterLocation )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_service_api_request_map') AND CONSTID = OBJECT_ID('PK_de_published_service_api_request_map'))
BEGIN
	ALTER TABLE de_published_service_api_request_map ADD CONSTRAINT PK_de_published_service_api_request_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID,
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName,	FlattenedSchemaName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_service_api_response_map') AND CONSTID = OBJECT_ID('PK_de_published_service_api_response_map'))
BEGIN
	ALTER TABLE de_published_service_api_response_map ADD CONSTRAINT PK_de_published_service_api_response_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID, 
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID,  SegmentName, DataItemName )
END
GO
-----Code Added For Task API Mapping  TECH-61907  Ends

-----Code Added For Gql operation  TECH-63474  Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_published_graphql_query') AND CONSTID = OBJECT_ID('PK_fw_published_graphql_query'))
BEGIN
	ALTER TABLE fw_published_graphql_query ADD CONSTRAINT PK_fw_published_graphql_query PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, [Version], QueryName,QueryType)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_published_graphql_arguments') AND CONSTID = OBJECT_ID('PK_fw_published_graphql_arguments'))
BEGIN
	ALTER TABLE fw_published_graphql_arguments ADD CONSTRAINT PK_fw_published_graphql_arguments PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, [Version], QueryName, FlattenedArgumentName )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_published_graphql_fields') AND CONSTID = OBJECT_ID('PK_fw_published_graphql_fields'))
BEGIN
	ALTER TABLE fw_published_graphql_fields ADD CONSTRAINT PK_fw_published_graphql_fields PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, [Version], QueryName, FlattenedFieldName )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_argument_mapping') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_argument_mapping'))
BEGIN
	ALTER TABLE de_published_task_gql_argument_mapping ADD CONSTRAINT PK_de_published_task_gql_argument_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, FlattenedArgumentName )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_mapping') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_mapping'))
BEGIN
	ALTER TABLE de_published_task_gql_mapping ADD CONSTRAINT PK_de_published_task_gql_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_field_mapping') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_field_mapping'))
BEGIN
	ALTER TABLE de_published_task_gql_field_mapping ADD CONSTRAINT PK_de_published_task_gql_field_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, ControlID, ViewName ,FieldName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_gql_Schema') AND CONSTID = OBJECT_ID('PK_de_published_gql_Schema'))
BEGIN
	ALTER TABLE de_published_gql_Schema ADD CONSTRAINT PK_de_published_gql_Schema PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, [Version] )
END
GO
-----Code Added For Gql operation TECH-63474  Ends

--Code added for the defect id : TECH-64197 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_published_graphql_arg_fields') AND CONSTID = OBJECT_ID('PK_fw_published_graphql_arg_fields'))
BEGIN
	ALTER TABLE fw_published_graphql_arg_fields ADD CONSTRAINT PK_fw_published_graphql_arg_fields PRIMARY KEY CLUSTERED ( customername,projectname,docno,processname,componentname,importversion,queryname,[key],category)
END
GO

--Code added for the defect id : TECH-64197 ends


--Code added for the defect id : TECH-64865 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_field_mapping') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_field_mapping'))
BEGIN
	ALTER TABLE de_published_task_gql_field_mapping ADD CONSTRAINT PK_de_published_task_gql_field_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, ControlID, ViewName ,FieldName, MapType)
END
GO

--Code added for the defect id : TECH-64865 ends

/* Code Added for the Defect-Id TECH-66583 Starts */

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_comp_ctrl_type_mst') and constid = object_id('ep_published_comp_ctrl_type_mst_pkey'))
begin
	alter table ep_published_comp_ctrl_type_mst add constraint ep_published_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_comp_ctrl_type_mst_extn') and constid = object_id('ep_published_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table ep_published_comp_ctrl_type_mst_extn add constraint ep_published_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_published_comp_task_type_mst') and constid = object_id('ep_published_comp_task_type_mst_pkey'))
begin
	alter table ep_published_comp_task_type_mst add constraint ep_published_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, task_type_name)
end

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if not exists (select 'x' from sysconstraints where id = object_id('re_published_comp_ctrl_type_mst') and constid = object_id('re_published_comp_ctrl_type_mst_pkey'))
begin
	alter table re_published_comp_ctrl_type_mst add constraint re_published_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name,  ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_comp_ctrl_type_mst_extn') and constid = object_id('re_published_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table re_published_comp_ctrl_type_mst_extn add constraint re_published_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name,  ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_published_comp_task_type_mst') and constid = object_id('re_published_comp_task_type_mst_pkey'))
begin
	alter table re_published_comp_task_type_mst add constraint re_published_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name,  task_type_name)
end

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if not exists (select 'x' from sysconstraints where id = object_id('de_published_comp_ctrl_type_mst') and constid = object_id('de_published_comp_ctrl_type_mst_pkey'))
begin
	alter table de_published_comp_ctrl_type_mst add constraint de_published_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name,  ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_comp_ctrl_type_mst_extn') and constid = object_id('de_published_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table de_published_comp_ctrl_type_mst_extn add constraint de_published_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name,  ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_published_comp_task_type_mst') and constid = object_id('de_published_comp_task_type_mst_pkey'))
begin
	alter table de_published_comp_task_type_mst add constraint de_published_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name,  task_type_name)
end

/* Code Added for the Defect-Id : TECH-66583 Ends */

/* Code Added for the Defect-Id : TECH-69624 Starts */

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_published_ui_control_customaction') AND CONSTID = OBJECT_ID('ep_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE ep_published_ui_control_customaction ADD CONSTRAINT ep_published_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_published_ui_control_customaction') AND CONSTID = OBJECT_ID('re_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE re_published_ui_control_customaction ADD CONSTRAINT re_published_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	rcnno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END 
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_ui_control_customaction') AND CONSTID = OBJECT_ID('de_published_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE de_published_ui_control_customaction ADD CONSTRAINT de_published_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END
GO
/* Code Added for the Defect-Id : TECH-69624 Ends */


--Code Added for the DefectId TECH-70687 Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_published_ui_section_Titleaction') AND CONSTID = OBJECT_ID('ep_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE ep_published_ui_section_Titleaction ADD CONSTRAINT ep_published_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_published_ui_section_Titleaction') AND CONSTID = OBJECT_ID('re_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE re_published_ui_section_Titleaction ADD CONSTRAINT re_published_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	rcnno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_ui_section_Titleaction') AND CONSTID = OBJECT_ID('de_published_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE de_published_ui_section_Titleaction ADD CONSTRAINT de_published_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO
--Code Added for the DefectId TECH-70687 Ends


--COde added for TECH-72114 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_report') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_report'))
BEGIN
	ALTER TABLE de_published_task_gql_report ADD CONSTRAINT PK_de_published_task_gql_report 
	PRIMARY KEY(CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_published_task_gql_report_param') AND CONSTID = OBJECT_ID('PK_de_published_task_gql_report_param'))
BEGIN
	ALTER TABLE de_published_task_gql_report_param ADD CONSTRAINT PK_de_published_task_gql_report_param 
	PRIMARY KEY(CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName, ParameterName)
END 
GO
--Code added for TECH-72114 ends