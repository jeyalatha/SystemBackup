/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		For Droping Constraints
********************************************************************************/
SET NOCOUNT ON

if exists(select 'x' from sysobjects where name = 'Activities_fkey_Problem')
begin
	alter table Activities drop constraint Activities_fkey_Problem
end

if exists(select 'x' from sysobjects where name = 'ActPk')
begin
	alter table Activities drop constraint ActPk
end

if exists(select 'x' from sysobjects where name = 'Activity_Predecessors_fkey_Activities')
begin
	alter table Activity_Predecessors drop constraint Activity_Predecessors_fkey_Activities
end

if exists(select 'x' from sysobjects where name = 'Apkg_Configure_PK')
begin
	alter table Apkg_Configure drop constraint Apkg_Configure_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Configure_DocDetail_PK')
begin
	alter table Apkg_Configure_DocDetail drop constraint Apkg_Configure_DocDetail_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Configure_DocMaster_PK')
begin
	alter table Apkg_Configure_DocMaster drop constraint Apkg_Configure_DocMaster_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Cust_Proj_Language_fkey_Apkg_Language')
begin
	alter table Apkg_Cust_Proj_Language drop constraint Apkg_Cust_Proj_Language_fkey_Apkg_Language
end

if exists(select 'x' from sysobjects where name = 'Apkg_Cust_Proj_Language_PK')
begin
	alter table Apkg_Cust_Proj_Language drop constraint Apkg_Cust_Proj_Language_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Customer_fkey_Apkg_Cust_Proj_Language')
begin
	alter table Apkg_Customer drop constraint Apkg_Customer_fkey_Apkg_Cust_Proj_Language
end

if exists(select 'x' from sysobjects where name = 'Apkg_Customer_PK')
begin
	alter table Apkg_Customer drop constraint Apkg_Customer_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Language_PK')
begin
	alter table Apkg_Language drop constraint Apkg_Language_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Project_fkey_Apkg_Cust_Proj_Language')
begin
	alter table Apkg_Project drop constraint Apkg_Project_fkey_Apkg_Cust_Proj_Language
end

if exists(select 'x' from sysobjects where name = 'Apkg_Project_PK')
begin
	alter table Apkg_Project drop constraint Apkg_Project_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Reference_Values_PK')
begin
	alter table Apkg_Reference_Values drop constraint Apkg_Reference_Values_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_ReleaseSet_PK')
begin
	alter table Apkg_ReleaseSet drop constraint Apkg_ReleaseSet_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_releaseset_ico_PK')
begin
	alter table Apkg_releaseset_ico drop constraint Apkg_releaseset_ico_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_Runtime_Configure_Pk')
begin
	alter table Apkg_Runtime_Configure drop constraint Apkg_Runtime_Configure_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTime_Doc_ReleaseDtl_fkey_Apkg_Runtime_Configure')
begin
	alter table Apkg_RunTime_Doc_ReleaseDtl drop constraint Apkg_RunTime_Doc_ReleaseDtl_fkey_Apkg_Runtime_Configure
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTime_Doc_ReleaseDtl_Pk')
begin
	alter table Apkg_RunTime_Doc_ReleaseDtl drop constraint Apkg_RunTime_Doc_ReleaseDtl_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTime_ReleaseDtl_Pk')
begin
	alter table Apkg_RunTime_ReleaseDtl drop constraint Apkg_RunTime_ReleaseDtl_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_Batchfile_Pk')
begin
	alter table Apkg_RuntimeArch_Batchfile drop constraint Apkg_RuntimeArch_Batchfile_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_Batchfile_SP_fkey_Apkg_RuntimeArch_Batchfile')
begin
	alter table Apkg_RuntimeArch_Batchfile_SP drop constraint Apkg_RuntimeArch_Batchfile_SP_fkey_Apkg_RuntimeArch_Batchfile
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_Batchfile_SP_Pk')
begin
	alter table Apkg_RuntimeArch_Batchfile_SP drop constraint Apkg_RuntimeArch_Batchfile_SP_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_Bparam_Pk')
begin
	alter table Apkg_RuntimeArch_Bparam drop constraint Apkg_RuntimeArch_Bparam_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_Detail_fkey_Apkg_RunTimeArch_Master')
begin
	alter table Apkg_RunTimeArch_Detail drop constraint Apkg_RunTimeArch_Detail_fkey_Apkg_RunTimeArch_Master
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_Detail_Pk')
begin
	alter table Apkg_RunTimeArch_Detail drop constraint Apkg_RunTimeArch_Detail_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DOC_Batchfile_Pk')
begin
	alter table Apkg_RuntimeArch_DOC_Batchfile drop constraint Apkg_RuntimeArch_DOC_Batchfile_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DOC_Batchfile_SP_fkey_Apkg_RuntimeArch_DOC_SubBatchfile')
begin
	alter table Apkg_RuntimeArch_DOC_Batchfile_SP drop constraint Apkg_RuntimeArch_DOC_Batchfile_SP_fkey_Apkg_RuntimeArch_DOC_SubBatchfile
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DOC_Batchfile_SP_Pk')
begin
	alter table Apkg_RuntimeArch_DOC_Batchfile_SP drop constraint Apkg_RuntimeArch_DOC_Batchfile_SP_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DOC_SubBatchfile_fkey_Apkg_RuntimeArch_DOC_Batchfile')
begin
	alter table Apkg_RuntimeArch_DOC_SubBatchfile drop constraint Apkg_RuntimeArch_DOC_SubBatchfile_fkey_Apkg_RuntimeArch_DOC_Batchfile
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DOC_SubBatchfile_Pk')
begin
	alter table Apkg_RuntimeArch_DOC_SubBatchfile drop constraint Apkg_RuntimeArch_DOC_SubBatchfile_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_DocBparam_Pk')
begin
	alter table Apkg_RuntimeArch_DocBparam drop constraint Apkg_RuntimeArch_DocBparam_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_DocDetail_fkey_Apkg_RunTimeArch_DocMaster')
begin
	alter table Apkg_RunTimeArch_DocDetail drop constraint Apkg_RunTimeArch_DocDetail_fkey_Apkg_RunTimeArch_DocMaster
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_DocDetail_Pk')
begin
	alter table Apkg_RunTimeArch_DocDetail drop constraint Apkg_RunTimeArch_DocDetail_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_DocMaster_fkey_Apkg_RunTimeArch_DocPreReq')
begin
	alter table Apkg_RunTimeArch_DocMaster drop constraint Apkg_RunTimeArch_DocMaster_fkey_Apkg_RunTimeArch_DocPreReq
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_DocMaster_Pk')
begin
	alter table Apkg_RunTimeArch_DocMaster drop constraint Apkg_RunTimeArch_DocMaster_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_DocPreReq_Pk')
begin
	alter table Apkg_RunTimeArch_DocPreReq drop constraint Apkg_RunTimeArch_DocPreReq_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_Master_fkey_Apkg_RunTimeArch_PreReq')
begin
	alter table Apkg_RunTimeArch_Master drop constraint Apkg_RunTimeArch_Master_fkey_Apkg_RunTimeArch_PreReq
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_Master_Pk')
begin
	alter table Apkg_RunTimeArch_Master drop constraint Apkg_RunTimeArch_Master_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RunTimeArch_PreReq_Pk')
begin
	alter table Apkg_RunTimeArch_PreReq drop constraint Apkg_RunTimeArch_PreReq_Pk
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_SubBatchfile_fkey_Apkg_RuntimeArch_Batchfile')
begin
	alter table Apkg_RuntimeArch_SubBatchfile drop constraint Apkg_RuntimeArch_SubBatchfile_fkey_Apkg_RuntimeArch_Batchfile
end

if exists(select 'x' from sysobjects where name = 'Apkg_RuntimeArch_SubBatchfile_Pk')
begin
	alter table Apkg_RuntimeArch_SubBatchfile drop constraint Apkg_RuntimeArch_SubBatchfile_Pk
end

if exists(select 'x' from sysobjects where name = 'apkg_ssafe_dtl_PK')
begin
	alter table Apkg_Ssafe_Dtl drop constraint apkg_ssafe_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Activity_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_Activity drop constraint Apkg_TechnoArch_Activity_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Activity_PK')
begin
	alter table Apkg_TechnoArch_Activity drop constraint Apkg_TechnoArch_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Activity_source_fkey_Apkg_TechnoArch_Activity')
begin
	alter table Apkg_TechnoArch_Activity_source drop constraint Apkg_TechnoArch_Activity_source_fkey_Apkg_TechnoArch_Activity
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Activity_source_PK')
begin
	alter table Apkg_TechnoArch_Activity_source drop constraint Apkg_TechnoArch_Activity_source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BP_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_BP drop constraint Apkg_TechnoArch_BP_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BP_PK')
begin
	alter table Apkg_TechnoArch_BP drop constraint Apkg_TechnoArch_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BP_source_fkey_Apkg_TechnoArch_BP')
begin
	alter table Apkg_TechnoArch_BP_source drop constraint Apkg_TechnoArch_BP_source_fkey_Apkg_TechnoArch_BP
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BP_source_PK')
begin
	alter table Apkg_TechnoArch_BP_source drop constraint Apkg_TechnoArch_BP_source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BR_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_BR drop constraint Apkg_TechnoArch_BR_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_BR_PK')
begin
	alter table Apkg_TechnoArch_BR drop constraint Apkg_TechnoArch_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechNoArch_BRArtifact_DocDependency_PK')
begin
	alter table Apkg_TechNoArch_BRArtifact_DocDependency drop constraint Apkg_TechNoArch_BRArtifact_DocDependency_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Component_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_Component drop constraint Apkg_TechnoArch_Component_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Component_PK')
begin
	alter table Apkg_TechnoArch_Component drop constraint Apkg_TechnoArch_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Component_source_fkey_Apkg_TechnoArch_Component')
begin
	alter table Apkg_TechnoArch_Component_source drop constraint Apkg_TechnoArch_Component_source_fkey_Apkg_TechnoArch_Component
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Component_source_PK')
begin
	alter table Apkg_TechnoArch_Component_source drop constraint Apkg_TechnoArch_Component_source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechNoArch_Detail_fkey_Apkg_TechnoArch_Master')
begin
	alter table Apkg_TechNoArch_Detail drop constraint Apkg_TechNoArch_Detail_fkey_Apkg_TechnoArch_Master
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechNoArch_Detail_PK')
begin
	alter table Apkg_TechNoArch_Detail drop constraint Apkg_TechNoArch_Detail_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Activity_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_Activity drop constraint Apkg_TechnoArch_Doc_Activity_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Activity_PK')
begin
	alter table Apkg_TechnoArch_Doc_Activity drop constraint Apkg_TechnoArch_Doc_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Activity_Source_fkey_Apkg_TechnoArch_Doc_Activity')
begin
	alter table Apkg_TechnoArch_Doc_Activity_Source drop constraint Apkg_TechnoArch_Doc_Activity_Source_fkey_Apkg_TechnoArch_Doc_Activity
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Activity_Source_PK')
begin
	alter table Apkg_TechnoArch_Doc_Activity_Source drop constraint Apkg_TechnoArch_Doc_Activity_Source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BP_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_BP drop constraint Apkg_TechnoArch_Doc_BP_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BP_PK')
begin
	alter table Apkg_TechnoArch_Doc_BP drop constraint Apkg_TechnoArch_Doc_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BP_source_fkey_Apkg_TechnoArch_Doc_BP')
begin
	alter table Apkg_TechnoArch_Doc_BP_source drop constraint Apkg_TechnoArch_Doc_BP_source_fkey_Apkg_TechnoArch_Doc_BP
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BP_source_PK')
begin
	alter table Apkg_TechnoArch_Doc_BP_source drop constraint Apkg_TechnoArch_Doc_BP_source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BR_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_BR drop constraint Apkg_TechnoArch_Doc_BR_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BR_PK')
begin
	alter table Apkg_TechnoArch_Doc_BR drop constraint Apkg_TechnoArch_Doc_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BR_Source_fkey_Apkg_TechnoArch_Doc_BR')
begin
	alter table Apkg_TechnoArch_Doc_BR_Source drop constraint Apkg_TechnoArch_Doc_BR_Source_fkey_Apkg_TechnoArch_Doc_BR
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_BR_Source_PK')
begin
	alter table Apkg_TechnoArch_Doc_BR_Source drop constraint Apkg_TechnoArch_Doc_BR_Source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Component_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_Component drop constraint Apkg_TechnoArch_Doc_Component_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Component_PK')
begin
	alter table Apkg_TechnoArch_Doc_Component drop constraint Apkg_TechnoArch_Doc_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Component_Source_fkey_Apkg_TechnoArch_Doc_Component')
begin
	alter table Apkg_TechnoArch_Doc_Component_Source drop constraint Apkg_TechnoArch_Doc_Component_Source_fkey_Apkg_TechnoArch_Doc_Component
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Component_Source_PK')
begin
	alter table Apkg_TechnoArch_Doc_Component_Source drop constraint Apkg_TechnoArch_Doc_Component_Source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Rm_Files_PK')
begin
	alter table Apkg_TechnoArch_Doc_Rm_Files drop constraint Apkg_TechnoArch_Doc_Rm_Files_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Task_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_Task drop constraint Apkg_TechnoArch_Doc_Task_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Task_PK')
begin
	alter table Apkg_TechnoArch_Doc_Task drop constraint Apkg_TechnoArch_Doc_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Task_Source_fkey_Apkg_TechnoArch_Doc_Task')
begin
	alter table Apkg_TechnoArch_Doc_Task_Source drop constraint Apkg_TechnoArch_Doc_Task_Source_fkey_Apkg_TechnoArch_Doc_Task
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_Task_Source_PK')
begin
	alter table Apkg_TechnoArch_Doc_Task_Source drop constraint Apkg_TechnoArch_Doc_Task_Source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_fkey_Apkg_TechNoArch_DocDetail')
begin
	alter table Apkg_TechnoArch_Doc_UI drop constraint Apkg_TechnoArch_Doc_UI_fkey_Apkg_TechNoArch_DocDetail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_PK')
begin
	alter table Apkg_TechnoArch_Doc_UI drop constraint Apkg_TechnoArch_Doc_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_Assoc_fkey_Apkg_TechnoArch_Doc_UI')
begin
	alter table Apkg_TechnoArch_Doc_UI_Assoc drop constraint Apkg_TechnoArch_Doc_UI_Assoc_fkey_Apkg_TechnoArch_Doc_UI
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_Assoc_PK')
begin
	alter table Apkg_TechnoArch_Doc_UI_Assoc drop constraint Apkg_TechnoArch_Doc_UI_Assoc_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_Source_fkey_Apkg_TechnoArch_Doc_UI')
begin
	alter table Apkg_TechnoArch_Doc_UI_Source drop constraint Apkg_TechnoArch_Doc_UI_Source_fkey_Apkg_TechnoArch_Doc_UI
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Doc_UI_Source_PK')
begin
	alter table Apkg_TechnoArch_Doc_UI_Source drop constraint Apkg_TechnoArch_Doc_UI_Source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechNoArch_DocDetail_fkey_Apkg_TechnoArch_DocMaster')
begin
	alter table Apkg_TechNoArch_DocDetail drop constraint Apkg_TechNoArch_DocDetail_fkey_Apkg_TechnoArch_DocMaster
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechNoArch_DocDetail_PK')
begin
	alter table Apkg_TechNoArch_DocDetail drop constraint Apkg_TechNoArch_DocDetail_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_DocMaster_PK')
begin
	alter table Apkg_TechnoArch_DocMaster drop constraint Apkg_TechnoArch_DocMaster_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_DocSource_Detail_fkey_Apkg_TechnoArch_DocSource_Master')
begin
	alter table Apkg_TechnoArch_DocSource_Detail drop constraint Apkg_TechnoArch_DocSource_Detail_fkey_Apkg_TechnoArch_DocSource_Master
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_DocSource_Detail_PK')
begin
	alter table Apkg_TechnoArch_DocSource_Detail drop constraint Apkg_TechnoArch_DocSource_Detail_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_DocSource_Master_PK')
begin
	alter table Apkg_TechnoArch_DocSource_Master drop constraint Apkg_TechnoArch_DocSource_Master_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Master_PK')
begin
	alter table Apkg_TechnoArch_Master drop constraint Apkg_TechnoArch_Master_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Rm_Files_PK')
begin
	alter table Apkg_TechnoArch_Rm_Files drop constraint Apkg_TechnoArch_Rm_Files_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Task_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_Task drop constraint Apkg_TechnoArch_Task_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Task_PK')
begin
	alter table Apkg_TechnoArch_Task drop constraint Apkg_TechnoArch_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Task_source_fkey_Apkg_TechnoArch_Task')
begin
	alter table Apkg_TechnoArch_Task_source drop constraint Apkg_TechnoArch_Task_source_fkey_Apkg_TechnoArch_Task
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_Task_source_PK')
begin
	alter table Apkg_TechnoArch_Task_source drop constraint Apkg_TechnoArch_Task_source_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_fkey_Apkg_TechNoArch_Detail')
begin
	alter table Apkg_TechnoArch_UI drop constraint Apkg_TechnoArch_UI_fkey_Apkg_TechNoArch_Detail
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_PK')
begin
	alter table Apkg_TechnoArch_UI drop constraint Apkg_TechnoArch_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_assoc_fkey_Apkg_TechnoArch_UI')
begin
	alter table Apkg_TechnoArch_UI_assoc drop constraint Apkg_TechnoArch_UI_assoc_fkey_Apkg_TechnoArch_UI
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_assoc_PK')
begin
	alter table Apkg_TechnoArch_UI_assoc drop constraint Apkg_TechnoArch_UI_assoc_PK
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_source_fkey_Apkg_TechnoArch_UI')
begin
	alter table Apkg_TechnoArch_UI_source drop constraint Apkg_TechnoArch_UI_source_fkey_Apkg_TechnoArch_UI
end

if exists(select 'x' from sysobjects where name = 'Apkg_TechnoArch_UI_source_PK')
begin
	alter table Apkg_TechnoArch_UI_source drop constraint Apkg_TechnoArch_UI_source_PK
end

if exists(select 'x' from sysobjects where name = 'avs_component_bt_validation_pkey')
begin
	alter table avs_component_bt_validation drop constraint avs_component_bt_validation_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_message_pkey')
begin
	alter table avs_message drop constraint avs_message_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_message_lng_extn_pkey')
begin
	alter table avs_message_lng_extn drop constraint avs_message_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_project_bt_validation_pkey')
begin
	alter table avs_project_bt_validation drop constraint avs_project_bt_validation_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_quick_code_met_pkey')
begin
	alter table avs_quick_code_met drop constraint avs_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_service_validation_dtl_pkey')
begin
	alter table avs_service_validation_dtl drop constraint avs_service_validation_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_validation_group_pkey')
begin
	alter table avs_validation_group drop constraint avs_validation_group_pkey
end

if exists(select 'x' from sysobjects where name = 'avs_validation_group_dtl_pkey')
begin
	alter table avs_validation_group_dtl drop constraint avs_validation_group_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_depends_fkey_ce_component_sp')
begin
	alter table ce_comp_sp_depends drop constraint ce_comp_sp_depends_fkey_ce_component_sp
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_depends_pkey')
begin
	alter table ce_comp_sp_depends drop constraint ce_comp_sp_depends_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_depends_dtl_PK')
begin
	alter table ce_comp_sp_depends_dtl drop constraint ce_comp_sp_depends_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_depends_func_dtl_PK')
begin
	alter table ce_comp_sp_depends_func_dtl drop constraint ce_comp_sp_depends_func_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_errors_pkey')
begin
	alter table ce_comp_sp_errors drop constraint ce_comp_sp_errors_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_params_PK')
begin
	alter table ce_comp_sp_params drop constraint ce_comp_sp_params_PK
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_result_PK')
begin
	alter table ce_comp_sp_result drop constraint ce_comp_sp_result_PK
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_result_criteria_PK')
begin
	alter table ce_comp_sp_result_criteria drop constraint ce_comp_sp_result_criteria_PK
end

if exists(select 'x' from sysobjects where name = 'ce_comp_sp_result_stmts_PK')
begin
	alter table ce_comp_sp_result_stmts drop constraint ce_comp_sp_result_stmts_PK
end

if exists(select 'x' from sysobjects where name = 'ce_component_sp_pkey')
begin
	alter table ce_component_sp drop constraint ce_component_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_fixnote_ico_map_pkey')
begin
	alter table ce_fixnote_ico_map drop constraint ce_fixnote_ico_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ico_method_service_map_pkey')
begin
	alter table ce_ico_method_service_map drop constraint ce_ico_method_service_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_pkey')
begin
	alter table ce_ico_sp drop constraint ce_ico_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_depends_fkey_ce_ico_sp_spec')
begin
	alter table ce_ico_sp_depends drop constraint ce_ico_sp_depends_fkey_ce_ico_sp_spec
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_depends_pkey')
begin
	alter table ce_ico_sp_depends drop constraint ce_ico_sp_depends_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_depends_dtl_PK')
begin
	alter table ce_ico_sp_depends_dtl drop constraint ce_ico_sp_depends_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_errors_fkey_ce_ico_sp_spec')
begin
	alter table ce_ico_sp_errors drop constraint ce_ico_sp_errors_fkey_ce_ico_sp_spec
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_errors_pkey')
begin
	alter table ce_ico_sp_errors drop constraint ce_ico_sp_errors_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_params_PK')
begin
	alter table ce_ico_sp_params drop constraint ce_ico_sp_params_PK
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_result_criteria_PK')
begin
	alter table ce_ico_sp_result_criteria drop constraint ce_ico_sp_result_criteria_PK
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_result_stmts_PK')
begin
	alter table ce_ico_sp_result_stmts drop constraint ce_ico_sp_result_stmts_PK
end

if exists(select 'x' from sysobjects where name = 'ce_ico_sp_spec_pkey')
begin
	alter table ce_ico_sp_spec drop constraint ce_ico_sp_spec_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_quick_code_met_pkey')
begin
	alter table ce_quick_code_met drop constraint ce_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_quick_code_met_lng_extn_pkey')
begin
	alter table ce_quick_code_met_lng_extn drop constraint ce_quick_code_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_rmt_ico_ui_pkey')
begin
	alter table ce_rmt_ico_ui drop constraint ce_rmt_ico_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'ce_ui_ico_pkey')
begin
	alter table ce_ui_ico drop constraint ce_ui_ico_pkey
end

if exists(select 'x' from sysobjects where name = 'cvs_control_validation_pkey')
begin
	alter table cvs_control_validation drop constraint cvs_control_validation_pkey
end

if exists(select 'x' from sysobjects where name = 'cvs_message_Fkey_cvs_control_validation')
begin
	alter table cvs_message drop constraint cvs_message_Fkey_cvs_control_validation
end

if exists(select 'x' from sysobjects where name = 'PK_cvs_message')
begin
	alter table cvs_message drop constraint PK_cvs_message
end

if exists(select 'x' from sysobjects where name = 'cvs_message_lng_extn_Fkey_cvs_message')
begin
	alter table cvs_message_lng_extn drop constraint cvs_message_lng_extn_Fkey_cvs_message
end

if exists(select 'x' from sysobjects where name = 'PK_cvs_message_lng_extn')
begin
	alter table cvs_message_lng_extn drop constraint PK_cvs_message_lng_extn
end

if exists(select 'x' from sysobjects where name = 'DB_Variable_InteractionsPK')
begin
	alter table DB_Column_Variable_Interactions drop constraint DB_Variable_InteractionsPK
end

if exists(select 'x' from sysobjects where name = 'DB_ConsColumn_PK')
begin
	alter table DB_Constraint_Columns drop constraint DB_ConsColumn_PK
end

if exists(select 'x' from sysobjects where name = 'DB_Cons_PK')
begin
	alter table DB_Constraints drop constraint DB_Cons_PK
end

if exists(select 'x' from sysobjects where name = 'DB_Index_Columns_fkey_DB_Indexes')
begin
	alter table DB_Index_Columns drop constraint DB_Index_Columns_fkey_DB_Indexes
end

if exists(select 'x' from sysobjects where name = 'DB_Index_Columns_PK')
begin
	alter table DB_Index_Columns drop constraint DB_Index_Columns_PK
end

if exists(select 'x' from sysobjects where name = 'DB_Indexes_fkey_DB_Objects')
begin
	alter table DB_Indexes drop constraint DB_Indexes_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Indexes_PK')
begin
	alter table DB_Indexes drop constraint DB_Indexes_PK
end

if exists(select 'x' from sysobjects where name = 'DB_Object_Columns_fkey_DB_Objects')
begin
	alter table DB_Object_Columns drop constraint DB_Object_Columns_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Object_ColumnsPK')
begin
	alter table DB_Object_Columns drop constraint DB_Object_ColumnsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Object_declarations_fkey_DB_Objects')
begin
	alter table DB_Object_declarations drop constraint DB_Object_declarations_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Object_declarationsPK')
begin
	alter table DB_Object_declarations drop constraint DB_Object_declarationsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Object_Interaction_fkey_DB_Objects')
begin
	alter table DB_Object_Interaction drop constraint DB_Object_Interaction_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Object_InteractionPK')
begin
	alter table DB_Object_Interaction drop constraint DB_Object_InteractionPK
end

if exists(select 'x' from sysobjects where name = 'DB_Object_Statements_fkey_DB_Objects')
begin
	alter table DB_Object_Statements drop constraint DB_Object_Statements_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Object_StatementsPK')
begin
	alter table DB_Object_Statements drop constraint DB_Object_StatementsPK
end

if exists(select 'x' from sysobjects where name = 'Customer_idPK')
begin
	alter table DB_Objects drop constraint Customer_idPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_cursor_ColumnsPK')
begin
	alter table DB_Statement_cursor_Columns drop constraint DB_Statement_cursor_ColumnsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Interactions_fkey_DB_Statement_Object_Used')
begin
	alter table DB_Statement_Interactions drop constraint DB_Statement_Interactions_fkey_DB_Statement_Object_Used
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_InteractionsPK')
begin
	alter table DB_Statement_Interactions drop constraint DB_Statement_InteractionsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_Columns_fkey_DB_Statement_Object_Used')
begin
	alter table DB_Statement_Object_Columns drop constraint DB_Statement_Object_Columns_fkey_DB_Statement_Object_Used
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_ColumnsPK')
begin
	alter table DB_Statement_Object_Columns drop constraint DB_Statement_Object_ColumnsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_Functions_fkey_DB_Statement_Object_Used')
begin
	alter table DB_Statement_Object_Functions drop constraint DB_Statement_Object_Functions_fkey_DB_Statement_Object_Used
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_FunctionsPK')
begin
	alter table DB_Statement_Object_Functions drop constraint DB_Statement_Object_FunctionsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_OtherColumns_fkey_DB_Objects')
begin
	alter table DB_Statement_Object_OtherColumns drop constraint DB_Statement_Object_OtherColumns_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_OtherColumnsPK')
begin
	alter table DB_Statement_Object_OtherColumns drop constraint DB_Statement_Object_OtherColumnsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_ResultsPK')
begin
	alter table DB_Statement_Object_Results drop constraint DB_Statement_Object_ResultsPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_Used_fkey_DB_Objects')
begin
	alter table DB_Statement_Object_Used drop constraint DB_Statement_Object_Used_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_Statement_Object_UsedPK')
begin
	alter table DB_Statement_Object_Used drop constraint DB_Statement_Object_UsedPK
end

if exists(select 'x' from sysobjects where name = 'DB_Statements_UsagePK')
begin
	alter table DB_Statements_Usage drop constraint DB_Statements_UsagePK
end

if exists(select 'x' from sysobjects where name = 'DB_UDDs_fkey_DB_Objects')
begin
	alter table DB_UDDs drop constraint DB_UDDs_fkey_DB_Objects
end

if exists(select 'x' from sysobjects where name = 'DB_UDDs_PK')
begin
	alter table DB_UDDs drop constraint DB_UDDs_PK
end

if exists(select 'x' from sysobjects where name = 'de_action_pkey')
begin
	alter table de_action drop constraint de_action_pkey
end

if exists(select 'x' from sysobjects where name = 'de_action_fprowno_tmp_pkey')
begin
	alter table de_action_fprowno_tmp drop constraint de_action_fprowno_tmp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_action_lng_extn_pkey')
begin
	alter table de_action_lng_extn drop constraint de_action_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_action_section_map_pkey')
begin
	alter table de_action_section_map drop constraint de_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_activity_history_pk')
begin
	alter table de_activity_history drop constraint de_activity_history_pk
end

if exists(select 'x' from sysobjects where name = 'de_applicable_database_pkey')
begin
	alter table de_applicable_database drop constraint de_applicable_database_pkey
end

if exists(select 'x' from sysobjects where name = 'de_bo_dataitem_relation_fkey_de_bo_segment_relation')
begin
	alter table de_bo_dataitem_relation drop constraint de_bo_dataitem_relation_fkey_de_bo_segment_relation
end

if exists(select 'x' from sysobjects where name = 'de_bo_dataitem_relation_pkey')
begin
	alter table de_bo_dataitem_relation drop constraint de_bo_dataitem_relation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_bo_segment_fkey_de_business_object')
begin
	alter table de_bo_segment drop constraint de_bo_segment_fkey_de_business_object
end

if exists(select 'x' from sysobjects where name = 'de_bo_segment_pkey')
begin
	alter table de_bo_segment drop constraint de_bo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_bo_segment_dataitem_fkey_de_bo_segment')
begin
	alter table de_bo_segment_dataitem drop constraint de_bo_segment_dataitem_fkey_de_bo_segment
end

if exists(select 'x' from sysobjects where name = 'de_bo_segment_dataitem_pkey')
begin
	alter table de_bo_segment_dataitem drop constraint de_bo_segment_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_bo_segment_relation_pkey')
begin
	alter table de_bo_segment_relation drop constraint de_bo_segment_relation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_bt_association_history_pk')
begin
	alter table de_bt_association_history drop constraint de_bt_association_history_pk
end

if exists(select 'x' from sysobjects where name = 'de_bt_attributes_history_pk')
begin
	alter table de_bt_attributes_history drop constraint de_bt_attributes_history_pk
end

if exists(select 'x' from sysobjects where name = 'de_bt_synonym_history_pk')
begin
	alter table de_bt_synonym_history drop constraint de_bt_synonym_history_pk
end

if exists(select 'x' from sysobjects where name = 'de_business_object_pkey')
begin
	alter table de_business_object drop constraint de_business_object_pkey
end

if exists(select 'x' from sysobjects where name = 'de_business_rule_pkey')
begin
	alter table de_business_rule drop constraint de_business_rule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_business_term_pkey')
begin
	alter table de_business_term drop constraint de_business_term_pkey
end

if exists(select 'x' from sysobjects where name = 'de_chart_header_pkey')
begin
	alter table de_chart_header drop constraint de_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 'de_chart_sample_data_pkey')
begin
	alter table de_chart_sample_data drop constraint de_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'de_chart_series_pkey')
begin
	alter table de_chart_series drop constraint de_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 'de_chm_service_datatitem_PK')
begin
	alter table de_chm_service_datatitem drop constraint de_chm_service_datatitem_PK
end

if exists(select 'x' from sysobjects where name = 'de_comp_doc_status_PKey')
begin
	alter table de_comp_doc_status drop constraint de_comp_doc_status_PKey
end

if exists(select 'x' from sysobjects where name = 'de_contextual_links_PK')
begin
	alter table de_contextual_links drop constraint de_contextual_links_PK
end

if exists(select 'x' from sysobjects where name = 'de_control_extensions_PK')
begin
	alter table de_control_extensions drop constraint de_control_extensions_PK
end

if exists(select 'x' from sysobjects where name = 'de_custom_listedit_PKey')
begin
	alter table de_custom_listedit drop constraint de_custom_listedit_PKey
end

if exists(select 'x' from sysobjects where name = 'de_date_highlight_control_map_PKey')
begin
	alter table de_date_highlight_control_map drop constraint de_date_highlight_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 'de_ecr_publish_chk_pkey')
begin
	alter table de_ecr_publish_chk drop constraint de_ecr_publish_chk_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_enum_value_default_flag')
begin
	alter table de_enum_value drop constraint Chk_de_enum_value_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_enum_value_pkey')
begin
	alter table de_enum_value drop constraint de_enum_value_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_detail_layout_pkey')
begin
	alter table de_exrep_detail_layout drop constraint de_exrep_detail_layout_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_header_layout_pkey')
begin
	alter table de_exrep_header_layout drop constraint de_exrep_header_layout_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_report_sections_pkey')
begin
	alter table de_exrep_report_sections drop constraint de_exrep_report_sections_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_task_template_map_pkey')
begin
	alter table de_exrep_task_template_map drop constraint de_exrep_task_template_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_templates_dtl_pkey')
begin
	alter table de_exrep_templates_dtl drop constraint de_exrep_templates_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_exrep_templates_hdr_pkey')
begin
	alter table de_exrep_templates_hdr drop constraint de_exrep_templates_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ext_js_control_PK')
begin
	alter table de_ext_js_control drop constraint de_ext_js_control_PK
end

if exists(select 'x' from sysobjects where name = 'de_ext_js_section_PK')
begin
	alter table de_ext_js_section drop constraint de_ext_js_section_PK
end

if exists(select 'x' from sysobjects where name = 'de_ext_js_section_column_PK')
begin
	alter table de_ext_js_section_column drop constraint de_ext_js_section_column_PK
end

if exists(select 'x' from sysobjects where name = 'de_ezeeview_sp_PK')
begin
	alter table de_ezeeview_sp drop constraint de_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 'de_ezeeview_spparamlist_pk')
begin
	alter table de_ezeeview_spparamlist drop constraint de_ezeeview_spparamlist_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_res_ilbo_dataitem_pk')
begin
	alter table de_ezwiz_res_ilbo_dataitem drop constraint de_ezwiz_res_ilbo_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_res_step_dataitem_pk')
begin
	alter table de_ezwiz_res_step_dataitem drop constraint de_ezwiz_res_step_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_wizard_pk')
begin
	alter table de_ezwiz_wizard drop constraint de_ezwiz_wizard_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_wizard_local_info_pk')
begin
	alter table de_ezwiz_wizard_local_info drop constraint de_ezwiz_wizard_local_info_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_wizard_step_pk')
begin
	alter table de_ezwiz_wizard_step drop constraint de_ezwiz_wizard_step_pk
end

if exists(select 'x' from sysobjects where name = 'de_ezwiz_wizard_step_local_info_pk')
begin
	alter table de_ezwiz_wizard_step_local_info drop constraint de_ezwiz_wizard_step_local_info_pk
end

if exists(select 'x' from sysobjects where name = 'de_flowbr_pkey')
begin
	alter table de_flowbr drop constraint de_flowbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_flowbr_br_error_default_flag')
begin
	alter table de_flowbr_br_error drop constraint Chk_de_flowbr_br_error_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_flowbr_br_error_pkey')
begin
	alter table de_flowbr_br_error drop constraint de_flowbr_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_flowbr_br_error_lng_extn_default_flag')
begin
	alter table de_flowbr_br_error_lng_extn drop constraint Chk_de_flowbr_br_error_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_flowbr_combo_pkey')
begin
	alter table de_flowbr_combo drop constraint de_flowbr_combo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_flowbr_method_map_pkey')
begin
	alter table de_flowbr_method_map drop constraint de_flowbr_method_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_flowbr_rule_map_br_type')
begin
	alter table de_flowbr_rule_map drop constraint Chk_de_flowbr_rule_map_br_type
end

if exists(select 'x' from sysobjects where name = 'de_flowbr_rule_map_pkey')
begin
	alter table de_flowbr_rule_map drop constraint de_flowbr_rule_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_affected_ius_temp_pkey')
begin
	alter table de_fw_des_affected_ius_temp drop constraint de_fw_des_affected_ius_temp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_be_placeholder_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_be_placeholder drop constraint de_fw_des_be_placeholder_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_be_placeholder_fkey_de_fw_des_error_placeholder')
begin
	alter table de_fw_des_be_placeholder drop constraint de_fw_des_be_placeholder_fkey_de_fw_des_error_placeholder
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_be_placeholder_pkey')
begin
	alter table de_fw_des_be_placeholder drop constraint de_fw_des_be_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_bo_statusflag')
begin
	alter table de_fw_des_bo drop constraint Chk_de_fw_des_bo_statusflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_bo_pkey')
begin
	alter table de_fw_des_bo drop constraint de_fw_des_bo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_bo_documentation_fkey_de_fw_des_bo')
begin
	alter table de_fw_des_bo_documentation drop constraint de_fw_des_bo_documentation_fkey_de_fw_des_bo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_bo_documentation_pkey')
begin
	alter table de_fw_des_bo_documentation drop constraint de_fw_des_bo_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_br_documentation_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_br_documentation drop constraint de_fw_des_br_documentation_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_br_documentation_pkey')
begin
	alter table de_fw_des_br_documentation drop constraint de_fw_des_br_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_br_logical_parameter_pkey')
begin
	alter table de_fw_des_br_logical_parameter drop constraint de_fw_des_br_logical_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_brerror_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_brerror drop constraint de_fw_des_brerror_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_brerror_fkey_de_fw_des_error')
begin
	alter table de_fw_des_brerror drop constraint de_fw_des_brerror_fkey_de_fw_des_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_brerror_pkey')
begin
	alter table de_fw_des_brerror drop constraint de_fw_des_brerror_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_brerror_unmap_pkey')
begin
	alter table de_fw_des_brerror_unmap drop constraint de_fw_des_brerror_unmap_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_bro_systemgenerated')
begin
	alter table de_fw_des_bro drop constraint Chk_de_fw_des_bro_systemgenerated
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_bro_pkey')
begin
	alter table de_fw_des_bro drop constraint de_fw_des_bro_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_businessrule_isintegbr')
begin
	alter table de_fw_des_businessrule drop constraint Chk_de_fw_des_businessrule_isintegbr
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_businessrule_statusflag')
begin
	alter table de_fw_des_businessrule drop constraint Chk_de_fw_des_businessrule_statusflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_businessrule_systemgenerated')
begin
	alter table de_fw_des_businessrule drop constraint Chk_de_fw_des_businessrule_systemgenerated
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_businessrule_fkey_de_fw_des_bo')
begin
	alter table de_fw_des_businessrule drop constraint de_fw_des_businessrule_fkey_de_fw_des_bo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_businessrule_fkey_de_fw_des_bro')
begin
	alter table de_fw_des_businessrule drop constraint de_fw_des_businessrule_fkey_de_fw_des_bro
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_businessrule_pkey')
begin
	alter table de_fw_des_businessrule drop constraint de_fw_des_businessrule_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_de_fw_des_businessrule_iedktemp')
begin
	alter table de_fw_des_businessrule_iedktemp drop constraint PK_de_fw_des_businessrule_iedktemp
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_chart_service_dataitem_pkey')
begin
	alter table de_fw_des_chart_service_dataitem drop constraint de_fw_des_chart_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_chart_service_segment_pkey')
begin
	alter table de_fw_des_chart_service_segment drop constraint de_fw_des_chart_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_context_fkey_de_fw_des_error')
begin
	alter table de_fw_des_context drop constraint de_fw_des_context_fkey_de_fw_des_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_context_pkey')
begin
	alter table de_fw_des_context drop constraint de_fw_des_context_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_corr_action_local_info_fkey_de_fw_des_context')
begin
	alter table de_fw_des_corr_action_local_info drop constraint de_fw_des_corr_action_local_info_fkey_de_fw_des_context
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_corr_action_local_info_pkey')
begin
	alter table de_fw_des_corr_action_local_info drop constraint de_fw_des_corr_action_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_dataitem_ispartofkey')
begin
	alter table de_fw_des_dataitem drop constraint Chk_de_fw_des_dataitem_ispartofkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_dataitem_mandatoryflag')
begin
	alter table de_fw_des_dataitem drop constraint Chk_de_fw_des_dataitem_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_dataitem_fkey_de_fw_des_dataitem')
begin
	alter table de_fw_des_dataitem drop constraint de_fw_des_dataitem_fkey_de_fw_des_dataitem
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_dataitem_fkey_de_fw_des_segment')
begin
	alter table de_fw_des_dataitem drop constraint de_fw_des_dataitem_fkey_de_fw_des_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_dataitem_pkey')
begin
	alter table de_fw_des_dataitem drop constraint de_fw_des_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_parameter_fkey_de_fw_des_br_logical_parameter')
begin
	alter table de_fw_des_di_parameter drop constraint de_fw_des_di_parameter_fkey_de_fw_des_br_logical_parameter
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_parameter_fkey_de_fw_des_processsection_br_is')
begin
	alter table de_fw_des_di_parameter drop constraint de_fw_des_di_parameter_fkey_de_fw_des_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_parameter_pkey')
begin
	alter table de_fw_des_di_parameter drop constraint de_fw_des_di_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_placeholder_fkey_de_fw_des_brerror')
begin
	alter table de_fw_des_di_placeholder drop constraint de_fw_des_di_placeholder_fkey_de_fw_des_brerror
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_placeholder_fkey_de_fw_des_error_placeholder')
begin
	alter table de_fw_des_di_placeholder drop constraint de_fw_des_di_placeholder_fkey_de_fw_des_error_placeholder
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_placeholder_fkey_de_fw_des_processsection_br_is')
begin
	alter table de_fw_des_di_placeholder drop constraint de_fw_des_di_placeholder_fkey_de_fw_des_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_placeholder_fkey_de_fw_des_service_dataitem')
begin
	alter table de_fw_des_di_placeholder drop constraint de_fw_des_di_placeholder_fkey_de_fw_des_service_dataitem
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_di_placeholder_pkey')
begin
	alter table de_fw_des_di_placeholder drop constraint de_fw_des_di_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_err_det_local_info_fkey_de_fw_des_error')
begin
	alter table de_fw_des_err_det_local_info drop constraint de_fw_des_err_det_local_info_fkey_de_fw_des_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_err_det_local_info_pkey')
begin
	alter table de_fw_des_err_det_local_info drop constraint de_fw_des_err_det_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_errbtn_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_des_errbtn_local_info drop constraint de_fw_des_errbtn_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_errbtn_local_info_pkey')
begin
	alter table de_fw_des_errbtn_local_info drop constraint de_fw_des_errbtn_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_error_pkey')
begin
	alter table de_fw_des_error drop constraint de_fw_des_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_error_lookup_dataitem_pk')
begin
	alter table de_fw_des_error_lookup_dataitem drop constraint de_fw_des_error_lookup_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_error_placeholder_fkey_de_fw_des_error')
begin
	alter table de_fw_des_error_placeholder drop constraint de_fw_des_error_placeholder_fkey_de_fw_des_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_error_placeholder_pkey')
begin
	alter table de_fw_des_error_placeholder drop constraint de_fw_des_error_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_focus_control_pkey')
begin
	alter table de_fw_des_focus_control drop constraint de_fw_des_focus_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_followup_tasks_pk')
begin
	alter table de_fw_des_followup_tasks drop constraint de_fw_des_followup_tasks_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_action_group_pkey')
begin
	alter table de_fw_des_ilbo_action_group drop constraint de_fw_des_ilbo_action_group_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actiongrp_event_fkey_de_fw_des_ilbo_action_group')
begin
	alter table de_fw_des_ilbo_actiongrp_event drop constraint de_fw_des_ilbo_actiongrp_event_fkey_de_fw_des_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actiongrp_event_fkey_de_fw_des_ilbo_ctrl_event')
begin
	alter table de_fw_des_ilbo_actiongrp_event drop constraint de_fw_des_ilbo_actiongrp_event_fkey_de_fw_des_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actiongrp_event_pkey')
begin
	alter table de_fw_des_ilbo_actiongrp_event drop constraint de_fw_des_ilbo_actiongrp_event_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actiongrp_task_fkey_de_fw_des_ilbo_action_group')
begin
	alter table de_fw_des_ilbo_actiongrp_task drop constraint de_fw_des_ilbo_actiongrp_task_fkey_de_fw_des_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actiongrp_task_pkey')
begin
	alter table de_fw_des_ilbo_actiongrp_task drop constraint de_fw_des_ilbo_actiongrp_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actions_fkey_de_fw_des_ilbo_action_group')
begin
	alter table de_fw_des_ilbo_actions drop constraint de_fw_des_ilbo_actions_fkey_de_fw_des_ilbo_action_group
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_actions_pkey')
begin
	alter table de_fw_des_ilbo_actions drop constraint de_fw_des_ilbo_actions_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_controlvalue_fkey_de_fw_des_ilbo_ctrl_event')
begin
	alter table de_fw_des_ilbo_controlvalue drop constraint de_fw_des_ilbo_controlvalue_fkey_de_fw_des_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_controlvalue_pkey')
begin
	alter table de_fw_des_ilbo_controlvalue drop constraint de_fw_des_ilbo_controlvalue_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_ilbo_ctrl_event_createstubflag')
begin
	alter table de_fw_des_ilbo_ctrl_event drop constraint Chk_de_fw_des_ilbo_ctrl_event_createstubflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_ctrl_event_pkey')
begin
	alter table de_fw_des_ilbo_ctrl_event drop constraint de_fw_des_ilbo_ctrl_event_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_placeholder_pkey')
begin
	alter table de_fw_des_ilbo_placeholder drop constraint de_fw_des_ilbo_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_service_view_attributemap_pkey')
begin
	alter table de_fw_des_ilbo_service_view_attributemap drop constraint de_fw_des_ilbo_service_view_attributemap_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_ilbo_service_view_datamap_iscontrol')
begin
	alter table de_fw_des_ilbo_service_view_datamap drop constraint Chk_de_fw_des_ilbo_service_view_datamap_iscontrol
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_service_view_datamap_pkey')
begin
	alter table de_fw_des_ilbo_service_view_datamap drop constraint de_fw_des_ilbo_service_view_datamap_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_ilbo_services_isprepopulate')
begin
	alter table de_fw_des_ilbo_services drop constraint Chk_de_fw_des_ilbo_services_isprepopulate
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_services_fkey_de_fw_des_service')
begin
	alter table de_fw_des_ilbo_services drop constraint de_fw_des_ilbo_services_fkey_de_fw_des_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilbo_services_pkey')
begin
	alter table de_fw_des_ilbo_services drop constraint de_fw_des_ilbo_services_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilerror_fkey_de_fw_des_ilbo_ctrl_event')
begin
	alter table de_fw_des_ilerror drop constraint de_fw_des_ilerror_fkey_de_fw_des_ilbo_ctrl_event
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_ilerror_pkey')
begin
	alter table de_fw_des_ilerror drop constraint de_fw_des_ilerror_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_integ_serv_map_fkey_de_fw_des_processsection_br_is')
begin
	alter table de_fw_des_integ_serv_map drop constraint de_fw_des_integ_serv_map_fkey_de_fw_des_processsection_br_is
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_integ_serv_map_pkey')
begin
	alter table de_fw_des_integ_serv_map drop constraint de_fw_des_integ_serv_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_integ_serv_map_mr_pop_pkey')
begin
	alter table de_fw_des_integ_serv_map_mr_pop drop constraint de_fw_des_integ_serv_map_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_message_task_map_pk')
begin
	alter table de_fw_des_message_task_map drop constraint de_fw_des_message_task_map_pk
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_fkey_de_fw_des_service')
begin
	alter table de_fw_des_processsection drop constraint de_fw_des_processsection_fkey_de_fw_des_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_pkey')
begin
	alter table de_fw_des_processsection drop constraint de_fw_des_processsection_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_processsection_br_is_executionflag')
begin
	alter table de_fw_des_processsection_br_is drop constraint Chk_de_fw_des_processsection_br_is_executionflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_processsection_br_is_isbr')
begin
	alter table de_fw_des_processsection_br_is drop constraint Chk_de_fw_des_processsection_br_is_isbr
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_processsection_br_is drop constraint de_fw_des_processsection_br_is_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_fkey_de_fw_des_processsection')
begin
	alter table de_fw_des_processsection_br_is drop constraint de_fw_des_processsection_br_is_fkey_de_fw_des_processsection
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_pkey')
begin
	alter table de_fw_des_processsection_br_is drop constraint de_fw_des_processsection_br_is_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_mr_pop_pkey')
begin
	alter table de_fw_des_processsection_br_is_mr_pop drop constraint de_fw_des_processsection_br_is_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_mr_pop_pkey')
begin
	alter table de_fw_des_processsection_mr_pop drop constraint de_fw_des_processsection_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_reqbr_desbr_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_reqbr_desbr drop constraint de_fw_des_reqbr_desbr_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_reqbr_desbr_pkey')
begin
	alter table de_fw_des_reqbr_desbr drop constraint de_fw_des_reqbr_desbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_segment_instanceflag')
begin
	alter table de_fw_des_segment drop constraint Chk_de_fw_des_segment_instanceflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_segment_fkey_de_fw_des_bo')
begin
	alter table de_fw_des_segment drop constraint de_fw_des_segment_fkey_de_fw_des_bo
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_segment_pkey')
begin
	alter table de_fw_des_segment drop constraint de_fw_des_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_isintegser')
begin
	alter table de_fw_des_service drop constraint Chk_de_fw_des_service_isintegser
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_statusflag')
begin
	alter table de_fw_des_service drop constraint Chk_de_fw_des_service_statusflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_fkey_de_fw_des_svco')
begin
	alter table de_fw_des_service drop constraint de_fw_des_service_fkey_de_fw_des_svco
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_pkey')
begin
	alter table de_fw_des_service drop constraint de_fw_des_service_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_dataitem_ispartofkey')
begin
	alter table de_fw_des_service_dataitem drop constraint Chk_de_fw_des_service_dataitem_ispartofkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_dataitem_mandatoryflag')
begin
	alter table de_fw_des_service_dataitem drop constraint Chk_de_fw_des_service_dataitem_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_dataitem_fkey_de_fw_des_service_segment')
begin
	alter table de_fw_des_service_dataitem drop constraint de_fw_des_service_dataitem_fkey_de_fw_des_service_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_dataitem_pkey')
begin
	alter table de_fw_des_service_dataitem drop constraint de_fw_des_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_documentation_fkey_de_fw_des_service')
begin
	alter table de_fw_des_service_documentation drop constraint de_fw_des_service_documentation_fkey_de_fw_des_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_documentation_pkey')
begin
	alter table de_fw_des_service_documentation drop constraint de_fw_des_service_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_de_fw_des_service_iedktemp')
begin
	alter table de_fw_des_service_iedktemp drop constraint PK_de_fw_des_service_iedktemp
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_segment_instanceflag')
begin
	alter table de_fw_des_service_segment drop constraint Chk_de_fw_des_service_segment_instanceflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_service_segment_mandatoryflag')
begin
	alter table de_fw_des_service_segment drop constraint Chk_de_fw_des_service_segment_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_segment_fkey_de_fw_des_service')
begin
	alter table de_fw_des_service_segment drop constraint de_fw_des_service_segment_fkey_de_fw_des_service
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_segment_fkey_de_fw_des_service_segment')
begin
	alter table de_fw_des_service_segment drop constraint de_fw_des_service_segment_fkey_de_fw_des_service_segment
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_service_segment_pkey')
begin
	alter table de_fw_des_service_segment drop constraint de_fw_des_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_sp_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_sp drop constraint de_fw_des_sp_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_sp_pkey')
begin
	alter table de_fw_des_sp drop constraint de_fw_des_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_svco_pkey')
begin
	alter table de_fw_des_svco drop constraint de_fw_des_svco_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_task_callout_pkey')
begin
	alter table de_fw_des_task_callout drop constraint de_fw_des_task_callout_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_task_callout_dataitem_pkey')
begin
	alter table de_fw_des_task_callout_dataitem drop constraint de_fw_des_task_callout_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_task_callout_segement_pkey')
begin
	alter table de_fw_des_task_callout_segement drop constraint de_fw_des_task_callout_segement_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_activity_iswfenabled')
begin
	alter table de_fw_req_activity drop constraint Chk_de_fw_req_activity_iswfenabled
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_fkey_de_fw_req_process_component')
begin
	alter table de_fw_req_activity drop constraint de_fw_req_activity_fkey_de_fw_req_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_pkey')
begin
	alter table de_fw_req_activity drop constraint de_fw_req_activity_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_documentation_fkey_de_fw_req_activity')
begin
	alter table de_fw_req_activity_documentation drop constraint de_fw_req_activity_documentation_fkey_de_fw_req_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_activity_documentation drop constraint de_fw_req_activity_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_documentation_pkey')
begin
	alter table de_fw_req_activity_documentation drop constraint de_fw_req_activity_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_fkey_de_fw_req_activity')
begin
	alter table de_fw_req_activity_ilbo drop constraint de_fw_req_activity_ilbo_fkey_de_fw_req_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_activity_ilbo drop constraint de_fw_req_activity_ilbo_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_pkey')
begin
	alter table de_fw_req_activity_ilbo drop constraint de_fw_req_activity_ilbo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_task_fkey_de_fw_req_activity_ilbo')
begin
	alter table de_fw_req_activity_ilbo_task drop constraint de_fw_req_activity_ilbo_task_fkey_de_fw_req_activity_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_task_fkey_de_fw_req_activity_task')
begin
	alter table de_fw_req_activity_ilbo_task drop constraint de_fw_req_activity_ilbo_task_fkey_de_fw_req_activity_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_task_pkey')
begin
	alter table de_fw_req_activity_ilbo_task drop constraint de_fw_req_activity_ilbo_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_ilbo_task_extension_map_pkey')
begin
	alter table de_fw_req_activity_ilbo_task_extension_map drop constraint de_fw_req_activity_ilbo_task_extension_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_local_info_fkey_de_fw_req_activity')
begin
	alter table de_fw_req_activity_local_info drop constraint de_fw_req_activity_local_info_fkey_de_fw_req_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_req_activity_local_info drop constraint de_fw_req_activity_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_local_info_pkey')
begin
	alter table de_fw_req_activity_local_info drop constraint de_fw_req_activity_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_task_fkey_de_fw_req_activity')
begin
	alter table de_fw_req_activity_task drop constraint de_fw_req_activity_task_fkey_de_fw_req_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_task_fkey_de_fw_req_task')
begin
	alter table de_fw_req_activity_task drop constraint de_fw_req_activity_task_fkey_de_fw_req_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_activity_task_pkey')
begin
	alter table de_fw_req_activity_task drop constraint de_fw_req_activity_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_bterm_fkey_de_fw_req_bterm')
begin
	alter table de_fw_req_br_bterm drop constraint de_fw_req_br_bterm_fkey_de_fw_req_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_bterm_fkey_de_fw_req_bterm_synonym')
begin
	alter table de_fw_req_br_bterm drop constraint de_fw_req_br_bterm_fkey_de_fw_req_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_bterm_fkey_de_fw_req_businessrule')
begin
	alter table de_fw_req_br_bterm drop constraint de_fw_req_br_bterm_fkey_de_fw_req_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_bterm_pkey')
begin
	alter table de_fw_req_br_bterm drop constraint de_fw_req_br_bterm_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_documentation_fkey_de_fw_req_businessrule')
begin
	alter table de_fw_req_br_documentation drop constraint de_fw_req_br_documentation_fkey_de_fw_req_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_documentation_pkey')
begin
	alter table de_fw_req_br_documentation drop constraint de_fw_req_br_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_fkey_de_fw_req_businessrule')
begin
	alter table de_fw_req_br_error drop constraint de_fw_req_br_error_fkey_de_fw_req_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_fkey_de_fw_req_error')
begin
	alter table de_fw_req_br_error drop constraint de_fw_req_br_error_fkey_de_fw_req_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_pkey')
begin
	alter table de_fw_req_br_error drop constraint de_fw_req_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_placeholder_fkey_de_fw_req_task_br_error_context')
begin
	alter table de_fw_req_br_error_placeholder drop constraint de_fw_req_br_error_placeholder_fkey_de_fw_req_task_br_error_context
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_placeholder_fkey_de_fw_req_taskrulesynonym_map')
begin
	alter table de_fw_req_br_error_placeholder drop constraint de_fw_req_br_error_placeholder_fkey_de_fw_req_taskrulesynonym_map
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_br_error_placeholder_pkey')
begin
	alter table de_fw_req_br_error_placeholder drop constraint de_fw_req_br_error_placeholder_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_bterm_isbterm')
begin
	alter table de_fw_req_bterm drop constraint Chk_de_fw_req_bterm_isbterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_fkey_de_fw_req_precision')
begin
	alter table de_fw_req_bterm drop constraint de_fw_req_bterm_fkey_de_fw_req_precision
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_pkey')
begin
	alter table de_fw_req_bterm drop constraint de_fw_req_bterm_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_enumerated_option_fkey_de_fw_req_bterm')
begin
	alter table de_fw_req_bterm_enumerated_option drop constraint de_fw_req_bterm_enumerated_option_fkey_de_fw_req_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_enumerated_option_pkey')
begin
	alter table de_fw_req_bterm_enumerated_option drop constraint de_fw_req_bterm_enumerated_option_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_group_fkey_de_fw_req_bterm')
begin
	alter table de_fw_req_bterm_group drop constraint de_fw_req_bterm_group_fkey_de_fw_req_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_group_fkey_de_fw_req_process_component')
begin
	alter table de_fw_req_bterm_group drop constraint de_fw_req_bterm_group_fkey_de_fw_req_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_group_pkey')
begin
	alter table de_fw_req_bterm_group drop constraint de_fw_req_bterm_group_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_synonym_fkey_de_fw_req_bterm')
begin
	alter table de_fw_req_bterm_synonym drop constraint de_fw_req_bterm_synonym_fkey_de_fw_req_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_bterm_synonym_pkey')
begin
	alter table de_fw_req_bterm_synonym drop constraint de_fw_req_bterm_synonym_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_businessrule_pkey')
begin
	alter table de_fw_req_businessrule drop constraint de_fw_req_businessrule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_component_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_component_documentation drop constraint de_fw_req_component_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_component_documentation_pkey')
begin
	alter table de_fw_req_component_documentation drop constraint de_fw_req_component_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_component_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_req_component_local_info drop constraint de_fw_req_component_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_component_local_info_fkey_de_fw_req_process_component')
begin
	alter table de_fw_req_component_local_info drop constraint de_fw_req_component_local_info_fkey_de_fw_req_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_component_local_info_pkey')
begin
	alter table de_fw_req_component_local_info drop constraint de_fw_req_component_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_error_pkey')
begin
	alter table de_fw_req_error drop constraint de_fw_req_error_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_error_local_info_fkey_de_fw_req_error')
begin
	alter table de_fw_req_error_local_info drop constraint de_fw_req_error_local_info_fkey_de_fw_req_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_error_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_req_error_local_info drop constraint de_fw_req_error_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_error_local_info_pkey')
begin
	alter table de_fw_req_error_local_info drop constraint de_fw_req_error_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_ilbo_statusflag')
begin
	alter table de_fw_req_ilbo drop constraint Chk_de_fw_req_ilbo_statusflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_pkey')
begin
	alter table de_fw_req_ilbo drop constraint de_fw_req_ilbo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_control_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_control drop constraint de_fw_req_ilbo_control_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_control_pkey')
begin
	alter table de_fw_req_ilbo_control drop constraint de_fw_req_ilbo_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_control_property_pkey')
begin
	alter table de_fw_req_ilbo_control_property drop constraint de_fw_req_ilbo_control_property_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_ilbo_data_publish_iscontrol')
begin
	alter table de_fw_req_ilbo_data_publish drop constraint Chk_de_fw_req_ilbo_data_publish_iscontrol
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_ilbo_data_publish_mandatoryflag')
begin
	alter table de_fw_req_ilbo_data_publish drop constraint Chk_de_fw_req_ilbo_data_publish_mandatoryflag
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_data_publish_fkey_de_fw_req_ilbo_link_publish')
begin
	alter table de_fw_req_ilbo_data_publish drop constraint de_fw_req_ilbo_data_publish_fkey_de_fw_req_ilbo_link_publish
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_data_publish_pkey')
begin
	alter table de_fw_req_ilbo_data_publish drop constraint de_fw_req_ilbo_data_publish_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_req_ilbo_data_use_iscontrol')
begin
	alter table de_fw_req_ilbo_data_use drop constraint Chk_de_fw_req_ilbo_data_use_iscontrol
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_data_use_pkey')
begin
	alter table de_fw_req_ilbo_data_use drop constraint de_fw_req_ilbo_data_use_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_documentation_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_documentation drop constraint de_fw_req_ilbo_documentation_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_ilbo_documentation drop constraint de_fw_req_ilbo_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_documentation_pkey')
begin
	alter table de_fw_req_ilbo_documentation drop constraint de_fw_req_ilbo_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_local_info_fkey_de_fw_req_ilbo_link_publish')
begin
	alter table de_fw_req_ilbo_link_local_info drop constraint de_fw_req_ilbo_link_local_info_fkey_de_fw_req_ilbo_link_publish
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_local_info_pkey')
begin
	alter table de_fw_req_ilbo_link_local_info drop constraint de_fw_req_ilbo_link_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_publish_pkey')
begin
	alter table de_fw_req_ilbo_link_publish drop constraint de_fw_req_ilbo_link_publish_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_use_documentation_fkey_de_fw_req_ilbo_linkuse')
begin
	alter table de_fw_req_ilbo_link_use_documentation drop constraint de_fw_req_ilbo_link_use_documentation_fkey_de_fw_req_ilbo_linkuse
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_use_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_ilbo_link_use_documentation drop constraint de_fw_req_ilbo_link_use_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_link_use_documentation_pkey')
begin
	alter table de_fw_req_ilbo_link_use_documentation drop constraint de_fw_req_ilbo_link_use_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_linkuse_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_linkuse drop constraint de_fw_req_ilbo_linkuse_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_linkuse_fkey_de_fw_req_task')
begin
	alter table de_fw_req_ilbo_linkuse drop constraint de_fw_req_ilbo_linkuse_fkey_de_fw_req_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_linkuse_pkey')
begin
	alter table de_fw_req_ilbo_linkuse drop constraint de_fw_req_ilbo_linkuse_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_local_info_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_local_info drop constraint de_fw_req_ilbo_local_info_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_req_ilbo_local_info drop constraint de_fw_req_ilbo_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_local_info_pkey')
begin
	alter table de_fw_req_ilbo_local_info drop constraint de_fw_req_ilbo_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_project_details_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_project_details drop constraint de_fw_req_ilbo_project_details_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_project_details_pkey')
begin
	alter table de_fw_req_ilbo_project_details drop constraint de_fw_req_ilbo_project_details_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_tab_properties_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_tab_properties drop constraint de_fw_req_ilbo_tab_properties_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_tab_properties_pkey')
begin
	alter table de_fw_req_ilbo_tab_properties drop constraint de_fw_req_ilbo_tab_properties_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_tabs_fkey_de_fw_req_ilbo')
begin
	alter table de_fw_req_ilbo_tabs drop constraint de_fw_req_ilbo_tabs_fkey_de_fw_req_ilbo
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_tabs_pkey')
begin
	alter table de_fw_req_ilbo_tabs drop constraint de_fw_req_ilbo_tabs_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_task_rpt_PK')
begin
	alter table de_fw_req_ilbo_task_rpt drop constraint de_fw_req_ilbo_task_rpt_PK
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_fkey_de_fw_req_bterm_synonym')
begin
	alter table de_fw_req_ilbo_view drop constraint de_fw_req_ilbo_view_fkey_de_fw_req_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_fkey_de_fw_req_ilbo_control')
begin
	alter table de_fw_req_ilbo_view drop constraint de_fw_req_ilbo_view_fkey_de_fw_req_ilbo_control
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_pkey')
begin
	alter table de_fw_req_ilbo_view drop constraint de_fw_req_ilbo_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_documentation_fkey_de_fw_req_ilbo_view')
begin
	alter table de_fw_req_ilbo_view_documentation drop constraint de_fw_req_ilbo_view_documentation_fkey_de_fw_req_ilbo_view
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_ilbo_view_documentation drop constraint de_fw_req_ilbo_view_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_documentation_pkey')
begin
	alter table de_fw_req_ilbo_view_documentation drop constraint de_fw_req_ilbo_view_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_local_info_fkey_de_fw_req_ilbo_view')
begin
	alter table de_fw_req_ilbo_view_local_info drop constraint de_fw_req_ilbo_view_local_info_fkey_de_fw_req_ilbo_view
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilbo_view_local_info_pkey')
begin
	alter table de_fw_req_ilbo_view_local_info drop constraint de_fw_req_ilbo_view_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_ilboctrl_initval_pkey')
begin
	alter table de_fw_req_ilboctrl_initval drop constraint de_fw_req_ilboctrl_initval_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_lang_bterm_synonym_fkey_de_fw_req_bterm_synonym')
begin
	alter table de_fw_req_lang_bterm_synonym drop constraint de_fw_req_lang_bterm_synonym_fkey_de_fw_req_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_lang_bterm_synonym_fkey_de_fw_req_language')
begin
	alter table de_fw_req_lang_bterm_synonym drop constraint de_fw_req_lang_bterm_synonym_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_lang_bterm_synonym_pkey')
begin
	alter table de_fw_req_lang_bterm_synonym drop constraint de_fw_req_lang_bterm_synonym_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_language_pkey')
begin
	alter table de_fw_req_language drop constraint de_fw_req_language_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_precision_pkey')
begin
	alter table de_fw_req_precision drop constraint de_fw_req_precision_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_fkey_de_fw_req_process')
begin
	alter table de_fw_req_process drop constraint de_fw_req_process_fkey_de_fw_req_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_pkey')
begin
	alter table de_fw_req_process drop constraint de_fw_req_process_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_component_fkey_de_fw_req_process')
begin
	alter table de_fw_req_process_component drop constraint de_fw_req_process_component_fkey_de_fw_req_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_component_pkey')
begin
	alter table de_fw_req_process_component drop constraint de_fw_req_process_component_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_process_documentation drop constraint de_fw_req_process_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_documentation_fkey_de_fw_req_process')
begin
	alter table de_fw_req_process_documentation drop constraint de_fw_req_process_documentation_fkey_de_fw_req_process
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_process_documentation_pkey')
begin
	alter table de_fw_req_process_documentation drop constraint de_fw_req_process_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_reference_value_fkey_de_fw_req_language')
begin
	alter table de_fw_req_reference_value drop constraint de_fw_req_reference_value_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_reference_value_pkey')
begin
	alter table de_fw_req_reference_value drop constraint de_fw_req_reference_value_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_pkey')
begin
	alter table de_fw_req_state drop constraint de_fw_req_state_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_activity_fkey_de_fw_req_activity')
begin
	alter table de_fw_req_state_activity drop constraint de_fw_req_state_activity_fkey_de_fw_req_activity
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_activity_fkey_de_fw_req_process_component')
begin
	alter table de_fw_req_state_activity drop constraint de_fw_req_state_activity_fkey_de_fw_req_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_activity_fkey_de_fw_req_state')
begin
	alter table de_fw_req_state_activity drop constraint de_fw_req_state_activity_fkey_de_fw_req_state
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_activity_pkey')
begin
	alter table de_fw_req_state_activity drop constraint de_fw_req_state_activity_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_component_fkey_de_fw_req_process_component')
begin
	alter table de_fw_req_state_component drop constraint de_fw_req_state_component_fkey_de_fw_req_process_component
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_component_fkey_de_fw_req_state')
begin
	alter table de_fw_req_state_component drop constraint de_fw_req_state_component_fkey_de_fw_req_state
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_component_fkey_de_fw_req_value_chain')
begin
	alter table de_fw_req_state_component drop constraint de_fw_req_state_component_fkey_de_fw_req_value_chain
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_state_component_pkey')
begin
	alter table de_fw_req_state_component drop constraint de_fw_req_state_component_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_system_parameters_pkey')
begin
	alter table de_fw_req_system_parameters drop constraint de_fw_req_system_parameters_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_pkey')
begin
	alter table de_fw_req_task drop constraint de_fw_req_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_br_error_context_fkey_de_fw_req_br_error')
begin
	alter table de_fw_req_task_br_error_context drop constraint de_fw_req_task_br_error_context_fkey_de_fw_req_br_error
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_br_error_context_fkey_de_fw_req_task_rule')
begin
	alter table de_fw_req_task_br_error_context drop constraint de_fw_req_task_br_error_context_fkey_de_fw_req_task_rule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_br_error_context_pkey')
begin
	alter table de_fw_req_task_br_error_context drop constraint de_fw_req_task_br_error_context_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_task_documentation drop constraint de_fw_req_task_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_documentation_fkey_de_fw_req_task')
begin
	alter table de_fw_req_task_documentation drop constraint de_fw_req_task_documentation_fkey_de_fw_req_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_documentation_pkey')
begin
	alter table de_fw_req_task_documentation drop constraint de_fw_req_task_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_local_info_fkey_de_fw_req_language')
begin
	alter table de_fw_req_task_local_info drop constraint de_fw_req_task_local_info_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_local_info_fkey_de_fw_req_task')
begin
	alter table de_fw_req_task_local_info drop constraint de_fw_req_task_local_info_fkey_de_fw_req_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_local_info_pkey')
begin
	alter table de_fw_req_task_local_info drop constraint de_fw_req_task_local_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_rule_fkey_de_fw_req_businessrule')
begin
	alter table de_fw_req_task_rule drop constraint de_fw_req_task_rule_fkey_de_fw_req_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_rule_fkey_de_fw_req_task')
begin
	alter table de_fw_req_task_rule drop constraint de_fw_req_task_rule_fkey_de_fw_req_task
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_task_rule_pkey')
begin
	alter table de_fw_req_task_rule drop constraint de_fw_req_task_rule_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_taskrulesynonym_map_fkey_de_fw_req_br_bterm')
begin
	alter table de_fw_req_taskrulesynonym_map drop constraint de_fw_req_taskrulesynonym_map_fkey_de_fw_req_br_bterm
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_taskrulesynonym_map_fkey_de_fw_req_bterm_synonym')
begin
	alter table de_fw_req_taskrulesynonym_map drop constraint de_fw_req_taskrulesynonym_map_fkey_de_fw_req_bterm_synonym
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_taskrulesynonym_map_pkey')
begin
	alter table de_fw_req_taskrulesynonym_map drop constraint de_fw_req_taskrulesynonym_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_value_chain_pkey')
begin
	alter table de_fw_req_value_chain drop constraint de_fw_req_value_chain_pkey
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_vc_documentation_fkey_de_fw_req_language')
begin
	alter table de_fw_req_vc_documentation drop constraint de_fw_req_vc_documentation_fkey_de_fw_req_language
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_vc_documentation_fkey_de_fw_req_value_chain')
begin
	alter table de_fw_req_vc_documentation drop constraint de_fw_req_vc_documentation_fkey_de_fw_req_value_chain
end

if exists(select 'x' from sysobjects where name = 'de_fw_req_vc_documentation_pkey')
begin
	alter table de_fw_req_vc_documentation drop constraint de_fw_req_vc_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_data_type')
begin
	alter table de_glossary drop constraint Chk_de_glossary_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_length')
begin
	alter table de_glossary drop constraint Chk_de_glossary_length
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_synonym_status')
begin
	alter table de_glossary drop constraint Chk_de_glossary_synonym_status
end

if exists(select 'x' from sysobjects where name = 'de_glossary_pkey')
begin
	alter table de_glossary drop constraint de_glossary_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_lng_extn_data_type')
begin
	alter table de_glossary_lng_extn drop constraint Chk_de_glossary_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_lng_extn_length')
begin
	alter table de_glossary_lng_extn drop constraint Chk_de_glossary_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_de_glossary_lng_extn_synonym_status')
begin
	alter table de_glossary_lng_extn drop constraint Chk_de_glossary_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'de_glossary_lng_extn_pkey')
begin
	alter table de_glossary_lng_extn drop constraint de_glossary_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_hidden_view_transfer_flag')
begin
	alter table de_hidden_view drop constraint Chk_de_hidden_view_transfer_flag
end

if exists(select 'x' from sysobjects where name = 'de_hidden_view_pkey')
begin
	alter table de_hidden_view drop constraint de_hidden_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_hidden_view_usage_pkey')
begin
	alter table de_hidden_view_usage drop constraint de_hidden_view_usage_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ibo_resolution_pkey')
begin
	alter table de_ibo_resolution drop constraint de_ibo_resolution_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ibo_segment_pkey')
begin
	alter table de_ibo_segment drop constraint de_ibo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ibo_segment_dataitem_pkey')
begin
	alter table de_ibo_segment_dataitem drop constraint de_ibo_segment_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_interaction_bo_pkey')
begin
	alter table de_interaction_bo drop constraint de_interaction_bo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_is_dataitem_map_pkey')
begin
	alter table de_is_dataitem_map drop constraint de_is_dataitem_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_is_interaction_pkey')
begin
	alter table de_is_interaction drop constraint de_is_interaction_pkey
end

if exists(select 'x' from sysobjects where name = 'de_listedit_column_PKey')
begin
	alter table de_listedit_column drop constraint de_listedit_column_PKey
end

if exists(select 'x' from sysobjects where name = 'de_listedit_control_map_PKey')
begin
	alter table de_listedit_control_map drop constraint de_listedit_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_control_dtl_fkey_de_glossary')
begin
	alter table de_LogicExt_ui_control_dtl drop constraint de_LogicExt_ui_control_dtl_fkey_de_glossary
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_control_dtl_fkey_de_glossary_ref')
begin
	alter table de_LogicExt_ui_control_dtl drop constraint de_LogicExt_ui_control_dtl_fkey_de_glossary_ref
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_control_dtl_fkey_de_ui')
begin
	alter table de_LogicExt_ui_control_dtl drop constraint de_LogicExt_ui_control_dtl_fkey_de_ui
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_control_dtl_fkey_de_ui_page')
begin
	alter table de_LogicExt_ui_control_dtl drop constraint de_LogicExt_ui_control_dtl_fkey_de_ui_page
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_control_dtl_pkey')
begin
	alter table de_LogicExt_ui_control_dtl drop constraint de_LogicExt_ui_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_grid_dtl_fkey_de_glossary_ref')
begin
	alter table de_LogicExt_ui_grid_dtl drop constraint de_LogicExt_ui_grid_dtl_fkey_de_glossary_ref
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_grid_dtl_fkey_de_ui')
begin
	alter table de_LogicExt_ui_grid_dtl drop constraint de_LogicExt_ui_grid_dtl_fkey_de_ui
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_grid_dtl_fkey_de_ui_page')
begin
	alter table de_LogicExt_ui_grid_dtl drop constraint de_LogicExt_ui_grid_dtl_fkey_de_ui_page
end

if exists(select 'x' from sysobjects where name = 'de_LogicExt_ui_grid_dtl_pkey')
begin
	alter table de_LogicExt_ui_grid_dtl drop constraint de_LogicExt_ui_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_message_pkey')
begin
	alter table de_message drop constraint de_message_pkey
end

if exists(select 'x' from sysobjects where name = 'de_method_doc_pkey')
begin
	alter table de_method_doc drop constraint de_method_doc_pkey
end

if exists(select 'x' from sysobjects where name = 'de_method_message_map_pkey')
begin
	alter table de_method_message_map drop constraint de_method_message_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_nativeapp_mapping_PK')
begin
	alter table de_nativeapp_mapping drop constraint de_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 'de_non_ui_control_pkey')
begin
	alter table de_non_ui_control drop constraint de_non_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_offtask_message_pk')
begin
	alter table de_offtask_message drop constraint de_offtask_message_pk
end

if exists(select 'x' from sysobjects where name = 'de_offtask_message_lng_extn_pk')
begin
	alter table de_offtask_message_lng_extn drop constraint de_offtask_message_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'offtask_message_lng_extn_fkey_de_offtask_message')
begin
	alter table de_offtask_message_lng_extn drop constraint offtask_message_lng_extn_fkey_de_offtask_message
end

if exists(select 'x' from sysobjects where name = 'de_offtask_message_ph_pk')
begin
	alter table de_offtask_message_ph drop constraint de_offtask_message_ph_pk
end

if exists(select 'x' from sysobjects where name = 'offtask_message_ph_fkey_de_offtask_message')
begin
	alter table de_offtask_message_ph drop constraint offtask_message_ph_fkey_de_offtask_message
end

if exists(select 'x' from sysobjects where name = 'de_offtask_message_phlist_pk')
begin
	alter table de_offtask_message_phlist drop constraint de_offtask_message_phlist_pk
end

if exists(select 'x' from sysobjects where name = 'de_offtask_query_pk')
begin
	alter table de_offtask_query drop constraint de_offtask_query_pk
end

if exists(select 'x' from sysobjects where name = 'de_offtask_queryparam_fkey_de_offtask_query')
begin
	alter table de_offtask_queryparam drop constraint de_offtask_queryparam_fkey_de_offtask_query
end

if exists(select 'x' from sysobjects where name = 'de_offtask_queryparam_pk')
begin
	alter table de_offtask_queryparam drop constraint de_offtask_queryparam_pk
end

if exists(select 'x' from sysobjects where name = 'de_offtask_tskqrymap_pk')
begin
	alter table de_offtask_tskqrymap drop constraint de_offtask_tskqrymap_pk
end

if exists(select 'x' from sysobjects where name = 'de_phone_pkey')
begin
	alter table de_phone drop constraint de_phone_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_column_group_mapping_pkey')
begin
	alter table de_phone_column_group_mapping drop constraint de_phone_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_columngroup_pkey')
begin
	alter table de_phone_columngroup drop constraint de_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_control_fkey_de_phone_section')
begin
	alter table de_phone_control drop constraint de_phone_control_fkey_de_phone_section
end

if exists(select 'x' from sysobjects where name = 'de_phone_control_pkey')
begin
	alter table de_phone_control drop constraint de_phone_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_grid_fkey_de_phone_control')
begin
	alter table de_phone_grid drop constraint de_phone_grid_fkey_de_phone_control
end

if exists(select 'x' from sysobjects where name = 'de_phone_grid_pkey')
begin
	alter table de_phone_grid drop constraint de_phone_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_grid_columngroup_pkey')
begin
	alter table de_phone_grid_columngroup drop constraint de_phone_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_page_fkey_de_phone')
begin
	alter table de_phone_page drop constraint de_phone_page_fkey_de_phone
end

if exists(select 'x' from sysobjects where name = 'de_phone_page_pkey')
begin
	alter table de_phone_page drop constraint de_phone_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_phone_section_fkey_de_phone_page')
begin
	alter table de_phone_section drop constraint de_phone_section_fkey_de_phone_page
end

if exists(select 'x' from sysobjects where name = 'de_phone_section_pkey')
begin
	alter table de_phone_section drop constraint de_phone_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_pivot_configure_pkey')
begin
	alter table de_pivot_configure drop constraint de_pivot_configure_pkey
end

if exists(select 'x' from sysobjects where name = 'de_pivot_fields_pkey')
begin
	alter table de_pivot_fields drop constraint de_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 'de_pivot_lang_extn_pkey')
begin
	alter table de_pivot_lang_extn drop constraint de_pivot_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'de_precision_type_pkey')
begin
	alter table de_precision_type drop constraint de_precision_type_pkey
end

if exists(select 'x' from sysobjects where name = 'de_provider_ibo_pkey')
begin
	alter table de_provider_ibo drop constraint de_provider_ibo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_provider_ibo_dataitem_fkey_de_provider_ibo_segment')
begin
	alter table de_provider_ibo_dataitem drop constraint de_provider_ibo_dataitem_fkey_de_provider_ibo_segment
end

if exists(select 'x' from sysobjects where name = 'de_provider_ibo_segment_fkey_de_provider_ibo')
begin
	alter table de_provider_ibo_segment drop constraint de_provider_ibo_segment_fkey_de_provider_ibo
end

if exists(select 'x' from sysobjects where name = 'de_provider_ibo_segment_pkey')
begin
	alter table de_provider_ibo_segment drop constraint de_provider_ibo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_publication_pkey')
begin
	alter table de_publication drop constraint de_publication_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_publication_dataitem_published_flow_direction')
begin
	alter table de_publication_dataitem drop constraint Chk_de_publication_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_publication_dataitem_pkey')
begin
	alter table de_publication_dataitem drop constraint de_publication_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_publication_dataitem_mr_pop_pkey')
begin
	alter table de_publication_dataitem_mr_pop drop constraint de_publication_dataitem_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 'de_publication_ref_pkey')
begin
	alter table de_publication_ref drop constraint de_publication_ref_pkey
end

if exists(select 'x' from sysobjects where name = 'de_quick_code_mst_pkey')
begin
	alter table de_quick_code_mst drop constraint de_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_radio_button_default_flag')
begin
	alter table de_radio_button drop constraint Chk_de_radio_button_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_radio_button_pkey')
begin
	alter table de_radio_button drop constraint de_radio_button_pkey
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_appvw_dtl_fkey_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_appvw_dtl drop constraint de_re_wsinp_appvw_dtl_fkey_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_appvw_dtl')
begin
	alter table de_re_wsinp_appvw_dtl drop constraint pk_de_re_wsinp_appvw_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_area_desc_fkey_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_area_desc drop constraint de_re_wsinp_area_desc_fkey_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_area_desc')
begin
	alter table de_re_wsinp_area_desc drop constraint pk_de_re_wsinp_area_desc
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_area_dtl_fkey_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_area_dtl drop constraint de_re_wsinp_area_dtl_fkey_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_area_dtl')
begin
	alter table de_re_wsinp_area_dtl drop constraint pk_de_re_wsinp_area_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_area_hdr_fkey_de_re_wsinp_rcn_dtl')
begin
	alter table de_re_wsinp_area_hdr drop constraint de_re_wsinp_area_hdr_fkey_de_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_area_hdr drop constraint pk_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_cat_desc_hdr_fkey_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_cat_desc_hdr drop constraint de_re_wsinp_cat_desc_hdr_fkey_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_cat_desc_hdr')
begin
	alter table de_re_wsinp_cat_desc_hdr drop constraint pk_de_re_wsinp_cat_desc_hdr
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_cat_hdr_fkey_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_cat_hdr drop constraint de_re_wsinp_cat_hdr_fkey_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_cat_hdr drop constraint pk_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_cat_parameters_fkey_de_re_wsinp_def_wf_setup')
begin
	alter table de_re_wsinp_cat_parameters drop constraint de_re_wsinp_cat_parameters_fkey_de_re_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_cat_parameters')
begin
	alter table de_re_wsinp_cat_parameters drop constraint pk_de_re_wsinp_cat_parameters
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_con_security_fkey_de_re_wsinp_rcn_dtl')
begin
	alter table de_re_wsinp_con_security drop constraint de_re_wsinp_con_security_fkey_de_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_con_security')
begin
	alter table de_re_wsinp_con_security drop constraint pk_de_re_wsinp_con_security
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_def_msg_dtl_fkey_de_re_wsinp_tsk_state_dtl')
begin
	alter table de_re_wsinp_def_msg_dtl drop constraint de_re_wsinp_def_msg_dtl_fkey_de_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_def_msg_dtl')
begin
	alter table de_re_wsinp_def_msg_dtl drop constraint pk_de_re_wsinp_def_msg_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_def_wf_setup_fkey_de_re_wsinp_area_hdr')
begin
	alter table de_re_wsinp_def_wf_setup drop constraint de_re_wsinp_def_wf_setup_fkey_de_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_def_wf_setup')
begin
	alter table de_re_wsinp_def_wf_setup drop constraint pk_de_re_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_doc_flow_dtl_fkey_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_doc_flow_dtl drop constraint de_re_wsinp_doc_flow_dtl_fkey_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_doc_flow_dtl')
begin
	alter table de_re_wsinp_doc_flow_dtl drop constraint pk_de_re_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_docflow_msg_dtl_fkey_de_re_wsinp_doc_flow_dtl')
begin
	alter table de_re_wsinp_docflow_msg_dtl drop constraint de_re_wsinp_docflow_msg_dtl_fkey_de_re_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_docflow_msg_dtl')
begin
	alter table de_re_wsinp_docflow_msg_dtl drop constraint pk_de_re_wsinp_docflow_msg_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_actcode_fkey_de_re_wsinp_nonrvw_compcode')
begin
	alter table de_re_wsinp_nonrvw_actcode drop constraint de_re_wsinp_nonrvw_actcode_fkey_de_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_actcode')
begin
	alter table de_re_wsinp_nonrvw_actcode drop constraint pk_de_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_actdesc_fkey_de_re_wsinp_nonrvw_actcode')
begin
	alter table de_re_wsinp_nonrvw_actdesc drop constraint de_re_wsinp_nonrvw_actdesc_fkey_de_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_actdesc')
begin
	alter table de_re_wsinp_nonrvw_actdesc drop constraint pk_de_re_wsinp_nonrvw_actdesc
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_compcode_fkey_de_re_wsinp_rcn_dtl')
begin
	alter table de_re_wsinp_nonrvw_compcode drop constraint de_re_wsinp_nonrvw_compcode_fkey_de_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_compcode')
begin
	alter table de_re_wsinp_nonrvw_compcode drop constraint pk_de_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_compdesc_fkey_de_re_wsinp_nonrvw_compcode')
begin
	alter table de_re_wsinp_nonrvw_compdesc drop constraint de_re_wsinp_nonrvw_compdesc_fkey_de_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_compdesc')
begin
	alter table de_re_wsinp_nonrvw_compdesc drop constraint pk_de_re_wsinp_nonrvw_compdesc
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_taskcode_fkey_de_re_wsinp_nonrvw_actcode')
begin
	alter table de_re_wsinp_nonrvw_taskcode drop constraint de_re_wsinp_nonrvw_taskcode_fkey_de_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_taskcode')
begin
	alter table de_re_wsinp_nonrvw_taskcode drop constraint pk_de_re_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_nonrvw_taskdesc_fkey_de_re_wsinp_nonrvw_taskcode')
begin
	alter table de_re_wsinp_nonrvw_taskdesc drop constraint de_re_wsinp_nonrvw_taskdesc_fkey_de_re_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_nonrvw_taskdesc')
begin
	alter table de_re_wsinp_nonrvw_taskdesc drop constraint pk_de_re_wsinp_nonrvw_taskdesc
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_qc_dtl_fkey_de_re_wsinp_qc_hdr')
begin
	alter table de_re_wsinp_qc_dtl drop constraint de_re_wsinp_qc_dtl_fkey_de_re_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_qc_dtl')
begin
	alter table de_re_wsinp_qc_dtl drop constraint pk_de_re_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_qc_hdr')
begin
	alter table de_re_wsinp_qc_hdr drop constraint pk_de_re_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_qc_lang_dtl_fkey_de_re_wsinp_qc_dtl')
begin
	alter table de_re_wsinp_qc_lang_dtl drop constraint de_re_wsinp_qc_lang_dtl_fkey_de_re_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_qc_lang_dtl')
begin
	alter table de_re_wsinp_qc_lang_dtl drop constraint pk_de_re_wsinp_qc_lang_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_rcn_dtl')
begin
	alter table de_re_wsinp_rcn_dtl drop constraint pk_de_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_security_dtl_fkey_de_re_wsinp_secusr_dtl')
begin
	alter table de_re_wsinp_security_dtl drop constraint de_re_wsinp_security_dtl_fkey_de_re_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_security_dtl')
begin
	alter table de_re_wsinp_security_dtl drop constraint pk_de_re_wsinp_security_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_secusr_dtl_fkey_de_re_wsinp_rcn_dtl')
begin
	alter table de_re_wsinp_secusr_dtl drop constraint de_re_wsinp_secusr_dtl_fkey_de_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_secusr_dtl')
begin
	alter table de_re_wsinp_secusr_dtl drop constraint pk_de_re_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_service_dtl_fkey_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_service_dtl drop constraint de_re_wsinp_service_dtl_fkey_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_service_dtl')
begin
	alter table de_re_wsinp_service_dtl drop constraint pk_de_re_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_state_desc_dtl_fkey_de_re_wsinp_tsk_state_dtl')
begin
	alter table de_re_wsinp_state_desc_dtl drop constraint de_re_wsinp_state_desc_dtl_fkey_de_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_state_desc_dtl')
begin
	alter table de_re_wsinp_state_desc_dtl drop constraint pk_de_re_wsinp_state_desc_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_task_dtl_fkey_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_task_dtl drop constraint de_re_wsinp_task_dtl_fkey_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_task_dtl')
begin
	alter table de_re_wsinp_task_dtl drop constraint pk_de_re_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_tsk_state_dtl_fkey_de_re_wsinp_task_dtl')
begin
	alter table de_re_wsinp_tsk_state_dtl drop constraint de_re_wsinp_tsk_state_dtl_fkey_de_re_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_tsk_state_dtl')
begin
	alter table de_re_wsinp_tsk_state_dtl drop constraint pk_de_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_tsk_stflow_dtl_fkey_de_re_wsinp_tsk_state_dtl')
begin
	alter table de_re_wsinp_tsk_stflow_dtl drop constraint de_re_wsinp_tsk_stflow_dtl_fkey_de_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_tsk_stflow_dtl')
begin
	alter table de_re_wsinp_tsk_stflow_dtl drop constraint pk_de_re_wsinp_tsk_stflow_dtl
end

if exists(select 'x' from sysobjects where name = 'de_re_wsinp_usr_noncon_task_fkey_de_re_wsinp_cat_hdr')
begin
	alter table de_re_wsinp_usr_noncon_task drop constraint de_re_wsinp_usr_noncon_task_fkey_de_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_de_re_wsinp_usr_noncon_task')
begin
	alter table de_re_wsinp_usr_noncon_task drop constraint pk_de_re_wsinp_usr_noncon_task
end

if exists(select 'x' from sysobjects where name = 'de_refine_chart_service_dataitem_pkey')
begin
	alter table de_refine_chart_service_dataitem drop constraint de_refine_chart_service_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_chart_service_segment_pkey')
begin
	alter table de_refine_chart_service_segment drop constraint de_refine_chart_service_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_ilboservice_map_pkey')
begin
	alter table de_refine_ilboservice_map drop constraint de_refine_ilboservice_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_method_documentation_pkey')
begin
	alter table de_refine_method_documentation drop constraint de_refine_method_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_method_error_map_pkey')
begin
	alter table de_refine_method_error_map drop constraint de_refine_method_error_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_parameter_pkey')
begin
	alter table de_refine_parameter drop constraint de_refine_parameter_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_process_section_pkey')
begin
	alter table de_refine_process_section drop constraint de_refine_process_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_refine_taskreuse_info_pkey')
begin
	alter table de_refine_taskreuse_info drop constraint de_refine_taskreuse_info_pkey
end

if exists(select 'x' from sysobjects where name = 'de_report_action_dataset_pkey')
begin
	alter table de_report_action_dataset drop constraint de_report_action_dataset_pkey
end

if exists(select 'x' from sysobjects where name = 'de_report_action_dataset_dataitem_PK')
begin
	alter table de_report_action_dataset_dataitem drop constraint de_report_action_dataset_dataitem_PK
end

if exists(select 'x' from sysobjects where name = 'de_report_action_dataset_segment_PK')
begin
	alter table de_report_action_dataset_segment drop constraint de_report_action_dataset_segment_PK
end

if exists(select 'x' from sysobjects where name = 'de_report_action_segment_pkey')
begin
	alter table de_report_action_segment drop constraint de_report_action_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_report_action_segment_dataitem_pkey')
begin
	alter table de_report_action_segment_dataitem drop constraint de_report_action_segment_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_report_attributes_PK')
begin
	alter table de_report_attributes drop constraint de_report_attributes_PK
end

if exists(select 'x' from sysobjects where name = 'de_report_attributes_tech_UNIQ')
begin
	alter table de_report_attributes drop constraint de_report_attributes_tech_UNIQ
end

if exists(select 'x' from sysobjects where name = 'de_report_dataset_dataitem_map_PK')
begin
	alter table de_report_dataset_dataitem_map drop constraint de_report_dataset_dataitem_map_PK
end

if exists(select 'x' from sysobjects where name = 'de_report_dataset_segment_map_PK')
begin
	alter table de_report_dataset_segment_map drop constraint de_report_dataset_segment_map_PK
end

if exists(select 'x' from sysobjects where name = 'de_requestor_ibo_pkey')
begin
	alter table de_requestor_ibo drop constraint de_requestor_ibo_pkey
end

if exists(select 'x' from sysobjects where name = 'de_requestor_ibo_dataitem_fkey_de_requestor_ibo_segment')
begin
	alter table de_requestor_ibo_dataitem drop constraint de_requestor_ibo_dataitem_fkey_de_requestor_ibo_segment
end

if exists(select 'x' from sysobjects where name = 'de_requestor_ibo_dataitem_pkey')
begin
	alter table de_requestor_ibo_dataitem drop constraint de_requestor_ibo_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_requestor_ibo_segment_fkey_de_requestor_ibo')
begin
	alter table de_requestor_ibo_segment drop constraint de_requestor_ibo_segment_fkey_de_requestor_ibo
end

if exists(select 'x' from sysobjects where name = 'de_requestor_ibo_segment_pkey')
begin
	alter table de_requestor_ibo_segment drop constraint de_requestor_ibo_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'de_resolved_link_pkey')
begin
	alter table de_resolved_link drop constraint de_resolved_link_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_resolved_link_dataitem_published_flow_direction')
begin
	alter table de_resolved_link_dataitem drop constraint Chk_de_resolved_link_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'Chk_de_resolved_link_dataitem_subscribed_flow_direction')
begin
	alter table de_resolved_link_dataitem drop constraint Chk_de_resolved_link_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_resolved_link_dataitem_pkey')
begin
	alter table de_resolved_link_dataitem drop constraint de_resolved_link_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_resolvelist_data_map_PKey')
begin
	alter table de_resolvelist_data_map drop constraint de_resolvelist_data_map_PKey
end

if exists(select 'x' from sysobjects where name = 'de_rmt_ico_ui_pkey')
begin
	alter table de_rmt_ico_ui drop constraint de_rmt_ico_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_rulegroup_exposed_flag')
begin
	alter table de_rulegroup drop constraint Chk_de_rulegroup_exposed_flag
end

if exists(select 'x' from sysobjects where name = 'de_rulegroup_pkey')
begin
	alter table de_rulegroup drop constraint de_rulegroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_rulegroup_step_pkey')
begin
	alter table de_rulegroup_step drop constraint de_rulegroup_step_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_rulegroup_step_msg_default_flag')
begin
	alter table de_rulegroup_step_msg drop constraint Chk_de_rulegroup_step_msg_default_flag
end

if exists(select 'x' from sysobjects where name = 'de_rulegroup_step_msg_pkey')
begin
	alter table de_rulegroup_step_msg drop constraint de_rulegroup_step_msg_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_column_pkey')
begin
	alter table de_schema_column drop constraint de_schema_column_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_dependentobj_pkey')
begin
	alter table de_schema_dependentobj drop constraint de_schema_dependentobj_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_function_pkey')
begin
	alter table de_schema_function drop constraint de_schema_function_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_function_param_pkey')
begin
	alter table de_schema_function_param drop constraint de_schema_function_param_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_index_pkey')
begin
	alter table de_schema_index drop constraint de_schema_index_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_index_columns_pkey')
begin
	alter table de_schema_index_columns drop constraint de_schema_index_columns_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_option_pkey')
begin
	alter table de_schema_option drop constraint de_schema_option_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_preference_pkey')
begin
	alter table de_schema_preference drop constraint de_schema_preference_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_relation_pkey')
begin
	alter table de_schema_relation drop constraint de_schema_relation_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_relation_det_pkey')
begin
	alter table de_schema_relation_det drop constraint de_schema_relation_det_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_scripts_pkey')
begin
	alter table de_schema_scripts drop constraint de_schema_scripts_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_sp_pkey')
begin
	alter table de_schema_sp drop constraint de_schema_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_sp_param_pkey')
begin
	alter table de_schema_sp_param drop constraint de_schema_sp_param_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_table_pkey')
begin
	alter table de_schema_table drop constraint de_schema_table_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_udd_pkey')
begin
	alter table de_schema_udd drop constraint de_schema_udd_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_validation_log_pkey')
begin
	alter table de_schema_validation_log drop constraint de_schema_validation_log_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_view_pkey')
begin
	alter table de_schema_view drop constraint de_schema_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_schema_view_column_pkey')
begin
	alter table de_schema_view_column drop constraint de_schema_view_column_pkey
end

if exists(select 'x' from sysobjects where name = 'de_scratch_variable_pkey')
begin
	alter table de_scratch_variable drop constraint de_scratch_variable_pkey
end

if exists(select 'x' from sysobjects where name = 'de_scratch_variables_sys_pkey')
begin
	alter table de_scratch_variables_sys drop constraint de_scratch_variables_sys_pkey
end

if exists(select 'x' from sysobjects where name = 'de_service_gen_log_pkey')
begin
	alter table de_service_gen_log drop constraint de_service_gen_log_pkey
end

if exists(select 'x' from sysobjects where name = 'de_service_gen_log_dtl_pkey')
begin
	alter table de_service_gen_log_dtl drop constraint de_service_gen_log_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_service_le_selservice_temp_pk')
begin
	alter table de_service_le_selservice_temp drop constraint de_service_le_selservice_temp_pk
end

if exists(select 'x' from sysobjects where name = 'de_service_logic_extn_dtl_pk')
begin
	alter table de_service_logic_extn_dtl drop constraint de_service_logic_extn_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'de_service_logic_extn_pattern_pk')
begin
	alter table de_service_logic_extn_pattern drop constraint de_service_logic_extn_pattern_pk
end

if exists(select 'x' from sysobjects where name = 'de_sp_report_action_dataitem_pkey')
begin
	alter table de_sp_report_action_dataitem drop constraint de_sp_report_action_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_sp_report_action_segment_pkey')
begin
	alter table de_sp_report_action_segment drop constraint de_sp_report_action_segment_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_subscription_link_type')
begin
	alter table de_subscription drop constraint Chk_de_subscription_link_type
end

if exists(select 'x' from sysobjects where name = 'de_subscription_pkey')
begin
	alter table de_subscription drop constraint de_subscription_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_subscription_dataitem_subscribed_flow_direction')
begin
	alter table de_subscription_dataitem drop constraint Chk_de_subscription_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 'de_subscription_dataitem_pkey')
begin
	alter table de_subscription_dataitem drop constraint de_subscription_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'de_sync_view_pkey')
begin
	alter table de_sync_view drop constraint de_sync_view_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_pkey')
begin
	alter table de_tablet drop constraint de_tablet_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_column_group_mapping_pkey')
begin
	alter table de_tablet_column_group_mapping drop constraint de_tablet_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_columngroup_pkey')
begin
	alter table de_tablet_columngroup drop constraint de_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_control_fkey_de_tablet_section')
begin
	alter table de_tablet_control drop constraint de_tablet_control_fkey_de_tablet_section
end

if exists(select 'x' from sysobjects where name = 'de_tablet_control_pkey')
begin
	alter table de_tablet_control drop constraint de_tablet_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_grid_fkey_de_tablet_control')
begin
	alter table de_tablet_grid drop constraint de_tablet_grid_fkey_de_tablet_control
end

if exists(select 'x' from sysobjects where name = 'de_tablet_grid_pkey')
begin
	alter table de_tablet_grid drop constraint de_tablet_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_grid_columngroup_pkey')
begin
	alter table de_tablet_grid_columngroup drop constraint de_tablet_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_page_fkey_de_tablet')
begin
	alter table de_tablet_page drop constraint de_tablet_page_fkey_de_tablet
end

if exists(select 'x' from sysobjects where name = 'de_tablet_page_pkey')
begin
	alter table de_tablet_page drop constraint de_tablet_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tablet_section_fkey_de_tablet_page')
begin
	alter table de_tablet_section drop constraint de_tablet_section_fkey_de_tablet_page
end

if exists(select 'x' from sysobjects where name = 'de_tablet_section_pkey')
begin
	alter table de_tablet_section drop constraint de_tablet_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_task_callout_map_pkey')
begin
	alter table de_task_callout_map drop constraint de_task_callout_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_task_control_attributemap_pkey')
begin
	alter table de_task_control_attributemap drop constraint de_task_control_attributemap_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_task_control_map_map_flag')
begin
	alter table de_task_control_map drop constraint Chk_de_task_control_map_map_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_task_control_map_map_ml_flag')
begin
	alter table de_task_control_map drop constraint Chk_de_task_control_map_map_ml_flag
end

if exists(select 'x' from sysobjects where name = 'de_task_control_map_pkey')
begin
	alter table de_task_control_map drop constraint de_task_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_task_service_map_pkey')
begin
	alter table de_task_service_map drop constraint de_task_service_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_Templates_pk')
begin
	alter table de_Templates drop constraint de_Templates_pk
end

if exists(select 'x' from sysobjects where name = 'de_tree_dtl_pkey')
begin
	alter table de_tree_dtl drop constraint de_tree_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tree_sample_data_pkey')
begin
	alter table de_tree_sample_data drop constraint de_tree_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'de_tree_sample_data_map_pkey')
begin
	alter table de_tree_sample_data_map drop constraint de_tree_sample_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_caption_alignment')
begin
	alter table de_ui drop constraint Chk_de_ui_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_trail_bar')
begin
	alter table de_ui drop constraint Chk_de_ui_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_ui_format')
begin
	alter table de_ui drop constraint Chk_de_ui_ui_format
end

if exists(select 'x' from sysobjects where name = 'de_ui_pkey')
begin
	alter table de_ui drop constraint de_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_column_group_mapping_pkey')
begin
	alter table de_ui_column_group_mapping drop constraint de_ui_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_columngroup_pkey')
begin
	alter table de_ui_columngroup drop constraint de_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_combolink_pkey')
begin
	alter table de_ui_combolink drop constraint de_ui_combolink_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_contextmenu_task_dtl_pk')
begin
	alter table de_ui_contextmenu_task_dtl drop constraint de_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_control_pkey')
begin
	alter table de_ui_control drop constraint de_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_pkey')
begin
	alter table de_ui_device drop constraint de_ui_device_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_control_pkey')
begin
	alter table de_ui_device_control drop constraint de_ui_device_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_grid_fkey_de_ui_grid')
begin
	alter table de_ui_device_grid drop constraint de_ui_device_grid_fkey_de_ui_grid
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_grid_pkey')
begin
	alter table de_ui_device_grid drop constraint de_ui_device_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_page_fkey_de_ui_page')
begin
	alter table de_ui_device_page drop constraint de_ui_device_page_fkey_de_ui_page
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_page_pkey')
begin
	alter table de_ui_device_page drop constraint de_ui_device_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_device_section_pkey')
begin
	alter table de_ui_device_section drop constraint de_ui_device_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_displaytext_lang_extn_PKey')
begin
	alter table de_ui_displaytext_lang_extn drop constraint de_ui_displaytext_lang_extn_PKey
end

if exists(select 'x' from sysobjects where name = 'de_ui_grid_pkey')
begin
	alter table de_ui_grid drop constraint de_ui_grid_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_grid_columngroup_pkey')
begin
	alter table de_ui_grid_columngroup drop constraint de_ui_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_history_pk')
begin
	alter table de_ui_history drop constraint de_ui_history_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_ico_pkey')
begin
	alter table de_ui_ico drop constraint de_ui_ico_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_page_pkey')
begin
	alter table de_ui_page drop constraint de_ui_page_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_pageevents_pk')
begin
	alter table de_ui_pageevents drop constraint de_ui_pageevents_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_placeholder_lng_extn_pk')
begin
	alter table de_ui_placeholder_lng_extn drop constraint de_ui_placeholder_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_section_border_required')
begin
	alter table de_ui_section drop constraint Chk_de_ui_section_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_section_title_alignment')
begin
	alter table de_ui_section drop constraint Chk_de_ui_section_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_section_title_required')
begin
	alter table de_ui_section drop constraint Chk_de_ui_section_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_section_visisble_flag')
begin
	alter table de_ui_section drop constraint Chk_de_ui_section_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'de_ui_section_pkey')
begin
	alter table de_ui_section drop constraint de_ui_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_section_control_map_pkey')
begin
	alter table de_ui_section_control_map drop constraint de_ui_section_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_pkey')
begin
	alter table de_ui_state drop constraint de_ui_state_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_column_fkey_de_ui_grid')
begin
	alter table de_ui_state_column drop constraint de_ui_state_column_fkey_de_ui_grid
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_column_PK')
begin
	alter table de_ui_state_column drop constraint de_ui_state_column_PK
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_control_Fkey_de_ui_control')
begin
	alter table de_ui_state_control drop constraint de_ui_state_control_Fkey_de_ui_control
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_control_pkey')
begin
	alter table de_ui_state_control drop constraint de_ui_state_control_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_page_fkey_de_ui_page')
begin
	alter table de_ui_state_page drop constraint de_ui_state_page_fkey_de_ui_page
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_page_PK')
begin
	alter table de_ui_state_page drop constraint de_ui_state_page_PK
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_section_Fkey_de_ui_section')
begin
	alter table de_ui_state_section drop constraint de_ui_state_section_Fkey_de_ui_section
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_section_pkey')
begin
	alter table de_ui_state_section drop constraint de_ui_state_section_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_task_pkey')
begin
	alter table de_ui_state_task drop constraint de_ui_state_task_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_state_task_mst_pkey')
begin
	alter table de_ui_state_task_mst drop constraint de_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'de_ui_taskpane_pk')
begin
	alter table de_ui_taskpane drop constraint de_ui_taskpane_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_Temp_placeholders_pk')
begin
	alter table de_ui_Temp_placeholders drop constraint de_ui_Temp_placeholders_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_template_controlmap_pk')
begin
	alter table de_ui_template_controlmap drop constraint de_ui_template_controlmap_pk
end

if exists(select 'x' from sysobjects where name = 'de_ui_toolbar_PKey')
begin
	alter table de_ui_toolbar drop constraint de_ui_toolbar_PKey
end

if exists(select 'x' from sysobjects where name = 'de_ui_toolbar_group_PKey')
begin
	alter table de_ui_toolbar_group drop constraint de_ui_toolbar_group_PKey
end

if exists(select 'x' from sysobjects where name = 'de_ui_toolbar_mapping_PKey')
begin
	alter table de_ui_toolbar_mapping drop constraint de_ui_toolbar_mapping_PKey
end

if exists(select 'x' from sysobjects where name = 'de_ui_tooltip_lng_extn_pk')
begin
	alter table de_ui_tooltip_lng_extn drop constraint de_ui_tooltip_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_de_ui_traversal_link_type')
begin
	alter table de_ui_traversal drop constraint Chk_de_ui_traversal_link_type
end

if exists(select 'x' from sysobjects where name = 'de_ui_traversal_pkey')
begin
	alter table de_ui_traversal drop constraint de_ui_traversal_pkey
end

if exists(select 'x' from sysobjects where name = 'de_user_section_pkey')
begin
	alter table de_user_section drop constraint de_user_section_pkey
end
-- Added on 31st Dec Starts

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_mdcf_glossary_lng_extn_fkey_de_glossary')
BEGIN
	ALTER TABLE de_mdcf_glossary_lng_extn DROP CONSTRAINT de_mdcf_glossary_lng_extn_fkey_de_glossary
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_mdcf_template_taskcontrol_map_fkey_de_mdcf_template_task')
BEGIN
	ALTER TABLE de_mdcf_template_taskcontrol_map DROP CONSTRAINT de_mdcf_template_taskcontrol_map_fkey_de_mdcf_template_task
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_mdcf_template_task_fkey_de_mdcf_template_ilbo')
BEGIN
	ALTER TABLE de_mdcf_template_task DROP CONSTRAINT de_mdcf_template_task_fkey_de_mdcf_template_ilbo
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_mdcf_template_ilbo_fkey_de_mdcf_template')
BEGIN
	ALTER TABLE de_mdcf_template_ilbo DROP CONSTRAINT de_mdcf_template_ilbo_fkey_de_mdcf_template
END
GO

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_template')
begin
	alter table de_mdcf_template drop constraint PK_de_mdcf_template
end

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_template_ilbo')
begin
	alter table de_mdcf_template_ilbo drop constraint PK_de_mdcf_template_ilbo
end

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_template_task')
begin
	alter table de_mdcf_template_task drop constraint PK_de_mdcf_template_task
end

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_template_taskseq')
begin
	alter table de_mdcf_template_taskseq drop constraint PK_de_mdcf_template_taskseq
end

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_template_taskcontrol_map')
begin
	alter table de_mdcf_template_taskcontrol_map drop constraint PK_de_mdcf_template_taskcontrol_map
end

if exists(select 'x' from sysobjects where name = 'PK_de_mdcf_glossary_lng_extn')
begin
	alter table de_mdcf_glossary_lng_extn drop constraint PK_de_mdcf_glossary_lng_extn
end

if exists(select 'x' from sysobjects where name = 'PK_de_up_defaulting_dtl')
begin
	alter table de_up_defaulting_dtl drop constraint PK_de_up_defaulting_dtl
end

-- Added on 31st Dec Ends
if exists(select 'x' from sysobjects where name = 'pk_de_wsinp_ecn_dtl')
begin
	alter table de_wsinp_ecn_dtl drop constraint pk_de_wsinp_ecn_dtl
end

if exists(select 'x' from sysobjects where name = 'de_wsinp_is_control_dtl_fkey_de_wsinp_task_dtl')
begin
	alter table de_wsinp_is_control_dtl drop constraint de_wsinp_is_control_dtl_fkey_de_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_wsinp_is_control_dtl')
begin
	alter table de_wsinp_is_control_dtl drop constraint pk_de_wsinp_is_control_dtl
end

if exists(select 'x' from sysobjects where name = 'de_wsinp_mypage_control_dtl_fkey_de_wsinp_task_dtl')
begin
	alter table de_wsinp_mypage_control_dtl drop constraint de_wsinp_mypage_control_dtl_fkey_de_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_wsinp_mypage_control_dtl')
begin
	alter table de_wsinp_mypage_control_dtl drop constraint pk_de_wsinp_mypage_control_dtl
end

if exists(select 'x' from sysobjects where name = 'de_wsinp_service_dtl_fkey_de_wsinp_task_dtl')
begin
	alter table de_wsinp_service_dtl drop constraint de_wsinp_service_dtl_fkey_de_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_wsinp_service_dtl')
begin
	alter table de_wsinp_service_dtl drop constraint pk_de_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 'de_wsinp_task_dtl_fkey_de_wsinp_ecn_dtl')
begin
	alter table de_wsinp_task_dtl drop constraint de_wsinp_task_dtl_fkey_de_wsinp_ecn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_de_wsinp_task_dtl')
begin
	alter table de_wsinp_task_dtl drop constraint pk_de_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'dlp_assignment_dtl_fkey_dlp_plan_dtl')
begin
	alter table dlp_assignment_dtl drop constraint dlp_assignment_dtl_fkey_dlp_plan_dtl
end

if exists(select 'x' from sysobjects where name = 'dlp_assignment_dtl_pkey')
begin
	alter table dlp_assignment_dtl drop constraint dlp_assignment_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_assignment_history_fkey_dlp_plan_history')
begin
	alter table dlp_assignment_history drop constraint dlp_assignment_history_fkey_dlp_plan_history
end

if exists(select 'x' from sysobjects where name = 'dlp_assignment_history_pkey')
begin
	alter table dlp_assignment_history drop constraint dlp_assignment_history_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_change_assignment_fkey_dlp_change_log')
begin
	alter table dlp_change_assignment drop constraint dlp_change_assignment_fkey_dlp_change_log
end

if exists(select 'x' from sysobjects where name = 'dlp_change_assignment_pkey')
begin
	alter table dlp_change_assignment drop constraint dlp_change_assignment_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_change_log_pkey')
begin
	alter table dlp_change_log drop constraint dlp_change_log_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_fin_note_hdr_pkey')
begin
	alter table dlp_fin_note_hdr drop constraint dlp_fin_note_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_gen_planstructure_pkey')
begin
	alter table dlp_gen_planstructure drop constraint dlp_gen_planstructure_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_gen_workproduct_pkey')
begin
	alter table dlp_gen_workproduct drop constraint dlp_gen_workproduct_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_genplan_Doc_pkey')
begin
	alter table dlp_genplan_doc drop constraint dlp_genplan_Doc_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_internal_milstone_pkey')
begin
	alter table dlp_internal_milstone drop constraint dlp_internal_milstone_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_leaf_predecessors_pkey')
begin
	alter table DLP_Leaf_predecessors drop constraint dlp_leaf_predecessors_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_nonsoftware_wp_pkey')
begin
	alter table dlp_nonsoftware_wp drop constraint dlp_nonsoftware_wp_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_plan_detail_arc_pkey')
begin
	alter table dlp_plan_detail_arc drop constraint dlp_plan_detail_arc_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_plan_dtl_pkey')
begin
	alter table dlp_plan_dtl drop constraint dlp_plan_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_plan_history_pkey')
begin
	alter table dlp_plan_history drop constraint dlp_plan_history_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_plan_metrix_dtl_pkey')
begin
	alter table dlp_plan_metrix_dtl drop constraint dlp_plan_metrix_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_pln_structure_pkey')
begin
	alter table dlp_pln_structure drop constraint dlp_pln_structure_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_pln_structure_ref_template_pkey')
begin
	alter table dlp_pln_structure_ref_template drop constraint dlp_pln_structure_ref_template_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_quick_code_met_pkey')
begin
	alter table dlp_quick_code_met drop constraint dlp_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_wp_activities_pkey')
begin
	alter table dlp_wp_activities drop constraint dlp_wp_activities_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_wp_component_pkey')
begin
	alter table dlp_wp_component drop constraint dlp_wp_component_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_wp_document_pkey')
begin
	alter table dlp_wp_document drop constraint dlp_wp_document_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_wp_process_pkey')
begin
	alter table dlp_wp_process drop constraint dlp_wp_process_pkey
end

if exists(select 'x' from sysobjects where name = 'dlp_wp_ui_pkey')
begin
	alter table dlp_wp_ui drop constraint dlp_wp_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'pk_dm_plf_release_objdet')
begin
	alter table dm_plf_release_objdet drop constraint pk_dm_plf_release_objdet
end

if exists(select 'x' from sysobjects where name = 'dmn_reference_table_pk')
begin
	alter table dmn_reference_table drop constraint dmn_reference_table_pk
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_CONTROLS')
begin
	alter table DOCMAP_CONTROLS drop constraint pk_DOCMAP_CONTROLS
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_GRID_LIST')
begin
	alter table DOCMAP_GRID_LIST drop constraint pk_DOCMAP_GRID_LIST
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_MAP')
begin
	alter table DOCMAP_MAP drop constraint pk_DOCMAP_MAP
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_MAPPINGS')
begin
	alter table DOCMAP_MAPPINGS drop constraint pk_DOCMAP_MAPPINGS
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_SECTIONS')
begin
	alter table DOCMAP_SECTIONS drop constraint pk_DOCMAP_SECTIONS
end

if exists(select 'x' from sysobjects where name = 'pk_DOCMAP_TMPL')
begin
	alter table DOCMAP_TMPL drop constraint pk_DOCMAP_TMPL
end

if exists(select 'x' from sysobjects where name = 'ec_comreview_pkey')
begin
	alter table ec_comreview drop constraint ec_comreview_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_comreview_dtl_pkey')
begin
	alter table ec_comreview_dtl drop constraint ec_comreview_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_comreview_type_pkey')
begin
	alter table ec_comreview_type drop constraint ec_comreview_type_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_conreview_pkey')
begin
	alter table ec_conreview drop constraint ec_conreview_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_conreview_dtl_pkey')
begin
	alter table ec_conreview_dtl drop constraint ec_conreview_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_conreview_type_pkey')
begin
	alter table ec_conreview_type drop constraint ec_conreview_type_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_dccreview_pkey')
begin
	alter table ec_dccreview drop constraint ec_dccreview_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_dccreview_dtl_pkey')
begin
	alter table ec_dccreview_dtl drop constraint ec_dccreview_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_dccreview_type_pkey')
begin
	alter table ec_dccreview_type drop constraint ec_dccreview_type_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_rereview_pkey')
begin
	alter table ec_rereview drop constraint ec_rereview_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_rereview_dtl_pkey')
begin
	alter table ec_rereview_dtl drop constraint ec_rereview_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ec_rereview_type_pkey')
begin
	alter table ec_rereview_type drop constraint ec_rereview_type_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_em_attach_go_mst')
begin
	alter table em_attach_go_mst drop constraint PK_em_attach_go_mst
end

if exists(select 'x' from sysobjects where name = 'PK_em_attachments_dtl')
begin
	alter table em_attachments_dtl drop constraint PK_em_attachments_dtl
end

if exists(select 'x' from sysobjects where name = 'em_attachments_mst_fkey_em_scenario')
begin
	alter table em_attachments_mst drop constraint em_attachments_mst_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_attachments_mst')
begin
	alter table em_attachments_mst drop constraint PK_em_attachments_mst
end

if exists(select 'x' from sysobjects where name = 'PK_em_configuration')
begin
	alter table em_configuration drop constraint PK_em_configuration
end

if exists(select 'x' from sysobjects where name = 'em_ilbo_fkey_em_scenario')
begin
	alter table em_ilbo drop constraint em_ilbo_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_link_fkey_em_scenario')
begin
	alter table em_link drop constraint em_link_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_node_fkey_em_scenario')
begin
	alter table em_node drop constraint em_node_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_pathinfo_fkey_em_scenario')
begin
	alter table em_pathinfo drop constraint em_pathinfo_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_point_fkey_em_scenario')
begin
	alter table em_point drop constraint em_point_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_publish_ilbo_fkey_em_scenario')
begin
	alter table em_publish_ilbo drop constraint em_publish_ilbo_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_publish_link_fkey_em_scenario')
begin
	alter table em_publish_link drop constraint em_publish_link_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_publish_node_fkey_em_scenario')
begin
	alter table em_publish_node drop constraint em_publish_node_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_publish_pathinfo_fkey_em_scenario')
begin
	alter table em_publish_pathinfo drop constraint em_publish_pathinfo_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_publish_point_fkey_em_scenario')
begin
	alter table em_publish_point drop constraint em_publish_point_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario')
begin
	alter table em_scenario drop constraint PK_em_scenario
end

if exists(select 'x' from sysobjects where name = 'em_scenario_activity_fkey_em_scenario')
begin
	alter table em_scenario_activity drop constraint em_scenario_activity_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity')
begin
	alter table em_scenario_activity drop constraint PK_em_scenario_activity
end

if exists(select 'x' from sysobjects where name = 'em_scenario_activity_association_fkey_em_scenario')
begin
	alter table em_scenario_activity_association drop constraint em_scenario_activity_association_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity_association')
begin
	alter table em_scenario_activity_association drop constraint PK_em_scenario_activity_association
end

if exists(select 'x' from sysobjects where name = 'em_scenario_activity_association_wrk_fkey_em_scenario')
begin
	alter table em_scenario_activity_association_wrk drop constraint em_scenario_activity_association_wrk_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity_association_wrk')
begin
	alter table em_scenario_activity_association_wrk drop constraint PK_em_scenario_activity_association_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_activity_events_wrk_fkey_em_scenario')
begin
	alter table em_scenario_activity_events_wrk drop constraint em_scenario_activity_events_wrk_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity_events_wrk')
begin
	alter table em_scenario_activity_events_wrk drop constraint PK_em_scenario_activity_events_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_activity_ui_wrk_fkey_em_scenario_activity_wrk')
begin
	alter table em_scenario_activity_ui_wrk drop constraint em_scenario_activity_ui_wrk_fkey_em_scenario_activity_wrk
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity_ui_wrk')
begin
	alter table em_scenario_activity_ui_wrk drop constraint PK_em_scenario_activity_ui_wrk
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_activity_wrk')
begin
	alter table em_scenario_activity_wrk drop constraint PK_em_scenario_activity_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_app_fkey_em_scenario')
begin
	alter table em_scenario_app drop constraint em_scenario_app_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_app')
begin
	alter table em_scenario_app drop constraint PK_em_scenario_app
end

if exists(select 'x' from sysobjects where name = 'em_scenario_bp_fkey_em_scenario')
begin
	alter table em_scenario_bp drop constraint em_scenario_bp_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_bp')
begin
	alter table em_scenario_bp drop constraint PK_em_scenario_bp
end

if exists(select 'x' from sysobjects where name = 'em_scenario_bp_association_fkey_em_scenario')
begin
	alter table em_scenario_bp_association drop constraint em_scenario_bp_association_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_bp_association')
begin
	alter table em_scenario_bp_association drop constraint PK_em_scenario_bp_association
end

if exists(select 'x' from sysobjects where name = 'em_scenario_bp_association_wrk_fkey_em_scenario')
begin
	alter table em_scenario_bp_association_wrk drop constraint em_scenario_bp_association_wrk_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_bp_association_wrk')
begin
	alter table em_scenario_bp_association_wrk drop constraint PK_em_scenario_bp_association_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_bp_events_wrk_fkey_em_scenario')
begin
	alter table em_scenario_bp_events_wrk drop constraint em_scenario_bp_events_wrk_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_bp_events_wrk')
begin
	alter table em_scenario_bp_events_wrk drop constraint PK_em_scenario_bp_events_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_function_wrk_fkey_em_scenario')
begin
	alter table em_scenario_function_wrk drop constraint em_scenario_function_wrk_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_function_wrk')
begin
	alter table em_scenario_function_wrk drop constraint PK_em_scenario_function_wrk
end

if exists(select 'x' from sysobjects where name = 'em_scenario_nodedtl_fkey_em_scenario')
begin
	alter table em_scenario_nodedtl drop constraint em_scenario_nodedtl_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_nodedtl')
begin
	alter table em_scenario_nodedtl drop constraint PK_em_scenario_nodedtl
end

if exists(select 'x' from sysobjects where name = 'em_scenario_nodedtl_bl_fkey_em_scenario')
begin
	alter table em_scenario_nodedtl_bl drop constraint em_scenario_nodedtl_bl_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_nodedtl_bl')
begin
	alter table em_scenario_nodedtl_bl drop constraint PK_em_scenario_nodedtl_bl
end

if exists(select 'x' from sysobjects where name = 'em_scenario_status_fkey_em_scenario')
begin
	alter table em_scenario_status drop constraint em_scenario_status_fkey_em_scenario
end

if exists(select 'x' from sysobjects where name = 'PK_em_scenario_status')
begin
	alter table em_scenario_status drop constraint PK_em_scenario_status
end

if exists(select 'x' from sysobjects where name = 'PK_em_temp_mluidetails')
begin
	alter table em_temp_mluidetails drop constraint PK_em_temp_mluidetails
end

if exists(select 'x' from sysobjects where name = 'PK_em_ui_nodedtl')
begin
	alter table em_ui_nodedtl drop constraint PK_em_ui_nodedtl
end

if exists(select 'x' from sysobjects where name = 'engg_dc_203exp_comp_details_pk')
begin
	alter table engg_dc_203exp_comp_details drop constraint engg_dc_203exp_comp_details_pk
end

if exists(select 'x' from sysobjects where name = 'engg_dc_203exp_exceptions_pub_unq_idx_pkey')
begin
	alter table engg_dc_203exp_exceptions_pub drop constraint engg_dc_203exp_exceptions_pub_unq_idx_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_dc_203exp_exceptions_re_pub_unq_idx_pkey')
begin
	alter table engg_dc_203exp_exceptions_re_pub drop constraint engg_dc_203exp_exceptions_re_pub_unq_idx_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_dc_203exp_exceptions_sol_pub_unq_idx_pkey')
begin
	alter table engg_dc_203exp_exceptions_sol_pub drop constraint engg_dc_203exp_exceptions_sol_pub_unq_idx_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_dc_203exp_status_details_pk')
begin
	alter table engg_dc_203exp_status_details drop constraint engg_dc_203exp_status_details_pk
end

if exists(select 'x' from sysobjects where name = 'dm_plf_user_version_map_plfDB_pkey')
begin
	alter table engg_dc_DM_plf_version drop constraint dm_plf_user_version_map_plfDB_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_engg_devcon_203exp_exceptions_exp_cat')
begin
	alter table engg_devcon_203exp_exceptions drop constraint Chk_engg_devcon_203exp_exceptions_exp_cat
end

if exists(select 'x' from sysobjects where name = 'Chk_engg_devcon_203exp_exceptions_exp_Level')
begin
	alter table engg_devcon_203exp_exceptions drop constraint Chk_engg_devcon_203exp_exceptions_exp_Level
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_Admin_status_pkey')
begin
	alter table engg_devcon_codegen_Admin_status drop constraint engg_devcon_codegen_Admin_status_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_client_dtls_pkey')
begin
	alter table engg_devcon_codegen_client_dtls drop constraint engg_devcon_codegen_client_dtls_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_client_metadata_pkey')
begin
	alter table engg_devcon_codegen_client_metadata drop constraint engg_devcon_codegen_client_metadata_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_mail_dtls_pkey')
begin
	alter table engg_devcon_codegen_mail_dtls drop constraint engg_devcon_codegen_mail_dtls_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_mail_dtls_his_pkey')
begin
	alter table engg_devcon_codegen_mail_dtls_his drop constraint engg_devcon_codegen_mail_dtls_his_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_mail_metadata_pkey')
begin
	alter table engg_devcon_codegen_mail_metadata drop constraint engg_devcon_codegen_mail_metadata_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_options_lang_his_pkey')
begin
	alter table engg_devcon_codegen_options_lang_his drop constraint engg_devcon_codegen_options_lang_his_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_options_metadata_pkey')
begin
	alter table engg_devcon_codegen_options_metadata drop constraint engg_devcon_codegen_options_metadata_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_schedule_dtls_pkey')
begin
	alter table engg_devcon_codegen_schedule_dtls drop constraint engg_devcon_codegen_schedule_dtls_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_schedule_dtls_his_pkey')
begin
	alter table engg_devcon_codegen_schedule_dtls_his drop constraint engg_devcon_codegen_schedule_dtls_his_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_status_dtls_pkey')
begin
	alter table engg_devcon_codegen_status_dtls drop constraint engg_devcon_codegen_status_dtls_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_codegen_status_dtls_his_pkey')
begin
	alter table engg_devcon_codegen_status_dtls_his drop constraint engg_devcon_codegen_status_dtls_his_pkey
end

if exists(select 'x' from sysobjects where name = 'Engg_devcon_doccmp_splist_unq_idx_pkey')
begin
	alter table Engg_devcon_doccmp_splist drop constraint Engg_devcon_doccmp_splist_unq_idx_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_devcon_querylist_pkey')
begin
	alter table engg_devcon_querylist drop constraint engg_devcon_querylist_pkey
end

if exists(select 'x' from sysobjects where name = 'devconversionPK')
begin
	alter table engg_developerconsole_version drop constraint devconversionPK
end

if exists(select 'x' from sysobjects where name = 'component_abbr_len')
begin
	alter table engg_edk_components drop constraint component_abbr_len
end

if exists(select 'x' from sysobjects where name = 'engg_edk_components_pkey')
begin
	alter table engg_edk_components drop constraint engg_edk_components_pkey
end

if exists(select 'x' from sysobjects where name = 'process_abbr_len')
begin
	alter table engg_edk_components drop constraint process_abbr_len
end

if exists(select 'x' from sysobjects where name = 'engg_gendeliv_reportconfig_unq_idx_pkey')
begin
	alter table engg_gendeliv_reportconfig drop constraint engg_gendeliv_reportconfig_unq_idx_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_203exp_status_trg_pkey')
begin
	alter table engg_mr_203exp_status_trg drop constraint engg_mr_203exp_status_trg_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_activity_mst_203_1_pkey')
begin
	alter table engg_mr_activity_mst_203_1 drop constraint engg_mr_activity_mst_203_1_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_comp_mst_203_1_pkey')
begin
	alter table engg_mr_comp_mst_203_1 drop constraint engg_mr_comp_mst_203_1_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_mig_chronicle_203_1_pkey')
begin
	alter table engg_mr_mig_chronicle_203_1 drop constraint engg_mr_mig_chronicle_203_1_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_mig_service_map_pkey')
begin
	alter table Engg_mr_mig_service_map drop constraint engg_mr_mig_service_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Engg_mr_mig_status_203_1_pkey')
begin
	alter table Engg_mr_mig_status_203_1 drop constraint Engg_mr_mig_status_203_1_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_process_mst_203_1_pkey')
begin
	alter table engg_mr_process_mst_203_1 drop constraint engg_mr_process_mst_203_1_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_mr_ui_mst_203_1_pk')
begin
	alter table engg_mr_ui_mst_203_1 drop constraint engg_mr_ui_mst_203_1_pk
end

if exists(select 'x' from sysobjects where name = 'engg_mr_ui_mst_203_1_src_pk')
begin
	alter table engg_mr_ui_mst_203_1_src drop constraint engg_mr_ui_mst_203_1_src_pk
end

if exists(select 'x' from sysobjects where name = 'engg_offline_activity_pk')
begin
	alter table engg_offline_activity drop constraint engg_offline_activity_pk
end

if exists(select 'x' from sysobjects where name = 'engg_offline_bp_pk')
begin
	alter table engg_offline_bp drop constraint engg_offline_bp_pk
end

if exists(select 'x' from sysobjects where name = 'engg_offline_function_pk')
begin
	alter table engg_offline_function drop constraint engg_offline_function_pk
end

if exists(select 'x' from sysobjects where name = 'engg_offline_ui_pk')
begin
	alter table engg_offline_ui drop constraint engg_offline_ui_pk
end

if exists(select 'x' from sysobjects where name = 'engg_previewmaintenance_log_PKey')
begin
	alter table engg_previewmaintenance_log drop constraint engg_previewmaintenance_log_PKey
end

if exists(select 'x' from sysobjects where name = 'engg_rdc_link_offset_prkey')
begin
	alter table engg_rdc_link_offset drop constraint engg_rdc_link_offset_prkey
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_codegen')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_codegen
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_ctrlc')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_ctrlc
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_de')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_de
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_ecr')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_ecr
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_link')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_link
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_proto')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_proto
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_prvw')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_prvw
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_chk_rcn')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_chk_rcn
end

if exists(select 'x' from sysobjects where name = 'engg_Revmig_status_pkey')
begin
	alter table engg_Revmig_status drop constraint engg_Revmig_status_pkey
end

if exists(select 'x' from sysobjects where name = 'engg_task_mapping_pr_key')
begin
	alter table engg_task_mapping drop constraint engg_task_mapping_pr_key
end

if exists(select 'x' from sysobjects where name = 'ep_action_mst_fkey_ep_ui_mst')
begin
	alter table ep_action_mst drop constraint ep_action_mst_fkey_ep_ui_mst
end

if exists(select 'x' from sysobjects where name = 'ep_action_mst_pkey')
begin
	alter table ep_action_mst drop constraint ep_action_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_action_mst_lng_extn_fkey_ep_ui_mst')
begin
	alter table ep_action_mst_lng_extn drop constraint ep_action_mst_lng_extn_fkey_ep_ui_mst
end

if exists(select 'x' from sysobjects where name = 'ep_action_mst_lng_extn_pkey')
begin
	alter table ep_action_mst_lng_extn drop constraint ep_action_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_action_section_map_pkey')
begin
	alter table ep_action_section_map drop constraint ep_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_attachdocument_dtl_pk')
begin
	alter table ep_attachdocument_dtl drop constraint ep_attachdocument_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_Calendar_configure_pkey')
begin
	alter table ep_calendar_configure drop constraint ep_Calendar_configure_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_chart_header_pkey')
begin
	alter table ep_chart_header drop constraint ep_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_chart_sample_data_Fkey_ep_chart_header')
begin
	alter table ep_chart_sample_data drop constraint ep_chart_sample_data_Fkey_ep_chart_header
end

if exists(select 'x' from sysobjects where name = 'ep_chart_sample_data_pkey')
begin
	alter table ep_chart_sample_data drop constraint ep_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_chart_series_Fkey_ep_chart_header')
begin
	alter table ep_chart_series drop constraint ep_chart_series_Fkey_ep_chart_header
end

if exists(select 'x' from sysobjects where name = 'ep_chart_series_pkey')
begin
	alter table ep_chart_series drop constraint ep_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_data_type')
begin
	alter table ep_component_glossary_mst drop constraint Chk_ep_component_glossary_mst_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_length')
begin
	alter table ep_component_glossary_mst drop constraint Chk_ep_component_glossary_mst_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_req_no')
begin
	alter table ep_component_glossary_mst drop constraint Chk_ep_component_glossary_mst_req_no
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_synonym_status')
begin
	alter table ep_component_glossary_mst drop constraint Chk_ep_component_glossary_mst_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_component_glossary_mst_pkey')
begin
	alter table ep_component_glossary_mst drop constraint ep_component_glossary_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_lng_extn_data_type')
begin
	alter table ep_component_glossary_mst_lng_extn drop constraint Chk_ep_component_glossary_mst_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_lng_extn_length')
begin
	alter table ep_component_glossary_mst_lng_extn drop constraint Chk_ep_component_glossary_mst_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_component_glossary_mst_lng_extn_synonym_status')
begin
	alter table ep_component_glossary_mst_lng_extn drop constraint Chk_ep_component_glossary_mst_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_component_glossary_mst_lng_extn_pkey')
begin
	alter table ep_component_glossary_mst_lng_extn drop constraint ep_component_glossary_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_contextual_links_PK')
begin
	alter table ep_contextual_links drop constraint ep_contextual_links_PK
end

if exists(select 'x' from sysobjects where name = 'ep_control_extensions_PK')
begin
	alter table ep_control_extensions drop constraint ep_control_extensions_PK
end

if exists(select 'x' from sysobjects where name = 'ep_custom_listedit_PKey')
begin
	alter table ep_custom_listedit drop constraint ep_custom_listedit_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_date_highlight_column_PKey')
begin
	alter table ep_date_highlight_column drop constraint ep_date_highlight_column_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_date_highlight_control_map_PKey')
begin
	alter table ep_date_highlight_control_map drop constraint ep_date_highlight_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_deleted_task_dtl_pkey')
begin
	alter table ep_deleted_task_dtl drop constraint ep_deleted_task_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_device_quick_code_met_pk')
begin
	alter table ep_device_quick_code_met drop constraint ep_device_quick_code_met_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_enum_value_dtl_default_flag')
begin
	alter table ep_enum_value_dtl drop constraint Chk_ep_enum_value_dtl_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_enum_value_dtl_fkey_ep_ui_section_dtl')
begin
	alter table ep_enum_value_dtl drop constraint ep_enum_value_dtl_fkey_ep_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_enum_value_dtl_pkey')
begin
	alter table ep_enum_value_dtl drop constraint ep_enum_value_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_enum_value_dtl_lng_extn_default_flag')
begin
	alter table ep_enum_value_dtl_lng_extn drop constraint Chk_ep_enum_value_dtl_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_enum_value_dtl_lng_extn_fkey_ep_ui_section_dtl')
begin
	alter table ep_enum_value_dtl_lng_extn drop constraint ep_enum_value_dtl_lng_extn_fkey_ep_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_enum_value_dtl_lng_extn_pkey')
begin
	alter table ep_enum_value_dtl_lng_extn drop constraint ep_enum_value_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ext_js_control_dtl_PK')
begin
	alter table ep_ext_js_control_dtl drop constraint ep_ext_js_control_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_ext_js_section_column_dtl_PK')
begin
	alter table ep_ext_js_section_column_dtl drop constraint ep_ext_js_section_column_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_ext_js_section_dtl_PK')
begin
	alter table ep_ext_js_section_dtl drop constraint ep_ext_js_section_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_flowbr_mst_fkey_ep_action_mst')
begin
	alter table ep_flowbr_mst drop constraint ep_flowbr_mst_fkey_ep_action_mst
end

if exists(select 'x' from sysobjects where name = 'ep_flowbr_mst_pkey')
begin
	alter table ep_flowbr_mst drop constraint ep_flowbr_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_flowbr_mst_lng_extn_fkey_ep_action_mst')
begin
	alter table ep_flowbr_mst_lng_extn drop constraint ep_flowbr_mst_lng_extn_fkey_ep_action_mst
end

if exists(select 'x' from sysobjects where name = 'ep_flowbr_mst_lng_extn_pkey')
begin
	alter table ep_flowbr_mst_lng_extn drop constraint ep_flowbr_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_data_type')
begin
	alter table ep_glossary_mst drop constraint Chk_ep_glossary_mst_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_length')
begin
	alter table ep_glossary_mst drop constraint Chk_ep_glossary_mst_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_synonym_status')
begin
	alter table ep_glossary_mst drop constraint Chk_ep_glossary_mst_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_glossary_mst_fkey_ep_glossary_mst')
begin
	alter table ep_glossary_mst drop constraint ep_glossary_mst_fkey_ep_glossary_mst
end

if exists(select 'x' from sysobjects where name = 'ep_glossary_mst_pkey')
begin
	alter table ep_glossary_mst drop constraint ep_glossary_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_lng_extn_data_type')
begin
	alter table ep_glossary_mst_lng_extn drop constraint Chk_ep_glossary_mst_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_lng_extn_length')
begin
	alter table ep_glossary_mst_lng_extn drop constraint Chk_ep_glossary_mst_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_glossary_mst_lng_extn_synonym_status')
begin
	alter table ep_glossary_mst_lng_extn drop constraint Chk_ep_glossary_mst_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 'ep_glossary_mst_lng_extn_fkey_ep_glossary_mst')
begin
	alter table ep_glossary_mst_lng_extn drop constraint ep_glossary_mst_lng_extn_fkey_ep_glossary_mst
end

if exists(select 'x' from sysobjects where name = 'ep_glossary_mst_lng_extn_pkey')
begin
	alter table ep_glossary_mst_lng_extn drop constraint ep_glossary_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_language_met_pkey')
begin
	alter table ep_language_met drop constraint ep_language_met_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_layout_ezeeview_sp_PK')
begin
	alter table ep_layout_ezeeview_sp drop constraint ep_layout_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 'ep_layout_ezeeview_spparamlist_pk')
begin
	alter table ep_layout_ezeeview_spparamlist drop constraint ep_layout_ezeeview_spparamlist_pk
end

if exists(select 'x' from sysobjects where name = 'ep_listedit_column_dtl_PKey')
begin
	alter table ep_listedit_column_dtl drop constraint ep_listedit_column_dtl_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_listedit_control_map_PKey')
begin
	alter table ep_listedit_control_map drop constraint ep_listedit_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_nativeapp_mapping_PK')
begin
	alter table ep_nativeapp_mapping drop constraint ep_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 'ep_new_ui_mst_pkey')
begin
	alter table ep_new_ui_mst drop constraint ep_new_ui_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_column_group_mapping_pkey')
begin
	alter table ep_phone_column_group_mapping drop constraint ep_phone_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_columngroup_pkey')
begin
	alter table ep_phone_columngroup drop constraint ep_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_control_dtl_fkey_ep_phone_section_dtl')
begin
	alter table ep_phone_control_dtl drop constraint ep_phone_control_dtl_fkey_ep_phone_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_phone_control_dtl_pkey')
begin
	alter table ep_phone_control_dtl drop constraint ep_phone_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_grid_columngroup_pkey')
begin
	alter table ep_phone_grid_columngroup drop constraint ep_phone_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_grid_dtl_fkey_ep_phone_control_dtl')
begin
	alter table ep_phone_grid_dtl drop constraint ep_phone_grid_dtl_fkey_ep_phone_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_phone_grid_dtl_pkey')
begin
	alter table ep_phone_grid_dtl drop constraint ep_phone_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_mst_pkey')
begin
	alter table ep_phone_mst drop constraint ep_phone_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_page_dtl_fkey_ep_phone_mst')
begin
	alter table ep_phone_page_dtl drop constraint ep_phone_page_dtl_fkey_ep_phone_mst
end

if exists(select 'x' from sysobjects where name = 'ep_phone_page_dtl_pkey')
begin
	alter table ep_phone_page_dtl drop constraint ep_phone_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_phone_section_dtl_fkey_ep_phone_page_dtl')
begin
	alter table ep_phone_section_dtl drop constraint ep_phone_section_dtl_fkey_ep_phone_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_phone_section_dtl_pkey')
begin
	alter table ep_phone_section_dtl drop constraint ep_phone_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_pivot_configure_pkey')
begin
	alter table ep_pivot_configure drop constraint ep_pivot_configure_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_pivot_fields_pkey')
begin
	alter table ep_pivot_fields drop constraint ep_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_pivot_lang_extn_pkey')
begin
	alter table ep_pivot_lang_extn drop constraint ep_pivot_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_quick_code_mst_pkey')
begin
	alter table ep_quick_code_mst drop constraint ep_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_quick_code_mst_lng_extn_pkey')
begin
	alter table ep_quick_code_mst_lng_extn drop constraint ep_quick_code_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_radio_button_dtl_default_flag')
begin
	alter table ep_radio_button_dtl drop constraint Chk_ep_radio_button_dtl_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_radio_button_dtl_fkey_ep_ui_control_dtl')
begin
	alter table ep_radio_button_dtl drop constraint ep_radio_button_dtl_fkey_ep_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_radio_button_dtl_pkey')
begin
	alter table ep_radio_button_dtl drop constraint ep_radio_button_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_radio_button_dtl_lng_extn_default_flag')
begin
	alter table ep_radio_button_dtl_lng_extn drop constraint Chk_ep_radio_button_dtl_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 'ep_radio_button_dtl_lng_extn_fkey_ep_ui_control_dtl')
begin
	alter table ep_radio_button_dtl_lng_extn drop constraint ep_radio_button_dtl_lng_extn_fkey_ep_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_radio_button_dtl_lng_extn_pkey')
begin
	alter table ep_radio_button_dtl_lng_extn drop constraint ep_radio_button_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_resolvelist_data_map_PKey')
begin
	alter table ep_resolvelist_data_map drop constraint ep_resolvelist_data_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_review_pkey')
begin
	alter table ep_review drop constraint ep_review_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_review_dtl_pkey')
begin
	alter table ep_review_dtl drop constraint ep_review_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_review_type_pkey')
begin
	alter table ep_review_type drop constraint ep_review_type_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_sync_view_pkey')
begin
	alter table ep_sync_view drop constraint ep_sync_view_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_column_group_mapping_pkey')
begin
	alter table ep_tablet_column_group_mapping drop constraint ep_tablet_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_columngroup_pkey')
begin
	alter table ep_tablet_columngroup drop constraint ep_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_control_dtl_fkey_ep_tablet_section_dtl')
begin
	alter table ep_tablet_control_dtl drop constraint ep_tablet_control_dtl_fkey_ep_tablet_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_control_dtl_pkey')
begin
	alter table ep_tablet_control_dtl drop constraint ep_tablet_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_grid_columngroup_pkey')
begin
	alter table ep_tablet_grid_columngroup drop constraint ep_tablet_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_grid_dtl_fkey_ep_tablet_control_dtl')
begin
	alter table ep_tablet_grid_dtl drop constraint ep_tablet_grid_dtl_fkey_ep_tablet_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_grid_dtl_pkey')
begin
	alter table ep_tablet_grid_dtl drop constraint ep_tablet_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_mst_pkey')
begin
	alter table ep_tablet_mst drop constraint ep_tablet_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_page_dtl_fkey_ep_tablet_mst')
begin
	alter table ep_tablet_page_dtl drop constraint ep_tablet_page_dtl_fkey_ep_tablet_mst
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_page_dtl_pkey')
begin
	alter table ep_tablet_page_dtl drop constraint ep_tablet_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_section_dtl_fkey_ep_tablet_page_dtl')
begin
	alter table ep_tablet_section_dtl drop constraint ep_tablet_section_dtl_fkey_ep_tablet_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_tablet_section_dtl_pkey')
begin
	alter table ep_tablet_section_dtl drop constraint ep_tablet_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_Templates_pk')
begin
	alter table ep_Templates drop constraint ep_Templates_pk
end

if exists(select 'x' from sysobjects where name = 'ep_tree_dtl_pkey')
begin
	alter table ep_tree_dtl drop constraint ep_tree_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tree_sample_data_pkey')
begin
	alter table ep_tree_sample_data drop constraint ep_tree_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tree_sample_data_bkupuiocx_pkey')
begin
	alter table ep_tree_sample_Data_bkupuiocx drop constraint ep_tree_sample_data_bkupuiocx_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tree_sample_data_map_fkey_ep_tree_sample_data')
begin
	alter table ep_tree_sample_data_map drop constraint ep_tree_sample_data_map_fkey_ep_tree_sample_data
end

if exists(select 'x' from sysobjects where name = 'ep_tree_sample_data_map_pkey')
begin
	alter table ep_tree_sample_data_map drop constraint ep_tree_sample_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_tree_sample_data_map_bkupuiocx_pkey')
begin
	alter table ep_tree_sample_Data_map_bkupuiocx drop constraint ep_tree_sample_data_map_bkupuiocx_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_column_group_mapping_pkey')
begin
	alter table ep_ui_column_group_mapping drop constraint ep_ui_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_columngroup_pkey')
begin
	alter table ep_ui_columngroup drop constraint ep_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_combolink_dtl_pkey')
begin
	alter table ep_ui_combolink_dtl drop constraint ep_ui_combolink_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_contextmenu_task_dtl_pk')
begin
	alter table ep_ui_contextmenu_task_dtl drop constraint ep_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_control_del_dtl_pk')
begin
	alter table ep_ui_control_del_dtl drop constraint ep_ui_control_del_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_control_dtl_fkey_ep_ui_section_dtl')
begin
	alter table ep_ui_control_dtl drop constraint ep_ui_control_dtl_fkey_ep_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_control_dtl_pkey')
begin
	alter table ep_ui_control_dtl drop constraint ep_ui_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_control_dtl_lng_extn_fkey_ep_ui_section_dtl')
begin
	alter table ep_ui_control_dtl_lng_extn drop constraint ep_ui_control_dtl_lng_extn_fkey_ep_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_control_dtl_lng_extn_pkey')
begin
	alter table ep_ui_control_dtl_lng_extn drop constraint ep_ui_control_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Ep_ui_control_properties_pkey')
begin
	alter table Ep_ui_control_properties drop constraint Ep_ui_control_properties_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_control_dtl_pkey')
begin
	alter table ep_ui_device_control_dtl drop constraint ep_ui_device_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_dtl_pkey')
begin
	alter table ep_ui_device_dtl drop constraint ep_ui_device_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_grid_dtl_fkey_ep_ui_grid_dtl')
begin
	alter table ep_ui_device_grid_dtl drop constraint ep_ui_device_grid_dtl_fkey_ep_ui_grid_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_grid_dtl_pkey')
begin
	alter table ep_ui_device_grid_dtl drop constraint ep_ui_device_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_page_dtl_fkey_ep_ui_page_dtl')
begin
	alter table ep_ui_device_page_dtl drop constraint ep_ui_device_page_dtl_fkey_ep_ui_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_page_dtl_pkey')
begin
	alter table ep_ui_device_page_dtl drop constraint ep_ui_device_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_device_section_dtl_pkey')
begin
	alter table ep_ui_device_section_dtl drop constraint ep_ui_device_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_displaytext_lang_extn_PKey')
begin
	alter table ep_ui_displaytext_lang_extn drop constraint ep_ui_displaytext_lang_extn_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_grid_columngroup_pkey')
begin
	alter table ep_ui_grid_columngroup drop constraint ep_ui_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_grid_dtl_fkey_ep_ui_control_dtl')
begin
	alter table ep_ui_grid_dtl drop constraint ep_ui_grid_dtl_fkey_ep_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_grid_dtl_pkey')
begin
	alter table ep_ui_grid_dtl drop constraint ep_ui_grid_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_grid_dtl_lng_extn_fkey_ep_ui_control_dtl')
begin
	alter table ep_ui_grid_dtl_lng_extn drop constraint ep_ui_grid_dtl_lng_extn_fkey_ep_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_grid_dtl_lng_extn_pkey')
begin
	alter table ep_ui_grid_dtl_lng_extn drop constraint ep_ui_grid_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_caption_alignment')
begin
	alter table ep_ui_mst drop constraint Chk_ep_ui_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_trail_bar')
begin
	alter table ep_ui_mst drop constraint Chk_ep_ui_mst_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_ui_format')
begin
	alter table ep_ui_mst drop constraint Chk_ep_ui_mst_ui_format
end

if exists(select 'x' from sysobjects where name = 'ep_ui_mst_pkey')
begin
	alter table ep_ui_mst drop constraint ep_ui_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_lng_extn_caption_alignment')
begin
	alter table ep_ui_mst_lng_extn drop constraint Chk_ep_ui_mst_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_lng_extn_trail_bar')
begin
	alter table ep_ui_mst_lng_extn drop constraint Chk_ep_ui_mst_lng_extn_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_mst_lng_extn_ui_format')
begin
	alter table ep_ui_mst_lng_extn drop constraint Chk_ep_ui_mst_lng_extn_ui_format
end

if exists(select 'x' from sysobjects where name = 'ep_ui_mst_lng_extn_pkey')
begin
	alter table ep_ui_mst_lng_extn drop constraint ep_ui_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_page_dtl_fkey_ep_ui_mst')
begin
	alter table ep_ui_page_dtl drop constraint ep_ui_page_dtl_fkey_ep_ui_mst
end

if exists(select 'x' from sysobjects where name = 'ep_ui_page_dtl_pkey')
begin
	alter table ep_ui_page_dtl drop constraint ep_ui_page_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_page_dtl_lng_extn_fkey_ep_ui_mst')
begin
	alter table ep_ui_page_dtl_lng_extn drop constraint ep_ui_page_dtl_lng_extn_fkey_ep_ui_mst
end

if exists(select 'x' from sysobjects where name = 'ep_ui_page_dtl_lng_extn_pkey')
begin
	alter table ep_ui_page_dtl_lng_extn drop constraint ep_ui_page_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_pageevents_dtl_pk')
begin
	alter table ep_ui_pageevents_dtl drop constraint ep_ui_pageevents_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_placeholder_dtl_lng_extn_pk')
begin
	alter table ep_ui_placeholder_dtl_lng_extn drop constraint ep_ui_placeholder_dtl_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_req_dtl_pkey')
begin
	alter table ep_ui_req_dtl drop constraint ep_ui_req_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_req_dtl_lng_extn_fkey_ep_ui_mst')
begin
	alter table ep_ui_req_dtl_lng_extn drop constraint ep_ui_req_dtl_lng_extn_fkey_ep_ui_mst
end

if exists(select 'x' from sysobjects where name = 'ep_ui_req_dtl_lng_extn_pkey')
begin
	alter table ep_ui_req_dtl_lng_extn drop constraint ep_ui_req_dtl_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_section_control_map_dtl_pkey')
begin
	alter table ep_ui_section_control_map_dtl drop constraint ep_ui_section_control_map_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_border_required')
begin
	alter table ep_ui_section_dtl drop constraint Chk_ep_ui_section_dtl_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_title_alignment')
begin
	alter table ep_ui_section_dtl drop constraint Chk_ep_ui_section_dtl_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_title_required')
begin
	alter table ep_ui_section_dtl drop constraint Chk_ep_ui_section_dtl_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_visisble_flag')
begin
	alter table ep_ui_section_dtl drop constraint Chk_ep_ui_section_dtl_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'ep_ui_section_dtl_fkey_ep_ui_page_dtl')
begin
	alter table ep_ui_section_dtl drop constraint ep_ui_section_dtl_fkey_ep_ui_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_section_dtl_pkey')
begin
	alter table ep_ui_section_dtl drop constraint ep_ui_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_lng_extn_border_required')
begin
	alter table ep_ui_section_dtl_lng_extn drop constraint Chk_ep_ui_section_dtl_lng_extn_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_lng_extn_title_alignment')
begin
	alter table ep_ui_section_dtl_lng_extn drop constraint Chk_ep_ui_section_dtl_lng_extn_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_lng_extn_title_required')
begin
	alter table ep_ui_section_dtl_lng_extn drop constraint Chk_ep_ui_section_dtl_lng_extn_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_section_dtl_lng_extn_visisble_flag')
begin
	alter table ep_ui_section_dtl_lng_extn drop constraint Chk_ep_ui_section_dtl_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'ep_ui_section_dtl_lng_extn_fkey_ep_ui_page_dtl')
begin
	alter table ep_ui_section_dtl_lng_extn drop constraint ep_ui_section_dtl_lng_extn_fkey_ep_ui_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_column_dtl_fkey_ep_ui_grid_dtl')
begin
	alter table ep_ui_state_column_dtl drop constraint ep_ui_state_column_dtl_fkey_ep_ui_grid_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_column_dtl_PK')
begin
	alter table ep_ui_state_column_dtl drop constraint ep_ui_state_column_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_control_dtl_Fkey_ep_ui_control_dtl')
begin
	alter table ep_ui_state_control_dtl drop constraint ep_ui_state_control_dtl_Fkey_ep_ui_control_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_control_dtl_pkey')
begin
	alter table ep_ui_state_control_dtl drop constraint ep_ui_state_control_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_dtl_pkey')
begin
	alter table ep_ui_state_dtl drop constraint ep_ui_state_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_page_dtl_fkey_ep_ui_page_dtl')
begin
	alter table ep_ui_state_page_dtl drop constraint ep_ui_state_page_dtl_fkey_ep_ui_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_page_dtl_PK')
begin
	alter table ep_ui_state_page_dtl drop constraint ep_ui_state_page_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_section_dtl_Fkey_ep_ui_section_dtl')
begin
	alter table ep_ui_state_section_dtl drop constraint ep_ui_state_section_dtl_Fkey_ep_ui_section_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_section_dtl_pkey')
begin
	alter table ep_ui_state_section_dtl drop constraint ep_ui_state_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_task_dtl_pkey')
begin
	alter table ep_ui_state_task_dtl drop constraint ep_ui_state_task_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_state_task_mst_pkey')
begin
	alter table ep_ui_state_task_mst drop constraint ep_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_Temp_placeholders_pk')
begin
	alter table ep_ui_Temp_placeholders drop constraint ep_ui_Temp_placeholders_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_template_controlmap_pk')
begin
	alter table ep_ui_template_controlmap drop constraint ep_ui_template_controlmap_pk
end

if exists(select 'x' from sysobjects where name = 'ep_ui_toolbar_dtl_PKey')
begin
	alter table ep_ui_toolbar_dtl drop constraint ep_ui_toolbar_dtl_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_toolbar_group_dtl_PKey')
begin
	alter table ep_ui_toolbar_group_dtl drop constraint ep_ui_toolbar_group_dtl_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_toolbar_mapping_dtl_PKey')
begin
	alter table ep_ui_toolbar_mapping_dtl drop constraint ep_ui_toolbar_mapping_dtl_PKey
end

if exists(select 'x' from sysobjects where name = 'ep_ui_tooltip_dtl_lng_extn_pk')
begin
	alter table ep_ui_tooltip_dtl_lng_extn drop constraint ep_ui_tooltip_dtl_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_ep_ui_traversal_dtl_link_type')
begin
	alter table ep_ui_traversal_dtl drop constraint Chk_ep_ui_traversal_dtl_link_type
end

if exists(select 'x' from sysobjects where name = 'ep_ui_traversal_dtl_fkey_ep_ui_page_dtl')
begin
	alter table ep_ui_traversal_dtl drop constraint ep_ui_traversal_dtl_fkey_ep_ui_page_dtl
end

if exists(select 'x' from sysobjects where name = 'ep_ui_traversal_dtl_pkey')
begin
	alter table ep_ui_traversal_dtl drop constraint ep_ui_traversal_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ep_user_section_dtl_pkey')
begin
	alter table ep_user_section_dtl drop constraint ep_user_section_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'es_business_term_pkey')
begin
	alter table es_business_term drop constraint es_business_term_pkey
end

if exists(select 'x' from sysobjects where name = 'es_business_term_lng_extn_pkey')
begin
	alter table es_business_term_lng_extn drop constraint es_business_term_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_CodeGen_Used_PK')
begin
	alter table es_CodeGen_Used drop constraint es_CodeGen_Used_PK
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_caption_alignment')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_caption_position')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_caption_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_caption_wrap')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_ctrl_position')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_delete_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_editable_flag')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_ellipses_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_event_handling_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_help_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_insert_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_password_char')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_select_flag')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_visisble_flag')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_zoom_req')
begin
	alter table es_comp_ctrl_type_mst drop constraint Chk_es_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_comp_ctrl_type_mst_pkey')
begin
	alter table es_comp_ctrl_type_mst drop constraint es_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_comp_ctrl_type_mst_extn_pkey')
begin
	alter table es_comp_ctrl_type_mst_extn drop constraint es_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_caption_alignment')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_caption_position')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_caption_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_caption_wrap')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_delete_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_editable_flag')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_ellipses_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_event_handling_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_help_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_insert_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_mandatory_flag')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_select_flag')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_visisble_flag')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_ctrl_type_mst_lng_extn_zoom_req')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint Chk_es_comp_ctrl_type_mst_lng_extn_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_comp_ctrl_type_mst_lng_extn_pkey')
begin
	alter table es_comp_ctrl_type_mst_lng_extn drop constraint es_comp_ctrl_type_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_hdn_ctrl_dtl_allow_deletion')
begin
	alter table es_comp_hdn_ctrl_dtl drop constraint Chk_es_comp_hdn_ctrl_dtl_allow_deletion
end

if exists(select 'x' from sysobjects where name = 'es_comp_hdn_ctrl_dtl_pkey')
begin
	alter table es_comp_hdn_ctrl_dtl drop constraint es_comp_hdn_ctrl_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'es_comp_param_mst_pkey')
begin
	alter table es_comp_param_mst drop constraint es_comp_param_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_comp_param_mst_lng_extn_pkey')
begin
	alter table es_comp_param_mst_lng_extn drop constraint es_comp_param_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_comp_stat_ctrl_type_mst_pkey')
begin
	alter table es_comp_stat_ctrl_type_mst drop constraint es_comp_stat_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_comp_stylesheet_pkey')
begin
	alter table es_comp_stylesheet drop constraint es_comp_stylesheet_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_clr_on_page_save')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_cond_ml_fetch')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_data_save_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_default_for')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_err_handle_method')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_hdr_check_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_hdr_fetch_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_hdr_ref_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_incl_place_holder')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_ml_fet_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_print_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_proc_sel_rows')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_refresh_on_save')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_task_confirmation')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_trn_scope_req')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_usr_role_map')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_valid_on_init')
begin
	alter table es_comp_task_type_mst drop constraint Chk_es_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_comp_task_type_mst_pkey')
begin
	alter table es_comp_task_type_mst drop constraint es_comp_task_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_clr_on_page_save')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_cond_ml_fetch')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_default_for')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_err_handle_method')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_hdr_check_req')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_hdr_fetch_req')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_hdr_ref_req')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_incl_place_holder')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_ml_fet_req')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_proc_sel_rows')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_refresh_on_save')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_task_confirmation')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_trn_scope_req')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_usr_role_map')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_comp_task_type_mst_lng_extn_valid_on_init')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint Chk_es_comp_task_type_mst_lng_extn_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_comp_task_type_mst_lng_extn_pkey')
begin
	alter table es_comp_task_type_mst_lng_extn drop constraint es_comp_task_type_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_events_met_pkey')
begin
	alter table es_ctrl_type_events_met drop constraint es_ctrl_type_events_met_pkey
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_events_mst_pkey')
begin
	alter table es_ctrl_type_events_mst drop constraint es_ctrl_type_events_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_caption_position')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_caption_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_caption_wrap')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_ctrl_position')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_delete_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_editable_flag')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_ellipses_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_event_handling_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_help_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_insert_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_mandatory_flag')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_password_char')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_select_flag')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_visisble_flag')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_zoom_req')
begin
	alter table es_ctrl_type_met drop constraint Chk_es_ctrl_type_met_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_met_pkey')
begin
	alter table es_ctrl_type_met drop constraint es_ctrl_type_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_caption_alignment')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_caption_position')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_caption_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_caption_wrap')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_delete_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_editable_flag')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_ellipses_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_event_handling_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_help_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_insert_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_mandatory_flag')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_select_flag')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_visisble_flag')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_met_lng_extn_zoom_req')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint Chk_es_ctrl_type_met_lng_extn_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_met_lng_extn_pkey')
begin
	alter table es_ctrl_type_met_lng_extn drop constraint es_ctrl_type_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_caption_alignment')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_caption_position')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_caption_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_caption_wrap')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_ctrl_position')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_delete_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_editable_flag')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_ellipses_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_event_handling_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_help_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_insert_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_mandatory_flag')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_password_char')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_select_flag')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_visisble_flag')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_zoom_req')
begin
	alter table es_ctrl_type_mst drop constraint Chk_es_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_mst_pkey')
begin
	alter table es_ctrl_type_mst drop constraint es_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_mst_extn_pkey')
begin
	alter table es_ctrl_type_mst_extn drop constraint es_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_caption_alignment')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_caption_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_caption_wrap')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_delete_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_editable_flag')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_ellipses_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_event_handling_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_help_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_insert_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_mandatory_flag')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_select_flag')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_visisble_flag')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_es_ctrl_type_mst_lng_extn_zoom_req')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint Chk_es_ctrl_type_mst_lng_extn_zoom_req
end

if exists(select 'x' from sysobjects where name = 'es_ctrl_type_mst_lng_extn_pkey')
begin
	alter table es_ctrl_type_mst_lng_extn drop constraint es_ctrl_type_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_Feature_Available_PK')
begin
	alter table es_Feature_Available drop constraint es_Feature_Available_PK
end

if exists(select 'x' from sysobjects where name = 'es_language_met_pkey')
begin
	alter table es_language_met drop constraint es_language_met_pkey
end

if exists(select 'x' from sysobjects where name = 'es_param_met_pkey')
begin
	alter table es_param_met drop constraint es_param_met_pkey
end

if exists(select 'x' from sysobjects where name = 'es_param_met_lng_extn_pkey')
begin
	alter table es_param_met_lng_extn drop constraint es_param_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_proj_hdn_ctrl_dtl_allow_deletion')
begin
	alter table es_proj_hdn_ctrl_dtl drop constraint Chk_es_proj_hdn_ctrl_dtl_allow_deletion
end

if exists(select 'x' from sysobjects where name = 'es_proj_hdn_ctrl_dtl_pkey')
begin
	alter table es_proj_hdn_ctrl_dtl drop constraint es_proj_hdn_ctrl_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'es_project_param_mst_pkey')
begin
	alter table es_project_param_mst drop constraint es_project_param_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_project_param_mst_lng_extn_pkey')
begin
	alter table es_project_param_mst_lng_extn drop constraint es_project_param_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_project_stylesheet_pkey')
begin
	alter table es_project_stylesheet drop constraint es_project_stylesheet_pkey
end

if exists(select 'x' from sysobjects where name = 'es_pt_mst_pkey')
begin
	alter table es_pt_mst drop constraint es_pt_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_quick_code_mst_pkey')
begin
	alter table es_quick_code_mst drop constraint es_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_review_pkey')
begin
	alter table es_review drop constraint es_review_pkey
end

if exists(select 'x' from sysobjects where name = 'es_review_dtl_pkey')
begin
	alter table es_review_dtl drop constraint es_review_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'es_review_type_pkey')
begin
	alter table es_review_type drop constraint es_review_type_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_clr_on_page_save')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_cond_ml_fetch')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_data_save_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_err_handle_method')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_hdr_check_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_hdr_fetch_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_hdr_ref_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_incl_place_holder')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_ml_fet_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_print_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_proc_sel_rows')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_refresh_on_save')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_task_confirmation')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_trn_scope_req')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_usr_role_map')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_valid_on_init')
begin
	alter table es_task_type_met drop constraint Chk_es_task_type_met_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_task_type_met_pkey')
begin
	alter table es_task_type_met drop constraint es_task_type_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_clr_on_page_save')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_cond_ml_fetch')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_default_for')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_err_handle_method')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_hdr_check_req')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_hdr_fetch_req')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_hdr_ref_req')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_incl_place_holder')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_ml_fet_req')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_proc_sel_rows')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_refresh_on_save')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_task_confirmation')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_trn_scope_req')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_usr_role_map')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_lng_extn_valid_on_init')
begin
	alter table es_task_type_met_lng_extn drop constraint Chk_es_task_type_met_lng_extn_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_task_type_met_lng_extn_pkey')
begin
	alter table es_task_type_met_lng_extn drop constraint es_task_type_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_met_default_for')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_met_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_clr_on_page_save')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_cond_ml_fetch')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_data_save_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_default_for')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_err_handle_method')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_hdr_check_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_hdr_fetch_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_hdr_ref_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_incl_place_holder')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_ml_fet_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_print_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_proc_sel_rows')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_refresh_on_save')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_task_confirmation')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_trn_scope_req')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_usr_role_map')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_valid_on_init')
begin
	alter table es_task_type_mst drop constraint Chk_es_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_task_type_mst_pkey')
begin
	alter table es_task_type_mst drop constraint es_task_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_clr_on_page_save')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_cond_ml_fetch')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_default_for')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_err_handle_method')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_hdr_check_req')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_hdr_fetch_req')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_hdr_ref_req')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_incl_place_holder')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_ml_fet_req')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_proc_sel_rows')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_refresh_on_save')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_task_confirmation')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_trn_scope_req')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_usr_role_map')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_es_task_type_mst_lng_extn_valid_on_init')
begin
	alter table es_task_type_mst_lng_extn drop constraint Chk_es_task_type_mst_lng_extn_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'es_task_type_mst_lng_extn_pkey')
begin
	alter table es_task_type_mst_lng_extn drop constraint es_task_type_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'es_template_mst_pkey')
begin
	alter table es_template_mst drop constraint es_template_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'es_ui_Reference_dtl_pkey')
begin
	alter table es_ui_Reference_dtl drop constraint es_ui_Reference_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'es_ui_Reference_usage_dtl_pkey')
begin
	alter table es_ui_Reference_usage_dtl drop constraint es_ui_Reference_usage_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_activity_change_type')
begin
	alter table est_activity drop constraint Chk_est_activity_change_type
end

if exists(select 'x' from sysobjects where name = 'Chk_est_activity_doc_type')
begin
	alter table est_activity drop constraint Chk_est_activity_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_activity_fkey_est_component')
begin
	alter table est_activity drop constraint est_activity_fkey_est_component
end

if exists(select 'x' from sysobjects where name = 'est_activity_pkey')
begin
	alter table est_activity drop constraint est_activity_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_activity_band_doc_type')
begin
	alter table est_activity_band drop constraint Chk_est_activity_band_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_activity_band_fkey_est_activity')
begin
	alter table est_activity_band drop constraint est_activity_band_fkey_est_activity
end

if exists(select 'x' from sysobjects where name = 'est_activity_band_pkey')
begin
	alter table est_activity_band drop constraint est_activity_band_pkey
end

if exists(select 'x' from sysobjects where name = 'est_activity_met_pkey')
begin
	alter table est_activity_met drop constraint est_activity_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_band_doc_type')
begin
	alter table est_band drop constraint Chk_est_band_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_band_fkey_est_estimate')
begin
	alter table est_band drop constraint est_band_fkey_est_estimate
end

if exists(select 'x' from sysobjects where name = 'est_band_pkey')
begin
	alter table est_band drop constraint est_band_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_est_band_matrix')
begin
	alter table est_band_matrix drop constraint PK_est_band_matrix
end

if exists(select 'x' from sysobjects where name = 'est_band_met_pkey')
begin
	alter table est_band_met drop constraint est_band_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_bo_change_type')
begin
	alter table est_bo drop constraint Chk_est_bo_change_type
end

if exists(select 'x' from sysobjects where name = 'Chk_est_bo_doc_type')
begin
	alter table est_bo drop constraint Chk_est_bo_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_bo_fkey_est_component')
begin
	alter table est_bo drop constraint est_bo_fkey_est_component
end

if exists(select 'x' from sysobjects where name = 'est_bo_pkey')
begin
	alter table est_bo drop constraint est_bo_pkey
end

if exists(select 'x' from sysobjects where name = 'est_bo_met_pkey')
begin
	alter table est_bo_met drop constraint est_bo_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_component_change_type')
begin
	alter table est_component drop constraint Chk_est_component_change_type
end

if exists(select 'x' from sysobjects where name = 'Chk_est_component_doc_type')
begin
	alter table est_component drop constraint Chk_est_component_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_component_fkey_est_estimate')
begin
	alter table est_component drop constraint est_component_fkey_est_estimate
end

if exists(select 'x' from sysobjects where name = 'est_component_pkey')
begin
	alter table est_component drop constraint est_component_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_component_band_doc_type')
begin
	alter table est_component_band drop constraint Chk_est_component_band_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_component_band_fkey_est_component')
begin
	alter table est_component_band drop constraint est_component_band_fkey_est_component
end

if exists(select 'x' from sysobjects where name = 'est_component_band_pkey')
begin
	alter table est_component_band drop constraint est_component_band_pkey
end

if exists(select 'x' from sysobjects where name = 'est_component_met_pkey')
begin
	alter table est_component_met drop constraint est_component_met_pkey
end

if exists(select 'x' from sysobjects where name = 'est_dfp_count_dtl_fkey_est_fpcal_comp_dtl')
begin
	alter table est_dfp_count_dtl drop constraint est_dfp_count_dtl_fkey_est_fpcal_comp_dtl
end

if exists(select 'x' from sysobjects where name = 'est_dfp_count_dtl_pk')
begin
	alter table est_dfp_count_dtl drop constraint est_dfp_count_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'est_eif_count_dtl_fkey_est_dfp_count_dtl')
begin
	alter table est_eif_count_dtl drop constraint est_eif_count_dtl_fkey_est_dfp_count_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_eif_count_dtl')
begin
	alter table est_eif_count_dtl drop constraint PK_est_eif_count_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_eif_object_dtl')
begin
	alter table est_eif_object_dtl drop constraint PK_est_eif_object_dtl
end

if exists(select 'x' from sysobjects where name = 'Chk_est_estimate_baseline_flag')
begin
	alter table est_estimate drop constraint Chk_est_estimate_baseline_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_est_estimate_current_flag')
begin
	alter table est_estimate drop constraint Chk_est_estimate_current_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_est_estimate_doc_type')
begin
	alter table est_estimate drop constraint Chk_est_estimate_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_estimate_pkey')
begin
	alter table est_estimate drop constraint est_estimate_pkey
end

if exists(select 'x' from sysobjects where name = 'est_fpcal_act_dtl_fkey_est_fpcal_comp_dtl')
begin
	alter table est_fpcal_act_dtl drop constraint est_fpcal_act_dtl_fkey_est_fpcal_comp_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_fpcal_act_dtl')
begin
	alter table est_fpcal_act_dtl drop constraint PK_est_fpcal_act_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_fpcal_comp_dtl')
begin
	alter table est_fpcal_comp_dtl drop constraint PK_est_fpcal_comp_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_group_act_band')
begin
	alter table est_group_act_band drop constraint PK_est_group_act_band
end

if exists(select 'x' from sysobjects where name = 'PK_est_group_comp_band')
begin
	alter table est_group_comp_band drop constraint PK_est_group_comp_band
end

if exists(select 'x' from sysobjects where name = 'est_group_comp_dtl_fkey_est_group_dtl')
begin
	alter table est_group_comp_dtl drop constraint est_group_comp_dtl_fkey_est_group_dtl
end

if exists(select 'x' from sysobjects where name = 'est_group_comp_dtl_pk')
begin
	alter table est_group_comp_dtl drop constraint est_group_comp_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'est_group_det_dtl_PK')
begin
	alter table est_group_det_dtl drop constraint est_group_det_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_dtl_pk')
begin
	alter table est_group_dtl drop constraint est_group_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'PK_est_group_eif_dtl')
begin
	alter table est_group_eif_dtl drop constraint PK_est_group_eif_dtl
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_comp_dtl_PK')
begin
	alter table est_group_enh_comp_dtl drop constraint est_group_enh_comp_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_det_dtl_PK')
begin
	alter table est_group_enh_det_dtl drop constraint est_group_enh_det_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_dfp_dtl_PK')
begin
	alter table est_group_enh_dfp_dtl drop constraint est_group_enh_dfp_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_dtl_PK')
begin
	alter table est_group_enh_dtl drop constraint est_group_enh_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_eif_dtl_PK')
begin
	alter table est_group_enh_eif_dtl drop constraint est_group_enh_eif_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_ilf_dtl_PK')
begin
	alter table est_group_enh_ilf_dtl drop constraint est_group_enh_ilf_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_refine_PK')
begin
	alter table est_group_enh_refine drop constraint est_group_enh_refine_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_tfp_dtl_PK')
begin
	alter table est_group_enh_tfp_dtl drop constraint est_group_enh_tfp_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_enh_tfp_ftr_dtl_PK')
begin
	alter table est_group_enh_tfp_ftr_dtl drop constraint est_group_enh_tfp_ftr_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'est_group_refined_tfp_pkey')
begin
	alter table est_group_refined_tfp drop constraint est_group_refined_tfp_pkey
end

if exists(select 'x' from sysobjects where name = 'est_group_refined_tfp_dtl_pkey')
begin
	alter table est_group_refined_tfp_dtl drop constraint est_group_refined_tfp_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_est_ilf_object_dtl')
begin
	alter table est_ilf_object_dtl drop constraint PK_est_ilf_object_dtl
end

if exists(select 'x' from sysobjects where name = 'est_ilf_object_ref_fkey_est_dfp_count_dtl')
begin
	alter table est_ilf_object_ref drop constraint est_ilf_object_ref_fkey_est_dfp_count_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_ilf_object_ref')
begin
	alter table est_ilf_object_ref drop constraint PK_est_ilf_object_ref
end

if exists(select 'x' from sysobjects where name = 'est_ilf_table_remove_PK')
begin
	alter table est_ilf_table_remove drop constraint est_ilf_table_remove_PK
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_act_band')
begin
	alter table est_postprw_act_band drop constraint PK_est_postprw_act_band
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_actres_dtl')
begin
	alter table est_postprw_actres_dtl drop constraint PK_est_postprw_actres_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_comp_band')
begin
	alter table est_postprw_comp_band drop constraint PK_est_postprw_comp_band
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_compres_dtl')
begin
	alter table est_postprw_compres_dtl drop constraint PK_est_postprw_compres_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_eif_obj_dtl')
begin
	alter table est_postprw_eif_obj_dtl drop constraint PK_est_postprw_eif_obj_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_ilf_obj_dtl')
begin
	alter table est_postprw_ilf_obj_dtl drop constraint PK_est_postprw_ilf_obj_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_postprw_ui_map')
begin
	alter table est_postprw_ui_map drop constraint PK_est_postprw_ui_map
end

if exists(select 'x' from sysobjects where name = 'est_quick_code_mst_pkey')
begin
	alter table est_quick_code_mst drop constraint est_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_est_task_change_type')
begin
	alter table est_task drop constraint Chk_est_task_change_type
end

if exists(select 'x' from sysobjects where name = 'Chk_est_task_doc_type')
begin
	alter table est_task drop constraint Chk_est_task_doc_type
end

if exists(select 'x' from sysobjects where name = 'est_task_fkey_est_activity')
begin
	alter table est_task drop constraint est_task_fkey_est_activity
end

if exists(select 'x' from sysobjects where name = 'est_task_pkey')
begin
	alter table est_task drop constraint est_task_pkey
end

if exists(select 'x' from sysobjects where name = 'est_task_met_pkey')
begin
	alter table est_task_met drop constraint est_task_met_pkey
end

if exists(select 'x' from sysobjects where name = 'est_tfp_count_dtl_fkey_est_fpcal_comp_dtl')
begin
	alter table est_tfp_count_dtl drop constraint est_tfp_count_dtl_fkey_est_fpcal_comp_dtl
end

if exists(select 'x' from sysobjects where name = 'PK_est_tfp_count_dtl')
begin
	alter table est_tfp_count_dtl drop constraint PK_est_tfp_count_dtl
end

if exists(select 'x' from sysobjects where name = 'est_tfp_ftr_dtl_fkey_est_tfp_count_dtl')
begin
	alter table est_tfp_ftr_dtl drop constraint est_tfp_ftr_dtl_fkey_est_tfp_count_dtl
end

if exists(select 'x' from sysobjects where name = 'est_tfp_ftr_dtl_pk')
begin
	alter table est_tfp_ftr_dtl drop constraint est_tfp_ftr_dtl_pk
end

if exists(select 'x' from sysobjects where name = 'PK_est_tfp_object_dtl')
begin
	alter table est_tfp_object_dtl drop constraint PK_est_tfp_object_dtl
end

if exists(select 'x' from sysobjects where name = 'est_version_ui_doc_ref_PK')
begin
	alter table est_version_ui_doc_ref drop constraint est_version_ui_doc_ref_PK
end

if exists(select 'x' from sysobjects where name = 'FK_EzeeView_PortalList_EzeeView_PortalTabitems_detail')
begin
	alter table EzeeView_PortalList drop constraint FK_EzeeView_PortalList_EzeeView_PortalTabitems_detail
end

if exists(select 'x' from sysobjects where name = 'PK_EzeeView_PortalList')
begin
	alter table EzeeView_PortalList drop constraint PK_EzeeView_PortalList
end

if exists(select 'x' from sysobjects where name = 'FK_EzeeView_Portallist_Details_EzeeView_PortalList')
begin
	alter table EzeeView_PortalList_Details drop constraint FK_EzeeView_Portallist_Details_EzeeView_PortalList
end

if exists(select 'x' from sysobjects where name = 'PK_EzeeView_Portallist_Details')
begin
	alter table EzeeView_PortalList_Details drop constraint PK_EzeeView_Portallist_Details
end

if exists(select 'x' from sysobjects where name = 'PK_EzeeView_PortalTabitems_detail')
begin
	alter table EzeeView_PortalTabItems_Detail drop constraint PK_EzeeView_PortalTabitems_detail
end

if exists(select 'x' from sysobjects where name = 'ezq_alias_PK')
begin
	alter table ezq_alias drop constraint ezq_alias_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_alias_dtl_PK')
begin
	alter table ezq_alias_dtl drop constraint ezq_alias_dtl_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_alias_OU_Privileges_PK')
begin
	alter table ezq_alias_OU_Privileges drop constraint ezq_alias_OU_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_alias_Privileges_PK')
begin
	alter table ezq_alias_Privileges drop constraint ezq_alias_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_alias_Role_Privileges_PK')
begin
	alter table ezq_alias_Role_Privileges drop constraint ezq_alias_Role_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Items_PK')
begin
	alter table ezq_Document_Items drop constraint ezq_Document_Items_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Lists_PK')
begin
	alter table ezq_Document_Lists drop constraint ezq_Document_Lists_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_OU_Privileges_PK')
begin
	alter table ezq_Document_OU_Privileges drop constraint ezq_Document_OU_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Privileges_PK')
begin
	alter table ezq_Document_Privileges drop constraint ezq_Document_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Relation_Items_PK')
begin
	alter table ezq_Document_Relation_Items drop constraint ezq_Document_Relation_Items_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Relations_PK')
begin
	alter table ezq_Document_Relations drop constraint ezq_Document_Relations_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Document_Role_Privileges_PK')
begin
	alter table ezq_Document_Role_Privileges drop constraint ezq_Document_Role_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Documents_PK')
begin
	alter table ezq_Documents drop constraint ezq_Documents_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_ListItems_PK')
begin
	alter table ezq_ListItems drop constraint ezq_ListItems_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Lists_PK')
begin
	alter table ezq_Lists drop constraint ezq_Lists_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Pick_Documents_PK')
begin
	alter table ezq_Pick_Documents drop constraint ezq_Pick_Documents_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Queries_PK')
begin
	alter table ezq_Queries drop constraint ezq_Queries_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_query_Items_PK')
begin
	alter table ezq_query_Items drop constraint ezq_query_Items_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_Role_Privileges_PK')
begin
	alter table ezq_Role_Privileges drop constraint ezq_Role_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_selected_alias_PK')
begin
	alter table ezq_selected_alias drop constraint ezq_selected_alias_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_selected_ou_PK')
begin
	alter table ezq_selected_ou drop constraint ezq_selected_ou_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_system_queries_PK')
begin
	alter table ezq_system_queries drop constraint ezq_system_queries_PK
end

if exists(select 'x' from sysobjects where name = 'ezq_User_Privileges_PK')
begin
	alter table ezq_User_Privileges drop constraint ezq_User_Privileges_PK
end

if exists(select 'x' from sysobjects where name = 'ezwiz_metadata_pk')
begin
	alter table ezwiz_metadata drop constraint ezwiz_metadata_pk
end

if exists(select 'x' from sysobjects where name = 'ezwiz_Reference_Value_pk')
begin
	alter table ezwiz_Reference_Value drop constraint ezwiz_Reference_Value_pk
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Act_Associate_Events_PK')
begin
	alter table Fw_Bpt_Act_Associate_Events drop constraint Fw_Bpt_Act_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Bpt_Activity drop constraint Fw_Bpt_Activity_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_PK')
begin
	alter table Fw_Bpt_Activity drop constraint Fw_Bpt_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_Events_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Bpt_Activity_Events drop constraint Fw_Bpt_Activity_Events_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_Events_Unq')
begin
	alter table Fw_Bpt_Activity_Events drop constraint Fw_Bpt_Activity_Events_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_Feature_fkey_Fw_Bpt_Feature')
begin
	alter table Fw_Bpt_Activity_Feature drop constraint Fw_Bpt_Activity_Feature_fkey_Fw_Bpt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_Feature_PK')
begin
	alter table Fw_Bpt_Activity_Feature drop constraint Fw_Bpt_Activity_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Actiivty_UI_PK')
begin
	alter table Fw_Bpt_Activity_UI drop constraint Fw_Bpt_Actiivty_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_UI_fkey_Fw_Bpt_Activity')
begin
	alter table Fw_Bpt_Activity_UI drop constraint Fw_Bpt_Activity_UI_fkey_Fw_Bpt_Activity
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Activity_UI_fkey_Fw_Bpt_UI')
begin
	alter table Fw_Bpt_Activity_UI drop constraint Fw_Bpt_Activity_UI_fkey_Fw_Bpt_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_AssociatedBRs_PK')
begin
	alter table Fw_Bpt_AssociatedBRs drop constraint Fw_Bpt_AssociatedBRs_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Bpt_BP drop constraint Fw_Bpt_BP_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_PK')
begin
	alter table Fw_Bpt_BP drop constraint Fw_Bpt_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Act_Associate_Events_PK')
begin
	alter table Fw_Bpt_BP_Act_Associate_Events drop constraint Fw_Bpt_BP_Act_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Associate_Events_PK')
begin
	alter table Fw_Bpt_BP_Associate_Events drop constraint Fw_Bpt_BP_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Events_fkey_Fw_Bpt_BP')
begin
	alter table Fw_Bpt_BP_Events drop constraint Fw_Bpt_BP_Events_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Events_Unq')
begin
	alter table Fw_Bpt_BP_Events drop constraint Fw_Bpt_BP_Events_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Feature_fkey_Fw_Bpt_Feature')
begin
	alter table Fw_Bpt_BP_Feature drop constraint Fw_Bpt_BP_Feature_fkey_Fw_Bpt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_Feature_PK')
begin
	alter table Fw_Bpt_BP_Feature drop constraint Fw_Bpt_BP_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BP_UI_Associate_Events_PK')
begin
	alter table Fw_Bpt_BP_UI_Associate_Events drop constraint Fw_Bpt_BP_UI_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Bpt_BR drop constraint Fw_Bpt_BR_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_PK')
begin
	alter table Fw_Bpt_BR drop constraint Fw_Bpt_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_Associate_Events_PK')
begin
	alter table Fw_Bpt_BR_Associate_Events drop constraint Fw_Bpt_BR_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_Events_fkey_Fw_Bpt_UI_Task')
begin
	alter table Fw_Bpt_BR_Events drop constraint Fw_Bpt_BR_Events_fkey_Fw_Bpt_UI_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_Events_Unq')
begin
	alter table Fw_Bpt_BR_Events drop constraint Fw_Bpt_BR_Events_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_Feature_fkey_Fw_Bpt_Feature')
begin
	alter table Fw_Bpt_BR_Feature drop constraint Fw_Bpt_BR_Feature_fkey_Fw_Bpt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_Feature_PK')
begin
	alter table Fw_Bpt_BR_Feature drop constraint Fw_Bpt_BR_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_BR_History_mr_ui_level_pk')
begin
	alter table Fw_Bpt_BR_History_mr_ui_level drop constraint Fw_Bpt_BR_History_mr_ui_level_pk
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Component_PK')
begin
	alter table Fw_Bpt_Component drop constraint Fw_Bpt_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Customer_PK')
begin
	alter table Fw_Bpt_Customer drop constraint Fw_Bpt_Customer_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Customer_Project_fkey_Fw_Bpt_Customer')
begin
	alter table Fw_Bpt_Customer_Project drop constraint Fw_Bpt_Customer_Project_fkey_Fw_Bpt_Customer
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Customer_Project_fkey_Fw_Bpt_Project')
begin
	alter table Fw_Bpt_Customer_Project drop constraint Fw_Bpt_Customer_Project_fkey_Fw_Bpt_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Customer_Project_PK')
begin
	alter table Fw_Bpt_Customer_Project drop constraint Fw_Bpt_Customer_Project_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Default_CustProj_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Bpt_Default_CustProj drop constraint Fw_Bpt_Default_CustProj_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Default_CustProj_PK')
begin
	alter table Fw_Bpt_Default_CustProj drop constraint Fw_Bpt_Default_CustProj_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Events_PK')
begin
	alter table Fw_Bpt_Events drop constraint Fw_Bpt_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Events_Gen_PK')
begin
	alter table Fw_Bpt_Events_Gen drop constraint Fw_Bpt_Events_Gen_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Feature_PK')
begin
	alter table Fw_Bpt_Feature drop constraint Fw_Bpt_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_fkey_Fw_Bpt_BP')
begin
	alter table Fw_Bpt_Function drop constraint Fw_Bpt_Function_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_PK')
begin
	alter table Fw_Bpt_Function drop constraint Fw_Bpt_Function_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_Component_fkey_Fw_Bpt_Component')
begin
	alter table Fw_Bpt_Function_Component drop constraint Fw_Bpt_Function_Component_fkey_Fw_Bpt_Component
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_Component_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Bpt_Function_Component drop constraint Fw_Bpt_Function_Component_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_Component_Function_UQ')
begin
	alter table Fw_Bpt_Function_Component drop constraint Fw_Bpt_Function_Component_Function_UQ
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Function_Component_PK')
begin
	alter table Fw_Bpt_Function_Component drop constraint Fw_Bpt_Function_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_LinkUI_Events_PK')
begin
	alter table Fw_Bpt_LinkUI_Events drop constraint Fw_Bpt_LinkUI_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Load_Events_PK')
begin
	alter table Fw_Bpt_Load_Events drop constraint Fw_Bpt_Load_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Project_PK')
begin
	alter table Fw_Bpt_Project drop constraint Fw_Bpt_Project_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Reference_CustProj_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Bpt_Reference_CustProj drop constraint Fw_Bpt_Reference_CustProj_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Reference_CustProj_PK')
begin
	alter table Fw_Bpt_Reference_CustProj drop constraint Fw_Bpt_Reference_CustProj_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Bpt_Task drop constraint Fw_Bpt_Task_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_PK')
begin
	alter table Fw_Bpt_Task drop constraint Fw_Bpt_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_Associate_Events_PK')
begin
	alter table Fw_Bpt_Task_Associate_Events drop constraint Fw_Bpt_Task_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_BR_AssociatedBRs_PK')
begin
	alter table Fw_Bpt_Task_BR_AssociatedBRs drop constraint Fw_Bpt_Task_BR_AssociatedBRs_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_Events_fkey_Fw_Bpt_Activity_UI')
begin
	alter table Fw_Bpt_Task_Events drop constraint Fw_Bpt_Task_Events_fkey_Fw_Bpt_Activity_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_Events_Unq')
begin
	alter table Fw_Bpt_Task_Events drop constraint Fw_Bpt_Task_Events_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_Feature_fkey_Fw_Bpt_Feature')
begin
	alter table Fw_Bpt_Task_Feature drop constraint Fw_Bpt_Task_Feature_fkey_Fw_Bpt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_Task_Feature_PK')
begin
	alter table Fw_Bpt_Task_Feature drop constraint Fw_Bpt_Task_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_PK')
begin
	alter table Fw_Bpt_UI drop constraint Fw_Bpt_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Associate_Events_PK')
begin
	alter table Fw_Bpt_UI_Associate_Events drop constraint Fw_Bpt_UI_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Events_fkey_Fw_Bpt_Activity')
begin
	alter table Fw_Bpt_UI_Events drop constraint Fw_Bpt_UI_Events_fkey_Fw_Bpt_Activity
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Events_Unq')
begin
	alter table Fw_Bpt_UI_Events drop constraint Fw_Bpt_UI_Events_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Feature_fkey_Fw_Bpt_Feature')
begin
	alter table Fw_Bpt_UI_Feature drop constraint Fw_Bpt_UI_Feature_fkey_Fw_Bpt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Feature_PK')
begin
	alter table Fw_Bpt_UI_Feature drop constraint Fw_Bpt_UI_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_fkey_Fw_Bpt_Activity_UI')
begin
	alter table Fw_Bpt_UI_Task drop constraint Fw_Bpt_UI_Task_fkey_Fw_Bpt_Activity_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_fkey_Fw_Bpt_Task')
begin
	alter table Fw_Bpt_UI_Task drop constraint Fw_Bpt_UI_Task_fkey_Fw_Bpt_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_PK')
begin
	alter table Fw_Bpt_UI_Task drop constraint Fw_Bpt_UI_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_BR_fkey_Fw_Bpt_BR')
begin
	alter table Fw_Bpt_UI_Task_BR drop constraint Fw_Bpt_UI_Task_BR_fkey_Fw_Bpt_BR
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_BR_fkey_Fw_Bpt_UI_Task')
begin
	alter table Fw_Bpt_UI_Task_BR drop constraint Fw_Bpt_UI_Task_BR_fkey_Fw_Bpt_UI_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_UI_Task_BR_PK')
begin
	alter table Fw_Bpt_UI_Task_BR drop constraint Fw_Bpt_UI_Task_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_User_CustProj_fkey_Fw_Bpt_Customer')
begin
	alter table Fw_Bpt_User_CustProj drop constraint Fw_Bpt_User_CustProj_fkey_Fw_Bpt_Customer
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_User_CustProj_fkey_Fw_Bpt_Project')
begin
	alter table Fw_Bpt_User_CustProj drop constraint Fw_Bpt_User_CustProj_fkey_Fw_Bpt_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Bpt_User_CustProj_PK')
begin
	alter table Fw_Bpt_User_CustProj drop constraint Fw_Bpt_User_CustProj_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Customer_FuncReq_PK')
begin
	alter table Fw_Cex_Customer_FuncReq drop constraint Fw_Cex_Customer_FuncReq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Reference_Value_PK')
begin
	alter table Fw_Cex_Reference_Value drop constraint Fw_Cex_Reference_Value_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Solutioning_fkey_Fw_Cex_Customer_FuncReq')
begin
	alter table Fw_Cex_Solutioning drop constraint Fw_Cex_Solutioning_fkey_Fw_Cex_Customer_FuncReq
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Solutioning_PK')
begin
	alter table Fw_Cex_Solutioning drop constraint Fw_Cex_Solutioning_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_PK')
begin
	alter table Fw_Cex_Theme drop constraint Fw_Cex_Theme_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_UN')
begin
	alter table Fw_Cex_Theme drop constraint Fw_Cex_Theme_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Detail_fkey_Fw_Cex_Theme')
begin
	alter table Fw_Cex_Theme_Detail drop constraint Fw_Cex_Theme_Detail_fkey_Fw_Cex_Theme
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Detail_PK')
begin
	alter table Fw_Cex_Theme_Detail drop constraint Fw_Cex_Theme_Detail_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Exposure_fkey_Fw_Cex_Theme')
begin
	alter table Fw_Cex_Theme_Exposure drop constraint Fw_Cex_Theme_Exposure_fkey_Fw_Cex_Theme
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Exposure_PK')
begin
	alter table Fw_Cex_Theme_Exposure drop constraint Fw_Cex_Theme_Exposure_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Exposure_Detail_fkey_Fw_Cex_Theme_Detail')
begin
	alter table Fw_Cex_Theme_Exposure_Detail drop constraint Fw_Cex_Theme_Exposure_Detail_fkey_Fw_Cex_Theme_Detail
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Exposure_Detail_fkey_Fw_Cex_Theme_Exposure')
begin
	alter table Fw_Cex_Theme_Exposure_Detail drop constraint Fw_Cex_Theme_Exposure_Detail_fkey_Fw_Cex_Theme_Exposure
end

if exists(select 'x' from sysobjects where name = 'Fw_Cex_Theme_Exposure_Detail_PK')
begin
	alter table Fw_Cex_Theme_Exposure_Detail drop constraint Fw_Cex_Theme_Exposure_Detail_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_fkey_Fw_Cmt_Function')
begin
	alter table Fw_Cmt_Activity drop constraint Fw_Cmt_Activity_fkey_Fw_Cmt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_PK')
begin
	alter table Fw_Cmt_Activity drop constraint Fw_Cmt_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_Events_fkey_Fw_Cmt_Function')
begin
	alter table Fw_Cmt_Activity_Events drop constraint Fw_Cmt_Activity_Events_fkey_Fw_Cmt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_Events_UN')
begin
	alter table Fw_Cmt_Activity_Events drop constraint Fw_Cmt_Activity_Events_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_Feature_fkey_Fw_Cmt_Feature')
begin
	alter table Fw_Cmt_Activity_Feature drop constraint Fw_Cmt_Activity_Feature_fkey_Fw_Cmt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_Feature_PK')
begin
	alter table Fw_Cmt_Activity_Feature drop constraint Fw_Cmt_Activity_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_UI_fkey_Fw_Cmt_UI')
begin
	alter table Fw_Cmt_Activity_UI drop constraint Fw_Cmt_Activity_UI_fkey_Fw_Cmt_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Activity_UI_PK')
begin
	alter table Fw_Cmt_Activity_UI drop constraint Fw_Cmt_Activity_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_AssociatedBRs_PK')
begin
	alter table Fw_Cmt_AssociatedBRs drop constraint Fw_Cmt_AssociatedBRs_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_PK')
begin
	alter table Fw_Cmt_BP drop constraint Fw_Cmt_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_cmt_BP_Act_Associate_Events_PK')
begin
	alter table Fw_Cmt_BP_Act_Associate_Events drop constraint Fw_cmt_BP_Act_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_Events_fkey_Fw_Cmt_BP')
begin
	alter table Fw_Cmt_BP_Events drop constraint Fw_Cmt_BP_Events_fkey_Fw_Cmt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_Events_UN')
begin
	alter table Fw_Cmt_BP_Events drop constraint Fw_Cmt_BP_Events_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_Feature_fkey_Fw_Cmt_Feature')
begin
	alter table Fw_Cmt_BP_Feature drop constraint Fw_Cmt_BP_Feature_fkey_Fw_Cmt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_Feature_PK')
begin
	alter table Fw_Cmt_BP_Feature drop constraint Fw_Cmt_BP_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BP_UI_Associate_Events_PK')
begin
	alter table Fw_Cmt_BP_UI_Associate_Events drop constraint Fw_Cmt_BP_UI_Associate_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_PK')
begin
	alter table Fw_Cmt_BR drop constraint Fw_Cmt_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_Events_fkey_Fw_Cmt_Events')
begin
	alter table Fw_Cmt_BR_Events drop constraint Fw_Cmt_BR_Events_fkey_Fw_Cmt_Events
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_Events_fkey_Fw_Cmt_UI_Task')
begin
	alter table Fw_Cmt_BR_Events drop constraint Fw_Cmt_BR_Events_fkey_Fw_Cmt_UI_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_Events_UN')
begin
	alter table Fw_Cmt_BR_Events drop constraint Fw_Cmt_BR_Events_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_Feature_fkey_Fw_Cmt_Feature')
begin
	alter table Fw_Cmt_BR_Feature drop constraint Fw_Cmt_BR_Feature_fkey_Fw_Cmt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_BR_Feature_PK')
begin
	alter table Fw_Cmt_BR_Feature drop constraint Fw_Cmt_BR_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Component_PK')
begin
	alter table Fw_Cmt_Component drop constraint Fw_Cmt_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Customer_FuncReq_PK')
begin
	alter table Fw_Cmt_Customer_FuncReq drop constraint Fw_Cmt_Customer_FuncReq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Events_PK')
begin
	alter table Fw_Cmt_Events drop constraint Fw_Cmt_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Feature_PK')
begin
	alter table Fw_Cmt_Feature drop constraint Fw_Cmt_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Function_fkey_Fw_Cmt_BP')
begin
	alter table Fw_Cmt_Function drop constraint Fw_Cmt_Function_fkey_Fw_Cmt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Function_PK')
begin
	alter table Fw_Cmt_Function drop constraint Fw_Cmt_Function_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Function_Component_PK')
begin
	alter table Fw_Cmt_Function_Component drop constraint Fw_Cmt_Function_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_LinkUI_Events_PK')
begin
	alter table Fw_Cmt_LinkUI_Events drop constraint Fw_Cmt_LinkUI_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Solutioning_PK')
begin
	alter table Fw_Cmt_Solutioning drop constraint Fw_Cmt_Solutioning_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_PK')
begin
	alter table Fw_Cmt_Task drop constraint Fw_Cmt_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_BR_fkey_Fw_Cmt_BR')
begin
	alter table Fw_Cmt_Task_BR drop constraint Fw_Cmt_Task_BR_fkey_Fw_Cmt_BR
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_BR_fkey_Fw_Cmt_UI_Task')
begin
	alter table Fw_Cmt_Task_BR drop constraint Fw_Cmt_Task_BR_fkey_Fw_Cmt_UI_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_BR_PK')
begin
	alter table Fw_Cmt_Task_BR drop constraint Fw_Cmt_Task_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_BR_AssociatedBRs_PK')
begin
	alter table Fw_Cmt_Task_BR_AssociatedBRs drop constraint Fw_Cmt_Task_BR_AssociatedBRs_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_Events_fkey_Fw_Cmt_Activity_UI')
begin
	alter table Fw_Cmt_Task_Events drop constraint Fw_Cmt_Task_Events_fkey_Fw_Cmt_Activity_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_Events_fkey_Fw_Cmt_Events')
begin
	alter table Fw_Cmt_Task_Events drop constraint Fw_Cmt_Task_Events_fkey_Fw_Cmt_Events
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_Events_UN')
begin
	alter table Fw_Cmt_Task_Events drop constraint Fw_Cmt_Task_Events_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_Feature_fkey_Fw_Cmt_Feature')
begin
	alter table Fw_Cmt_Task_Feature drop constraint Fw_Cmt_Task_Feature_fkey_Fw_Cmt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_Task_Feature_PK')
begin
	alter table Fw_Cmt_Task_Feature drop constraint Fw_Cmt_Task_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_PK')
begin
	alter table Fw_Cmt_UI drop constraint Fw_Cmt_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Events_fkey_Fw_Cmt_Activity')
begin
	alter table Fw_Cmt_UI_Events drop constraint Fw_Cmt_UI_Events_fkey_Fw_Cmt_Activity
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Events_UN')
begin
	alter table Fw_Cmt_UI_Events drop constraint Fw_Cmt_UI_Events_UN
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Feature_fkey_Fw_Cmt_Feature')
begin
	alter table Fw_Cmt_UI_Feature drop constraint Fw_Cmt_UI_Feature_fkey_Fw_Cmt_Feature
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Feature_PK')
begin
	alter table Fw_Cmt_UI_Feature drop constraint Fw_Cmt_UI_Feature_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Task_fkey_Fw_Cmt_Activity_UI')
begin
	alter table Fw_Cmt_UI_Task drop constraint Fw_Cmt_UI_Task_fkey_Fw_Cmt_Activity_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Task_fkey_Fw_Cmt_Task')
begin
	alter table Fw_Cmt_UI_Task drop constraint Fw_Cmt_UI_Task_fkey_Fw_Cmt_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Cmt_UI_Task_PK')
begin
	alter table Fw_Cmt_UI_Task drop constraint Fw_Cmt_UI_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_BPTBaseline_PK')
begin
	alter table Fw_Dlv_BPTBaseline drop constraint Fw_Dlv_BPTBaseline_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_CMTBaseline_PK')
begin
	alter table Fw_Dlv_CMTBaseline drop constraint Fw_Dlv_CMTBaseline_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_Customer_FuncReq_PK')
begin
	alter table Fw_Dlv_Customer_FuncReq drop constraint Fw_Dlv_Customer_FuncReq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_Document_PK')
begin
	alter table Fw_Dlv_Document drop constraint Fw_Dlv_Document_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_Location_PK')
begin
	alter table Fw_Dlv_Location drop constraint Fw_Dlv_Location_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_Role_PK')
begin
	alter table Fw_Dlv_Role drop constraint Fw_Dlv_Role_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Dlv_Solutioning_PK')
begin
	alter table Fw_Dlv_Solutioning drop constraint Fw_Dlv_Solutioning_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Act_Sequence_PK')
begin
	alter table Fw_Doc_Act_Sequence drop constraint Fw_Doc_Act_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActDetails_Scenario_PK')
begin
	alter table Fw_Doc_ActDetails_Scenario drop constraint Fw_Doc_ActDetails_Scenario_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActDetails_Scenario_Seq_fkey_Fw_Doc_ActDetails_Scenario')
begin
	alter table Fw_Doc_ActDetails_Scenario_Seq drop constraint Fw_Doc_ActDetails_Scenario_Seq_fkey_Fw_Doc_ActDetails_Scenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActDetails_Scenario_Seq_PK')
begin
	alter table Fw_Doc_ActDetails_Scenario_Seq drop constraint Fw_Doc_ActDetails_Scenario_Seq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Activity_Needs_PK')
begin
	alter table Fw_Doc_Activity_Needs drop constraint Fw_Doc_Activity_Needs_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActScenario_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Doc_ActScenario drop constraint Fw_Doc_ActScenario_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActScenario_fkey_Fw_Doc_Scenario')
begin
	alter table Fw_Doc_ActScenario drop constraint Fw_Doc_ActScenario_fkey_Fw_Doc_Scenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActScenario_PK')
begin
	alter table Fw_Doc_ActScenario drop constraint Fw_Doc_ActScenario_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActScr_Events_fkey_Fw_Doc_ActScenario')
begin
	alter table Fw_Doc_ActScr_Events drop constraint Fw_Doc_ActScr_Events_fkey_Fw_Doc_ActScenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_ActScr_Events_PK')
begin
	alter table Fw_Doc_ActScr_Events drop constraint Fw_Doc_ActScr_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BP_Environment_PK')
begin
	alter table Fw_Doc_BP_Environment drop constraint Fw_Doc_BP_Environment_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BP_Sequence_fkey_Fw_Bpt_BP')
begin
	alter table Fw_Doc_BP_Sequence drop constraint Fw_Doc_BP_Sequence_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BP_Sequence_PK')
begin
	alter table Fw_Doc_BP_Sequence drop constraint Fw_Doc_BP_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPHistory_PK')
begin
	alter table Fw_Doc_BPHistory drop constraint Fw_Doc_BPHistory_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPScenario_fkey_Fw_Bpt_BP')
begin
	alter table Fw_Doc_BPScenario drop constraint Fw_Doc_BPScenario_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPScenario_fkey_Fw_Doc_Scenario')
begin
	alter table Fw_Doc_BPScenario drop constraint Fw_Doc_BPScenario_fkey_Fw_Doc_Scenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPScenario_PK')
begin
	alter table Fw_Doc_BPScenario drop constraint Fw_Doc_BPScenario_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPScr_Events_fkey_Fw_Doc_BPScenario')
begin
	alter table Fw_Doc_BPScr_Events drop constraint Fw_Doc_BPScr_Events_fkey_Fw_Doc_BPScenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPScr_Events_PK')
begin
	alter table Fw_Doc_BPScr_Events drop constraint Fw_Doc_BPScr_Events_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BPTBaseline_PK')
begin
	alter table Fw_Doc_BPTBaseline drop constraint Fw_Doc_BPTBaseline_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_BR_PK')
begin
	alter table Fw_Doc_BR drop constraint Fw_Doc_BR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_CMTBaseline_PK')
begin
	alter table Fw_Doc_CMTBaseline drop constraint Fw_Doc_CMTBaseline_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Customer_FuncReq_PK')
begin
	alter table Fw_Doc_Customer_FuncReq drop constraint Fw_Doc_Customer_FuncReq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Document_PK')
begin
	alter table Fw_Doc_Document drop constraint Fw_Doc_Document_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_Act_Event_PK')
begin
	alter table Fw_Doc_Flash_Act_Event drop constraint Fw_Doc_Flash_Act_Event_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_Act_LastInstance_PK')
begin
	alter table Fw_Doc_Flash_Act_LastInstance drop constraint Fw_Doc_Flash_Act_LastInstance_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_Act_Scenarios_Activity_Details_PK')
begin
	alter table Fw_Doc_Flash_Act_Scenarios_Activity_Details drop constraint Fw_Doc_Flash_Act_Scenarios_Activity_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_Activity_PK')
begin
	alter table Fw_Doc_Flash_Activity drop constraint Fw_Doc_Flash_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_BP_Event_PK')
begin
	alter table Fw_Doc_Flash_BP_Event drop constraint Fw_Doc_Flash_BP_Event_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_BP_LastInstance_PK')
begin
	alter table Fw_Doc_Flash_BP_LastInstance drop constraint Fw_Doc_Flash_BP_LastInstance_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_BP_Scenarios_Function_Details_PK')
begin
	alter table Fw_Doc_Flash_BP_Scenarios_Function_Details drop constraint Fw_Doc_Flash_BP_Scenarios_Function_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Flash_Function_PK')
begin
	alter table Fw_Doc_Flash_Function drop constraint Fw_Doc_Flash_Function_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Func_Sequence_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Doc_Func_Sequence drop constraint Fw_Doc_Func_Sequence_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Func_Sequence_PK')
begin
	alter table Fw_Doc_Func_Sequence drop constraint Fw_Doc_Func_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Location_PK')
begin
	alter table Fw_Doc_Location drop constraint Fw_Doc_Location_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Role_PK')
begin
	alter table Fw_Doc_Role drop constraint Fw_Doc_Role_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Scenario_PK')
begin
	alter table Fw_Doc_Scenario drop constraint Fw_Doc_Scenario_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_SecDtls_PK')
begin
	alter table Fw_Doc_SecDtls drop constraint Fw_Doc_SecDtls_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Solutioning_PK')
begin
	alter table Fw_Doc_Solutioning drop constraint Fw_Doc_Solutioning_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_SubSecDtls_fkey_Fw_Doc_SecDtls')
begin
	alter table Fw_Doc_SubSecDtls drop constraint Fw_Doc_SubSecDtls_fkey_Fw_Doc_SecDtls
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_SubSecDtls_PK')
begin
	alter table Fw_Doc_SubSecDtls drop constraint Fw_Doc_SubSecDtls_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_Task_PK')
begin
	alter table Fw_Doc_Task drop constraint Fw_Doc_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_PK')
begin
	alter table Fw_Doc_UI drop constraint Fw_Doc_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Controls_PK')
begin
	alter table Fw_Doc_UI_Controls drop constraint Fw_Doc_UI_Controls_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Links_PK')
begin
	alter table Fw_Doc_UI_Links drop constraint Fw_Doc_UI_Links_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Scenario_fkey_Fw_Doc_UI')
begin
	alter table Fw_Doc_UI_Scenario drop constraint Fw_Doc_UI_Scenario_fkey_Fw_Doc_UI
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Scenario_PK')
begin
	alter table Fw_Doc_UI_Scenario drop constraint Fw_Doc_UI_Scenario_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Scenario_Seq_fkey_Fw_Doc_UI_Scenario')
begin
	alter table Fw_Doc_UI_Scenario_Seq drop constraint Fw_Doc_UI_Scenario_Seq_fkey_Fw_Doc_UI_Scenario
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Scenario_Seq_PK')
begin
	alter table Fw_Doc_UI_Scenario_Seq drop constraint Fw_Doc_UI_Scenario_Seq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Doc_UI_Sequence_PK')
begin
	alter table Fw_Doc_UI_Sequence drop constraint Fw_Doc_UI_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_Event_PK')
begin
	alter table Fw_Flash_Act_Event drop constraint Fw_Flash_Act_Event_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_LastInstance_PK')
begin
	alter table Fw_Flash_Act_LastInstance drop constraint Fw_Flash_Act_LastInstance_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_ReferenceNumber_PK')
begin
	alter table Fw_Flash_Act_ReferenceNumber drop constraint Fw_Flash_Act_ReferenceNumber_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_Scenario_StartEvent_PK')
begin
	alter table Fw_Flash_Act_Scenario_StartEvent drop constraint Fw_Flash_Act_Scenario_StartEvent_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_Scenario_TREndEvent_PK')
begin
	alter table Fw_Flash_Act_Scenario_TREndEvent drop constraint Fw_Flash_Act_Scenario_TREndEvent_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_Scenarios_Activity_Details_PK')
begin
	alter table Fw_Flash_Act_Scenarios_Activity_Details drop constraint Fw_Flash_Act_Scenarios_Activity_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Act_Scenarios_Events_Details_PK')
begin
	alter table Fw_Flash_Act_Scenarios_Events_Details drop constraint Fw_Flash_Act_Scenarios_Events_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Activity_PK')
begin
	alter table Fw_Flash_Activity drop constraint Fw_Flash_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_PK')
begin
	alter table Fw_Flash_BP drop constraint Fw_Flash_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_Event_PK')
begin
	alter table Fw_Flash_BP_Event drop constraint Fw_Flash_BP_Event_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_LastInstance_PK')
begin
	alter table Fw_Flash_BP_LastInstance drop constraint Fw_Flash_BP_LastInstance_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_Scenario_StartEvent_PK')
begin
	alter table Fw_Flash_BP_Scenario_StartEvent drop constraint Fw_Flash_BP_Scenario_StartEvent_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_Scenarios_PK')
begin
	alter table Fw_Flash_BP_Scenarios drop constraint Fw_Flash_BP_Scenarios_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_Scenarios_Events_Details_PK')
begin
	alter table Fw_Flash_BP_Scenarios_Events_Details drop constraint Fw_Flash_BP_Scenarios_Events_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_BP_Scenarios_Function_Details_PK')
begin
	alter table Fw_Flash_BP_Scenarios_Function_Details drop constraint Fw_Flash_BP_Scenarios_Function_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Cust_Proj_ReferenceNumber_PK')
begin
	alter table Fw_Flash_Cust_Proj_ReferenceNumber drop constraint Fw_Flash_Cust_Proj_ReferenceNumber_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Flash_Function_PK')
begin
	alter table Fw_Flash_Function drop constraint Fw_Flash_Function_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Activity_Events_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Map_Activity_Events drop constraint Fw_Map_Activity_Events_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Activity_Events_UNIQ1')
begin
	alter table Fw_Map_Activity_Events drop constraint Fw_Map_Activity_Events_UNIQ1
end

if exists(select 'x' from sysobjects where name = 'Fw_map_BP_fkey_Fw_Bpt_BP')
begin
	alter table Fw_map_BP drop constraint Fw_map_BP_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_map_BP_EventAssoc_PK1')
begin
	alter table Fw_Map_BP_EventAssoc drop constraint Fw_map_BP_EventAssoc_PK1
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_BP_Events_fkey_Fw_Bpt_BP')
begin
	alter table Fw_Map_BP_Events drop constraint Fw_Map_BP_Events_fkey_Fw_Bpt_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_BP_Events_UNIQ1')
begin
	alter table Fw_Map_BP_Events drop constraint Fw_Map_BP_Events_UNIQ1
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Component_fkey_Fw_Bpt_Component')
begin
	alter table Fw_Map_Component drop constraint Fw_Map_Component_fkey_Fw_Bpt_Component
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Customer_fkey_Fw_Bpt_Customer')
begin
	alter table Fw_Map_Customer drop constraint Fw_Map_Customer_fkey_Fw_Bpt_Customer
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Customer_Project_fkey_Fw_Bpt_Customer_Project')
begin
	alter table Fw_Map_Customer_Project drop constraint Fw_Map_Customer_Project_fkey_Fw_Bpt_Customer_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Default_CustProj_fkey_Fw_Bpt_Default_CustProj')
begin
	alter table Fw_Map_Default_CustProj drop constraint Fw_Map_Default_CustProj_fkey_Fw_Bpt_Default_CustProj
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Function_fkey_Fw_Bpt_Function')
begin
	alter table Fw_Map_Function drop constraint Fw_Map_Function_fkey_Fw_Bpt_Function
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Function_Component_fkey_Fw_Bpt_Function_Component')
begin
	alter table Fw_Map_Function_Component drop constraint Fw_Map_Function_Component_fkey_Fw_Bpt_Function_Component
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_Project_fkey_Fw_Bpt_Project')
begin
	alter table Fw_Map_Project drop constraint Fw_Map_Project_fkey_Fw_Bpt_Project
end

if exists(select 'x' from sysobjects where name = 'Fw_Map_UI_Events_UNIQ1')
begin
	alter table Fw_Map_UI_Events drop constraint Fw_Map_UI_Events_UNIQ1
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Activity_ui_task_temp_Unq')
begin
	alter table Fw_Nia_Activity_ui_task_temp drop constraint Fw_Nia_Activity_ui_task_temp_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_AnalyzeEvent_Dtl_fkey_Fw_Nia_BP_AnalyzeEvent_hdr')
begin
	alter table Fw_Nia_BP_AnalyzeEvent_Dtl drop constraint Fw_Nia_BP_AnalyzeEvent_Dtl_fkey_Fw_Nia_BP_AnalyzeEvent_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_AnalyzeEvent_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_BP_AnalyzeEvent_hdr drop constraint Fw_Nia_BP_AnalyzeEvent_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_BP_Analyz__15CABF25')
begin
	alter table Fw_Nia_BP_AnalyzeEvent_hdr drop constraint PK__Fw_Nia_BP_Analyz__15CABF25
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_AnalyzeFunction_Dtl_fkey_Fw_Nia_BP_AnalyzeFunction_hdr')
begin
	alter table Fw_Nia_BP_AnalyzeFunction_Dtl drop constraint Fw_Nia_BP_AnalyzeFunction_Dtl_fkey_Fw_Nia_BP_AnalyzeFunction_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_AnalyzeFunction_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_BP_AnalyzeFunction_hdr drop constraint Fw_Nia_BP_AnalyzeFunction_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_BP_Analyz__12EE527A')
begin
	alter table Fw_Nia_BP_AnalyzeFunction_hdr drop constraint PK__Fw_Nia_BP_Analyz__12EE527A
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_Picklist_Dtl_fkey_Fw_Nia_BP_Picklist_hdr')
begin
	alter table Fw_Nia_BP_Picklist_Dtl drop constraint Fw_Nia_BP_Picklist_Dtl_fkey_Fw_Nia_BP_Picklist_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_BP_Picklist_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_BP_Picklist_hdr drop constraint Fw_Nia_BP_Picklist_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_BP_Pickli__1011E5CF')
begin
	alter table Fw_Nia_BP_Picklist_hdr drop constraint PK__Fw_Nia_BP_Pickli__1011E5CF
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_AnalyzeActivity_dtl_fkey_Fw_Nia_Function_AnalyzeActivity_hdr')
begin
	alter table Fw_Nia_Function_AnalyzeActivity_dtl drop constraint Fw_Nia_Function_AnalyzeActivity_dtl_fkey_Fw_Nia_Function_AnalyzeActivity_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_AnalyzeActivity_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Function_AnalyzeActivity_hdr drop constraint Fw_Nia_Function_AnalyzeActivity_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Function___1E600526')
begin
	alter table Fw_Nia_Function_AnalyzeActivity_hdr drop constraint PK__Fw_Nia_Function___1E600526
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_AnalyzeEvent_Dtl_fkey_Fw_Nia_Function_AnalyzeEvent_hdr')
begin
	alter table Fw_Nia_Function_AnalyzeEvent_Dtl drop constraint Fw_Nia_Function_AnalyzeEvent_Dtl_fkey_Fw_Nia_Function_AnalyzeEvent_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_AnalyzeEvent_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Function_AnalyzeEvent_hdr drop constraint Fw_Nia_Function_AnalyzeEvent_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Function___213C71D1')
begin
	alter table Fw_Nia_Function_AnalyzeEvent_hdr drop constraint PK__Fw_Nia_Function___213C71D1
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_DynamPicklist_dtl_fkey_Fw_Nia_Function_DynamPicklist_hdr')
begin
	alter table Fw_Nia_Function_DynamPicklist_dtl drop constraint Fw_Nia_Function_DynamPicklist_dtl_fkey_Fw_Nia_Function_DynamPicklist_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_DynamPicklist_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Function_DynamPicklist_hdr drop constraint Fw_Nia_Function_DynamPicklist_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Function___18A72BD0')
begin
	alter table Fw_Nia_Function_DynamPicklist_hdr drop constraint PK__Fw_Nia_Function___18A72BD0
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_ReferPicklist_dtl_fkey_Fw_Nia_Function_ReferPicklist_hdr')
begin
	alter table Fw_Nia_Function_ReferPicklist_dtl drop constraint Fw_Nia_Function_ReferPicklist_dtl_fkey_Fw_Nia_Function_ReferPicklist_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Function_ReferPicklist_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Function_ReferPicklist_hdr drop constraint Fw_Nia_Function_ReferPicklist_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Function___1B83987B')
begin
	alter table Fw_Nia_Function_ReferPicklist_hdr drop constraint PK__Fw_Nia_Function___1B83987B
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_genDoc_Activity_PK')
begin
	alter table Fw_Nia_genDoc_Activity drop constraint Fw_Nia_genDoc_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_NIA_GENDOC_BATCH_PK')
begin
	alter table Fw_nia_gendoc_batch drop constraint Fw_NIA_GENDOC_BATCH_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_genDoc_Bp_PK')
begin
	alter table Fw_Nia_genDoc_Bp drop constraint Fw_Nia_genDoc_Bp_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Gendoc_dtltemp_Unq')
begin
	alter table Fw_Nia_Gendoc_dtltemp drop constraint Fw_Nia_Gendoc_dtltemp_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_genDoc_function_PK')
begin
	alter table Fw_Nia_genDoc_Function drop constraint Fw_Nia_genDoc_function_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_GenDoc_RCN_ECR_ICO_temp_Unq')
begin
	alter table Fw_Nia_GenDoc_RCN_ECR_ICO_temp drop constraint Fw_Nia_GenDoc_RCN_ECR_ICO_temp_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_genDoc_UI_PK')
begin
	alter table Fw_Nia_genDoc_UI drop constraint Fw_Nia_genDoc_UI_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Analyze_Dtl_fkey_Fw_Nia_Method_Analyze_Hdr')
begin
	alter table Fw_Nia_Method_Analyze_Dtl drop constraint Fw_Nia_Method_Analyze_Dtl_fkey_Fw_Nia_Method_Analyze_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Method_Analyze_Hdr drop constraint Fw_Nia_Method_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Method_An__57988282')
begin
	alter table Fw_Nia_Method_Analyze_Hdr drop constraint PK__Fw_Nia_Method_An__57988282
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Interaction_Dtl_fkey_Fw_Nia_Method_Interaction_Hdr')
begin
	alter table Fw_Nia_Method_Interaction_Dtl drop constraint Fw_Nia_Method_Interaction_Dtl_fkey_Fw_Nia_Method_Interaction_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Method_Interaction_Hdr drop constraint Fw_Nia_Method_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Method_In__5D515BD8')
begin
	alter table Fw_Nia_Method_Interaction_Hdr drop constraint PK__Fw_Nia_Method_In__5D515BD8
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Nodelist_Dtl_fkey_Fw_Nia_Method_Nodelist_Hdr')
begin
	alter table Fw_Nia_Method_Nodelist_Dtl drop constraint Fw_Nia_Method_Nodelist_Dtl_fkey_Fw_Nia_Method_Nodelist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Method_Nodelist_Hdr drop constraint Fw_Nia_Method_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Method_No__5A74EF2D')
begin
	alter table Fw_Nia_Method_Nodelist_Hdr drop constraint PK__Fw_Nia_Method_No__5A74EF2D
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Picklist_Dtl_fkey_Fw_Nia_Method_Picklist_Hdr')
begin
	alter table Fw_Nia_Method_Picklist_Dtl drop constraint Fw_Nia_Method_Picklist_Dtl_fkey_Fw_Nia_Method_Picklist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Method_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Method_Picklist_Hdr drop constraint Fw_Nia_Method_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Method_Pi__54BC15D7')
begin
	alter table Fw_Nia_Method_Picklist_Hdr drop constraint PK__Fw_Nia_Method_Pi__54BC15D7
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Analyze_Dtl_fkey_Fw_Nia_Service_Analyze_Hdr')
begin
	alter table Fw_Nia_Service_Analyze_Dtl drop constraint Fw_Nia_Service_Analyze_Dtl_fkey_Fw_Nia_Service_Analyze_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Service_Analyze_Hdr drop constraint Fw_Nia_Service_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Service_A__4C26CFD6')
begin
	alter table Fw_Nia_Service_Analyze_Hdr drop constraint PK__Fw_Nia_Service_A__4C26CFD6
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Interaction_Dtl_fkey_Fw_Nia_Service_Interaction_Hdr')
begin
	alter table Fw_Nia_Service_Interaction_Dtl drop constraint Fw_Nia_Service_Interaction_Dtl_fkey_Fw_Nia_Service_Interaction_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Service_Interaction_Hdr drop constraint Fw_Nia_Service_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Service_I__51DFA92C')
begin
	alter table Fw_Nia_Service_Interaction_Hdr drop constraint PK__Fw_Nia_Service_I__51DFA92C
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Nodelist_Dtl_fkey_Fw_Nia_Service_Nodelist_Hdr')
begin
	alter table Fw_Nia_Service_Nodelist_Dtl drop constraint Fw_Nia_Service_Nodelist_Dtl_fkey_Fw_Nia_Service_Nodelist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Service_Nodelist_Hdr drop constraint Fw_Nia_Service_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Service_N__4F033C81')
begin
	alter table Fw_Nia_Service_Nodelist_Hdr drop constraint PK__Fw_Nia_Service_N__4F033C81
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Picklist_Dtl_fkey_Fw_Nia_Service_Picklist_Hdr')
begin
	alter table Fw_Nia_Service_Picklist_Dtl drop constraint Fw_Nia_Service_Picklist_Dtl_fkey_Fw_Nia_Service_Picklist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Service_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Service_Picklist_Hdr drop constraint Fw_Nia_Service_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Service_P__3266FDD3')
begin
	alter table Fw_Nia_Service_Picklist_Hdr drop constraint PK__Fw_Nia_Service_P__3266FDD3
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Sheetid_Creation_PK')
begin
	alter table Fw_Nia_Sheetid_Creation drop constraint Fw_Nia_Sheetid_Creation_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SheetID_RCN_ECR_ICODtl_Unq')
begin
	alter table Fw_Nia_SheetID_RCN_ECR_ICODtl drop constraint Fw_Nia_SheetID_RCN_ECR_ICODtl_Unq
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Sheetid_Creation_Primarykey')
begin
	alter table FW_NIA_Sheetid_workrequest drop constraint Fw_Nia_Sheetid_Creation_Primarykey
end

if exists(select 'x' from sysobjects where name = 'FW_NIA_Sheetid_workrequest_fkey_Fw_Cex_Customer_FuncReq')
begin
	alter table FW_NIA_Sheetid_workrequest drop constraint FW_NIA_Sheetid_workrequest_fkey_Fw_Cex_Customer_FuncReq
end

if exists(select 'x' from sysobjects where name = 'FW_NIA_Sheetid_workrequest_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table FW_NIA_Sheetid_workrequest drop constraint FW_NIA_Sheetid_workrequest_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Analyze_Dtl_fkey_Fw_Nia_SP_Analyze_Hdr')
begin
	alter table Fw_Nia_SP_Analyze_Dtl drop constraint Fw_Nia_SP_Analyze_Dtl_fkey_Fw_Nia_SP_Analyze_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_SP_Analyze_Hdr drop constraint Fw_Nia_SP_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_SP_Analyz__630A352E')
begin
	alter table Fw_Nia_SP_Analyze_Hdr drop constraint PK__Fw_Nia_SP_Analyz__630A352E
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Interaction_Dtl_fkey_Fw_Nia_SP_Interaction_Hdr')
begin
	alter table Fw_Nia_SP_Interaction_Dtl drop constraint Fw_Nia_SP_Interaction_Dtl_fkey_Fw_Nia_SP_Interaction_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_SP_Interaction_Hdr drop constraint Fw_Nia_SP_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_SP_Intera__68C30E84')
begin
	alter table Fw_Nia_SP_Interaction_Hdr drop constraint PK__Fw_Nia_SP_Intera__68C30E84
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Nodelist_Dtl_fkey_Fw_Nia_SP_Nodelist_Hdr')
begin
	alter table Fw_Nia_SP_Nodelist_Dtl drop constraint Fw_Nia_SP_Nodelist_Dtl_fkey_Fw_Nia_SP_Nodelist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_SP_Nodelist_Hdr drop constraint Fw_Nia_SP_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_SP_Nodeli__65E6A1D9')
begin
	alter table Fw_Nia_SP_Nodelist_Hdr drop constraint PK__Fw_Nia_SP_Nodeli__65E6A1D9
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Picklist_Dtl_fkey_Fw_Nia_SP_Picklist_Hdr')
begin
	alter table Fw_Nia_SP_Picklist_Dtl drop constraint Fw_Nia_SP_Picklist_Dtl_fkey_Fw_Nia_SP_Picklist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_SP_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_SP_Picklist_Hdr drop constraint Fw_Nia_SP_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_SP_Pickli__602DC883')
begin
	alter table Fw_Nia_SP_Picklist_Hdr drop constraint PK__Fw_Nia_SP_Pickli__602DC883
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Analyze_Dtl_fkey_Fw_Nia_Task_Analyze_Hdr')
begin
	alter table Fw_Nia_Task_Analyze_Dtl drop constraint Fw_Nia_Task_Analyze_Dtl_fkey_Fw_Nia_Task_Analyze_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Task_Analyze_Hdr drop constraint Fw_Nia_Task_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Task_Anal__3A081F9B')
begin
	alter table Fw_Nia_Task_Analyze_Hdr drop constraint PK__Fw_Nia_Task_Anal__3A081F9B
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Interaction_Dtl_fkey_Fw_Nia_Task_Interaction_Hdr')
begin
	alter table Fw_Nia_Task_Interaction_Dtl drop constraint Fw_Nia_Task_Interaction_Dtl_fkey_Fw_Nia_Task_Interaction_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Task_Interaction_Hdr drop constraint Fw_Nia_Task_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Task_Inte__344F4645')
begin
	alter table Fw_Nia_Task_Interaction_Hdr drop constraint PK__Fw_Nia_Task_Inte__344F4645
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Nodelist_Dtl_fkey_Fw_Nia_Task_Nodelist_Hdr')
begin
	alter table Fw_Nia_Task_Nodelist_Dtl drop constraint Fw_Nia_Task_Nodelist_Dtl_fkey_Fw_Nia_Task_Nodelist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Task_Nodelist_Hdr drop constraint Fw_Nia_Task_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Task_Node__372BB2F0')
begin
	alter table Fw_Nia_Task_Nodelist_Hdr drop constraint PK__Fw_Nia_Task_Node__372BB2F0
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Picklist_Dtl_fkey_Fw_Nia_Task_Picklist_Hdr')
begin
	alter table Fw_Nia_Task_Picklist_Dtl drop constraint Fw_Nia_Task_Picklist_Dtl_fkey_Fw_Nia_Task_Picklist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_Task_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_Task_Picklist_Hdr drop constraint Fw_Nia_Task_Picklist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_Task_Pick__3CE48C46')
begin
	alter table Fw_Nia_Task_Picklist_Hdr drop constraint PK__Fw_Nia_Task_Pick__3CE48C46
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Analyze_Dtl_fkey_Fw_Nia_UI_Analyze_Hdr')
begin
	alter table Fw_Nia_UI_Analyze_Dtl drop constraint Fw_Nia_UI_Analyze_Dtl_fkey_Fw_Nia_UI_Analyze_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_UI_Analyze_Hdr drop constraint Fw_Nia_UI_Analyze_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_UI_Analyz__4579D247')
begin
	alter table Fw_Nia_UI_Analyze_Hdr drop constraint PK__Fw_Nia_UI_Analyz__4579D247
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Interaction_Dtl_fkey_Fw_Nia_UI_Interaction_Hdr')
begin
	alter table Fw_Nia_UI_Interaction_Dtl drop constraint Fw_Nia_UI_Interaction_Dtl_fkey_Fw_Nia_UI_Interaction_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_UI_Interaction_Hdr drop constraint Fw_Nia_UI_Interaction_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_UI_Intera__3FC0F8F1')
begin
	alter table Fw_Nia_UI_Interaction_Hdr drop constraint PK__Fw_Nia_UI_Intera__3FC0F8F1
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_NodeList_Dtl_fkey_Fw_Nia_UI_Nodelist_Hdr')
begin
	alter table Fw_Nia_UI_NodeList_Dtl drop constraint Fw_Nia_UI_NodeList_Dtl_fkey_Fw_Nia_UI_Nodelist_Hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_UI_Nodelist_Hdr drop constraint Fw_Nia_UI_Nodelist_Hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_UI_Nodeli__429D659C')
begin
	alter table Fw_Nia_UI_Nodelist_Hdr drop constraint PK__Fw_Nia_UI_Nodeli__429D659C
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Picklist_Dtl_fkey_Fw_Nia_UI_Picklist_hdr')
begin
	alter table Fw_Nia_UI_Picklist_Dtl drop constraint Fw_Nia_UI_Picklist_Dtl_fkey_Fw_Nia_UI_Picklist_hdr
end

if exists(select 'x' from sysobjects where name = 'Fw_Nia_UI_Picklist_hdr_fkey_Fw_Nia_Sheetid_Creation')
begin
	alter table Fw_Nia_UI_Picklist_hdr drop constraint Fw_Nia_UI_Picklist_hdr_fkey_Fw_Nia_Sheetid_Creation
end

if exists(select 'x' from sysobjects where name = 'PK__Fw_Nia_UI_Pickli__48563EF2')
begin
	alter table Fw_Nia_UI_Picklist_hdr drop constraint PK__Fw_Nia_UI_Pickli__48563EF2
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_CodeGenPath_PK')
begin
	alter table Fw_OPC_CodeGenPath drop constraint Fw_OPC_CodeGenPath_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_GenerateHTMPath_PK')
begin
	alter table Fw_OPC_GenerateHTMPath drop constraint Fw_OPC_GenerateHTMPath_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_InitiatePackage_PK')
begin
	alter table Fw_OPC_InitiatePackage drop constraint Fw_OPC_InitiatePackage_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_InitPackage_Activity_PK')
begin
	alter table Fw_OPC_InitPackage_Activity drop constraint Fw_OPC_InitPackage_Activity_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_InitPackage_Component_PK')
begin
	alter table Fw_OPC_InitPackage_Component drop constraint Fw_OPC_InitPackage_Component_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_ReleaseSet_FinalisedICO_PK')
begin
	alter table Fw_OPC_ReleaseSet_FinalisedICO drop constraint Fw_OPC_ReleaseSet_FinalisedICO_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_ReleaseSet_ICO_PK')
begin
	alter table Fw_OPC_ReleaseSet_ICO drop constraint Fw_OPC_ReleaseSet_ICO_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_ReleaseSet_ICO_Temp_PK')
begin
	alter table Fw_OPC_ReleaseSet_ICO_Temp drop constraint Fw_OPC_ReleaseSet_ICO_Temp_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_OPC_ReleaseSet_Master_PK')
begin
	alter table Fw_OPC_ReleaseSet_Master drop constraint Fw_OPC_ReleaseSet_Master_PK
end

if exists(select 'x' from sysobjects where name = 'FK_rule_assignment_stmt_rule_stmt')
begin
	alter table fw_req_ilbo_rule_assignment_stmt drop constraint FK_rule_assignment_stmt_rule_stmt
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_assignment_stmt')
begin
	alter table fw_req_ilbo_rule_assignment_stmt drop constraint PK_fw_req_ilbo_rule_assignment_stmt
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_bifunction')
begin
	alter table fw_req_ilbo_rule_bifunction drop constraint PK_fw_req_ilbo_rule_bifunction
end

if exists(select 'x' from sysobjects where name = 'FK_rule_bifunction_param_rule_bifunction')
begin
	alter table fw_req_ilbo_rule_bifunction_param drop constraint FK_rule_bifunction_param_rule_bifunction
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_bifunction_param')
begin
	alter table fw_req_ilbo_rule_bifunction_param drop constraint PK_fw_req_ilbo_rule_bifunction_param
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_eval')
begin
	alter table fw_req_ilbo_rule_eval drop constraint PK_fw_req_ilbo_rule_eval
end

if exists(select 'x' from sysobjects where name = 'FK_rule_eval_token_rule_eval')
begin
	alter table fw_req_ilbo_rule_eval_token drop constraint FK_rule_eval_token_rule_eval
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_eval_token')
begin
	alter table fw_req_ilbo_rule_eval_token drop constraint PK_fw_req_ilbo_rule_eval_token
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_group')
begin
	alter table fw_req_ilbo_rule_group drop constraint PK_fw_req_ilbo_rule_group
end

if exists(select 'x' from sysobjects where name = 'FK_rule_group_stmt_rule_group')
begin
	alter table fw_req_ilbo_rule_group_stmt drop constraint FK_rule_group_stmt_rule_group
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_group_stmt')
begin
	alter table fw_req_ilbo_rule_group_stmt drop constraint PK_fw_req_ilbo_rule_group_stmt
end

if exists(select 'x' from sysobjects where name = 'FK_rule_nst_stmt_rule_stmt_parent_stmt')
begin
	alter table fw_req_ilbo_rule_nested_stmts drop constraint FK_rule_nst_stmt_rule_stmt_parent_stmt
end

if exists(select 'x' from sysobjects where name = 'FK_rule_nst_stmt_rule_stmt_root_stmt')
begin
	alter table fw_req_ilbo_rule_nested_stmts drop constraint FK_rule_nst_stmt_rule_stmt_root_stmt
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_nested_stmts')
begin
	alter table fw_req_ilbo_rule_nested_stmts drop constraint PK_fw_req_ilbo_rule_nested_stmts
end

if exists(select 'x' from sysobjects where name = 'FK_rule_property_stmt_rule_stmt')
begin
	alter table fw_req_ilbo_rule_property_stmt drop constraint FK_rule_property_stmt_rule_stmt
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_property_stmt')
begin
	alter table fw_req_ilbo_rule_property_stmt drop constraint PK_fw_req_ilbo_rule_property_stmt
end

if exists(select 'x' from sysobjects where name = 'FK_rule_property_val_property_stmt')
begin
	alter table fw_req_ilbo_rule_property_value drop constraint FK_rule_property_val_property_stmt
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_property_value')
begin
	alter table fw_req_ilbo_rule_property_value drop constraint PK_fw_req_ilbo_rule_property_value
end

if exists(select 'x' from sysobjects where name = 'FK_rule_stmt_rule_stmt_type')
begin
	alter table fw_req_ilbo_rule_stmt drop constraint FK_rule_stmt_rule_stmt_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_stmt')
begin
	alter table fw_req_ilbo_rule_stmt drop constraint PK_fw_req_ilbo_rule_stmt
end

if exists(select 'x' from sysobjects where name = 'FK_rule_template_rule_source_type')
begin
	alter table fw_req_ilbo_rule_template drop constraint FK_rule_template_rule_source_type
end

if exists(select 'x' from sysobjects where name = 'FK_rule_template_rule_template_type')
begin
	alter table fw_req_ilbo_rule_template drop constraint FK_rule_template_rule_template_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_template')
begin
	alter table fw_req_ilbo_rule_template drop constraint PK_fw_req_ilbo_rule_template
end

if exists(select 'x' from sysobjects where name = 'UK_fw_req_ilbo_rule_template')
begin
	alter table fw_req_ilbo_rule_template drop constraint UK_fw_req_ilbo_rule_template
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_ilbo_rule_template_stmts')
begin
	alter table fw_req_ilbo_rule_template_stmts drop constraint PK_fw_req_ilbo_rule_template_stmts
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_artifact_type')
begin
	alter table fw_req_rule_artifact_type drop constraint PK_fw_req_rule_artifact_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_bifunction')
begin
	alter table fw_req_rule_bifunction drop constraint PK_fw_req_rule_bifunction
end

if exists(select 'x' from sysobjects where name = 'FK_rule_bifunction_rule_bifunction_param')
begin
	alter table fw_req_rule_bifunction_param drop constraint FK_rule_bifunction_rule_bifunction_param
end

if exists(select 'x' from sysobjects where name = 'FK_rule_data_type_rule_bifunction_param')
begin
	alter table fw_req_rule_bifunction_param drop constraint FK_rule_data_type_rule_bifunction_param
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_bifunction_param')
begin
	alter table fw_req_rule_bifunction_param drop constraint PK_fw_req_rule_bifunction_param
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_context_dataitem')
begin
	alter table fw_req_rule_context_dataitem drop constraint PK_fw_req_rule_context_dataitem
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_data_type')
begin
	alter table fw_req_rule_data_type drop constraint PK_fw_req_rule_data_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_inf_source_map')
begin
	alter table fw_req_rule_inf_source_map drop constraint PK_fw_req_rule_inf_source_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_inf_template_map')
begin
	alter table fw_req_rule_inf_template_map drop constraint PK_fw_req_rule_inf_template_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_property_type')
begin
	alter table fw_req_rule_property_type drop constraint PK_fw_req_rule_property_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_source_type')
begin
	alter table fw_req_rule_source_type drop constraint PK_fw_req_rule_source_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_stmt_type')
begin
	alter table fw_req_rule_stmt_type drop constraint PK_fw_req_rule_stmt_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_template_type')
begin
	alter table fw_req_rule_template_type drop constraint PK_fw_req_rule_template_type
end

if exists(select 'x' from sysobjects where name = 'PK_fw_req_rule_token_type')
begin
	alter table fw_req_rule_token_type drop constraint PK_fw_req_rule_token_type
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_activity_ReleaseVersion_pk')
begin
	alter table Fw_Rmt_activity_ReleaseVersion drop constraint Fw_Rmt_activity_ReleaseVersion_pk
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Bpt_RCN_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_Bpt_RCN drop constraint Fw_Rmt_Bpt_RCN_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Bpt_RCN_PK')
begin
	alter table Fw_Rmt_Bpt_RCN drop constraint Fw_Rmt_Bpt_RCN_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_ICO_details_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_Cmt_ICO_details drop constraint Fw_Rmt_Cmt_ICO_details_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_ICO_details_fkey_Fw_Rmt_ICO')
begin
	alter table Fw_Rmt_Cmt_ICO_details drop constraint Fw_Rmt_Cmt_ICO_details_fkey_Fw_Rmt_ICO
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_ICO_details_PK')
begin
	alter table Fw_Rmt_Cmt_ICO_details drop constraint Fw_Rmt_Cmt_ICO_details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_RCN_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_Cmt_RCN drop constraint Fw_Rmt_Cmt_RCN_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_RCN_PK')
begin
	alter table Fw_Rmt_Cmt_RCN drop constraint Fw_Rmt_Cmt_RCN_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Cmt_RCN_Details_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_Cmt_RCN_Details drop constraint Fw_Rmt_Cmt_RCN_Details_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'fw_rmt_component_user_pkey')
begin
	alter table fw_rmt_component_user drop constraint fw_rmt_component_user_pkey
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Direct_ECR_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_Direct_ECR drop constraint Fw_Rmt_Direct_ECR_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Direct_ECR_ImpactedTask_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_Direct_ECR_ImpactedTask drop constraint Fw_Rmt_Direct_ECR_ImpactedTask_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Direct_ECR_ImpactedTask_PK')
begin
	alter table Fw_Rmt_Direct_ECR_ImpactedTask drop constraint Fw_Rmt_Direct_ECR_ImpactedTask_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Direct_ECR_LinkBR_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_Direct_ECR_LinkBR drop constraint Fw_Rmt_Direct_ECR_LinkBR_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Direct_ECR_LinkBR_PK')
begin
	alter table Fw_Rmt_Direct_ECR_LinkBR drop constraint Fw_Rmt_Direct_ECR_LinkBR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_AssociatedDetailedBR_fkey_Fw_Rmt_DirectRCN_Task')
begin
	alter table Fw_Rmt_DirectRCN_AssociatedDetailedBR drop constraint Fw_Rmt_DirectRCN_AssociatedDetailedBR_fkey_Fw_Rmt_DirectRCN_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_AssociatedDetailedBR_PK')
begin
	alter table Fw_Rmt_DirectRCN_AssociatedDetailedBR drop constraint Fw_Rmt_DirectRCN_AssociatedDetailedBR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_AssociatedFlowBR_fkey_Fw_Rmt_DirectRCN_Task')
begin
	alter table Fw_Rmt_DirectRCN_AssociatedFlowBR drop constraint Fw_Rmt_DirectRCN_AssociatedFlowBR_fkey_Fw_Rmt_DirectRCN_Task
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_AssociatedFlowBR_PK')
begin
	alter table Fw_Rmt_DirectRCN_AssociatedFlowBR drop constraint Fw_Rmt_DirectRCN_AssociatedFlowBR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_DetailedBR_PK')
begin
	alter table Fw_Rmt_DirectRCN_DetailedBR drop constraint Fw_Rmt_DirectRCN_DetailedBR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_FlowBR_PK')
begin
	alter table Fw_Rmt_DirectRCN_FlowBR drop constraint Fw_Rmt_DirectRCN_FlowBR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_ImpactedTask_PK')
begin
	alter table Fw_Rmt_DirectRCN_ImpactedTask drop constraint Fw_Rmt_DirectRCN_ImpactedTask_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Link_fkey_Fw_Rmt_DirectRCN_WorkReq')
begin
	alter table Fw_Rmt_DirectRCN_Link drop constraint Fw_Rmt_DirectRCN_Link_fkey_Fw_Rmt_DirectRCN_WorkReq
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Link_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_DirectRCN_Link drop constraint Fw_Rmt_DirectRCN_Link_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Link_PK')
begin
	alter table Fw_Rmt_DirectRCN_Link drop constraint Fw_Rmt_DirectRCN_Link_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Task_fkey_Fw_Rmt_DirectRCN_WorkReq')
begin
	alter table Fw_Rmt_DirectRCN_Task drop constraint Fw_Rmt_DirectRCN_Task_fkey_Fw_Rmt_DirectRCN_WorkReq
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Task_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_DirectRCN_Task drop constraint Fw_Rmt_DirectRCN_Task_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_Task_PK')
begin
	alter table Fw_Rmt_DirectRCN_Task drop constraint Fw_Rmt_DirectRCN_Task_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_WorkReq_fkey_Fw_Rmt_ReleaseVersion_RCN')
begin
	alter table Fw_Rmt_DirectRCN_WorkReq drop constraint Fw_Rmt_DirectRCN_WorkReq_fkey_Fw_Rmt_ReleaseVersion_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_DirectRCN_WorkReq_PK')
begin
	alter table Fw_Rmt_DirectRCN_WorkReq drop constraint Fw_Rmt_DirectRCN_WorkReq_PK
end

if exists(select 'x' from sysobjects where name = 'FW_RMT_DOC_USER_PK')
begin
	alter table FW_RMT_DOC_USER drop constraint FW_RMT_DOC_USER_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_PK')
begin
	alter table Fw_Rmt_ECR drop constraint Fw_Rmt_ECR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_details_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_ECR_details drop constraint Fw_Rmt_ECR_details_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_details_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_ECR_details drop constraint Fw_Rmt_ECR_details_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_ICO_Details_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_ECR_ICO_Details drop constraint Fw_Rmt_ECR_ICO_Details_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_ICO_Details_fkey_Fw_Rmt_ICO')
begin
	alter table Fw_Rmt_ECR_ICO_Details drop constraint Fw_Rmt_ECR_ICO_Details_fkey_Fw_Rmt_ICO
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ECR_ICO_Details_PK')
begin
	alter table Fw_Rmt_ECR_ICO_Details drop constraint Fw_Rmt_ECR_ICO_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ICO_PK')
begin
	alter table Fw_Rmt_ICO drop constraint Fw_Rmt_ICO_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_Impacted_Wk_PK')
begin
	alter table Fw_Rmt_Impacted_Wk drop constraint Fw_Rmt_Impacted_Wk_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_RMT_Lang_CustProj_PK')
begin
	alter table Fw_RMT_Lang_CustProj drop constraint Fw_RMT_Lang_CustProj_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_RCN_PK')
begin
	alter table Fw_Rmt_RCN drop constraint Fw_Rmt_RCN_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_RCN_ECR_Details_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_RCN_ECR_Details drop constraint Fw_Rmt_RCN_ECR_Details_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_PK')
begin
	alter table Fw_Rmt_ReleaseVersion drop constraint Fw_Rmt_ReleaseVersion_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ECR_fkey_Fw_Rmt_ECR')
begin
	alter table Fw_Rmt_ReleaseVersion_ECR drop constraint Fw_Rmt_ReleaseVersion_ECR_fkey_Fw_Rmt_ECR
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ECR_fkey_Fw_Rmt_ReleaseVersion')
begin
	alter table Fw_Rmt_ReleaseVersion_ECR drop constraint Fw_Rmt_ReleaseVersion_ECR_fkey_Fw_Rmt_ReleaseVersion
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ECR_PK')
begin
	alter table Fw_Rmt_ReleaseVersion_ECR drop constraint Fw_Rmt_ReleaseVersion_ECR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ICO_fkey_Fw_Rmt_ICO')
begin
	alter table Fw_Rmt_ReleaseVersion_ICO drop constraint Fw_Rmt_ReleaseVersion_ICO_fkey_Fw_Rmt_ICO
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ICO_fkey_Fw_Rmt_ReleaseVersion')
begin
	alter table Fw_Rmt_ReleaseVersion_ICO drop constraint Fw_Rmt_ReleaseVersion_ICO_fkey_Fw_Rmt_ReleaseVersion
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_ICO_PK')
begin
	alter table Fw_Rmt_ReleaseVersion_ICO drop constraint Fw_Rmt_ReleaseVersion_ICO_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_RCN_fkey_Fw_Rmt_RCN')
begin
	alter table Fw_Rmt_ReleaseVersion_RCN drop constraint Fw_Rmt_ReleaseVersion_RCN_fkey_Fw_Rmt_RCN
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_RCN_fkey_Fw_Rmt_ReleaseVersion')
begin
	alter table Fw_Rmt_ReleaseVersion_RCN drop constraint Fw_Rmt_ReleaseVersion_RCN_fkey_Fw_Rmt_ReleaseVersion
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_RCN_PK')
begin
	alter table Fw_Rmt_ReleaseVersion_RCN drop constraint Fw_Rmt_ReleaseVersion_RCN_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ReleaseVersion_WorkReq_PK')
begin
	alter table Fw_Rmt_ReleaseVersion_WorkReq drop constraint Fw_Rmt_ReleaseVersion_WorkReq_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ShortClose_ECR_PK')
begin
	alter table Fw_Rmt_ShortClose_ECR drop constraint Fw_Rmt_ShortClose_ECR_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_ShortClose_RCN_PK')
begin
	alter table Fw_Rmt_ShortClose_RCN drop constraint Fw_Rmt_ShortClose_RCN_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Rmt_UserRole_Mapping_PK')
begin
	alter table Fw_Rmt_UserRole_Mapping drop constraint Fw_Rmt_UserRole_Mapping_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ApproveTestComp_PK')
begin
	alter table Fw_Tmt_ApproveTestComp drop constraint Fw_Tmt_ApproveTestComp_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_AssociateUser_fkey_Fw_Tmt_InitiateTest')
begin
	alter table Fw_Tmt_AssociateUser drop constraint Fw_Tmt_AssociateUser_fkey_Fw_Tmt_InitiateTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_AssociateUser_PK')
begin
	alter table Fw_Tmt_AssociateUser drop constraint Fw_Tmt_AssociateUser_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_EnvironmentSetup_PK')
begin
	alter table Fw_Tmt_EnvironmentSetup drop constraint Fw_Tmt_EnvironmentSetup_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_EnvSetup_Details_fkey_Fw_Tmt_EnvironmentSetup')
begin
	alter table Fw_Tmt_EnvSetup_Details drop constraint Fw_Tmt_EnvSetup_Details_fkey_Fw_Tmt_EnvironmentSetup
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_EnvSetup_Details_PK')
begin
	alter table Fw_Tmt_EnvSetup_Details drop constraint Fw_Tmt_EnvSetup_Details_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_EnvSetup_RelVer_fkey_Fw_Tmt_EnvironmentSetup')
begin
	alter table Fw_Tmt_EnvSetup_RelVer drop constraint Fw_Tmt_EnvSetup_RelVer_fkey_Fw_Tmt_EnvironmentSetup
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_EnvSetup_RelVer_PK')
begin
	alter table Fw_Tmt_EnvSetup_RelVer drop constraint Fw_Tmt_EnvSetup_RelVer_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_InitiateTest_PK')
begin
	alter table Fw_Tmt_InitiateTest drop constraint Fw_Tmt_InitiateTest_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_IntegrationTest_PK')
begin
	alter table Fw_Tmt_IntegrationTest drop constraint Fw_Tmt_IntegrationTest_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_IntegrationTestCase_fkey_Fw_Tmt_IntegrationTest')
begin
	alter table Fw_Tmt_IntegrationTestCase drop constraint Fw_Tmt_IntegrationTestCase_fkey_Fw_Tmt_IntegrationTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_IntegrationTestCase_PK')
begin
	alter table Fw_Tmt_IntegrationTestCase drop constraint Fw_Tmt_IntegrationTestCase_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_IntegrationTestPlan_PK')
begin
	alter table Fw_Tmt_IntegrationTestPlan drop constraint Fw_Tmt_IntegrationTestPlan_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITC_InstrSet_fkey_Fw_Tmt_IntegrationTestCase')
begin
	alter table Fw_Tmt_ITC_InstrSet drop constraint Fw_Tmt_ITC_InstrSet_fkey_Fw_Tmt_IntegrationTestCase
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITC_InstrSet_PK')
begin
	alter table Fw_Tmt_ITC_InstrSet drop constraint Fw_Tmt_ITC_InstrSet_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITC_Set_Sequence_fkey_Fw_Tmt_ITC_InstrSet')
begin
	alter table Fw_Tmt_ITC_Set_Sequence drop constraint Fw_Tmt_ITC_Set_Sequence_fkey_Fw_Tmt_ITC_InstrSet
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITC_Set_Sequence_PK')
begin
	alter table Fw_Tmt_ITC_Set_Sequence drop constraint Fw_Tmt_ITC_Set_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITP_ITC_fkey_Fw_Tmt_IntegrationTest')
begin
	alter table Fw_Tmt_ITP_ITC drop constraint Fw_Tmt_ITP_ITC_fkey_Fw_Tmt_IntegrationTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITP_ITC_fkey_Fw_Tmt_IntegrationTestPlan')
begin
	alter table Fw_Tmt_ITP_ITC drop constraint Fw_Tmt_ITP_ITC_fkey_Fw_Tmt_IntegrationTestPlan
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITP_ITC_PK')
begin
	alter table Fw_Tmt_ITP_ITC drop constraint Fw_Tmt_ITP_ITC_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITP_ITC_Set_fkey_Fw_Tmt_ITP_ITC')
begin
	alter table Fw_Tmt_ITP_ITC_Set drop constraint Fw_Tmt_ITP_ITC_Set_fkey_Fw_Tmt_ITP_ITC
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_ITP_ITC_Set_PK')
begin
	alter table Fw_Tmt_ITP_ITC_Set drop constraint Fw_Tmt_ITP_ITC_Set_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogITCResult_fkey_Fw_Tmt_AssociateUser')
begin
	alter table Fw_Tmt_LogITCResult drop constraint Fw_Tmt_LogITCResult_fkey_Fw_Tmt_AssociateUser
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogITCResult_PK')
begin
	alter table Fw_Tmt_LogITCResult drop constraint Fw_Tmt_LogITCResult_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogITInstructions_fkey_Fw_Tmt_LogITCResult')
begin
	alter table Fw_Tmt_LogITInstructions drop constraint Fw_Tmt_LogITInstructions_fkey_Fw_Tmt_LogITCResult
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogITInstructions_PK')
begin
	alter table Fw_Tmt_LogITInstructions drop constraint Fw_Tmt_LogITInstructions_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogSTCResult_fkey_Fw_Tmt_AssociateUser')
begin
	alter table Fw_Tmt_LogSTCResult drop constraint Fw_Tmt_LogSTCResult_fkey_Fw_Tmt_AssociateUser
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogSTCResult_PK')
begin
	alter table Fw_Tmt_LogSTCResult drop constraint Fw_Tmt_LogSTCResult_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogSTInstructions_fkey_Fw_Tmt_LogSTCResult')
begin
	alter table Fw_Tmt_LogSTInstructions drop constraint Fw_Tmt_LogSTInstructions_fkey_Fw_Tmt_LogSTCResult
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogSTInstructions_PK')
begin
	alter table Fw_Tmt_LogSTInstructions drop constraint Fw_Tmt_LogSTInstructions_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogTC_LatestTest_PK')
begin
	alter table Fw_Tmt_LogTC_LatestTest drop constraint Fw_Tmt_LogTC_LatestTest_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogUTCResult_fkey_Fw_Tmt_AssociateUser')
begin
	alter table Fw_Tmt_LogUTCResult drop constraint Fw_Tmt_LogUTCResult_fkey_Fw_Tmt_AssociateUser
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogUTCResult_PK')
begin
	alter table Fw_Tmt_LogUTCResult drop constraint Fw_Tmt_LogUTCResult_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogUTInstructions_fkey_Fw_Tmt_LogUTCResult')
begin
	alter table Fw_Tmt_LogUTInstructions drop constraint Fw_Tmt_LogUTInstructions_fkey_Fw_Tmt_LogUTCResult
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_LogUTInstructions_PK')
begin
	alter table Fw_Tmt_LogUTInstructions drop constraint Fw_Tmt_LogUTInstructions_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_Act_InstrSet_fkey_Fw_Tmt_SystemTestCase_Act')
begin
	alter table Fw_Tmt_STC_Act_InstrSet drop constraint Fw_Tmt_STC_Act_InstrSet_fkey_Fw_Tmt_SystemTestCase_Act
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_Act_InstrSet_PK')
begin
	alter table Fw_Tmt_STC_Act_InstrSet drop constraint Fw_Tmt_STC_Act_InstrSet_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_Act_Set_Sequence_fkey_Fw_Tmt_STC_Act_InstrSet')
begin
	alter table Fw_Tmt_STC_Act_Set_Sequence drop constraint Fw_Tmt_STC_Act_Set_Sequence_fkey_Fw_Tmt_STC_Act_InstrSet
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_Act_Set_Sequence_PK')
begin
	alter table Fw_Tmt_STC_Act_Set_Sequence drop constraint Fw_Tmt_STC_Act_Set_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_BP_InstrSet_fkey_Fw_Tmt_SystemTestCase_BP')
begin
	alter table Fw_Tmt_STC_BP_InstrSet drop constraint Fw_Tmt_STC_BP_InstrSet_fkey_Fw_Tmt_SystemTestCase_BP
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_BP_InstrSet_PK')
begin
	alter table Fw_Tmt_STC_BP_InstrSet drop constraint Fw_Tmt_STC_BP_InstrSet_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_BP_Set_Sequence_fkey_Fw_Tmt_STC_BP_InstrSet')
begin
	alter table Fw_Tmt_STC_BP_Set_Sequence drop constraint Fw_Tmt_STC_BP_Set_Sequence_fkey_Fw_Tmt_STC_BP_InstrSet
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STC_BP_Set_Sequence_PK')
begin
	alter table Fw_Tmt_STC_BP_Set_Sequence drop constraint Fw_Tmt_STC_BP_Set_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STP_STC_fkey_Fw_Tmt_SystemTestPlan')
begin
	alter table Fw_Tmt_STP_STC drop constraint Fw_Tmt_STP_STC_fkey_Fw_Tmt_SystemTestPlan
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STP_STC_PK')
begin
	alter table Fw_Tmt_STP_STC drop constraint Fw_Tmt_STP_STC_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STP_STC_Set_fkey_Fw_Tmt_STP_STC')
begin
	alter table Fw_Tmt_STP_STC_Set drop constraint Fw_Tmt_STP_STC_Set_fkey_Fw_Tmt_STP_STC
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_STP_STC_Set_PK')
begin
	alter table Fw_Tmt_STP_STC_Set drop constraint Fw_Tmt_STP_STC_Set_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTest_PK')
begin
	alter table Fw_Tmt_SystemTest drop constraint Fw_Tmt_SystemTest_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTestCase_Act_fkey_Fw_Tmt_SystemTest')
begin
	alter table Fw_Tmt_SystemTestCase_Act drop constraint Fw_Tmt_SystemTestCase_Act_fkey_Fw_Tmt_SystemTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTestCase_Act_PK')
begin
	alter table Fw_Tmt_SystemTestCase_Act drop constraint Fw_Tmt_SystemTestCase_Act_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTestCase_BP_fkey_Fw_Tmt_SystemTest')
begin
	alter table Fw_Tmt_SystemTestCase_BP drop constraint Fw_Tmt_SystemTestCase_BP_fkey_Fw_Tmt_SystemTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTestCase_BP_PK')
begin
	alter table Fw_Tmt_SystemTestCase_BP drop constraint Fw_Tmt_SystemTestCase_BP_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_SystemTestPlan_PK')
begin
	alter table Fw_Tmt_SystemTestPlan drop constraint Fw_Tmt_SystemTestPlan_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UnitTest_PK')
begin
	alter table Fw_Tmt_UnitTest drop constraint Fw_Tmt_UnitTest_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UnitTestCase_fkey_Fw_Tmt_UnitTest')
begin
	alter table Fw_Tmt_UnitTestCase drop constraint Fw_Tmt_UnitTestCase_fkey_Fw_Tmt_UnitTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UnitTestCase_PK')
begin
	alter table Fw_Tmt_UnitTestCase drop constraint Fw_Tmt_UnitTestCase_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UnitTestPlan_PK')
begin
	alter table Fw_Tmt_UnitTestPlan drop constraint Fw_Tmt_UnitTestPlan_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTC_InstrSet_fkey_Fw_Tmt_UnitTestCase')
begin
	alter table Fw_Tmt_UTC_InstrSet drop constraint Fw_Tmt_UTC_InstrSet_fkey_Fw_Tmt_UnitTestCase
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTC_InstrSet_PK')
begin
	alter table Fw_Tmt_UTC_InstrSet drop constraint Fw_Tmt_UTC_InstrSet_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTC_Set_Sequence_fkey_Fw_Tmt_UTC_InstrSet')
begin
	alter table Fw_Tmt_UTC_Set_Sequence drop constraint Fw_Tmt_UTC_Set_Sequence_fkey_Fw_Tmt_UTC_InstrSet
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTC_Set_Sequence_PK')
begin
	alter table Fw_Tmt_UTC_Set_Sequence drop constraint Fw_Tmt_UTC_Set_Sequence_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTP_UTC_fkey_Fw_Tmt_UnitTest')
begin
	alter table Fw_Tmt_UTP_UTC drop constraint Fw_Tmt_UTP_UTC_fkey_Fw_Tmt_UnitTest
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTP_UTC_fkey_Fw_Tmt_UnitTestPlan')
begin
	alter table Fw_Tmt_UTP_UTC drop constraint Fw_Tmt_UTP_UTC_fkey_Fw_Tmt_UnitTestPlan
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTP_UTC_PK')
begin
	alter table Fw_Tmt_UTP_UTC drop constraint Fw_Tmt_UTP_UTC_PK
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTP_UTC_Set_fkey_Fw_Tmt_UTP_UTC')
begin
	alter table Fw_Tmt_UTP_UTC_Set drop constraint Fw_Tmt_UTP_UTC_Set_fkey_Fw_Tmt_UTP_UTC
end

if exists(select 'x' from sysobjects where name = 'Fw_Tmt_UTP_UTC_Set_PK')
begin
	alter table Fw_Tmt_UTP_UTC_Set drop constraint Fw_Tmt_UTP_UTC_Set_PK
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_change_log_fkey_hpl_change_log')
begin
	alter table hpl_assignment_change_log drop constraint hpl_assignment_change_log_fkey_hpl_change_log
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_change_log_pkey')
begin
	alter table hpl_assignment_change_log drop constraint hpl_assignment_change_log_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_dtl_fkey_hpl_plan_detail')
begin
	alter table hpl_assignment_dtl drop constraint hpl_assignment_dtl_fkey_hpl_plan_detail
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_dtl_pkey')
begin
	alter table hpl_assignment_dtl drop constraint hpl_assignment_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_history_fkey_hpl_plan_history')
begin
	alter table hpl_assignment_history drop constraint hpl_assignment_history_fkey_hpl_plan_history
end

if exists(select 'x' from sysobjects where name = 'hpl_assignment_history_pkey')
begin
	alter table hpl_assignment_history drop constraint hpl_assignment_history_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_change_log_pkey')
begin
	alter table hpl_change_log drop constraint hpl_change_log_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_custml_ref_templates_pkey')
begin
	alter table hpl_custml_ref_templates drop constraint hpl_custml_ref_templates_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_fin_note_hdr_pkey')
begin
	alter table hpl_fin_note_hdr drop constraint hpl_fin_note_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_generate_log_pkey')
begin
	alter table hpl_generate_log drop constraint hpl_generate_log_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_generate_log_hdr_pkey')
begin
	alter table hpl_generate_log_hdr drop constraint hpl_generate_log_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_genplan_doc_pkey')
begin
	alter table hpl_genplan_doc drop constraint hpl_genplan_doc_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_Maintain_Plan_History_pkey')
begin
	alter table hpl_Maintain_Plan_History drop constraint hpl_Maintain_Plan_History_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_ns_workproducts_pkey')
begin
	alter table hpl_ns_workproducts drop constraint hpl_ns_workproducts_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_detail_pkey')
begin
	alter table hpl_plan_detail drop constraint hpl_plan_detail_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_detail_arc_pkey')
begin
	alter table hpl_plan_detail_arc drop constraint hpl_plan_detail_arc_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_history_pkey')
begin
	alter table hpl_plan_history drop constraint hpl_plan_history_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_predecessor_fkey_hpl_plan_detail')
begin
	alter table hpl_plan_predecessor drop constraint hpl_plan_predecessor_fkey_hpl_plan_detail
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_predecessor_fkey_hpl_plan_detail1')
begin
	alter table hpl_plan_predecessor drop constraint hpl_plan_predecessor_fkey_hpl_plan_detail1
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_predecessor_pkey')
begin
	alter table hpl_plan_predecessor drop constraint hpl_plan_predecessor_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_plan_structure_pkey')
begin
	alter table hpl_plan_structure drop constraint hpl_plan_structure_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_quick_code_met_pkey')
begin
	alter table hpl_quick_code_met drop constraint hpl_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_quick_code_met_lng_extn_pkey')
begin
	alter table hpl_quick_code_met_lng_extn drop constraint hpl_quick_code_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_risk_dtl_fkey_hpl_plan_detail')
begin
	alter table hpl_risk_dtl drop constraint hpl_risk_dtl_fkey_hpl_plan_detail
end

if exists(select 'x' from sysobjects where name = 'hpl_risk_dtl_pkey')
begin
	alter table hpl_risk_dtl drop constraint hpl_risk_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_struct_predecessor_pkey')
begin
	alter table hpl_struct_predecessor drop constraint hpl_struct_predecessor_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_worklist_mst_pkey')
begin
	alter table hpl_worklist_mst drop constraint hpl_worklist_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_workprod_component_fkey_hpl_workprod_process')
begin
	alter table hpl_workprod_component drop constraint hpl_workprod_component_fkey_hpl_workprod_process
end

if exists(select 'x' from sysobjects where name = 'hpl_workprod_component_pkey')
begin
	alter table hpl_workprod_component drop constraint hpl_workprod_component_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_workprod_document_pkey')
begin
	alter table hpl_workprod_document drop constraint hpl_workprod_document_pkey
end

if exists(select 'x' from sysobjects where name = 'hpl_workprod_process_fkey_hpl_workprod_document')
begin
	alter table hpl_workprod_process drop constraint hpl_workprod_process_fkey_hpl_workprod_document
end

if exists(select 'x' from sysobjects where name = 'hpl_workprod_process_pkey')
begin
	alter table hpl_workprod_process drop constraint hpl_workprod_process_pkey
end

if exists(select 'x' from sysobjects where name = 'irule_inf_req_details_PK')
begin
	alter table irule_inf_req_details drop constraint irule_inf_req_details_PK
end

if exists(select 'x' from sysobjects where name = 'method_trigger_dtl_pkey')
begin
	alter table Method_trigger_dtl drop constraint method_trigger_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_Class')
begin
	alter table NFR_Class drop constraint pk_NFR_Class
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_COMPSP_MAP')
begin
	alter table NFR_COMPSP_MAP drop constraint pk_NFR_COMPSP_MAP
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_DTL')
begin
	alter table NFR_DTL drop constraint pk_NFR_DTL
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_DTL2')
begin
	alter table NFR_DTL2 drop constraint pk_NFR_DTL2
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_MAP')
begin
	alter table NFR_MAP drop constraint pk_NFR_MAP
end

if exists(select 'x' from sysobjects where name = 'pk_nfr_reference_value')
begin
	alter table NFR_Reference_Value drop constraint pk_nfr_reference_value
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL')
begin
	alter table NFR_TMPL drop constraint pk_NFR_TMPL
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL_GRP')
begin
	alter table NFR_TMPL_GRP drop constraint pk_NFR_TMPL_GRP
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL_INST')
begin
	alter table NFR_TMPL_INST drop constraint pk_NFR_TMPL_INST
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL_INST_MATRIX')
begin
	alter table NFR_TMPL_INST_MATRIX drop constraint pk_NFR_TMPL_INST_MATRIX
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL_INST_ML')
begin
	alter table NFR_TMPL_INST_ML drop constraint pk_NFR_TMPL_INST_ML
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TMPL_SEG')
begin
	alter table NFR_TMPL_SEG drop constraint pk_NFR_TMPL_SEG
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_TypeCode')
begin
	alter table NFR_TypeCode drop constraint pk_NFR_TypeCode
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_VER_dtl')
begin
	alter table NFR_VER_DTL drop constraint pk_NFR_VER_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_VER_dtl2')
begin
	alter table NFR_VER_DTL2 drop constraint pk_NFR_VER_dtl2
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_VER_HISTORY')
begin
	alter table NFR_VER_HISTORY drop constraint pk_NFR_VER_HISTORY
end

if exists(select 'x' from sysobjects where name = 'pk_NFR_VER_MAP')
begin
	alter table NFR_VER_MAP drop constraint pk_NFR_VER_MAP
end

if exists(select 'x' from sysobjects where name = 'Organisation_Calendar_fkey_Problem')
begin
	alter table Organisation_Calendar drop constraint Organisation_Calendar_fkey_Problem
end

if exists(select 'x' from sysobjects where name = 'pc_calendar_dtl_pkey')
begin
	alter table pc_calendar_dtl drop constraint pc_calendar_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_ns_workprd_dtl_fkey_pc_ns_workprd_type_hdr')
begin
	alter table pc_ns_workprd_dtl drop constraint pc_ns_workprd_dtl_fkey_pc_ns_workprd_type_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_ns_workprd_dtl_pkey')
begin
	alter table pc_ns_workprd_dtl drop constraint pc_ns_workprd_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_ns_workprd_type_hdr_pkey')
begin
	alter table pc_ns_workprd_type_hdr drop constraint pc_ns_workprd_type_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_plan_temp_categ_wrkprd_map_fkey_pc_plan_template_category')
begin
	alter table pc_plan_temp_categ_wrkprd_map drop constraint pc_plan_temp_categ_wrkprd_map_fkey_pc_plan_template_category
end

if exists(select 'x' from sysobjects where name = 'pc_plan_temp_categ_wrkprd_map_pkey')
begin
	alter table pc_plan_temp_categ_wrkprd_map drop constraint pc_plan_temp_categ_wrkprd_map_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_plan_template_category_pkey')
begin
	alter table pc_plan_template_category drop constraint pc_plan_template_category_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_plan_template_dtl_fkey_pc_plan_template_hdr')
begin
	alter table pc_plan_template_dtl drop constraint pc_plan_template_dtl_fkey_pc_plan_template_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_plan_template_dtl_pkey')
begin
	alter table pc_plan_template_dtl drop constraint pc_plan_template_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_plan_template_hdr_fkey_pc_plan_temp_categ_wrkprd_map')
begin
	alter table pc_plan_template_hdr drop constraint pc_plan_template_hdr_fkey_pc_plan_temp_categ_wrkprd_map
end

if exists(select 'x' from sysobjects where name = 'pc_plan_template_hdr_pkey')
begin
	alter table pc_plan_template_hdr drop constraint pc_plan_template_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_documentation_fkey_pc_project_hdr')
begin
	alter table pc_proj_documentation drop constraint pc_proj_documentation_fkey_pc_project_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_proj_documentation_pkey')
begin
	alter table pc_proj_documentation drop constraint pc_proj_documentation_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_hardware_dtl_fkey_pc_project_hdr')
begin
	alter table pc_proj_hardware_dtl drop constraint pc_proj_hardware_dtl_fkey_pc_project_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_proj_hardware_dtl_pkey')
begin
	alter table pc_proj_hardware_dtl drop constraint pc_proj_hardware_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_role_dtl_fkey_pc_project_hdr')
begin
	alter table pc_proj_role_dtl drop constraint pc_proj_role_dtl_fkey_pc_project_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_proj_role_dtl_pkey')
begin
	alter table pc_proj_role_dtl drop constraint pc_proj_role_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_dtl_fkey_pc_proj_sol_center_dtl')
begin
	alter table pc_proj_sc_emp_dtl drop constraint pc_proj_sc_emp_dtl_fkey_pc_proj_sol_center_dtl
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_dtl_pkey')
begin
	alter table pc_proj_sc_emp_dtl drop constraint pc_proj_sc_emp_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_dtl_history_pkey')
begin
	alter table pc_proj_sc_emp_dtl_history drop constraint pc_proj_sc_emp_dtl_history_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_role_dtl_fkey_pc_proj_role_dtl')
begin
	alter table pc_proj_sc_emp_role_dtl drop constraint pc_proj_sc_emp_role_dtl_fkey_pc_proj_role_dtl
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_role_dtl_fkey_pc_proj_sol_center_dtl')
begin
	alter table pc_proj_sc_emp_role_dtl drop constraint pc_proj_sc_emp_role_dtl_fkey_pc_proj_sol_center_dtl
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_emp_role_dtl_pkey')
begin
	alter table pc_proj_sc_emp_role_dtl drop constraint pc_proj_sc_emp_role_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_supervisor_emp_dtl_pkey')
begin
	alter table pc_proj_sc_supervisor_emp_dtl drop constraint pc_proj_sc_supervisor_emp_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sc_supervisor_emp_dtl_history_pkey')
begin
	alter table pc_proj_sc_supervisor_emp_dtl_history drop constraint pc_proj_sc_supervisor_emp_dtl_history_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sol_center_dtl_fkey_pc_project_hdr')
begin
	alter table pc_proj_sol_center_dtl drop constraint pc_proj_sol_center_dtl_fkey_pc_project_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_proj_sol_center_dtl_pkey')
begin
	alter table pc_proj_sol_center_dtl drop constraint pc_proj_sol_center_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'PK__pc_project_calen__06BC187D')
begin
	alter table pc_project_calendar drop constraint PK__pc_project_calen__06BC187D
end

if exists(select 'x' from sysobjects where name = 'pc_project_hdr_pkey')
begin
	alter table pc_project_hdr drop constraint pc_project_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_quick_code_met_pkey')
begin
	alter table pc_quick_code_met drop constraint pc_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_quick_code_met_lng_extn_pkey')
begin
	alter table pc_quick_code_met_lng_extn drop constraint pc_quick_code_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_risk_template_dtl_fkey_pc_risk_template_hdr')
begin
	alter table pc_risk_template_dtl drop constraint pc_risk_template_dtl_fkey_pc_risk_template_hdr
end

if exists(select 'x' from sysobjects where name = 'pc_risk_template_dtl_pkey')
begin
	alter table pc_risk_template_dtl drop constraint pc_risk_template_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_risk_template_hdr_pkey')
begin
	alter table pc_risk_template_hdr drop constraint pc_risk_template_hdr_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_sol_center_met_pkey')
begin
	alter table pc_sol_center_met drop constraint pc_sol_center_met_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_sys_workprd_type_met_pkey')
begin
	alter table pc_sys_workprd_type_met drop constraint pc_sys_workprd_type_met_pkey
end

if exists(select 'x' from sysobjects where name = 'pc_wbs_mst_pkey')
begin
	alter table pc_wbs_mst drop constraint pc_wbs_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'Platform_Initialize_Detail_PK')
begin
	alter table Platform_Initialize_Detail drop constraint Platform_Initialize_Detail_PK
end

if exists(select 'x' from sysobjects where name = 'Cust_idPK')
begin
	alter table Problem drop constraint Cust_idPK
end

if exists(select 'x' from sysobjects where name = 're_action_pkey')
begin
	alter table re_action drop constraint re_action_pkey
end

if exists(select 'x' from sysobjects where name = 're_action_lng_extn_pkey')
begin
	alter table re_action_lng_extn drop constraint re_action_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_action_reuse_info_pkey')
begin
	alter table re_action_reuse_info drop constraint re_action_reuse_info_pkey
end

if exists(select 'x' from sysobjects where name = 're_action_section_map_pkey')
begin
	alter table re_action_section_map drop constraint re_action_section_map_pkey
end

if exists(select 'x' from sysobjects where name = 're_business_rule_pkey')
begin
	alter table re_business_rule drop constraint re_business_rule_pkey
end

if exists(select 'x' from sysobjects where name = 're_business_rule_lng_extn_pkey')
begin
	alter table re_business_rule_lng_extn drop constraint re_business_rule_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_chart_header_pkey')
begin
	alter table re_chart_header drop constraint re_chart_header_pkey
end

if exists(select 'x' from sysobjects where name = 're_chart_sample_data_pkey')
begin
	alter table re_chart_sample_data drop constraint re_chart_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 're_chart_series_pkey')
begin
	alter table re_chart_series drop constraint re_chart_series_pkey
end

if exists(select 'x' from sysobjects where name = 're_contextual_links_PK')
begin
	alter table re_contextual_links drop constraint re_contextual_links_PK
end

if exists(select 'x' from sysobjects where name = 're_control_extensions_PK')
begin
	alter table re_control_extensions drop constraint re_control_extensions_PK
end

if exists(select 'x' from sysobjects where name = 're_custom_listedit_PKey')
begin
	alter table re_custom_listedit drop constraint re_custom_listedit_PKey
end

if exists(select 'x' from sysobjects where name = 're_date_highlight_control_map_PKey')
begin
	alter table re_date_highlight_control_map drop constraint re_date_highlight_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_action')
begin
	alter table re_dwd_action drop constraint PK_re_dwd_action
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_action_section_map')
begin
	alter table re_dwd_action_section_map drop constraint PK_re_dwd_action_section_map
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_enum_value')
begin
	alter table re_dwd_enum_value drop constraint PK_re_dwd_enum_value
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_flowbr')
begin
	alter table re_dwd_flowbr drop constraint PK_re_dwd_flowbr
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_flowbr_br_error')
begin
	alter table re_dwd_flowbr_br_error drop constraint PK_re_dwd_flowbr_br_error
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_flowbr_combo')
begin
	alter table re_dwd_flowbr_combo drop constraint PK_re_dwd_flowbr_combo
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_flowbr_rule_map')
begin
	alter table re_dwd_flowbr_rule_map drop constraint PK_re_dwd_flowbr_rule_map
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_publication_dataitem')
begin
	alter table re_dwd_publication_dataitem drop constraint PK_re_dwd_publication_dataitem
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_radio_button')
begin
	alter table re_dwd_radio_button drop constraint PK_re_dwd_radio_button
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_resolved_link')
begin
	alter table re_dwd_resolved_link drop constraint PK_re_dwd_resolved_link
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_resolved_link_dataitem')
begin
	alter table re_dwd_resolved_link_dataitem drop constraint PK_re_dwd_resolved_link_dataitem
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_subscription')
begin
	alter table re_dwd_subscription drop constraint PK_re_dwd_subscription
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_subscription_dataitem')
begin
	alter table re_dwd_subscription_dataitem drop constraint PK_re_dwd_subscription_dataitem
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_control')
begin
	alter table re_dwd_ui_control drop constraint PK_re_dwd_ui_control
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_ecr')
begin
	alter table re_dwd_ui_ecr drop constraint PK_re_dwd_ui_ecr
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_grid')
begin
	alter table re_dwd_ui_grid drop constraint PK_re_dwd_ui_grid
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_page')
begin
	alter table re_dwd_ui_page drop constraint PK_re_dwd_ui_page
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_section')
begin
	alter table re_dwd_ui_section drop constraint PK_re_dwd_ui_section
end

if exists(select 'x' from sysobjects where name = 'PK_re_dwd_ui_traversal')
begin
	alter table re_dwd_ui_traversal drop constraint PK_re_dwd_ui_traversal
end

if exists(select 'x' from sysobjects where name = 'Chk_re_enum_value_default_flag')
begin
	alter table re_enum_value drop constraint Chk_re_enum_value_default_flag
end

if exists(select 'x' from sysobjects where name = 're_enum_value_pkey')
begin
	alter table re_enum_value drop constraint re_enum_value_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_enum_value_lng_extn_default_flag')
begin
	alter table re_enum_value_lng_extn drop constraint Chk_re_enum_value_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_enum_value_lng_extn_pkey')
begin
	alter table re_enum_value_lng_extn drop constraint re_enum_value_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_ext_js_control_PK')
begin
	alter table re_ext_js_control drop constraint re_ext_js_control_PK
end

if exists(select 'x' from sysobjects where name = 're_ext_js_section_PK')
begin
	alter table re_ext_js_section drop constraint re_ext_js_section_PK
end

if exists(select 'x' from sysobjects where name = 're_ext_js_section_column_PK')
begin
	alter table re_ext_js_section_column drop constraint re_ext_js_section_column_PK
end

if exists(select 'x' from sysobjects where name = 're_ezeeview_sp_PK')
begin
	alter table re_ezeeview_sp drop constraint re_ezeeview_sp_PK
end

if exists(select 'x' from sysobjects where name = 're_ezeeview_spparamlist_pk')
begin
	alter table re_ezeeview_spparamlist drop constraint re_ezeeview_spparamlist_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_res_ilbo_dataitem_pk')
begin
	alter table re_ezwiz_res_ilbo_dataitem drop constraint re_ezwiz_res_ilbo_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_res_step_dataitem_pk')
begin
	alter table re_ezwiz_res_step_dataitem drop constraint re_ezwiz_res_step_dataitem_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_wizard_pk')
begin
	alter table re_ezwiz_wizard drop constraint re_ezwiz_wizard_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_wizard_local_info_pk')
begin
	alter table re_ezwiz_wizard_local_info drop constraint re_ezwiz_wizard_local_info_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_wizard_step_pk')
begin
	alter table re_ezwiz_wizard_step drop constraint re_ezwiz_wizard_step_pk
end

if exists(select 'x' from sysobjects where name = 're_ezwiz_wizard_step_local_info_pk')
begin
	alter table re_ezwiz_wizard_step_local_info drop constraint re_ezwiz_wizard_step_local_info_pk
end

if exists(select 'x' from sysobjects where name = 're_flowbr_pkey')
begin
	alter table re_flowbr drop constraint re_flowbr_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_flowbr_br_error_default_flag')
begin
	alter table re_flowbr_br_error drop constraint Chk_re_flowbr_br_error_default_flag
end

if exists(select 'x' from sysobjects where name = 're_flowbr_br_error_fkey_re_flowbr_rule_map')
begin
	alter table re_flowbr_br_error drop constraint re_flowbr_br_error_fkey_re_flowbr_rule_map
end

if exists(select 'x' from sysobjects where name = 're_flowbr_br_error_pkey')
begin
	alter table re_flowbr_br_error drop constraint re_flowbr_br_error_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_flowbr_br_error_lng_extn_default_flag')
begin
	alter table re_flowbr_br_error_lng_extn drop constraint Chk_re_flowbr_br_error_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_flowbr_br_error_lng_extn_fkey_re_flowbr_rule_map')
begin
	alter table re_flowbr_br_error_lng_extn drop constraint re_flowbr_br_error_lng_extn_fkey_re_flowbr_rule_map
end

if exists(select 'x' from sysobjects where name = 're_flowbr_br_error_lng_extn_pkey')
begin
	alter table re_flowbr_br_error_lng_extn drop constraint re_flowbr_br_error_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_flowbr_combo_fkey_re_flowbr')
begin
	alter table re_flowbr_combo drop constraint re_flowbr_combo_fkey_re_flowbr
end

if exists(select 'x' from sysobjects where name = 're_flowbr_combo_pkey')
begin
	alter table re_flowbr_combo drop constraint re_flowbr_combo_pkey
end

if exists(select 'x' from sysobjects where name = 're_flowbr_lng_extn_pkey')
begin
	alter table re_flowbr_lng_extn drop constraint re_flowbr_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_flowbr_rule_map_br_type')
begin
	alter table re_flowbr_rule_map drop constraint Chk_re_flowbr_rule_map_br_type
end

if exists(select 'x' from sysobjects where name = 're_flowbr_rule_map_fkey_re_flowbr')
begin
	alter table re_flowbr_rule_map drop constraint re_flowbr_rule_map_fkey_re_flowbr
end

if exists(select 'x' from sysobjects where name = 're_flowbr_rule_map_pkey')
begin
	alter table re_flowbr_rule_map drop constraint re_flowbr_rule_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_data_type')
begin
	alter table re_glossary drop constraint Chk_re_glossary_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_length')
begin
	alter table re_glossary drop constraint Chk_re_glossary_length
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_synonym_status')
begin
	alter table re_glossary drop constraint Chk_re_glossary_synonym_status
end

if exists(select 'x' from sysobjects where name = 're_glossary_pkey')
begin
	alter table re_glossary drop constraint re_glossary_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_lng_extn_data_type')
begin
	alter table re_glossary_lng_extn drop constraint Chk_re_glossary_lng_extn_data_type
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_lng_extn_length')
begin
	alter table re_glossary_lng_extn drop constraint Chk_re_glossary_lng_extn_length
end

if exists(select 'x' from sysobjects where name = 'Chk_re_glossary_lng_extn_synonym_status')
begin
	alter table re_glossary_lng_extn drop constraint Chk_re_glossary_lng_extn_synonym_status
end

if exists(select 'x' from sysobjects where name = 're_glossary_lng_extn_pkey')
begin
	alter table re_glossary_lng_extn drop constraint re_glossary_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_listedit_column_PKey')
begin
	alter table re_listedit_column drop constraint re_listedit_column_PKey
end

if exists(select 'x' from sysobjects where name = 're_listedit_control_map_PKey')
begin
	alter table re_listedit_control_map drop constraint re_listedit_control_map_PKey
end

if exists(select 'x' from sysobjects where name = 're_message_pkey')
begin
	alter table re_message drop constraint re_message_pkey
end

if exists(select 'x' from sysobjects where name = 're_message_lng_extn_pkey')
begin
	alter table re_message_lng_extn drop constraint re_message_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_nativeapp_mapping_PK')
begin
	alter table re_nativeapp_mapping drop constraint re_nativeapp_mapping_PK
end

if exists(select 'x' from sysobjects where name = 're_non_ui_control_pkey')
begin
	alter table re_non_ui_control drop constraint re_non_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_pkey')
begin
	alter table re_phone drop constraint re_phone_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_column_group_mapping_pkey')
begin
	alter table re_phone_column_group_mapping drop constraint re_phone_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_columngroup_pkey')
begin
	alter table re_phone_columngroup drop constraint re_phone_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_control_fkey_re_phone_section')
begin
	alter table re_phone_control drop constraint re_phone_control_fkey_re_phone_section
end

if exists(select 'x' from sysobjects where name = 're_phone_control_pkey')
begin
	alter table re_phone_control drop constraint re_phone_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_grid_fkey_re_phone_control')
begin
	alter table re_phone_grid drop constraint re_phone_grid_fkey_re_phone_control
end

if exists(select 'x' from sysobjects where name = 're_phone_grid_pkey')
begin
	alter table re_phone_grid drop constraint re_phone_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_grid_columngroup_pkey')
begin
	alter table re_phone_grid_columngroup drop constraint re_phone_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_page_fkey_re_phone')
begin
	alter table re_phone_page drop constraint re_phone_page_fkey_re_phone
end

if exists(select 'x' from sysobjects where name = 're_phone_page_pkey')
begin
	alter table re_phone_page drop constraint re_phone_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_phone_section_fkey_re_phone_page')
begin
	alter table re_phone_section drop constraint re_phone_section_fkey_re_phone_page
end

if exists(select 'x' from sysobjects where name = 're_phone_section_pkey')
begin
	alter table re_phone_section drop constraint re_phone_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_pivot_configure_pkey')
begin
	alter table re_pivot_configure drop constraint re_pivot_configure_pkey
end

if exists(select 'x' from sysobjects where name = 're_pivot_fields_pkey')
begin
	alter table re_pivot_fields drop constraint re_pivot_fields_pkey
end

if exists(select 'x' from sysobjects where name = 're_pivot_lang_extn_pkey')
begin
	alter table re_pivot_lang_extn drop constraint re_pivot_lang_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_publication_pkey')
begin
	alter table re_publication drop constraint re_publication_pkey
end

if exists(select 'x' from sysobjects where name = 're_publication_dataitem_fkey_re_publication')
begin
	alter table re_publication_dataitem drop constraint re_publication_dataitem_fkey_re_publication
end

if exists(select 'x' from sysobjects where name = 're_publication_dataitem_pkey')
begin
	alter table re_publication_dataitem drop constraint re_publication_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 're_publication_lng_extn_pkey')
begin
	alter table re_publication_lng_extn drop constraint re_publication_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_quick_code_mst_pkey')
begin
	alter table re_quick_code_mst drop constraint re_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 're_quick_code_mst_lng_extn_pkey')
begin
	alter table re_quick_code_mst_lng_extn drop constraint re_quick_code_mst_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_radio_button_default_flag')
begin
	alter table re_radio_button drop constraint Chk_re_radio_button_default_flag
end

if exists(select 'x' from sysobjects where name = 're_radio_button_pkey')
begin
	alter table re_radio_button drop constraint re_radio_button_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_radio_button_lng_extn_default_flag')
begin
	alter table re_radio_button_lng_extn drop constraint Chk_re_radio_button_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_radio_button_lng_extn_pkey')
begin
	alter table re_radio_button_lng_extn drop constraint re_radio_button_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_report_action_dataset_pkey')
begin
	alter table re_report_action_dataset drop constraint re_report_action_dataset_pkey
end

if exists(select 'x' from sysobjects where name = 're_resolved_link_pkey')
begin
	alter table re_resolved_link drop constraint re_resolved_link_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_resolved_link_dataitem_published_flow_direction')
begin
	alter table re_resolved_link_dataitem drop constraint Chk_re_resolved_link_dataitem_published_flow_direction
end

if exists(select 'x' from sysobjects where name = 'Chk_re_resolved_link_dataitem_subscribed_flow_direction')
begin
	alter table re_resolved_link_dataitem drop constraint Chk_re_resolved_link_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 're_resolved_link_dataitem_fkey_re_resolved_link')
begin
	alter table re_resolved_link_dataitem drop constraint re_resolved_link_dataitem_fkey_re_resolved_link
end

if exists(select 'x' from sysobjects where name = 're_resolved_link_dataitem_pkey')
begin
	alter table re_resolved_link_dataitem drop constraint re_resolved_link_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 're_resolved_link_dataitem_mr_pop_pkey')
begin
	alter table re_resolved_link_dataitem_mr_pop drop constraint re_resolved_link_dataitem_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 're_resolved_link_mr_pop_pkey')
begin
	alter table re_resolved_link_mr_pop drop constraint re_resolved_link_mr_pop_pkey
end

if exists(select 'x' from sysobjects where name = 're_resolvelist_data_map_PKey')
begin
	alter table re_resolvelist_data_map drop constraint re_resolvelist_data_map_PKey
end

if exists(select 'x' from sysobjects where name = 're_rmt_ecr_ui_pkey')
begin
	alter table re_rmt_ecr_ui drop constraint re_rmt_ecr_ui_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_rulegroup_exposed_flag')
begin
	alter table re_rulegroup drop constraint Chk_re_rulegroup_exposed_flag
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_pkey')
begin
	alter table re_rulegroup drop constraint re_rulegroup_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_rulegroup_lng_extn_exposed_flag')
begin
	alter table re_rulegroup_lng_extn drop constraint Chk_re_rulegroup_lng_extn_exposed_flag
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_lng_extn_pkey')
begin
	alter table re_rulegroup_lng_extn drop constraint re_rulegroup_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_fkey_re_rulegroup')
begin
	alter table re_rulegroup_step drop constraint re_rulegroup_step_fkey_re_rulegroup
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_pkey')
begin
	alter table re_rulegroup_step drop constraint re_rulegroup_step_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_rulegroup_step_msg_default_flag')
begin
	alter table re_rulegroup_step_msg drop constraint Chk_re_rulegroup_step_msg_default_flag
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_msg_fkey_re_rulegroup_step')
begin
	alter table re_rulegroup_step_msg drop constraint re_rulegroup_step_msg_fkey_re_rulegroup_step
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_msg_pkey')
begin
	alter table re_rulegroup_step_msg drop constraint re_rulegroup_step_msg_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_rulegroup_step_msg_lng_extn_default_flag')
begin
	alter table re_rulegroup_step_msg_lng_extn drop constraint Chk_re_rulegroup_step_msg_lng_extn_default_flag
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_msg_lng_extn_fkey_re_rulegroup_step')
begin
	alter table re_rulegroup_step_msg_lng_extn drop constraint re_rulegroup_step_msg_lng_extn_fkey_re_rulegroup_step
end

if exists(select 'x' from sysobjects where name = 're_rulegroup_step_msg_lng_extn_pkey')
begin
	alter table re_rulegroup_step_msg_lng_extn drop constraint re_rulegroup_step_msg_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_subscription_link_type')
begin
	alter table re_subscription drop constraint Chk_re_subscription_link_type
end

if exists(select 'x' from sysobjects where name = 're_subscription_pkey')
begin
	alter table re_subscription drop constraint re_subscription_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_subscription_dataitem_subscribed_flow_direction')
begin
	alter table re_subscription_dataitem drop constraint Chk_re_subscription_dataitem_subscribed_flow_direction
end

if exists(select 'x' from sysobjects where name = 're_subscription_dataitem_fkey_re_subscription')
begin
	alter table re_subscription_dataitem drop constraint re_subscription_dataitem_fkey_re_subscription
end

if exists(select 'x' from sysobjects where name = 're_subscription_dataitem_pkey')
begin
	alter table re_subscription_dataitem drop constraint re_subscription_dataitem_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_subscription_lng_extn_link_type')
begin
	alter table re_subscription_lng_extn drop constraint Chk_re_subscription_lng_extn_link_type
end

if exists(select 'x' from sysobjects where name = 're_subscription_lng_extn_pkey')
begin
	alter table re_subscription_lng_extn drop constraint re_subscription_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_sync_view_pkey')
begin
	alter table re_sync_view drop constraint re_sync_view_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_pkey')
begin
	alter table re_tablet drop constraint re_tablet_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_column_group_mapping_pkey')
begin
	alter table re_tablet_column_group_mapping drop constraint re_tablet_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_columngroup_pkey')
begin
	alter table re_tablet_columngroup drop constraint re_tablet_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_control_fkey_re_tablet_section')
begin
	alter table re_tablet_control drop constraint re_tablet_control_fkey_re_tablet_section
end

if exists(select 'x' from sysobjects where name = 're_tablet_control_pkey')
begin
	alter table re_tablet_control drop constraint re_tablet_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_grid_fkey_re_tablet_control')
begin
	alter table re_tablet_grid drop constraint re_tablet_grid_fkey_re_tablet_control
end

if exists(select 'x' from sysobjects where name = 're_tablet_grid_pkey')
begin
	alter table re_tablet_grid drop constraint re_tablet_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_grid_columngroup_pkey')
begin
	alter table re_tablet_grid_columngroup drop constraint re_tablet_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_page_fkey_re_tablet')
begin
	alter table re_tablet_page drop constraint re_tablet_page_fkey_re_tablet
end

if exists(select 'x' from sysobjects where name = 're_tablet_page_pkey')
begin
	alter table re_tablet_page drop constraint re_tablet_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_tablet_section_fkey_re_tablet_page')
begin
	alter table re_tablet_section drop constraint re_tablet_section_fkey_re_tablet_page
end

if exists(select 'x' from sysobjects where name = 're_tablet_section_pkey')
begin
	alter table re_tablet_section drop constraint re_tablet_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_Templates_pk')
begin
	alter table re_Templates drop constraint re_Templates_pk
end

if exists(select 'x' from sysobjects where name = 're_tree_dtl_pkey')
begin
	alter table re_tree_dtl drop constraint re_tree_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 're_tree_sample_data_pkey')
begin
	alter table re_tree_sample_data drop constraint re_tree_sample_data_pkey
end

if exists(select 'x' from sysobjects where name = 're_tree_sample_data_map_pkey')
begin
	alter table re_tree_sample_data_map drop constraint re_tree_sample_data_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_caption_alignment')
begin
	alter table re_ui drop constraint Chk_re_ui_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_trail_bar')
begin
	alter table re_ui drop constraint Chk_re_ui_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_ui_format')
begin
	alter table re_ui drop constraint Chk_re_ui_ui_format
end

if exists(select 'x' from sysobjects where name = 're_ui_pkey')
begin
	alter table re_ui drop constraint re_ui_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_column_group_mapping_pkey')
begin
	alter table re_ui_column_group_mapping drop constraint re_ui_column_group_mapping_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_columngroup_pkey')
begin
	alter table re_ui_columngroup drop constraint re_ui_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_combolink_pkey')
begin
	alter table re_ui_combolink drop constraint re_ui_combolink_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_contextmenu_task_dtl_pk')
begin
	alter table re_ui_contextmenu_task_dtl drop constraint re_ui_contextmenu_task_dtl_pk
end

if exists(select 'x' from sysobjects where name = 're_ui_control_pkey')
begin
	alter table re_ui_control drop constraint re_ui_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_control_lng_extn_pkey')
begin
	alter table re_ui_control_lng_extn drop constraint re_ui_control_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_device_pkey')
begin
	alter table re_ui_device drop constraint re_ui_device_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_device_control_pkey')
begin
	alter table re_ui_device_control drop constraint re_ui_device_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_device_grid_fkey_re_ui_grid')
begin
	alter table re_ui_device_grid drop constraint re_ui_device_grid_fkey_re_ui_grid
end

if exists(select 'x' from sysobjects where name = 're_ui_device_grid_pkey')
begin
	alter table re_ui_device_grid drop constraint re_ui_device_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_device_page_fkey_re_ui_page')
begin
	alter table re_ui_device_page drop constraint re_ui_device_page_fkey_re_ui_page
end

if exists(select 'x' from sysobjects where name = 're_ui_device_page_pkey')
begin
	alter table re_ui_device_page drop constraint re_ui_device_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_device_section_pkey')
begin
	alter table re_ui_device_section drop constraint re_ui_device_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_displaytext_lang_extn_PKey')
begin
	alter table re_ui_displaytext_lang_extn drop constraint re_ui_displaytext_lang_extn_PKey
end

if exists(select 'x' from sysobjects where name = 're_ui_ecr_pkey')
begin
	alter table re_ui_ecr drop constraint re_ui_ecr_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_grid_pkey')
begin
	alter table re_ui_grid drop constraint re_ui_grid_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_grid_columngroup_pkey')
begin
	alter table re_ui_grid_columngroup drop constraint re_ui_grid_columngroup_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_grid_lng_extn_pkey')
begin
	alter table re_ui_grid_lng_extn drop constraint re_ui_grid_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_lng_extn_caption_alignment')
begin
	alter table re_ui_lng_extn drop constraint Chk_re_ui_lng_extn_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_lng_extn_trail_bar')
begin
	alter table re_ui_lng_extn drop constraint Chk_re_ui_lng_extn_trail_bar
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_lng_extn_ui_format')
begin
	alter table re_ui_lng_extn drop constraint Chk_re_ui_lng_extn_ui_format
end

if exists(select 'x' from sysobjects where name = 're_ui_page_pkey')
begin
	alter table re_ui_page drop constraint re_ui_page_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_page_lng_extn_pkey')
begin
	alter table re_ui_page_lng_extn drop constraint re_ui_page_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_pageevents_pk')
begin
	alter table re_ui_pageevents drop constraint re_ui_pageevents_pk
end

if exists(select 'x' from sysobjects where name = 're_ui_placeholder_lng_extn_pk')
begin
	alter table re_ui_placeholder_lng_extn drop constraint re_ui_placeholder_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_border_required')
begin
	alter table re_ui_section drop constraint Chk_re_ui_section_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_title_required')
begin
	alter table re_ui_section drop constraint Chk_re_ui_section_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_visisble_flag')
begin
	alter table re_ui_section drop constraint Chk_re_ui_section_visisble_flag
end

if exists(select 'x' from sysobjects where name = 're_ui_section_pkey')
begin
	alter table re_ui_section drop constraint re_ui_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_section_control_map_pkey')
begin
	alter table re_ui_section_control_map drop constraint re_ui_section_control_map_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_lng_extn_border_required')
begin
	alter table re_ui_section_lng_extn drop constraint Chk_re_ui_section_lng_extn_border_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_lng_extn_title_alignment')
begin
	alter table re_ui_section_lng_extn drop constraint Chk_re_ui_section_lng_extn_title_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_lng_extn_title_required')
begin
	alter table re_ui_section_lng_extn drop constraint Chk_re_ui_section_lng_extn_title_required
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_section_lng_extn_visisble_flag')
begin
	alter table re_ui_section_lng_extn drop constraint Chk_re_ui_section_lng_extn_visisble_flag
end

if exists(select 'x' from sysobjects where name = 're_ui_section_lng_extn_pkey')
begin
	alter table re_ui_section_lng_extn drop constraint re_ui_section_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_state_pkey')
begin
	alter table re_ui_state drop constraint re_ui_state_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_state_column_fkey_re_ui_grid')
begin
	alter table re_ui_state_column drop constraint re_ui_state_column_fkey_re_ui_grid
end

if exists(select 'x' from sysobjects where name = 're_ui_state_column_PK')
begin
	alter table re_ui_state_column drop constraint re_ui_state_column_PK
end

if exists(select 'x' from sysobjects where name = 're_ui_state_control_Fkey_re_ui_control')
begin
	alter table re_ui_state_control drop constraint re_ui_state_control_Fkey_re_ui_control
end

if exists(select 'x' from sysobjects where name = 're_ui_state_control_pkey')
begin
	alter table re_ui_state_control drop constraint re_ui_state_control_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_state_page_fkey_re_ui_page')
begin
	alter table re_ui_state_page drop constraint re_ui_state_page_fkey_re_ui_page
end

if exists(select 'x' from sysobjects where name = 're_ui_state_page_PK')
begin
	alter table re_ui_state_page drop constraint re_ui_state_page_PK
end

if exists(select 'x' from sysobjects where name = 're_ui_state_section_Fkey_re_ui_section')
begin
	alter table re_ui_state_section drop constraint re_ui_state_section_Fkey_re_ui_section
end

if exists(select 'x' from sysobjects where name = 're_ui_state_section_pkey')
begin
	alter table re_ui_state_section drop constraint re_ui_state_section_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_state_task_pkey')
begin
	alter table re_ui_state_task drop constraint re_ui_state_task_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_state_task_mst_pkey')
begin
	alter table re_ui_state_task_mst drop constraint re_ui_state_task_mst_pkey
end

if exists(select 'x' from sysobjects where name = 're_ui_Temp_placeholders_pk')
begin
	alter table re_ui_Temp_placeholders drop constraint re_ui_Temp_placeholders_pk
end

if exists(select 'x' from sysobjects where name = 're_ui_template_controlmap_pk')
begin
	alter table re_ui_template_controlmap drop constraint re_ui_template_controlmap_pk
end

if exists(select 'x' from sysobjects where name = 're_ui_toolbar_PKey')
begin
	alter table re_ui_toolbar drop constraint re_ui_toolbar_PKey
end

if exists(select 'x' from sysobjects where name = 're_ui_toolbar_group_PKey')
begin
	alter table re_ui_toolbar_group drop constraint re_ui_toolbar_group_PKey
end

if exists(select 'x' from sysobjects where name = 're_ui_toolbar_mapping_PKey')
begin
	alter table re_ui_toolbar_mapping drop constraint re_ui_toolbar_mapping_PKey
end

if exists(select 'x' from sysobjects where name = 're_ui_tooltip_lng_extn_pk')
begin
	alter table re_ui_tooltip_lng_extn drop constraint re_ui_tooltip_lng_extn_pk
end

if exists(select 'x' from sysobjects where name = 'Chk_re_ui_traversal_link_type')
begin
	alter table re_ui_traversal drop constraint Chk_re_ui_traversal_link_type
end

if exists(select 'x' from sysobjects where name = 're_ui_traversal_pkey')
begin
	alter table re_ui_traversal drop constraint re_ui_traversal_pkey
end

if exists(select 'x' from sysobjects where name = 're_user_section_pkey')
begin
	alter table re_user_section drop constraint re_user_section_pkey
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_appvw_dtl')
begin
	alter table re_wsinp_appvw_dtl drop constraint pk_re_wsinp_appvw_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_appvw_dtl_fkey_re_wsinp_area_hdr')
begin
	alter table re_wsinp_appvw_dtl drop constraint re_wsinp_appvw_dtl_fkey_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_area_desc')
begin
	alter table re_wsinp_area_desc drop constraint pk_re_wsinp_area_desc
end

if exists(select 'x' from sysobjects where name = 're_wsinp_area_desc_fkey_re_wsinp_area_hdr')
begin
	alter table re_wsinp_area_desc drop constraint re_wsinp_area_desc_fkey_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_area_dtl')
begin
	alter table re_wsinp_area_dtl drop constraint pk_re_wsinp_area_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_area_dtl_fkey_re_wsinp_area_hdr')
begin
	alter table re_wsinp_area_dtl drop constraint re_wsinp_area_dtl_fkey_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_area_hdr')
begin
	alter table re_wsinp_area_hdr drop constraint pk_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 're_wsinp_area_hdr_fkey_re_wsinp_rcn_dtl')
begin
	alter table re_wsinp_area_hdr drop constraint re_wsinp_area_hdr_fkey_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_cat_desc_hdr')
begin
	alter table re_wsinp_cat_desc_hdr drop constraint pk_re_wsinp_cat_desc_hdr
end

if exists(select 'x' from sysobjects where name = 're_wsinp_cat_desc_hdr_fkey_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_cat_desc_hdr drop constraint re_wsinp_cat_desc_hdr_fkey_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_cat_hdr drop constraint pk_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 're_wsinp_cat_hdr_fkey_re_wsinp_area_hdr')
begin
	alter table re_wsinp_cat_hdr drop constraint re_wsinp_cat_hdr_fkey_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_cat_parameters')
begin
	alter table re_wsinp_cat_parameters drop constraint pk_re_wsinp_cat_parameters
end

if exists(select 'x' from sysobjects where name = 're_wsinp_cat_parameters_fkey_re_wsinp_def_wf_setup')
begin
	alter table re_wsinp_cat_parameters drop constraint re_wsinp_cat_parameters_fkey_re_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_con_security')
begin
	alter table re_wsinp_con_security drop constraint pk_re_wsinp_con_security
end

if exists(select 'x' from sysobjects where name = 're_wsinp_con_security_fkey_re_wsinp_rcn_dtl')
begin
	alter table re_wsinp_con_security drop constraint re_wsinp_con_security_fkey_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_def_msg_dtl')
begin
	alter table re_wsinp_def_msg_dtl drop constraint pk_re_wsinp_def_msg_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_def_msg_dtl_fkey_re_wsinp_tsk_state_dtl')
begin
	alter table re_wsinp_def_msg_dtl drop constraint re_wsinp_def_msg_dtl_fkey_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_def_wf_setup')
begin
	alter table re_wsinp_def_wf_setup drop constraint pk_re_wsinp_def_wf_setup
end

if exists(select 'x' from sysobjects where name = 're_wsinp_def_wf_setup_fkey_re_wsinp_area_hdr')
begin
	alter table re_wsinp_def_wf_setup drop constraint re_wsinp_def_wf_setup_fkey_re_wsinp_area_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_doc_flow_dtl')
begin
	alter table re_wsinp_doc_flow_dtl drop constraint pk_re_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_doc_flow_dtl_fkey_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_doc_flow_dtl drop constraint re_wsinp_doc_flow_dtl_fkey_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_docflow_msg_dtl')
begin
	alter table re_wsinp_docflow_msg_dtl drop constraint pk_re_wsinp_docflow_msg_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_docflow_msg_dtl_fkey_re_wsinp_doc_flow_dtl')
begin
	alter table re_wsinp_docflow_msg_dtl drop constraint re_wsinp_docflow_msg_dtl_fkey_re_wsinp_doc_flow_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_actcode')
begin
	alter table re_wsinp_nonrvw_actcode drop constraint pk_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_actcode_fkey_re_wsinp_nonrvw_compcode')
begin
	alter table re_wsinp_nonrvw_actcode drop constraint re_wsinp_nonrvw_actcode_fkey_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_actdesc')
begin
	alter table re_wsinp_nonrvw_actdesc drop constraint pk_re_wsinp_nonrvw_actdesc
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_actdesc_fkey_re_wsinp_nonrvw_actcode')
begin
	alter table re_wsinp_nonrvw_actdesc drop constraint re_wsinp_nonrvw_actdesc_fkey_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_compcode')
begin
	alter table re_wsinp_nonrvw_compcode drop constraint pk_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_compcode_fkey_re_wsinp_rcn_dtl')
begin
	alter table re_wsinp_nonrvw_compcode drop constraint re_wsinp_nonrvw_compcode_fkey_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_compdesc')
begin
	alter table re_wsinp_nonrvw_compdesc drop constraint pk_re_wsinp_nonrvw_compdesc
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_compdesc_fkey_re_wsinp_nonrvw_compcode')
begin
	alter table re_wsinp_nonrvw_compdesc drop constraint re_wsinp_nonrvw_compdesc_fkey_re_wsinp_nonrvw_compcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_taskcode')
begin
	alter table re_wsinp_nonrvw_taskcode drop constraint pk_re_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_taskcode_fkey_re_wsinp_nonrvw_actcode')
begin
	alter table re_wsinp_nonrvw_taskcode drop constraint re_wsinp_nonrvw_taskcode_fkey_re_wsinp_nonrvw_actcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_nonrvw_taskdesc')
begin
	alter table re_wsinp_nonrvw_taskdesc drop constraint pk_re_wsinp_nonrvw_taskdesc
end

if exists(select 'x' from sysobjects where name = 're_wsinp_nonrvw_taskdesc_fkey_re_wsinp_nonrvw_taskcode')
begin
	alter table re_wsinp_nonrvw_taskdesc drop constraint re_wsinp_nonrvw_taskdesc_fkey_re_wsinp_nonrvw_taskcode
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_qc_dtl')
begin
	alter table re_wsinp_qc_dtl drop constraint pk_re_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_qc_dtl_fkey_re_wsinp_qc_hdr')
begin
	alter table re_wsinp_qc_dtl drop constraint re_wsinp_qc_dtl_fkey_re_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_qc_hdr')
begin
	alter table re_wsinp_qc_hdr drop constraint pk_re_wsinp_qc_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_qc_lang_dtl')
begin
	alter table re_wsinp_qc_lang_dtl drop constraint pk_re_wsinp_qc_lang_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_qc_lang_dtl_fkey_re_wsinp_qc_dtl')
begin
	alter table re_wsinp_qc_lang_dtl drop constraint re_wsinp_qc_lang_dtl_fkey_re_wsinp_qc_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_rcn_dtl')
begin
	alter table re_wsinp_rcn_dtl drop constraint pk_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_security_dtl')
begin
	alter table re_wsinp_security_dtl drop constraint pk_re_wsinp_security_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_security_dtl_fkey_re_wsinp_secusr_dtl')
begin
	alter table re_wsinp_security_dtl drop constraint re_wsinp_security_dtl_fkey_re_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_secusr_dtl')
begin
	alter table re_wsinp_secusr_dtl drop constraint pk_re_wsinp_secusr_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_secusr_dtl_fkey_re_wsinp_rcn_dtl')
begin
	alter table re_wsinp_secusr_dtl drop constraint re_wsinp_secusr_dtl_fkey_re_wsinp_rcn_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_service_dtl')
begin
	alter table re_wsinp_service_dtl drop constraint pk_re_wsinp_service_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_service_dtl_fkey_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_service_dtl drop constraint re_wsinp_service_dtl_fkey_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_state_desc_dtl')
begin
	alter table re_wsinp_state_desc_dtl drop constraint pk_re_wsinp_state_desc_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_state_desc_dtl_fkey_re_wsinp_tsk_state_dtl')
begin
	alter table re_wsinp_state_desc_dtl drop constraint re_wsinp_state_desc_dtl_fkey_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_task_dtl')
begin
	alter table re_wsinp_task_dtl drop constraint pk_re_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_task_dtl_fkey_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_task_dtl drop constraint re_wsinp_task_dtl_fkey_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_tsk_state_dtl')
begin
	alter table re_wsinp_tsk_state_dtl drop constraint pk_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_tsk_state_dtl_fkey_re_wsinp_task_dtl')
begin
	alter table re_wsinp_tsk_state_dtl drop constraint re_wsinp_tsk_state_dtl_fkey_re_wsinp_task_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_tsk_stflow_dtl')
begin
	alter table re_wsinp_tsk_stflow_dtl drop constraint pk_re_wsinp_tsk_stflow_dtl
end

if exists(select 'x' from sysobjects where name = 're_wsinp_tsk_stflow_dtl_fkey_re_wsinp_tsk_state_dtl')
begin
	alter table re_wsinp_tsk_stflow_dtl drop constraint re_wsinp_tsk_stflow_dtl_fkey_re_wsinp_tsk_state_dtl
end

if exists(select 'x' from sysobjects where name = 'pk_re_wsinp_usr_noncon_task')
begin
	alter table re_wsinp_usr_noncon_task drop constraint pk_re_wsinp_usr_noncon_task
end

if exists(select 'x' from sysobjects where name = 're_wsinp_usr_noncon_task_fkey_re_wsinp_cat_hdr')
begin
	alter table re_wsinp_usr_noncon_task drop constraint re_wsinp_usr_noncon_task_fkey_re_wsinp_cat_hdr
end

if exists(select 'x' from sysobjects where name = 'PK_REN_CGConfig')
begin
	alter table REN_CGConfig drop constraint PK_REN_CGConfig
end

if exists(select 'x' from sysobjects where name = 'PK_REN_Temp_UI')
begin
	alter table REN_Temp_UI drop constraint PK_REN_Temp_UI
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Apkg_Ssafe_Dtl_Pkey')
begin
	alter table Rev_Eng_Apkg_Ssafe_Dtl drop constraint Rev_Eng_Apkg_Ssafe_Dtl_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_business_rule_Pkey')
begin
	alter table Rev_Eng_de_business_rule drop constraint Rev_Eng_de_business_rule_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_flowbr_Pkey')
begin
	alter table Rev_Eng_de_flowbr drop constraint Rev_Eng_de_flowbr_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_flowbr_br_error_Pkey')
begin
	alter table Rev_Eng_de_flowbr_br_error drop constraint Rev_Eng_de_flowbr_br_error_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_flowbr_combo_Pkey')
begin
	alter table Rev_Eng_de_flowbr_combo drop constraint Rev_Eng_de_flowbr_combo_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_flowbr_method_map_Pkey')
begin
	alter table Rev_Eng_de_flowbr_method_map drop constraint Rev_Eng_de_flowbr_method_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_flowbr_rule_map_Pkey')
begin
	alter table Rev_Eng_de_flowbr_rule_map drop constraint Rev_Eng_de_flowbr_rule_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_des_bro_Pkey')
begin
	alter table Rev_Eng_de_fw_des_bro drop constraint Rev_Eng_de_fw_des_bro_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_des_businessrule_Pkey')
begin
	alter table Rev_Eng_de_fw_des_businessrule drop constraint Rev_Eng_de_fw_des_businessrule_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_des_ilbo_actions_Pkey')
begin
	alter table Rev_Eng_de_fw_des_ilbo_actions drop constraint Rev_Eng_de_fw_des_ilbo_actions_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_des_processsection_br_is_Pkey')
begin
	alter table Rev_Eng_de_fw_des_processsection_br_is drop constraint Rev_Eng_de_fw_des_processsection_br_is_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_des_reqbr_desbr_Pkey')
begin
	alter table Rev_Eng_de_fw_des_reqbr_desbr drop constraint Rev_Eng_de_fw_des_reqbr_desbr_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_br_bterm_Pkey')
begin
	alter table Rev_Eng_de_fw_req_br_bterm drop constraint Rev_Eng_de_fw_req_br_bterm_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_br_documentation_Pkey')
begin
	alter table Rev_Eng_de_fw_req_br_documentation drop constraint Rev_Eng_de_fw_req_br_documentation_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_br_error_Pkey')
begin
	alter table Rev_Eng_de_fw_req_br_error drop constraint Rev_Eng_de_fw_req_br_error_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_br_error_placeholder_Pkey')
begin
	alter table Rev_Eng_de_fw_req_br_error_placeholder drop constraint Rev_Eng_de_fw_req_br_error_placeholder_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_businessrule_Pkey')
begin
	alter table Rev_Eng_de_fw_req_businessrule drop constraint Rev_Eng_de_fw_req_businessrule_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_state_activity_Pkey')
begin
	alter table Rev_Eng_de_fw_req_state_activity drop constraint Rev_Eng_de_fw_req_state_activity_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_state_component_Pkey')
begin
	alter table Rev_Eng_de_fw_req_state_component drop constraint Rev_Eng_de_fw_req_state_component_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_task_br_error_context_Pkey')
begin
	alter table Rev_Eng_de_fw_req_task_br_error_context drop constraint Rev_Eng_de_fw_req_task_br_error_context_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_task_rule_Pkey')
begin
	alter table Rev_Eng_de_fw_req_task_rule drop constraint Rev_Eng_de_fw_req_task_rule_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_fw_req_taskrulesynonym_map_Pkey')
begin
	alter table Rev_Eng_de_fw_req_taskrulesynonym_map drop constraint Rev_Eng_de_fw_req_taskrulesynonym_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_method_doc_Pkey')
begin
	alter table Rev_Eng_de_method_doc drop constraint Rev_Eng_de_method_doc_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_method_message_map_Pkey')
begin
	alter table Rev_Eng_de_method_message_map drop constraint Rev_Eng_de_method_message_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_refine_method_documentation_Pkey')
begin
	alter table Rev_Eng_de_refine_method_documentation drop constraint Rev_Eng_de_refine_method_documentation_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_refine_method_error_map_Pkey')
begin
	alter table Rev_Eng_de_refine_method_error_map drop constraint Rev_Eng_de_refine_method_error_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_refine_parameter_Pkey')
begin
	alter table Rev_Eng_de_refine_parameter drop constraint Rev_Eng_de_refine_parameter_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_rulegroup_Pkey')
begin
	alter table Rev_Eng_de_rulegroup drop constraint Rev_Eng_de_rulegroup_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_rulegroup_step_Pkey')
begin
	alter table Rev_Eng_de_rulegroup_step drop constraint Rev_Eng_de_rulegroup_step_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_rulegroup_step_msg_Pkey')
begin
	alter table Rev_Eng_de_rulegroup_step_msg drop constraint Rev_Eng_de_rulegroup_step_msg_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_service_logic_extn_dtl_Pkey')
begin
	alter table Rev_Eng_de_service_logic_extn_dtl drop constraint Rev_Eng_de_service_logic_extn_dtl_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_de_ui_ico_Pkey')
begin
	alter table Rev_Eng_de_ui_ico drop constraint Rev_Eng_de_ui_ico_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_em_scenario_function_wrk_Pkey')
begin
	alter table Rev_Eng_em_scenario_function_wrk drop constraint Rev_Eng_em_scenario_function_wrk_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_component_glossary_mst_Pkey')
begin
	alter table Rev_Eng_ep_component_glossary_mst drop constraint Rev_Eng_ep_component_glossary_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_component_glossary_mst_lng_extn_Pkey')
begin
	alter table Rev_Eng_ep_component_glossary_mst_lng_extn drop constraint Rev_Eng_ep_component_glossary_mst_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_deleted_task_dtl_Pkey')
begin
	alter table Rev_Eng_ep_deleted_task_dtl drop constraint Rev_Eng_ep_deleted_task_dtl_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_flowbr_mst_Pkey')
begin
	alter table Rev_Eng_ep_flowbr_mst drop constraint Rev_Eng_ep_flowbr_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_flowbr_mst_lng_extn_Pkey')
begin
	alter table Rev_Eng_ep_flowbr_mst_lng_extn drop constraint Rev_Eng_ep_flowbr_mst_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_ep_ui_req_dtl_Pkey')
begin
	alter table Rev_Eng_ep_ui_req_dtl drop constraint Rev_Eng_ep_ui_req_dtl_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_ctrl_type_mst_Pkey')
begin
	alter table Rev_Eng_es_comp_ctrl_type_mst drop constraint Rev_Eng_es_comp_ctrl_type_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_ctrl_type_mst_lng_extn_Pkey')
begin
	alter table Rev_Eng_es_comp_ctrl_type_mst_lng_extn drop constraint Rev_Eng_es_comp_ctrl_type_mst_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_hdn_ctrl_dtl_Pkey')
begin
	alter table Rev_Eng_es_comp_hdn_ctrl_dtl drop constraint Rev_Eng_es_comp_hdn_ctrl_dtl_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_param_mst_Pkey')
begin
	alter table Rev_Eng_es_comp_param_mst drop constraint Rev_Eng_es_comp_param_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_param_mst_lng_extn_Pkey')
begin
	alter table Rev_Eng_es_comp_param_mst_lng_extn drop constraint Rev_Eng_es_comp_param_mst_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_stat_ctrl_type_mst_Pkey')
begin
	alter table Rev_Eng_es_comp_stat_ctrl_type_mst drop constraint Rev_Eng_es_comp_stat_ctrl_type_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_stylesheet_Pkey')
begin
	alter table Rev_Eng_es_comp_stylesheet drop constraint Rev_Eng_es_comp_stylesheet_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_task_type_mst_Pkey')
begin
	alter table Rev_Eng_es_comp_task_type_mst drop constraint Rev_Eng_es_comp_task_type_mst_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_es_comp_task_type_mst_lng_extn_Pkey')
begin
	alter table Rev_Eng_es_comp_task_type_mst_lng_extn drop constraint Rev_Eng_es_comp_task_type_mst_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Activity_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Activity drop constraint Rev_Eng_Fw_Bpt_Activity_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Activity_UI_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Activity_UI drop constraint Rev_Eng_Fw_Bpt_Activity_UI_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_AssociatedBRs_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_AssociatedBRs drop constraint Rev_Eng_Fw_Bpt_AssociatedBRs_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_BR_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_BR drop constraint Rev_Eng_Fw_Bpt_BR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_BR_Associate_Events_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_BR_Associate_Events drop constraint Rev_Eng_Fw_Bpt_BR_Associate_Events_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_BR_Events_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_BR_Events drop constraint Rev_Eng_Fw_Bpt_BR_Events_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_BR_Feature_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_BR_Feature drop constraint Rev_Eng_Fw_Bpt_BR_Feature_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Component_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Component drop constraint Rev_Eng_Fw_Bpt_Component_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Function_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Function drop constraint Rev_Eng_Fw_Bpt_Function_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Function_Component_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Function_Component drop constraint Rev_Eng_Fw_Bpt_Function_Component_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_LinkUI_Events_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_LinkUI_Events drop constraint Rev_Eng_Fw_Bpt_LinkUI_Events_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Task_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Task drop constraint Rev_Eng_Fw_Bpt_Task_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs drop constraint Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_UI_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_UI drop constraint Rev_Eng_Fw_Bpt_UI_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_UI_Task_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_UI_Task drop constraint Rev_Eng_Fw_Bpt_UI_Task_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Bpt_UI_Task_BR_Pkey')
begin
	alter table Rev_Eng_Fw_Bpt_UI_Task_BR drop constraint Rev_Eng_Fw_Bpt_UI_Task_BR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Activity_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Activity drop constraint Rev_Eng_Fw_Cmt_Activity_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Activity_UI_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Activity_UI drop constraint Rev_Eng_Fw_Cmt_Activity_UI_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_AssociatedBRs_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_AssociatedBRs drop constraint Rev_Eng_Fw_Cmt_AssociatedBRs_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_BR_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_BR drop constraint Rev_Eng_Fw_Cmt_BR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_BR_Feature_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_BR_Feature drop constraint Rev_Eng_Fw_Cmt_BR_Feature_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Component_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Component drop constraint Rev_Eng_Fw_Cmt_Component_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Function_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Function drop constraint Rev_Eng_Fw_Cmt_Function_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Function_Component_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Function_Component drop constraint Rev_Eng_Fw_Cmt_Function_Component_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Task_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Task drop constraint Rev_Eng_Fw_Cmt_Task_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Task_BR_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Task_BR drop constraint Rev_Eng_Fw_Cmt_Task_BR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs drop constraint Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_UI_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_UI drop constraint Rev_Eng_Fw_Cmt_UI_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Cmt_UI_Task_Pkey')
begin
	alter table Rev_Eng_Fw_Cmt_UI_Task drop constraint Rev_Eng_Fw_Cmt_UI_Task_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Doc_BR_Pkey')
begin
	alter table Rev_Eng_Fw_Doc_BR drop constraint Rev_Eng_Fw_Doc_BR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Nia_genDoc_Activity_Pkey')
begin
	alter table Rev_Eng_Fw_Nia_genDoc_Activity drop constraint Rev_Eng_Fw_Nia_genDoc_Activity_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Nia_genDoc_Function_Pkey')
begin
	alter table Rev_Eng_Fw_Nia_genDoc_Function drop constraint Rev_Eng_Fw_Nia_genDoc_Function_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Nia_genDoc_UI_Pkey')
begin
	alter table Rev_Eng_Fw_Nia_genDoc_UI drop constraint Rev_Eng_Fw_Nia_genDoc_UI_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_OPC_CodeGenPath_Pkey')
begin
	alter table Rev_Eng_Fw_OPC_CodeGenPath drop constraint Rev_Eng_Fw_OPC_CodeGenPath_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_Bpt_RCN_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_Bpt_RCN drop constraint Rev_Eng_Fw_Rmt_Bpt_RCN_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_Cmt_ICO_details_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_Cmt_ICO_details drop constraint Rev_Eng_Fw_Rmt_Cmt_ICO_details_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_Cmt_RCN_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_Cmt_RCN drop constraint Rev_Eng_Fw_Rmt_Cmt_RCN_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR drop constraint Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR drop constraint Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR drop constraint Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR drop constraint Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_DirectRCN_FlowBR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_FlowBR drop constraint Rev_Eng_Fw_Rmt_DirectRCN_FlowBR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ECR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ECR drop constraint Rev_Eng_Fw_Rmt_ECR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ECR_ICO_Details_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ECR_ICO_Details drop constraint Rev_Eng_Fw_Rmt_ECR_ICO_Details_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ICO_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ICO drop constraint Rev_Eng_Fw_Rmt_ICO_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_RCN_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_RCN drop constraint Rev_Eng_Fw_Rmt_RCN_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ReleaseVersion_ECR_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_ECR drop constraint Rev_Eng_Fw_Rmt_ReleaseVersion_ECR_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ReleaseVersion_ICO_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_ICO drop constraint Rev_Eng_Fw_Rmt_ReleaseVersion_ICO_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_ReleaseVersion_RCN_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_RCN drop constraint Rev_Eng_Fw_Rmt_ReleaseVersion_RCN_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_Fw_Rmt_UserRole_Mapping_Pkey')
begin
	alter table Rev_Eng_Fw_Rmt_UserRole_Mapping drop constraint Rev_Eng_Fw_Rmt_UserRole_Mapping_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_business_rule_Pkey')
begin
	alter table Rev_Eng_re_business_rule drop constraint Rev_Eng_re_business_rule_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_business_rule_lng_extn_Pkey')
begin
	alter table Rev_Eng_re_business_rule_lng_extn drop constraint Rev_Eng_re_business_rule_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_dwd_flowbr_Pkey')
begin
	alter table Rev_Eng_re_dwd_flowbr drop constraint Rev_Eng_re_dwd_flowbr_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_dwd_flowbr_br_error_Pkey')
begin
	alter table Rev_Eng_re_dwd_flowbr_br_error drop constraint Rev_Eng_re_dwd_flowbr_br_error_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_dwd_flowbr_combo_Pkey')
begin
	alter table Rev_Eng_re_dwd_flowbr_combo drop constraint Rev_Eng_re_dwd_flowbr_combo_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_dwd_flowbr_rule_map_Pkey')
begin
	alter table Rev_Eng_re_dwd_flowbr_rule_map drop constraint Rev_Eng_re_dwd_flowbr_rule_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_Pkey')
begin
	alter table Rev_Eng_re_flowbr drop constraint Rev_Eng_re_flowbr_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_br_error_Pkey')
begin
	alter table Rev_Eng_re_flowbr_br_error drop constraint Rev_Eng_re_flowbr_br_error_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_br_error_lng_extn_Pkey')
begin
	alter table Rev_Eng_re_flowbr_br_error_lng_extn drop constraint Rev_Eng_re_flowbr_br_error_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_combo_Pkey')
begin
	alter table Rev_Eng_re_flowbr_combo drop constraint Rev_Eng_re_flowbr_combo_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_lng_extn_Pkey')
begin
	alter table Rev_Eng_re_flowbr_lng_extn drop constraint Rev_Eng_re_flowbr_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_flowbr_rule_map_Pkey')
begin
	alter table Rev_Eng_re_flowbr_rule_map drop constraint Rev_Eng_re_flowbr_rule_map_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_rulegroup_Pkey')
begin
	alter table Rev_Eng_re_rulegroup drop constraint Rev_Eng_re_rulegroup_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_rulegroup_lng_extn_Pkey')
begin
	alter table Rev_Eng_re_rulegroup_lng_extn drop constraint Rev_Eng_re_rulegroup_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_rulegroup_step_Pkey')
begin
	alter table Rev_Eng_re_rulegroup_step drop constraint Rev_Eng_re_rulegroup_step_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_rulegroup_step_msg_Pkey')
begin
	alter table Rev_Eng_re_rulegroup_step_msg drop constraint Rev_Eng_re_rulegroup_step_msg_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_rulegroup_step_msg_lng_extn_Pkey')
begin
	alter table Rev_Eng_re_rulegroup_step_msg_lng_extn drop constraint Rev_Eng_re_rulegroup_step_msg_lng_extn_Pkey
end

if exists(select 'x' from sysobjects where name = 'Rev_Eng_re_ui_ecr_Pkey')
begin
	alter table Rev_Eng_re_ui_ecr drop constraint Rev_Eng_re_ui_ecr_Pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_associated_deliverable_pkey')
begin
	alter table revmgmt_associated_deliverable drop constraint revmgmt_associated_deliverable_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_action_met_pkey')
begin
	alter table revmgmt_checklist_action_met drop constraint revmgmt_checklist_action_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_action_met_lng_extn_pkey')
begin
	alter table revmgmt_checklist_action_met_lng_extn drop constraint revmgmt_checklist_action_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_action_mst_pkey')
begin
	alter table revmgmt_checklist_action_mst drop constraint revmgmt_checklist_action_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_met_pkey')
begin
	alter table revmgmt_checklist_met drop constraint revmgmt_checklist_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_met_lng_extn_pkey')
begin
	alter table revmgmt_checklist_met_lng_extn drop constraint revmgmt_checklist_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_checklist_mst_pkey')
begin
	alter table revmgmt_checklist_mst drop constraint revmgmt_checklist_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_deliverable_level_pkey')
begin
	alter table revmgmt_deliverable_level drop constraint revmgmt_deliverable_level_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_deliverable_met_pkey')
begin
	alter table revmgmt_deliverable_met drop constraint revmgmt_deliverable_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_document_dtl_pkey')
begin
	alter table revmgmt_document_dtl drop constraint revmgmt_document_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_document_reviewer_pkey')
begin
	alter table revmgmt_document_reviewer drop constraint revmgmt_document_reviewer_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_document_user_pkey')
begin
	alter table revmgmt_document_user drop constraint revmgmt_document_user_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_documents_pkey')
begin
	alter table revmgmt_documents drop constraint revmgmt_documents_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_freeform_list_pkey')
begin
	alter table revmgmt_freeform_list drop constraint revmgmt_freeform_list_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_perform_chk_dtl_pkey')
begin
	alter table revmgmt_perform_chk_dtl drop constraint revmgmt_perform_chk_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_quick_code_met_pkey')
begin
	alter table revmgmt_quick_code_met drop constraint revmgmt_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewer_pkey')
begin
	alter table revmgmt_reviewer drop constraint revmgmt_reviewer_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewpoints_mst_pkey')
begin
	alter table revmgmt_reviewpoints_mst drop constraint revmgmt_reviewpoints_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewtype_chklist_mst_pkey')
begin
	alter table revmgmt_reviewtype_chklist_mst drop constraint revmgmt_reviewtype_chklist_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewtype_met_pkey')
begin
	alter table revmgmt_reviewtype_met drop constraint revmgmt_reviewtype_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewtype_met_lng_extn_pkey')
begin
	alter table revmgmt_reviewtype_met_lng_extn drop constraint revmgmt_reviewtype_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_reviewtype_mst_pkey')
begin
	alter table revmgmt_reviewtype_mst drop constraint revmgmt_reviewtype_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_revtype_delv_chklist_met_pkey')
begin
	alter table revmgmt_revtype_delv_chklist_met drop constraint revmgmt_revtype_delv_chklist_met_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_revtype_delv_map_pkey')
begin
	alter table revmgmt_revtype_delv_map drop constraint revmgmt_revtype_delv_map_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_rvpnts_rwtype_chklist_mst_pkey')
begin
	alter table revmgmt_rvpnts_rwtype_chklist_mst drop constraint revmgmt_rvpnts_rwtype_chklist_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_rvpnts_rwtype_mst_pkey')
begin
	alter table revmgmt_rvpnts_rwtype_mst drop constraint revmgmt_rvpnts_rwtype_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_user_pkey')
begin
	alter table revmgmt_user drop constraint revmgmt_user_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_user_freeform_action_list_pkey')
begin
	alter table revmgmt_user_freeform_action_list drop constraint revmgmt_user_freeform_action_list_pkey
end

if exists(select 'x' from sysobjects where name = 'revmgmt_user_rev_action_list_pkey')
begin
	alter table revmgmt_user_rev_action_list drop constraint revmgmt_user_rev_action_list_pkey
end

if exists(select 'x' from sysobjects where name = 'Rmt_Publish_DB_met_pkey')
begin
	alter table Rmt_Publish_DB_met drop constraint Rmt_Publish_DB_met_pkey
end

if exists(select 'x' from sysobjects where name = 'Rmt_Reference_Value_PK')
begin
	alter table Rmt_Reference_Value drop constraint Rmt_Reference_Value_PK
end

if exists(select 'x' from sysobjects where name = 'PK__sch_dlp_fin_note__33C23270')
begin
	alter table sch_dlp_fin_note drop constraint PK__sch_dlp_fin_note__33C23270
end

if exists(select 'x' from sysobjects where name = 'PK__sch_dlp_plan_ite__31D9E9FE')
begin
	alter table sch_dlp_plan_item drop constraint PK__sch_dlp_plan_ite__31D9E9FE
end

if exists(select 'x' from sysobjects where name = 'sch_dlp_plan_item_fkey_sch_dlp_fin_note')
begin
	alter table sch_dlp_plan_item drop constraint sch_dlp_plan_item_fkey_sch_dlp_fin_note
end

if exists(select 'x' from sysobjects where name = 'PK_sch_dlp_planner')
begin
	alter table sch_dlp_planner drop constraint PK_sch_dlp_planner
end

if exists(select 'x' from sysobjects where name = 'PK__sch_finalization__2A38C836')
begin
	alter table sch_finalization_note drop constraint PK__sch_finalization__2A38C836
end

if exists(select 'x' from sysobjects where name = 'PK__sch_finalized_pl__28507FC4')
begin
	alter table sch_finalized_plan_item drop constraint PK__sch_finalized_pl__28507FC4
end

if exists(select 'x' from sysobjects where name = 'sch_finalized_plan_item_fkey_sch_finalization_note')
begin
	alter table sch_finalized_plan_item drop constraint sch_finalized_plan_item_fkey_sch_finalization_note
end

if exists(select 'x' from sysobjects where name = 'PK__sch_finalized_re__26683752')
begin
	alter table sch_finalized_res_assign drop constraint PK__sch_finalized_re__26683752
end

if exists(select 'x' from sysobjects where name = 'sch_finalized_res_assign_fkey_sch_finalized_plan_item')
begin
	alter table sch_finalized_res_assign drop constraint sch_finalized_res_assign_fkey_sch_finalized_plan_item
end

if exists(select 'x' from sysobjects where name = 'sch_generate_task_temp_pkey')
begin
	alter table sch_generate_task_temp drop constraint sch_generate_task_temp_pkey
end

if exists(select 'x' from sysobjects where name = 'sch_plan_detail_arc_pkey')
begin
	alter table sch_plan_detail_arc drop constraint sch_plan_detail_arc_pkey
end

if exists(select 'x' from sysobjects where name = 'PK__sch_plan_item__194411B5')
begin
	alter table sch_plan_item drop constraint PK__sch_plan_item__194411B5
end

if exists(select 'x' from sysobjects where name = 'sch_quick_code_met_pkey')
begin
	alter table sch_quick_code_met drop constraint sch_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_sch_res_assign')
begin
	alter table sch_res_assign drop constraint PK_sch_res_assign
end

if exists(select 'x' from sysobjects where name = 'PK__sch_resource_cal__2E09591A')
begin
	alter table sch_resource_calendar drop constraint PK__sch_resource_cal__2E09591A
end

if exists(select 'x' from sysobjects where name = 'Schedule_Result_fkey_Problem')
begin
	alter table Schedule_Result drop constraint Schedule_Result_fkey_Problem
end

if exists(select 'x' from sysobjects where name = 'sql_objectTemp_cndx')
begin
	alter table sql_objectTemp drop constraint sql_objectTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_syscolumnsTemp_cndx')
begin
	alter table sql_syscolumnsTemp drop constraint sql_syscolumnsTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_syscommentsTemp_cndx')
begin
	alter table sql_syscommentsTemp drop constraint sql_syscommentsTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_sysindexesTemp_cndx')
begin
	alter table sql_sysindexesTemp drop constraint sql_sysindexesTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_sysindexkeysTemp_cndx')
begin
	alter table sql_sysindexkeysTemp drop constraint sql_sysindexkeysTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_sysobjectsTemp_cndx')
begin
	alter table sql_sysobjectsTemp drop constraint sql_sysobjectsTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_systypesTemp_cndx')
begin
	alter table sql_systypesTemp drop constraint sql_systypesTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_Xreference_cndx')
begin
	alter table sql_Xreference drop constraint sql_Xreference_cndx
end

if exists(select 'x' from sysobjects where name = 'sql_xrefTemp_cndx')
begin
	alter table sql_xrefTemp drop constraint sql_xrefTemp_cndx
end

if exists(select 'x' from sysobjects where name = 'ssc_quick_code_met_pkey')
begin
	alter table ssc_quick_code_met drop constraint ssc_quick_code_met_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_quick_code_met_lng_extn_pkey')
begin
	alter table ssc_quick_code_met_lng_extn drop constraint ssc_quick_code_met_lng_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_mst_pkey')
begin
	alter table ssc_sco_mst drop constraint ssc_sco_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_fkey_ssc_sco_mst')
begin
	alter table ssc_sco_sp drop constraint ssc_sco_sp_fkey_ssc_sco_mst
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_pkey')
begin
	alter table ssc_sco_sp drop constraint ssc_sco_sp_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_depends_fkey_ssc_sco_sp')
begin
	alter table ssc_sco_sp_depends drop constraint ssc_sco_sp_depends_fkey_ssc_sco_sp
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_depends_pkey')
begin
	alter table ssc_sco_sp_depends drop constraint ssc_sco_sp_depends_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_errors_fkey_ssc_sco_sp')
begin
	alter table ssc_sco_sp_errors drop constraint ssc_sco_sp_errors_fkey_ssc_sco_sp
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_errors_pkey')
begin
	alter table ssc_sco_sp_errors drop constraint ssc_sco_sp_errors_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_hst_pkey')
begin
	alter table ssc_sco_sp_hst drop constraint ssc_sco_sp_hst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_spec_fkey_ssc_sco_sp')
begin
	alter table ssc_sco_sp_spec drop constraint ssc_sco_sp_spec_fkey_ssc_sco_sp
end

if exists(select 'x' from sysobjects where name = 'ssc_sco_sp_spec_pkey')
begin
	alter table ssc_sco_sp_spec drop constraint ssc_sco_sp_spec_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_genxml_tmp_pkey')
begin
	alter table ssco_genxml_tmp drop constraint ssco_genxml_tmp_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_incorp_mst_pkey')
begin
	alter table ssco_incorp_mst drop constraint ssco_incorp_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_config_fkey_ssco_packset_mst')
begin
	alter table ssco_packset_config drop constraint ssco_packset_config_fkey_ssco_packset_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_config_pkey')
begin
	alter table ssco_packset_config drop constraint ssco_packset_config_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_mst_pkey')
begin
	alter table ssco_packset_mst drop constraint ssco_packset_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_rmobjects_fkey_ssco_packset_mst')
begin
	alter table ssco_packset_rmobjects drop constraint ssco_packset_rmobjects_fkey_ssco_packset_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_rmobjects_pkey')
begin
	alter table ssco_packset_rmobjects drop constraint ssco_packset_rmobjects_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_workschedule_fkey_ssco_packset_mst')
begin
	alter table ssco_packset_workschedule drop constraint ssco_packset_workschedule_fkey_ssco_packset_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_packset_workschedule_pkey')
begin
	alter table ssco_packset_workschedule drop constraint ssco_packset_workschedule_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_quick_code_mst_pkey')
begin
	alter table ssco_quick_code_mst drop constraint ssco_quick_code_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_comm_dtl_fkey_ssco_vendor_mst')
begin
	alter table ssco_vendor_comm_dtl drop constraint ssco_vendor_comm_dtl_fkey_ssco_vendor_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_comm_dtl_pkey')
begin
	alter table ssco_vendor_comm_dtl drop constraint ssco_vendor_comm_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_contact_dtl_fkey_ssco_vendor_mst')
begin
	alter table ssco_vendor_contact_dtl drop constraint ssco_vendor_contact_dtl_fkey_ssco_vendor_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_contact_dtl_pkey')
begin
	alter table ssco_vendor_contact_dtl drop constraint ssco_vendor_contact_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_custproj_map_fkey_ssco_vendor_mst')
begin
	alter table ssco_vendor_custproj_map drop constraint ssco_vendor_custproj_map_fkey_ssco_vendor_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_custproj_map_pkey')
begin
	alter table ssco_vendor_custproj_map drop constraint ssco_vendor_custproj_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_mst_pkey')
begin
	alter table ssco_vendor_mst drop constraint ssco_vendor_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_system_dtl_fkey_ssco_vendor_mst')
begin
	alter table ssco_vendor_system_dtl drop constraint ssco_vendor_system_dtl_fkey_ssco_vendor_mst
end

if exists(select 'x' from sysobjects where name = 'ssco_vendor_system_dtl_pkey')
begin
	alter table ssco_vendor_system_dtl drop constraint ssco_vendor_system_dtl_pkey
end

if exists(select 'x' from sysobjects where name = 'PK_stg_migration_activities')
begin
	alter table stg_migration_activities drop constraint PK_stg_migration_activities
end

if exists(select 'x' from sysobjects where name = 'PK_stg_migration_component')
begin
	alter table stg_migration_component drop constraint PK_stg_migration_component
end

if exists(select 'x' from sysobjects where name = 'UK_stg_migration_component')
begin
	alter table stg_migration_component drop constraint UK_stg_migration_component
end

if exists(select 'x' from sysobjects where name = 'PK_stg_migration_component_ecr')
begin
	alter table stg_migration_component_ecr drop constraint PK_stg_migration_component_ecr
end

if exists(select 'x' from sysobjects where name = 'PK_stg_migration_integservice')
begin
	alter table stg_migration_integservice drop constraint PK_stg_migration_integservice
end

if exists(select 'x' from sysobjects where name = 'temp_5103_mandatory_pkey')
begin
	alter table temp_5103_mandatory drop constraint temp_5103_mandatory_pkey
end

if exists(select 'x' from sysobjects where name = 'temp_5103_mandatory_col_PEKY')
begin
	alter table temp_5103_mandatory_col drop constraint temp_5103_mandatory_col_PEKY
end

if exists(select 'x' from sysobjects where name = 'TimeDetailsLog_fkey_Problem')
begin
	alter table TimeDetailsLog drop constraint TimeDetailsLog_fkey_Problem
end

if exists(select 'x' from sysobjects where name = 'ts_calendar_PKey')
begin
	alter table ts_calendar drop constraint ts_calendar_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_emp_solutioncenter_map_fkey_ts_empmaster')
begin
	alter table ts_emp_solutioncenter_map drop constraint ts_emp_solutioncenter_map_fkey_ts_empmaster
end

if exists(select 'x' from sysobjects where name = 'ts_emp_solutioncenter_map_fkey_ts_solutioncenter')
begin
	alter table ts_emp_solutioncenter_map drop constraint ts_emp_solutioncenter_map_fkey_ts_solutioncenter
end

if exists(select 'x' from sysobjects where name = 'ts_emp_solutioncenter_map_PKey')
begin
	alter table ts_emp_solutioncenter_map drop constraint ts_emp_solutioncenter_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_emp_taskmaster_PKey')
begin
	alter table ts_emp_taskmaster drop constraint ts_emp_taskmaster_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_emp_taskmaster_booking_his_PKey')
begin
	alter table ts_emp_taskmaster_booking_his drop constraint ts_emp_taskmaster_booking_his_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_emp_taskmaster_his_PKey')
begin
	alter table ts_emp_taskmaster_his drop constraint ts_emp_taskmaster_his_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_empmaster_PKey')
begin
	alter table ts_empmaster drop constraint ts_empmaster_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_management_preferance_fkey_ts_solutioncenter')
begin
	alter table ts_management_preferance drop constraint ts_management_preferance_fkey_ts_solutioncenter
end

if exists(select 'x' from sysobjects where name = 'ts_management_preferance_PKey')
begin
	alter table ts_management_preferance drop constraint ts_management_preferance_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_Primarysupervisor_emp_map_pkey')
begin
	alter table ts_Primarysupervisor_emp_map drop constraint ts_Primarysupervisor_emp_map_pkey
end

if exists(select 'x' from sysobjects where name = 'ts_project_emp_cost_PKey')
begin
	alter table ts_project_emp_cost drop constraint ts_project_emp_cost_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_project_ref_forcosting_metadata_PKey')
begin
	alter table ts_project_ref_forcosting_metadata drop constraint ts_project_ref_forcosting_metadata_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_project_solutioncenter_map_fkey_ts_projectmaster')
begin
	alter table ts_project_solutioncenter_map drop constraint ts_project_solutioncenter_map_fkey_ts_projectmaster
end

if exists(select 'x' from sysobjects where name = 'ts_project_solutioncenter_map_fkey_ts_solutioncenter')
begin
	alter table ts_project_solutioncenter_map drop constraint ts_project_solutioncenter_map_fkey_ts_solutioncenter
end

if exists(select 'x' from sysobjects where name = 'ts_project_solutioncenter_map_PKey')
begin
	alter table ts_project_solutioncenter_map drop constraint ts_project_solutioncenter_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_projectmaster_PKey')
begin
	alter table ts_projectmaster drop constraint ts_projectmaster_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_quickcode_met_PKey')
begin
	alter table ts_quickcode_met drop constraint ts_quickcode_met_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_solutioncenter_PKey')
begin
	alter table ts_solutioncenter drop constraint ts_solutioncenter_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_solutioncenter_project_emp_map_PKey')
begin
	alter table ts_solutioncenter_project_emp_map drop constraint ts_solutioncenter_project_emp_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_supervisor_emp_map_fkey_ts_empmaster')
begin
	alter table ts_supervisor_emp_map drop constraint ts_supervisor_emp_map_fkey_ts_empmaster
end

if exists(select 'x' from sysobjects where name = 'ts_supervisor_emp_map_fkey_ts_projectmaster')
begin
	alter table ts_supervisor_emp_map drop constraint ts_supervisor_emp_map_fkey_ts_projectmaster
end

if exists(select 'x' from sysobjects where name = 'ts_supervisor_emp_map_PKey')
begin
	alter table ts_supervisor_emp_map drop constraint ts_supervisor_emp_map_PKey
end

if exists(select 'x' from sysobjects where name = 'ts_timebooking_fkey_ts_empmaster')
begin
	alter table ts_timebooking drop constraint ts_timebooking_fkey_ts_empmaster
end

if exists(select 'x' from sysobjects where name = 'ts_timebooking_fkey_ts_projectmaster')
begin
	alter table ts_timebooking drop constraint ts_timebooking_fkey_ts_projectmaster
end

if exists(select 'x' from sysobjects where name = 'ts_timebooking_PKey')
begin
	alter table ts_timebooking drop constraint ts_timebooking_PKey
end

if exists(select 'x' from sysobjects where name = 'XPKVID_APP_PREF')
begin
	alter table VID_APP_PREF drop constraint XPKVID_APP_PREF
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CHART_CONFIG_TMP')
begin
	alter table VID_CHART_CONFIG_TMP drop constraint pk_VID_CHART_CONFIG_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHART_CONFIG_TMP_fkey_VID_CHARTS_TMP')
begin
	alter table VID_CHART_CONFIG_TMP drop constraint VID_CHART_CONFIG_TMP_fkey_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHART_DATA_TMP_fkey_VID_CHARTS_TMP')
begin
	alter table VID_CHART_DATA_TMP drop constraint VID_CHART_DATA_TMP_fkey_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CHART_SERIES_TMP')
begin
	alter table VID_CHART_SERIES_TMP drop constraint pk_VID_CHART_SERIES_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHART_SERIES_TMP_fkey_VID_CHARTS_TMP')
begin
	alter table VID_CHART_SERIES_TMP drop constraint VID_CHART_SERIES_TMP_fkey_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CHART_XAXIS_TMP')
begin
	alter table VID_CHART_XAXIS_TMP drop constraint pk_VID_CHART_XAXIS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHART_XAXIS_TMP_fkey_VID_CHARTS_TMP')
begin
	alter table VID_CHART_XAXIS_TMP drop constraint VID_CHART_XAXIS_TMP_fkey_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CHART_YAXIS_TMP')
begin
	alter table VID_CHART_YAXIS_TMP drop constraint pk_VID_CHART_YAXIS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHART_YAXIS_TMP_fkey_VID_CHARTS_TMP')
begin
	alter table VID_CHART_YAXIS_TMP drop constraint VID_CHART_YAXIS_TMP_fkey_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CHARTS_TMP')
begin
	alter table VID_CHARTS_TMP drop constraint pk_VID_CHARTS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CHARTS_TMP_fkey_VID_SECTIONS_TMP')
begin
	alter table VID_CHARTS_TMP drop constraint VID_CHARTS_TMP_fkey_VID_SECTIONS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_CONTROLS_TMP')
begin
	alter table VID_CONTROLS_TMP drop constraint pk_VID_CONTROLS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_CONTROLS_TMP_fkey_VID_SECTIONS_TMP')
begin
	alter table VID_CONTROLS_TMP drop constraint VID_CONTROLS_TMP_fkey_VID_SECTIONS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_ENUMVALUES_TMP')
begin
	alter table VID_ENUMVALUES_TMP drop constraint pk_VID_ENUMVALUES_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_ENUMVALUES_TMP_fkey_VID_CONTROLS_TMP')
begin
	alter table VID_ENUMVALUES_TMP drop constraint VID_ENUMVALUES_TMP_fkey_VID_CONTROLS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_GRIDCOLUMNS_TMP')
begin
	alter table VID_GRIDCOLUMNS_TMP drop constraint pk_VID_GRIDCOLUMNS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_GRIDCOLUMNS_TMP_fkey_VID_CONTROLS_TMP')
begin
	alter table VID_GRIDCOLUMNS_TMP drop constraint VID_GRIDCOLUMNS_TMP_fkey_VID_CONTROLS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_ILBO_TMP')
begin
	alter table VID_ILBO_TMP drop constraint pk_VID_ILBO_TMP
end

if exists(select 'x' from sysobjects where name = 'XPKvid_obj_base')
begin
	alter table vid_obj_base drop constraint XPKvid_obj_base
end

if exists(select 'x' from sysobjects where name = 'pk_VID_PAGES_TMP')
begin
	alter table VID_PAGES_TMP drop constraint pk_VID_PAGES_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_PAGES_TMP_fkey_VID_ILBO_TMP')
begin
	alter table VID_PAGES_TMP drop constraint VID_PAGES_TMP_fkey_VID_ILBO_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_RADIOBUTTONS_TMP')
begin
	alter table VID_RADIOBUTTONS_TMP drop constraint pk_VID_RADIOBUTTONS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_RADIOBUTTONS_TMP_fkey_VID_CONTROLS_TMP')
begin
	alter table VID_RADIOBUTTONS_TMP drop constraint VID_RADIOBUTTONS_TMP_fkey_VID_CONTROLS_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_SECTIONS_TMP')
begin
	alter table VID_SECTIONS_TMP drop constraint pk_VID_SECTIONS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_SECTIONS_TMP_fkey_VID_PAGES_TMP')
begin
	alter table VID_SECTIONS_TMP drop constraint VID_SECTIONS_TMP_fkey_VID_PAGES_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_TREE_NTS_TMP')
begin
	alter table VID_TREE_NTS_TMP drop constraint pk_VID_TREE_NTS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_TREE_NTS_TMP_fkey_VID_TREES_TMP')
begin
	alter table VID_TREE_NTS_TMP drop constraint VID_TREE_NTS_TMP_fkey_VID_TREES_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_TREECONTROLS_TMP')
begin
	alter table VID_TREECONTROLS_TMP drop constraint pk_VID_TREECONTROLS_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_TREECONTROLS_TMP_fkey_VID_TREES_TMP')
begin
	alter table VID_TREECONTROLS_TMP drop constraint VID_TREECONTROLS_TMP_fkey_VID_TREES_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_TREENODES_TMP')
begin
	alter table VID_TREENODES_TMP drop constraint pk_VID_TREENODES_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_TREENODES_TMP_fkey_VID_TREES_TMP')
begin
	alter table VID_TREENODES_TMP drop constraint VID_TREENODES_TMP_fkey_VID_TREES_TMP
end

if exists(select 'x' from sysobjects where name = 'pk_VID_TREES_TMP')
begin
	alter table VID_TREES_TMP drop constraint pk_VID_TREES_TMP
end

if exists(select 'x' from sysobjects where name = 'VID_TREES_TMP_fkey_VID_SECTIONS_TMP')
begin
	alter table VID_TREES_TMP drop constraint VID_TREES_TMP_fkey_VID_SECTIONS_TMP
end

-- Added for the Request TECH-43307 Starts
IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_ui_section_refinement')
BEGIN
	ALTER table ep_ui_section_refinement DROP CONSTRAINT PK_ep_ui_section_refinement 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_responsive_sec_weightage')
BEGIN
	ALTER table ep_responsive_sec_weightage DROP CONSTRAINT PK_ep_responsive_sec_weightage 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_ui_section_refinement')
BEGIN
	ALTER table re_ui_section_refinement DROP CONSTRAINT PK_re_ui_section_refinement 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_responsive_sec_weightage')
BEGIN
	ALTER table re_responsive_sec_weightage DROP CONSTRAINT PK_re_responsive_sec_weightage 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_ui_section_refinement')
BEGIN
	ALTER table de_ui_section_refinement DROP CONSTRAINT PK_de_ui_section_refinement 
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_responsive_sec_weightage')
BEGIN
	ALTER table de_responsive_sec_weightage DROP CONSTRAINT PK_de_responsive_sec_weightage 
END
GO
-- Added for the Request TECH-43307 Ends

/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Feb 2020
Purpose 		For Droping Constraints
********************************************************************************/

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_processsection_br_is_executionflag')
begin
	alter table de_fw_des_processsection_br_is drop constraint Chk_de_fw_des_processsection_br_is_executionflag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_fw_des_processsection_br_is_isbr')
begin
	alter table de_fw_des_processsection_br_is drop constraint Chk_de_fw_des_processsection_br_is_isbr
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_fkey_de_fw_des_businessrule')
begin
	alter table de_fw_des_processsection_br_is drop constraint de_fw_des_processsection_br_is_fkey_de_fw_des_businessrule
end

if exists(select 'x' from sysobjects where name = 'de_fw_des_processsection_br_is_fkey_de_fw_des_processsection')
begin
	alter table de_fw_des_processsection_br_is drop constraint de_fw_des_processsection_br_is_fkey_de_fw_des_processsection
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_pathoperationparameter_serv_map')
begin
	alter table fw_des_api_pathoperationparameter_serv_map drop constraint PK_fw_des_api_pathoperationparameter_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_pathoperationparameter_task_map')
begin
	alter table fw_des_api_pathoperationparameter_task_map drop constraint PK_fw_des_api_pathoperationparameter_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_pathparameter_serv_map')
begin
	alter table fw_des_api_pathparameter_serv_map drop constraint PK_fw_des_api_pathparameter_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_pathparameter_task_map')
begin
	alter table fw_des_api_pathparameter_task_map drop constraint PK_fw_des_api_pathparameter_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_request_serv_map')
begin
	alter table fw_des_api_request_serv_map drop constraint PK_fw_des_api_request_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_request_task_map')
begin
	alter table fw_des_api_request_task_map drop constraint PK_fw_des_api_request_task_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_response_serv_map')
begin
	alter table fw_des_api_response_serv_map drop constraint PK_fw_des_api_response_serv_map
end

if exists(select 'x' from sysobjects where name = 'PK_fw_des_api_response_task_map')
begin
	alter table fw_des_api_response_task_map drop constraint PK_fw_des_api_response_task_map
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_processsection_br_is_createddate')
begin
	alter table de_fw_des_processsection_br_is drop constraint def_de_fw_des_processsection_br_is_createddate
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_processsection_br_is_executionflag')
begin
	alter table de_fw_des_processsection_br_is drop constraint def_de_fw_des_processsection_br_is_executionflag
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_processsection_br_is_isbr')
begin
	alter table de_fw_des_processsection_br_is drop constraint def_de_fw_des_processsection_br_is_isbr
end

if exists(select 'x' from sysobjects where name = 'def_de_fw_des_processsection_br_is_modifieddate')
begin
	alter table de_fw_des_processsection_br_is drop constraint def_de_fw_des_processsection_br_is_modifieddate
end

-- Added for Elastic Search & UPE


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ListEdit_map')
BEGIN
       ALTER table de_els_query_listedit_map DROP CONSTRAINT PK_de_els_query_ListEdit_map
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ListEdit_input')
BEGIN
       ALTER table de_els_query_listedit_input DROP CONSTRAINT PK_de_els_query_ListEdit_input
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ListEdit_result')
BEGIN
       ALTER table de_els_query_listedit_result DROP CONSTRAINT PK_de_els_query_ListEdit_result
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ps_map')
BEGIN
       ALTER table de_els_query_ps_map DROP CONSTRAINT PK_de_els_query_ps_map
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ps_input')
BEGIN
       ALTER table de_els_query_ps_input DROP CONSTRAINT PK_de_els_query_ps_input
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_de_els_query_ps_result')
BEGIN
       ALTER table de_els_query_ps_result DROP CONSTRAINT PK_de_els_query_ps_result
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_els_query_ListEdit_map')
BEGIN
       ALTER table ep_els_query_listedit_map DROP CONSTRAINT PK_ep_els_query_ListEdit_map
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_els_query_ListEdit_input')
BEGIN
       ALTER table ep_els_query_listedit_input DROP CONSTRAINT PK_ep_els_query_ListEdit_input
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_ep_els_query_ListEdit_result')
BEGIN
       ALTER table ep_els_query_listedit_result DROP CONSTRAINT PK_ep_els_query_ListEdit_result
END
GO


IF EXISTS(select 'x' from sysobjects where name = 'PK_re_els_query_ListEdit_map')
BEGIN
       ALTER table re_els_query_listedit_map DROP CONSTRAINT PK_re_els_query_ListEdit_map
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_els_query_ListEdit_input')
BEGIN
       ALTER table re_els_query_listedit_input DROP CONSTRAINT PK_re_els_query_ListEdit_input
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_re_els_query_ListEdit_result')
BEGIN
       ALTER table re_els_query_listedit_result DROP CONSTRAINT PK_re_els_query_ListEdit_result
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_upe_control')
BEGIN
       ALTER table de_upe_control DROP CONSTRAINT PK_de_upe_control
END
GO

IF EXISTS(select 'x' from sysobjects where name = 'PK_de_upe_control_parameters')
BEGIN
       ALTER table de_upe_control_parameters DROP CONSTRAINT PK_de_upe_control_parameters
END
GO

--code added for the defect-id Tech-60451 starts
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_ep_ui_grid_extension')
BEGIN
       ALTER TABLE ep_ui_grid_extension DROP CONSTRAINT PK_ep_ui_grid_extension
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_re_ui_grid_extension')
BEGIN
       ALTER TABLE re_ui_grid_extension DROP CONSTRAINT PK_re_ui_grid_extension
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_ui_grid_Extension')
BEGIN
       ALTER TABLE de_ui_grid_Extension DROP CONSTRAINT PK_de_ui_grid_Extension
END
GO
--code added for the defect-id Tech-60451 Ends

---Code Added For New Feature--Task API Mapping  for the defect id Tech-61144 starts 
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_plf_api_info')
BEGIN
       ALTER TABLE plf_api_info DROP CONSTRAINT PK_plf_api_info
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_plf_api_Parameter_info')
BEGIN
       ALTER TABLE plf_api_Parameter_info DROP CONSTRAINT PK_plf_api_Parameter_info
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_plf_api_Request_info')
BEGIN
       ALTER TABLE plf_api_Request_info DROP CONSTRAINT PK_plf_api_Request_info
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_plf_api_response_info')
BEGIN
       ALTER TABLE plf_api_response_info DROP CONSTRAINT PK_plf_api_response_info
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_api_mapping')
BEGIN
       ALTER TABLE de_task_api_mapping DROP CONSTRAINT PK_de_task_api_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_api_subtask')
BEGIN
       ALTER TABLE de_task_api_subtask DROP CONSTRAINT PK_de_task_api_subtask
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_api_parameter_map')
BEGIN
       ALTER TABLE de_task_api_parameter_map DROP CONSTRAINT PK_de_task_api_parameter_map
END
GO


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_api_request_map')
BEGIN
       ALTER TABLE de_task_api_request_map DROP CONSTRAINT PK_de_task_api_request_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_api_response_map')
BEGIN
       ALTER TABLE de_task_api_response_map DROP CONSTRAINT PK_de_task_api_response_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_subtask')
BEGIN
       ALTER TABLE de_subtask DROP CONSTRAINT PK_de_subtask
END
GO
-----Code Added For New Feature-Task API Mapping for the defect id TECH-61144  Ends

-----Code Added For  Feature--Task API Mapping  for the defect id Tech-61907 starts 
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_service_api_parameter_map')
BEGIN
       ALTER TABLE de_service_api_parameter_map DROP CONSTRAINT PK_de_service_api_parameter_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_service_api_request_map')
BEGIN
       ALTER TABLE de_service_api_request_map DROP CONSTRAINT PK_de_service_api_request_map
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_service_api_response_map')
BEGIN
       ALTER TABLE de_service_api_response_map DROP CONSTRAINT PK_de_service_api_response_map
END
GO
-----Code Added For Feature-Task API Mapping for the defect id TECH-61907  Ends

-----Code Added For Feature-Gql operation for the defect id TECH-63474  Starts


IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_query')
BEGIN
       ALTER TABLE fw_graphql_query DROP CONSTRAINT PK_fw_graphql_query
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_query_arguments')
BEGIN
       ALTER TABLE fw_graphql_query_arguments DROP CONSTRAINT PK_fw_graphql_query_arguments
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_query_fields')
BEGIN
       ALTER TABLE fw_graphql_query_fields DROP CONSTRAINT PK_fw_graphql_query_fields
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_sdl')
BEGIN
       ALTER TABLE fw_graphql_sdl DROP CONSTRAINT PK_fw_graphql_sdl
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_gql_mapping')
BEGIN
       ALTER TABLE de_task_gql_mapping DROP CONSTRAINT PK_de_task_gql_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_gql_argument_mapping')
BEGIN
       ALTER TABLE de_task_gql_argument_mapping DROP CONSTRAINT PK_de_task_gql_argument_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_task_gql_field_mapping')
BEGIN
       ALTER TABLE de_task_gql_field_mapping DROP CONSTRAINT PK_de_task_gql_field_mapping
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_de_gql_Schema')
BEGIN
       ALTER TABLE de_gql_Schema DROP CONSTRAINT PK_de_gql_Schema
END
GO

-----Code Added For Feature-Gql operation for the defect id TECH-63474  Ends

--Code added for the defect id : TECH-64197 starts

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_arg_fields')
BEGIN
       ALTER TABLE fw_graphql_arg_fields DROP CONSTRAINT PK_fw_graphql_arg_fields
END
GO

--Code added for the defect id : TECH-64197 ends

--Code Added for the Defect-Id : TECH-66583 Starts

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_caption_alignment')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_caption_position')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_caption_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_caption_wrap')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_ctrl_position')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_delete_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_editable_flag')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_ellipses_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_event_handling_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_help_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_insert_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_password_char')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_select_flag')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_visisble_flag')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_ctrl_type_mst_zoom_req')
begin
	alter table re_comp_ctrl_type_mst drop constraint Chk_re_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 're_comp_ctrl_type_mst_pkey')
begin
	alter table re_comp_ctrl_type_mst drop constraint re_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 're_comp_ctrl_type_mst_extn_pkey')
begin
	alter table re_comp_ctrl_type_mst_extn drop constraint re_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_clr_on_page_save')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_cond_ml_fetch')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_data_save_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_default_for')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_err_handle_method')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_hdr_check_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_hdr_fetch_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_hdr_ref_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_incl_place_holder')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_ml_fet_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_print_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_proc_sel_rows')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_refresh_on_save')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_task_confirmation')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_trn_scope_req')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_usr_role_map')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_re_comp_task_type_mst_valid_on_init')
begin
	alter table re_comp_task_type_mst drop constraint Chk_re_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 're_comp_task_type_mst_pkey')
begin
	alter table re_comp_task_type_mst drop constraint re_comp_task_type_mst_pkey
end

-------------------------------------------------------------------------------------------------------
if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_caption_alignment')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_caption_alignment
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_caption_position')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_caption_position
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_caption_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_caption_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_caption_wrap')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_caption_wrap
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_ctrl_position')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_ctrl_position
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_delete_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_delete_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_editable_flag')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_editable_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_ellipses_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_ellipses_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_event_handling_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_event_handling_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_help_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_help_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_insert_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_insert_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_mandatory_flag')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_mandatory_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_password_char')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_password_char
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_select_flag')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_select_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_visisble_flag')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_visisble_flag
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_ctrl_type_mst_zoom_req')
begin
	alter table de_comp_ctrl_type_mst drop constraint Chk_de_comp_ctrl_type_mst_zoom_req
end

if exists(select 'x' from sysobjects where name = 'de_comp_ctrl_type_mst_pkey')
begin
	alter table de_comp_ctrl_type_mst drop constraint de_comp_ctrl_type_mst_pkey
end

if exists(select 'x' from sysobjects where name = 'de_comp_ctrl_type_mst_extn_pkey')
begin
	alter table de_comp_ctrl_type_mst_extn drop constraint de_comp_ctrl_type_mst_extn_pkey
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_clr_on_page_save')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_clr_on_page_save
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_cond_ml_fetch')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_cond_ml_fetch
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_data_save_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_data_save_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_default_for')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_default_for
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_err_handle_method')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_err_handle_method
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_hdr_check_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_hdr_check_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_hdr_fetch_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_hdr_fetch_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_hdr_ref_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_hdr_ref_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_incl_place_holder')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_incl_place_holder
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_ml_fet_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_ml_fet_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_print_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_print_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_proc_sel_rows')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_proc_sel_rows
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_refresh_on_save')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_refresh_on_save
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_task_confirmation')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_task_confirmation
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_trn_scope_req')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_trn_scope_req
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_usr_role_map')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_usr_role_map
end

if exists(select 'x' from sysobjects where name = 'Chk_de_comp_task_type_mst_valid_on_init')
begin
	alter table de_comp_task_type_mst drop constraint Chk_de_comp_task_type_mst_valid_on_init
end

if exists(select 'x' from sysobjects where name = 'de_comp_task_type_mst_pkey')
begin
	alter table de_comp_task_type_mst drop constraint de_comp_task_type_mst_pkey
end

--Code Added for the Defect-Id : TECH-66583 Ends

--code added for defectid TECH-67697 starts
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_arg_fields_history')
BEGIN
       ALTER TABLE fw_graphql_arg_fields_history DROP CONSTRAINT PK_fw_graphql_arg_fields_history
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_query_history')
BEGIN
       ALTER TABLE fw_graphql_query_history DROP CONSTRAINT PK_fw_graphql_query_history
END
GO

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PK_fw_graphql_sdl_history')
BEGIN
       ALTER TABLE fw_graphql_sdl_history DROP CONSTRAINT PK_fw_graphql_sdl_history
END
GO
--code added for defectid TECH-67697 ends

--Code Added for the DefectId TECH-67339 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ezwiz_wizard_step_pk'))
BEGIN
	ALTER TABLE  ezwiz_wizard_step DROP CONSTRAINT ezwiz_wizard_step_pk
END
GO
--Code Added for the DefectId TECH-67339 Ends

--Code Added for the DefectId TECH-69624 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ep_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  ep_ui_control_customaction DROP CONSTRAINT ep_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('re_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  re_ui_control_customaction DROP CONSTRAINT re_ui_control_customaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE  de_ui_control_customaction DROP CONSTRAINT de_ui_control_customaction_pk
END
GO
--Code Added for the DefectId TECH-69624 Ends

--Code Added for the DefectId TECH-70687 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('ep_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE  ep_ui_section_Titleaction DROP CONSTRAINT ep_ui_section_Titleaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('re_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE  re_ui_section_Titleaction DROP CONSTRAINT re_ui_section_Titleaction_pk
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE de_ui_section_Titleaction DROP CONSTRAINT de_ui_section_Titleaction_pk
END
GO
--Code Added for the DefectId TECH-70687 Ends

--Code Added for TECH-72114 starts
IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report'))
BEGIN
	ALTER TABLE  de_published_task_gql_report DROP CONSTRAINT PK_de_published_task_gql_report
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report_param'))
BEGIN
	ALTER TABLE  de_published_task_gql_report_param DROP CONSTRAINT PK_de_published_task_gql_report_param
END
GO
--Code Added for TECH-72114 ends
SET NOCOUNT OFF

