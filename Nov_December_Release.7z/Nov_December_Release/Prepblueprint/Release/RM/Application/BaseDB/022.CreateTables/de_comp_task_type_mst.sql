/********************************************************************************************/
/*Created By 		Platform DB Extractor
  Created Date 		24 FEB 2022
  Defect Id			TECH-66583
  Description		RVW 2.0 Model publish table implementation for control and task property.*/
/*********************************************************************************************/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_comp_task_type_mst' AND TYPE = 'u')
BEGIN
	CREATE TABLE de_comp_task_type_mst	( customer_name ENGG_NAME  NOT NULL )
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'project_name' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	project_name	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'ecrno' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	ecrno	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'process_name' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	process_name	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'component_name' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	component_name	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'task_type_name' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	task_type_name	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'task_type_descr' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	task_type_descr	engg_description	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'default_for' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	default_for	engg_name	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'refresh_on_save' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	refresh_on_save	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'valid_on_init' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	valid_on_init	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'err_handle_method' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	err_handle_method	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'incl_place_holder' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	incl_place_holder	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'cond_ml_fetch' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	cond_ml_fetch	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'clr_on_page_save' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	clr_on_page_save	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'hdr_fetch_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	hdr_fetch_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'ml_fet_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	ml_fet_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'hdr_ref_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	hdr_ref_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'hdr_check_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	hdr_check_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'proc_sel_rows' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	proc_sel_rows	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'usr_role_map' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	usr_role_map	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'trn_scope_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	trn_scope_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'comp_task_type_sysid' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	comp_task_type_sysid	engg_sysid	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'timestamp' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	timestamp	engg_timestamp	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'createdby' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	createdby	engg_ctxt_user	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'createddate' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	createddate	engg_date	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'modifiedby' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	modifiedby	engg_ctxt_user	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'modifieddate' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	modifieddate	engg_date	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'task_type_doc' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	task_type_doc	engg_documentation	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'hdr_save_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	hdr_save_req	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'ml_save_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	ml_save_req	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'fprowno_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	fprowno_req	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'cbdef_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	cbdef_req	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'no_placeholder' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	no_placeholder	engg_seqno	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'data_save_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	data_save_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'print_req' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	print_req	engg_flag	NOT NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'task_confirmation' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	task_confirmation	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'Logic_Extensions' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	Logic_Extensions	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'process_updrows' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	process_updrows	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'alternate_db' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	alternate_db	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'sys_proc_sel_rows' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	sys_proc_sel_rows	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'sys_process_updrows' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	sys_process_updrows	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'Linkasui' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	Linkasui	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'Uiastrans' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	Uiastrans	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'MLSaveSinglesegment' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	MLSaveSinglesegment	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'sys_proc_selupd_rows' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	sys_proc_selupd_rows	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'CurrentContextInformation' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	CurrentContextInformation	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'ParentContextInformation' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	ParentContextInformation	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'ModeflagEnabled' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	ModeflagEnabled	engg_flag	NULL	
END	
GO	

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'BulkValidation' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	BulkValidation	engg_flag	NULL	
END	
GO	

--Code Added for TECH-75230 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_comp_task_type_mst' AND NAME = 'BubbleMessage' )	
BEGIN	
	ALTER TABLE	de_comp_task_type_mst	Add	BubbleMessage	engg_flag	NULL	
END	
GO	
--Code Added for TECH-75230 ends

IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_comp_task_type_mst' AND TYPE = 'P')
BEGIN
GRANT EXEC ON de_comp_task_type_mst TO PUBLIC
END
GO

