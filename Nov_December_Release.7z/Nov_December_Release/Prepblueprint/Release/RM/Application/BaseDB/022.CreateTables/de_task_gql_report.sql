/********************************************************************************
Created By 		Priyadarshini U
Created Date 	17 Aug 2021
Purpose 		Create Table Script - de_task_gql_report
********************************************************************************/

IF NOT EXISTS ( SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_task_gql_report' AND TYPE = 'U' )
BEGIN
	CREATE TABLE de_task_gql_report 	( CustomerName engg_name  NOT  NULL )
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ProjectName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ProjectName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'DocNo' )
BEGIN
	ALTER TABLE de_task_gql_report ADD DocNo engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ProcessName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ProcessName engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ComponentName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ComponentName engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ActivityName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ActivityName engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'UIName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD UIName engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'TaskName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD TaskName engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ReportName' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ReportName engg_name NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'OutputFormat' )
BEGIN
	ALTER TABLE de_task_gql_report ADD OutputFormat engg_type NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'LaunchMode' )
BEGIN
	ALTER TABLE de_task_gql_report ADD LaunchMode engg_type NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'TimeStamp' )
BEGIN
	ALTER TABLE de_task_gql_report ADD TimeStamp   engg_timestamp  NOT  NULL
END
GO


IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'CreatedBy' )
BEGIN
	ALTER TABLE de_task_gql_report ADD CreatedBy   engg_name  NOT NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'CreatedDate' )
BEGIN
	ALTER TABLE de_task_gql_report ADD CreatedDate   engg_date NOT  NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ModifiedBy' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ModifiedBy   engg_name NOT NULL
END
GO


IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_task_gql_report' AND NAME = 'ModifiedDate' )
BEGIN
	ALTER TABLE de_task_gql_report ADD ModifiedDate   engg_date  NOT NULL
END
GO


