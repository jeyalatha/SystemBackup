/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - de_fw_des_service
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'de_fw_des_service' and type = 'u')
begin
	create table de_fw_des_service
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'servicename')
begin
	alter table de_fw_des_service add servicename engg_service_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'componentname')
begin
	alter table de_fw_des_service add componentname engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'servicetype')
begin
	alter table de_fw_des_service add servicetype engg_tiny_no  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'isintegser')
begin
	alter table de_fw_des_service add isintegser engg_tiny_no  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'statusflag')
begin
	alter table de_fw_des_service add statusflag engg_tiny_no  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'upduser')
begin
	alter table de_fw_des_service add upduser engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'updtime')
begin
	alter table de_fw_des_service add updtime engg_date  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'project_name')
begin
	alter table de_fw_des_service add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'process_name')
begin
	alter table de_fw_des_service add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'timestamp')
begin
	alter table de_fw_des_service add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'createdby')
begin
	alter table de_fw_des_service add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'createddate')
begin
	alter table de_fw_des_service add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'modifiedby')
begin
	alter table de_fw_des_service add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'modifieddate')
begin
	alter table de_fw_des_service add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'svconame')
begin
	alter table de_fw_des_service add svconame engg_svco_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'processingtype')
begin
	alter table de_fw_des_service add processingtype engg_tiny_no null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'remarks')
begin
	alter table de_fw_des_service add remarks engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'ecrno')
begin
	alter table de_fw_des_service add ecrno engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'iszipped')
begin
	alter table de_fw_des_service add iszipped engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'iscached')
begin
	alter table de_fw_des_service add iscached engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'clearkey_pattern')
begin
	alter table de_fw_des_service add clearkey_pattern engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'setkey_pattern')
begin
	alter table de_fw_des_service add setkey_pattern engg_description null
end
go

--TECH-69327
IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_fw_des_service' AND NAME = 'isbubblemessage')
BEGIN
ALTER TABLE de_fw_des_service ADD isbubblemessage engg_seqno NULL
END
GO
--TECH-69327


--Code Added for TECH-75230 starts
if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'ApplyRefinements')
begin
	alter table de_fw_des_service add ApplyRefinements engg_flag null
end
go
--Code Added for TECH-75230 ends