/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - de_task_control_map
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'de_task_control_map' and type = 'u')
begin
	create table de_task_control_map
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'project_name')
begin
	alter table de_task_control_map add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'process_name')
begin
	alter table de_task_control_map add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'component_name')
begin
	alter table de_task_control_map add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'activity_name')
begin
	alter table de_task_control_map add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'ui_name')
begin
	alter table de_task_control_map add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'action_name')
begin
	alter table de_task_control_map add action_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'page_name')
begin
	alter table de_task_control_map add page_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'section_name')
begin
	alter table de_task_control_map add section_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'control_bt_synonym')
begin
	alter table de_task_control_map add control_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'map_flag')
begin
	alter table de_task_control_map add map_flag engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'map_ml_flag')
begin
	alter table de_task_control_map add map_ml_flag engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'tc_sysid')
begin
	alter table de_task_control_map add tc_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'timestamp')
begin
	alter table de_task_control_map add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'createdby')
begin
	alter table de_task_control_map add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'createddate')
begin
	alter table de_task_control_map add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'modifiedby')
begin
	alter table de_task_control_map add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'modifieddate')
begin
	alter table de_task_control_map add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'control_id')
begin
	alter table de_task_control_map add control_id engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'view_name')
begin
	alter table de_task_control_map add View_Name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'new_control_bt_synonym')
begin
	alter table de_task_control_map add new_control_bt_synonym engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'mapping_instance')
begin
	alter table de_task_control_map add mapping_instance engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'ecrno')
begin
	alter table de_task_control_map add ecrno engg_name null
end
go

--Code Added for TECH-75230 starts
if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'Load')
begin
	alter table de_task_control_map add Load engg_flag null
end
go

if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'Control_type')
begin
	alter table de_task_control_map add Control_type engg_name null
end
go
--Code Added for TECH-75230 ends