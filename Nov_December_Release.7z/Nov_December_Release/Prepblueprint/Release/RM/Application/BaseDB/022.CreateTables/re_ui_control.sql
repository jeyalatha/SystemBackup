/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - re_ui_control
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 're_ui_control' and type = 'u')
begin
	create table re_ui_control
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'project_name')
begin
	alter table re_ui_control add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'process_name')
begin
	alter table re_ui_control add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'component_name')
begin
	alter table re_ui_control add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'activity_name')
begin
	alter table re_ui_control add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'ui_name')
begin
	alter table re_ui_control add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'page_bt_synonym')
begin
	alter table re_ui_control add page_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'section_bt_synonym')
begin
	alter table re_ui_control add section_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_bt_synonym')
begin
	alter table re_ui_control add control_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_type')
begin
	alter table re_ui_control add control_type engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'horder')
begin
	alter table re_ui_control add horder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'vorder')
begin
	alter table re_ui_control add vorder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'ui_control_sysid')
begin
	alter table re_ui_control add ui_control_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'ui_section_sysid')
begin
	alter table re_ui_control add ui_section_sysid engg_sysid  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'timestamp')
begin
	alter table re_ui_control add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'createdby')
begin
	alter table re_ui_control add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'createddate')
begin
	alter table re_ui_control add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'modifiedby')
begin
	alter table re_ui_control add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'modifieddate')
begin
	alter table re_ui_control add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'data_column_width')
begin
	alter table re_ui_control add data_column_width engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'label_column_width')
begin
	alter table re_ui_control add label_column_width engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_id')
begin
	alter table re_ui_control add control_id engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'view_name')
begin
	alter table re_ui_control add view_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'visisble_length')
begin
	alter table re_ui_control add visisble_length engg_length null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'proto_tooltip')
begin
	alter table re_ui_control add proto_tooltip engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'sample_data')
begin
	alter table re_ui_control add sample_data engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_doc')
begin
	alter table re_ui_control add control_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_prefix')
begin
	alter table re_ui_control add control_prefix engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'order_seq')
begin
	alter table re_ui_control add order_seq engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'label_column_scalemode')
begin
	alter table re_ui_control add label_column_scalemode engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'data_column_scalemode')
begin
	alter table re_ui_control add data_column_scalemode engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'tab_seq')
begin
	alter table re_ui_control add tab_seq engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'help_tabstop')
begin
	alter table re_ui_control add help_tabstop engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'labelclass')
begin
	alter table re_ui_control add LabelClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'controlclass')
begin
	alter table re_ui_control add ControlClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'labelimageclass')
begin
	alter table re_ui_control add LabelImageClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'controlimageclass')
begin
	alter table re_ui_control add ControlImageClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'rcnno')
begin
	alter table re_ui_control add rcnno engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'set_user_pref')
begin
	alter table re_ui_control add Set_User_Pref engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'freezecount')
begin
	alter table re_ui_control add freezecount engg_rowno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'controlimage')
begin
	alter table re_ui_control add controlimage engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'colspan')
begin
	alter table re_ui_control add colspan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'rowspan')
begin
	alter table re_ui_control add rowspan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'templateid')
begin
	alter table re_ui_control add TemplateID engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'preserve_visible_length')
begin
	alter table re_ui_control add Preserve_visible_length engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'auto_width_column')
begin
	alter table re_ui_control add Auto_width_column engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'templatecategory')
begin
	alter table re_ui_control add TemplateCategory engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'templatespecific')
begin
	alter table re_ui_control add TemplateSpecific engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'control_class_ext6')
begin
	alter table re_ui_control add Control_class_ext6 engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'icon_position')
begin
	alter table re_ui_control add icon_position engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'icon_class')
begin
	alter table re_ui_control add icon_class engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'accesskey')
begin
	alter table re_ui_control add AccessKey engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'sensitivedata')
begin
	alter table re_ui_control add sensitivedata engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'isplatform')
begin
	alter table re_ui_control add IsPlatform engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'dynamicstyle')
begin
	alter table re_ui_control add DynamicStyle engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_ui_control' and name = 'imageasdata')
begin
	alter table re_ui_control add ImageAsData engg_flag null
end
go


IF NOT EXISTS (SELECT'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 're_ui_control' AND NAME = 'MoreEventEnabled')
BEGIN
ALTER TABLE re_ui_control add MoreEventEnabled engg_flag null
END
GO

IF NOT EXISTS (SELECT'x' FROM syscolumns (NOLOCK) WHERE object_name(id) = 're_ui_control' AND NAME = 'UpeSetFocusEnabled')
BEGIN
ALTER TABLE re_ui_control ADD UpeSetFocusEnabled engg_flag null
END
GO

--code added for TECH-63527 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='re_ui_control' and name = 'AssociateControl')
BEGIN
    ALTER TABLE re_ui_control ADD AssociateControl    engg_name   NULL
END
GO

--code added for TECH-63527 ends

--Code Added for the Defect id TECH-69624 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderLeftWidth' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderLeftWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderRightWidth' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderRightWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderTopWidth' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderTopWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderBottomWidth' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderBottomWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderLeftColor' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderLeftColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderRightColor' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderRightColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderTopColor' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderTopColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderBottomColor' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderBottomColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderTopLeftRadius' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderTopLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderTopRightRadius' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderTopRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderBottomLeftRadius' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderBottomLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderBottomRightRadius' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderBottomRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'BorderStyle' )
BEGIN
	ALTER TABLE re_ui_control ADD BorderStyle engg_name NULL
END
GO

--Code Added for the Defect id TECH-69624 ends

--Code Added for the Defect Id TECH-72114 Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_control' AND NAME = 'ControlFormat')
BEGIN
	ALTER TABLE re_ui_control ADD ControlFormat engg_flag NULL
END
GO

--Code Added for the Defect Id TECH-72114 Ends

--Code Added for TECH-75230 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_Control' AND NAME = 'ButtonNature' )
BEGIN
	ALTER TABLE re_ui_Control ADD ButtonNature engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_Control' AND NAME = 'InlineStyle' )
BEGIN
	ALTER TABLE re_ui_Control ADD InlineStyle Engg_Nvarchar_Max NULL
END
GO
--Code Added for TECH-75230 ends