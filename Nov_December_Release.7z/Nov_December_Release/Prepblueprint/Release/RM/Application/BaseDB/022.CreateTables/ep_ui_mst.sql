/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - ep_ui_mst
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'ep_ui_mst' and type = 'u')
begin
	create table ep_ui_mst
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'project_name')
begin
	alter table ep_ui_mst add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'req_no')
begin
	alter table ep_ui_mst add req_no engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'process_name')
begin
	alter table ep_ui_mst add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'component_name')
begin
	alter table ep_ui_mst add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'activity_name')
begin
	alter table ep_ui_mst add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_name')
begin
	alter table ep_ui_mst add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_descr')
begin
	alter table ep_ui_mst add ui_descr engg_description  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_type')
begin
	alter table ep_ui_mst add ui_type engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_format')
begin
	alter table ep_ui_mst add ui_format engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'caption_alignment')
begin
	alter table ep_ui_mst add caption_alignment engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'trail_bar')
begin
	alter table ep_ui_mst add trail_bar engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tab_height')
begin
	alter table ep_ui_mst add tab_height engg_length  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_sysid')
begin
	alter table ep_ui_mst add ui_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'timestamp')
begin
	alter table ep_ui_mst add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'createdby')
begin
	alter table ep_ui_mst add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'createddate')
begin
	alter table ep_ui_mst add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'modifiedby')
begin
	alter table ep_ui_mst add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'modifieddate')
begin
	alter table ep_ui_mst add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'current_req_no')
begin
	alter table ep_ui_mst add current_req_no engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_doc')
begin
	alter table ep_ui_mst add ui_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'base_component_name')
begin
	alter table ep_ui_mst add base_component_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'base_activity_name')
begin
	alter table ep_ui_mst add base_activity_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'base_ui_name')
begin
	alter table ep_ui_mst add base_ui_name engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'grid_type')
begin
	alter table ep_ui_mst add grid_type engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'state_processing')
begin
	alter table ep_ui_mst add state_processing engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'wrkreqno')
begin
	alter table ep_ui_mst add wrkreqno engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'callout_type')
begin
	alter table ep_ui_mst add callout_type engg_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'taskpane_req')
begin
	alter table ep_ui_mst add taskpane_req engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'new_line_ui')
begin
	alter table ep_ui_mst add New_Line_Ui engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tab_type')
begin
	alter table ep_ui_mst add Tab_Type engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tabposition')
begin
	alter table ep_ui_mst add TabPosition engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'postlaunchtask')
begin
	alter table ep_ui_mst add PostLaunchTask engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'smarthide')
begin
	alter table ep_ui_mst add SmartHide engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'is_device')
begin
	alter table ep_ui_mst add Is_device engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'hideilbotitlemenu_req')
begin
	alter table ep_ui_mst add HideIlbotitlemenu_req engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'exclude_systemtabindex')
begin
	alter table ep_ui_mst add Exclude_Systemtabindex engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'hide_print')
begin
	alter table ep_ui_mst add Hide_Print engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'personalization')
begin
	alter table ep_ui_mst add personalization engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'devicetype')
begin
	alter table ep_ui_mst add DeviceType engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tabstyle')
begin
	alter table ep_ui_mst add TabStyle engg_doc_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'isdesktop')
begin
	alter table ep_ui_mst add IsDesktop engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'layout')
begin
	alter table ep_ui_mst add Layout engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'xycoordinates')
begin
	alter table ep_ui_mst add XYCoordinates engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'columnlaywidth')
begin
	alter table ep_ui_mst add ColumnLayWidth engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tabheaderpostion')
begin
	alter table ep_ui_mst add TabHeaderPostion engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'tabrotation')
begin
	alter table ep_ui_mst add TabRotation engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'hide_imp_defaults')
begin
	alter table ep_ui_mst add hide_imp_defaults engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'ui_subtype')
begin
	alter table ep_ui_mst add ui_subtype engg_doc_type null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'dbname')
begin
	alter table ep_ui_mst add DBName engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'isglance')
begin
	alter table ep_ui_mst add IsGlance engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'nativeapplication')
begin
	alter table ep_ui_mst add NativeApplication engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_mst' and name = 'conditional_popupclose')
begin
	alter table ep_ui_mst add Conditional_popupclose engg_flag null
end
go

IF  NOT EXISTS (SELECT 'M' FROM syscolumns WHERE object_name(id) =	'ep_ui_mst' AND NAME	=	'Titlebar_Search' )
BEGIN
    ALTER TABLE  ep_ui_mst	ADD	   Titlebar_Search	   engg_flag	NULL            
END
GO

--code added for Defectid TECH-70687 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'Sidebar' )
BEGIN
	ALTER TABLE ep_ui_mst ADD Sidebar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'Docked' )
BEGIN
	ALTER TABLE ep_ui_mst ADD Docked engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'LeftToolbar' )
BEGIN
	ALTER TABLE ep_ui_mst ADD LeftToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'RightToolbar' )
BEGIN
	ALTER TABLE ep_ui_mst ADD RightToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'TopToolbar' )
BEGIN
	ALTER TABLE ep_ui_mst ADD TopToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_mst' AND NAME = 'BottomToolbar' )
BEGIN
	ALTER TABLE ep_ui_mst ADD BottomToolbar engg_flag NULL
END
GO
--code added for Defectid TECH-70687 ends

--code added for Defectid TECH-72114 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'TemplateJSON')
BEGIN
    ALTER TABLE ep_ui_mst add TemplateJSON    ENGG_NVARCHAR_MAX   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'StyleSheet')
BEGIN
    ALTER TABLE ep_ui_mst add StyleSheet    ENGG_NVARCHAR_MAX   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'ConfigurationXML')
BEGIN
    ALTER TABLE ep_ui_mst add ConfigurationXML    ENGG_NVARCHAR_MAX   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'TemplateJSONDBC')
BEGIN
    ALTER TABLE ep_ui_mst add TemplateJSONDBC    ENGG_NVARCHAR_MAX   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'StyleSheetDBC')
BEGIN
    ALTER TABLE ep_ui_mst add StyleSheetDBC    ENGG_NVARCHAR_MAX   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='ep_ui_mst' and name = 'ConfigurationXMLDBC')
BEGIN
    ALTER TABLE ep_ui_mst add ConfigurationXMLDBC    ENGG_NVARCHAR_MAX   NULL
END
GO
--code added for Defectid TECH-72114 ends

--Code Added for TECH-75230 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='PullToRefresh' and name = 'PullToRefresh')
BEGIN
    ALTER TABLE ep_ui_mst add PullToRefresh    engg_flag   NULL
END
GO
--Code Added for TECH-75230 ends