/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		Create Table Script - ep_ui_section_dtl
********************************************************************************/

if not exists (select 'x' from sysobjects where name = 'ep_ui_section_dtl' and type = 'u')
begin
	create table ep_ui_section_dtl
	(customer_name engg_name  not null)
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'project_name')
begin
	alter table ep_ui_section_dtl add project_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'req_no')
begin
	alter table ep_ui_section_dtl add req_no engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'process_name')
begin
	alter table ep_ui_section_dtl add process_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'component_name')
begin
	alter table ep_ui_section_dtl add component_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'activity_name')
begin
	alter table ep_ui_section_dtl add activity_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'ui_name')
begin
	alter table ep_ui_section_dtl add ui_name engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'page_bt_synonym')
begin
	alter table ep_ui_section_dtl add page_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_bt_synonym')
begin
	alter table ep_ui_section_dtl add section_bt_synonym engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'visisble_flag')
begin
	alter table ep_ui_section_dtl add visisble_flag engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'title_required')
begin
	alter table ep_ui_section_dtl add title_required engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'border_required')
begin
	alter table ep_ui_section_dtl add border_required engg_flag  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'title_alignment')
begin
	alter table ep_ui_section_dtl add title_alignment engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'parent_section')
begin
	alter table ep_ui_section_dtl add parent_section engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'horder')
begin
	alter table ep_ui_section_dtl add horder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'vorder')
begin
	alter table ep_ui_section_dtl add vorder engg_seqno  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'ui_section_sysid')
begin
	alter table ep_ui_section_dtl add ui_section_sysid engg_sysid null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'page_sysid')
begin
	alter table ep_ui_section_dtl add page_sysid engg_sysid  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'timestamp')
begin
	alter table ep_ui_section_dtl add timestamp engg_timestamp null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'createdby')
begin
	alter table ep_ui_section_dtl add createdby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'createddate')
begin
	alter table ep_ui_section_dtl add createddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'modifiedby')
begin
	alter table ep_ui_section_dtl add modifiedby engg_ctxt_user null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'modifieddate')
begin
	alter table ep_ui_section_dtl add modifieddate engg_date null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_doc')
begin
	alter table ep_ui_section_dtl add section_doc engg_documentation null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'width')
begin
	alter table ep_ui_section_dtl add width engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'height')
begin
	alter table ep_ui_section_dtl add height engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_type')
begin
	alter table ep_ui_section_dtl add section_type engg_name  not null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'ctrl_caption_align')
begin
	alter table ep_ui_section_dtl add ctrl_caption_align engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'sectionprefixclass')
begin
	alter table ep_ui_section_dtl add SectionPrefixClass engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'caption_format')
begin
	alter table ep_ui_section_dtl add caption_Format engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_width_scalemode')
begin
	alter table ep_ui_section_dtl add Section_width_Scalemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_height_scalemode')
begin
	alter table ep_ui_section_dtl add Section_height_Scalemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'wrkreqno')
begin
	alter table ep_ui_section_dtl add wrkreqno engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_prefix')
begin
	alter table ep_ui_section_dtl add section_prefix engg_prefix null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'associated_control')
begin
	alter table ep_ui_section_dtl add Associated_control engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'splitter_pos')
begin
	alter table ep_ui_section_dtl add splitter_pos engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'ncolspan')
begin
	alter table ep_ui_section_dtl add NColSpan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'nrowspan')
begin
	alter table ep_ui_section_dtl add NRowSpan engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_alignment')
begin
	alter table ep_ui_section_dtl add Section_Alignment engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_collapsemode')
begin
	alter table ep_ui_section_dtl add section_collapsemode engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'isstatic')
begin
	alter table ep_ui_section_dtl add IsStatic engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'section_collapse')
begin
	alter table ep_ui_section_dtl add section_collapse engg_name null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'carouselnavigation')
begin
	alter table ep_ui_section_dtl add CarouselNavigation engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'cell_spacing')
begin
	alter table ep_ui_section_dtl add cell_spacing engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'cell_padding')
begin
	alter table ep_ui_section_dtl add cell_padding engg_seqno null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'region')
begin
	alter table ep_ui_section_dtl add Region engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'titleposition')
begin
	alter table ep_ui_section_dtl add TitlePosition engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'collapsedir')
begin
	alter table ep_ui_section_dtl add CollapseDir engg_code null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'sectionlayout')
begin
	--alter table ep_ui_section_dtl add SectionLayout engg_flag null
	alter table ep_ui_section_dtl add SectionLayout engg_name null --TECH-69624
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'xycoordinates')
begin
	alter table ep_ui_section_dtl add XYCoordinates engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'columnlaywidth')
begin
	alter table ep_ui_section_dtl add ColumnLayWidth engg_description null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'isplatform')
begin
	alter table ep_ui_section_dtl add IsPlatform engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'ep_ui_section_dtl' and name = 'slidingbar_height')
begin
	alter table ep_ui_section_dtl add Slidingbar_Height engg_name null
end
go


--Code Added for the Defect id TECH-69624 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderLeftWidth' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderLeftWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderRightWidth' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderRightWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderTopWidth' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderTopWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderBottomWidth' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderBottomWidth engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderLeftColor' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderLeftColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderRightColor' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderRightColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderTopColor' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderTopColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderBottomColor' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderBottomColor engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderTopLeftRadius' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderTopLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderTopRightRadius' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderTopRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderBottomLeftRadius' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderBottomLeftRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderBottomRightRadius' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderBottomRightRadius engg_code NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'BorderStyle' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD BorderStyle engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'ForResponsive' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD ForResponsive engg_seqno NULL
END
GO

--Code Added for the Defect id TECH-69624 ends

--Code Added for the Defect id TECH-70687 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'LeftToolbar' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD LeftToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'RightToolbar' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD RightToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'TopToolbar' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD TopToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'BottomToolbar' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD BottomToolbar engg_flag NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'MinimizedRows' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD MinimizedRows engg_seqno NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'ViewMode' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD ViewMode engg_name NULL
END
GO
--Code Added for the Defect id TECH-70687 ends

--Code Added for the Defect id TECH-72114 starts

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Section_dtl' AND NAME = 'TitleIcon' )
BEGIN
	ALTER TABLE ep_ui_Section_dtl ADD TitleIcon engg_name NULL
END
GO
--Code Added for the Defect id TECH-72114 ends

--Code Added for TECH-75230 starts
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'Orientation' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD Orientation engg_name NULL
END
GO
--Code Added for TECH-75230 ends