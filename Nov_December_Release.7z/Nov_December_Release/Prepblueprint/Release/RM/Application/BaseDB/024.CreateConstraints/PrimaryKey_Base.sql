/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		For Creating Primary Key Constraints
********************************************************************************/

if not exists (select 'x' from sysconstraints where id = object_id('Activities') and constid = object_id('ActPk'))
begin
	alter table Activities add constraint ActPk primary key clustered (Cust_id, Proj_id, Problem_id, Act_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Configure') and constid = object_id('Apkg_Configure_PK'))
begin
	alter table Apkg_Configure add constraint Apkg_Configure_PK primary key clustered (CustomerID, ProjectId, LangID, RunTimeVersion, ReleaseVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Configure_DocDetail') and constid = object_id('Apkg_Configure_DocDetail_PK'))
begin
	alter table Apkg_Configure_DocDetail add constraint Apkg_Configure_DocDetail_PK primary key clustered (CustomerId, ProjectId, LangID, RunTimeVersion, ReleaseVersion, ReleaseCount)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Configure_DocMaster') and constid = object_id('Apkg_Configure_DocMaster_PK'))
begin
	alter table Apkg_Configure_DocMaster add constraint Apkg_Configure_DocMaster_PK primary key clustered (CustomerID, ProjectID, LangID, Releasecount)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Cust_Proj_Language') and constid = object_id('Apkg_Cust_Proj_Language_PK'))
begin
	alter table Apkg_Cust_Proj_Language add constraint Apkg_Cust_Proj_Language_PK primary key clustered (LangID, CustomerID, ProjectID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Customer') and constid = object_id('Apkg_Customer_PK'))
begin
	alter table Apkg_Customer add constraint Apkg_Customer_PK primary key clustered (ProjectID, LangID, CustomerID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Language') and constid = object_id('Apkg_Language_PK'))
begin
	alter table Apkg_Language add constraint Apkg_Language_PK primary key clustered (LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Project') and constid = object_id('Apkg_Project_PK'))
begin
	alter table Apkg_Project add constraint Apkg_Project_PK primary key clustered (CustomerID, LangID, ProjectID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Reference_Values') and constid = object_id('Apkg_Reference_Values_PK'))
begin
	alter table Apkg_Reference_Values add constraint Apkg_Reference_Values_PK primary key clustered (RefType, RefCode, LangId)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_ReleaseSet') and constid = object_id('Apkg_ReleaseSet_PK'))
begin
	alter table Apkg_ReleaseSet add constraint Apkg_ReleaseSet_PK primary key clustered (CustomerId, ProjectID, LangId, Release_Version, ReleaseSet)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_releaseset_ico') and constid = object_id('Apkg_releaseset_ico_PK'))
begin
	alter table Apkg_releaseset_ico add constraint Apkg_releaseset_ico_PK primary key clustered (CustomerID, ProjectId, Release_Version, ReleaseSet, ICO)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Runtime_Configure') and constid = object_id('Apkg_Runtime_Configure_Pk'))
begin
	alter table Apkg_Runtime_Configure add constraint Apkg_Runtime_Configure_Pk primary key clustered (CustomerID, ProjectID, Releasecount)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTime_Doc_ReleaseDtl') and constid = object_id('Apkg_RunTime_Doc_ReleaseDtl_Pk'))
begin
	alter table Apkg_RunTime_Doc_ReleaseDtl add constraint Apkg_RunTime_Doc_ReleaseDtl_Pk primary key clustered (CustomerID, ProjectID, Platform, Releasecount, RTVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTime_ReleaseDtl') and constid = object_id('Apkg_RunTime_ReleaseDtl_Pk'))
begin
	alter table Apkg_RunTime_ReleaseDtl add constraint Apkg_RunTime_ReleaseDtl_Pk primary key clustered (CustomerID, ProjectID, Platform, Releasecount, RTVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_Batchfile') and constid = object_id('Apkg_RuntimeArch_Batchfile_Pk'))
begin
	alter table Apkg_RuntimeArch_Batchfile add constraint Apkg_RuntimeArch_Batchfile_Pk primary key clustered (CustomerID, ProjectID, RTVersion, RDBMSName, RDBMSVersion, BatchfileSeq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_Batchfile_SP') and constid = object_id('Apkg_RuntimeArch_Batchfile_SP_Pk'))
begin
	alter table Apkg_RuntimeArch_Batchfile_SP add constraint Apkg_RuntimeArch_Batchfile_SP_Pk primary key clustered (CustomerID, ProjectID, RTVersion, RDBMSName, RDBMSVersion, BatchfileSeq, FileSeq, Subbatchfileseq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_Bparam') and constid = object_id('Apkg_RuntimeArch_Bparam_Pk'))
begin
	alter table Apkg_RuntimeArch_Bparam add constraint Apkg_RuntimeArch_Bparam_Pk primary key clustered (CustomerID, ProjectID, RTVersion, RDBMSName, RDBMSVersion, BatchfileSeq, ParamOrder, Subbatchfileseq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_Detail') and constid = object_id('Apkg_RunTimeArch_Detail_Pk'))
begin
	alter table Apkg_RunTimeArch_Detail add constraint Apkg_RunTimeArch_Detail_Pk primary key clustered (CustomerID, ProjectID, Platform, RTVersion, PreReqListNo, RTArtifactType, SoftwareListNo, RTArtifactTypeName, SourceArtifactType, SourceArtifactName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_DOC_Batchfile') and constid = object_id('Apkg_RuntimeArch_DOC_Batchfile_Pk'))
begin
	alter table Apkg_RuntimeArch_DOC_Batchfile add constraint Apkg_RuntimeArch_DOC_Batchfile_Pk primary key clustered (CustomerID, ProjectID, RTVersion, RDBMSName, RDBMSVersion, BatchfileSeq, ReleaseCount)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_DOC_Batchfile_SP') and constid = object_id('Apkg_RuntimeArch_DOC_Batchfile_SP_Pk'))
begin
	alter table Apkg_RuntimeArch_DOC_Batchfile_SP add constraint Apkg_RuntimeArch_DOC_Batchfile_SP_Pk primary key clustered (CustomerID, ProjectID, ReleaseCount, RTVersion, RDBMSVersion, RDBMSName, BatchfileSeq, SubbatchFileSeq, FileSeq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_DOC_SubBatchfile') and constid = object_id('Apkg_RuntimeArch_DOC_SubBatchfile_Pk'))
begin
	alter table Apkg_RuntimeArch_DOC_SubBatchfile add constraint Apkg_RuntimeArch_DOC_SubBatchfile_Pk primary key clustered (CustomerID, ProjectID, ReleaseCount, RTVersion, BatchfileSeq, RDBMSName, RDBMSVersion, SubbatchFileSeq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_DocBparam') and constid = object_id('Apkg_RuntimeArch_DocBparam_Pk'))
begin
	alter table Apkg_RuntimeArch_DocBparam add constraint Apkg_RuntimeArch_DocBparam_Pk primary key clustered (CustomerID, ProjectID, Releasecount, RTVersion, RDBMSName, RDBMSVersion, BatchfileSeq, ParamOrder, Batchfiletype)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_DocDetail') and constid = object_id('Apkg_RunTimeArch_DocDetail_Pk'))
begin
	alter table Apkg_RunTimeArch_DocDetail add constraint Apkg_RunTimeArch_DocDetail_Pk primary key clustered (CustomerID, ProjectID, Platform, Releasecount, RTVersion, PreReqSoftware, PreReqListNo, SoftwareListNo, RTArtifactType, RTArtifactTypeName, SourceArtifactType, SourceArtifactName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_DocMaster') and constid = object_id('Apkg_RunTimeArch_DocMaster_Pk'))
begin
	alter table Apkg_RunTimeArch_DocMaster add constraint Apkg_RunTimeArch_DocMaster_Pk primary key clustered (CustomerID, ProjectID, Platform, Releasecount, RTVersion, PreReqSoftware, PreReqListNo, RTArtifactType, RTArtifactTypeName, SoftwareListNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_DocPreReq') and constid = object_id('Apkg_RunTimeArch_DocPreReq_Pk'))
begin
	alter table Apkg_RunTimeArch_DocPreReq add constraint Apkg_RunTimeArch_DocPreReq_Pk primary key clustered (CustomerID, ProjectID, Platform, PreReqListNo, PreReqSoftware, Releasecount)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_Master') and constid = object_id('Apkg_RunTimeArch_Master_Pk'))
begin
	alter table Apkg_RunTimeArch_Master add constraint Apkg_RunTimeArch_Master_Pk primary key clustered (CustomerID, ProjectID, Platform, RTVersion, PreReqListNo, RTArtifactType, SoftwareListNo, RTArtifactTypeName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RunTimeArch_PreReq') and constid = object_id('Apkg_RunTimeArch_PreReq_Pk'))
begin
	alter table Apkg_RunTimeArch_PreReq add constraint Apkg_RunTimeArch_PreReq_Pk primary key clustered (CustomerID, ProjectID, Platform, PreReqListNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_RuntimeArch_SubBatchfile') and constid = object_id('Apkg_RuntimeArch_SubBatchfile_Pk'))
begin
	alter table Apkg_RuntimeArch_SubBatchfile add constraint Apkg_RuntimeArch_SubBatchfile_Pk primary key clustered (CustomerID, ProjectID, RTVersion, BatchfileSeq, RDBMSName, RDBMSVersion, Subbatchfileseq)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_Ssafe_Dtl') and constid = object_id('apkg_ssafe_dtl_PK'))
begin
	alter table Apkg_Ssafe_Dtl add constraint apkg_ssafe_dtl_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersion, SsafePath, UserName, DocumentID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Activity') and constid = object_id('Apkg_TechnoArch_Activity_PK'))
begin
	alter table Apkg_TechnoArch_Activity add constraint Apkg_TechnoArch_Activity_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Activity_source') and constid = object_id('Apkg_TechnoArch_Activity_source_PK'))
begin
	alter table Apkg_TechnoArch_Activity_source add constraint Apkg_TechnoArch_Activity_source_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_BP') and constid = object_id('Apkg_TechnoArch_BP_PK'))
begin
	alter table Apkg_TechnoArch_BP add constraint Apkg_TechnoArch_BP_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, ExecutableName, ReleaseArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_BP_source') and constid = object_id('Apkg_TechnoArch_BP_source_PK'))
begin
	alter table Apkg_TechnoArch_BP_source add constraint Apkg_TechnoArch_BP_source_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, ReleaseArtifactType, BPID, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_BR') and constid = object_id('Apkg_TechnoArch_BR_PK'))
begin
	alter table Apkg_TechnoArch_BR add constraint Apkg_TechnoArch_BR_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, Component, ActivityID, UIID, TaskID, ReleaseArtifactType, MethodName, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechNoArch_BRArtifact_DocDependency') and constid = object_id('Apkg_TechNoArch_BRArtifact_DocDependency_PK'))
begin
	alter table Apkg_TechNoArch_BRArtifact_DocDependency add constraint Apkg_TechNoArch_BRArtifact_DocDependency_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersion, ReleaseCount, FromComponent, FromArtifactname, FromArtifactType, ToComponent, ToArtifactname, ToArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Component') and constid = object_id('Apkg_TechnoArch_Component_PK'))
begin
	alter table Apkg_TechnoArch_Component add constraint Apkg_TechnoArch_Component_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Component_source') and constid = object_id('Apkg_TechnoArch_Component_source_PK'))
begin
	alter table Apkg_TechnoArch_Component_source add constraint Apkg_TechnoArch_Component_source_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechNoArch_Detail') and constid = object_id('Apkg_TechNoArch_Detail_PK'))
begin
	alter table Apkg_TechNoArch_Detail add constraint Apkg_TechNoArch_Detail_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseArtifactType, ReleaseVersion, RunTimeVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Activity') and constid = object_id('Apkg_TechnoArch_Doc_Activity_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Activity add constraint Apkg_TechnoArch_Doc_Activity_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Activity_Source') and constid = object_id('Apkg_TechnoArch_Doc_Activity_Source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Activity_Source add constraint Apkg_TechnoArch_Doc_Activity_Source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_BP') and constid = object_id('Apkg_TechnoArch_Doc_BP_PK'))
begin
	alter table Apkg_TechnoArch_Doc_BP add constraint Apkg_TechnoArch_Doc_BP_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_BP_source') and constid = object_id('Apkg_TechnoArch_Doc_BP_source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_BP_source add constraint Apkg_TechnoArch_Doc_BP_source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseVersion, ReleaseCount, RunTimeVersion, BPID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_BR') and constid = object_id('Apkg_TechnoArch_Doc_BR_PK'))
begin
	alter table Apkg_TechnoArch_Doc_BR add constraint Apkg_TechnoArch_Doc_BR_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, Component, ActivityID, UIID, TaskID, ExecutableName, MethodName, ReleaseArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_BR_Source') and constid = object_id('Apkg_TechnoArch_Doc_BR_Source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_BR_Source add constraint Apkg_TechnoArch_Doc_BR_Source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, Component, ActivityID, UIID, TaskID, ReleaseArtifactType, MethodName, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Component') and constid = object_id('Apkg_TechnoArch_Doc_Component_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Component add constraint Apkg_TechnoArch_Doc_Component_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Component_Source') and constid = object_id('Apkg_TechnoArch_Doc_Component_Source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Component_Source add constraint Apkg_TechnoArch_Doc_Component_Source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Rm_Files') and constid = object_id('Apkg_TechnoArch_Doc_Rm_Files_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Rm_Files add constraint Apkg_TechnoArch_Doc_Rm_Files_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseCount, ReleaseVersion, RDBMSName, RDBMSVersion, Filetype, FileNam)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Task') and constid = object_id('Apkg_TechnoArch_Doc_Task_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Task add constraint Apkg_TechnoArch_Doc_Task_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, TaskID, ReleaseArtifactType, ServiceName, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_Task_Source') and constid = object_id('Apkg_TechnoArch_Doc_Task_Source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_Task_Source add constraint Apkg_TechnoArch_Doc_Task_Source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, TaskID, ReleaseArtifactType, ServiceName, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_UI') and constid = object_id('Apkg_TechnoArch_Doc_UI_PK'))
begin
	alter table Apkg_TechnoArch_Doc_UI add constraint Apkg_TechnoArch_Doc_UI_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_UI_Assoc') and constid = object_id('Apkg_TechnoArch_Doc_UI_Assoc_PK'))
begin
	alter table Apkg_TechnoArch_Doc_UI_Assoc add constraint Apkg_TechnoArch_Doc_UI_Assoc_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, ExecutableName, LinkedUI, Linkedactivity, Linkedcomponent)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Doc_UI_Source') and constid = object_id('Apkg_TechnoArch_Doc_UI_Source_PK'))
begin
	alter table Apkg_TechnoArch_Doc_UI_Source add constraint Apkg_TechnoArch_Doc_UI_Source_PK primary key clustered (CustomerID, ProjectId, LangID, Platform, ReleaseCount, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechNoArch_DocDetail') and constid = object_id('Apkg_TechNoArch_DocDetail_PK'))
begin
	alter table Apkg_TechNoArch_DocDetail add constraint Apkg_TechNoArch_DocDetail_PK primary key clustered (CustomerID, ProjectId, Platform, LangID, ReleaseArtifactType, ReleaseVersion, RunTimeVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_DocMaster') and constid = object_id('Apkg_TechnoArch_DocMaster_PK'))
begin
	alter table Apkg_TechnoArch_DocMaster add constraint Apkg_TechnoArch_DocMaster_PK primary key clustered (Platform, ReleaseArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_DocSource_Detail') and constid = object_id('Apkg_TechnoArch_DocSource_Detail_PK'))
begin
	alter table Apkg_TechnoArch_DocSource_Detail add constraint Apkg_TechnoArch_DocSource_Detail_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, ApplicablePlatformLayer, Source_Artifact_Type, RunTimeVersion)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_DocSource_Master') and constid = object_id('Apkg_TechnoArch_DocSource_Master_PK'))
begin
	alter table Apkg_TechnoArch_DocSource_Master add constraint Apkg_TechnoArch_DocSource_Master_PK primary key clustered (Platform, Source_Artifact_Type)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Master') and constid = object_id('Apkg_TechnoArch_Master_PK'))
begin
	alter table Apkg_TechnoArch_Master add constraint Apkg_TechnoArch_Master_PK primary key clustered (Platform, ReleaseArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Rm_Files') and constid = object_id('Apkg_TechnoArch_Rm_Files_PK'))
begin
	alter table Apkg_TechnoArch_Rm_Files add constraint Apkg_TechnoArch_Rm_Files_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersion, RDBMSName, RDBMSVersion, Filetype, FileNam)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Task') and constid = object_id('Apkg_TechnoArch_Task_PK'))
begin
	alter table Apkg_TechnoArch_Task add constraint Apkg_TechnoArch_Task_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, TaskID, ReleaseArtifactType, ExecutableName, ServiceName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_Task_source') and constid = object_id('Apkg_TechnoArch_Task_source_PK'))
begin
	alter table Apkg_TechnoArch_Task_source add constraint Apkg_TechnoArch_Task_source_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, TaskID, ReleaseArtifactType, ExecutableName, ServiceName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_UI') and constid = object_id('Apkg_TechnoArch_UI_PK'))
begin
	alter table Apkg_TechnoArch_UI add constraint Apkg_TechnoArch_UI_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_UI_assoc') and constid = object_id('Apkg_TechnoArch_UI_assoc_PK'))
begin
	alter table Apkg_TechnoArch_UI_assoc add constraint Apkg_TechnoArch_UI_assoc_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, LinkType, LinkedUI, Linkedcomponent, linkedActivity, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Apkg_TechnoArch_UI_source') and constid = object_id('Apkg_TechnoArch_UI_source_PK'))
begin
	alter table Apkg_TechnoArch_UI_source add constraint Apkg_TechnoArch_UI_source_PK primary key clustered (CustomerID, ProjectID, LangID, Platform, ReleaseVersion, RunTimeVersion, BPID, Componentname, ActivityID, UIID, ReleaseArtifactType, ExecutableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_component_bt_validation') and constid = object_id('avs_component_bt_validation_pkey'))
begin
	alter table avs_component_bt_validation add constraint avs_component_bt_validation_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_name, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_message') and constid = object_id('avs_message_pkey'))
begin
	alter table avs_message add constraint avs_message_pkey primary key clustered (customer_name, project_name, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_message_lng_extn') and constid = object_id('avs_message_lng_extn_pkey'))
begin
	alter table avs_message_lng_extn add constraint avs_message_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_project_bt_validation') and constid = object_id('avs_project_bt_validation_pkey'))
begin
	alter table avs_project_bt_validation add constraint avs_project_bt_validation_pkey primary key clustered (customer_name, project_name, bt_name, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_quick_code_met') and constid = object_id('avs_quick_code_met_pkey'))
begin
	alter table avs_quick_code_met add constraint avs_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_service_validation_dtl') and constid = object_id('avs_service_validation_dtl_pkey'))
begin
	alter table avs_service_validation_dtl add constraint avs_service_validation_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, service_name, segment_name, dataitemname, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_validation_group') and constid = object_id('avs_validation_group_pkey'))
begin
	alter table avs_validation_group add constraint avs_validation_group_pkey primary key clustered (customer_name, project_name, val_grp_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('avs_validation_group_dtl') and constid = object_id('avs_validation_group_dtl_pkey'))
begin
	alter table avs_validation_group_dtl add constraint avs_validation_group_dtl_pkey primary key clustered (customer_name, project_name, val_grp_code, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_depends') and constid = object_id('ce_comp_sp_depends_pkey'))
begin
	alter table ce_comp_sp_depends add constraint ce_comp_sp_depends_pkey primary key clustered (customer_name, project_name, process_name, component_name, sp_name, parent_object_type, child_object_type, child_sp_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_depends_dtl') and constid = object_id('ce_comp_sp_depends_dtl_PK'))
begin
	alter table ce_comp_sp_depends_dtl add constraint ce_comp_sp_depends_dtl_PK primary key clustered (customer_name, project_name, process_name, component_name, objectname, objecttype, interactingobject, interactingobjecttype, referred_column)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_depends_func_dtl') and constid = object_id('ce_comp_sp_depends_func_dtl_PK'))
begin
	alter table ce_comp_sp_depends_func_dtl add constraint ce_comp_sp_depends_func_dtl_PK primary key clustered (customer_name, project_name, process_name, component_name, objectname, objecttype, interactingobject, interactingobjecttype, referred_column, function_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_errors') and constid = object_id('ce_comp_sp_errors_pkey'))
begin
	alter table ce_comp_sp_errors add constraint ce_comp_sp_errors_pkey primary key clustered (customer_name, project_name, process_name, component_name, sp_name, sp_error_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_params') and constid = object_id('ce_comp_sp_params_PK'))
begin
	alter table ce_comp_sp_params add constraint ce_comp_sp_params_PK primary key clustered (customer_name, project_name, process_name, component_name, spname, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_result') and constid = object_id('ce_comp_sp_result_PK'))
begin
	alter table ce_comp_sp_result add constraint ce_comp_sp_result_PK primary key clustered (customer_name, project_name, process_name, component_name, spname, result_set, object, object_type, output_columns)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_result_criteria') and constid = object_id('ce_comp_sp_result_criteria_PK'))
begin
	alter table ce_comp_sp_result_criteria add constraint ce_comp_sp_result_criteria_PK primary key clustered (customer_name, project_name, process_name, component_name, objectname, objecttype, resultset, lhs_object, lhs_object_type, lhs_parameter, rhs_object, rhs_object_type, rhs_parameter)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_comp_sp_result_stmts') and constid = object_id('ce_comp_sp_result_stmts_PK'))
begin
	alter table ce_comp_sp_result_stmts add constraint ce_comp_sp_result_stmts_PK primary key clustered (customer_name, project_name, process_name, component_name, spname, result_set, stmt_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_component_sp') and constid = object_id('ce_component_sp_pkey'))
begin
	alter table ce_component_sp add constraint ce_component_sp_pkey primary key clustered (customer_name, project_name, process_name, component_name, sp_name, sp_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_fixnote_ico_map') and constid = object_id('ce_fixnote_ico_map_pkey'))
begin
	alter table ce_fixnote_ico_map add constraint ce_fixnote_ico_map_pkey primary key clustered (customer_name, project_name, dm_version_no, process_name, component_name, fixnote_no, ico_number)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_method_service_map') and constid = object_id('ce_ico_method_service_map_pkey'))
begin
	alter table ce_ico_method_service_map add constraint ce_ico_method_service_map_pkey primary key clustered (ico_no, customer_name, project_name, process_name, component_name, activity_name, method_name, ui_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp') and constid = object_id('ce_ico_sp_pkey'))
begin
	alter table ce_ico_sp add constraint ce_ico_sp_pkey primary key clustered (ico_no, customer_name, project_name, process_name, component_name, sp_name, sp_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_depends') and constid = object_id('ce_ico_sp_depends_pkey'))
begin
	alter table ce_ico_sp_depends add constraint ce_ico_sp_depends_pkey primary key clustered (ico_no, customer_name, project_name, process_name, component_name, sp_name, child_object_type, parent_object_type, child_object_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_depends_dtl') and constid = object_id('ce_ico_sp_depends_dtl_PK'))
begin
	alter table ce_ico_sp_depends_dtl add constraint ce_ico_sp_depends_dtl_PK primary key clustered (customer_name, project_name, process_name, component_name, ico_number, objectname, objecttype, interactingobject, interactingobjecttype, referred_column)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_errors') and constid = object_id('ce_ico_sp_errors_pkey'))
begin
	alter table ce_ico_sp_errors add constraint ce_ico_sp_errors_pkey primary key clustered (ico_no, customer_name, project_name, process_name, component_name, sp_name, sp_error_no, parent_object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_params') and constid = object_id('ce_ico_sp_params_PK'))
begin
	alter table ce_ico_sp_params add constraint ce_ico_sp_params_PK primary key clustered (customer_name, project_name, process_name, component_name, ico_number, spname, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_result_criteria') and constid = object_id('ce_ico_sp_result_criteria_PK'))
begin
	alter table ce_ico_sp_result_criteria add constraint ce_ico_sp_result_criteria_PK primary key clustered (customer_name, project_name, process_name, component_name, ico_number, objectname, objecttype, resultset, lhs_object, lhs_object_type, lhs_parameter, rhs_object, rhs_object_type, rhs_parameter)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_result_stmts') and constid = object_id('ce_ico_sp_result_stmts_PK'))
begin
	alter table ce_ico_sp_result_stmts add constraint ce_ico_sp_result_stmts_PK primary key clustered (customer_name, project_name, process_name, component_name, ico_name, spname, result_set, stmt_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ico_sp_spec') and constid = object_id('ce_ico_sp_spec_pkey'))
begin
	alter table ce_ico_sp_spec add constraint ce_ico_sp_spec_pkey primary key clustered (ico_no, customer_name, project_name, process_name, component_name, sp_name, parent_object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_quick_code_met') and constid = object_id('ce_quick_code_met_pkey'))
begin
	alter table ce_quick_code_met add constraint ce_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_quick_code_met_lng_extn') and constid = object_id('ce_quick_code_met_lng_extn_pkey'))
begin
	alter table ce_quick_code_met_lng_extn add constraint ce_quick_code_met_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_rmt_ico_ui') and constid = object_id('ce_rmt_ico_ui_pkey'))
begin
	alter table ce_rmt_ico_ui add constraint ce_rmt_ico_ui_pkey primary key clustered (customer_name, project_name, cr_no, rcn_no, ecr_no, ico_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ce_ui_ico') and constid = object_id('ce_ui_ico_pkey'))
begin
	alter table ce_ui_ico add constraint ce_ui_ico_pkey primary key clustered (customer_name, project_name, ecr_no, ico_no, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_control_validation') and constid = object_id('cvs_control_validation_pkey'))
begin
	alter table cvs_control_validation add constraint cvs_control_validation_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_message') and constid = object_id('PK_cvs_message'))
begin
	alter table cvs_message add constraint PK_cvs_message primary key clustered (customer_name, Project_name, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code, message_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('cvs_message_lng_extn') and constid = object_id('PK_cvs_message_lng_extn'))
begin
	alter table cvs_message_lng_extn add constraint PK_cvs_message_lng_extn primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, task_name, control_name, validation_code, message_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Column_Variable_Interactions') and constid = object_id('DB_Variable_InteractionsPK'))
begin
	alter table DB_Column_Variable_Interactions add constraint DB_Variable_InteractionsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, TableName, ColumnName, VariableName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Constraint_Columns') and constid = object_id('DB_ConsColumn_PK'))
begin
	alter table DB_Constraint_Columns add constraint DB_ConsColumn_PK primary key clustered (Customer, Project, Object, ObjectType, Tablename, ConstraintName, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Constraints') and constid = object_id('DB_Cons_PK'))
begin
	alter table DB_Constraints add constraint DB_Cons_PK primary key clustered (Customer, Project, Object, ObjectType, Tablename, ConstraintName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Index_Columns') and constid = object_id('DB_Index_Columns_PK'))
begin
	alter table DB_Index_Columns add constraint DB_Index_Columns_PK primary key clustered (Customer, Project, Object, ObjectType, Tablename, IndexName, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Indexes') and constid = object_id('DB_Indexes_PK'))
begin
	alter table DB_Indexes add constraint DB_Indexes_PK primary key clustered (Customer, Project, Object, ObjectType, Tablename, IndexName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Object_Columns') and constid = object_id('DB_Object_ColumnsPK'))
begin
	alter table DB_Object_Columns add constraint DB_Object_ColumnsPK primary key clustered (Customer, Project, Object, ObjectType, ColumnSequence, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Object_declarations') and constid = object_id('DB_Object_declarationsPK'))
begin
	alter table DB_Object_declarations add constraint DB_Object_declarationsPK primary key clustered (Customer, Project, Object, ObjectType, DeclarationType, DeclarationName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Object_Interaction') and constid = object_id('DB_Object_InteractionPK'))
begin
	alter table DB_Object_Interaction add constraint DB_Object_InteractionPK primary key clustered (Customer, Project, Object, ObjectType, InteractingObject, InteractingObjectType)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Object_Statements') and constid = object_id('DB_Object_StatementsPK'))
begin
	alter table DB_Object_Statements add constraint DB_Object_StatementsPK primary key clustered (Customer, Project, object, Objecttype, StatementSequence)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Objects') and constid = object_id('Customer_idPK'))
begin
	alter table DB_Objects add constraint Customer_idPK primary key clustered (Customer, Project, Object, ObjectType)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_cursor_Columns') and constid = object_id('DB_Statement_cursor_ColumnsPK'))
begin
	alter table DB_Statement_cursor_Columns add constraint DB_Statement_cursor_ColumnsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, ColumnName, AliasName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Interactions') and constid = object_id('DB_Statement_InteractionsPK'))
begin
	alter table DB_Statement_Interactions add constraint DB_Statement_InteractionsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, ColumnName, OperationType, TargetObjectType, TargetObject, TargetColumn)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Object_Columns') and constid = object_id('DB_Statement_Object_ColumnsPK'))
begin
	alter table DB_Statement_Object_Columns add constraint DB_Statement_Object_ColumnsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Object_Functions') and constid = object_id('DB_Statement_Object_FunctionsPK'))
begin
	alter table DB_Statement_Object_Functions add constraint DB_Statement_Object_FunctionsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, ColumnName, FunctionName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Object_OtherColumns') and constid = object_id('DB_Statement_Object_OtherColumnsPK'))
begin
	alter table DB_Statement_Object_OtherColumns add constraint DB_Statement_Object_OtherColumnsPK primary key clustered (Customer, Project, object, ObjectType, StatementID, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Object_Results') and constid = object_id('DB_Statement_Object_ResultsPK'))
begin
	alter table DB_Statement_Object_Results add constraint DB_Statement_Object_ResultsPK primary key clustered (Customer, Project, Object, ObjectType, StatementID, AliasName, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statement_Object_Used') and constid = object_id('DB_Statement_Object_UsedPK'))
begin
	alter table DB_Statement_Object_Used add constraint DB_Statement_Object_UsedPK primary key clustered (Customer, Project, Object, ObjectType, StatementID)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_Statements_Usage') and constid = object_id('DB_Statements_UsagePK'))
begin
	alter table DB_Statements_Usage add constraint DB_Statements_UsagePK primary key clustered (Customer, Project, Object, StatementID)
end

if not exists (select 'x' from sysconstraints where id = object_id('DB_UDDs') and constid = object_id('DB_UDDs_PK'))
begin
	alter table DB_UDDs add constraint DB_UDDs_PK primary key clustered (Customer, Project, object, ObjectType, UDDName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_action') and constid = object_id('de_action_pkey'))
begin
	alter table de_action add constraint de_action_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_action_fprowno_tmp') and constid = object_id('de_action_fprowno_tmp_pkey'))
begin
	alter table de_action_fprowno_tmp add constraint de_action_fprowno_tmp_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_action_lng_extn') and constid = object_id('de_action_lng_extn_pkey'))
begin
	alter table de_action_lng_extn add constraint de_action_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_action_section_map') and constid = object_id('de_action_section_map_pkey'))
begin
	alter table de_action_section_map add constraint de_action_section_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, section_page_bt_synonym, task_name, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_activity_history') and constid = object_id('de_activity_history_pk'))
begin
	alter table de_activity_history add constraint de_activity_history_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, History_version)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_applicable_database') and constid = object_id('de_applicable_database_pkey'))
begin
	alter table de_applicable_database add constraint de_applicable_database_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bo_dataitem_relation') and constid = object_id('de_bo_dataitem_relation_pkey'))
begin
	alter table de_bo_dataitem_relation add constraint de_bo_dataitem_relation_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name, bo_segment_name, relationship_name, bo_dataitem_name, related_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bo_segment') and constid = object_id('de_bo_segment_pkey'))
begin
	alter table de_bo_segment add constraint de_bo_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name, bo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bo_segment_dataitem') and constid = object_id('de_bo_segment_dataitem_pkey'))
begin
	alter table de_bo_segment_dataitem add constraint de_bo_segment_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name, bo_segment_name, bo_segment_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bo_segment_relation') and constid = object_id('de_bo_segment_relation_pkey'))
begin
	alter table de_bo_segment_relation add constraint de_bo_segment_relation_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name, bo_segment_name, relationship_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bt_association_history') and constid = object_id('de_bt_association_history_pk'))
begin
	alter table de_bt_association_history add constraint de_bt_association_history_pk primary key clustered (customer_name, project_name, process_name, component_name, bt_synonym_name, History_version)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bt_attributes_history') and constid = object_id('de_bt_attributes_history_pk'))
begin
	alter table de_bt_attributes_history add constraint de_bt_attributes_history_pk primary key clustered (customer_name, project_name, process_name, component_name, bt_name, History_version)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_bt_synonym_history') and constid = object_id('de_bt_synonym_history_pk'))
begin
	alter table de_bt_synonym_history add constraint de_bt_synonym_history_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, old_bt_synonym, new_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_business_object') and constid = object_id('de_business_object_pkey'))
begin
	alter table de_business_object add constraint de_business_object_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_business_rule') and constid = object_id('de_business_rule_pkey'))
begin
	alter table de_business_rule add constraint de_business_rule_pkey primary key clustered (customer_name, project_name, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_business_term') and constid = object_id('de_business_term_pkey'))
begin
	alter table de_business_term add constraint de_business_term_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_chart_header') and constid = object_id('de_chart_header_pkey'))
begin
	alter table de_chart_header add constraint de_chart_header_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_chart_sample_data') and constid = object_id('de_chart_sample_data_pkey'))
begin
	alter table de_chart_sample_data add constraint de_chart_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_chart_series') and constid = object_id('de_chart_series_pkey'))
begin
	alter table de_chart_series add constraint de_chart_series_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_chm_service_datatitem') and constid = object_id('de_chm_service_datatitem_PK'))
begin
	alter table de_chm_service_datatitem add constraint de_chm_service_datatitem_PK primary key clustered (customer_name, project_name, process_name, component_name, service_name, segment_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_comp_doc_status') and constid = object_id('de_comp_doc_status_PKey'))
begin
	alter table de_comp_doc_status add constraint de_comp_doc_status_PKey primary key clustered (customer_name, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_contextual_links') and constid = object_id('de_contextual_links_PK'))
begin
	alter table de_contextual_links add constraint de_contextual_links_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_control_extensions') and constid = object_id('de_control_extensions_PK'))
begin
	alter table de_control_extensions add constraint de_control_extensions_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_custom_listedit') and constid = object_id('de_custom_listedit_PKey'))
begin
	alter table de_custom_listedit add constraint de_custom_listedit_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_date_highlight_control_map') and constid = object_id('de_date_highlight_control_map_PKey'))
begin
	alter table de_date_highlight_control_map add constraint de_date_highlight_control_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ecr_publish_chk') and constid = object_id('de_ecr_publish_chk_pkey'))
begin
	alter table de_ecr_publish_chk add constraint de_ecr_publish_chk_pkey primary key clustered (customer_Name, Project_Name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_enum_value') and constid = object_id('de_enum_value_pkey'))
begin
	alter table de_enum_value add constraint de_enum_value_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_detail_layout') and constid = object_id('de_exrep_detail_layout_pkey'))
begin
	alter table de_exrep_detail_layout add constraint de_exrep_detail_layout_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, template_id, sheet_id, section_name, field_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_header_layout') and constid = object_id('de_exrep_header_layout_pkey'))
begin
	alter table de_exrep_header_layout add constraint de_exrep_header_layout_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, template_id, sheet_id, section_name, field_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_report_sections') and constid = object_id('de_exrep_report_sections_pkey'))
begin
	alter table de_exrep_report_sections add constraint de_exrep_report_sections_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, template_id, sheet_id, section_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_task_template_map') and constid = object_id('de_exrep_task_template_map_pkey'))
begin
	alter table de_exrep_task_template_map add constraint de_exrep_task_template_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_templates_dtl') and constid = object_id('de_exrep_templates_dtl_pkey'))
begin
	alter table de_exrep_templates_dtl add constraint de_exrep_templates_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, template_id, sheet_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_exrep_templates_hdr') and constid = object_id('de_exrep_templates_hdr_pkey'))
begin
	alter table de_exrep_templates_hdr add constraint de_exrep_templates_hdr_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, template_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ext_js_control') and constid = object_id('de_ext_js_control_PK'))
begin
	alter table de_ext_js_control add constraint de_ext_js_control_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ext_js_section') and constid = object_id('de_ext_js_section_PK'))
begin
	alter table de_ext_js_section add constraint de_ext_js_section_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ext_js_section_column') and constid = object_id('de_ext_js_section_column_PK'))
begin
	alter table de_ext_js_section_column add constraint de_ext_js_section_column_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezeeview_sp') and constid = object_id('de_ezeeview_sp_PK'))
begin
	alter table de_ezeeview_sp add constraint de_ezeeview_sp_PK primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezeeview_spparamlist') and constid = object_id('de_ezeeview_spparamlist_pk'))
begin
	alter table de_ezeeview_spparamlist add constraint de_ezeeview_spparamlist_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_res_ilbo_dataitem') and constid = object_id('de_ezwiz_res_ilbo_dataitem_pk'))
begin
	alter table de_ezwiz_res_ilbo_dataitem add constraint de_ezwiz_res_ilbo_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno, parent_ilbo_name, child_ilbo_name, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_res_step_dataitem') and constid = object_id('de_ezwiz_res_step_dataitem_pk'))
begin
	alter table de_ezwiz_res_step_dataitem add constraint de_ezwiz_res_step_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, parent_step_seqno, child_step_seqno, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_wizard') and constid = object_id('de_ezwiz_wizard_pk'))
begin
	alter table de_ezwiz_wizard add constraint de_ezwiz_wizard_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_wizard_local_info') and constid = object_id('de_ezwiz_wizard_local_info_pk'))
begin
	alter table de_ezwiz_wizard_local_info add constraint de_ezwiz_wizard_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_wizard_step') and constid = object_id('de_ezwiz_wizard_step_pk'))
begin
	alter table de_ezwiz_wizard_step add constraint de_ezwiz_wizard_step_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ezwiz_wizard_step_local_info') and constid = object_id('de_ezwiz_wizard_step_local_info_pk'))
begin
	alter table de_ezwiz_wizard_step_local_info add constraint de_ezwiz_wizard_step_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_flowbr') and constid = object_id('de_flowbr_pkey'))
begin
	alter table de_flowbr add constraint de_flowbr_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_flowbr_br_error') and constid = object_id('de_flowbr_br_error_pkey'))
begin
	alter table de_flowbr_br_error add constraint de_flowbr_br_error_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_flowbr_combo') and constid = object_id('de_flowbr_combo_pkey'))
begin
	alter table de_flowbr_combo add constraint de_flowbr_combo_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_flowbr_method_map') and constid = object_id('de_flowbr_method_map_pkey'))
begin
	alter table de_flowbr_method_map add constraint de_flowbr_method_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_flowbr_rule_map') and constid = object_id('de_flowbr_rule_map_pkey'))
begin
	alter table de_flowbr_rule_map add constraint de_flowbr_rule_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_affected_ius_temp') and constid = object_id('de_fw_des_affected_ius_temp_pkey'))
begin
	alter table de_fw_des_affected_ius_temp add constraint de_fw_des_affected_ius_temp_pkey primary key clustered (componentname, iucode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_be_placeholder') and constid = object_id('de_fw_des_be_placeholder_pkey'))
begin
	alter table de_fw_des_be_placeholder add constraint de_fw_des_be_placeholder_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid, placeholdername, errorid, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_bo') and constid = object_id('de_fw_des_bo_pkey'))
begin
	alter table de_fw_des_bo add constraint de_fw_des_bo_pkey primary key clustered (customer_name, project_name, bocode, process_name, componentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_bo_documentation') and constid = object_id('de_fw_des_bo_documentation_pkey'))
begin
	alter table de_fw_des_bo_documentation add constraint de_fw_des_bo_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, bocode, serialno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_br_documentation') and constid = object_id('de_fw_des_br_documentation_pkey'))
begin
	alter table de_fw_des_br_documentation add constraint de_fw_des_br_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid, serialno, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_br_logical_parameter') and constid = object_id('de_fw_des_br_logical_parameter_pkey'))
begin
	alter table de_fw_des_br_logical_parameter add constraint de_fw_des_br_logical_parameter_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid, logicalparametername, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_brerror') and constid = object_id('de_fw_des_brerror_pkey'))
begin
	alter table de_fw_des_brerror add constraint de_fw_des_brerror_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid, errorid, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_brerror_unmap') and constid = object_id('de_fw_des_brerror_unmap_pkey'))
begin
	alter table de_fw_des_brerror_unmap add constraint de_fw_des_brerror_unmap_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_bro') and constid = object_id('de_fw_des_bro_pkey'))
begin
	alter table de_fw_des_bro add constraint de_fw_des_bro_pkey primary key clustered (customer_name, project_name, process_name, componentname, broname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_businessrule') and constid = object_id('de_fw_des_businessrule_pkey'))
begin
	alter table de_fw_des_businessrule add constraint de_fw_des_businessrule_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_businessrule_iedktemp') and constid = object_id('PK_de_fw_des_businessrule_iedktemp'))
begin
	alter table de_fw_des_businessrule_iedktemp add constraint PK_de_fw_des_businessrule_iedktemp primary key clustered (MethodName, Guid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_chart_service_dataitem') and constid = object_id('de_fw_des_chart_service_dataitem_pkey'))
begin
	alter table de_fw_des_chart_service_dataitem add constraint de_fw_des_chart_service_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_chart_service_segment') and constid = object_id('de_fw_des_chart_service_segment_pkey'))
begin
	alter table de_fw_des_chart_service_segment add constraint de_fw_des_chart_service_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, chart_id, chart_section, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_context') and constid = object_id('de_fw_des_context_pkey'))
begin
	alter table de_fw_des_context add constraint de_fw_des_context_pkey primary key clustered (errorid, errorcontext)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_corr_action_local_info') and constid = object_id('de_fw_des_corr_action_local_info_pkey'))
begin
	alter table de_fw_des_corr_action_local_info add constraint de_fw_des_corr_action_local_info_pkey primary key clustered (errorid, errorcontext, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_dataitem') and constid = object_id('de_fw_des_dataitem_pkey'))
begin
	alter table de_fw_des_dataitem add constraint de_fw_des_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, bocode, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_di_parameter') and constid = object_id('de_fw_des_di_parameter_pkey'))
begin
	alter table de_fw_des_di_parameter add constraint de_fw_des_di_parameter_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, sectionname, sequenceno, parametername)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_di_placeholder') and constid = object_id('de_fw_des_di_placeholder_pkey'))
begin
	alter table de_fw_des_di_placeholder add constraint de_fw_des_di_placeholder_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, sectionname, sequenceno, methodid, placeholdername, errorid, segmentname, dataitemname, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_err_det_local_info') and constid = object_id('de_fw_des_err_det_local_info_pkey'))
begin
	alter table de_fw_des_err_det_local_info add constraint de_fw_des_err_det_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, errorid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_errbtn_local_info') and constid = object_id('de_fw_des_errbtn_local_info_pkey'))
begin
	alter table de_fw_des_errbtn_local_info add constraint de_fw_des_errbtn_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, severityid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_error') and constid = object_id('de_fw_des_error_pkey'))
begin
	alter table de_fw_des_error add constraint de_fw_des_error_pkey primary key clustered (customer_name, project_name, process_name, componentname, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_error_lookup_dataitem') and constid = object_id('de_fw_des_error_lookup_dataitem_pk'))
begin
	alter table de_fw_des_error_lookup_dataitem add constraint de_fw_des_error_lookup_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, errorid, pub_name, pub_page, pub_dataitemname, sub_page, sub_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_error_placeholder') and constid = object_id('de_fw_des_error_placeholder_pkey'))
begin
	alter table de_fw_des_error_placeholder add constraint de_fw_des_error_placeholder_pkey primary key clustered (customer_name, project_name, process_name, component_name, errorid, placeholdername)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_focus_control') and constid = object_id('de_fw_des_focus_control_pkey'))
begin
	alter table de_fw_des_focus_control add constraint de_fw_des_focus_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, errorcontext, errorid, segmentname, focusdataitem, controlid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_followup_tasks') and constid = object_id('de_fw_des_followup_tasks_pk'))
begin
	alter table de_fw_des_followup_tasks add constraint de_fw_des_followup_tasks_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, success_errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_action_group') and constid = object_id('de_fw_des_ilbo_action_group_pkey'))
begin
	alter table de_fw_des_ilbo_action_group add constraint de_fw_des_ilbo_action_group_pkey primary key clustered (ilbocode, groupcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_actiongrp_event') and constid = object_id('de_fw_des_ilbo_actiongrp_event_pkey'))
begin
	alter table de_fw_des_ilbo_actiongrp_event add constraint de_fw_des_ilbo_actiongrp_event_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, activityid, groupcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_actiongrp_task') and constid = object_id('de_fw_des_ilbo_actiongrp_task_pkey'))
begin
	alter table de_fw_des_ilbo_actiongrp_task add constraint de_fw_des_ilbo_actiongrp_task_pkey primary key clustered (activityid, taskname, ilbocode, groupcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_actions') and constid = object_id('de_fw_des_ilbo_actions_pkey'))
begin
	alter table de_fw_des_ilbo_actions add constraint de_fw_des_ilbo_actions_pkey primary key clustered (ilbocode, groupcode, actionsequence)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_controlvalue') and constid = object_id('de_fw_des_ilbo_controlvalue_pkey'))
begin
	alter table de_fw_des_ilbo_controlvalue add constraint de_fw_des_ilbo_controlvalue_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_ctrl_event') and constid = object_id('de_fw_des_ilbo_ctrl_event_pkey'))
begin
	alter table de_fw_des_ilbo_ctrl_event add constraint de_fw_des_ilbo_ctrl_event_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, eventname, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_placeholder') and constid = object_id('de_fw_des_ilbo_placeholder_pkey'))
begin
	alter table de_fw_des_ilbo_placeholder add constraint de_fw_des_ilbo_placeholder_pkey primary key clustered (ilbocode, placeholdername, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_service_view_attributemap') and constid = object_id('de_fw_des_ilbo_service_view_attributemap_pkey'))
begin
	alter table de_fw_des_ilbo_service_view_attributemap add constraint de_fw_des_ilbo_service_view_attributemap_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, servicename, activityid, taskname, segmentname, dataitemname, PropertyType, PropertyName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_service_view_datamap') and constid = object_id('de_fw_des_ilbo_service_view_datamap_pkey'))
begin
	alter table de_fw_des_ilbo_service_view_datamap add constraint de_fw_des_ilbo_service_view_datamap_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, servicename, activityid, taskname, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilbo_services') and constid = object_id('de_fw_des_ilbo_services_pkey'))
begin
	alter table de_fw_des_ilbo_services add constraint de_fw_des_ilbo_services_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, servicename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_ilerror') and constid = object_id('de_fw_des_ilerror_pkey'))
begin
	alter table de_fw_des_ilerror add constraint de_fw_des_ilerror_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, errorid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_integ_serv_map') and constid = object_id('de_fw_des_integ_serv_map_pkey'))
begin
	alter table de_fw_des_integ_serv_map add constraint de_fw_des_integ_serv_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, callingservicename, sectionname, sequenceno, integsegment, integdataitem)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_integ_serv_map_mr_pop') and constid = object_id('de_fw_des_integ_serv_map_mr_pop_pkey'))
begin
	alter table de_fw_des_integ_serv_map_mr_pop add constraint de_fw_des_integ_serv_map_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, callingservicename, sectionname, sequenceno, integsegment, integdataitem, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_message_task_map') and constid = object_id('de_fw_des_message_task_map_pk'))
begin
	alter table de_fw_des_message_task_map add constraint de_fw_des_message_task_map_pk primary key clustered (Customer_name, Project_name, process_name, component_name, activity_name, ui_name, taskname, MessageID, maptask_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_processsection') and constid = object_id('de_fw_des_processsection_pkey'))
begin
	alter table de_fw_des_processsection add constraint de_fw_des_processsection_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, sectionname, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_processsection_br_is') and constid = object_id('de_fw_des_processsection_br_is_pkey'))
begin
	alter table de_fw_des_processsection_br_is add constraint de_fw_des_processsection_br_is_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, sectionname, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_processsection_br_is_mr_pop') and constid = object_id('de_fw_des_processsection_br_is_mr_pop_pkey'))
begin
	alter table de_fw_des_processsection_br_is_mr_pop add constraint de_fw_des_processsection_br_is_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, servicename, sectionname, sequenceno, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_processsection_mr_pop') and constid = object_id('de_fw_des_processsection_mr_pop_pkey'))
begin
	alter table de_fw_des_processsection_mr_pop add constraint de_fw_des_processsection_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, servicename, sectionname, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_reqbr_desbr') and constid = object_id('de_fw_des_reqbr_desbr_pkey'))
begin
	alter table de_fw_des_reqbr_desbr add constraint de_fw_des_reqbr_desbr_pkey primary key clustered (customer_name, project_name, process_name, component_name, reqbrname, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_segment') and constid = object_id('de_fw_des_segment_pkey'))
begin
	alter table de_fw_des_segment add constraint de_fw_des_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, bocode, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_service') and constid = object_id('de_fw_des_service_pkey'))
begin
	alter table de_fw_des_service add constraint de_fw_des_service_pkey primary key clustered (customer_name, project_name, process_name, componentname, servicename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_service_dataitem') and constid = object_id('de_fw_des_service_dataitem_pkey'))
begin
	alter table de_fw_des_service_dataitem add constraint de_fw_des_service_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_service_documentation') and constid = object_id('de_fw_des_service_documentation_pkey'))
begin
	alter table de_fw_des_service_documentation add constraint de_fw_des_service_documentation_pkey primary key clustered (customer_name, process_name, project_name, component_name, servicename, serialno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_service_iedktemp') and constid = object_id('PK_de_fw_des_service_iedktemp'))
begin
	alter table de_fw_des_service_iedktemp add constraint PK_de_fw_des_service_iedktemp primary key clustered (ServiceName, Guid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_service_segment') and constid = object_id('de_fw_des_service_segment_pkey'))
begin
	alter table de_fw_des_service_segment add constraint de_fw_des_service_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_sp') and constid = object_id('de_fw_des_sp_pkey'))
begin
	alter table de_fw_des_sp add constraint de_fw_des_sp_pkey primary key clustered (customer_name, project_name, process_name, component_name, methodid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_svco') and constid = object_id('de_fw_des_svco_pkey'))
begin
	alter table de_fw_des_svco add constraint de_fw_des_svco_pkey primary key clustered (customer_name, project_name, process_name, component_name, svconame)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_task_callout') and constid = object_id('de_fw_des_task_callout_pkey'))
begin
	alter table de_fw_des_task_callout add constraint de_fw_des_task_callout_pkey primary key clustered (CustomerName, ProjectName, EcrNo, Process_Name, Component_Name, Activity_Name, UI_Name, Task_Name, CalloutName, CalloutMode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_task_callout_dataitem') and constid = object_id('de_fw_des_task_callout_dataitem_pkey'))
begin
	alter table de_fw_des_task_callout_dataitem add constraint de_fw_des_task_callout_dataitem_pkey primary key clustered (CustomerName, ProjectName, Process_Name, Component_Name, Activity_Name, UI_Name, Task_Name, CalloutName, CalloutMode, SegmentName, DataItemName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_task_callout_segement') and constid = object_id('de_fw_des_task_callout_segement_pkey'))
begin
	alter table de_fw_des_task_callout_segement add constraint de_fw_des_task_callout_segement_pkey primary key clustered (CustomerName, ProjectName, EcrNo, Process_Name, Component_Name, Activity_Name, UI_Name, Task_Name, CalloutName, CalloutMode, SegmentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity') and constid = object_id('de_fw_req_activity_pkey'))
begin
	alter table de_fw_req_activity add constraint de_fw_req_activity_pkey primary key clustered (customer_name, project_name, process_name, componentname, activityid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_documentation') and constid = object_id('de_fw_req_activity_documentation_pkey'))
begin
	alter table de_fw_req_activity_documentation add constraint de_fw_req_activity_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_ilbo') and constid = object_id('de_fw_req_activity_ilbo_pkey'))
begin
	alter table de_fw_req_activity_ilbo add constraint de_fw_req_activity_ilbo_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_ilbo_task') and constid = object_id('de_fw_req_activity_ilbo_task_pkey'))
begin
	alter table de_fw_req_activity_ilbo_task add constraint de_fw_req_activity_ilbo_task_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_ilbo_task_extension_map') and constid = object_id('de_fw_req_activity_ilbo_task_extension_map_pkey'))
begin
	alter table de_fw_req_activity_ilbo_task_extension_map add constraint de_fw_req_activity_ilbo_task_extension_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_local_info') and constid = object_id('de_fw_req_activity_local_info_pkey'))
begin
	alter table de_fw_req_activity_local_info add constraint de_fw_req_activity_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_activity_task') and constid = object_id('de_fw_req_activity_task_pkey'))
begin
	alter table de_fw_req_activity_task add constraint de_fw_req_activity_task_pkey primary key clustered (customer_name, project_name, process_name, component_name, activityid, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_br_bterm') and constid = object_id('de_fw_req_br_bterm_pkey'))
begin
	alter table de_fw_req_br_bterm add constraint de_fw_req_br_bterm_pkey primary key clustered (customer_name, project_name, process_name, component_name, brname, paramno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_br_documentation') and constid = object_id('de_fw_req_br_documentation_pkey'))
begin
	alter table de_fw_req_br_documentation add constraint de_fw_req_br_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_br_error') and constid = object_id('de_fw_req_br_error_pkey'))
begin
	alter table de_fw_req_br_error add constraint de_fw_req_br_error_pkey primary key clustered (customer_name, project_name, process_name, component_name, brname, errorcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_br_error_placeholder') and constid = object_id('de_fw_req_br_error_placeholder_pkey'))
begin
	alter table de_fw_req_br_error_placeholder add constraint de_fw_req_br_error_placeholder_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, brsequence, brname, errorcode, placeholdersequence, paramno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_bterm') and constid = object_id('de_fw_req_bterm_pkey'))
begin
	alter table de_fw_req_bterm add constraint de_fw_req_bterm_pkey primary key clustered (customer_name, project_name, process_name, component_name, btname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_bterm_enumerated_option') and constid = object_id('de_fw_req_bterm_enumerated_option_pkey'))
begin
	alter table de_fw_req_bterm_enumerated_option add constraint de_fw_req_bterm_enumerated_option_pkey primary key clustered (customer_name, project_name, process_name, component_name, btname, langid, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_bterm_group') and constid = object_id('de_fw_req_bterm_group_pkey'))
begin
	alter table de_fw_req_bterm_group add constraint de_fw_req_bterm_group_pkey primary key clustered (customer_name, project_name, process_name, componentname, btname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_bterm_synonym') and constid = object_id('de_fw_req_bterm_synonym_pkey'))
begin
	alter table de_fw_req_bterm_synonym add constraint de_fw_req_bterm_synonym_pkey primary key clustered (customer_name, project_name, process_name, component_name, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_businessrule') and constid = object_id('de_fw_req_businessrule_pkey'))
begin
	alter table de_fw_req_businessrule add constraint de_fw_req_businessrule_pkey primary key clustered (customer_name, project_name, process_name, component_name, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_component_documentation') and constid = object_id('de_fw_req_component_documentation_pkey'))
begin
	alter table de_fw_req_component_documentation add constraint de_fw_req_component_documentation_pkey primary key clustered (customer_name, project_name, componentname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_component_local_info') and constid = object_id('de_fw_req_component_local_info_pkey'))
begin
	alter table de_fw_req_component_local_info add constraint de_fw_req_component_local_info_pkey primary key clustered (customer_name, project_name, process_name, componentname, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_error') and constid = object_id('de_fw_req_error_pkey'))
begin
	alter table de_fw_req_error add constraint de_fw_req_error_pkey primary key clustered (customer_name, project_name, process_name, component_name, errorcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_error_local_info') and constid = object_id('de_fw_req_error_local_info_pkey'))
begin
	alter table de_fw_req_error_local_info add constraint de_fw_req_error_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, errorcode, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo') and constid = object_id('de_fw_req_ilbo_pkey'))
begin
	alter table de_fw_req_ilbo add constraint de_fw_req_ilbo_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_control') and constid = object_id('de_fw_req_ilbo_control_pkey'))
begin
	alter table de_fw_req_ilbo_control add constraint de_fw_req_ilbo_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_control_property') and constid = object_id('de_fw_req_ilbo_control_property_pkey'))
begin
	alter table de_fw_req_ilbo_control_property add constraint de_fw_req_ilbo_control_property_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, viewname, propertyname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_data_publish') and constid = object_id('de_fw_req_ilbo_data_publish_pkey'))
begin
	alter table de_fw_req_ilbo_data_publish add constraint de_fw_req_ilbo_data_publish_pkey primary key clustered (customer_name, project_name, linkid, ilbocode, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_data_use') and constid = object_id('de_fw_req_ilbo_data_use_pkey'))
begin
	alter table de_fw_req_ilbo_data_use add constraint de_fw_req_ilbo_data_use_pkey primary key clustered (customer_name, project_name, parentilbocode, linkid, taskname, dataitemname, controlid, viewname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_documentation') and constid = object_id('de_fw_req_ilbo_documentation_pkey'))
begin
	alter table de_fw_req_ilbo_documentation add constraint de_fw_req_ilbo_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_link_local_info') and constid = object_id('de_fw_req_ilbo_link_local_info_pkey'))
begin
	alter table de_fw_req_ilbo_link_local_info add constraint de_fw_req_ilbo_link_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, linkid, ilbocode, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_link_publish') and constid = object_id('de_fw_req_ilbo_link_publish_pkey'))
begin
	alter table de_fw_req_ilbo_link_publish add constraint de_fw_req_ilbo_link_publish_pkey primary key clustered (customer_name, project_name, linkid, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_link_use_documentation') and constid = object_id('de_fw_req_ilbo_link_use_documentation_pkey'))
begin
	alter table de_fw_req_ilbo_link_use_documentation add constraint de_fw_req_ilbo_link_use_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, parentilbocode, linkid, taskname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_linkuse') and constid = object_id('de_fw_req_ilbo_linkuse_pkey'))
begin
	alter table de_fw_req_ilbo_linkuse add constraint de_fw_req_ilbo_linkuse_pkey primary key clustered (customer_name, project_name, parentilbocode, linkid, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_local_info') and constid = object_id('de_fw_req_ilbo_local_info_pkey'))
begin
	alter table de_fw_req_ilbo_local_info add constraint de_fw_req_ilbo_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_project_details') and constid = object_id('de_fw_req_ilbo_project_details_pkey'))
begin
	alter table de_fw_req_ilbo_project_details add constraint de_fw_req_ilbo_project_details_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_tab_properties') and constid = object_id('de_fw_req_ilbo_tab_properties_pkey'))
begin
	alter table de_fw_req_ilbo_tab_properties add constraint de_fw_req_ilbo_tab_properties_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, tabname, propertyname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_tabs') and constid = object_id('de_fw_req_ilbo_tabs_pkey'))
begin
	alter table de_fw_req_ilbo_tabs add constraint de_fw_req_ilbo_tabs_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, tabname, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_task_rpt') and constid = object_id('de_fw_req_ilbo_task_rpt_PK'))
begin
	alter table de_fw_req_ilbo_task_rpt add constraint de_fw_req_ilbo_task_rpt_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ilbocode, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_view') and constid = object_id('de_fw_req_ilbo_view_pkey'))
begin
	alter table de_fw_req_ilbo_view add constraint de_fw_req_ilbo_view_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, viewname, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_view_documentation') and constid = object_id('de_fw_req_ilbo_view_documentation_pkey'))
begin
	alter table de_fw_req_ilbo_view_documentation add constraint de_fw_req_ilbo_view_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, viewname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilbo_view_local_info') and constid = object_id('de_fw_req_ilbo_view_local_info_pkey'))
begin
	alter table de_fw_req_ilbo_view_local_info add constraint de_fw_req_ilbo_view_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, viewname, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_ilboctrl_initval') and constid = object_id('de_fw_req_ilboctrl_initval_pkey'))
begin
	alter table de_fw_req_ilboctrl_initval add constraint de_fw_req_ilboctrl_initval_pkey primary key clustered (customer_name, project_name, process_name, component_name, ilbocode, controlid, viewname, sequenceno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_lang_bterm_synonym') and constid = object_id('de_fw_req_lang_bterm_synonym_pkey'))
begin
	alter table de_fw_req_lang_bterm_synonym add constraint de_fw_req_lang_bterm_synonym_pkey primary key clustered (customer_name, project_name, process_name, component_name, btsynonym, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_language') and constid = object_id('de_fw_req_language_pkey'))
begin
	alter table de_fw_req_language add constraint de_fw_req_language_pkey primary key clustered (customer_name, project_name, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_precision') and constid = object_id('de_fw_req_precision_pkey'))
begin
	alter table de_fw_req_precision add constraint de_fw_req_precision_pkey primary key clustered (customer_name, project_name, process_name, component_name, precisiontype)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_process') and constid = object_id('de_fw_req_process_pkey'))
begin
	alter table de_fw_req_process add constraint de_fw_req_process_pkey primary key clustered (customer_name, project_name, processname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_process_component') and constid = object_id('de_fw_req_process_component_pkey'))
begin
	alter table de_fw_req_process_component add constraint de_fw_req_process_component_pkey primary key clustered (customer_name, project_name, parentprocess, componentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_process_documentation') and constid = object_id('de_fw_req_process_documentation_pkey'))
begin
	alter table de_fw_req_process_documentation add constraint de_fw_req_process_documentation_pkey primary key clustered (customer_name, project_name, processname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_reference_value') and constid = object_id('de_fw_req_reference_value_pkey'))
begin
	alter table de_fw_req_reference_value add constraint de_fw_req_reference_value_pkey primary key clustered (customer_name, project_name, process_name, component_name, referencetype, langid, referencevalue)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_state') and constid = object_id('de_fw_req_state_pkey'))
begin
	alter table de_fw_req_state add constraint de_fw_req_state_pkey primary key clustered (customer_name, project_name, statename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_state_activity') and constid = object_id('de_fw_req_state_activity_pkey'))
begin
	alter table de_fw_req_state_activity add constraint de_fw_req_state_activity_pkey primary key clustered (customer_name, project_name, process_name, componentname, statename, activityid, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_state_component') and constid = object_id('de_fw_req_state_component_pkey'))
begin
	alter table de_fw_req_state_component add constraint de_fw_req_state_component_pkey primary key clustered (customer_name, project_name, process_name, statename, componentname, vcname, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_system_parameters') and constid = object_id('de_fw_req_system_parameters_pkey'))
begin
	alter table de_fw_req_system_parameters add constraint de_fw_req_system_parameters_pkey primary key clustered (customer_name, project_name, paramname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_task') and constid = object_id('de_fw_req_task_pkey'))
begin
	alter table de_fw_req_task add constraint de_fw_req_task_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_task_br_error_context') and constid = object_id('de_fw_req_task_br_error_context_pkey'))
begin
	alter table de_fw_req_task_br_error_context add constraint de_fw_req_task_br_error_context_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, brsequence, brname, errorcode)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_task_documentation') and constid = object_id('de_fw_req_task_documentation_pkey'))
begin
	alter table de_fw_req_task_documentation add constraint de_fw_req_task_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_task_local_info') and constid = object_id('de_fw_req_task_local_info_pkey'))
begin
	alter table de_fw_req_task_local_info add constraint de_fw_req_task_local_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_task_rule') and constid = object_id('de_fw_req_task_rule_pkey'))
begin
	alter table de_fw_req_task_rule add constraint de_fw_req_task_rule_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, brsequence, brname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_taskrulesynonym_map') and constid = object_id('de_fw_req_taskrulesynonym_map_pkey'))
begin
	alter table de_fw_req_taskrulesynonym_map add constraint de_fw_req_taskrulesynonym_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, taskname, brsequence, brname, paramno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_value_chain') and constid = object_id('de_fw_req_value_chain_pkey'))
begin
	alter table de_fw_req_value_chain add constraint de_fw_req_value_chain_pkey primary key clustered (customer_name, project_name, vcname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_req_vc_documentation') and constid = object_id('de_fw_req_vc_documentation_pkey'))
begin
	alter table de_fw_req_vc_documentation add constraint de_fw_req_vc_documentation_pkey primary key clustered (customer_name, project_name, vcname, langid, paragraphno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_glossary') and constid = object_id('de_glossary_pkey'))
begin
	alter table de_glossary add constraint de_glossary_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_glossary_lng_extn') and constid = object_id('de_glossary_lng_extn_pkey'))
begin
	alter table de_glossary_lng_extn add constraint de_glossary_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_hidden_view') and constid = object_id('de_hidden_view_pkey'))
begin
	alter table de_hidden_view add constraint de_hidden_view_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, section_name, control_bt_synonym, hidden_view_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_hidden_view_usage') and constid = object_id('de_hidden_view_usage_pkey'))
begin
	alter table de_hidden_view_usage add constraint de_hidden_view_usage_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, control_page_name, control_bt_sysnonym, hidden_view_bt_sysnonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ibo_resolution') and constid = object_id('de_ibo_resolution_pkey'))
begin
	alter table de_ibo_resolution add constraint de_ibo_resolution_pkey primary key clustered (customer_name, project_name, process_name, component_name, requestor_ibo_name, requestor_ibo_segment_name, provider_ibo_name, provider_ibo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ibo_segment') and constid = object_id('de_ibo_segment_pkey'))
begin
	alter table de_ibo_segment add constraint de_ibo_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name, ibo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ibo_segment_dataitem') and constid = object_id('de_ibo_segment_dataitem_pkey'))
begin
	alter table de_ibo_segment_dataitem add constraint de_ibo_segment_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name, ibo_segment_name, ibo_segment_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_interaction_bo') and constid = object_id('de_interaction_bo_pkey'))
begin
	alter table de_interaction_bo add constraint de_interaction_bo_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_is_dataitem_map') and constid = object_id('de_is_dataitem_map_pkey'))
begin
	alter table de_is_dataitem_map add constraint de_is_dataitem_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, ps_name, is_name, called_segment_name, called_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_is_interaction') and constid = object_id('de_is_interaction_pkey'))
begin
	alter table de_is_interaction add constraint de_is_interaction_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, ps_name, is_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_listedit_column') and constid = object_id('de_listedit_column_PKey'))
begin
	alter table de_listedit_column add constraint de_listedit_column_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_listedit_control_map') and constid = object_id('de_listedit_control_map_PKey'))
begin
	alter table de_listedit_control_map add constraint de_listedit_control_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_LogicExt_ui_control_dtl') and constid = object_id('de_LogicExt_ui_control_dtl_pkey'))
begin
	alter table de_LogicExt_ui_control_dtl add constraint de_LogicExt_ui_control_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_LogicExt_ui_grid_dtl') and constid = object_id('de_LogicExt_ui_grid_dtl_pkey'))
begin
	alter table de_LogicExt_ui_grid_dtl add constraint de_LogicExt_ui_grid_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_message') and constid = object_id('de_message_pkey'))
begin
	alter table de_message add constraint de_message_pkey primary key clustered (customer_name, project_name, process_name, component_name, error_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_method_doc') and constid = object_id('de_method_doc_pkey'))
begin
	alter table de_method_doc add constraint de_method_doc_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_method_message_map') and constid = object_id('de_method_message_map_pkey'))
begin
	alter table de_method_message_map add constraint de_method_message_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_nativeapp_mapping') and constid = object_id('de_nativeapp_mapping_PK'))
begin
	alter table de_nativeapp_mapping add constraint de_nativeapp_mapping_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_non_ui_control') and constid = object_id('de_non_ui_control_pkey'))
begin
	alter table de_non_ui_control add constraint de_non_ui_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_message') and constid = object_id('de_offtask_message_pk'))
begin
	alter table de_offtask_message add constraint de_offtask_message_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_message_lng_extn') and constid = object_id('de_offtask_message_lng_extn_pk'))
begin
	alter table de_offtask_message_lng_extn add constraint de_offtask_message_lng_extn_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, language_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_message_ph') and constid = object_id('de_offtask_message_ph_pk'))
begin
	alter table de_offtask_message_ph add constraint de_offtask_message_ph_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, message_id, placeholder_seq, mapped_control_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_message_phlist') and constid = object_id('de_offtask_message_phlist_pk'))
begin
	alter table de_offtask_message_phlist add constraint de_offtask_message_phlist_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, message_id, placeholder_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_query') and constid = object_id('de_offtask_query_pk'))
begin
	alter table de_offtask_query add constraint de_offtask_query_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, query_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_queryparam') and constid = object_id('de_offtask_queryparam_pk'))
begin
	alter table de_offtask_queryparam add constraint de_offtask_queryparam_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, query_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_offtask_tskqrymap') and constid = object_id('de_offtask_tskqrymap_pk'))
begin
	alter table de_offtask_tskqrymap add constraint de_offtask_tskqrymap_pk primary key clustered (Customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, query_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone') and constid = object_id('de_phone_pkey'))
begin
	alter table de_phone add constraint de_phone_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_column_group_mapping') and constid = object_id('de_phone_column_group_mapping_pkey'))
begin
	alter table de_phone_column_group_mapping add constraint de_phone_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_columngroup') and constid = object_id('de_phone_columngroup_pkey'))
begin
	alter table de_phone_columngroup add constraint de_phone_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_control') and constid = object_id('de_phone_control_pkey'))
begin
	alter table de_phone_control add constraint de_phone_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_grid') and constid = object_id('de_phone_grid_pkey'))
begin
	alter table de_phone_grid add constraint de_phone_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_grid_columngroup') and constid = object_id('de_phone_grid_columngroup_pkey'))
begin
	alter table de_phone_grid_columngroup add constraint de_phone_grid_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_page') and constid = object_id('de_phone_page_pkey'))
begin
	alter table de_phone_page add constraint de_phone_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_phone_section') and constid = object_id('de_phone_section_pkey'))
begin
	alter table de_phone_section add constraint de_phone_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_pivot_configure') and constid = object_id('de_pivot_configure_pkey'))
begin
	alter table de_pivot_configure add constraint de_pivot_configure_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_pivot_fields') and constid = object_id('de_pivot_fields_pkey'))
begin
	alter table de_pivot_fields add constraint de_pivot_fields_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_pivot_lang_extn') and constid = object_id('de_pivot_lang_extn_pkey'))
begin
	alter table de_pivot_lang_extn add constraint de_pivot_lang_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, DisplayField, Languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_precision_type') and constid = object_id('de_precision_type_pkey'))
begin
	alter table de_precision_type add constraint de_precision_type_pkey primary key clustered (customer_name, project_name, process_name, component_name, pt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_provider_ibo') and constid = object_id('de_provider_ibo_pkey'))
begin
	alter table de_provider_ibo add constraint de_provider_ibo_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_provider_ibo_segment') and constid = object_id('de_provider_ibo_segment_pkey'))
begin
	alter table de_provider_ibo_segment add constraint de_provider_ibo_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name, ibo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_publication') and constid = object_id('de_publication_pkey'))
begin
	alter table de_publication add constraint de_publication_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_publication_dataitem') and constid = object_id('de_publication_dataitem_pkey'))
begin
	alter table de_publication_dataitem add constraint de_publication_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_publication_dataitem_mr_pop') and constid = object_id('de_publication_dataitem_mr_pop_pkey'))
begin
	alter table de_publication_dataitem_mr_pop add constraint de_publication_dataitem_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, Mig_Id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_publication_ref') and constid = object_id('de_publication_ref_pkey'))
begin
	alter table de_publication_ref add constraint de_publication_ref_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, publication_name, ref_subscriber_comp_name, ref_subscriber_act_name, ref_subscriber_ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_quick_code_mst') and constid = object_id('de_quick_code_mst_pkey'))
begin
	alter table de_quick_code_mst add constraint de_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_radio_button') and constid = object_id('de_radio_button_pkey'))
begin
	alter table de_radio_button add constraint de_radio_button_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_appvw_dtl') and constid = object_id('pk_de_re_wsinp_appvw_dtl'))
begin
	alter table de_re_wsinp_appvw_dtl add constraint pk_de_re_wsinp_appvw_dtl primary key clustered (customer_code, project_code, area_code, notification_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_area_desc') and constid = object_id('pk_de_re_wsinp_area_desc'))
begin
	alter table de_re_wsinp_area_desc add constraint pk_de_re_wsinp_area_desc primary key clustered (customer_code, project_code, area_code, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_area_dtl') and constid = object_id('pk_de_re_wsinp_area_dtl'))
begin
	alter table de_re_wsinp_area_dtl add constraint pk_de_re_wsinp_area_dtl primary key clustered (customer_code, project_code, area_code, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_area_hdr') and constid = object_id('pk_de_re_wsinp_area_hdr'))
begin
	alter table de_re_wsinp_area_hdr add constraint pk_de_re_wsinp_area_hdr primary key clustered (customer_code, project_code, area_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_cat_desc_hdr') and constid = object_id('pk_de_re_wsinp_cat_desc_hdr'))
begin
	alter table de_re_wsinp_cat_desc_hdr add constraint pk_de_re_wsinp_cat_desc_hdr primary key clustered (customer_code, project_code, area_code, cat_key, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_cat_hdr') and constid = object_id('pk_de_re_wsinp_cat_hdr'))
begin
	alter table de_re_wsinp_cat_hdr add constraint pk_de_re_wsinp_cat_hdr primary key clustered (customer_code, project_code, area_code, cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_cat_parameters') and constid = object_id('pk_de_re_wsinp_cat_parameters'))
begin
	alter table de_re_wsinp_cat_parameters add constraint pk_de_re_wsinp_cat_parameters primary key clustered (customer_code, project_code, area_code, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_con_security') and constid = object_id('pk_de_re_wsinp_con_security'))
begin
	alter table de_re_wsinp_con_security add constraint pk_de_re_wsinp_con_security primary key clustered (consider_security, customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_def_msg_dtl') and constid = object_id('pk_de_re_wsinp_def_msg_dtl'))
begin
	alter table de_re_wsinp_def_msg_dtl add constraint pk_de_re_wsinp_def_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, notification_type, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_def_wf_setup') and constid = object_id('pk_de_re_wsinp_def_wf_setup'))
begin
	alter table de_re_wsinp_def_wf_setup add constraint pk_de_re_wsinp_def_wf_setup primary key clustered (customer_code, project_code, area_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_doc_flow_dtl') and constid = object_id('pk_de_re_wsinp_doc_flow_dtl'))
begin
	alter table de_re_wsinp_doc_flow_dtl add constraint pk_de_re_wsinp_doc_flow_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_docflow_msg_dtl') and constid = object_id('pk_de_re_wsinp_docflow_msg_dtl'))
begin
	alter table de_re_wsinp_docflow_msg_dtl add constraint pk_de_re_wsinp_docflow_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, notification_type, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_actcode') and constid = object_id('pk_de_re_wsinp_nonrvw_actcode'))
begin
	alter table de_re_wsinp_nonrvw_actcode add constraint pk_de_re_wsinp_nonrvw_actcode primary key clustered (customer_code, project_code, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_actdesc') and constid = object_id('pk_de_re_wsinp_nonrvw_actdesc'))
begin
	alter table de_re_wsinp_nonrvw_actdesc add constraint pk_de_re_wsinp_nonrvw_actdesc primary key clustered (customer_code, project_code, component_name, activity_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_compcode') and constid = object_id('pk_de_re_wsinp_nonrvw_compcode'))
begin
	alter table de_re_wsinp_nonrvw_compcode add constraint pk_de_re_wsinp_nonrvw_compcode primary key clustered (customer_code, project_code, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_compdesc') and constid = object_id('pk_de_re_wsinp_nonrvw_compdesc'))
begin
	alter table de_re_wsinp_nonrvw_compdesc add constraint pk_de_re_wsinp_nonrvw_compdesc primary key clustered (customer_code, project_code, component_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_taskcode') and constid = object_id('pk_de_re_wsinp_nonrvw_taskcode'))
begin
	alter table de_re_wsinp_nonrvw_taskcode add constraint pk_de_re_wsinp_nonrvw_taskcode primary key clustered (customer_code, project_code, component_name, activity_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_nonrvw_taskdesc') and constid = object_id('pk_de_re_wsinp_nonrvw_taskdesc'))
begin
	alter table de_re_wsinp_nonrvw_taskdesc add constraint pk_de_re_wsinp_nonrvw_taskdesc primary key clustered (customer_code, project_code, component_name, activity_name, task_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_qc_dtl') and constid = object_id('pk_de_re_wsinp_qc_dtl'))
begin
	alter table de_re_wsinp_qc_dtl add constraint pk_de_re_wsinp_qc_dtl primary key clustered (wf_quick_code, wf_quick_code_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_qc_hdr') and constid = object_id('pk_de_re_wsinp_qc_hdr'))
begin
	alter table de_re_wsinp_qc_hdr add constraint pk_de_re_wsinp_qc_hdr primary key clustered (wf_quick_code_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_qc_lang_dtl') and constid = object_id('pk_de_re_wsinp_qc_lang_dtl'))
begin
	alter table de_re_wsinp_qc_lang_dtl add constraint pk_de_re_wsinp_qc_lang_dtl primary key clustered (wf_quick_code_type, wf_quick_code, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_rcn_dtl') and constid = object_id('pk_de_re_wsinp_rcn_dtl'))
begin
	alter table de_re_wsinp_rcn_dtl add constraint pk_de_re_wsinp_rcn_dtl primary key clustered (customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_security_dtl') and constid = object_id('pk_de_re_wsinp_security_dtl'))
begin
	alter table de_re_wsinp_security_dtl add constraint pk_de_re_wsinp_security_dtl primary key clustered (customer_code, project_code, permitted_user, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_secusr_dtl') and constid = object_id('pk_de_re_wsinp_secusr_dtl'))
begin
	alter table de_re_wsinp_secusr_dtl add constraint pk_de_re_wsinp_secusr_dtl primary key clustered (customer_code, project_code, permitted_user)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_service_dtl') and constid = object_id('pk_de_re_wsinp_service_dtl'))
begin
	alter table de_re_wsinp_service_dtl add constraint pk_de_re_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, cat_key, sequence_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_state_desc_dtl') and constid = object_id('pk_de_re_wsinp_state_desc_dtl'))
begin
	alter table de_re_wsinp_state_desc_dtl add constraint pk_de_re_wsinp_state_desc_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_task_dtl') and constid = object_id('pk_de_re_wsinp_task_dtl'))
begin
	alter table de_re_wsinp_task_dtl add constraint pk_de_re_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_tsk_state_dtl') and constid = object_id('pk_de_re_wsinp_tsk_state_dtl'))
begin
	alter table de_re_wsinp_tsk_state_dtl add constraint pk_de_re_wsinp_tsk_state_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_tsk_stflow_dtl') and constid = object_id('pk_de_re_wsinp_tsk_stflow_dtl'))
begin
	alter table de_re_wsinp_tsk_stflow_dtl add constraint pk_de_re_wsinp_tsk_stflow_dtl primary key clustered (cat_key, state_name, to_cat_key, to_state, area_code, customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_re_wsinp_usr_noncon_task') and constid = object_id('pk_de_re_wsinp_usr_noncon_task'))
begin
	alter table de_re_wsinp_usr_noncon_task add constraint pk_de_re_wsinp_usr_noncon_task primary key clustered (customer_code, project_code, area_code, cat_key, calling_catkey)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_chart_service_dataitem') and constid = object_id('de_refine_chart_service_dataitem_pkey'))
begin
	alter table de_refine_chart_service_dataitem add constraint de_refine_chart_service_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_chart_service_segment') and constid = object_id('de_refine_chart_service_segment_pkey'))
begin
	alter table de_refine_chart_service_segment add constraint de_refine_chart_service_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, chart_id, chart_section, servicename, segmentname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_ilboservice_map') and constid = object_id('de_refine_ilboservice_map_pkey'))
begin
	alter table de_refine_ilboservice_map add constraint de_refine_ilboservice_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ilbocode, servicename, activityid, taskname, segmentname, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_method_documentation') and constid = object_id('de_refine_method_documentation_pkey'))
begin
	alter table de_refine_method_documentation add constraint de_refine_method_documentation_pkey primary key clustered (customer_name, project_name, process_name, component_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_method_error_map') and constid = object_id('de_refine_method_error_map_pkey'))
begin
	alter table de_refine_method_error_map add constraint de_refine_method_error_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, req_errorno, des_errorno, sp_errorno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_parameter') and constid = object_id('de_refine_parameter_pkey'))
begin
	alter table de_refine_parameter add constraint de_refine_parameter_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_process_section') and constid = object_id('de_refine_process_section_pkey'))
begin
	alter table de_refine_process_section add constraint de_refine_process_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, ps_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_refine_taskreuse_info') and constid = object_id('de_refine_taskreuse_info_pkey'))
begin
	alter table de_refine_taskreuse_info add constraint de_refine_taskreuse_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, service_name, ui_name, page_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_action_dataset') and constid = object_id('de_report_action_dataset_pkey'))
begin
	alter table de_report_action_dataset add constraint de_report_action_dataset_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_action_dataset_dataitem') and constid = object_id('de_report_action_dataset_dataitem_PK'))
begin
	alter table de_report_action_dataset_dataitem add constraint de_report_action_dataset_dataitem_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_action_dataset_segment') and constid = object_id('de_report_action_dataset_segment_PK'))
begin
	alter table de_report_action_dataset_segment add constraint de_report_action_dataset_segment_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_action_segment') and constid = object_id('de_report_action_segment_pkey'))
begin
	alter table de_report_action_segment add constraint de_report_action_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_action_segment_dataitem') and constid = object_id('de_report_action_segment_dataitem_pkey'))
begin
	alter table de_report_action_segment_dataitem add constraint de_report_action_segment_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_attributes') and constid = object_id('de_report_attributes_PK'))
begin
	alter table de_report_attributes add constraint de_report_attributes_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_dataset_dataitem_map') and constid = object_id('de_report_dataset_dataitem_map_PK'))
begin
	alter table de_report_dataset_dataitem_map add constraint de_report_dataset_dataitem_map_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name, dataset_dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_report_dataset_segment_map') and constid = object_id('de_report_dataset_segment_map_PK'))
begin
	alter table de_report_dataset_segment_map add constraint de_report_dataset_segment_map_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, report_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_requestor_ibo') and constid = object_id('de_requestor_ibo_pkey'))
begin
	alter table de_requestor_ibo add constraint de_requestor_ibo_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_requestor_ibo_dataitem') and constid = object_id('de_requestor_ibo_dataitem_pkey'))
begin
	alter table de_requestor_ibo_dataitem add constraint de_requestor_ibo_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name, ibo_segment_name, ibo_dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_requestor_ibo_segment') and constid = object_id('de_requestor_ibo_segment_pkey'))
begin
	alter table de_requestor_ibo_segment add constraint de_requestor_ibo_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, ibo_name, ibo_segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_resolved_link') and constid = object_id('de_resolved_link_pkey'))
begin
	alter table de_resolved_link add constraint de_resolved_link_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_resolved_link_dataitem') and constid = object_id('de_resolved_link_dataitem_pkey'))
begin
	alter table de_resolved_link_dataitem add constraint de_resolved_link_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, subscription_name, subscribed_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_resolvelist_data_map') and constid = object_id('de_resolvelist_data_map_PKey'))
begin
	alter table de_resolvelist_data_map add constraint de_resolvelist_data_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_rmt_ico_ui') and constid = object_id('de_rmt_ico_ui_pkey'))
begin
	alter table de_rmt_ico_ui add constraint de_rmt_ico_ui_pkey primary key clustered (customer_name, project_name, ico_no, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_rulegroup') and constid = object_id('de_rulegroup_pkey'))
begin
	alter table de_rulegroup add constraint de_rulegroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_rulegroup_step') and constid = object_id('de_rulegroup_step_pkey'))
begin
	alter table de_rulegroup_step add constraint de_rulegroup_step_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_rulegroup_step_msg') and constid = object_id('de_rulegroup_step_msg_pkey'))
begin
	alter table de_rulegroup_step_msg add constraint de_rulegroup_step_msg_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_column') and constid = object_id('de_schema_column_pkey'))
begin
	alter table de_schema_column add constraint de_schema_column_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, table_name, column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_dependentobj') and constid = object_id('de_schema_dependentobj_pkey'))
begin
	alter table de_schema_dependentobj add constraint de_schema_dependentobj_pkey primary key clustered (db_name, sp_name, dep_object_type, dep_object_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_function') and constid = object_id('de_schema_function_pkey'))
begin
	alter table de_schema_function add constraint de_schema_function_pkey primary key clustered (db_name, function_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_function_param') and constid = object_id('de_schema_function_param_pkey'))
begin
	alter table de_schema_function_param add constraint de_schema_function_param_pkey primary key clustered (db_name, function_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_index') and constid = object_id('de_schema_index_pkey'))
begin
	alter table de_schema_index add constraint de_schema_index_pkey primary key clustered (db_name, Index_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_index_columns') and constid = object_id('de_schema_index_columns_pkey'))
begin
	alter table de_schema_index_columns add constraint de_schema_index_columns_pkey primary key clustered (db_name, Index_name, Table_name, Column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_option') and constid = object_id('de_schema_option_pkey'))
begin
	alter table de_schema_option add constraint de_schema_option_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, option_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_preference') and constid = object_id('de_schema_preference_pkey'))
begin
	alter table de_schema_preference add constraint de_schema_preference_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, entity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_relation') and constid = object_id('de_schema_relation_pkey'))
begin
	alter table de_schema_relation add constraint de_schema_relation_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_relation_det') and constid = object_id('de_schema_relation_det_pkey'))
begin
	alter table de_schema_relation_det add constraint de_schema_relation_det_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, parent_column_name, child_column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_scripts') and constid = object_id('de_schema_scripts_pkey'))
begin
	alter table de_schema_scripts add constraint de_schema_scripts_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, object_type, object_name, script_option)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_sp') and constid = object_id('de_schema_sp_pkey'))
begin
	alter table de_schema_sp add constraint de_schema_sp_pkey primary key clustered (db_name, sp_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_sp_param') and constid = object_id('de_schema_sp_param_pkey'))
begin
	alter table de_schema_sp_param add constraint de_schema_sp_param_pkey primary key clustered (db_name, sp_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_table') and constid = object_id('de_schema_table_pkey'))
begin
	alter table de_schema_table add constraint de_schema_table_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, table_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_udd') and constid = object_id('de_schema_udd_pkey'))
begin
	alter table de_schema_udd add constraint de_schema_udd_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, udd_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_validation_log') and constid = object_id('de_schema_validation_log_pkey'))
begin
	alter table de_schema_validation_log add constraint de_schema_validation_log_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, guid, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_view') and constid = object_id('de_schema_view_pkey'))
begin
	alter table de_schema_view add constraint de_schema_view_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, view_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_schema_view_column') and constid = object_id('de_schema_view_column_pkey'))
begin
	alter table de_schema_view_column add constraint de_schema_view_column_pkey primary key clustered (customer_name, project_name, process_name, component_name, db_name, view_name, column_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_scratch_variable') and constid = object_id('de_scratch_variable_pkey'))
begin
	alter table de_scratch_variable add constraint de_scratch_variable_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, task_name, scratch_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_scratch_variables_sys') and constid = object_id('de_scratch_variables_sys_pkey'))
begin
	alter table de_scratch_variables_sys add constraint de_scratch_variables_sys_pkey primary key clustered (customer_name, project_name, process_name, component_name, btsynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_service_gen_log') and constid = object_id('de_service_gen_log_pkey'))
begin
	alter table de_service_gen_log add constraint de_service_gen_log_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_service_gen_log_dtl') and constid = object_id('de_service_gen_log_dtl_pkey'))
begin
	alter table de_service_gen_log_dtl add constraint de_service_gen_log_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, sequence_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_service_le_selservice_temp') and constid = object_id('de_service_le_selservice_temp_pk'))
begin
	alter table de_service_le_selservice_temp add constraint de_service_le_selservice_temp_pk primary key clustered (customer_name, project_name, process_name, component_name, ecr_no, Activity_name, ui_name, servicename, RDBMS_Type, ctxt_user, guid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_service_logic_extn_dtl') and constid = object_id('de_service_logic_extn_dtl_pk'))
begin
	alter table de_service_logic_extn_dtl add constraint de_service_logic_extn_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, servicename, section_name, methodid, methodname, BR_sequence, RDBMS_Type, ext_before)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_service_logic_extn_pattern') and constid = object_id('de_service_logic_extn_pattern_pk'))
begin
	alter table de_service_logic_extn_pattern add constraint de_service_logic_extn_pattern_pk primary key clustered (customer_name, project_name, process_name, component_name, RDBMS_Type, method_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_sp_report_action_dataitem') and constid = object_id('de_sp_report_action_dataitem_pkey'))
begin
	alter table de_sp_report_action_dataitem add constraint de_sp_report_action_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, report_name, segment_name, dataitem_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_sp_report_action_segment') and constid = object_id('de_sp_report_action_segment_pkey'))
begin
	alter table de_sp_report_action_segment add constraint de_sp_report_action_segment_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, report_name, segment_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_subscription') and constid = object_id('de_subscription_pkey'))
begin
	alter table de_subscription add constraint de_subscription_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_subscription_dataitem') and constid = object_id('de_subscription_dataitem_pkey'))
begin
	alter table de_subscription_dataitem add constraint de_subscription_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, subscribed_bt_synonym, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_sync_view') and constid = object_id('de_sync_view_pkey'))
begin
	alter table de_sync_view add constraint de_sync_view_pkey primary key clustered (Customer_name, Project_name, process_name, component_name, activity_name, ui_name, map_le_controlid, legrid_view_name, map_le_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet') and constid = object_id('de_tablet_pkey'))
begin
	alter table de_tablet add constraint de_tablet_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_column_group_mapping') and constid = object_id('de_tablet_column_group_mapping_pkey'))
begin
	alter table de_tablet_column_group_mapping add constraint de_tablet_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_columngroup') and constid = object_id('de_tablet_columngroup_pkey'))
begin
	alter table de_tablet_columngroup add constraint de_tablet_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_control') and constid = object_id('de_tablet_control_pkey'))
begin
	alter table de_tablet_control add constraint de_tablet_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_grid') and constid = object_id('de_tablet_grid_pkey'))
begin
	alter table de_tablet_grid add constraint de_tablet_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_grid_columngroup') and constid = object_id('de_tablet_grid_columngroup_pkey'))
begin
	alter table de_tablet_grid_columngroup add constraint de_tablet_grid_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_page') and constid = object_id('de_tablet_page_pkey'))
begin
	alter table de_tablet_page add constraint de_tablet_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tablet_section') and constid = object_id('de_tablet_section_pkey'))
begin
	alter table de_tablet_section add constraint de_tablet_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_task_callout_map') and constid = object_id('de_task_callout_map_pkey'))
begin
	alter table de_task_callout_map add constraint de_task_callout_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, calloutname, Calloutmode, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_task_control_attributemap') and constid = object_id('de_task_control_attributemap_pkey'))
begin
	alter table de_task_control_attributemap add constraint de_task_control_attributemap_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, page_name, control_bt_synonym, propertytype, propertyname)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_task_control_map') and constid = object_id('de_task_control_map_pkey'))
begin
	alter table de_task_control_map add constraint de_task_control_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, page_name, section_name, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_task_service_map') and constid = object_id('de_task_service_map_pkey'))
begin
	alter table de_task_service_map add constraint de_task_service_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_Templates') and constid = object_id('de_Templates_pk'))
begin
	alter table de_Templates add constraint de_Templates_pk primary key clustered (customer_name, project_name, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tree_dtl') and constid = object_id('de_tree_dtl_pkey'))
begin
	alter table de_tree_dtl add constraint de_tree_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tree_sample_data') and constid = object_id('de_tree_sample_data_pkey'))
begin
	alter table de_tree_sample_data add constraint de_tree_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, Node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_tree_sample_data_map') and constid = object_id('de_tree_sample_data_map_pkey'))
begin
	alter table de_tree_sample_data_map add constraint de_tree_sample_data_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui') and constid = object_id('de_ui_pkey'))
begin
	alter table de_ui add constraint de_ui_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_column_group_mapping') and constid = object_id('de_ui_column_group_mapping_pkey'))
begin
	alter table de_ui_column_group_mapping add constraint de_ui_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_columngroup') and constid = object_id('de_ui_columngroup_pkey'))
begin
	alter table de_ui_columngroup add constraint de_ui_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_combolink') and constid = object_id('de_ui_combolink_pkey'))
begin
	alter table de_ui_combolink add constraint de_ui_combolink_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_contextmenu_task_dtl') and constid = object_id('de_ui_contextmenu_task_dtl_pk'))
begin
	alter table de_ui_contextmenu_task_dtl add constraint de_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, section_name, control_bt_synonym, task_name, ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_control') and constid = object_id('de_ui_control_pkey'))
begin
	alter table de_ui_control add constraint de_ui_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_device') and constid = object_id('de_ui_device_pkey'))
begin
	alter table de_ui_device add constraint de_ui_device_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_device_control') and constid = object_id('de_ui_device_control_pkey'))
begin
	alter table de_ui_device_control add constraint de_ui_device_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_device_grid') and constid = object_id('de_ui_device_grid_pkey'))
begin
	alter table de_ui_device_grid add constraint de_ui_device_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_device_page') and constid = object_id('de_ui_device_page_pkey'))
begin
	alter table de_ui_device_page add constraint de_ui_device_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_device_section') and constid = object_id('de_ui_device_section_pkey'))
begin
	alter table de_ui_device_section add constraint de_ui_device_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_displaytext_lang_extn') and constid = object_id('de_ui_displaytext_lang_extn_PKey'))
begin
	alter table de_ui_displaytext_lang_extn add constraint de_ui_displaytext_lang_extn_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_task_name, lang_id, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_grid') and constid = object_id('de_ui_grid_pkey'))
begin
	alter table de_ui_grid add constraint de_ui_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_grid_columngroup') and constid = object_id('de_ui_grid_columngroup_pkey'))
begin
	alter table de_ui_grid_columngroup add constraint de_ui_grid_columngroup_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_history') and constid = object_id('de_ui_history_pk'))
begin
	alter table de_ui_history add constraint de_ui_history_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, History_version)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_ico') and constid = object_id('de_ui_ico_pkey'))
begin
	alter table de_ui_ico add constraint de_ui_ico_pkey primary key clustered (customer_name, project_name, ico_no, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_page') and constid = object_id('de_ui_page_pkey'))
begin
	alter table de_ui_page add constraint de_ui_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_pageevents') and constid = object_id('de_ui_pageevents_pk'))
begin
	alter table de_ui_pageevents add constraint de_ui_pageevents_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_placeholder_lng_extn') and constid = object_id('de_ui_placeholder_lng_extn_pk'))
begin
	alter table de_ui_placeholder_lng_extn add constraint de_ui_placeholder_lng_extn_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_section') and constid = object_id('de_ui_section_pkey'))
begin
	alter table de_ui_section add constraint de_ui_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_section_control_map') and constid = object_id('de_ui_section_control_map_pkey'))
begin
	alter table de_ui_section_control_map add constraint de_ui_section_control_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state') and constid = object_id('de_ui_state_pkey'))
begin
	alter table de_ui_state add constraint de_ui_state_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_column') and constid = object_id('de_ui_state_column_PK'))
begin
	alter table de_ui_state_column add constraint de_ui_state_column_PK primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_control') and constid = object_id('de_ui_state_control_pkey'))
begin
	alter table de_ui_state_control add constraint de_ui_state_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_page') and constid = object_id('de_ui_state_page_PK'))
begin
	alter table de_ui_state_page add constraint de_ui_state_page_PK primary key clustered (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, state_id, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_section') and constid = object_id('de_ui_state_section_pkey'))
begin
	alter table de_ui_state_section add constraint de_ui_state_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_task') and constid = object_id('de_ui_state_task_pkey'))
begin
	alter table de_ui_state_task add constraint de_ui_state_task_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_state_task_mst') and constid = object_id('de_ui_state_task_mst_pkey'))
begin
	alter table de_ui_state_task_mst add constraint de_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_taskpane') and constid = object_id('de_ui_taskpane_pk'))
begin
	alter table de_ui_taskpane add constraint de_ui_taskpane_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_Temp_placeholders') and constid = object_id('de_ui_Temp_placeholders_pk'))
begin
	alter table de_ui_Temp_placeholders add constraint de_ui_Temp_placeholders_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid, placeholder)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_template_controlmap') and constid = object_id('de_ui_template_controlmap_pk'))
begin
	alter table de_ui_template_controlmap add constraint de_ui_template_controlmap_pk primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_toolbar') and constid = object_id('de_ui_toolbar_PKey'))
begin
	alter table de_ui_toolbar add constraint de_ui_toolbar_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_toolbar_group') and constid = object_id('de_ui_toolbar_group_PKey'))
begin
	alter table de_ui_toolbar_group add constraint de_ui_toolbar_group_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_toolbar_mapping') and constid = object_id('de_ui_toolbar_mapping_PKey'))
begin
	alter table de_ui_toolbar_mapping add constraint de_ui_toolbar_mapping_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_tooltip_lng_extn') and constid = object_id('de_ui_tooltip_lng_extn_pk'))
begin
	alter table de_ui_tooltip_lng_extn add constraint de_ui_tooltip_lng_extn_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_ui_traversal') and constid = object_id('de_ui_traversal_pkey'))
begin
	alter table de_ui_traversal add constraint de_ui_traversal_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_user_section') and constid = object_id('de_user_section_pkey'))
begin
	alter table de_user_section add constraint de_user_section_pkey primary key clustered (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end
-- Added on 31st Dec Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_up_defaulting_dtl') AND CONSTID = OBJECT_ID('PK_de_up_defaulting_dtl'))
BEGIN
	ALTER TABLE de_up_defaulting_dtl ADD CONSTRAINT PK_de_up_defaulting_dtl 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, control_bt_synonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_template') AND CONSTID = OBJECT_ID('PK_de_mdcf_template'))
BEGIN
	ALTER TABLE de_mdcf_template ADD CONSTRAINT PK_de_mdcf_template 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_template_ilbo') AND CONSTID = OBJECT_ID('PK_de_mdcf_template_ilbo'))
BEGIN
	ALTER TABLE de_mdcf_template_ilbo ADD CONSTRAINT PK_de_mdcf_template_ilbo
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name)
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_template_task') AND CONSTID = OBJECT_ID('PK_de_mdcf_template_task'))
BEGIN
	ALTER TABLE de_mdcf_template_task ADD CONSTRAINT PK_de_mdcf_template_task 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_template_taskseq') AND CONSTID = OBJECT_ID('PK_de_mdcf_template_taskseq'))
BEGIN
	ALTER TABLE de_mdcf_template_taskseq ADD CONSTRAINT PK_de_mdcf_template_taskseq 
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name, Task_Description, Task_sequence)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_template_taskcontrol_map') AND CONSTID = OBJECT_ID('PK_de_mdcf_template_taskcontrol_map'))
BEGIN
	ALTER TABLE de_mdcf_template_taskcontrol_map ADD CONSTRAINT PK_de_mdcf_template_taskcontrol_map
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, activity_name, ui_name, Task_Name, BT_synonym_name)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_mdcf_glossary_lng_extn') AND CONSTID = OBJECT_ID('PK_de_mdcf_glossary_lng_extn'))
BEGIN
	ALTER TABLE de_mdcf_glossary_lng_extn ADD CONSTRAINT PK_de_mdcf_glossary_lng_extn
	PRIMARY KEY CLUSTERED (customer_name, project_name, process_name, component_name, TemplateID, bt_synonym_name, languageid)
END
GO
-- Added on 31st Dec Ends

if not exists (select 'x' from sysconstraints where id = object_id('de_wsinp_ecn_dtl') and constid = object_id('pk_de_wsinp_ecn_dtl'))
begin
	alter table de_wsinp_ecn_dtl add constraint pk_de_wsinp_ecn_dtl primary key clustered (customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_wsinp_is_control_dtl') and constid = object_id('pk_de_wsinp_is_control_dtl'))
begin
	alter table de_wsinp_is_control_dtl add constraint pk_de_wsinp_is_control_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, page_code, control_name, view_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_wsinp_mypage_control_dtl') and constid = object_id('pk_de_wsinp_mypage_control_dtl'))
begin
	alter table de_wsinp_mypage_control_dtl add constraint pk_de_wsinp_mypage_control_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, page_code, control_name, view_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_wsinp_service_dtl') and constid = object_id('pk_de_wsinp_service_dtl'))
begin
	alter table de_wsinp_service_dtl add constraint pk_de_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name, sequence_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_wsinp_task_dtl') and constid = object_id('pk_de_wsinp_task_dtl'))
begin
	alter table de_wsinp_task_dtl add constraint pk_de_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, component_name, activity_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_assignment_dtl') and constid = object_id('dlp_assignment_dtl_pkey'))
begin
	alter table dlp_assignment_dtl add constraint dlp_assignment_dtl_pkey primary key clustered (customer_name, project_name, plan_id, structure_id, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_assignment_history') and constid = object_id('dlp_assignment_history_pkey'))
begin
	alter table dlp_assignment_history add constraint dlp_assignment_history_pkey primary key clustered (customer_name, project_name, dlp_version_no, plan_id, structure_id, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_change_assignment') and constid = object_id('dlp_change_assignment_pkey'))
begin
	alter table dlp_change_assignment add constraint dlp_change_assignment_pkey primary key clustered (customer_name, project_name, his_version_no, plan_id, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_change_log') and constid = object_id('dlp_change_log_pkey'))
begin
	alter table dlp_change_log add constraint dlp_change_log_pkey primary key clustered (customer_name, project_name, his_version_no, plan_id, structure_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_fin_note_hdr') and constid = object_id('dlp_fin_note_hdr_pkey'))
begin
	alter table dlp_fin_note_hdr add constraint dlp_fin_note_hdr_pkey primary key clustered (customer_name, project_name, finalization_note_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_gen_planstructure') and constid = object_id('dlp_gen_planstructure_pkey'))
begin
	alter table dlp_gen_planstructure add constraint dlp_gen_planstructure_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, guid, user_id, structure_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_gen_workproduct') and constid = object_id('dlp_gen_workproduct_pkey'))
begin
	alter table dlp_gen_workproduct add constraint dlp_gen_workproduct_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, user_id, guid, workproduct_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_genplan_doc') and constid = object_id('dlp_genplan_Doc_pkey'))
begin
	alter table dlp_genplan_doc add constraint dlp_genplan_Doc_pkey primary key clustered (Customer_name, project_name, hlp_finalization_note, plan_id, Work_product_type, Work_product, DocumentType, DocumentNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_internal_milstone') and constid = object_id('dlp_internal_milstone_pkey'))
begin
	alter table dlp_internal_milstone add constraint dlp_internal_milstone_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, hlp_plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('DLP_Leaf_predecessors') and constid = object_id('dlp_leaf_predecessors_pkey'))
begin
	alter table DLP_Leaf_predecessors add constraint dlp_leaf_predecessors_pkey primary key clustered (customer_name, project_name, plan_id, predecessors)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_nonsoftware_wp') and constid = object_id('dlp_nonsoftware_wp_pkey'))
begin
	alter table dlp_nonsoftware_wp add constraint dlp_nonsoftware_wp_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, work_product, work_prodcut_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_plan_detail_arc') and constid = object_id('dlp_plan_detail_arc_pkey'))
begin
	alter table dlp_plan_detail_arc add constraint dlp_plan_detail_arc_pkey primary key clustered (customer_name, project_name, hlp_finalization_note)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_plan_dtl') and constid = object_id('dlp_plan_dtl_pkey'))
begin
	alter table dlp_plan_dtl add constraint dlp_plan_dtl_pkey primary key clustered (customer_name, project_name, plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_plan_history') and constid = object_id('dlp_plan_history_pkey'))
begin
	alter table dlp_plan_history add constraint dlp_plan_history_pkey primary key clustered (customer_name, project_name, dlp_version_no, plan_id, structure_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_plan_metrix_dtl') and constid = object_id('dlp_plan_metrix_dtl_pkey'))
begin
	alter table dlp_plan_metrix_dtl add constraint dlp_plan_metrix_dtl_pkey primary key clustered (Customer_Name, Project_Name, plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_pln_structure') and constid = object_id('dlp_pln_structure_pkey'))
begin
	alter table dlp_pln_structure add constraint dlp_pln_structure_pkey primary key clustered (customer_name, project_name, plan_structure_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_pln_structure_ref_template') and constid = object_id('dlp_pln_structure_ref_template_pkey'))
begin
	alter table dlp_pln_structure_ref_template add constraint dlp_pln_structure_ref_template_pkey primary key clustered (customer_name, project_name, plan_structure_id, ref_template_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_quick_code_met') and constid = object_id('dlp_quick_code_met_pkey'))
begin
	alter table dlp_quick_code_met add constraint dlp_quick_code_met_pkey primary key clustered (quick_code, quick_code_type, quick_code_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_wp_activities') and constid = object_id('dlp_wp_activities_pkey'))
begin
	alter table dlp_wp_activities add constraint dlp_wp_activities_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, document_type, document_no, user_id, wp_id, process_name, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_wp_component') and constid = object_id('dlp_wp_component_pkey'))
begin
	alter table dlp_wp_component add constraint dlp_wp_component_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, document_type, document_no, user_id, wp_id, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_wp_document') and constid = object_id('dlp_wp_document_pkey'))
begin
	alter table dlp_wp_document add constraint dlp_wp_document_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, document_type, document_no, user_id, wp_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_wp_process') and constid = object_id('dlp_wp_process_pkey'))
begin
	alter table dlp_wp_process add constraint dlp_wp_process_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, document_type, document_no, user_id, wp_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('dlp_wp_ui') and constid = object_id('dlp_wp_ui_pkey'))
begin
	alter table dlp_wp_ui add constraint dlp_wp_ui_pkey primary key clustered (customer_name, project_name, hlp_finalization_note, document_type, document_no, user_id, wp_id, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('dm_plf_release_objdet') and constid = object_id('pk_dm_plf_release_objdet'))
begin
	alter table dm_plf_release_objdet add constraint pk_dm_plf_release_objdet primary key clustered (CustomerName, ProjectName, ServerName, ReleaseNo, DBName, ObjectType, ObjectName)
end

if not exists (select 'x' from sysconstraints where id = object_id('dmn_reference_table') and constid = object_id('dmn_reference_table_pk'))
begin
	alter table dmn_reference_table add constraint dmn_reference_table_pk primary key clustered (UpdationType, Impacted_Table)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_CONTROLS') and constid = object_id('pk_DOCMAP_CONTROLS'))
begin
	alter table DOCMAP_CONTROLS add constraint pk_DOCMAP_CONTROLS primary key clustered (TMPL_CODE, MAP_CODE, SECTION_CODE, CONTROL_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_GRID_LIST') and constid = object_id('pk_DOCMAP_GRID_LIST'))
begin
	alter table DOCMAP_GRID_LIST add constraint pk_DOCMAP_GRID_LIST primary key clustered (TMPL_CODE, MAP_CODE, SECTION_CODE, CONTROL_CODE, GRID_COL_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_MAP') and constid = object_id('pk_DOCMAP_MAP'))
begin
	alter table DOCMAP_MAP add constraint pk_DOCMAP_MAP primary key clustered (customerid, projectid)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_MAPPINGS') and constid = object_id('pk_DOCMAP_MAPPINGS'))
begin
	alter table DOCMAP_MAPPINGS add constraint pk_DOCMAP_MAPPINGS primary key clustered (TMPL_CODE, MAP_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_SECTIONS') and constid = object_id('pk_DOCMAP_SECTIONS'))
begin
	alter table DOCMAP_SECTIONS add constraint pk_DOCMAP_SECTIONS primary key clustered (TMPL_CODE, MAP_CODE, SECTION_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('DOCMAP_TMPL') and constid = object_id('pk_DOCMAP_TMPL'))
begin
	alter table DOCMAP_TMPL add constraint pk_DOCMAP_TMPL primary key clustered (TMPL_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_comreview') and constid = object_id('ec_comreview_pkey'))
begin
	alter table ec_comreview add constraint ec_comreview_pkey primary key clustered (customer_name, project_name, ico_no, process_name, component_name, reviewset_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_comreview_dtl') and constid = object_id('ec_comreview_dtl_pkey'))
begin
	alter table ec_comreview_dtl add constraint ec_comreview_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_comreview_type') and constid = object_id('ec_comreview_type_pkey'))
begin
	alter table ec_comreview_type add constraint ec_comreview_type_pkey primary key clustered (customer_name, project_name, ico_no, process_name, component_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_conreview') and constid = object_id('ec_conreview_pkey'))
begin
	alter table ec_conreview add constraint ec_conreview_pkey primary key clustered (customer_name, project_name, reviewset_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_conreview_dtl') and constid = object_id('ec_conreview_dtl_pkey'))
begin
	alter table ec_conreview_dtl add constraint ec_conreview_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_conreview_type') and constid = object_id('ec_conreview_type_pkey'))
begin
	alter table ec_conreview_type add constraint ec_conreview_type_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_dccreview') and constid = object_id('ec_dccreview_pkey'))
begin
	alter table ec_dccreview add constraint ec_dccreview_pkey primary key clustered (customer_name, project_name, reviewset_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_dccreview_dtl') and constid = object_id('ec_dccreview_dtl_pkey'))
begin
	alter table ec_dccreview_dtl add constraint ec_dccreview_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_dccreview_type') and constid = object_id('ec_dccreview_type_pkey'))
begin
	alter table ec_dccreview_type add constraint ec_dccreview_type_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_rereview') and constid = object_id('ec_rereview_pkey'))
begin
	alter table ec_rereview add constraint ec_rereview_pkey primary key clustered (customer_name, project_name, reviewset_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_rereview_dtl') and constid = object_id('ec_rereview_dtl_pkey'))
begin
	alter table ec_rereview_dtl add constraint ec_rereview_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('ec_rereview_type') and constid = object_id('ec_rereview_type_pkey'))
begin
	alter table ec_rereview_type add constraint ec_rereview_type_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_attach_go_mst') and constid = object_id('PK_em_attach_go_mst'))
begin
	alter table em_attach_go_mst add constraint PK_em_attach_go_mst primary key clustered (Customerid, ProjectID, artifact_id, artifact_tag)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_attachments_dtl') and constid = object_id('PK_em_attachments_dtl'))
begin
	alter table em_attachments_dtl add constraint PK_em_attachments_dtl primary key clustered (artifact_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_attachments_mst') and constid = object_id('PK_em_attachments_mst'))
begin
	alter table em_attachments_mst add constraint PK_em_attachments_mst primary key clustered (Customerid, ProjectID, ScenarioID, scenariolevel, entityindex, entitytype, doctype, artifact_id, artifact_tag)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_configuration') and constid = object_id('PK_em_configuration'))
begin
	alter table em_configuration add constraint PK_em_configuration primary key clustered (Customerid, Projectid, UserID, Config_Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario') and constid = object_id('PK_em_scenario'))
begin
	alter table em_scenario add constraint PK_em_scenario primary key clustered (Customerid, ProjectID, ScenarioID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity') and constid = object_id('PK_em_scenario_activity'))
begin
	alter table em_scenario_activity add constraint PK_em_scenario_activity primary key clustered (Customerid, ProjectID, ScenarioID, bpid, functionid)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity_association') and constid = object_id('PK_em_scenario_activity_association'))
begin
	alter table em_scenario_activity_association add constraint PK_em_scenario_activity_association primary key clustered (CustomerID, ProjectID, ScenarioID, BPID, FunctionID, ActivityID, StartEventName, EntEventName, ExtEventName)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity_association_wrk') and constid = object_id('PK_em_scenario_activity_association_wrk'))
begin
	alter table em_scenario_activity_association_wrk add constraint PK_em_scenario_activity_association_wrk primary key clustered (CustomerID, ProjectID, ScenarioID, ActNodeID, StartEventID, EntEventID, ExtEventID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity_events_wrk') and constid = object_id('PK_em_scenario_activity_events_wrk'))
begin
	alter table em_scenario_activity_events_wrk add constraint PK_em_scenario_activity_events_wrk primary key clustered (CustomerID, ProjectID, ScenarioID, EventID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity_ui_wrk') and constid = object_id('PK_em_scenario_activity_ui_wrk'))
begin
	alter table em_scenario_activity_ui_wrk add constraint PK_em_scenario_activity_ui_wrk primary key clustered (Customerid, ProjectID, ScenarioID, NodeID, UIID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_activity_wrk') and constid = object_id('PK_em_scenario_activity_wrk'))
begin
	alter table em_scenario_activity_wrk add constraint PK_em_scenario_activity_wrk primary key clustered (Customerid, ProjectID, ScenarioID, NodeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_app') and constid = object_id('PK_em_scenario_app'))
begin
	alter table em_scenario_app add constraint PK_em_scenario_app primary key clustered (Customerid, ProjectID, ScenarioID, InfoType)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_bp') and constid = object_id('PK_em_scenario_bp'))
begin
	alter table em_scenario_bp add constraint PK_em_scenario_bp primary key clustered (Customerid, ProjectID, ScenarioID, bpid)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_bp_association') and constid = object_id('PK_em_scenario_bp_association'))
begin
	alter table em_scenario_bp_association add constraint PK_em_scenario_bp_association primary key clustered (CustomerID, ProjectID, ScenarioID, BPID, FunctionID, StartEventName, EntEventName, ExtEventName)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_bp_association_wrk') and constid = object_id('PK_em_scenario_bp_association_wrk'))
begin
	alter table em_scenario_bp_association_wrk add constraint PK_em_scenario_bp_association_wrk primary key clustered (CustomerID, ProjectID, ScenarioID, FnNodeID, StartEventID, EntEventID, ExtEventID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_bp_events_wrk') and constid = object_id('PK_em_scenario_bp_events_wrk'))
begin
	alter table em_scenario_bp_events_wrk add constraint PK_em_scenario_bp_events_wrk primary key clustered (CustomerID, ProjectID, ScenarioID, EventID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_function_wrk') and constid = object_id('PK_em_scenario_function_wrk'))
begin
	alter table em_scenario_function_wrk add constraint PK_em_scenario_function_wrk primary key clustered (Customerid, ProjectID, ScenarioID, NodeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_nodedtl') and constid = object_id('PK_em_scenario_nodedtl'))
begin
	alter table em_scenario_nodedtl add constraint PK_em_scenario_nodedtl primary key clustered (Customerid, ProjectID, ScenarioID, ScenarioLevel, NodeID, NodeType, NodeSeq)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_nodedtl_bl') and constid = object_id('PK_em_scenario_nodedtl_bl'))
begin
	alter table em_scenario_nodedtl_bl add constraint PK_em_scenario_nodedtl_bl primary key clustered (Customerid, ProjectID, ScenarioID, ScenarioLevel, NodeID, NodeType, NodeSeq)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_scenario_status') and constid = object_id('PK_em_scenario_status'))
begin
	alter table em_scenario_status add constraint PK_em_scenario_status primary key clustered (Customerid, ProjectID, ScenarioID, ScenarioLevel)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_temp_mluidetails') and constid = object_id('PK_em_temp_mluidetails'))
begin
	alter table em_temp_mluidetails add constraint PK_em_temp_mluidetails primary key clustered (GUID, UIName)
end

if not exists (select 'x' from sysconstraints where id = object_id('em_ui_nodedtl') and constid = object_id('PK_em_ui_nodedtl'))
begin
	alter table em_ui_nodedtl add constraint PK_em_ui_nodedtl primary key clustered (Customerid, ProjectID, WorkReqID, BPID, FuncID, ActID, UIID, NodeType, NodeSeq, NodeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_203exp_comp_details') and constid = object_id('engg_dc_203exp_comp_details_pk'))
begin
	alter table engg_dc_203exp_comp_details add constraint engg_dc_203exp_comp_details_pk primary key clustered (src_customer_name, src_project_name, src_ecr_no, src_process_name, src_FunctionId, src_component_name, mig_id, src_server, src_database)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_203exp_exceptions_pub') and constid = object_id('engg_dc_203exp_exceptions_pub_unq_idx_pkey'))
begin
	alter table engg_dc_203exp_exceptions_pub add constraint engg_dc_203exp_exceptions_pub_unq_idx_pkey primary key clustered (exp_id, exp_descr, exp_Level, exp_cat, spname)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_203exp_exceptions_re_pub') and constid = object_id('engg_dc_203exp_exceptions_re_pub_unq_idx_pkey'))
begin
	alter table engg_dc_203exp_exceptions_re_pub add constraint engg_dc_203exp_exceptions_re_pub_unq_idx_pkey primary key clustered (exp_id, exp_descr, exp_Level, exp_cat, spname)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_203exp_exceptions_sol_pub') and constid = object_id('engg_dc_203exp_exceptions_sol_pub_unq_idx_pkey'))
begin
	alter table engg_dc_203exp_exceptions_sol_pub add constraint engg_dc_203exp_exceptions_sol_pub_unq_idx_pkey primary key clustered (exp_id, exp_descr, exp_Level, exp_cat, spname)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_203exp_status_details') and constid = object_id('engg_dc_203exp_status_details_pk'))
begin
	alter table engg_dc_203exp_status_details add constraint engg_dc_203exp_status_details_pk primary key clustered (src_component_name, dst_component_name, mig_id, exp_id, src_server, src_database)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_dc_DM_plf_version') and constid = object_id('dm_plf_user_version_map_plfDB_pkey'))
begin
	alter table engg_dc_DM_plf_version add constraint dm_plf_user_version_map_plfDB_pkey primary key clustered (customer_name, project_name, version_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_Admin_status') and constid = object_id('engg_devcon_codegen_Admin_status_pkey'))
begin
	alter table engg_devcon_codegen_Admin_status add constraint engg_devcon_codegen_Admin_status_pkey primary key clustered (Guid, CustomerName, ProjectName, Request_ID, ComponentName, Ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_client_dtls') and constid = object_id('engg_devcon_codegen_client_dtls_pkey'))
begin
	alter table engg_devcon_codegen_client_dtls add constraint engg_devcon_codegen_client_dtls_pkey primary key clustered (MachineName, MachineIp)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_client_metadata') and constid = object_id('engg_devcon_codegen_client_metadata_pkey'))
begin
	alter table engg_devcon_codegen_client_metadata add constraint engg_devcon_codegen_client_metadata_pkey primary key clustered (Customername, Projectname, CodeGenClient, AppUrl)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_mail_dtls') and constid = object_id('engg_devcon_codegen_mail_dtls_pkey'))
begin
	alter table engg_devcon_codegen_mail_dtls add constraint engg_devcon_codegen_mail_dtls_pkey primary key clustered (Guid)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_mail_dtls_his') and constid = object_id('engg_devcon_codegen_mail_dtls_his_pkey'))
begin
	alter table engg_devcon_codegen_mail_dtls_his add constraint engg_devcon_codegen_mail_dtls_his_pkey primary key clustered (Guid, customername, projectname)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_mail_metadata') and constid = object_id('engg_devcon_codegen_mail_metadata_pkey'))
begin
	alter table engg_devcon_codegen_mail_metadata add constraint engg_devcon_codegen_mail_metadata_pkey primary key clustered (Customername, Projectname, Empid, ReportType)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_options_lang_his') and constid = object_id('engg_devcon_codegen_options_lang_his_pkey'))
begin
	alter table engg_devcon_codegen_options_lang_his add constraint engg_devcon_codegen_options_lang_his_pkey primary key clustered (customername, projectname, request_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_options_metadata') and constid = object_id('engg_devcon_codegen_options_metadata_pkey'))
begin
	alter table engg_devcon_codegen_options_metadata add constraint engg_devcon_codegen_options_metadata_pkey primary key clustered (customer_name, project_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_schedule_dtls') and constid = object_id('engg_devcon_codegen_schedule_dtls_pkey'))
begin
	alter table engg_devcon_codegen_schedule_dtls add constraint engg_devcon_codegen_schedule_dtls_pkey primary key clustered (Guid, Customername, Projectname, Request_ID)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_schedule_dtls_his') and constid = object_id('engg_devcon_codegen_schedule_dtls_his_pkey'))
begin
	alter table engg_devcon_codegen_schedule_dtls_his add constraint engg_devcon_codegen_schedule_dtls_his_pkey primary key clustered (Customername, Projectname, Request_ID)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_status_dtls') and constid = object_id('engg_devcon_codegen_status_dtls_pkey'))
begin
	alter table engg_devcon_codegen_status_dtls add constraint engg_devcon_codegen_status_dtls_pkey primary key clustered (Guid, ComponentName, Ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_codegen_status_dtls_his') and constid = object_id('engg_devcon_codegen_status_dtls_his_pkey'))
begin
	alter table engg_devcon_codegen_status_dtls_his add constraint engg_devcon_codegen_status_dtls_his_pkey primary key clustered (Guid, customername, projectname, request_id, ComponentName, Ecrno)
end

if not exists (select 'x' from sysconstraints where id = object_id('Engg_devcon_doccmp_splist') and constid = object_id('Engg_devcon_doccmp_splist_unq_idx_pkey'))
begin
	alter table Engg_devcon_doccmp_splist add constraint Engg_devcon_doccmp_splist_unq_idx_pkey primary key clustered (Sp_id, Node_type, Sp_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_devcon_querylist') and constid = object_id('engg_devcon_querylist_pkey'))
begin
	alter table engg_devcon_querylist add constraint engg_devcon_querylist_pkey primary key clustered (ReportId)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_developerconsole_version') and constid = object_id('devconversionPK'))
begin
	alter table engg_developerconsole_version add constraint devconversionPK primary key clustered (ComponentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_edk_components') and constid = object_id('engg_edk_components_pkey'))
begin
	alter table engg_edk_components add constraint engg_edk_components_pkey primary key clustered (customer_name, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_gendeliv_reportconfig') and constid = object_id('engg_gendeliv_reportconfig_unq_idx_pkey'))
begin
	alter table engg_gendeliv_reportconfig add constraint engg_gendeliv_reportconfig_unq_idx_pkey primary key clustered (Customer_Name, Project_Name, Ecr_No, Process_Name, Component_Name, Activity_Name, Ui_Name, Report_Name, Task_Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_203exp_status_trg') and constid = object_id('engg_mr_203exp_status_trg_pkey'))
begin
	alter table engg_mr_203exp_status_trg add constraint engg_mr_203exp_status_trg_pkey primary key clustered (dst_component_name, mig_id, src_server, src_database)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_activity_mst_203_1') and constid = object_id('engg_mr_activity_mst_203_1_pkey'))
begin
	alter table engg_mr_activity_mst_203_1 add constraint engg_mr_activity_mst_203_1_pkey primary key clustered (dst_process_name, dst_comp_name, dst_act_name, scr_act_name, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_comp_mst_203_1') and constid = object_id('engg_mr_comp_mst_203_1_pkey'))
begin
	alter table engg_mr_comp_mst_203_1 add constraint engg_mr_comp_mst_203_1_pkey primary key clustered (dst_process_name, dst_comp_name, scr_comp_name, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_mig_chronicle_203_1') and constid = object_id('engg_mr_mig_chronicle_203_1_pkey'))
begin
	alter table engg_mr_mig_chronicle_203_1 add constraint engg_mr_mig_chronicle_203_1_pkey primary key clustered (req_id, src_customer_name, src_project_name, src_process_name, src_component_name, src_activity_name, src_ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Engg_mr_mig_service_map') and constid = object_id('engg_mr_mig_service_map_pkey'))
begin
	alter table Engg_mr_mig_service_map add constraint engg_mr_mig_service_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, service_name, req_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Engg_mr_mig_status_203_1') and constid = object_id('Engg_mr_mig_status_203_1_pkey'))
begin
	alter table Engg_mr_mig_status_203_1 add constraint Engg_mr_mig_status_203_1_pkey primary key clustered (dst_customer_name, dst_project_name, dst_process_name, dst_component_name, Mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_process_mst_203_1') and constid = object_id('engg_mr_process_mst_203_1_pkey'))
begin
	alter table engg_mr_process_mst_203_1 add constraint engg_mr_process_mst_203_1_pkey primary key clustered (dst_process_name, scr_process_name, src_customer_name, src_project_name, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_ui_mst_203_1') and constid = object_id('engg_mr_ui_mst_203_1_pk'))
begin
	alter table engg_mr_ui_mst_203_1 add constraint engg_mr_ui_mst_203_1_pk primary key clustered (src_customer_name, src_project_name, src_ecr_no, src_process_name, src_FunctionId, src_component_name, src_activity_name, src_ui_name, dst_customer_name, dst_project_name, dst_process_name, dst_functionid, dst_component_name, dst_activity_name, dst_ui_name, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_mr_ui_mst_203_1_src') and constid = object_id('engg_mr_ui_mst_203_1_src_pk'))
begin
	alter table engg_mr_ui_mst_203_1_src add constraint engg_mr_ui_mst_203_1_src_pk primary key clustered (src_customer_name, src_project_name, src_ecr_no, src_process_name, src_FunctionId, src_component_name, dst_customer_name, dst_project_name, dst_process_name, dst_functionid, dst_component_name, dst_activity_name, dst_ui_name, mig_id, src_server, src_database)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_offline_activity') and constid = object_id('engg_offline_activity_pk'))
begin
	alter table engg_offline_activity add constraint engg_offline_activity_pk primary key clustered (Guid, CustomerName, ProjectName, BPName, FunctionName, ActivityID, ActivityName)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_offline_bp') and constid = object_id('engg_offline_bp_pk'))
begin
	alter table engg_offline_bp add constraint engg_offline_bp_pk primary key clustered (Guid, CustomerName, ProjectName, BPID, BPName)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_offline_function') and constid = object_id('engg_offline_function_pk'))
begin
	alter table engg_offline_function add constraint engg_offline_function_pk primary key clustered (Guid, CustomerName, ProjectName, BPName, FunctionID, FunctionName)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_offline_ui') and constid = object_id('engg_offline_ui_pk'))
begin
	alter table engg_offline_ui add constraint engg_offline_ui_pk primary key clustered (Guid, CustomerName, ProjectName, BPName, FunctionName, ActivityName, UIID, UIName)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_previewmaintenance_log') and constid = object_id('engg_previewmaintenance_log_PKey'))
begin
	alter table engg_previewmaintenance_log add constraint engg_previewmaintenance_log_PKey primary key clustered (trans_no, trans_seqno)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_rdc_link_offset') and constid = object_id('engg_rdc_link_offset_prkey'))
begin
	alter table engg_rdc_link_offset add constraint engg_rdc_link_offset_prkey primary key clustered (RDC_Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_Revmig_status') and constid = object_id('engg_Revmig_status_pkey'))
begin
	alter table engg_Revmig_status add constraint engg_Revmig_status_pkey primary key clustered (Customer_name, Project_name, Process_name, Component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('engg_task_mapping') and constid = object_id('engg_task_mapping_pr_key'))
begin
	alter table engg_task_mapping add constraint engg_task_mapping_pr_key primary key clustered (customer_name, project_name, process_name, component_name, ui_name, activity_name, page_name, old_task_name, new_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_action_mst') and constid = object_id('ep_action_mst_pkey'))
begin
	alter table ep_action_mst add constraint ep_action_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_action_mst_lng_extn') and constid = object_id('ep_action_mst_lng_extn_pkey'))
begin
	alter table ep_action_mst_lng_extn add constraint ep_action_mst_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_action_section_map') and constid = object_id('ep_action_section_map_pkey'))
begin
	alter table ep_action_section_map add constraint ep_action_section_map_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, section_page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_attachdocument_dtl') and constid = object_id('ep_attachdocument_dtl_pk'))
begin
	alter table ep_attachdocument_dtl add constraint ep_attachdocument_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, req_rcn_ecr_no, page_bt_synonym, task_name, service_name, method_name, key_column)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_calendar_configure') and constid = object_id('ep_Calendar_configure_pkey'))
begin
	alter table ep_calendar_configure add constraint ep_Calendar_configure_pkey primary key clustered (customer_name, Project_name, Req_no, Process_name, Component_name, Activity_name, ui_name, page_name, section_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_chart_header') and constid = object_id('ep_chart_header_pkey'))
begin
	alter table ep_chart_header add constraint ep_chart_header_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_chart_sample_data') and constid = object_id('ep_chart_sample_data_pkey'))
begin
	alter table ep_chart_sample_data add constraint ep_chart_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_chart_series') and constid = object_id('ep_chart_series_pkey'))
begin
	alter table ep_chart_series add constraint ep_chart_series_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_component_glossary_mst') and constid = object_id('ep_component_glossary_mst_pkey'))
begin
	alter table ep_component_glossary_mst add constraint ep_component_glossary_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_component_glossary_mst_lng_extn') and constid = object_id('ep_component_glossary_mst_lng_extn_pkey'))
begin
	alter table ep_component_glossary_mst_lng_extn add constraint ep_component_glossary_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_contextual_links') and constid = object_id('ep_contextual_links_PK'))
begin
	alter table ep_contextual_links add constraint ep_contextual_links_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_control_extensions') and constid = object_id('ep_control_extensions_PK'))
begin
	alter table ep_control_extensions add constraint ep_control_extensions_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_custom_listedit') and constid = object_id('ep_custom_listedit_PKey'))
begin
	alter table ep_custom_listedit add constraint ep_custom_listedit_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_date_highlight_column') and constid = object_id('ep_date_highlight_column_PKey'))
begin
	alter table ep_date_highlight_column add constraint ep_date_highlight_column_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, listedit_synonym, listedit_column_synonym, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_date_highlight_control_map') and constid = object_id('ep_date_highlight_control_map_PKey'))
begin
	alter table ep_date_highlight_control_map add constraint ep_date_highlight_control_map_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_deleted_task_dtl') and constid = object_id('ep_deleted_task_dtl_pkey'))
begin
	alter table ep_deleted_task_dtl add constraint ep_deleted_task_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_device_quick_code_met') and constid = object_id('ep_device_quick_code_met_pk'))
begin
	alter table ep_device_quick_code_met add constraint ep_device_quick_code_met_pk primary key clustered (parameter_type, parameter_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_enum_value_dtl') and constid = object_id('ep_enum_value_dtl_pkey'))
begin
	alter table ep_enum_value_dtl add constraint ep_enum_value_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_enum_value_dtl_lng_extn') and constid = object_id('ep_enum_value_dtl_lng_extn_pkey'))
begin
	alter table ep_enum_value_dtl_lng_extn add constraint ep_enum_value_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ext_js_control_dtl') and constid = object_id('ep_ext_js_control_dtl_PK'))
begin
	alter table ep_ext_js_control_dtl add constraint ep_ext_js_control_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ext_js_section_column_dtl') and constid = object_id('ep_ext_js_section_column_dtl_PK'))
begin
	alter table ep_ext_js_section_column_dtl add constraint ep_ext_js_section_column_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, Column_BT_Synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ext_js_section_dtl') and constid = object_id('ep_ext_js_section_dtl_PK'))
begin
	alter table ep_ext_js_section_dtl add constraint ep_ext_js_section_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_flowbr_mst') and constid = object_id('ep_flowbr_mst_pkey'))
begin
	alter table ep_flowbr_mst add constraint ep_flowbr_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_flowbr_mst_lng_extn') and constid = object_id('ep_flowbr_mst_lng_extn_pkey'))
begin
	alter table ep_flowbr_mst_lng_extn add constraint ep_flowbr_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_glossary_mst') and constid = object_id('ep_glossary_mst_pkey'))
begin
	alter table ep_glossary_mst add constraint ep_glossary_mst_pkey primary key clustered (customer_name, project_name, req_no, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_glossary_mst_lng_extn') and constid = object_id('ep_glossary_mst_lng_extn_pkey'))
begin
	alter table ep_glossary_mst_lng_extn add constraint ep_glossary_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_language_met') and constid = object_id('ep_language_met_pkey'))
begin
	alter table ep_language_met add constraint ep_language_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_layout_ezeeview_sp') and constid = object_id('ep_layout_ezeeview_sp_PK'))
begin
	alter table ep_layout_ezeeview_sp add constraint ep_layout_ezeeview_sp_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_layout_ezeeview_spparamlist') and constid = object_id('ep_layout_ezeeview_spparamlist_pk'))
begin
	alter table ep_layout_ezeeview_spparamlist add constraint ep_layout_ezeeview_spparamlist_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_listedit_column_dtl') and constid = object_id('ep_listedit_column_dtl_PKey'))
begin
	alter table ep_listedit_column_dtl add constraint ep_listedit_column_dtl_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_listedit_control_map') and constid = object_id('ep_listedit_control_map_PKey'))
begin
	alter table ep_listedit_control_map add constraint ep_listedit_control_map_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_nativeapp_mapping') and constid = object_id('ep_nativeapp_mapping_PK'))
begin
	alter table ep_nativeapp_mapping add constraint ep_nativeapp_mapping_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_new_ui_mst') and constid = object_id('ep_new_ui_mst_pkey'))
begin
	alter table ep_new_ui_mst add constraint ep_new_ui_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_column_group_mapping') and constid = object_id('ep_phone_column_group_mapping_pkey'))
begin
	alter table ep_phone_column_group_mapping add constraint ep_phone_column_group_mapping_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_columngroup') and constid = object_id('ep_phone_columngroup_pkey'))
begin
	alter table ep_phone_columngroup add constraint ep_phone_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_control_dtl') and constid = object_id('ep_phone_control_dtl_pkey'))
begin
	alter table ep_phone_control_dtl add constraint ep_phone_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_grid_columngroup') and constid = object_id('ep_phone_grid_columngroup_pkey'))
begin
	alter table ep_phone_grid_columngroup add constraint ep_phone_grid_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_grid_dtl') and constid = object_id('ep_phone_grid_dtl_pkey'))
begin
	alter table ep_phone_grid_dtl add constraint ep_phone_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_mst') and constid = object_id('ep_phone_mst_pkey'))
begin
	alter table ep_phone_mst add constraint ep_phone_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_page_dtl') and constid = object_id('ep_phone_page_dtl_pkey'))
begin
	alter table ep_phone_page_dtl add constraint ep_phone_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_phone_section_dtl') and constid = object_id('ep_phone_section_dtl_pkey'))
begin
	alter table ep_phone_section_dtl add constraint ep_phone_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_pivot_configure') and constid = object_id('ep_pivot_configure_pkey'))
begin
	alter table ep_pivot_configure add constraint ep_pivot_configure_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_pivot_fields') and constid = object_id('ep_pivot_fields_pkey'))
begin
	alter table ep_pivot_fields add constraint ep_pivot_fields_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_pivot_lang_extn') and constid = object_id('ep_pivot_lang_extn_pkey'))
begin
	alter table ep_pivot_lang_extn add constraint ep_pivot_lang_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, DisplayField, Languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_quick_code_mst') and constid = object_id('ep_quick_code_mst_pkey'))
begin
	alter table ep_quick_code_mst add constraint ep_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_quick_code_mst_lng_extn') and constid = object_id('ep_quick_code_mst_lng_extn_pkey'))
begin
	alter table ep_quick_code_mst_lng_extn add constraint ep_quick_code_mst_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_radio_button_dtl') and constid = object_id('ep_radio_button_dtl_pkey'))
begin
	alter table ep_radio_button_dtl add constraint ep_radio_button_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_radio_button_dtl_lng_extn') and constid = object_id('ep_radio_button_dtl_lng_extn_pkey'))
begin
	alter table ep_radio_button_dtl_lng_extn add constraint ep_radio_button_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_resolvelist_data_map') and constid = object_id('ep_resolvelist_data_map_PKey'))
begin
	alter table ep_resolvelist_data_map add constraint ep_resolvelist_data_map_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_review') and constid = object_id('ep_review_pkey'))
begin
	alter table ep_review add constraint ep_review_pkey primary key clustered (customer_name, project_name, reviewset_no, workrequest_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_review_dtl') and constid = object_id('ep_review_dtl_pkey'))
begin
	alter table ep_review_dtl add constraint ep_review_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_review_type') and constid = object_id('ep_review_type_pkey'))
begin
	alter table ep_review_type add constraint ep_review_type_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_sync_view') and constid = object_id('ep_sync_view_pkey'))
begin
	alter table ep_sync_view add constraint ep_sync_view_pkey primary key clustered (Customer_name, Project_name, process_name, component_name, activity_name, ui_name, legrid_control_id, legrid_view_name, map_le_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_column_group_mapping') and constid = object_id('ep_tablet_column_group_mapping_pkey'))
begin
	alter table ep_tablet_column_group_mapping add constraint ep_tablet_column_group_mapping_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_columngroup') and constid = object_id('ep_tablet_columngroup_pkey'))
begin
	alter table ep_tablet_columngroup add constraint ep_tablet_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_control_dtl') and constid = object_id('ep_tablet_control_dtl_pkey'))
begin
	alter table ep_tablet_control_dtl add constraint ep_tablet_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_grid_columngroup') and constid = object_id('ep_tablet_grid_columngroup_pkey'))
begin
	alter table ep_tablet_grid_columngroup add constraint ep_tablet_grid_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_grid_dtl') and constid = object_id('ep_tablet_grid_dtl_pkey'))
begin
	alter table ep_tablet_grid_dtl add constraint ep_tablet_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_mst') and constid = object_id('ep_tablet_mst_pkey'))
begin
	alter table ep_tablet_mst add constraint ep_tablet_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_page_dtl') and constid = object_id('ep_tablet_page_dtl_pkey'))
begin
	alter table ep_tablet_page_dtl add constraint ep_tablet_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tablet_section_dtl') and constid = object_id('ep_tablet_section_dtl_pkey'))
begin
	alter table ep_tablet_section_dtl add constraint ep_tablet_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_Templates') and constid = object_id('ep_Templates_pk'))
begin
	alter table ep_Templates add constraint ep_Templates_pk primary key clustered (customer_name, project_name, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tree_dtl') and constid = object_id('ep_tree_dtl_pkey'))
begin
	alter table ep_tree_dtl add constraint ep_tree_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tree_sample_data') and constid = object_id('ep_tree_sample_data_pkey'))
begin
	alter table ep_tree_sample_data add constraint ep_tree_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, Node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tree_sample_Data_bkupuiocx') and constid = object_id('ep_tree_sample_data_bkupuiocx_pkey'))
begin
	alter table ep_tree_sample_Data_bkupuiocx add constraint ep_tree_sample_data_bkupuiocx_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, Node_id, deleteddate)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tree_sample_data_map') and constid = object_id('ep_tree_sample_data_map_pkey'))
begin
	alter table ep_tree_sample_data_map add constraint ep_tree_sample_data_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_tree_sample_Data_map_bkupuiocx') and constid = object_id('ep_tree_sample_data_map_bkupuiocx_pkey'))
begin
	alter table ep_tree_sample_Data_map_bkupuiocx add constraint ep_tree_sample_data_map_bkupuiocx_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id, deleteddate)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_column_group_mapping') and constid = object_id('ep_ui_column_group_mapping_pkey'))
begin
	alter table ep_ui_column_group_mapping add constraint ep_ui_column_group_mapping_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_columngroup') and constid = object_id('ep_ui_columngroup_pkey'))
begin
	alter table ep_ui_columngroup add constraint ep_ui_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_combolink_dtl') and constid = object_id('ep_ui_combolink_dtl_pkey'))
begin
	alter table ep_ui_combolink_dtl add constraint ep_ui_combolink_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_contextmenu_task_dtl') and constid = object_id('ep_ui_contextmenu_task_dtl_pk'))
begin
	alter table ep_ui_contextmenu_task_dtl add constraint ep_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_control_del_dtl') and constid = object_id('ep_ui_control_del_dtl_pk'))
begin
	alter table ep_ui_control_del_dtl add constraint ep_ui_control_del_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, section_bt_synonym, control_bt_synonym, control_type, req_no, guid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_control_dtl') and constid = object_id('ep_ui_control_dtl_pkey'))
begin
	alter table ep_ui_control_dtl add constraint ep_ui_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_control_dtl_lng_extn') and constid = object_id('ep_ui_control_dtl_lng_extn_pkey'))
begin
	alter table ep_ui_control_dtl_lng_extn add constraint ep_ui_control_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Ep_ui_control_properties') and constid = object_id('Ep_ui_control_properties_pkey'))
begin
	alter table Ep_ui_control_properties add constraint Ep_ui_control_properties_pkey primary key clustered (customername, projectname, req_no, processname, componentname, ilbocode, controlid, viewname, propertyname)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_device_control_dtl') and constid = object_id('ep_ui_device_control_dtl_pkey'))
begin
	alter table ep_ui_device_control_dtl add constraint ep_ui_device_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_device_dtl') and constid = object_id('ep_ui_device_dtl_pkey'))
begin
	alter table ep_ui_device_dtl add constraint ep_ui_device_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_device_grid_dtl') and constid = object_id('ep_ui_device_grid_dtl_pkey'))
begin
	alter table ep_ui_device_grid_dtl add constraint ep_ui_device_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_device_page_dtl') and constid = object_id('ep_ui_device_page_dtl_pkey'))
begin
	alter table ep_ui_device_page_dtl add constraint ep_ui_device_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_device_section_dtl') and constid = object_id('ep_ui_device_section_dtl_pkey'))
begin
	alter table ep_ui_device_section_dtl add constraint ep_ui_device_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_displaytext_lang_extn') and constid = object_id('ep_ui_displaytext_lang_extn_PKey'))
begin
	alter table ep_ui_displaytext_lang_extn add constraint ep_ui_displaytext_lang_extn_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_task_name, lang_id, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_grid_columngroup') and constid = object_id('ep_ui_grid_columngroup_pkey'))
begin
	alter table ep_ui_grid_columngroup add constraint ep_ui_grid_columngroup_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_grid_dtl') and constid = object_id('ep_ui_grid_dtl_pkey'))
begin
	alter table ep_ui_grid_dtl add constraint ep_ui_grid_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_grid_dtl_lng_extn') and constid = object_id('ep_ui_grid_dtl_lng_extn_pkey'))
begin
	alter table ep_ui_grid_dtl_lng_extn add constraint ep_ui_grid_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_mst') and constid = object_id('ep_ui_mst_pkey'))
begin
	alter table ep_ui_mst add constraint ep_ui_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_mst_lng_extn') and constid = object_id('ep_ui_mst_lng_extn_pkey'))
begin
	alter table ep_ui_mst_lng_extn add constraint ep_ui_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_page_dtl') and constid = object_id('ep_ui_page_dtl_pkey'))
begin
	alter table ep_ui_page_dtl add constraint ep_ui_page_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_page_dtl_lng_extn') and constid = object_id('ep_ui_page_dtl_lng_extn_pkey'))
begin
	alter table ep_ui_page_dtl_lng_extn add constraint ep_ui_page_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_pageevents_dtl') and constid = object_id('ep_ui_pageevents_dtl_pk'))
begin
	alter table ep_ui_pageevents_dtl add constraint ep_ui_pageevents_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_placeholder_dtl_lng_extn') and constid = object_id('ep_ui_placeholder_dtl_lng_extn_pk'))
begin
	alter table ep_ui_placeholder_dtl_lng_extn add constraint ep_ui_placeholder_dtl_lng_extn_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_req_dtl') and constid = object_id('ep_ui_req_dtl_pkey'))
begin
	alter table ep_ui_req_dtl add constraint ep_ui_req_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_req_dtl_lng_extn') and constid = object_id('ep_ui_req_dtl_lng_extn_pkey'))
begin
	alter table ep_ui_req_dtl_lng_extn add constraint ep_ui_req_dtl_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_section_control_map_dtl') and constid = object_id('ep_ui_section_control_map_dtl_pkey'))
begin
	alter table ep_ui_section_control_map_dtl add constraint ep_ui_section_control_map_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_section_dtl') and constid = object_id('ep_ui_section_dtl_pkey'))
begin
	alter table ep_ui_section_dtl add constraint ep_ui_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_column_dtl') and constid = object_id('ep_ui_state_column_dtl_PK'))
begin
	alter table ep_ui_state_column_dtl add constraint ep_ui_state_column_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym, column_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_control_dtl') and constid = object_id('ep_ui_state_control_dtl_pkey'))
begin
	alter table ep_ui_state_control_dtl add constraint ep_ui_state_control_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_dtl') and constid = object_id('ep_ui_state_dtl_pkey'))
begin
	alter table ep_ui_state_dtl add constraint ep_ui_state_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_page_dtl') and constid = object_id('ep_ui_state_page_dtl_PK'))
begin
	alter table ep_ui_state_page_dtl add constraint ep_ui_state_page_dtl_PK primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, state_id, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_section_dtl') and constid = object_id('ep_ui_state_section_dtl_pkey'))
begin
	alter table ep_ui_state_section_dtl add constraint ep_ui_state_section_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_task_dtl') and constid = object_id('ep_ui_state_task_dtl_pkey'))
begin
	alter table ep_ui_state_task_dtl add constraint ep_ui_state_task_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_state_task_mst') and constid = object_id('ep_ui_state_task_mst_pkey'))
begin
	alter table ep_ui_state_task_mst add constraint ep_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_Temp_placeholders') and constid = object_id('ep_ui_Temp_placeholders_pk'))
begin
	alter table ep_ui_Temp_placeholders add constraint ep_ui_Temp_placeholders_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid, placeholder)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_template_controlmap') and constid = object_id('ep_ui_template_controlmap_pk'))
begin
	alter table ep_ui_template_controlmap add constraint ep_ui_template_controlmap_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_toolbar_dtl') and constid = object_id('ep_ui_toolbar_dtl_PKey'))
begin
	alter table ep_ui_toolbar_dtl add constraint ep_ui_toolbar_dtl_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_toolbar_group_dtl') and constid = object_id('ep_ui_toolbar_group_dtl_PKey'))
begin
	alter table ep_ui_toolbar_group_dtl add constraint ep_ui_toolbar_group_dtl_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_toolbar_mapping_dtl') and constid = object_id('ep_ui_toolbar_mapping_dtl_PKey'))
begin
	alter table ep_ui_toolbar_mapping_dtl add constraint ep_ui_toolbar_mapping_dtl_PKey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_tooltip_dtl_lng_extn') and constid = object_id('ep_ui_tooltip_dtl_lng_extn_pk'))
begin
	alter table ep_ui_tooltip_dtl_lng_extn add constraint ep_ui_tooltip_dtl_lng_extn_pk primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_ui_traversal_dtl') and constid = object_id('ep_ui_traversal_dtl_pkey'))
begin
	alter table ep_ui_traversal_dtl add constraint ep_ui_traversal_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('ep_user_section_dtl') and constid = object_id('ep_user_section_dtl_pkey'))
begin
	alter table ep_user_section_dtl add constraint ep_user_section_dtl_pkey primary key clustered (customer_name, project_name, reqno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_business_term') and constid = object_id('es_business_term_pkey'))
begin
	alter table es_business_term add constraint es_business_term_pkey primary key clustered (customer_name, project_name, bt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_business_term_lng_extn') and constid = object_id('es_business_term_lng_extn_pkey'))
begin
	alter table es_business_term_lng_extn add constraint es_business_term_lng_extn_pkey primary key clustered (customer_name, project_name, bt_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_CodeGen_Used') and constid = object_id('es_CodeGen_Used_PK'))
begin
	alter table es_CodeGen_Used add constraint es_CodeGen_Used_PK primary key clustered (Customer_Name, Project_Name, Feature_List)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_ctrl_type_mst') and constid = object_id('es_comp_ctrl_type_mst_pkey'))
begin
	alter table es_comp_ctrl_type_mst add constraint es_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_ctrl_type_mst_extn') and constid = object_id('es_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table es_comp_ctrl_type_mst_extn add constraint es_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_ctrl_type_mst_lng_extn') and constid = object_id('es_comp_ctrl_type_mst_lng_extn_pkey'))
begin
	alter table es_comp_ctrl_type_mst_lng_extn add constraint es_comp_ctrl_type_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_hdn_ctrl_dtl') and constid = object_id('es_comp_hdn_ctrl_dtl_pkey'))
begin
	alter table es_comp_hdn_ctrl_dtl add constraint es_comp_hdn_ctrl_dtl_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_param_mst') and constid = object_id('es_comp_param_mst_pkey'))
begin
	alter table es_comp_param_mst add constraint es_comp_param_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, param_category)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_param_mst_lng_extn') and constid = object_id('es_comp_param_mst_lng_extn_pkey'))
begin
	alter table es_comp_param_mst_lng_extn add constraint es_comp_param_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, param_category, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_stat_ctrl_type_mst') and constid = object_id('es_comp_stat_ctrl_type_mst_pkey'))
begin
	alter table es_comp_stat_ctrl_type_mst add constraint es_comp_stat_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_stylesheet') and constid = object_id('es_comp_stylesheet_pkey'))
begin
	alter table es_comp_stylesheet add constraint es_comp_stylesheet_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, stylesheet_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_task_type_mst') and constid = object_id('es_comp_task_type_mst_pkey'))
begin
	alter table es_comp_task_type_mst add constraint es_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, task_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_comp_task_type_mst_lng_extn') and constid = object_id('es_comp_task_type_mst_lng_extn_pkey'))
begin
	alter table es_comp_task_type_mst_lng_extn add constraint es_comp_task_type_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, task_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_events_met') and constid = object_id('es_ctrl_type_events_met_pkey'))
begin
	alter table es_ctrl_type_events_met add constraint es_ctrl_type_events_met_pkey primary key clustered (base_ctrl_type, events_desc)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_events_mst') and constid = object_id('es_ctrl_type_events_mst_pkey'))
begin
	alter table es_ctrl_type_events_mst add constraint es_ctrl_type_events_mst_pkey primary key clustered (customer_name, project_name, req_no, process_name, component_name, ctrl_type_name, events_desc)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_met') and constid = object_id('es_ctrl_type_met_pkey'))
begin
	alter table es_ctrl_type_met add constraint es_ctrl_type_met_pkey primary key clustered (ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_met_lng_extn') and constid = object_id('es_ctrl_type_met_lng_extn_pkey'))
begin
	alter table es_ctrl_type_met_lng_extn add constraint es_ctrl_type_met_lng_extn_pkey primary key clustered (ctrl_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_mst') and constid = object_id('es_ctrl_type_mst_pkey'))
begin
	alter table es_ctrl_type_mst add constraint es_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, req_no, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_mst_extn') and constid = object_id('es_ctrl_type_mst_extn_pkey'))
begin
	alter table es_ctrl_type_mst_extn add constraint es_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, req_no, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ctrl_type_mst_lng_extn') and constid = object_id('es_ctrl_type_mst_lng_extn_pkey'))
begin
	alter table es_ctrl_type_mst_lng_extn add constraint es_ctrl_type_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, ctrl_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_Feature_Available') and constid = object_id('es_Feature_Available_PK'))
begin
	alter table es_Feature_Available add constraint es_Feature_Available_PK primary key clustered (Feature_List)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_language_met') and constid = object_id('es_language_met_pkey'))
begin
	alter table es_language_met add constraint es_language_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_param_met') and constid = object_id('es_param_met_pkey'))
begin
	alter table es_param_met add constraint es_param_met_pkey primary key clustered (param_category)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_param_met_lng_extn') and constid = object_id('es_param_met_lng_extn_pkey'))
begin
	alter table es_param_met_lng_extn add constraint es_param_met_lng_extn_pkey primary key clustered (param_category, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_proj_hdn_ctrl_dtl') and constid = object_id('es_proj_hdn_ctrl_dtl_pkey'))
begin
	alter table es_proj_hdn_ctrl_dtl add constraint es_proj_hdn_ctrl_dtl_pkey primary key clustered (customer_name, project_name, req_no, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_project_param_mst') and constid = object_id('es_project_param_mst_pkey'))
begin
	alter table es_project_param_mst add constraint es_project_param_mst_pkey primary key clustered (customer_name, project_name, req_no, param_category)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_project_param_mst_lng_extn') and constid = object_id('es_project_param_mst_lng_extn_pkey'))
begin
	alter table es_project_param_mst_lng_extn add constraint es_project_param_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, param_category, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_project_stylesheet') and constid = object_id('es_project_stylesheet_pkey'))
begin
	alter table es_project_stylesheet add constraint es_project_stylesheet_pkey primary key clustered (customer_name, project_name, req_no, stylesheet_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_pt_mst') and constid = object_id('es_pt_mst_pkey'))
begin
	alter table es_pt_mst add constraint es_pt_mst_pkey primary key clustered (customer_name, project_name, pt_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_quick_code_mst') and constid = object_id('es_quick_code_mst_pkey'))
begin
	alter table es_quick_code_mst add constraint es_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_review') and constid = object_id('es_review_pkey'))
begin
	alter table es_review add constraint es_review_pkey primary key clustered (customer_name, project_name, reviewset_no, reviewpoint)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_review_dtl') and constid = object_id('es_review_dtl_pkey'))
begin
	alter table es_review_dtl add constraint es_review_dtl_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type, deliverable_type, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_review_type') and constid = object_id('es_review_type_pkey'))
begin
	alter table es_review_type add constraint es_review_type_pkey primary key clustered (customer_name, project_name, reviewset_no, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_task_type_met') and constid = object_id('es_task_type_met_pkey'))
begin
	alter table es_task_type_met add constraint es_task_type_met_pkey primary key clustered (task_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_task_type_met_lng_extn') and constid = object_id('es_task_type_met_lng_extn_pkey'))
begin
	alter table es_task_type_met_lng_extn add constraint es_task_type_met_lng_extn_pkey primary key clustered (task_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_task_type_mst') and constid = object_id('es_task_type_mst_pkey'))
begin
	alter table es_task_type_mst add constraint es_task_type_mst_pkey primary key clustered (customer_name, project_name, req_no, task_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_task_type_mst_lng_extn') and constid = object_id('es_task_type_mst_lng_extn_pkey'))
begin
	alter table es_task_type_mst_lng_extn add constraint es_task_type_mst_lng_extn_pkey primary key clustered (customer_name, project_name, req_no, task_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_template_mst') and constid = object_id('es_template_mst_pkey'))
begin
	alter table es_template_mst add constraint es_template_mst_pkey primary key clustered (customer_name, project_name, TemplateID)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ui_Reference_dtl') and constid = object_id('es_ui_Reference_dtl_pkey'))
begin
	alter table es_ui_Reference_dtl add constraint es_ui_Reference_dtl_pkey primary key clustered (customer_name, project_name, Ref_component_name, Ref_activity_name, Ref_ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('es_ui_Reference_usage_dtl') and constid = object_id('es_ui_Reference_usage_dtl_pkey'))
begin
	alter table es_ui_Reference_usage_dtl add constraint es_ui_Reference_usage_dtl_pkey primary key clustered (customer_name, project_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_activity') and constid = object_id('est_activity_pkey'))
begin
	alter table est_activity add constraint est_activity_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_activity_band') and constid = object_id('est_activity_band_pkey'))
begin
	alter table est_activity_band add constraint est_activity_band_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name, activity_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_activity_met') and constid = object_id('est_activity_met_pkey'))
begin
	alter table est_activity_met add constraint est_activity_met_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_band') and constid = object_id('est_band_pkey'))
begin
	alter table est_band add constraint est_band_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, band_type, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_band_matrix') and constid = object_id('PK_est_band_matrix'))
begin
	alter table est_band_matrix add constraint PK_est_band_matrix primary key clustered (band_type, min_RET, max_RET, min_DET, max_DET, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_band_met') and constid = object_id('est_band_met_pkey'))
begin
	alter table est_band_met add constraint est_band_met_pkey primary key clustered (band_type, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_bo') and constid = object_id('est_bo_pkey'))
begin
	alter table est_bo add constraint est_bo_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_bo_met') and constid = object_id('est_bo_met_pkey'))
begin
	alter table est_bo_met add constraint est_bo_met_pkey primary key clustered (customer_name, project_name, process_name, component_name, bo_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_component') and constid = object_id('est_component_pkey'))
begin
	alter table est_component add constraint est_component_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_component_band') and constid = object_id('est_component_band_pkey'))
begin
	alter table est_component_band add constraint est_component_band_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_component_met') and constid = object_id('est_component_met_pkey'))
begin
	alter table est_component_met add constraint est_component_met_pkey primary key clustered (customer_name, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_dfp_count_dtl') and constid = object_id('est_dfp_count_dtl_pk'))
begin
	alter table est_dfp_count_dtl add constraint est_dfp_count_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, dfp_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_eif_count_dtl') and constid = object_id('PK_est_eif_count_dtl'))
begin
	alter table est_eif_count_dtl add constraint PK_est_eif_count_dtl primary key clustered (customer_name, project_name, process_name, component_name, EIF_name, ret_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_eif_object_dtl') and constid = object_id('PK_est_eif_object_dtl'))
begin
	alter table est_eif_object_dtl add constraint PK_est_eif_object_dtl primary key clustered (customer_name, project_name, process_name, guid, from_component, from_object, from_object_type, to_compnent, to_object, to_object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_estimate') and constid = object_id('est_estimate_pkey'))
begin
	alter table est_estimate add constraint est_estimate_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_fpcal_act_dtl') and constid = object_id('PK_est_fpcal_act_dtl'))
begin
	alter table est_fpcal_act_dtl add constraint PK_est_fpcal_act_dtl primary key clustered (customer_name, project_name, process_name, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_fpcal_comp_dtl') and constid = object_id('PK_est_fpcal_comp_dtl'))
begin
	alter table est_fpcal_comp_dtl add constraint PK_est_fpcal_comp_dtl primary key clustered (customer_name, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_act_band') and constid = object_id('PK_est_group_act_band'))
begin
	alter table est_group_act_band add constraint PK_est_group_act_band primary key clustered (customer_name, project_name, group_name, process_name, component_name, activity_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_comp_band') and constid = object_id('PK_est_group_comp_band'))
begin
	alter table est_group_comp_band add constraint PK_est_group_comp_band primary key clustered (customer_name, project_name, group_name, process_name, component_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_comp_dtl') and constid = object_id('est_group_comp_dtl_pk'))
begin
	alter table est_group_comp_dtl add constraint est_group_comp_dtl_pk primary key clustered (customer_name, project_name, component_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_det_dtl') and constid = object_id('est_group_det_dtl_PK'))
begin
	alter table est_group_det_dtl add constraint est_group_det_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, function_name, RET_object, DET_object, function_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_dtl') and constid = object_id('est_group_dtl_pk'))
begin
	alter table est_group_dtl add constraint est_group_dtl_pk primary key clustered (customer_name, project_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_eif_dtl') and constid = object_id('PK_est_group_eif_dtl'))
begin
	alter table est_group_eif_dtl add constraint PK_est_group_eif_dtl primary key clustered (customer_name, project_name, group_name, process_name, component_name, eif_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_comp_dtl') and constid = object_id('est_group_enh_comp_dtl_PK'))
begin
	alter table est_group_enh_comp_dtl add constraint est_group_enh_comp_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_det_dtl') and constid = object_id('est_group_enh_det_dtl_PK'))
begin
	alter table est_group_enh_det_dtl add constraint est_group_enh_det_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, function_type, function_name, RET_object, DET_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_dfp_dtl') and constid = object_id('est_group_enh_dfp_dtl_PK'))
begin
	alter table est_group_enh_dfp_dtl add constraint est_group_enh_dfp_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, DFP_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_dtl') and constid = object_id('est_group_enh_dtl_PK'))
begin
	alter table est_group_enh_dtl add constraint est_group_enh_dtl_PK primary key clustered (customer_name, project_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_eif_dtl') and constid = object_id('est_group_enh_eif_dtl_PK'))
begin
	alter table est_group_enh_eif_dtl add constraint est_group_enh_eif_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, EIF_name, RET_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_ilf_dtl') and constid = object_id('est_group_enh_ilf_dtl_PK'))
begin
	alter table est_group_enh_ilf_dtl add constraint est_group_enh_ilf_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, ILF_name, RET_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_refine') and constid = object_id('est_group_enh_refine_PK'))
begin
	alter table est_group_enh_refine add constraint est_group_enh_refine_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, function_type, function_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_tfp_dtl') and constid = object_id('est_group_enh_tfp_dtl_PK'))
begin
	alter table est_group_enh_tfp_dtl add constraint est_group_enh_tfp_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, activity_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_enh_tfp_ftr_dtl') and constid = object_id('est_group_enh_tfp_ftr_dtl_PK'))
begin
	alter table est_group_enh_tfp_ftr_dtl add constraint est_group_enh_tfp_ftr_dtl_PK primary key clustered (customer_name, project_name, group_name, process_name, component_name, activity_name, Service_name, FTR_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_refined_tfp') and constid = object_id('est_group_refined_tfp_pkey'))
begin
	alter table est_group_refined_tfp add constraint est_group_refined_tfp_pkey primary key clustered (customer_name, project_name, group_name, process_name, component_name, activity_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_group_refined_tfp_dtl') and constid = object_id('est_group_refined_tfp_dtl_pkey'))
begin
	alter table est_group_refined_tfp_dtl add constraint est_group_refined_tfp_dtl_pkey primary key clustered (customer_name, project_name, group_name, process_name, component_name, activity_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_ilf_object_dtl') and constid = object_id('PK_est_ilf_object_dtl'))
begin
	alter table est_ilf_object_dtl add constraint PK_est_ilf_object_dtl primary key clustered (customer_name, project_name, process_name, component_name, object_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_ilf_object_ref') and constid = object_id('PK_est_ilf_object_ref'))
begin
	alter table est_ilf_object_ref add constraint PK_est_ilf_object_ref primary key clustered (customer_name, project_name, process_name, component_name, ilf_name, ret_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_ilf_table_remove') and constid = object_id('est_ilf_table_remove_PK'))
begin
	alter table est_ilf_table_remove add constraint est_ilf_table_remove_PK primary key clustered (customer_name, project_name, process_name, component_name, table_name, parent_table_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_act_band') and constid = object_id('PK_est_postprw_act_band'))
begin
	alter table est_postprw_act_band add constraint PK_est_postprw_act_band primary key clustered (customer_name, project_name, release_no, process_name, component_name, activity_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_actres_dtl') and constid = object_id('PK_est_postprw_actres_dtl'))
begin
	alter table est_postprw_actres_dtl add constraint PK_est_postprw_actres_dtl primary key clustered (customer_name, project_name, release_no, process_name, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_comp_band') and constid = object_id('PK_est_postprw_comp_band'))
begin
	alter table est_postprw_comp_band add constraint PK_est_postprw_comp_band primary key clustered (customer_name, project_name, release_no, process_name, component_name, band_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_compres_dtl') and constid = object_id('PK_est_postprw_compres_dtl'))
begin
	alter table est_postprw_compres_dtl add constraint PK_est_postprw_compres_dtl primary key clustered (customer_name, project_name, release_no, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_eif_obj_dtl') and constid = object_id('PK_est_postprw_eif_obj_dtl'))
begin
	alter table est_postprw_eif_obj_dtl add constraint PK_est_postprw_eif_obj_dtl primary key clustered (customer_name, project_name, release_no, process_name, component_name, eif_name, eif_component, eif_ret_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_ilf_obj_dtl') and constid = object_id('PK_est_postprw_ilf_obj_dtl'))
begin
	alter table est_postprw_ilf_obj_dtl add constraint PK_est_postprw_ilf_obj_dtl primary key clustered (customer_name, project_name, release_no, process_name, component_name, ilf_name, ilf_ret_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_postprw_ui_map') and constid = object_id('PK_est_postprw_ui_map'))
begin
	alter table est_postprw_ui_map add constraint PK_est_postprw_ui_map primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_quick_code_mst') and constid = object_id('est_quick_code_mst_pkey'))
begin
	alter table est_quick_code_mst add constraint est_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_task') and constid = object_id('est_task_pkey'))
begin
	alter table est_task add constraint est_task_pkey primary key clustered (customer_name, project_name, release_no, doc_type, doc_no, version_no, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_task_met') and constid = object_id('est_task_met_pkey'))
begin
	alter table est_task_met add constraint est_task_met_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_tfp_count_dtl') and constid = object_id('PK_est_tfp_count_dtl'))
begin
	alter table est_tfp_count_dtl add constraint PK_est_tfp_count_dtl primary key clustered (customer_name, project_name, process_name, component_name, service_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_tfp_ftr_dtl') and constid = object_id('est_tfp_ftr_dtl_pk'))
begin
	alter table est_tfp_ftr_dtl add constraint est_tfp_ftr_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, service_name, FTR_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_tfp_object_dtl') and constid = object_id('PK_est_tfp_object_dtl'))
begin
	alter table est_tfp_object_dtl add constraint PK_est_tfp_object_dtl primary key clustered (customer_name, project_name, process_name, from_component, task_name, servicename, from_object, to_object)
end

if not exists (select 'x' from sysconstraints where id = object_id('est_version_ui_doc_ref') and constid = object_id('est_version_ui_doc_ref_PK'))
begin
	alter table est_version_ui_doc_ref add constraint est_version_ui_doc_ref_PK primary key clustered (customer_name, project_name, group_name, version_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('EzeeView_PortalList') and constid = object_id('PK_EzeeView_PortalList'))
begin
	alter table EzeeView_PortalList add constraint PK_EzeeView_PortalList primary key clustered (OU, Role, user_name, Language, portal_name, portlet_name, report_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('EzeeView_PortalList_Details') and constid = object_id('PK_EzeeView_Portallist_Details'))
begin
	alter table EzeeView_PortalList_Details add constraint PK_EzeeView_Portallist_Details primary key clustered (OU, Role, user_name, Language, portal_name, portlet_name, report_name, Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('EzeeView_PortalTabItems_Detail') and constid = object_id('PK_EzeeView_PortalTabitems_detail'))
begin
	alter table EzeeView_PortalTabItems_Detail add constraint PK_EzeeView_PortalTabitems_detail primary key clustered (OU, Role, user_name, Language, portal_name, report_name, Tab_Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_alias') and constid = object_id('ezq_alias_PK'))
begin
	alter table ezq_alias add constraint ezq_alias_PK primary key clustered (aliasname)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_alias_dtl') and constid = object_id('ezq_alias_dtl_PK'))
begin
	alter table ezq_alias_dtl add constraint ezq_alias_dtl_PK primary key clustered (aliasname, DataItemName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_alias_OU_Privileges') and constid = object_id('ezq_alias_OU_Privileges_PK'))
begin
	alter table ezq_alias_OU_Privileges add constraint ezq_alias_OU_Privileges_PK primary key clustered (aliasName, OUID)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_alias_Privileges') and constid = object_id('ezq_alias_Privileges_PK'))
begin
	alter table ezq_alias_Privileges add constraint ezq_alias_Privileges_PK primary key clustered (AliasName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_alias_Role_Privileges') and constid = object_id('ezq_alias_Role_Privileges_PK'))
begin
	alter table ezq_alias_Role_Privileges add constraint ezq_alias_Role_Privileges_PK primary key clustered (aliasName, RoleName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Items') and constid = object_id('ezq_Document_Items_PK'))
begin
	alter table ezq_Document_Items add constraint ezq_Document_Items_PK primary key clustered (DocumentName, DataItemName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Lists') and constid = object_id('ezq_Document_Lists_PK'))
begin
	alter table ezq_Document_Lists add constraint ezq_Document_Lists_PK primary key clustered (DocumentName, DataItemName, ListName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_OU_Privileges') and constid = object_id('ezq_Document_OU_Privileges_PK'))
begin
	alter table ezq_Document_OU_Privileges add constraint ezq_Document_OU_Privileges_PK primary key clustered (DocumentName, OUID)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Privileges') and constid = object_id('ezq_Document_Privileges_PK'))
begin
	alter table ezq_Document_Privileges add constraint ezq_Document_Privileges_PK primary key clustered (DocumentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Relation_Items') and constid = object_id('ezq_Document_Relation_Items_PK'))
begin
	alter table ezq_Document_Relation_Items add constraint ezq_Document_Relation_Items_PK primary key clustered (RelationName, ParentDocument, ChildDocument, ParentItem, ChildItem)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Relations') and constid = object_id('ezq_Document_Relations_PK'))
begin
	alter table ezq_Document_Relations add constraint ezq_Document_Relations_PK primary key clustered (RelationName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Document_Role_Privileges') and constid = object_id('ezq_Document_Role_Privileges_PK'))
begin
	alter table ezq_Document_Role_Privileges add constraint ezq_Document_Role_Privileges_PK primary key clustered (DocumentName, RoleName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Documents') and constid = object_id('ezq_Documents_PK'))
begin
	alter table ezq_Documents add constraint ezq_Documents_PK primary key clustered (DocumentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_ListItems') and constid = object_id('ezq_ListItems_PK'))
begin
	alter table ezq_ListItems add constraint ezq_ListItems_PK primary key clustered (ListName, ListItemName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Lists') and constid = object_id('ezq_Lists_PK'))
begin
	alter table ezq_Lists add constraint ezq_Lists_PK primary key clustered (ListName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Pick_Documents') and constid = object_id('ezq_Pick_Documents_PK'))
begin
	alter table ezq_Pick_Documents add constraint ezq_Pick_Documents_PK primary key clustered (ctxt_user, Aliasname)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Queries') and constid = object_id('ezq_Queries_PK'))
begin
	alter table ezq_Queries add constraint ezq_Queries_PK primary key clustered (ctxt_user, QueryName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_query_Items') and constid = object_id('ezq_query_Items_PK'))
begin
	alter table ezq_query_Items add constraint ezq_query_Items_PK primary key clustered (queryName, DataItemName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_Role_Privileges') and constid = object_id('ezq_Role_Privileges_PK'))
begin
	alter table ezq_Role_Privileges add constraint ezq_Role_Privileges_PK primary key clustered (RoleName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_selected_alias') and constid = object_id('ezq_selected_alias_PK'))
begin
	alter table ezq_selected_alias add constraint ezq_selected_alias_PK primary key clustered (aliasname)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_selected_ou') and constid = object_id('ezq_selected_ou_PK'))
begin
	alter table ezq_selected_ou add constraint ezq_selected_ou_PK primary key clustered (ouid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_system_queries') and constid = object_id('ezq_system_queries_PK'))
begin
	alter table ezq_system_queries add constraint ezq_system_queries_PK primary key clustered (ctxt_user, OuID, RoleName, QueryName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezq_User_Privileges') and constid = object_id('ezq_User_Privileges_PK'))
begin
	alter table ezq_User_Privileges add constraint ezq_User_Privileges_PK primary key clustered (UserName)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezwiz_metadata') and constid = object_id('ezwiz_metadata_pk'))
begin
	alter table ezwiz_metadata add constraint ezwiz_metadata_pk primary key clustered (customer_name, project_name, wizardPrefix)
end

if not exists (select 'x' from sysconstraints where id = object_id('ezwiz_Reference_Value') and constid = object_id('ezwiz_Reference_Value_pk'))
begin
	alter table ezwiz_Reference_Value add constraint ezwiz_Reference_Value_pk primary key clustered (ReferenceType, LangID, ReferenceValue)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Act_Associate_Events') and constid = object_id('Fw_Bpt_Act_Associate_Events_PK'))
begin
	alter table Fw_Bpt_Act_Associate_Events add constraint Fw_Bpt_Act_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Activity') and constid = object_id('Fw_Bpt_Activity_PK'))
begin
	alter table Fw_Bpt_Activity add constraint Fw_Bpt_Activity_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Activity_Feature') and constid = object_id('Fw_Bpt_Activity_Feature_PK'))
begin
	alter table Fw_Bpt_Activity_Feature add constraint Fw_Bpt_Activity_Feature_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, FeatureID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Activity_UI') and constid = object_id('Fw_Bpt_Actiivty_UI_PK'))
begin
	alter table Fw_Bpt_Activity_UI add constraint Fw_Bpt_Actiivty_UI_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_AssociatedBRs') and constid = object_id('Fw_Bpt_AssociatedBRs_PK'))
begin
	alter table Fw_Bpt_AssociatedBRs add constraint Fw_Bpt_AssociatedBRs_PK primary key clustered (CustomerID, ProjectID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BP') and constid = object_id('Fw_Bpt_BP_PK'))
begin
	alter table Fw_Bpt_BP add constraint Fw_Bpt_BP_PK primary key clustered (CustomerID, ProjectID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BP_Act_Associate_Events') and constid = object_id('Fw_Bpt_BP_Act_Associate_Events_PK'))
begin
	alter table Fw_Bpt_BP_Act_Associate_Events add constraint Fw_Bpt_BP_Act_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, BPEventName, ActEventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BP_Associate_Events') and constid = object_id('Fw_Bpt_BP_Associate_Events_PK'))
begin
	alter table Fw_Bpt_BP_Associate_Events add constraint Fw_Bpt_BP_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BP_Feature') and constid = object_id('Fw_Bpt_BP_Feature_PK'))
begin
	alter table Fw_Bpt_BP_Feature add constraint Fw_Bpt_BP_Feature_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, FeatureID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BP_UI_Associate_Events') and constid = object_id('Fw_Bpt_BP_UI_Associate_Events_PK'))
begin
	alter table Fw_Bpt_BP_UI_Associate_Events add constraint Fw_Bpt_BP_UI_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, BPEventName, UIEventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BR') and constid = object_id('Fw_Bpt_BR_PK'))
begin
	alter table Fw_Bpt_BR add constraint Fw_Bpt_BR_PK primary key clustered (CustomerID, ProjectID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BR_Associate_Events') and constid = object_id('Fw_Bpt_BR_Associate_Events_PK'))
begin
	alter table Fw_Bpt_BR_Associate_Events add constraint Fw_Bpt_BR_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BR_Feature') and constid = object_id('Fw_Bpt_BR_Feature_PK'))
begin
	alter table Fw_Bpt_BR_Feature add constraint Fw_Bpt_BR_Feature_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, FeatureID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_BR_History_mr_ui_level') and constid = object_id('Fw_Bpt_BR_History_mr_ui_level_pk'))
begin
	alter table Fw_Bpt_BR_History_mr_ui_level add constraint Fw_Bpt_BR_History_mr_ui_level_pk primary key clustered (CustomerID, ProjectID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Component') and constid = object_id('Fw_Bpt_Component_PK'))
begin
	alter table Fw_Bpt_Component add constraint Fw_Bpt_Component_PK primary key clustered (CustomerID, ProjectID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Customer') and constid = object_id('Fw_Bpt_Customer_PK'))
begin
	alter table Fw_Bpt_Customer add constraint Fw_Bpt_Customer_PK primary key clustered (CustomerID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Customer_Project') and constid = object_id('Fw_Bpt_Customer_Project_PK'))
begin
	alter table Fw_Bpt_Customer_Project add constraint Fw_Bpt_Customer_Project_PK primary key clustered (CustomerID, ProjectID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Default_CustProj') and constid = object_id('Fw_Bpt_Default_CustProj_PK'))
begin
	alter table Fw_Bpt_Default_CustProj add constraint Fw_Bpt_Default_CustProj_PK primary key clustered (UserID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Events') and constid = object_id('Fw_Bpt_Events_PK'))
begin
	alter table Fw_Bpt_Events add constraint Fw_Bpt_Events_PK primary key clustered (customerid, projectid, eventname, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Events_Gen') and constid = object_id('Fw_Bpt_Events_Gen_PK'))
begin
	alter table Fw_Bpt_Events_Gen add constraint Fw_Bpt_Events_Gen_PK primary key clustered (customerid, projectid, langid, EventLevel)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Feature') and constid = object_id('Fw_Bpt_Feature_PK'))
begin
	alter table Fw_Bpt_Feature add constraint Fw_Bpt_Feature_PK primary key clustered (CustomerID, ProjectID, FeatureID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Function') and constid = object_id('Fw_Bpt_Function_PK'))
begin
	alter table Fw_Bpt_Function add constraint Fw_Bpt_Function_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Function_Component') and constid = object_id('Fw_Bpt_Function_Component_PK'))
begin
	alter table Fw_Bpt_Function_Component add constraint Fw_Bpt_Function_Component_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_LinkUI_Events') and constid = object_id('Fw_Bpt_LinkUI_Events_PK'))
begin
	alter table Fw_Bpt_LinkUI_Events add constraint Fw_Bpt_LinkUI_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, PageName, LinkName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Load_Events') and constid = object_id('Fw_Bpt_Load_Events_PK'))
begin
	alter table Fw_Bpt_Load_Events add constraint Fw_Bpt_Load_Events_PK primary key clustered (CustomerID, ProjectID, LdEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Project') and constid = object_id('Fw_Bpt_Project_PK'))
begin
	alter table Fw_Bpt_Project add constraint Fw_Bpt_Project_PK primary key clustered (ProjectID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Reference_CustProj') and constid = object_id('Fw_Bpt_Reference_CustProj_PK'))
begin
	alter table Fw_Bpt_Reference_CustProj add constraint Fw_Bpt_Reference_CustProj_PK primary key clustered (CustomerID, ProjectID, ExistCustomerID, ExistProjectID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Task') and constid = object_id('Fw_Bpt_Task_PK'))
begin
	alter table Fw_Bpt_Task add constraint Fw_Bpt_Task_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, TaskID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Task_Associate_Events') and constid = object_id('Fw_Bpt_Task_Associate_Events_PK'))
begin
	alter table Fw_Bpt_Task_Associate_Events add constraint Fw_Bpt_Task_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Task_BR_AssociatedBRs') and constid = object_id('Fw_Bpt_Task_BR_AssociatedBRs_PK'))
begin
	alter table Fw_Bpt_Task_BR_AssociatedBRs add constraint Fw_Bpt_Task_BR_AssociatedBRs_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_Task_Feature') and constid = object_id('Fw_Bpt_Task_Feature_PK'))
begin
	alter table Fw_Bpt_Task_Feature add constraint Fw_Bpt_Task_Feature_PK primary key clustered (customerid, projectid, bpid, functionid, activityid, uiid, taskid, featureid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_UI') and constid = object_id('Fw_Bpt_UI_PK'))
begin
	alter table Fw_Bpt_UI add constraint Fw_Bpt_UI_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_UI_Associate_Events') and constid = object_id('Fw_Bpt_UI_Associate_Events_PK'))
begin
	alter table Fw_Bpt_UI_Associate_Events add constraint Fw_Bpt_UI_Associate_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_UI_Feature') and constid = object_id('Fw_Bpt_UI_Feature_PK'))
begin
	alter table Fw_Bpt_UI_Feature add constraint Fw_Bpt_UI_Feature_PK primary key clustered (customerid, projectid, bpid, functionid, activityid, uiid, featureid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_UI_Task') and constid = object_id('Fw_Bpt_UI_Task_PK'))
begin
	alter table Fw_Bpt_UI_Task add constraint Fw_Bpt_UI_Task_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_UI_Task_BR') and constid = object_id('Fw_Bpt_UI_Task_BR_PK'))
begin
	alter table Fw_Bpt_UI_Task_BR add constraint Fw_Bpt_UI_Task_BR_PK primary key clustered (customerid, projectid, bpid, functionid, activityid, uiid, taskid, brid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Bpt_User_CustProj') and constid = object_id('Fw_Bpt_User_CustProj_PK'))
begin
	alter table Fw_Bpt_User_CustProj add constraint Fw_Bpt_User_CustProj_PK primary key clustered (UserID, LangID, CustomerID, ProjectID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Customer_FuncReq') and constid = object_id('Fw_Cex_Customer_FuncReq_PK'))
begin
	alter table Fw_Cex_Customer_FuncReq add constraint Fw_Cex_Customer_FuncReq_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Reference_Value') and constid = object_id('Fw_Cex_Reference_Value_PK'))
begin
	alter table Fw_Cex_Reference_Value add constraint Fw_Cex_Reference_Value_PK primary key clustered (ReferenceType, LangID, ReferenceValue, ReferenceDesc)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Solutioning') and constid = object_id('Fw_Cex_Solutioning_PK'))
begin
	alter table Fw_Cex_Solutioning add constraint Fw_Cex_Solutioning_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Theme') and constid = object_id('Fw_Cex_Theme_PK'))
begin
	alter table Fw_Cex_Theme add constraint Fw_Cex_Theme_PK primary key clustered (CustomerID, ProjectID, ThemeID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Theme_Detail') and constid = object_id('Fw_Cex_Theme_Detail_PK'))
begin
	alter table Fw_Cex_Theme_Detail add constraint Fw_Cex_Theme_Detail_PK primary key clustered (CustomerID, ProjectID, ThemeID, LangID, InternalUsageID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Theme_Exposure') and constid = object_id('Fw_Cex_Theme_Exposure_PK'))
begin
	alter table Fw_Cex_Theme_Exposure add constraint Fw_Cex_Theme_Exposure_PK primary key clustered (CustomerID, ProjectID, ThemeID, LangID, ExposureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cex_Theme_Exposure_Detail') and constid = object_id('Fw_Cex_Theme_Exposure_Detail_PK'))
begin
	alter table Fw_Cex_Theme_Exposure_Detail add constraint Fw_Cex_Theme_Exposure_Detail_PK primary key clustered (CustomerID, ProjectID, ThemeID, LangID, InternalUsageID, ExposureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Activity') and constid = object_id('Fw_Cmt_Activity_PK'))
begin
	alter table Fw_Cmt_Activity add constraint Fw_Cmt_Activity_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Activity_Feature') and constid = object_id('Fw_Cmt_Activity_Feature_PK'))
begin
	alter table Fw_Cmt_Activity_Feature add constraint Fw_Cmt_Activity_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, LangID, FeatureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Activity_UI') and constid = object_id('Fw_Cmt_Activity_UI_PK'))
begin
	alter table Fw_Cmt_Activity_UI add constraint Fw_Cmt_Activity_UI_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_AssociatedBRs') and constid = object_id('Fw_Cmt_AssociatedBRs_PK'))
begin
	alter table Fw_Cmt_AssociatedBRs add constraint Fw_Cmt_AssociatedBRs_PK primary key clustered (CustomerID, ProjectID, WorkReqID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BP') and constid = object_id('Fw_Cmt_BP_PK'))
begin
	alter table Fw_Cmt_BP add constraint Fw_Cmt_BP_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BP_Act_Associate_Events') and constid = object_id('Fw_cmt_BP_Act_Associate_Events_PK'))
begin
	alter table Fw_Cmt_BP_Act_Associate_Events add constraint Fw_cmt_BP_Act_Associate_Events_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, BPEventName, ActEventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BP_Feature') and constid = object_id('Fw_Cmt_BP_Feature_PK'))
begin
	alter table Fw_Cmt_BP_Feature add constraint Fw_Cmt_BP_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, LangID, FeatureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BP_UI_Associate_Events') and constid = object_id('Fw_Cmt_BP_UI_Associate_Events_PK'))
begin
	alter table Fw_Cmt_BP_UI_Associate_Events add constraint Fw_Cmt_BP_UI_Associate_Events_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, BPEventName, UIEventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BR') and constid = object_id('Fw_Cmt_BR_PK'))
begin
	alter table Fw_Cmt_BR add constraint Fw_Cmt_BR_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_BR_Feature') and constid = object_id('Fw_Cmt_BR_Feature_PK'))
begin
	alter table Fw_Cmt_BR_Feature add constraint Fw_Cmt_BR_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, LangID, FeatureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Component') and constid = object_id('Fw_Cmt_Component_PK'))
begin
	alter table Fw_Cmt_Component add constraint Fw_Cmt_Component_PK primary key clustered (CustomerID, ProjectID, WorkReqID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Customer_FuncReq') and constid = object_id('Fw_Cmt_Customer_FuncReq_PK'))
begin
	alter table Fw_Cmt_Customer_FuncReq add constraint Fw_Cmt_Customer_FuncReq_PK primary key clustered (WorkReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Events') and constid = object_id('Fw_Cmt_Events_PK'))
begin
	alter table Fw_Cmt_Events add constraint Fw_Cmt_Events_PK primary key clustered (CustomerID, ProjectID, WorkReqID, EventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Feature') and constid = object_id('Fw_Cmt_Feature_PK'))
begin
	alter table Fw_Cmt_Feature add constraint Fw_Cmt_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, FeatureID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Function') and constid = object_id('Fw_Cmt_Function_PK'))
begin
	alter table Fw_Cmt_Function add constraint Fw_Cmt_Function_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Function_Component') and constid = object_id('Fw_Cmt_Function_Component_PK'))
begin
	alter table Fw_Cmt_Function_Component add constraint Fw_Cmt_Function_Component_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_LinkUI_Events') and constid = object_id('Fw_Cmt_LinkUI_Events_PK'))
begin
	alter table Fw_Cmt_LinkUI_Events add constraint Fw_Cmt_LinkUI_Events_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, PageName, LinkName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Solutioning') and constid = object_id('Fw_Cmt_Solutioning_PK'))
begin
	alter table Fw_Cmt_Solutioning add constraint Fw_Cmt_Solutioning_PK primary key clustered (WorkReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Task') and constid = object_id('Fw_Cmt_Task_PK'))
begin
	alter table Fw_Cmt_Task add constraint Fw_Cmt_Task_PK primary key clustered (CustomerID, ProjectID, WorkReqID, TaskID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Task_BR') and constid = object_id('Fw_Cmt_Task_BR_PK'))
begin
	alter table Fw_Cmt_Task_BR add constraint Fw_Cmt_Task_BR_PK primary key clustered (LangID, BRID, TaskID, UIID, WorkReqID, ActivityID, FunctionID, BPID, ProjectID, CustomerID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Task_BR_AssociatedBRs') and constid = object_id('Fw_Cmt_Task_BR_AssociatedBRs_PK'))
begin
	alter table Fw_Cmt_Task_BR_AssociatedBRs add constraint Fw_Cmt_Task_BR_AssociatedBRs_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_Task_Feature') and constid = object_id('Fw_Cmt_Task_Feature_PK'))
begin
	alter table Fw_Cmt_Task_Feature add constraint Fw_Cmt_Task_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, LangID, FeatureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_UI') and constid = object_id('Fw_Cmt_UI_PK'))
begin
	alter table Fw_Cmt_UI add constraint Fw_Cmt_UI_PK primary key clustered (CustomerID, ProjectID, WorkReqID, UIID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_UI_Feature') and constid = object_id('Fw_Cmt_UI_Feature_PK'))
begin
	alter table Fw_Cmt_UI_Feature add constraint Fw_Cmt_UI_Feature_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, LangID, FeatureID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Cmt_UI_Task') and constid = object_id('Fw_Cmt_UI_Task_PK'))
begin
	alter table Fw_Cmt_UI_Task add constraint Fw_Cmt_UI_Task_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_BPTBaseline') and constid = object_id('Fw_Dlv_BPTBaseline_PK'))
begin
	alter table Fw_Dlv_BPTBaseline add constraint Fw_Dlv_BPTBaseline_PK primary key clustered (CustomerID, ProjectID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_CMTBaseline') and constid = object_id('Fw_Dlv_CMTBaseline_PK'))
begin
	alter table Fw_Dlv_CMTBaseline add constraint Fw_Dlv_CMTBaseline_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_Customer_FuncReq') and constid = object_id('Fw_Dlv_Customer_FuncReq_PK'))
begin
	alter table Fw_Dlv_Customer_FuncReq add constraint Fw_Dlv_Customer_FuncReq_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_Document') and constid = object_id('Fw_Dlv_Document_PK'))
begin
	alter table Fw_Dlv_Document add constraint Fw_Dlv_Document_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, DocumentID, DocumentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_Location') and constid = object_id('Fw_Dlv_Location_PK'))
begin
	alter table Fw_Dlv_Location add constraint Fw_Dlv_Location_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, CompanyName, BUName, Location)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_Role') and constid = object_id('Fw_Dlv_Role_PK'))
begin
	alter table Fw_Dlv_Role add constraint Fw_Dlv_Role_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, Role, Responsibility)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Dlv_Solutioning') and constid = object_id('Fw_Dlv_Solutioning_PK'))
begin
	alter table Fw_Dlv_Solutioning add constraint Fw_Dlv_Solutioning_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Act_Sequence') and constid = object_id('Fw_Doc_Act_Sequence_PK'))
begin
	alter table Fw_Doc_Act_Sequence add constraint Fw_Doc_Act_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_ActDetails_Scenario') and constid = object_id('Fw_Doc_ActDetails_Scenario_PK'))
begin
	alter table Fw_Doc_ActDetails_Scenario add constraint Fw_Doc_ActDetails_Scenario_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_ActDetails_Scenario_Seq') and constid = object_id('Fw_Doc_ActDetails_Scenario_Seq_PK'))
begin
	alter table Fw_Doc_ActDetails_Scenario_Seq add constraint Fw_Doc_ActDetails_Scenario_Seq_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Activity_Needs') and constid = object_id('Fw_Doc_Activity_Needs_PK'))
begin
	alter table Fw_Doc_Activity_Needs add constraint Fw_Doc_Activity_Needs_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_ActScenario') and constid = object_id('Fw_Doc_ActScenario_PK'))
begin
	alter table Fw_Doc_ActScenario add constraint Fw_Doc_ActScenario_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_ActScr_Events') and constid = object_id('Fw_Doc_ActScr_Events_PK'))
begin
	alter table Fw_Doc_ActScr_Events add constraint Fw_Doc_ActScr_Events_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, InstanceID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BP_Environment') and constid = object_id('Fw_Doc_BP_Environment_PK'))
begin
	alter table Fw_Doc_BP_Environment add constraint Fw_Doc_BP_Environment_PK primary key clustered (CustomerID, ProjectID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BP_Sequence') and constid = object_id('Fw_Doc_BP_Sequence_PK'))
begin
	alter table Fw_Doc_BP_Sequence add constraint Fw_Doc_BP_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BPHistory') and constid = object_id('Fw_Doc_BPHistory_PK'))
begin
	alter table Fw_Doc_BPHistory add constraint Fw_Doc_BPHistory_PK primary key clustered (CustomerID, ProjectID, BPID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BPScenario') and constid = object_id('Fw_Doc_BPScenario_PK'))
begin
	alter table Fw_Doc_BPScenario add constraint Fw_Doc_BPScenario_PK primary key clustered (CustomerID, ProjectID, BPID, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BPScr_Events') and constid = object_id('Fw_Doc_BPScr_Events_PK'))
begin
	alter table Fw_Doc_BPScr_Events add constraint Fw_Doc_BPScr_Events_PK primary key clustered (CustomerID, ProjectID, BPID, ScenarioID, FunctionID, InstanceID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BPTBaseline') and constid = object_id('Fw_Doc_BPTBaseline_PK'))
begin
	alter table Fw_Doc_BPTBaseline add constraint Fw_Doc_BPTBaseline_PK primary key clustered (CustomerID, ProjectID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_BR') and constid = object_id('Fw_Doc_BR_PK'))
begin
	alter table Fw_Doc_BR add constraint Fw_Doc_BR_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_CMTBaseline') and constid = object_id('Fw_Doc_CMTBaseline_PK'))
begin
	alter table Fw_Doc_CMTBaseline add constraint Fw_Doc_CMTBaseline_PK primary key clustered (CustomerID, ProjectID, WorkReqID, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Customer_FuncReq') and constid = object_id('Fw_Doc_Customer_FuncReq_PK'))
begin
	alter table Fw_Doc_Customer_FuncReq add constraint Fw_Doc_Customer_FuncReq_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Document') and constid = object_id('Fw_Doc_Document_PK'))
begin
	alter table Fw_Doc_Document add constraint Fw_Doc_Document_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, ActivityID, DocumentID, DocumentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_Act_Event') and constid = object_id('Fw_Doc_Flash_Act_Event_PK'))
begin
	alter table Fw_Doc_Flash_Act_Event add constraint Fw_Doc_Flash_Act_Event_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, EventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_Act_LastInstance') and constid = object_id('Fw_Doc_Flash_Act_LastInstance_PK'))
begin
	alter table Fw_Doc_Flash_Act_LastInstance add constraint Fw_Doc_Flash_Act_LastInstance_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_Act_Scenarios_Activity_Details') and constid = object_id('Fw_Doc_Flash_Act_Scenarios_Activity_Details_PK'))
begin
	alter table Fw_Doc_Flash_Act_Scenarios_Activity_Details add constraint Fw_Doc_Flash_Act_Scenarios_Activity_Details_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_Activity') and constid = object_id('Fw_Doc_Flash_Activity_PK'))
begin
	alter table Fw_Doc_Flash_Activity add constraint Fw_Doc_Flash_Activity_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_BP_Event') and constid = object_id('Fw_Doc_Flash_BP_Event_PK'))
begin
	alter table Fw_Doc_Flash_BP_Event add constraint Fw_Doc_Flash_BP_Event_PK primary key clustered (CustomerID, ProjectID, BPID, EventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_BP_LastInstance') and constid = object_id('Fw_Doc_Flash_BP_LastInstance_PK'))
begin
	alter table Fw_Doc_Flash_BP_LastInstance add constraint Fw_Doc_Flash_BP_LastInstance_PK primary key clustered (CustomerID, ProjectID, BPID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_BP_Scenarios_Function_Details') and constid = object_id('Fw_Doc_Flash_BP_Scenarios_Function_Details_PK'))
begin
	alter table Fw_Doc_Flash_BP_Scenarios_Function_Details add constraint Fw_Doc_Flash_BP_Scenarios_Function_Details_PK primary key clustered (CustomerID, ProjectID, BPID, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Flash_Function') and constid = object_id('Fw_Doc_Flash_Function_PK'))
begin
	alter table Fw_Doc_Flash_Function add constraint Fw_Doc_Flash_Function_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Func_Sequence') and constid = object_id('Fw_Doc_Func_Sequence_PK'))
begin
	alter table Fw_Doc_Func_Sequence add constraint Fw_Doc_Func_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Location') and constid = object_id('Fw_Doc_Location_PK'))
begin
	alter table Fw_Doc_Location add constraint Fw_Doc_Location_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, ActivityID, CompanyName, BUName, Location)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Role') and constid = object_id('Fw_Doc_Role_PK'))
begin
	alter table Fw_Doc_Role add constraint Fw_Doc_Role_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, LangID, ActivityID, Role, Responsibility)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Scenario') and constid = object_id('Fw_Doc_Scenario_PK'))
begin
	alter table Fw_Doc_Scenario add constraint Fw_Doc_Scenario_PK primary key clustered (CustomerID, ProjectID, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_SecDtls') and constid = object_id('Fw_Doc_SecDtls_PK'))
begin
	alter table Fw_Doc_SecDtls add constraint Fw_Doc_SecDtls_PK primary key clustered (CustomerID, ProjectID, BPID, SeqNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Solutioning') and constid = object_id('Fw_Doc_Solutioning_PK'))
begin
	alter table Fw_Doc_Solutioning add constraint Fw_Doc_Solutioning_PK primary key clustered (CustomerReqID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_SubSecDtls') and constid = object_id('Fw_Doc_SubSecDtls_PK'))
begin
	alter table Fw_Doc_SubSecDtls add constraint Fw_Doc_SubSecDtls_PK primary key clustered (CustomerID, ProjectID, BPID, SeqNo, TabSeqNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_Task') and constid = object_id('Fw_Doc_Task_PK'))
begin
	alter table Fw_Doc_Task add constraint Fw_Doc_Task_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, TaskSequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI') and constid = object_id('Fw_Doc_UI_PK'))
begin
	alter table Fw_Doc_UI add constraint Fw_Doc_UI_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI_Controls') and constid = object_id('Fw_Doc_UI_Controls_PK'))
begin
	alter table Fw_Doc_UI_Controls add constraint Fw_Doc_UI_Controls_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, ControlID, ViewName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI_Links') and constid = object_id('Fw_Doc_UI_Links_PK'))
begin
	alter table Fw_Doc_UI_Links add constraint Fw_Doc_UI_Links_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, PageName, LinkName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI_Scenario') and constid = object_id('Fw_Doc_UI_Scenario_PK'))
begin
	alter table Fw_Doc_UI_Scenario add constraint Fw_Doc_UI_Scenario_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI_Scenario_Seq') and constid = object_id('Fw_Doc_UI_Scenario_Seq_PK'))
begin
	alter table Fw_Doc_UI_Scenario_Seq add constraint Fw_Doc_UI_Scenario_Seq_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, ScenarioID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Doc_UI_Sequence') and constid = object_id('Fw_Doc_UI_Sequence_PK'))
begin
	alter table Fw_Doc_UI_Sequence add constraint Fw_Doc_UI_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_Event') and constid = object_id('Fw_Flash_Act_Event_PK'))
begin
	alter table Fw_Flash_Act_Event add constraint Fw_Flash_Act_Event_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, EventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_LastInstance') and constid = object_id('Fw_Flash_Act_LastInstance_PK'))
begin
	alter table Fw_Flash_Act_LastInstance add constraint Fw_Flash_Act_LastInstance_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, LangID, InstanceID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_ReferenceNumber') and constid = object_id('Fw_Flash_Act_ReferenceNumber_PK'))
begin
	alter table Fw_Flash_Act_ReferenceNumber add constraint Fw_Flash_Act_ReferenceNumber_PK primary key clustered (CustomerID, ProjectID, BPID, ScenarioID, FunctionID, ReferenceNumber, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_Scenario_StartEvent') and constid = object_id('Fw_Flash_Act_Scenario_StartEvent_PK'))
begin
	alter table Fw_Flash_Act_Scenario_StartEvent add constraint Fw_Flash_Act_Scenario_StartEvent_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, ScenarioID, EventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_Scenario_TREndEvent') and constid = object_id('Fw_Flash_Act_Scenario_TREndEvent_PK'))
begin
	alter table Fw_Flash_Act_Scenario_TREndEvent add constraint Fw_Flash_Act_Scenario_TREndEvent_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, ScenarioID, EventName, ModeFlag, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_Scenarios_Activity_Details') and constid = object_id('Fw_Flash_Act_Scenarios_Activity_Details_PK'))
begin
	alter table Fw_Flash_Act_Scenarios_Activity_Details add constraint Fw_Flash_Act_Scenarios_Activity_Details_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Act_Scenarios_Events_Details') and constid = object_id('Fw_Flash_Act_Scenarios_Events_Details_PK'))
begin
	alter table Fw_Flash_Act_Scenarios_Events_Details add constraint Fw_Flash_Act_Scenarios_Events_Details_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Activity') and constid = object_id('Fw_Flash_Activity_PK'))
begin
	alter table Fw_Flash_Activity add constraint Fw_Flash_Activity_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ReferenceNumber, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP') and constid = object_id('Fw_Flash_BP_PK'))
begin
	alter table Fw_Flash_BP add constraint Fw_Flash_BP_PK primary key clustered (CustomerID, ProjectID, ReferenceNumber, BPID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_Event') and constid = object_id('Fw_Flash_BP_Event_PK'))
begin
	alter table Fw_Flash_BP_Event add constraint Fw_Flash_BP_Event_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, EventName, EventType, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_LastInstance') and constid = object_id('Fw_Flash_BP_LastInstance_PK'))
begin
	alter table Fw_Flash_BP_LastInstance add constraint Fw_Flash_BP_LastInstance_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, LangID, InstanceID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_Scenario_StartEvent') and constid = object_id('Fw_Flash_BP_Scenario_StartEvent_PK'))
begin
	alter table Fw_Flash_BP_Scenario_StartEvent add constraint Fw_Flash_BP_Scenario_StartEvent_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, ScenarioID, EventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_Scenarios') and constid = object_id('Fw_Flash_BP_Scenarios_PK'))
begin
	alter table Fw_Flash_BP_Scenarios add constraint Fw_Flash_BP_Scenarios_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, ScenarioID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_Scenarios_Events_Details') and constid = object_id('Fw_Flash_BP_Scenarios_Events_Details_PK'))
begin
	alter table Fw_Flash_BP_Scenarios_Events_Details add constraint Fw_Flash_BP_Scenarios_Events_Details_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_BP_Scenarios_Function_Details') and constid = object_id('Fw_Flash_BP_Scenarios_Function_Details_PK'))
begin
	alter table Fw_Flash_BP_Scenarios_Function_Details add constraint Fw_Flash_BP_Scenarios_Function_Details_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, ScenarioID, InstanceID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Cust_Proj_ReferenceNumber') and constid = object_id('Fw_Flash_Cust_Proj_ReferenceNumber_PK'))
begin
	alter table Fw_Flash_Cust_Proj_ReferenceNumber add constraint Fw_Flash_Cust_Proj_ReferenceNumber_PK primary key clustered (CustomerID, ProjectID, ReferenceNumber, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Flash_Function') and constid = object_id('Fw_Flash_Function_PK'))
begin
	alter table Fw_Flash_Function add constraint Fw_Flash_Function_PK primary key clustered (CustomerID, ProjectID, BPID, ReferenceNumber, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Map_BP_EventAssoc') and constid = object_id('Fw_map_BP_EventAssoc_PK1'))
begin
	alter table Fw_Map_BP_EventAssoc add constraint Fw_map_BP_EventAssoc_PK1 primary key clustered (EventName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_BP_AnalyzeEvent_hdr') and constid = object_id('PK__Fw_Nia_BP_Analyz__15CABF25'))
begin
	alter table Fw_Nia_BP_AnalyzeEvent_hdr add constraint PK__Fw_Nia_BP_Analyz__15CABF25 primary key clustered (BPEvent_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_BP_AnalyzeFunction_hdr') and constid = object_id('PK__Fw_Nia_BP_Analyz__12EE527A'))
begin
	alter table Fw_Nia_BP_AnalyzeFunction_hdr add constraint PK__Fw_Nia_BP_Analyz__12EE527A primary key clustered (BPFunc_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_BP_Picklist_hdr') and constid = object_id('PK__Fw_Nia_BP_Pickli__1011E5CF'))
begin
	alter table Fw_Nia_BP_Picklist_hdr add constraint PK__Fw_Nia_BP_Pickli__1011E5CF primary key clustered (BP_Picklistid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Function_AnalyzeActivity_hdr') and constid = object_id('PK__Fw_Nia_Function___1E600526'))
begin
	alter table Fw_Nia_Function_AnalyzeActivity_hdr add constraint PK__Fw_Nia_Function___1E600526 primary key clustered (FuncAct_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Function_AnalyzeEvent_hdr') and constid = object_id('PK__Fw_Nia_Function___213C71D1'))
begin
	alter table Fw_Nia_Function_AnalyzeEvent_hdr add constraint PK__Fw_Nia_Function___213C71D1 primary key clustered (FuncEvent_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Function_DynamPicklist_hdr') and constid = object_id('PK__Fw_Nia_Function___18A72BD0'))
begin
	alter table Fw_Nia_Function_DynamPicklist_hdr add constraint PK__Fw_Nia_Function___18A72BD0 primary key clustered (Function_DynamPicklistid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Function_ReferPicklist_hdr') and constid = object_id('PK__Fw_Nia_Function___1B83987B'))
begin
	alter table Fw_Nia_Function_ReferPicklist_hdr add constraint PK__Fw_Nia_Function___1B83987B primary key clustered (Function_ReferPicklistid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_genDoc_Activity') and constid = object_id('Fw_Nia_genDoc_Activity_PK'))
begin
	alter table Fw_Nia_genDoc_Activity add constraint Fw_Nia_genDoc_Activity_PK primary key clustered (CustomerID, ProjectID, batchid, BPID, FunctionID, ActivityID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_nia_gendoc_batch') and constid = object_id('Fw_NIA_GENDOC_BATCH_PK'))
begin
	alter table Fw_nia_gendoc_batch add constraint Fw_NIA_GENDOC_BATCH_PK primary key clustered (Customerid, Projectid, Batchid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_genDoc_Bp') and constid = object_id('Fw_Nia_genDoc_Bp_PK'))
begin
	alter table Fw_Nia_genDoc_Bp add constraint Fw_Nia_genDoc_Bp_PK primary key clustered (CustomerID, ProjectID, batchid, BPID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_genDoc_Function') and constid = object_id('Fw_Nia_genDoc_function_PK'))
begin
	alter table Fw_Nia_genDoc_Function add constraint Fw_Nia_genDoc_function_PK primary key clustered (CustomerID, ProjectID, batchid, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_genDoc_UI') and constid = object_id('Fw_Nia_genDoc_UI_PK'))
begin
	alter table Fw_Nia_genDoc_UI add constraint Fw_Nia_genDoc_UI_PK primary key clustered (CustomerID, ProjectID, batchid, BPID, FunctionID, ActivityID, UIID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Method_Analyze_Hdr') and constid = object_id('PK__Fw_Nia_Method_An__57988282'))
begin
	alter table Fw_Nia_Method_Analyze_Hdr add constraint PK__Fw_Nia_Method_An__57988282 primary key clustered (Method_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Method_Interaction_Hdr') and constid = object_id('PK__Fw_Nia_Method_In__5D515BD8'))
begin
	alter table Fw_Nia_Method_Interaction_Hdr add constraint PK__Fw_Nia_Method_In__5D515BD8 primary key clustered (Method_InteractionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Method_Nodelist_Hdr') and constid = object_id('PK__Fw_Nia_Method_No__5A74EF2D'))
begin
	alter table Fw_Nia_Method_Nodelist_Hdr add constraint PK__Fw_Nia_Method_No__5A74EF2D primary key clustered (Method_NodelistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Method_Picklist_Hdr') and constid = object_id('PK__Fw_Nia_Method_Pi__54BC15D7'))
begin
	alter table Fw_Nia_Method_Picklist_Hdr add constraint PK__Fw_Nia_Method_Pi__54BC15D7 primary key clustered (Method_PicklistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Service_Analyze_Hdr') and constid = object_id('PK__Fw_Nia_Service_A__4C26CFD6'))
begin
	alter table Fw_Nia_Service_Analyze_Hdr add constraint PK__Fw_Nia_Service_A__4C26CFD6 primary key clustered (Service_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Service_Interaction_Hdr') and constid = object_id('PK__Fw_Nia_Service_I__51DFA92C'))
begin
	alter table Fw_Nia_Service_Interaction_Hdr add constraint PK__Fw_Nia_Service_I__51DFA92C primary key clustered (Service_InteractionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Service_Nodelist_Hdr') and constid = object_id('PK__Fw_Nia_Service_N__4F033C81'))
begin
	alter table Fw_Nia_Service_Nodelist_Hdr add constraint PK__Fw_Nia_Service_N__4F033C81 primary key clustered (Service_NodelistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Service_Picklist_Hdr') and constid = object_id('PK__Fw_Nia_Service_P__3266FDD3'))
begin
	alter table Fw_Nia_Service_Picklist_Hdr add constraint PK__Fw_Nia_Service_P__3266FDD3 primary key clustered (Service_PicklistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Sheetid_Creation') and constid = object_id('Fw_Nia_Sheetid_Creation_PK'))
begin
	alter table Fw_Nia_Sheetid_Creation add constraint Fw_Nia_Sheetid_Creation_PK primary key clustered (Sheetid, Customerid, Projectid)
end

if not exists (select 'x' from sysconstraints where id = object_id('FW_NIA_Sheetid_workrequest') and constid = object_id('Fw_Nia_Sheetid_Creation_Primarykey'))
begin
	alter table FW_NIA_Sheetid_workrequest add constraint Fw_Nia_Sheetid_Creation_Primarykey primary key clustered (customerid, projectid, sheetid, workrequestid, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_SP_Analyze_Hdr') and constid = object_id('PK__Fw_Nia_SP_Analyz__630A352E'))
begin
	alter table Fw_Nia_SP_Analyze_Hdr add constraint PK__Fw_Nia_SP_Analyz__630A352E primary key clustered (SP_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_SP_Interaction_Hdr') and constid = object_id('PK__Fw_Nia_SP_Intera__68C30E84'))
begin
	alter table Fw_Nia_SP_Interaction_Hdr add constraint PK__Fw_Nia_SP_Intera__68C30E84 primary key clustered (SP_InteractionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_SP_Nodelist_Hdr') and constid = object_id('PK__Fw_Nia_SP_Nodeli__65E6A1D9'))
begin
	alter table Fw_Nia_SP_Nodelist_Hdr add constraint PK__Fw_Nia_SP_Nodeli__65E6A1D9 primary key clustered (SP_NodelistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_SP_Picklist_Hdr') and constid = object_id('PK__Fw_Nia_SP_Pickli__602DC883'))
begin
	alter table Fw_Nia_SP_Picklist_Hdr add constraint PK__Fw_Nia_SP_Pickli__602DC883 primary key clustered (SP_PicklistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Task_Analyze_Hdr') and constid = object_id('PK__Fw_Nia_Task_Anal__3A081F9B'))
begin
	alter table Fw_Nia_Task_Analyze_Hdr add constraint PK__Fw_Nia_Task_Anal__3A081F9B primary key clustered (Task_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Task_Interaction_Hdr') and constid = object_id('PK__Fw_Nia_Task_Inte__344F4645'))
begin
	alter table Fw_Nia_Task_Interaction_Hdr add constraint PK__Fw_Nia_Task_Inte__344F4645 primary key clustered (Task_InteractionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Task_Nodelist_Hdr') and constid = object_id('PK__Fw_Nia_Task_Node__372BB2F0'))
begin
	alter table Fw_Nia_Task_Nodelist_Hdr add constraint PK__Fw_Nia_Task_Node__372BB2F0 primary key clustered (Task_NodelistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_Task_Picklist_Hdr') and constid = object_id('PK__Fw_Nia_Task_Pick__3CE48C46'))
begin
	alter table Fw_Nia_Task_Picklist_Hdr add constraint PK__Fw_Nia_Task_Pick__3CE48C46 primary key clustered (Task_PicklistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_UI_Analyze_Hdr') and constid = object_id('PK__Fw_Nia_UI_Analyz__4579D247'))
begin
	alter table Fw_Nia_UI_Analyze_Hdr add constraint PK__Fw_Nia_UI_Analyz__4579D247 primary key clustered (UI_AnalyzeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_UI_Interaction_Hdr') and constid = object_id('PK__Fw_Nia_UI_Intera__3FC0F8F1'))
begin
	alter table Fw_Nia_UI_Interaction_Hdr add constraint PK__Fw_Nia_UI_Intera__3FC0F8F1 primary key clustered (UI_InteractionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_UI_Nodelist_Hdr') and constid = object_id('PK__Fw_Nia_UI_Nodeli__429D659C'))
begin
	alter table Fw_Nia_UI_Nodelist_Hdr add constraint PK__Fw_Nia_UI_Nodeli__429D659C primary key clustered (UI_NodelistID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Nia_UI_Picklist_hdr') and constid = object_id('PK__Fw_Nia_UI_Pickli__48563EF2'))
begin
	alter table Fw_Nia_UI_Picklist_hdr add constraint PK__Fw_Nia_UI_Pickli__48563EF2 primary key clustered (UI_Picklistid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_CodeGenPath') and constid = object_id('Fw_OPC_CodeGenPath_PK'))
begin
	alter table Fw_OPC_CodeGenPath add constraint Fw_OPC_CodeGenPath_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, ComponentName, ICONumber, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_GenerateHTMPath') and constid = object_id('Fw_OPC_GenerateHTMPath_PK'))
begin
	alter table Fw_OPC_GenerateHTMPath add constraint Fw_OPC_GenerateHTMPath_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, ComponentName, ICONumber, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_InitiatePackage') and constid = object_id('Fw_OPC_InitiatePackage_PK'))
begin
	alter table Fw_OPC_InitiatePackage add constraint Fw_OPC_InitiatePackage_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, ReleaseSetID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_InitPackage_Activity') and constid = object_id('Fw_OPC_InitPackage_Activity_PK'))
begin
	alter table Fw_OPC_InitPackage_Activity add constraint Fw_OPC_InitPackage_Activity_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, ComponentName, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_InitPackage_Component') and constid = object_id('Fw_OPC_InitPackage_Component_PK'))
begin
	alter table Fw_OPC_InitPackage_Component add constraint Fw_OPC_InitPackage_Component_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_ReleaseSet_FinalisedICO') and constid = object_id('Fw_OPC_ReleaseSet_FinalisedICO_PK'))
begin
	alter table Fw_OPC_ReleaseSet_FinalisedICO add constraint Fw_OPC_ReleaseSet_FinalisedICO_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, ReleaseSet, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_ReleaseSet_ICO') and constid = object_id('Fw_OPC_ReleaseSet_ICO_PK'))
begin
	alter table Fw_OPC_ReleaseSet_ICO add constraint Fw_OPC_ReleaseSet_ICO_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, ReleaseSet, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_ReleaseSet_ICO_Temp') and constid = object_id('Fw_OPC_ReleaseSet_ICO_Temp_PK'))
begin
	alter table Fw_OPC_ReleaseSet_ICO_Temp add constraint Fw_OPC_ReleaseSet_ICO_Temp_PK primary key clustered (TransactionID, CustomerID, ProjectID, ActivityID, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_OPC_ReleaseSet_Master') and constid = object_id('Fw_OPC_ReleaseSet_Master_PK'))
begin
	alter table Fw_OPC_ReleaseSet_Master add constraint Fw_OPC_ReleaseSet_Master_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, ReleaseSet)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_assignment_stmt') and constid = object_id('PK_fw_req_ilbo_rule_assignment_stmt'))
begin
	alter table fw_req_ilbo_rule_assignment_stmt add constraint PK_fw_req_ilbo_rule_assignment_stmt primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, StmtID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_bifunction') and constid = object_id('PK_fw_req_ilbo_rule_bifunction'))
begin
	alter table fw_req_ilbo_rule_bifunction add constraint PK_fw_req_ilbo_rule_bifunction primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, FunctionNameID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_bifunction_param') and constid = object_id('PK_fw_req_ilbo_rule_bifunction_param'))
begin
	alter table fw_req_ilbo_rule_bifunction_param add constraint PK_fw_req_ilbo_rule_bifunction_param primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, FunctionNameID, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_eval') and constid = object_id('PK_fw_req_ilbo_rule_eval'))
begin
	alter table fw_req_ilbo_rule_eval add constraint PK_fw_req_ilbo_rule_eval primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, Evalid)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_eval_token') and constid = object_id('PK_fw_req_ilbo_rule_eval_token'))
begin
	alter table fw_req_ilbo_rule_eval_token add constraint PK_fw_req_ilbo_rule_eval_token primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, Evalid, SeqNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_group') and constid = object_id('PK_fw_req_ilbo_rule_group'))
begin
	alter table fw_req_ilbo_rule_group add constraint PK_fw_req_ilbo_rule_group primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, GroupID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_group_stmt') and constid = object_id('PK_fw_req_ilbo_rule_group_stmt'))
begin
	alter table fw_req_ilbo_rule_group_stmt add constraint PK_fw_req_ilbo_rule_group_stmt primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, GroupID, StmtID, StmtSeqNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_nested_stmts') and constid = object_id('PK_fw_req_ilbo_rule_nested_stmts'))
begin
	alter table fw_req_ilbo_rule_nested_stmts add constraint PK_fw_req_ilbo_rule_nested_stmts primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, RootStmtID, ParentStmtID, StmtCondType, StmtID, SeqNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_property_stmt') and constid = object_id('PK_fw_req_ilbo_rule_property_stmt'))
begin
	alter table fw_req_ilbo_rule_property_stmt add constraint PK_fw_req_ilbo_rule_property_stmt primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, StmtID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_property_value') and constid = object_id('PK_fw_req_ilbo_rule_property_value'))
begin
	alter table fw_req_ilbo_rule_property_value add constraint PK_fw_req_ilbo_rule_property_value primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, StmtID, PropertyName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_stmt') and constid = object_id('PK_fw_req_ilbo_rule_stmt'))
begin
	alter table fw_req_ilbo_rule_stmt add constraint PK_fw_req_ilbo_rule_stmt primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, StmtID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_template') and constid = object_id('PK_fw_req_ilbo_rule_template'))
begin
	alter table fw_req_ilbo_rule_template add constraint PK_fw_req_ilbo_rule_template primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, SourceType, TemplateType, TemplateID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_ilbo_rule_template_stmts') and constid = object_id('PK_fw_req_ilbo_rule_template_stmts'))
begin
	alter table fw_req_ilbo_rule_template_stmts add constraint PK_fw_req_ilbo_rule_template_stmts primary key clustered (CustomerName, ProjectName, DocumentNumber, ComponentName, ILBOCode, PolicyID, StmtSeqNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_artifact_type') and constid = object_id('PK_fw_req_rule_artifact_type'))
begin
	alter table fw_req_rule_artifact_type add constraint PK_fw_req_rule_artifact_type primary key clustered (ArtifactType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_bifunction') and constid = object_id('PK_fw_req_rule_bifunction'))
begin
	alter table fw_req_rule_bifunction add constraint PK_fw_req_rule_bifunction primary key clustered (FunctionName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_bifunction_param') and constid = object_id('PK_fw_req_rule_bifunction_param'))
begin
	alter table fw_req_rule_bifunction_param add constraint PK_fw_req_rule_bifunction_param primary key clustered (FunctionName, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_context_dataitem') and constid = object_id('PK_fw_req_rule_context_dataitem'))
begin
	alter table fw_req_rule_context_dataitem add constraint PK_fw_req_rule_context_dataitem primary key clustered (ContextDataItem)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_data_type') and constid = object_id('PK_fw_req_rule_data_type'))
begin
	alter table fw_req_rule_data_type add constraint PK_fw_req_rule_data_type primary key clustered (DataTypeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_inf_source_map') and constid = object_id('PK_fw_req_rule_inf_source_map'))
begin
	alter table fw_req_rule_inf_source_map add constraint PK_fw_req_rule_inf_source_map primary key clustered (InterfaceCode, SourceType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_inf_template_map') and constid = object_id('PK_fw_req_rule_inf_template_map'))
begin
	alter table fw_req_rule_inf_template_map add constraint PK_fw_req_rule_inf_template_map primary key clustered (InterfaceCode, TemplateType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_property_type') and constid = object_id('PK_fw_req_rule_property_type'))
begin
	alter table fw_req_rule_property_type add constraint PK_fw_req_rule_property_type primary key clustered (PropertyType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_source_type') and constid = object_id('PK_fw_req_rule_source_type'))
begin
	alter table fw_req_rule_source_type add constraint PK_fw_req_rule_source_type primary key clustered (SourceType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_stmt_type') and constid = object_id('PK_fw_req_rule_stmt_type'))
begin
	alter table fw_req_rule_stmt_type add constraint PK_fw_req_rule_stmt_type primary key clustered (StmtType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_template_type') and constid = object_id('PK_fw_req_rule_template_type'))
begin
	alter table fw_req_rule_template_type add constraint PK_fw_req_rule_template_type primary key clustered (TemplateType)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_req_rule_token_type') and constid = object_id('PK_fw_req_rule_token_type'))
begin
	alter table fw_req_rule_token_type add constraint PK_fw_req_rule_token_type primary key clustered (TokenType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_activity_ReleaseVersion') and constid = object_id('Fw_Rmt_activity_ReleaseVersion_pk'))
begin
	alter table Fw_Rmt_activity_ReleaseVersion add constraint Fw_Rmt_activity_ReleaseVersion_pk primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, componentname, Activityname)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Bpt_RCN') and constid = object_id('Fw_Rmt_Bpt_RCN_PK'))
begin
	alter table Fw_Rmt_Bpt_RCN add constraint Fw_Rmt_Bpt_RCN_PK primary key clustered (CustomerID, ProjectID, LangID, RCNNumber, BPID, FunctionID, ComponentName, ActivityID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Cmt_ICO_details') and constid = object_id('Fw_Rmt_Cmt_ICO_details_PK'))
begin
	alter table Fw_Rmt_Cmt_ICO_details add constraint Fw_Rmt_Cmt_ICO_details_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber, ICONumber, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Cmt_RCN') and constid = object_id('Fw_Rmt_Cmt_RCN_PK'))
begin
	alter table Fw_Rmt_Cmt_RCN add constraint Fw_Rmt_Cmt_RCN_PK primary key clustered (CustomerID, ProjectID, LangID, RCNNumber, WorkReqID)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_rmt_component_user') and constid = object_id('fw_rmt_component_user_pkey'))
begin
	alter table fw_rmt_component_user add constraint fw_rmt_component_user_pkey primary key clustered (CustomerID, ProjectID, UserName, BpcName, ComponentName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Direct_ECR_ImpactedTask') and constid = object_id('Fw_Rmt_Direct_ECR_ImpactedTask_PK'))
begin
	alter table Fw_Rmt_Direct_ECR_ImpactedTask add constraint Fw_Rmt_Direct_ECR_ImpactedTask_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber, ReleaseVersionNo, ServiceName, ImpactedComponentName, ActivityID, UIID, ImpactedTaskID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Direct_ECR_LinkBR') and constid = object_id('Fw_Rmt_Direct_ECR_LinkBR_PK'))
begin
	alter table Fw_Rmt_Direct_ECR_LinkBR add constraint Fw_Rmt_Direct_ECR_LinkBR_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber, ServiceName, BRName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_AssociatedDetailedBR') and constid = object_id('Fw_Rmt_DirectRCN_AssociatedDetailedBR_PK'))
begin
	alter table Fw_Rmt_DirectRCN_AssociatedDetailedBR add constraint Fw_Rmt_DirectRCN_AssociatedDetailedBR_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskID, DetailedBRID, FlowBRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_AssociatedFlowBR') and constid = object_id('Fw_Rmt_DirectRCN_AssociatedFlowBR_PK'))
begin
	alter table Fw_Rmt_DirectRCN_AssociatedFlowBR add constraint Fw_Rmt_DirectRCN_AssociatedFlowBR_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskID, FlowBRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_DetailedBR') and constid = object_id('Fw_Rmt_DirectRCN_DetailedBR_PK'))
begin
	alter table Fw_Rmt_DirectRCN_DetailedBR add constraint Fw_Rmt_DirectRCN_DetailedBR_PK primary key clustered (CustomerID, ProjectID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_FlowBR') and constid = object_id('Fw_Rmt_DirectRCN_FlowBR_PK'))
begin
	alter table Fw_Rmt_DirectRCN_FlowBR add constraint Fw_Rmt_DirectRCN_FlowBR_PK primary key clustered (CustomerID, ProjectID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_ImpactedTask') and constid = object_id('Fw_Rmt_DirectRCN_ImpactedTask_PK'))
begin
	alter table Fw_Rmt_DirectRCN_ImpactedTask add constraint Fw_Rmt_DirectRCN_ImpactedTask_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskName, ImpactedActivityID, ImpactedUIID, ImpactedTaskname)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_Link') and constid = object_id('Fw_Rmt_DirectRCN_Link_PK'))
begin
	alter table Fw_Rmt_DirectRCN_Link add constraint Fw_Rmt_DirectRCN_Link_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, LinkName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_Task') and constid = object_id('Fw_Rmt_DirectRCN_Task_PK'))
begin
	alter table Fw_Rmt_DirectRCN_Task add constraint Fw_Rmt_DirectRCN_Task_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_DirectRCN_WorkReq') and constid = object_id('Fw_Rmt_DirectRCN_WorkReq_PK'))
begin
	alter table Fw_Rmt_DirectRCN_WorkReq add constraint Fw_Rmt_DirectRCN_WorkReq_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, RCNNumber, LangID, WorkReqID)
end

if not exists (select 'x' from sysconstraints where id = object_id('FW_RMT_DOC_USER') and constid = object_id('FW_RMT_DOC_USER_PK'))
begin
	alter table FW_RMT_DOC_USER add constraint FW_RMT_DOC_USER_PK primary key clustered (CUSTOMERID, PROJECTID, DOCTYPE, DOCNO, USERNAME)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ECR') and constid = object_id('Fw_Rmt_ECR_PK'))
begin
	alter table Fw_Rmt_ECR add constraint Fw_Rmt_ECR_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ECR_ICO_Details') and constid = object_id('Fw_Rmt_ECR_ICO_Details_PK'))
begin
	alter table Fw_Rmt_ECR_ICO_Details add constraint Fw_Rmt_ECR_ICO_Details_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ICO') and constid = object_id('Fw_Rmt_ICO_PK'))
begin
	alter table Fw_Rmt_ICO add constraint Fw_Rmt_ICO_PK primary key clustered (CustomerID, ProjectID, LangID, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_Impacted_Wk') and constid = object_id('Fw_Rmt_Impacted_Wk_PK'))
begin
	alter table Fw_Rmt_Impacted_Wk add constraint Fw_Rmt_Impacted_Wk_PK primary key clustered (CustomerID, ProjectID, LangID, WorkReqID, DepWorkReqID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_RMT_Lang_CustProj') and constid = object_id('Fw_RMT_Lang_CustProj_PK'))
begin
	alter table Fw_RMT_Lang_CustProj add constraint Fw_RMT_Lang_CustProj_PK primary key clustered (Customer, Project, LangCode)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_RCN') and constid = object_id('Fw_Rmt_RCN_PK'))
begin
	alter table Fw_Rmt_RCN add constraint Fw_Rmt_RCN_PK primary key clustered (CustomerID, ProjectID, LangID, RCNNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ReleaseVersion') and constid = object_id('Fw_Rmt_ReleaseVersion_PK'))
begin
	alter table Fw_Rmt_ReleaseVersion add constraint Fw_Rmt_ReleaseVersion_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ReleaseVersion_ECR') and constid = object_id('Fw_Rmt_ReleaseVersion_ECR_PK'))
begin
	alter table Fw_Rmt_ReleaseVersion_ECR add constraint Fw_Rmt_ReleaseVersion_ECR_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ReleaseVersion_ICO') and constid = object_id('Fw_Rmt_ReleaseVersion_ICO_PK'))
begin
	alter table Fw_Rmt_ReleaseVersion_ICO add constraint Fw_Rmt_ReleaseVersion_ICO_PK primary key clustered (CustomerID, ProjectID, LangID, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ReleaseVersion_RCN') and constid = object_id('Fw_Rmt_ReleaseVersion_RCN_PK'))
begin
	alter table Fw_Rmt_ReleaseVersion_RCN add constraint Fw_Rmt_ReleaseVersion_RCN_PK primary key clustered (CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ReleaseVersion_WorkReq') and constid = object_id('Fw_Rmt_ReleaseVersion_WorkReq_PK'))
begin
	alter table Fw_Rmt_ReleaseVersion_WorkReq add constraint Fw_Rmt_ReleaseVersion_WorkReq_PK primary key clustered (CustomerID, ProjectID, ReleaseVersionNo, LangID, WorkReqID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ShortClose_ECR') and constid = object_id('Fw_Rmt_ShortClose_ECR_PK'))
begin
	alter table Fw_Rmt_ShortClose_ECR add constraint Fw_Rmt_ShortClose_ECR_PK primary key clustered (CustomerID, ProjectID, LangID, ECRNumber, ECRType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_ShortClose_RCN') and constid = object_id('Fw_Rmt_ShortClose_RCN_PK'))
begin
	alter table Fw_Rmt_ShortClose_RCN add constraint Fw_Rmt_ShortClose_RCN_PK primary key clustered (CustomerID, ProjectID, LangID, RCNNumber, RCNType)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Rmt_UserRole_Mapping') and constid = object_id('Fw_Rmt_UserRole_Mapping_PK'))
begin
	alter table Fw_Rmt_UserRole_Mapping add constraint Fw_Rmt_UserRole_Mapping_PK primary key clustered (CustomerId, Projectid, UserName, BPId, FunctionId)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_ApproveTestComp') and constid = object_id('Fw_Tmt_ApproveTestComp_PK'))
begin
	alter table Fw_Tmt_ApproveTestComp add constraint Fw_Tmt_ApproveTestComp_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_AssociateUser') and constid = object_id('Fw_Tmt_AssociateUser_PK'))
begin
	alter table Fw_Tmt_AssociateUser add constraint Fw_Tmt_AssociateUser_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, AssignedTo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_EnvironmentSetup') and constid = object_id('Fw_Tmt_EnvironmentSetup_PK'))
begin
	alter table Fw_Tmt_EnvironmentSetup add constraint Fw_Tmt_EnvironmentSetup_PK primary key clustered (CustomerID, ProjectID, EnvSetupNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_EnvSetup_Details') and constid = object_id('Fw_Tmt_EnvSetup_Details_PK'))
begin
	alter table Fw_Tmt_EnvSetup_Details add constraint Fw_Tmt_EnvSetup_Details_PK primary key clustered (CustomerID, ProjectID, EnvSetupNo, EnvItemName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_EnvSetup_RelVer') and constid = object_id('Fw_Tmt_EnvSetup_RelVer_PK'))
begin
	alter table Fw_Tmt_EnvSetup_RelVer add constraint Fw_Tmt_EnvSetup_RelVer_PK primary key clustered (CustomerID, ProjectID, EnvSetupNo, RelVersionNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_InitiateTest') and constid = object_id('Fw_Tmt_InitiateTest_PK'))
begin
	alter table Fw_Tmt_InitiateTest add constraint Fw_Tmt_InitiateTest_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_IntegrationTest') and constid = object_id('Fw_Tmt_IntegrationTest_PK'))
begin
	alter table Fw_Tmt_IntegrationTest add constraint Fw_Tmt_IntegrationTest_PK primary key clustered (CustomerID, ProjectID, FunctionID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_IntegrationTestCase') and constid = object_id('Fw_Tmt_IntegrationTestCase_PK'))
begin
	alter table Fw_Tmt_IntegrationTestCase add constraint Fw_Tmt_IntegrationTestCase_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_IntegrationTestPlan') and constid = object_id('Fw_Tmt_IntegrationTestPlan_PK'))
begin
	alter table Fw_Tmt_IntegrationTestPlan add constraint Fw_Tmt_IntegrationTestPlan_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_ITC_InstrSet') and constid = object_id('Fw_Tmt_ITC_InstrSet_PK'))
begin
	alter table Fw_Tmt_ITC_InstrSet add constraint Fw_Tmt_ITC_InstrSet_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TestCaseNo, InstrSetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_ITC_Set_Sequence') and constid = object_id('Fw_Tmt_ITC_Set_Sequence_PK'))
begin
	alter table Fw_Tmt_ITC_Set_Sequence add constraint Fw_Tmt_ITC_Set_Sequence_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TestCaseNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_ITP_ITC') and constid = object_id('Fw_Tmt_ITP_ITC_PK'))
begin
	alter table Fw_Tmt_ITP_ITC add constraint Fw_Tmt_ITP_ITC_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, FunctionID, ActivityID, UIID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_ITP_ITC_Set') and constid = object_id('Fw_Tmt_ITP_ITC_Set_PK'))
begin
	alter table Fw_Tmt_ITP_ITC_Set add constraint Fw_Tmt_ITP_ITC_Set_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, FunctionID, ActivityID, UIID, TestCaseNo, SetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogITCResult') and constid = object_id('Fw_Tmt_LogITCResult_PK'))
begin
	alter table Fw_Tmt_LogITCResult add constraint Fw_Tmt_LogITCResult_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogITInstructions') and constid = object_id('Fw_Tmt_LogITInstructions_PK'))
begin
	alter table Fw_Tmt_LogITInstructions add constraint Fw_Tmt_LogITInstructions_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogSTCResult') and constid = object_id('Fw_Tmt_LogSTCResult_PK'))
begin
	alter table Fw_Tmt_LogSTCResult add constraint Fw_Tmt_LogSTCResult_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogSTInstructions') and constid = object_id('Fw_Tmt_LogSTInstructions_PK'))
begin
	alter table Fw_Tmt_LogSTInstructions add constraint Fw_Tmt_LogSTInstructions_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogTC_LatestTest') and constid = object_id('Fw_Tmt_LogTC_LatestTest_PK'))
begin
	alter table Fw_Tmt_LogTC_LatestTest add constraint Fw_Tmt_LogTC_LatestTest_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogUTCResult') and constid = object_id('Fw_Tmt_LogUTCResult_PK'))
begin
	alter table Fw_Tmt_LogUTCResult add constraint Fw_Tmt_LogUTCResult_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_LogUTInstructions') and constid = object_id('Fw_Tmt_LogUTInstructions_PK'))
begin
	alter table Fw_Tmt_LogUTInstructions add constraint Fw_Tmt_LogUTInstructions_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, TestedUser, TestCaseNo, InstanceNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STC_Act_InstrSet') and constid = object_id('Fw_Tmt_STC_Act_InstrSet_PK'))
begin
	alter table Fw_Tmt_STC_Act_InstrSet add constraint Fw_Tmt_STC_Act_InstrSet_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, TestCaseNo, InstrSetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STC_Act_Set_Sequence') and constid = object_id('Fw_Tmt_STC_Act_Set_Sequence_PK'))
begin
	alter table Fw_Tmt_STC_Act_Set_Sequence add constraint Fw_Tmt_STC_Act_Set_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, TestCaseNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STC_BP_InstrSet') and constid = object_id('Fw_Tmt_STC_BP_InstrSet_PK'))
begin
	alter table Fw_Tmt_STC_BP_InstrSet add constraint Fw_Tmt_STC_BP_InstrSet_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ScenarioID, TestCaseNo, InstrSetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STC_BP_Set_Sequence') and constid = object_id('Fw_Tmt_STC_BP_Set_Sequence_PK'))
begin
	alter table Fw_Tmt_STC_BP_Set_Sequence add constraint Fw_Tmt_STC_BP_Set_Sequence_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ScenarioID, TestCaseNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STP_STC') and constid = object_id('Fw_Tmt_STP_STC_PK'))
begin
	alter table Fw_Tmt_STP_STC add constraint Fw_Tmt_STP_STC_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, ScenarioID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_STP_STC_Set') and constid = object_id('Fw_Tmt_STP_STC_Set_PK'))
begin
	alter table Fw_Tmt_STP_STC_Set add constraint Fw_Tmt_STP_STC_Set_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, ScenarioID, TestCaseNo, SetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_SystemTest') and constid = object_id('Fw_Tmt_SystemTest_PK'))
begin
	alter table Fw_Tmt_SystemTest add constraint Fw_Tmt_SystemTest_PK primary key clustered (CustomerID, ProjectID, FunctionID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_SystemTestCase_Act') and constid = object_id('Fw_Tmt_SystemTestCase_Act_PK'))
begin
	alter table Fw_Tmt_SystemTestCase_Act add constraint Fw_Tmt_SystemTestCase_Act_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ActivityID, ScenarioID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_SystemTestCase_BP') and constid = object_id('Fw_Tmt_SystemTestCase_BP_PK'))
begin
	alter table Fw_Tmt_SystemTestCase_BP add constraint Fw_Tmt_SystemTestCase_BP_PK primary key clustered (CustomerID, ProjectID, BPID, FunctionID, ScenarioID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_SystemTestPlan') and constid = object_id('Fw_Tmt_SystemTestPlan_PK'))
begin
	alter table Fw_Tmt_SystemTestPlan add constraint Fw_Tmt_SystemTestPlan_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UnitTest') and constid = object_id('Fw_Tmt_UnitTest_PK'))
begin
	alter table Fw_Tmt_UnitTest add constraint Fw_Tmt_UnitTest_PK primary key clustered (CustomerID, ProjectID, FunctionID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UnitTestCase') and constid = object_id('Fw_Tmt_UnitTestCase_PK'))
begin
	alter table Fw_Tmt_UnitTestCase add constraint Fw_Tmt_UnitTestCase_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TaskID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UnitTestPlan') and constid = object_id('Fw_Tmt_UnitTestPlan_PK'))
begin
	alter table Fw_Tmt_UnitTestPlan add constraint Fw_Tmt_UnitTestPlan_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UTC_InstrSet') and constid = object_id('Fw_Tmt_UTC_InstrSet_PK'))
begin
	alter table Fw_Tmt_UTC_InstrSet add constraint Fw_Tmt_UTC_InstrSet_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TaskID, TestCaseNo, InstrSetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UTC_Set_Sequence') and constid = object_id('Fw_Tmt_UTC_Set_Sequence_PK'))
begin
	alter table Fw_Tmt_UTC_Set_Sequence add constraint Fw_Tmt_UTC_Set_Sequence_PK primary key clustered (CustomerID, ProjectID, FunctionID, ActivityID, UIID, TaskID, TestCaseNo, InstrSetID, SequenceNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UTP_UTC') and constid = object_id('Fw_Tmt_UTP_UTC_PK'))
begin
	alter table Fw_Tmt_UTP_UTC add constraint Fw_Tmt_UTP_UTC_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, FunctionID, ActivityID, UIID, TestCaseNo, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Fw_Tmt_UTP_UTC_Set') and constid = object_id('Fw_Tmt_UTP_UTC_Set_PK'))
begin
	alter table Fw_Tmt_UTP_UTC_Set add constraint Fw_Tmt_UTP_UTC_Set_PK primary key clustered (CustomerID, ProjectID, RelVersionNo, DocumentType, DocumentNo, TestPlanNo, FunctionID, ActivityID, UIID, TestCaseNo, SetID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_assignment_change_log') and constid = object_id('hpl_assignment_change_log_pkey'))
begin
	alter table hpl_assignment_change_log add constraint hpl_assignment_change_log_pkey primary key clustered (change_version, customer_name, project_name, plan_id, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_assignment_dtl') and constid = object_id('hpl_assignment_dtl_pkey'))
begin
	alter table hpl_assignment_dtl add constraint hpl_assignment_dtl_pkey primary key clustered (customer_name, project_name, plan_id, employee_code, version_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_assignment_history') and constid = object_id('hpl_assignment_history_pkey'))
begin
	alter table hpl_assignment_history add constraint hpl_assignment_history_pkey primary key clustered (hst_version_no, customer_name, project_name, plan_id, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_change_log') and constid = object_id('hpl_change_log_pkey'))
begin
	alter table hpl_change_log add constraint hpl_change_log_pkey primary key clustered (customer_name, project_name, plan_id, change_version)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_custml_ref_templates') and constid = object_id('hpl_custml_ref_templates_pkey'))
begin
	alter table hpl_custml_ref_templates add constraint hpl_custml_ref_templates_pkey primary key clustered (customer_name, project_name, plan_id, reference_template)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_fin_note_hdr') and constid = object_id('hpl_fin_note_hdr_pkey'))
begin
	alter table hpl_fin_note_hdr add constraint hpl_fin_note_hdr_pkey primary key clustered (customer_name, project_name, finalization_note_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_generate_log') and constid = object_id('hpl_generate_log_pkey'))
begin
	alter table hpl_generate_log add constraint hpl_generate_log_pkey primary key clustered (customer_name, project_name, plan_id, plan_item, plan_version_no, generated_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_generate_log_hdr') and constid = object_id('hpl_generate_log_hdr_pkey'))
begin
	alter table hpl_generate_log_hdr add constraint hpl_generate_log_hdr_pkey primary key clustered (customer_name, project_name, batch_id, user_id, start_date, end_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_genplan_doc') and constid = object_id('hpl_genplan_doc_pkey'))
begin
	alter table hpl_genplan_doc add constraint hpl_genplan_doc_pkey primary key clustered (Customer_name, project_name, plan_id, Work_product_type, Work_product, DocumentType, DocumentNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_Maintain_Plan_History') and constid = object_id('hpl_Maintain_Plan_History_pkey'))
begin
	alter table hpl_Maintain_Plan_History add constraint hpl_Maintain_Plan_History_pkey primary key clustered (customer_name, project_name, plan_id, hst_version_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_ns_workproducts') and constid = object_id('hpl_ns_workproducts_pkey'))
begin
	alter table hpl_ns_workproducts add constraint hpl_ns_workproducts_pkey primary key clustered (customer_name, project_name, workprd_type, user_id, work_product)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_plan_detail') and constid = object_id('hpl_plan_detail_pkey'))
begin
	alter table hpl_plan_detail add constraint hpl_plan_detail_pkey primary key clustered (customer_name, project_name, plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_plan_detail_arc') and constid = object_id('hpl_plan_detail_arc_pkey'))
begin
	alter table hpl_plan_detail_arc add constraint hpl_plan_detail_arc_pkey primary key clustered (Customer_name, Project_name, Plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_plan_history') and constid = object_id('hpl_plan_history_pkey'))
begin
	alter table hpl_plan_history add constraint hpl_plan_history_pkey primary key clustered (customer_name, project_name, plan_id, hst_version_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_plan_predecessor') and constid = object_id('hpl_plan_predecessor_pkey'))
begin
	alter table hpl_plan_predecessor add constraint hpl_plan_predecessor_pkey primary key clustered (customer_name, project_name, plan_id, predecessor)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_plan_structure') and constid = object_id('hpl_plan_structure_pkey'))
begin
	alter table hpl_plan_structure add constraint hpl_plan_structure_pkey primary key clustered (customer_name, project_name, plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_quick_code_met') and constid = object_id('hpl_quick_code_met_pkey'))
begin
	alter table hpl_quick_code_met add constraint hpl_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_quick_code_met_lng_extn') and constid = object_id('hpl_quick_code_met_lng_extn_pkey'))
begin
	alter table hpl_quick_code_met_lng_extn add constraint hpl_quick_code_met_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_risk_dtl') and constid = object_id('hpl_risk_dtl_pkey'))
begin
	alter table hpl_risk_dtl add constraint hpl_risk_dtl_pkey primary key clustered (customer_name, project_name, plan_id, risk_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_struct_predecessor') and constid = object_id('hpl_struct_predecessor_pkey'))
begin
	alter table hpl_struct_predecessor add constraint hpl_struct_predecessor_pkey primary key clustered (customer_name, project_name, plan_id, predecessor)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_worklist_mst') and constid = object_id('hpl_worklist_mst_pkey'))
begin
	alter table hpl_worklist_mst add constraint hpl_worklist_mst_pkey primary key clustered (customer_name, project_name, workitem_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_workprod_component') and constid = object_id('hpl_workprod_component_pkey'))
begin
	alter table hpl_workprod_component add constraint hpl_workprod_component_pkey primary key clustered (customer_name, project_name, document_type, document_no, process_name, component_name, user_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_workprod_document') and constid = object_id('hpl_workprod_document_pkey'))
begin
	alter table hpl_workprod_document add constraint hpl_workprod_document_pkey primary key clustered (customer_name, project_name, document_type, document_no, user_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('hpl_workprod_process') and constid = object_id('hpl_workprod_process_pkey'))
begin
	alter table hpl_workprod_process add constraint hpl_workprod_process_pkey primary key clustered (customer_name, project_name, document_type, document_no, process_name, user_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('irule_inf_req_details') and constid = object_id('irule_inf_req_details_PK'))
begin
	alter table irule_inf_req_details add constraint irule_inf_req_details_PK primary key clustered (CustomerName, ProjectName, DocumentNumber, ProcessName, ComponentName, ActivityName, ILBOCode, TabName, SectionName, LangId)
end

if not exists (select 'x' from sysconstraints where id = object_id('Method_trigger_dtl') and constid = object_id('method_trigger_dtl_pkey'))
begin
	alter table Method_trigger_dtl add constraint method_trigger_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, method_name, createdby, createddate)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_Class') and constid = object_id('pk_NFR_Class'))
begin
	alter table NFR_Class add constraint pk_NFR_Class primary key clustered (nfr_class_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_COMPSP_MAP') and constid = object_id('pk_NFR_COMPSP_MAP'))
begin
	alter table NFR_COMPSP_MAP add constraint pk_NFR_COMPSP_MAP primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_DTL') and constid = object_id('pk_NFR_DTL'))
begin
	alter table NFR_DTL add constraint pk_NFR_DTL primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE, NODEID, CFG_code, nfr_class_code, GRP_code, SEG_code, INST_code, INST_SEQ)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_DTL2') and constid = object_id('pk_NFR_DTL2'))
begin
	alter table NFR_DTL2 add constraint pk_NFR_DTL2 primary key clustered (ROWID)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_MAP') and constid = object_id('pk_NFR_MAP'))
begin
	alter table NFR_MAP add constraint pk_NFR_MAP primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_Reference_Value') and constid = object_id('pk_nfr_reference_value'))
begin
	alter table NFR_Reference_Value add constraint pk_nfr_reference_value primary key clustered (ReferenceType)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL') and constid = object_id('pk_NFR_TMPL'))
begin
	alter table NFR_TMPL add constraint pk_NFR_TMPL primary key clustered (cfg_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL_GRP') and constid = object_id('pk_NFR_TMPL_GRP'))
begin
	alter table NFR_TMPL_GRP add constraint pk_NFR_TMPL_GRP primary key clustered (cfg_code, nfr_class_code, GRP_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL_INST') and constid = object_id('pk_NFR_TMPL_INST'))
begin
	alter table NFR_TMPL_INST add constraint pk_NFR_TMPL_INST primary key clustered (cfg_code, nfr_class_code, GRP_code, SEG_code, INST_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL_INST_MATRIX') and constid = object_id('pk_NFR_TMPL_INST_MATRIX'))
begin
	alter table NFR_TMPL_INST_MATRIX add constraint pk_NFR_TMPL_INST_MATRIX primary key clustered (cfg_code, nfr_class_code, GRP_code, SEG_code, INST_code, INST_SEQ)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL_INST_ML') and constid = object_id('pk_NFR_TMPL_INST_ML'))
begin
	alter table NFR_TMPL_INST_ML add constraint pk_NFR_TMPL_INST_ML primary key clustered (cfg_code, nfr_class_code, GRP_code, SEG_code, INST_code, INST_ML_CODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TMPL_SEG') and constid = object_id('pk_NFR_TMPL_SEG'))
begin
	alter table NFR_TMPL_SEG add constraint pk_NFR_TMPL_SEG primary key clustered (cfg_code, nfr_class_code, GRP_code, SEG_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_TypeCode') and constid = object_id('pk_NFR_TypeCode'))
begin
	alter table NFR_TypeCode add constraint pk_NFR_TypeCode primary key clustered (Type_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_VER_DTL') and constid = object_id('pk_NFR_VER_dtl'))
begin
	alter table NFR_VER_DTL add constraint pk_NFR_VER_dtl primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE, NODEID, CURRENT_VERSION, CFG_code, nfr_class_code, GRP_code, SEG_code, INST_code, INST_SEQ)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_VER_DTL2') and constid = object_id('pk_NFR_VER_dtl2'))
begin
	alter table NFR_VER_DTL2 add constraint pk_NFR_VER_dtl2 primary key clustered (CURRENT_VERSION, ROWID)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_VER_HISTORY') and constid = object_id('pk_NFR_VER_HISTORY'))
begin
	alter table NFR_VER_HISTORY add constraint pk_NFR_VER_HISTORY primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE, NODEID, CURRENT_VERSION)
end

if not exists (select 'x' from sysconstraints where id = object_id('NFR_VER_MAP') and constid = object_id('pk_NFR_VER_MAP'))
begin
	alter table NFR_VER_MAP add constraint pk_NFR_VER_MAP primary key clustered (CUSTOMERID, PROJECTID, DOC_code, NODETYPE)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_calendar_dtl') and constid = object_id('pc_calendar_dtl_pkey'))
begin
	alter table pc_calendar_dtl add constraint pc_calendar_dtl_pkey primary key clustered (customer_name, project_name, weekday)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_ns_workprd_dtl') and constid = object_id('pc_ns_workprd_dtl_pkey'))
begin
	alter table pc_ns_workprd_dtl add constraint pc_ns_workprd_dtl_pkey primary key clustered (customer_name, project_name, plan_type, workproduct_type, work_product)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_ns_workprd_type_hdr') and constid = object_id('pc_ns_workprd_type_hdr_pkey'))
begin
	alter table pc_ns_workprd_type_hdr add constraint pc_ns_workprd_type_hdr_pkey primary key clustered (customer_name, project_name, plan_type, workproduct_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_plan_temp_categ_wrkprd_map') and constid = object_id('pc_plan_temp_categ_wrkprd_map_pkey'))
begin
	alter table pc_plan_temp_categ_wrkprd_map add constraint pc_plan_temp_categ_wrkprd_map_pkey primary key clustered (customer_name, project_name, template_category, plan_type, work_product_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_plan_template_category') and constid = object_id('pc_plan_template_category_pkey'))
begin
	alter table pc_plan_template_category add constraint pc_plan_template_category_pkey primary key clustered (customer_name, project_name, template_category)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_plan_template_dtl') and constid = object_id('pc_plan_template_dtl_pkey'))
begin
	alter table pc_plan_template_dtl add constraint pc_plan_template_dtl_pkey primary key clustered (customer_name, project_name, template_category, plan_type, work_product_type, template_id, wbs_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_plan_template_hdr') and constid = object_id('pc_plan_template_hdr_pkey'))
begin
	alter table pc_plan_template_hdr add constraint pc_plan_template_hdr_pkey primary key clustered (customer_name, project_name, template_category, plan_type, work_product_type, template_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_documentation') and constid = object_id('pc_proj_documentation_pkey'))
begin
	alter table pc_proj_documentation add constraint pc_proj_documentation_pkey primary key clustered (customer_name, project_name, documentation_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_hardware_dtl') and constid = object_id('pc_proj_hardware_dtl_pkey'))
begin
	alter table pc_proj_hardware_dtl add constraint pc_proj_hardware_dtl_pkey primary key clustered (customer_name, project_name, resource_type, resource_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_role_dtl') and constid = object_id('pc_proj_role_dtl_pkey'))
begin
	alter table pc_proj_role_dtl add constraint pc_proj_role_dtl_pkey primary key clustered (customer_name, project_name, role_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sc_emp_dtl') and constid = object_id('pc_proj_sc_emp_dtl_pkey'))
begin
	alter table pc_proj_sc_emp_dtl add constraint pc_proj_sc_emp_dtl_pkey primary key clustered (customer_name, project_name, solution_center_code, employee_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sc_emp_dtl_history') and constid = object_id('pc_proj_sc_emp_dtl_history_pkey'))
begin
	alter table pc_proj_sc_emp_dtl_history add constraint pc_proj_sc_emp_dtl_history_pkey primary key clustered (customer_name, project_name, solution_center_code, employee_code, hst_verison_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sc_emp_role_dtl') and constid = object_id('pc_proj_sc_emp_role_dtl_pkey'))
begin
	alter table pc_proj_sc_emp_role_dtl add constraint pc_proj_sc_emp_role_dtl_pkey primary key clustered (customer_name, project_name, solution_center_code, role_name, employee_code, available_fromdate, available_todate)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sc_supervisor_emp_dtl') and constid = object_id('pc_proj_sc_supervisor_emp_dtl_pkey'))
begin
	alter table pc_proj_sc_supervisor_emp_dtl add constraint pc_proj_sc_supervisor_emp_dtl_pkey primary key clustered (customer_name, project_name, employee_code, Supervisor_code, Effective_from, Primary_Supervisor)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sc_supervisor_emp_dtl_history') and constid = object_id('pc_proj_sc_supervisor_emp_dtl_history_pkey'))
begin
	alter table pc_proj_sc_supervisor_emp_dtl_history add constraint pc_proj_sc_supervisor_emp_dtl_history_pkey primary key clustered (customer_name, project_name, solution_center_code, employee_code, hst_verison_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_proj_sol_center_dtl') and constid = object_id('pc_proj_sol_center_dtl_pkey'))
begin
	alter table pc_proj_sol_center_dtl add constraint pc_proj_sol_center_dtl_pkey primary key clustered (customer_name, project_name, solution_center_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_project_calendar') and constid = object_id('PK__pc_project_calen__06BC187D'))
begin
	alter table pc_project_calendar add constraint PK__pc_project_calen__06BC187D primary key clustered (customer_name, project_name, date)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_project_hdr') and constid = object_id('pc_project_hdr_pkey'))
begin
	alter table pc_project_hdr add constraint pc_project_hdr_pkey primary key clustered (customer_name, project_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_quick_code_met') and constid = object_id('pc_quick_code_met_pkey'))
begin
	alter table pc_quick_code_met add constraint pc_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_quick_code_met_lng_extn') and constid = object_id('pc_quick_code_met_lng_extn_pkey'))
begin
	alter table pc_quick_code_met_lng_extn add constraint pc_quick_code_met_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_risk_template_dtl') and constid = object_id('pc_risk_template_dtl_pkey'))
begin
	alter table pc_risk_template_dtl add constraint pc_risk_template_dtl_pkey primary key clustered (customer_name, project_name, template_id, risk_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_risk_template_hdr') and constid = object_id('pc_risk_template_hdr_pkey'))
begin
	alter table pc_risk_template_hdr add constraint pc_risk_template_hdr_pkey primary key clustered (customer_name, project_name, template_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_sol_center_met') and constid = object_id('pc_sol_center_met_pkey'))
begin
	alter table pc_sol_center_met add constraint pc_sol_center_met_pkey primary key clustered (sol_center_code, sol_center_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_sys_workprd_type_met') and constid = object_id('pc_sys_workprd_type_met_pkey'))
begin
	alter table pc_sys_workprd_type_met add constraint pc_sys_workprd_type_met_pkey primary key clustered (workproduct_type, parent_workproduct_type, applicable_level)
end

if not exists (select 'x' from sysconstraints where id = object_id('pc_wbs_mst') and constid = object_id('pc_wbs_mst_pkey'))
begin
	alter table pc_wbs_mst add constraint pc_wbs_mst_pkey primary key clustered (customer_name, project_name, wbs_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('Platform_Initialize_Detail') and constid = object_id('Platform_Initialize_Detail_PK'))
begin
	alter table Platform_Initialize_Detail add constraint Platform_Initialize_Detail_PK primary key clustered (Process_name, existance)
end

if not exists (select 'x' from sysconstraints where id = object_id('Problem') and constid = object_id('Cust_idPK'))
begin
	alter table Problem add constraint Cust_idPK primary key clustered (Cust_id, Proj_id, Problem_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_action') and constid = object_id('re_action_pkey'))
begin
	alter table re_action add constraint re_action_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_action_lng_extn') and constid = object_id('re_action_lng_extn_pkey'))
begin
	alter table re_action_lng_extn add constraint re_action_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_action_reuse_info') and constid = object_id('re_action_reuse_info_pkey'))
begin
	alter table re_action_reuse_info add constraint re_action_reuse_info_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_seq, task_pattern)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_action_section_map') and constid = object_id('re_action_section_map_pkey'))
begin
	alter table re_action_section_map add constraint re_action_section_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, section_page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_business_rule') and constid = object_id('re_business_rule_pkey'))
begin
	alter table re_business_rule add constraint re_business_rule_pkey primary key clustered (customer_name, project_name, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_business_rule_lng_extn') and constid = object_id('re_business_rule_lng_extn_pkey'))
begin
	alter table re_business_rule_lng_extn add constraint re_business_rule_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, br_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_chart_header') and constid = object_id('re_chart_header_pkey'))
begin
	alter table re_chart_header add constraint re_chart_header_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_chart_sample_data') and constid = object_id('re_chart_sample_data_pkey'))
begin
	alter table re_chart_sample_data add constraint re_chart_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_chart_series') and constid = object_id('re_chart_series_pkey'))
begin
	alter table re_chart_series add constraint re_chart_series_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_contextual_links') and constid = object_id('re_contextual_links_PK'))
begin
	alter table re_contextual_links add constraint re_contextual_links_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_control_extensions') and constid = object_id('re_control_extensions_PK'))
begin
	alter table re_control_extensions add constraint re_control_extensions_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_custom_listedit') and constid = object_id('re_custom_listedit_PKey'))
begin
	alter table re_custom_listedit add constraint re_custom_listedit_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_date_highlight_control_map') and constid = object_id('re_date_highlight_control_map_PKey'))
begin
	alter table re_date_highlight_control_map add constraint re_date_highlight_control_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_action') and constid = object_id('PK_re_dwd_action'))
begin
	alter table re_dwd_action add constraint PK_re_dwd_action primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_seq, task_pattern, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_action_section_map') and constid = object_id('PK_re_dwd_action_section_map'))
begin
	alter table re_dwd_action_section_map add constraint PK_re_dwd_action_section_map primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, section_page_bt_synonym, section_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_enum_value') and constid = object_id('PK_re_dwd_enum_value'))
begin
	alter table re_dwd_enum_value add constraint PK_re_dwd_enum_value primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_flowbr') and constid = object_id('PK_re_dwd_flowbr'))
begin
	alter table re_dwd_flowbr add constraint PK_re_dwd_flowbr primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, flowbr_sequence, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_flowbr_br_error') and constid = object_id('PK_re_dwd_flowbr_br_error'))
begin
	alter table re_dwd_flowbr_br_error add constraint PK_re_dwd_flowbr_br_error primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_flowbr_combo') and constid = object_id('PK_re_dwd_flowbr_combo'))
begin
	alter table re_dwd_flowbr_combo add constraint PK_re_dwd_flowbr_combo primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_flowbr_rule_map') and constid = object_id('PK_re_dwd_flowbr_rule_map'))
begin
	alter table re_dwd_flowbr_rule_map add constraint PK_re_dwd_flowbr_rule_map primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, br_name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_publication_dataitem') and constid = object_id('PK_re_dwd_publication_dataitem'))
begin
	alter table re_dwd_publication_dataitem add constraint PK_re_dwd_publication_dataitem primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, published_bt_synonym, published_flow_direction, dataitemname, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_radio_button') and constid = object_id('PK_re_dwd_radio_button'))
begin
	alter table re_dwd_radio_button add constraint PK_re_dwd_radio_button primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_resolved_link') and constid = object_id('PK_re_dwd_resolved_link'))
begin
	alter table re_dwd_resolved_link add constraint PK_re_dwd_resolved_link primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, publication_comp_name, publication_act_name, publication_ui_name, publication_name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_resolved_link_dataitem') and constid = object_id('PK_re_dwd_resolved_link_dataitem'))
begin
	alter table re_dwd_resolved_link_dataitem add constraint PK_re_dwd_resolved_link_dataitem primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, subscription_name, subscribed_bt_synonym, publication_comp_name, publication_act_name, publication_ui_name, publication_name, published_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_subscription') and constid = object_id('PK_re_dwd_subscription'))
begin
	alter table re_dwd_subscription add constraint PK_re_dwd_subscription primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, page_bt_synonym, subscription_descr, control_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_subscription_dataitem') and constid = object_id('PK_re_dwd_subscription_dataitem'))
begin
	alter table re_dwd_subscription_dataitem add constraint PK_re_dwd_subscription_dataitem primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, subscribed_bt_synonym, page_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_control') and constid = object_id('PK_re_dwd_ui_control'))
begin
	alter table re_dwd_ui_control add constraint PK_re_dwd_ui_control primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_ecr') and constid = object_id('PK_re_dwd_ui_ecr'))
begin
	alter table re_dwd_ui_ecr add constraint PK_re_dwd_ui_ecr primary key clustered (customer_name, project_name, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_grid') and constid = object_id('PK_re_dwd_ui_grid'))
begin
	alter table re_dwd_ui_grid add constraint PK_re_dwd_ui_grid primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, column_type, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_page') and constid = object_id('PK_re_dwd_ui_page'))
begin
	alter table re_dwd_ui_page add constraint PK_re_dwd_ui_page primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_section') and constid = object_id('PK_re_dwd_ui_section'))
begin
	alter table re_dwd_ui_section add constraint PK_re_dwd_ui_section primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_dwd_ui_traversal') and constid = object_id('PK_re_dwd_ui_traversal'))
begin
	alter table re_dwd_ui_traversal add constraint PK_re_dwd_ui_traversal primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_enum_value') and constid = object_id('re_enum_value_pkey'))
begin
	alter table re_enum_value add constraint re_enum_value_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_enum_value_lng_extn') and constid = object_id('re_enum_value_lng_extn_pkey'))
begin
	alter table re_enum_value_lng_extn add constraint re_enum_value_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, enum_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ext_js_control') and constid = object_id('re_ext_js_control_PK'))
begin
	alter table re_ext_js_control add constraint re_ext_js_control_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ext_js_section') and constid = object_id('re_ext_js_section_PK'))
begin
	alter table re_ext_js_section add constraint re_ext_js_section_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ext_js_section_column') and constid = object_id('re_ext_js_section_column_PK'))
begin
	alter table re_ext_js_section_column add constraint re_ext_js_section_column_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezeeview_sp') and constid = object_id('re_ezeeview_sp_PK'))
begin
	alter table re_ezeeview_sp add constraint re_ezeeview_sp_PK primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezeeview_spparamlist') and constid = object_id('re_ezeeview_spparamlist_pk'))
begin
	alter table re_ezeeview_spparamlist add constraint re_ezeeview_spparamlist_pk primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, Link_ControlName, control_page_name, Mapped_Control)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_res_ilbo_dataitem') and constid = object_id('re_ezwiz_res_ilbo_dataitem_pk'))
begin
	alter table re_ezwiz_res_ilbo_dataitem add constraint re_ezwiz_res_ilbo_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno, parent_ilbo_name, child_ilbo_name, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_res_step_dataitem') and constid = object_id('re_ezwiz_res_step_dataitem_pk'))
begin
	alter table re_ezwiz_res_step_dataitem add constraint re_ezwiz_res_step_dataitem_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, parent_step_seqno, child_step_seqno, parent_bt_synonym, child_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_wizard') and constid = object_id('re_ezwiz_wizard_pk'))
begin
	alter table re_ezwiz_wizard add constraint re_ezwiz_wizard_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_wizard_local_info') and constid = object_id('re_ezwiz_wizard_local_info_pk'))
begin
	alter table re_ezwiz_wizard_local_info add constraint re_ezwiz_wizard_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_wizard_step') and constid = object_id('re_ezwiz_wizard_step_pk'))
begin
	alter table re_ezwiz_wizard_step add constraint re_ezwiz_wizard_step_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ezwiz_wizard_step_local_info') and constid = object_id('re_ezwiz_wizard_step_local_info_pk'))
begin
	alter table re_ezwiz_wizard_step_local_info add constraint re_ezwiz_wizard_step_local_info_pk primary key clustered (customer_name, project_name, process_name, component_name, wizard_name, step_seqno, lang_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr') and constid = object_id('re_flowbr_pkey'))
begin
	alter table re_flowbr add constraint re_flowbr_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr_br_error') and constid = object_id('re_flowbr_br_error_pkey'))
begin
	alter table re_flowbr_br_error add constraint re_flowbr_br_error_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr_br_error_lng_extn') and constid = object_id('re_flowbr_br_error_lng_extn_pkey'))
begin
	alter table re_flowbr_br_error_lng_extn add constraint re_flowbr_br_error_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr_combo') and constid = object_id('re_flowbr_combo_pkey'))
begin
	alter table re_flowbr_combo add constraint re_flowbr_combo_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr_lng_extn') and constid = object_id('re_flowbr_lng_extn_pkey'))
begin
	alter table re_flowbr_lng_extn add constraint re_flowbr_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_flowbr_rule_map') and constid = object_id('re_flowbr_rule_map_pkey'))
begin
	alter table re_flowbr_rule_map add constraint re_flowbr_rule_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_glossary') and constid = object_id('re_glossary_pkey'))
begin
	alter table re_glossary add constraint re_glossary_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_glossary_lng_extn') and constid = object_id('re_glossary_lng_extn_pkey'))
begin
	alter table re_glossary_lng_extn add constraint re_glossary_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_listedit_column') and constid = object_id('re_listedit_column_PKey'))
begin
	alter table re_listedit_column add constraint re_listedit_column_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_listedit_control_map') and constid = object_id('re_listedit_control_map_PKey'))
begin
	alter table re_listedit_control_map add constraint re_listedit_control_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_message') and constid = object_id('re_message_pkey'))
begin
	alter table re_message add constraint re_message_pkey primary key clustered (customer_name, project_name, process_name, component_name, error_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_message_lng_extn') and constid = object_id('re_message_lng_extn_pkey'))
begin
	alter table re_message_lng_extn add constraint re_message_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, error_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_nativeapp_mapping') and constid = object_id('re_nativeapp_mapping_PK'))
begin
	alter table re_nativeapp_mapping add constraint re_nativeapp_mapping_PK primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_non_ui_control') and constid = object_id('re_non_ui_control_pkey'))
begin
	alter table re_non_ui_control add constraint re_non_ui_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone') and constid = object_id('re_phone_pkey'))
begin
	alter table re_phone add constraint re_phone_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_column_group_mapping') and constid = object_id('re_phone_column_group_mapping_pkey'))
begin
	alter table re_phone_column_group_mapping add constraint re_phone_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_columngroup') and constid = object_id('re_phone_columngroup_pkey'))
begin
	alter table re_phone_columngroup add constraint re_phone_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_control') and constid = object_id('re_phone_control_pkey'))
begin
	alter table re_phone_control add constraint re_phone_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_grid') and constid = object_id('re_phone_grid_pkey'))
begin
	alter table re_phone_grid add constraint re_phone_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_grid_columngroup') and constid = object_id('re_phone_grid_columngroup_pkey'))
begin
	alter table re_phone_grid_columngroup add constraint re_phone_grid_columngroup_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_page') and constid = object_id('re_phone_page_pkey'))
begin
	alter table re_phone_page add constraint re_phone_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_phone_section') and constid = object_id('re_phone_section_pkey'))
begin
	alter table re_phone_section add constraint re_phone_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_pivot_configure') and constid = object_id('re_pivot_configure_pkey'))
begin
	alter table re_pivot_configure add constraint re_pivot_configure_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_pivot_fields') and constid = object_id('re_pivot_fields_pkey'))
begin
	alter table re_pivot_fields add constraint re_pivot_fields_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_pivot_lang_extn') and constid = object_id('re_pivot_lang_extn_pkey'))
begin
	alter table re_pivot_lang_extn add constraint re_pivot_lang_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_name, Control_bt_synonym, DisplayField, Languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_publication') and constid = object_id('re_publication_pkey'))
begin
	alter table re_publication add constraint re_publication_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_publication_dataitem') and constid = object_id('re_publication_dataitem_pkey'))
begin
	alter table re_publication_dataitem add constraint re_publication_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_publication_lng_extn') and constid = object_id('re_publication_lng_extn_pkey'))
begin
	alter table re_publication_lng_extn add constraint re_publication_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, publication_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_quick_code_mst') and constid = object_id('re_quick_code_mst_pkey'))
begin
	alter table re_quick_code_mst add constraint re_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_quick_code_mst_lng_extn') and constid = object_id('re_quick_code_mst_lng_extn_pkey'))
begin
	alter table re_quick_code_mst_lng_extn add constraint re_quick_code_mst_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_radio_button') and constid = object_id('re_radio_button_pkey'))
begin
	alter table re_radio_button add constraint re_radio_button_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_radio_button_lng_extn') and constid = object_id('re_radio_button_lng_extn_pkey'))
begin
	alter table re_radio_button_lng_extn add constraint re_radio_button_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, button_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_report_action_dataset') and constid = object_id('re_report_action_dataset_pkey'))
begin
	alter table re_report_action_dataset add constraint re_report_action_dataset_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, action_name, dataset_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_resolved_link') and constid = object_id('re_resolved_link_pkey'))
begin
	alter table re_resolved_link add constraint re_resolved_link_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, publication_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_resolved_link_dataitem') and constid = object_id('re_resolved_link_dataitem_pkey'))
begin
	alter table re_resolved_link_dataitem add constraint re_resolved_link_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, subscription_name, subscribed_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_resolved_link_dataitem_mr_pop') and constid = object_id('re_resolved_link_dataitem_mr_pop_pkey'))
begin
	alter table re_resolved_link_dataitem_mr_pop add constraint re_resolved_link_dataitem_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, activity_name, ui_name, page_bt_synonym, publication_name, dataitemname, subscription_name, subscribed_bt_synonym, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_resolved_link_mr_pop') and constid = object_id('re_resolved_link_mr_pop_pkey'))
begin
	alter table re_resolved_link_mr_pop add constraint re_resolved_link_mr_pop_pkey primary key clustered (Customer_Name, Project_Name, process_name, component_name, activity_name, ui_name, subscription_name, publication_name, mig_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_resolvelist_data_map') and constid = object_id('re_resolvelist_data_map_PKey'))
begin
	alter table re_resolvelist_data_map add constraint re_resolvelist_data_map_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, mapped_bt_syn_page, mapped_bt_synonym, listedit_synonym, listedit_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rmt_ecr_ui') and constid = object_id('re_rmt_ecr_ui_pkey'))
begin
	alter table re_rmt_ecr_ui add constraint re_rmt_ecr_ui_pkey primary key clustered (customer_name, project_name, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rulegroup') and constid = object_id('re_rulegroup_pkey'))
begin
	alter table re_rulegroup add constraint re_rulegroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rulegroup_lng_extn') and constid = object_id('re_rulegroup_lng_extn_pkey'))
begin
	alter table re_rulegroup_lng_extn add constraint re_rulegroup_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rulegroup_step') and constid = object_id('re_rulegroup_step_pkey'))
begin
	alter table re_rulegroup_step add constraint re_rulegroup_step_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rulegroup_step_msg') and constid = object_id('re_rulegroup_step_msg_pkey'))
begin
	alter table re_rulegroup_step_msg add constraint re_rulegroup_step_msg_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_rulegroup_step_msg_lng_extn') and constid = object_id('re_rulegroup_step_msg_lng_extn_pkey'))
begin
	alter table re_rulegroup_step_msg_lng_extn add constraint re_rulegroup_step_msg_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_subscription') and constid = object_id('re_subscription_pkey'))
begin
	alter table re_subscription add constraint re_subscription_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_subscription_dataitem') and constid = object_id('re_subscription_dataitem_pkey'))
begin
	alter table re_subscription_dataitem add constraint re_subscription_dataitem_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, subscribed_bt_synonym, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_subscription_lng_extn') and constid = object_id('re_subscription_lng_extn_pkey'))
begin
	alter table re_subscription_lng_extn add constraint re_subscription_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, subscription_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_sync_view') and constid = object_id('re_sync_view_pkey'))
begin
	alter table re_sync_view add constraint re_sync_view_pkey primary key clustered (Customer_name, Project_name, process_name, component_name, activity_name, ui_name, map_le_controlid, legrid_view_name, map_le_column_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet') and constid = object_id('re_tablet_pkey'))
begin
	alter table re_tablet add constraint re_tablet_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_column_group_mapping') and constid = object_id('re_tablet_column_group_mapping_pkey'))
begin
	alter table re_tablet_column_group_mapping add constraint re_tablet_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_columngroup') and constid = object_id('re_tablet_columngroup_pkey'))
begin
	alter table re_tablet_columngroup add constraint re_tablet_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_control') and constid = object_id('re_tablet_control_pkey'))
begin
	alter table re_tablet_control add constraint re_tablet_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_grid') and constid = object_id('re_tablet_grid_pkey'))
begin
	alter table re_tablet_grid add constraint re_tablet_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_grid_columngroup') and constid = object_id('re_tablet_grid_columngroup_pkey'))
begin
	alter table re_tablet_grid_columngroup add constraint re_tablet_grid_columngroup_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_page') and constid = object_id('re_tablet_page_pkey'))
begin
	alter table re_tablet_page add constraint re_tablet_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tablet_section') and constid = object_id('re_tablet_section_pkey'))
begin
	alter table re_tablet_section add constraint re_tablet_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_Templates') and constid = object_id('re_Templates_pk'))
begin
	alter table re_Templates add constraint re_Templates_pk primary key clustered (customer_name, project_name, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tree_dtl') and constid = object_id('re_tree_dtl_pkey'))
begin
	alter table re_tree_dtl add constraint re_tree_dtl_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tree_sample_data') and constid = object_id('re_tree_sample_data_pkey'))
begin
	alter table re_tree_sample_data add constraint re_tree_sample_data_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, Node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_tree_sample_data_map') and constid = object_id('re_tree_sample_data_map_pkey'))
begin
	alter table re_tree_sample_data_map add constraint re_tree_sample_data_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui') and constid = object_id('re_ui_pkey'))
begin
	alter table re_ui add constraint re_ui_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_column_group_mapping') and constid = object_id('re_ui_column_group_mapping_pkey'))
begin
	alter table re_ui_column_group_mapping add constraint re_ui_column_group_mapping_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_columngroup') and constid = object_id('re_ui_columngroup_pkey'))
begin
	alter table re_ui_columngroup add constraint re_ui_columngroup_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_combolink') and constid = object_id('re_ui_combolink_pkey'))
begin
	alter table re_ui_combolink add constraint re_ui_combolink_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, Combo_control_bt_synonym, link_control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_contextmenu_task_dtl') and constid = object_id('re_ui_contextmenu_task_dtl_pk'))
begin
	alter table re_ui_contextmenu_task_dtl add constraint re_ui_contextmenu_task_dtl_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, task_name, rcn_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_control') and constid = object_id('re_ui_control_pkey'))
begin
	alter table re_ui_control add constraint re_ui_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_control_lng_extn') and constid = object_id('re_ui_control_lng_extn_pkey'))
begin
	alter table re_ui_control_lng_extn add constraint re_ui_control_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_device') and constid = object_id('re_ui_device_pkey'))
begin
	alter table re_ui_device add constraint re_ui_device_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_device_control') and constid = object_id('re_ui_device_control_pkey'))
begin
	alter table re_ui_device_control add constraint re_ui_device_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_device_grid') and constid = object_id('re_ui_device_grid_pkey'))
begin
	alter table re_ui_device_grid add constraint re_ui_device_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_device_page') and constid = object_id('re_ui_device_page_pkey'))
begin
	alter table re_ui_device_page add constraint re_ui_device_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_device_section') and constid = object_id('re_ui_device_section_pkey'))
begin
	alter table re_ui_device_section add constraint re_ui_device_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, attributename)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_displaytext_lang_extn') and constid = object_id('re_ui_displaytext_lang_extn_PKey'))
begin
	alter table re_ui_displaytext_lang_extn add constraint re_ui_displaytext_lang_extn_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_task_name, lang_id, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_ecr') and constid = object_id('re_ui_ecr_pkey'))
begin
	alter table re_ui_ecr add constraint re_ui_ecr_pkey primary key clustered (customer_name, project_name, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_grid') and constid = object_id('re_ui_grid_pkey'))
begin
	alter table re_ui_grid add constraint re_ui_grid_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_grid_columngroup') and constid = object_id('re_ui_grid_columngroup_pkey'))
begin
	alter table re_ui_grid_columngroup add constraint re_ui_grid_columngroup_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, Page_bt_synonym, section_bt_synonym, grid_control_bt_synonym, Group_name, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_grid_lng_extn') and constid = object_id('re_ui_grid_lng_extn_pkey'))
begin
	alter table re_ui_grid_lng_extn add constraint re_ui_grid_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_page') and constid = object_id('re_ui_page_pkey'))
begin
	alter table re_ui_page add constraint re_ui_page_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_page_lng_extn') and constid = object_id('re_ui_page_lng_extn_pkey'))
begin
	alter table re_ui_page_lng_extn add constraint re_ui_page_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_pageevents') and constid = object_id('re_ui_pageevents_pk'))
begin
	alter table re_ui_pageevents add constraint re_ui_pageevents_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_placeholder_lng_extn') and constid = object_id('re_ui_placeholder_lng_extn_pk'))
begin
	alter table re_ui_placeholder_lng_extn add constraint re_ui_placeholder_lng_extn_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, control_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_section') and constid = object_id('re_ui_section_pkey'))
begin
	alter table re_ui_section add constraint re_ui_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_section_control_map') and constid = object_id('re_ui_section_control_map_pkey'))
begin
	alter table re_ui_section_control_map add constraint re_ui_section_control_map_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_section_lng_extn') and constid = object_id('re_ui_section_lng_extn_pkey'))
begin
	alter table re_ui_section_lng_extn add constraint re_ui_section_lng_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state') and constid = object_id('re_ui_state_pkey'))
begin
	alter table re_ui_state add constraint re_ui_state_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_column') and constid = object_id('re_ui_state_column_PK'))
begin
	alter table re_ui_state_column add constraint re_ui_state_column_PK primary key clustered (customer_name, project_name, rcn_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_control') and constid = object_id('re_ui_state_control_pkey'))
begin
	alter table re_ui_state_control add constraint re_ui_state_control_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_page') and constid = object_id('re_ui_state_page_PK'))
begin
	alter table re_ui_state_page add constraint re_ui_state_page_PK primary key clustered (customer_name, project_name, rcn_no, process_name, component_name, activity_name, ui_name, state_id, page_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_section') and constid = object_id('re_ui_state_section_pkey'))
begin
	alter table re_ui_state_section add constraint re_ui_state_section_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_task') and constid = object_id('re_ui_state_task_pkey'))
begin
	alter table re_ui_state_task add constraint re_ui_state_task_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_state_task_mst') and constid = object_id('re_ui_state_task_mst_pkey'))
begin
	alter table re_ui_state_task_mst add constraint re_ui_state_task_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, state_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_Temp_placeholders') and constid = object_id('re_ui_Temp_placeholders_pk'))
begin
	alter table re_ui_Temp_placeholders add constraint re_ui_Temp_placeholders_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid, placeholder)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_template_controlmap') and constid = object_id('re_ui_template_controlmap_pk'))
begin
	alter table re_ui_template_controlmap add constraint re_ui_template_controlmap_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, templateid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_toolbar') and constid = object_id('re_ui_toolbar_PKey'))
begin
	alter table re_ui_toolbar add constraint re_ui_toolbar_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_name, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_toolbar_group') and constid = object_id('re_ui_toolbar_group_PKey'))
begin
	alter table re_ui_toolbar_group add constraint re_ui_toolbar_group_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, group_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_toolbar_mapping') and constid = object_id('re_ui_toolbar_mapping_PKey'))
begin
	alter table re_ui_toolbar_mapping add constraint re_ui_toolbar_mapping_PKey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_tooltip_lng_extn') and constid = object_id('re_ui_tooltip_lng_extn_pk'))
begin
	alter table re_ui_tooltip_lng_extn add constraint re_ui_tooltip_lng_extn_pk primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, column_bt_synonym, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_ui_traversal') and constid = object_id('re_ui_traversal_pkey'))
begin
	alter table re_ui_traversal add constraint re_ui_traversal_pkey primary key clustered (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, link_type, trvsl_seq)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_user_section') and constid = object_id('re_user_section_pkey'))
begin
	alter table re_user_section add constraint re_user_section_pkey primary key clustered (customer_name, project_name, rcnno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, type, languageid, include_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_appvw_dtl') and constid = object_id('pk_re_wsinp_appvw_dtl'))
begin
	alter table re_wsinp_appvw_dtl add constraint pk_re_wsinp_appvw_dtl primary key clustered (customer_code, project_code, area_code, notification_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_area_desc') and constid = object_id('pk_re_wsinp_area_desc'))
begin
	alter table re_wsinp_area_desc add constraint pk_re_wsinp_area_desc primary key clustered (customer_code, project_code, area_code, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_area_dtl') and constid = object_id('pk_re_wsinp_area_dtl'))
begin
	alter table re_wsinp_area_dtl add constraint pk_re_wsinp_area_dtl primary key clustered (customer_code, project_code, area_code, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_area_hdr') and constid = object_id('pk_re_wsinp_area_hdr'))
begin
	alter table re_wsinp_area_hdr add constraint pk_re_wsinp_area_hdr primary key clustered (customer_code, project_code, area_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_cat_desc_hdr') and constid = object_id('pk_re_wsinp_cat_desc_hdr'))
begin
	alter table re_wsinp_cat_desc_hdr add constraint pk_re_wsinp_cat_desc_hdr primary key clustered (customer_code, project_code, area_code, cat_key, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_cat_hdr') and constid = object_id('pk_re_wsinp_cat_hdr'))
begin
	alter table re_wsinp_cat_hdr add constraint pk_re_wsinp_cat_hdr primary key clustered (customer_code, project_code, area_code, cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_cat_parameters') and constid = object_id('pk_re_wsinp_cat_parameters'))
begin
	alter table re_wsinp_cat_parameters add constraint pk_re_wsinp_cat_parameters primary key clustered (customer_code, project_code, area_code, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_con_security') and constid = object_id('pk_re_wsinp_con_security'))
begin
	alter table re_wsinp_con_security add constraint pk_re_wsinp_con_security primary key clustered (consider_security, customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_def_msg_dtl') and constid = object_id('pk_re_wsinp_def_msg_dtl'))
begin
	alter table re_wsinp_def_msg_dtl add constraint pk_re_wsinp_def_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, notification_type, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_def_wf_setup') and constid = object_id('pk_re_wsinp_def_wf_setup'))
begin
	alter table re_wsinp_def_wf_setup add constraint pk_re_wsinp_def_wf_setup primary key clustered (customer_code, project_code, area_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_doc_flow_dtl') and constid = object_id('pk_re_wsinp_doc_flow_dtl'))
begin
	alter table re_wsinp_doc_flow_dtl add constraint pk_re_wsinp_doc_flow_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_docflow_msg_dtl') and constid = object_id('pk_re_wsinp_docflow_msg_dtl'))
begin
	alter table re_wsinp_docflow_msg_dtl add constraint pk_re_wsinp_docflow_msg_dtl primary key clustered (customer_code, project_code, area_code, cat_key, to_cat_key, notification_type, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_actcode') and constid = object_id('pk_re_wsinp_nonrvw_actcode'))
begin
	alter table re_wsinp_nonrvw_actcode add constraint pk_re_wsinp_nonrvw_actcode primary key clustered (customer_code, project_code, component_name, activity_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_actdesc') and constid = object_id('pk_re_wsinp_nonrvw_actdesc'))
begin
	alter table re_wsinp_nonrvw_actdesc add constraint pk_re_wsinp_nonrvw_actdesc primary key clustered (customer_code, project_code, component_name, activity_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_compcode') and constid = object_id('pk_re_wsinp_nonrvw_compcode'))
begin
	alter table re_wsinp_nonrvw_compcode add constraint pk_re_wsinp_nonrvw_compcode primary key clustered (customer_code, project_code, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_compdesc') and constid = object_id('pk_re_wsinp_nonrvw_compdesc'))
begin
	alter table re_wsinp_nonrvw_compdesc add constraint pk_re_wsinp_nonrvw_compdesc primary key clustered (customer_code, project_code, component_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_taskcode') and constid = object_id('pk_re_wsinp_nonrvw_taskcode'))
begin
	alter table re_wsinp_nonrvw_taskcode add constraint pk_re_wsinp_nonrvw_taskcode primary key clustered (customer_code, project_code, component_name, activity_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_nonrvw_taskdesc') and constid = object_id('pk_re_wsinp_nonrvw_taskdesc'))
begin
	alter table re_wsinp_nonrvw_taskdesc add constraint pk_re_wsinp_nonrvw_taskdesc primary key clustered (customer_code, project_code, component_name, activity_name, task_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_qc_dtl') and constid = object_id('pk_re_wsinp_qc_dtl'))
begin
	alter table re_wsinp_qc_dtl add constraint pk_re_wsinp_qc_dtl primary key clustered (wf_quick_code, wf_quick_code_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_qc_hdr') and constid = object_id('pk_re_wsinp_qc_hdr'))
begin
	alter table re_wsinp_qc_hdr add constraint pk_re_wsinp_qc_hdr primary key clustered (wf_quick_code_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_qc_lang_dtl') and constid = object_id('pk_re_wsinp_qc_lang_dtl'))
begin
	alter table re_wsinp_qc_lang_dtl add constraint pk_re_wsinp_qc_lang_dtl primary key clustered (wf_quick_code_type, wf_quick_code, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_rcn_dtl') and constid = object_id('pk_re_wsinp_rcn_dtl'))
begin
	alter table re_wsinp_rcn_dtl add constraint pk_re_wsinp_rcn_dtl primary key clustered (customer_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_security_dtl') and constid = object_id('pk_re_wsinp_security_dtl'))
begin
	alter table re_wsinp_security_dtl add constraint pk_re_wsinp_security_dtl primary key clustered (customer_code, project_code, permitted_user, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_secusr_dtl') and constid = object_id('pk_re_wsinp_secusr_dtl'))
begin
	alter table re_wsinp_secusr_dtl add constraint pk_re_wsinp_secusr_dtl primary key clustered (customer_code, project_code, permitted_user)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_service_dtl') and constid = object_id('pk_re_wsinp_service_dtl'))
begin
	alter table re_wsinp_service_dtl add constraint pk_re_wsinp_service_dtl primary key clustered (customer_code, project_code, area_code, cat_key, sequence_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_state_desc_dtl') and constid = object_id('pk_re_wsinp_state_desc_dtl'))
begin
	alter table re_wsinp_state_desc_dtl add constraint pk_re_wsinp_state_desc_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, language_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_task_dtl') and constid = object_id('pk_re_wsinp_task_dtl'))
begin
	alter table re_wsinp_task_dtl add constraint pk_re_wsinp_task_dtl primary key clustered (customer_code, project_code, area_code, cat_key)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_tsk_state_dtl') and constid = object_id('pk_re_wsinp_tsk_state_dtl'))
begin
	alter table re_wsinp_tsk_state_dtl add constraint pk_re_wsinp_tsk_state_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_tsk_stflow_dtl') and constid = object_id('pk_re_wsinp_tsk_stflow_dtl'))
begin
	alter table re_wsinp_tsk_stflow_dtl add constraint pk_re_wsinp_tsk_stflow_dtl primary key clustered (customer_code, project_code, area_code, cat_key, state_name, to_cat_key, to_state)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_wsinp_usr_noncon_task') and constid = object_id('pk_re_wsinp_usr_noncon_task'))
begin
	alter table re_wsinp_usr_noncon_task add constraint pk_re_wsinp_usr_noncon_task primary key clustered (customer_code, project_code, area_code, cat_key, calling_catkey)
end

if not exists (select 'x' from sysconstraints where id = object_id('REN_CGConfig') and constid = object_id('PK_REN_CGConfig'))
begin
	alter table REN_CGConfig add constraint PK_REN_CGConfig primary key clustered (CustomerID, ProjectID, CGen_code_type, CGen_code_subtype, CGen_code_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('REN_Temp_UI') and constid = object_id('PK_REN_Temp_UI'))
begin
	alter table REN_Temp_UI add constraint PK_REN_Temp_UI primary key clustered (GUID, UIName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Apkg_Ssafe_Dtl') and constid = object_id('Rev_Eng_Apkg_Ssafe_Dtl_Pkey'))
begin
	alter table Rev_Eng_Apkg_Ssafe_Dtl add constraint Rev_Eng_Apkg_Ssafe_Dtl_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ReleaseVersion, DocumentID, SsafePath, UserName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_business_rule') and constid = object_id('Rev_Eng_de_business_rule_Pkey'))
begin
	alter table Rev_Eng_de_business_rule add constraint Rev_Eng_de_business_rule_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_flowbr') and constid = object_id('Rev_Eng_de_flowbr_Pkey'))
begin
	alter table Rev_Eng_de_flowbr add constraint Rev_Eng_de_flowbr_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_flowbr_br_error') and constid = object_id('Rev_Eng_de_flowbr_br_error_Pkey'))
begin
	alter table Rev_Eng_de_flowbr_br_error add constraint Rev_Eng_de_flowbr_br_error_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_flowbr_combo') and constid = object_id('Rev_Eng_de_flowbr_combo_Pkey'))
begin
	alter table Rev_Eng_de_flowbr_combo add constraint Rev_Eng_de_flowbr_combo_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_flowbr_method_map') and constid = object_id('Rev_Eng_de_flowbr_method_map_Pkey'))
begin
	alter table Rev_Eng_de_flowbr_method_map add constraint Rev_Eng_de_flowbr_method_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_flowbr_rule_map') and constid = object_id('Rev_Eng_de_flowbr_rule_map_Pkey'))
begin
	alter table Rev_Eng_de_flowbr_rule_map add constraint Rev_Eng_de_flowbr_rule_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_des_bro') and constid = object_id('Rev_Eng_de_fw_des_bro_Pkey'))
begin
	alter table Rev_Eng_de_fw_des_bro add constraint Rev_Eng_de_fw_des_bro_Pkey primary key clustered (Mig_id, customer_name, broname, componentname, project_name, process_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_des_businessrule') and constid = object_id('Rev_Eng_de_fw_des_businessrule_Pkey'))
begin
	alter table Rev_Eng_de_fw_des_businessrule add constraint Rev_Eng_de_fw_des_businessrule_Pkey primary key clustered (Mig_id, customer_name, methodid, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_des_ilbo_actions') and constid = object_id('Rev_Eng_de_fw_des_ilbo_actions_Pkey'))
begin
	alter table Rev_Eng_de_fw_des_ilbo_actions add constraint Rev_Eng_de_fw_des_ilbo_actions_Pkey primary key clustered (Mig_id, ilbocode, groupcode, actionsequence)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_des_processsection_br_is') and constid = object_id('Rev_Eng_de_fw_des_processsection_br_is_Pkey'))
begin
	alter table Rev_Eng_de_fw_des_processsection_br_is add constraint Rev_Eng_de_fw_des_processsection_br_is_Pkey primary key clustered (Mig_id, customer_name, servicename, sectionname, sequenceno, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_des_reqbr_desbr') and constid = object_id('Rev_Eng_de_fw_des_reqbr_desbr_Pkey'))
begin
	alter table Rev_Eng_de_fw_des_reqbr_desbr add constraint Rev_Eng_de_fw_des_reqbr_desbr_Pkey primary key clustered (Mig_id, customer_name, reqbrname, methodid, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_br_bterm') and constid = object_id('Rev_Eng_de_fw_req_br_bterm_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_br_bterm add constraint Rev_Eng_de_fw_req_br_bterm_Pkey primary key clustered (Mig_id, customer_name, brname, paramno, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_br_documentation') and constid = object_id('Rev_Eng_de_fw_req_br_documentation_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_br_documentation add constraint Rev_Eng_de_fw_req_br_documentation_Pkey primary key clustered (Mig_id, customer_name, brname, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_br_error') and constid = object_id('Rev_Eng_de_fw_req_br_error_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_br_error add constraint Rev_Eng_de_fw_req_br_error_Pkey primary key clustered (Mig_id, customer_name, brname, errorcode, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_br_error_placeholder') and constid = object_id('Rev_Eng_de_fw_req_br_error_placeholder_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_br_error_placeholder add constraint Rev_Eng_de_fw_req_br_error_placeholder_Pkey primary key clustered (Mig_id, customer_name, taskname, brsequence, brname, errorcode, placeholdersequence, paramno, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_businessrule') and constid = object_id('Rev_Eng_de_fw_req_businessrule_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_businessrule add constraint Rev_Eng_de_fw_req_businessrule_Pkey primary key clustered (Mig_id, customer_name, brname, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_state_activity') and constid = object_id('Rev_Eng_de_fw_req_state_activity_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_state_activity add constraint Rev_Eng_de_fw_req_state_activity_Pkey primary key clustered (Mig_id, customer_name, statename, activityid, brname, componentname, project_name, process_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_state_component') and constid = object_id('Rev_Eng_de_fw_req_state_component_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_state_component add constraint Rev_Eng_de_fw_req_state_component_Pkey primary key clustered (Mig_id, customer_name, statename, componentname, vcname, brname, project_name, process_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_task_br_error_context') and constid = object_id('Rev_Eng_de_fw_req_task_br_error_context_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_task_br_error_context add constraint Rev_Eng_de_fw_req_task_br_error_context_Pkey primary key clustered (Mig_id, customer_name, taskname, brsequence, brname, errorcode, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_task_rule') and constid = object_id('Rev_Eng_de_fw_req_task_rule_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_task_rule add constraint Rev_Eng_de_fw_req_task_rule_Pkey primary key clustered (Mig_id, customer_name, taskname, brsequence, brname, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_fw_req_taskrulesynonym_map') and constid = object_id('Rev_Eng_de_fw_req_taskrulesynonym_map_Pkey'))
begin
	alter table Rev_Eng_de_fw_req_taskrulesynonym_map add constraint Rev_Eng_de_fw_req_taskrulesynonym_map_Pkey primary key clustered (Mig_id, customer_name, taskname, brsequence, brname, paramno, project_name, process_name, component_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_method_doc') and constid = object_id('Rev_Eng_de_method_doc_Pkey'))
begin
	alter table Rev_Eng_de_method_doc add constraint Rev_Eng_de_method_doc_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_method_message_map') and constid = object_id('Rev_Eng_de_method_message_map_Pkey'))
begin
	alter table Rev_Eng_de_method_message_map add constraint Rev_Eng_de_method_message_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_refine_method_documentation') and constid = object_id('Rev_Eng_de_refine_method_documentation_Pkey'))
begin
	alter table Rev_Eng_de_refine_method_documentation add constraint Rev_Eng_de_refine_method_documentation_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, flowbr_name, method_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_refine_method_error_map') and constid = object_id('Rev_Eng_de_refine_method_error_map_Pkey'))
begin
	alter table Rev_Eng_de_refine_method_error_map add constraint Rev_Eng_de_refine_method_error_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, req_errorno, des_errorno, sp_errorno)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_refine_parameter') and constid = object_id('Rev_Eng_de_refine_parameter_Pkey'))
begin
	alter table Rev_Eng_de_refine_parameter add constraint Rev_Eng_de_refine_parameter_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, service_name, flowbr_name, method_name, parameter_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_rulegroup') and constid = object_id('Rev_Eng_de_rulegroup_Pkey'))
begin
	alter table Rev_Eng_de_rulegroup add constraint Rev_Eng_de_rulegroup_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_rulegroup_step') and constid = object_id('Rev_Eng_de_rulegroup_step_Pkey'))
begin
	alter table Rev_Eng_de_rulegroup_step add constraint Rev_Eng_de_rulegroup_step_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_rulegroup_step_msg') and constid = object_id('Rev_Eng_de_rulegroup_step_msg_Pkey'))
begin
	alter table Rev_Eng_de_rulegroup_step_msg add constraint Rev_Eng_de_rulegroup_step_msg_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_service_logic_extn_dtl') and constid = object_id('Rev_Eng_de_service_logic_extn_dtl_Pkey'))
begin
	alter table Rev_Eng_de_service_logic_extn_dtl add constraint Rev_Eng_de_service_logic_extn_dtl_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, ecr_no, servicename, section_name, methodid, methodname, BR_sequence, RDBMS_Type, ext_before)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_de_ui_ico') and constid = object_id('Rev_Eng_de_ui_ico_Pkey'))
begin
	alter table Rev_Eng_de_ui_ico add constraint Rev_Eng_de_ui_ico_Pkey primary key clustered (Mig_id, customer_name, project_name, ico_no, ecr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_em_scenario_function_wrk') and constid = object_id('Rev_Eng_em_scenario_function_wrk_Pkey'))
begin
	alter table Rev_Eng_em_scenario_function_wrk add constraint Rev_Eng_em_scenario_function_wrk_Pkey primary key clustered (Mig_id, Customerid, ProjectID, ScenarioID, NodeID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_component_glossary_mst') and constid = object_id('Rev_Eng_ep_component_glossary_mst_Pkey'))
begin
	alter table Rev_Eng_ep_component_glossary_mst add constraint Rev_Eng_ep_component_glossary_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_component_glossary_mst_lng_extn') and constid = object_id('Rev_Eng_ep_component_glossary_mst_lng_extn_Pkey'))
begin
	alter table Rev_Eng_ep_component_glossary_mst_lng_extn add constraint Rev_Eng_ep_component_glossary_mst_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, bt_synonym_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_deleted_task_dtl') and constid = object_id('Rev_Eng_ep_deleted_task_dtl_Pkey'))
begin
	alter table Rev_Eng_ep_deleted_task_dtl add constraint Rev_Eng_ep_deleted_task_dtl_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, task_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_flowbr_mst') and constid = object_id('Rev_Eng_ep_flowbr_mst_Pkey'))
begin
	alter table Rev_Eng_ep_flowbr_mst add constraint Rev_Eng_ep_flowbr_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_flowbr_mst_lng_extn') and constid = object_id('Rev_Eng_ep_flowbr_mst_lng_extn_Pkey'))
begin
	alter table Rev_Eng_ep_flowbr_mst_lng_extn add constraint Rev_Eng_ep_flowbr_mst_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_ep_ui_req_dtl') and constid = object_id('Rev_Eng_ep_ui_req_dtl_Pkey'))
begin
	alter table Rev_Eng_ep_ui_req_dtl add constraint Rev_Eng_ep_ui_req_dtl_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_ctrl_type_mst') and constid = object_id('Rev_Eng_es_comp_ctrl_type_mst_Pkey'))
begin
	alter table Rev_Eng_es_comp_ctrl_type_mst add constraint Rev_Eng_es_comp_ctrl_type_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_ctrl_type_mst_lng_extn') and constid = object_id('Rev_Eng_es_comp_ctrl_type_mst_lng_extn_Pkey'))
begin
	alter table Rev_Eng_es_comp_ctrl_type_mst_lng_extn add constraint Rev_Eng_es_comp_ctrl_type_mst_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, ctrl_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_hdn_ctrl_dtl') and constid = object_id('Rev_Eng_es_comp_hdn_ctrl_dtl_Pkey'))
begin
	alter table Rev_Eng_es_comp_hdn_ctrl_dtl add constraint Rev_Eng_es_comp_hdn_ctrl_dtl_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, bt_synonym_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_param_mst') and constid = object_id('Rev_Eng_es_comp_param_mst_Pkey'))
begin
	alter table Rev_Eng_es_comp_param_mst add constraint Rev_Eng_es_comp_param_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, param_category)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_param_mst_lng_extn') and constid = object_id('Rev_Eng_es_comp_param_mst_lng_extn_Pkey'))
begin
	alter table Rev_Eng_es_comp_param_mst_lng_extn add constraint Rev_Eng_es_comp_param_mst_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, param_category, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_stat_ctrl_type_mst') and constid = object_id('Rev_Eng_es_comp_stat_ctrl_type_mst_Pkey'))
begin
	alter table Rev_Eng_es_comp_stat_ctrl_type_mst add constraint Rev_Eng_es_comp_stat_ctrl_type_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_stylesheet') and constid = object_id('Rev_Eng_es_comp_stylesheet_Pkey'))
begin
	alter table Rev_Eng_es_comp_stylesheet add constraint Rev_Eng_es_comp_stylesheet_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, stylesheet_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_task_type_mst') and constid = object_id('Rev_Eng_es_comp_task_type_mst_Pkey'))
begin
	alter table Rev_Eng_es_comp_task_type_mst add constraint Rev_Eng_es_comp_task_type_mst_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, task_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_es_comp_task_type_mst_lng_extn') and constid = object_id('Rev_Eng_es_comp_task_type_mst_lng_extn_Pkey'))
begin
	alter table Rev_Eng_es_comp_task_type_mst_lng_extn add constraint Rev_Eng_es_comp_task_type_mst_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, req_no, process_name, component_name, task_type_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Activity') and constid = object_id('Rev_Eng_Fw_Bpt_Activity_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Activity add constraint Rev_Eng_Fw_Bpt_Activity_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Activity_UI') and constid = object_id('Rev_Eng_Fw_Bpt_Activity_UI_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Activity_UI add constraint Rev_Eng_Fw_Bpt_Activity_UI_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_AssociatedBRs') and constid = object_id('Rev_Eng_Fw_Bpt_AssociatedBRs_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_AssociatedBRs add constraint Rev_Eng_Fw_Bpt_AssociatedBRs_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_BR') and constid = object_id('Rev_Eng_Fw_Bpt_BR_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_BR add constraint Rev_Eng_Fw_Bpt_BR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_BR_Associate_Events') and constid = object_id('Rev_Eng_Fw_Bpt_BR_Associate_Events_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_BR_Associate_Events add constraint Rev_Eng_Fw_Bpt_BR_Associate_Events_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, EntEventName, ExtEventName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_BR_Events') and constid = object_id('Rev_Eng_Fw_Bpt_BR_Events_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_BR_Events add constraint Rev_Eng_Fw_Bpt_BR_Events_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, EventName, LangID, EventType, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_BR_Feature') and constid = object_id('Rev_Eng_Fw_Bpt_BR_Feature_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_BR_Feature add constraint Rev_Eng_Fw_Bpt_BR_Feature_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, FeatureID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Component') and constid = object_id('Rev_Eng_Fw_Bpt_Component_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Component add constraint Rev_Eng_Fw_Bpt_Component_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Function') and constid = object_id('Rev_Eng_Fw_Bpt_Function_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Function add constraint Rev_Eng_Fw_Bpt_Function_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Function_Component') and constid = object_id('Rev_Eng_Fw_Bpt_Function_Component_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Function_Component add constraint Rev_Eng_Fw_Bpt_Function_Component_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_LinkUI_Events') and constid = object_id('Rev_Eng_Fw_Bpt_LinkUI_Events_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_LinkUI_Events add constraint Rev_Eng_Fw_Bpt_LinkUI_Events_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, PageName, LinkName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Task') and constid = object_id('Rev_Eng_Fw_Bpt_Task_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Task add constraint Rev_Eng_Fw_Bpt_Task_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, TaskID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs') and constid = object_id('Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs add constraint Rev_Eng_Fw_Bpt_Task_BR_AssociatedBRs_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_UI') and constid = object_id('Rev_Eng_Fw_Bpt_UI_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_UI add constraint Rev_Eng_Fw_Bpt_UI_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, UIID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_UI_Task') and constid = object_id('Rev_Eng_Fw_Bpt_UI_Task_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_UI_Task add constraint Rev_Eng_Fw_Bpt_UI_Task_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Bpt_UI_Task_BR') and constid = object_id('Rev_Eng_Fw_Bpt_UI_Task_BR_Pkey'))
begin
	alter table Rev_Eng_Fw_Bpt_UI_Task_BR add constraint Rev_Eng_Fw_Bpt_UI_Task_BR_Pkey primary key clustered (Mig_id, customerid, projectid, bpid, functionid, activityid, uiid, taskid, brid, langid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Activity') and constid = object_id('Rev_Eng_Fw_Cmt_Activity_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Activity add constraint Rev_Eng_Fw_Cmt_Activity_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Activity_UI') and constid = object_id('Rev_Eng_Fw_Cmt_Activity_UI_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Activity_UI add constraint Rev_Eng_Fw_Cmt_Activity_UI_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_AssociatedBRs') and constid = object_id('Rev_Eng_Fw_Cmt_AssociatedBRs_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_AssociatedBRs add constraint Rev_Eng_Fw_Cmt_AssociatedBRs_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_BR') and constid = object_id('Rev_Eng_Fw_Cmt_BR_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_BR add constraint Rev_Eng_Fw_Cmt_BR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_BR_Feature') and constid = object_id('Rev_Eng_Fw_Cmt_BR_Feature_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_BR_Feature add constraint Rev_Eng_Fw_Cmt_BR_Feature_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, FeatureID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Component') and constid = object_id('Rev_Eng_Fw_Cmt_Component_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Component add constraint Rev_Eng_Fw_Cmt_Component_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Function') and constid = object_id('Rev_Eng_Fw_Cmt_Function_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Function add constraint Rev_Eng_Fw_Cmt_Function_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Function_Component') and constid = object_id('Rev_Eng_Fw_Cmt_Function_Component_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Function_Component add constraint Rev_Eng_Fw_Cmt_Function_Component_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ComponentName, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Task') and constid = object_id('Rev_Eng_Fw_Cmt_Task_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Task add constraint Rev_Eng_Fw_Cmt_Task_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, TaskID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Task_BR') and constid = object_id('Rev_Eng_Fw_Cmt_Task_BR_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Task_BR add constraint Rev_Eng_Fw_Cmt_Task_BR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs') and constid = object_id('Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs add constraint Rev_Eng_Fw_Cmt_Task_BR_AssociatedBRs_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, AssociatedBRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_UI') and constid = object_id('Rev_Eng_Fw_Cmt_UI_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_UI add constraint Rev_Eng_Fw_Cmt_UI_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, UIID, LangID, BPID, FunctionID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Cmt_UI_Task') and constid = object_id('Rev_Eng_Fw_Cmt_UI_Task_Pkey'))
begin
	alter table Rev_Eng_Fw_Cmt_UI_Task add constraint Rev_Eng_Fw_Cmt_UI_Task_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, WorkReqID, BPID, FunctionID, ActivityID, UIID, TaskID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Doc_BR') and constid = object_id('Rev_Eng_Fw_Doc_BR_Pkey'))
begin
	alter table Rev_Eng_Fw_Doc_BR add constraint Rev_Eng_Fw_Doc_BR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, TaskID, BRID, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Nia_genDoc_Activity') and constid = object_id('Rev_Eng_Fw_Nia_genDoc_Activity_Pkey'))
begin
	alter table Rev_Eng_Fw_Nia_genDoc_Activity add constraint Rev_Eng_Fw_Nia_genDoc_Activity_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, batchid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Nia_genDoc_Function') and constid = object_id('Rev_Eng_Fw_Nia_genDoc_Function_Pkey'))
begin
	alter table Rev_Eng_Fw_Nia_genDoc_Function add constraint Rev_Eng_Fw_Nia_genDoc_Function_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, batchid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Nia_genDoc_UI') and constid = object_id('Rev_Eng_Fw_Nia_genDoc_UI_Pkey'))
begin
	alter table Rev_Eng_Fw_Nia_genDoc_UI add constraint Rev_Eng_Fw_Nia_genDoc_UI_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, BPID, FunctionID, ActivityID, UIID, batchid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_OPC_CodeGenPath') and constid = object_id('Rev_Eng_Fw_OPC_CodeGenPath_Pkey'))
begin
	alter table Rev_Eng_Fw_OPC_CodeGenPath add constraint Rev_Eng_Fw_OPC_CodeGenPath_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, ReleaseVersionNo, ComponentName, ICONumber, LangID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_Bpt_RCN') and constid = object_id('Rev_Eng_Fw_Rmt_Bpt_RCN_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_Bpt_RCN add constraint Rev_Eng_Fw_Rmt_Bpt_RCN_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, RCNNumber, BPID, FunctionID, ComponentName, ActivityID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_Cmt_ICO_details') and constid = object_id('Rev_Eng_Fw_Rmt_Cmt_ICO_details_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_Cmt_ICO_details add constraint Rev_Eng_Fw_Rmt_Cmt_ICO_details_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ECRNumber, ICONumber, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_Cmt_RCN') and constid = object_id('Rev_Eng_Fw_Rmt_Cmt_RCN_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_Cmt_RCN add constraint Rev_Eng_Fw_Rmt_Cmt_RCN_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, RCNNumber, WorkReqID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR') and constid = object_id('Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR add constraint Rev_Eng_Fw_Rmt_Direct_ECR_LinkBR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ECRNumber, ServiceName, BRName)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR') and constid = object_id('Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR add constraint Rev_Eng_Fw_Rmt_DirectRCN_AssociatedDetailedBR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskID, DetailedBRID, FlowBRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR') and constid = object_id('Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR add constraint Rev_Eng_Fw_Rmt_DirectRCN_AssociatedFlowBR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber, BPID, ComponentName, ActivityID, UIID, TaskID, FlowBRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR') and constid = object_id('Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR add constraint Rev_Eng_Fw_Rmt_DirectRCN_DetailedBR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_DirectRCN_FlowBR') and constid = object_id('Rev_Eng_Fw_Rmt_DirectRCN_FlowBR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_DirectRCN_FlowBR add constraint Rev_Eng_Fw_Rmt_DirectRCN_FlowBR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, BRID)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ECR') and constid = object_id('Rev_Eng_Fw_Rmt_ECR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ECR add constraint Rev_Eng_Fw_Rmt_ECR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ECRNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ECR_ICO_Details') and constid = object_id('Rev_Eng_Fw_Rmt_ECR_ICO_Details_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ECR_ICO_Details add constraint Rev_Eng_Fw_Rmt_ECR_ICO_Details_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ECRNumber, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ICO') and constid = object_id('Rev_Eng_Fw_Rmt_ICO_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ICO add constraint Rev_Eng_Fw_Rmt_ICO_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_RCN') and constid = object_id('Rev_Eng_Fw_Rmt_RCN_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_RCN add constraint Rev_Eng_Fw_Rmt_RCN_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, RCNNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_ECR') and constid = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_ECR_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_ECR add constraint Rev_Eng_Fw_Rmt_ReleaseVersion_ECR_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ECRNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_ICO') and constid = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_ICO_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_ICO add constraint Rev_Eng_Fw_Rmt_ReleaseVersion_ICO_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ICONumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_RCN') and constid = object_id('Rev_Eng_Fw_Rmt_ReleaseVersion_RCN_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_ReleaseVersion_RCN add constraint Rev_Eng_Fw_Rmt_ReleaseVersion_RCN_Pkey primary key clustered (Mig_id, CustomerID, ProjectID, LangID, ReleaseVersionNo, RCNNumber)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_Fw_Rmt_UserRole_Mapping') and constid = object_id('Rev_Eng_Fw_Rmt_UserRole_Mapping_Pkey'))
begin
	alter table Rev_Eng_Fw_Rmt_UserRole_Mapping add constraint Rev_Eng_Fw_Rmt_UserRole_Mapping_Pkey primary key clustered (Mig_id, CustomerId, Projectid, UserName, BPId, FunctionId)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_business_rule') and constid = object_id('Rev_Eng_re_business_rule_Pkey'))
begin
	alter table Rev_Eng_re_business_rule add constraint Rev_Eng_re_business_rule_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, br_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_business_rule_lng_extn') and constid = object_id('Rev_Eng_re_business_rule_lng_extn_Pkey'))
begin
	alter table Rev_Eng_re_business_rule_lng_extn add constraint Rev_Eng_re_business_rule_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, br_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_dwd_flowbr') and constid = object_id('Rev_Eng_re_dwd_flowbr_Pkey'))
begin
	alter table Rev_Eng_re_dwd_flowbr add constraint Rev_Eng_re_dwd_flowbr_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, flowbr_sequence, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_dwd_flowbr_br_error') and constid = object_id('Rev_Eng_re_dwd_flowbr_br_error_Pkey'))
begin
	alter table Rev_Eng_re_dwd_flowbr_br_error add constraint Rev_Eng_re_dwd_flowbr_br_error_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_dwd_flowbr_combo') and constid = object_id('Rev_Eng_re_dwd_flowbr_combo_Pkey'))
begin
	alter table Rev_Eng_re_dwd_flowbr_combo add constraint Rev_Eng_re_dwd_flowbr_combo_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_dwd_flowbr_rule_map') and constid = object_id('Rev_Eng_re_dwd_flowbr_rule_map_Pkey'))
begin
	alter table Rev_Eng_re_dwd_flowbr_rule_map add constraint Rev_Eng_re_dwd_flowbr_rule_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, br_name, ecr_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr') and constid = object_id('Rev_Eng_re_flowbr_Pkey'))
begin
	alter table Rev_Eng_re_flowbr add constraint Rev_Eng_re_flowbr_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr_br_error') and constid = object_id('Rev_Eng_re_flowbr_br_error_Pkey'))
begin
	alter table Rev_Eng_re_flowbr_br_error add constraint Rev_Eng_re_flowbr_br_error_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr_br_error_lng_extn') and constid = object_id('Rev_Eng_re_flowbr_br_error_lng_extn_Pkey'))
begin
	alter table Rev_Eng_re_flowbr_br_error_lng_extn add constraint Rev_Eng_re_flowbr_br_error_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr_combo') and constid = object_id('Rev_Eng_re_flowbr_combo_Pkey'))
begin
	alter table Rev_Eng_re_flowbr_combo add constraint Rev_Eng_re_flowbr_combo_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, combo_bt_synonym, combo_page_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr_lng_extn') and constid = object_id('Rev_Eng_re_flowbr_lng_extn_Pkey'))
begin
	alter table Rev_Eng_re_flowbr_lng_extn add constraint Rev_Eng_re_flowbr_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_flowbr_rule_map') and constid = object_id('Rev_Eng_re_flowbr_rule_map_Pkey'))
begin
	alter table Rev_Eng_re_flowbr_rule_map add constraint Rev_Eng_re_flowbr_rule_map_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, flowbr_name, br_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_rulegroup') and constid = object_id('Rev_Eng_re_rulegroup_Pkey'))
begin
	alter table Rev_Eng_re_rulegroup add constraint Rev_Eng_re_rulegroup_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_rulegroup_lng_extn') and constid = object_id('Rev_Eng_re_rulegroup_lng_extn_Pkey'))
begin
	alter table Rev_Eng_re_rulegroup_lng_extn add constraint Rev_Eng_re_rulegroup_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_rulegroup_step') and constid = object_id('Rev_Eng_re_rulegroup_step_Pkey'))
begin
	alter table Rev_Eng_re_rulegroup_step add constraint Rev_Eng_re_rulegroup_step_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, step_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_rulegroup_step_msg') and constid = object_id('Rev_Eng_re_rulegroup_step_msg_Pkey'))
begin
	alter table Rev_Eng_re_rulegroup_step_msg add constraint Rev_Eng_re_rulegroup_step_msg_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_rulegroup_step_msg_lng_extn') and constid = object_id('Rev_Eng_re_rulegroup_step_msg_lng_extn_Pkey'))
begin
	alter table Rev_Eng_re_rulegroup_step_msg_lng_extn add constraint Rev_Eng_re_rulegroup_step_msg_lng_extn_Pkey primary key clustered (Mig_id, customer_name, project_name, process_name, component_name, brgroup_name, step_id, message_id, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rev_Eng_re_ui_ecr') and constid = object_id('Rev_Eng_re_ui_ecr_Pkey'))
begin
	alter table Rev_Eng_re_ui_ecr add constraint Rev_Eng_re_ui_ecr_Pkey primary key clustered (Mig_id, customer_name, project_name, ecr_no, rcr_no, process_name, component_name, activity_name, ui_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_associated_deliverable') and constid = object_id('revmgmt_associated_deliverable_pkey'))
begin
	alter table revmgmt_associated_deliverable add constraint revmgmt_associated_deliverable_pkey primary key clustered (customer_name, project_name, deliverable)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_action_met') and constid = object_id('revmgmt_checklist_action_met_pkey'))
begin
	alter table revmgmt_checklist_action_met add constraint revmgmt_checklist_action_met_pkey primary key clustered (check_list, action_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_action_met_lng_extn') and constid = object_id('revmgmt_checklist_action_met_lng_extn_pkey'))
begin
	alter table revmgmt_checklist_action_met_lng_extn add constraint revmgmt_checklist_action_met_lng_extn_pkey primary key clustered (check_list, action_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_action_mst') and constid = object_id('revmgmt_checklist_action_mst_pkey'))
begin
	alter table revmgmt_checklist_action_mst add constraint revmgmt_checklist_action_mst_pkey primary key clustered (customer_name, project_name, action_code, check_list, mandatory)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_met') and constid = object_id('revmgmt_checklist_met_pkey'))
begin
	alter table revmgmt_checklist_met add constraint revmgmt_checklist_met_pkey primary key clustered (check_list)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_met_lng_extn') and constid = object_id('revmgmt_checklist_met_lng_extn_pkey'))
begin
	alter table revmgmt_checklist_met_lng_extn add constraint revmgmt_checklist_met_lng_extn_pkey primary key clustered (check_list, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_checklist_mst') and constid = object_id('revmgmt_checklist_mst_pkey'))
begin
	alter table revmgmt_checklist_mst add constraint revmgmt_checklist_mst_pkey primary key clustered (customer_name, project_name, check_list)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_deliverable_level') and constid = object_id('revmgmt_deliverable_level_pkey'))
begin
	alter table revmgmt_deliverable_level add constraint revmgmt_deliverable_level_pkey primary key clustered (customer_name, project_name, deliverable, level1_value, level2_value, level3_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_deliverable_met') and constid = object_id('revmgmt_deliverable_met_pkey'))
begin
	alter table revmgmt_deliverable_met add constraint revmgmt_deliverable_met_pkey primary key clustered (deliverable, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_document_dtl') and constid = object_id('revmgmt_document_dtl_pkey'))
begin
	alter table revmgmt_document_dtl add constraint revmgmt_document_dtl_pkey primary key clustered (customer_name, project_name, release, document_no, review_points, review_type, deliverable, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_document_reviewer') and constid = object_id('revmgmt_document_reviewer_pkey'))
begin
	alter table revmgmt_document_reviewer add constraint revmgmt_document_reviewer_pkey primary key clustered (customer_name, project_name, release, review_points, document_no, review_type, deliverable, check_list, level1, level2, level3, reviewer)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_document_user') and constid = object_id('revmgmt_document_user_pkey'))
begin
	alter table revmgmt_document_user add constraint revmgmt_document_user_pkey primary key clustered (customer_name, project_name, release, review_points, document_no, review_type, deliverable, check_list, level1, level2, level3, userid)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_documents') and constid = object_id('revmgmt_documents_pkey'))
begin
	alter table revmgmt_documents add constraint revmgmt_documents_pkey primary key clustered (customer_name, project_name, release, document_no, review_points, review_type, deliverable)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_freeform_list') and constid = object_id('revmgmt_freeform_list_pkey'))
begin
	alter table revmgmt_freeform_list add constraint revmgmt_freeform_list_pkey primary key clustered (customer_name, project_name, release, document_no, deliverable, review_points, review_type, check_list, freeform_code, reviewer, level1, level2, level3)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_perform_chk_dtl') and constid = object_id('revmgmt_perform_chk_dtl_pkey'))
begin
	alter table revmgmt_perform_chk_dtl add constraint revmgmt_perform_chk_dtl_pkey primary key clustered (customer_name, project_name, release, document_no, review_type, check_list, reviewelement, level1, level2, level3, review_points, deliverable, action_code, reviewer)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_quick_code_met') and constid = object_id('revmgmt_quick_code_met_pkey'))
begin
	alter table revmgmt_quick_code_met add constraint revmgmt_quick_code_met_pkey primary key clustered (quick_code, quick_type, quick_value)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewer') and constid = object_id('revmgmt_reviewer_pkey'))
begin
	alter table revmgmt_reviewer add constraint revmgmt_reviewer_pkey primary key clustered (customer_name, project_name, review_type, deliverable, reviewer, review_point)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewpoints_mst') and constid = object_id('revmgmt_reviewpoints_mst_pkey'))
begin
	alter table revmgmt_reviewpoints_mst add constraint revmgmt_reviewpoints_mst_pkey primary key clustered (customer_name, project_name, review_points, release, mandatory)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewtype_chklist_mst') and constid = object_id('revmgmt_reviewtype_chklist_mst_pkey'))
begin
	alter table revmgmt_reviewtype_chklist_mst add constraint revmgmt_reviewtype_chklist_mst_pkey primary key clustered (customer_name, project_name, review_type, deliverable, check_list, mandatory)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewtype_met') and constid = object_id('revmgmt_reviewtype_met_pkey'))
begin
	alter table revmgmt_reviewtype_met add constraint revmgmt_reviewtype_met_pkey primary key clustered (review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewtype_met_lng_extn') and constid = object_id('revmgmt_reviewtype_met_lng_extn_pkey'))
begin
	alter table revmgmt_reviewtype_met_lng_extn add constraint revmgmt_reviewtype_met_lng_extn_pkey primary key clustered (review_type, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_reviewtype_mst') and constid = object_id('revmgmt_reviewtype_mst_pkey'))
begin
	alter table revmgmt_reviewtype_mst add constraint revmgmt_reviewtype_mst_pkey primary key clustered (customer_name, project_name, review_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_revtype_delv_chklist_met') and constid = object_id('revmgmt_revtype_delv_chklist_met_pkey'))
begin
	alter table revmgmt_revtype_delv_chklist_met add constraint revmgmt_revtype_delv_chklist_met_pkey primary key clustered (reviewpoint, review_type, deliverable, check_list)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_revtype_delv_map') and constid = object_id('revmgmt_revtype_delv_map_pkey'))
begin
	alter table revmgmt_revtype_delv_map add constraint revmgmt_revtype_delv_map_pkey primary key clustered (customer_name, project_name, review_type, deilverable)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_rvpnts_rwtype_chklist_mst') and constid = object_id('revmgmt_rvpnts_rwtype_chklist_mst_pkey'))
begin
	alter table revmgmt_rvpnts_rwtype_chklist_mst add constraint revmgmt_rvpnts_rwtype_chklist_mst_pkey primary key clustered (customer_name, project_name, release, review_points, review_type, deliverable, check_list)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_rvpnts_rwtype_mst') and constid = object_id('revmgmt_rvpnts_rwtype_mst_pkey'))
begin
	alter table revmgmt_rvpnts_rwtype_mst add constraint revmgmt_rvpnts_rwtype_mst_pkey primary key clustered (customer_name, project_name, release, review_points, review_type, deliverable)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_user') and constid = object_id('revmgmt_user_pkey'))
begin
	alter table revmgmt_user add constraint revmgmt_user_pkey primary key clustered (customer_name, project_name, review_type, deliverable, userid, review_point)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_user_freeform_action_list') and constid = object_id('revmgmt_user_freeform_action_list_pkey'))
begin
	alter table revmgmt_user_freeform_action_list add constraint revmgmt_user_freeform_action_list_pkey primary key clustered (customer_name, project_name, release, document_no, deliverable, review_points, review_type, check_list, freeform_code, reviewer, level1, level2, level3, userid)
end

if not exists (select 'x' from sysconstraints where id = object_id('revmgmt_user_rev_action_list') and constid = object_id('revmgmt_user_rev_action_list_pkey'))
begin
	alter table revmgmt_user_rev_action_list add constraint revmgmt_user_rev_action_list_pkey primary key clustered (customer_name, project_name, release, document_no, review_points, review_type, check_list, level1, level2, level3, action_code, reviewelement, deliverable, reviewer, userid)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rmt_Publish_DB_met') and constid = object_id('Rmt_Publish_DB_met_pkey'))
begin
	alter table Rmt_Publish_DB_met add constraint Rmt_Publish_DB_met_pkey primary key clustered (Table_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('Rmt_Reference_Value') and constid = object_id('Rmt_Reference_Value_PK'))
begin
	alter table Rmt_Reference_Value add constraint Rmt_Reference_Value_PK primary key clustered (ReferenceType, LangID, ReferenceValue)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_dlp_fin_note') and constid = object_id('PK__sch_dlp_fin_note__33C23270'))
begin
	alter table sch_dlp_fin_note add constraint PK__sch_dlp_fin_note__33C23270 primary key clustered (customer_name, project_name, dlp_fin_note_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_dlp_plan_item') and constid = object_id('PK__sch_dlp_plan_ite__31D9E9FE'))
begin
	alter table sch_dlp_plan_item add constraint PK__sch_dlp_plan_ite__31D9E9FE primary key clustered (customer_name, project_name, dlp_fin_note_no, dlp_plan_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_dlp_planner') and constid = object_id('PK_sch_dlp_planner'))
begin
	alter table sch_dlp_planner add constraint PK_sch_dlp_planner primary key clustered (customer_name, project_name, task_id, planner_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_finalization_note') and constid = object_id('PK__sch_finalization__2A38C836'))
begin
	alter table sch_finalization_note add constraint PK__sch_finalization__2A38C836 primary key clustered (customer_name, project_name, sch_fin_note_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_finalized_plan_item') and constid = object_id('PK__sch_finalized_pl__28507FC4'))
begin
	alter table sch_finalized_plan_item add constraint PK__sch_finalized_pl__28507FC4 primary key clustered (customer_name, project_name, sch_fin_note_no, task_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_finalized_res_assign') and constid = object_id('PK__sch_finalized_re__26683752'))
begin
	alter table sch_finalized_res_assign add constraint PK__sch_finalized_re__26683752 primary key clustered (customer_name, project_name, sch_fin_note_no, task_id, assignment_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_generate_task_temp') and constid = object_id('sch_generate_task_temp_pkey'))
begin
	alter table sch_generate_task_temp add constraint sch_generate_task_temp_pkey primary key clustered (customer_name, project_name, guid, task_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_plan_detail_arc') and constid = object_id('sch_plan_detail_arc_pkey'))
begin
	alter table sch_plan_detail_arc add constraint sch_plan_detail_arc_pkey primary key clustered (customer_name, project_name, dlp_fin_note_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_plan_item') and constid = object_id('PK__sch_plan_item__194411B5'))
begin
	alter table sch_plan_item add constraint PK__sch_plan_item__194411B5 primary key clustered (customer_name, project_name, task_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_quick_code_met') and constid = object_id('sch_quick_code_met_pkey'))
begin
	alter table sch_quick_code_met add constraint sch_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_res_assign') and constid = object_id('PK_sch_res_assign'))
begin
	alter table sch_res_assign add constraint PK_sch_res_assign primary key clustered (customer_name, project_name, task_id, assignment_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sch_resource_calendar') and constid = object_id('PK__sch_resource_cal__2E09591A'))
begin
	alter table sch_resource_calendar add constraint PK__sch_resource_cal__2E09591A primary key clustered (customer_name, project_name, resource_code, calendar_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_objectTemp') and constid = object_id('sql_objectTemp_cndx'))
begin
	alter table sql_objectTemp add constraint sql_objectTemp_cndx primary key clustered (ObjectId, AttributeName)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_syscolumnsTemp') and constid = object_id('sql_syscolumnsTemp_cndx'))
begin
	alter table sql_syscolumnsTemp add constraint sql_syscolumnsTemp_cndx primary key clustered (name, id, colid)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_syscommentsTemp') and constid = object_id('sql_syscommentsTemp_cndx'))
begin
	alter table sql_syscommentsTemp add constraint sql_syscommentsTemp_cndx primary key clustered (id, number, colid)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_sysindexesTemp') and constid = object_id('sql_sysindexesTemp_cndx'))
begin
	alter table sql_sysindexesTemp add constraint sql_sysindexesTemp_cndx primary key clustered (name, id)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_sysindexkeysTemp') and constid = object_id('sql_sysindexkeysTemp_cndx'))
begin
	alter table sql_sysindexkeysTemp add constraint sql_sysindexkeysTemp_cndx primary key clustered (id, indid, colid)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_sysobjectsTemp') and constid = object_id('sql_sysobjectsTemp_cndx'))
begin
	alter table sql_sysobjectsTemp add constraint sql_sysobjectsTemp_cndx primary key clustered (name, id, type)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_systypesTemp') and constid = object_id('sql_systypesTemp_cndx'))
begin
	alter table sql_systypesTemp add constraint sql_systypesTemp_cndx primary key clustered (name, xtype, xusertype)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_Xreference') and constid = object_id('sql_Xreference_cndx'))
begin
	alter table sql_Xreference add constraint sql_Xreference_cndx primary key clustered (ParentClassId, ParentObjectId, SequenceNo, ChildClassId, ChildObjectId)
end

if not exists (select 'x' from sysconstraints where id = object_id('sql_xrefTemp') and constid = object_id('sql_xrefTemp_cndx'))
begin
	alter table sql_xrefTemp add constraint sql_xrefTemp_cndx primary key clustered (ParentClassId, ParentObjectId, SequenceNo, ChildClassId, ChildObjectId)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_quick_code_met') and constid = object_id('ssc_quick_code_met_pkey'))
begin
	alter table ssc_quick_code_met add constraint ssc_quick_code_met_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_quick_code_met_lng_extn') and constid = object_id('ssc_quick_code_met_lng_extn_pkey'))
begin
	alter table ssc_quick_code_met_lng_extn add constraint ssc_quick_code_met_lng_extn_pkey primary key clustered (quick_code_type, quick_code, languageid)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_mst') and constid = object_id('ssc_sco_mst_pkey'))
begin
	alter table ssc_sco_mst add constraint ssc_sco_mst_pkey primary key clustered (customer_name, project_name, ico_no, process_name, component_name, ssco_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_sp') and constid = object_id('ssc_sco_sp_pkey'))
begin
	alter table ssc_sco_sp add constraint ssc_sco_sp_pkey primary key clustered (ssco_no, ico_no, customer_name, project_name, process_name, component_name, sp_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_sp_depends') and constid = object_id('ssc_sco_sp_depends_pkey'))
begin
	alter table ssc_sco_sp_depends add constraint ssc_sco_sp_depends_pkey primary key clustered (ssco_no, ico_no, customer_name, project_name, process_name, component_name, sp_name, child_object_name, parent_object_type, child_object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_sp_errors') and constid = object_id('ssc_sco_sp_errors_pkey'))
begin
	alter table ssc_sco_sp_errors add constraint ssc_sco_sp_errors_pkey primary key clustered (ssco_no, ico_no, customer_name, project_name, process_name, component_name, sp_name, sp_error_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_sp_hst') and constid = object_id('ssc_sco_sp_hst_pkey'))
begin
	alter table ssc_sco_sp_hst add constraint ssc_sco_sp_hst_pkey primary key clustered (ssco_no, ico_no, customer_name, project_name, process_name, component_name, sp_name, last_upd_date, object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssc_sco_sp_spec') and constid = object_id('ssc_sco_sp_spec_pkey'))
begin
	alter table ssc_sco_sp_spec add constraint ssc_sco_sp_spec_pkey primary key clustered (ssco_no, ico_no, customer_name, project_name, process_name, component_name, sp_name, parent_object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_genxml_tmp') and constid = object_id('ssco_genxml_tmp_pkey'))
begin
	alter table ssco_genxml_tmp add constraint ssco_genxml_tmp_pkey primary key clustered (guid, customer_name, project_name, vendor_name, ssco_no, packset_no, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_incorp_mst') and constid = object_id('ssco_incorp_mst_pkey'))
begin
	alter table ssco_incorp_mst add constraint ssco_incorp_mst_pkey primary key clustered (customer_name, project_name, vendor_name, ssco_no, packset_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_packset_config') and constid = object_id('ssco_packset_config_pkey'))
begin
	alter table ssco_packset_config add constraint ssco_packset_config_pkey primary key clustered (customer_name, project_name, vendor_name, ssco_no, packset_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_packset_mst') and constid = object_id('ssco_packset_mst_pkey'))
begin
	alter table ssco_packset_mst add constraint ssco_packset_mst_pkey primary key clustered (customer_name, project_name, vendor_name, ssco_no, packset_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_packset_rmobjects') and constid = object_id('ssco_packset_rmobjects_pkey'))
begin
	alter table ssco_packset_rmobjects add constraint ssco_packset_rmobjects_pkey primary key clustered (customer_name, project_name, vendor_name, ssco_no, packset_no, object_name, object_type)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_packset_workschedule') and constid = object_id('ssco_packset_workschedule_pkey'))
begin
	alter table ssco_packset_workschedule add constraint ssco_packset_workschedule_pkey primary key clustered (customer_name, project_name, vendor_name, ssco_no, packset_no, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_quick_code_mst') and constid = object_id('ssco_quick_code_mst_pkey'))
begin
	alter table ssco_quick_code_mst add constraint ssco_quick_code_mst_pkey primary key clustered (quick_code_type, quick_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_vendor_comm_dtl') and constid = object_id('ssco_vendor_comm_dtl_pkey'))
begin
	alter table ssco_vendor_comm_dtl add constraint ssco_vendor_comm_dtl_pkey primary key clustered (vendor_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_vendor_contact_dtl') and constid = object_id('ssco_vendor_contact_dtl_pkey'))
begin
	alter table ssco_vendor_contact_dtl add constraint ssco_vendor_contact_dtl_pkey primary key clustered (vendor_name, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_vendor_custproj_map') and constid = object_id('ssco_vendor_custproj_map_pkey'))
begin
	alter table ssco_vendor_custproj_map add constraint ssco_vendor_custproj_map_pkey primary key clustered (vendor_name, customer_name, project_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_vendor_mst') and constid = object_id('ssco_vendor_mst_pkey'))
begin
	alter table ssco_vendor_mst add constraint ssco_vendor_mst_pkey primary key clustered (vendor_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('ssco_vendor_system_dtl') and constid = object_id('ssco_vendor_system_dtl_pkey'))
begin
	alter table ssco_vendor_system_dtl add constraint ssco_vendor_system_dtl_pkey primary key clustered (vendor_name, customer_name, project_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('stg_migration_activities') and constid = object_id('PK_stg_migration_activities'))
begin
	alter table stg_migration_activities add constraint PK_stg_migration_activities primary key clustered (Customer, Project, Process, ECR, Component, Activity, ActivityId)
end

if not exists (select 'x' from sysconstraints where id = object_id('stg_migration_component') and constid = object_id('PK_stg_migration_component'))
begin
	alter table stg_migration_component add constraint PK_stg_migration_component primary key clustered (Customer, Project, Process, Component)
end

if not exists (select 'x' from sysconstraints where id = object_id('stg_migration_component_ecr') and constid = object_id('PK_stg_migration_component_ecr'))
begin
	alter table stg_migration_component_ecr add constraint PK_stg_migration_component_ecr primary key clustered (Customer, Project, Process, Ecr, Component)
end

if not exists (select 'x' from sysconstraints where id = object_id('stg_migration_integservice') and constid = object_id('PK_stg_migration_integservice'))
begin
	alter table stg_migration_integservice add constraint PK_stg_migration_integservice primary key clustered (Customer, Project, Process, ECR, Component, Service)
end

if not exists (select 'x' from sysconstraints where id = object_id('temp_5103_mandatory') and constid = object_id('temp_5103_mandatory_pkey'))
begin
	alter table temp_5103_mandatory add constraint temp_5103_mandatory_pkey primary key clustered (component_name, activity_id, ui_id, section_bt_synonym, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('temp_5103_mandatory_col') and constid = object_id('temp_5103_mandatory_col_PEKY'))
begin
	alter table temp_5103_mandatory_col add constraint temp_5103_mandatory_col_PEKY primary key clustered (Component_name, Activity_id, UI_id, control_bt_synonym)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_calendar') and constid = object_id('ts_calendar_PKey'))
begin
	alter table ts_calendar add constraint ts_calendar_PKey primary key clustered (calendardate)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_emp_solutioncenter_map') and constid = object_id('ts_emp_solutioncenter_map_PKey'))
begin
	alter table ts_emp_solutioncenter_map add constraint ts_emp_solutioncenter_map_PKey primary key clustered (emp_code, solutioncenter_code, effective_from_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_emp_taskmaster') and constid = object_id('ts_emp_taskmaster_PKey'))
begin
	alter table ts_emp_taskmaster add constraint ts_emp_taskmaster_PKey primary key clustered (solutioncenter_code, project_code, activity_code, task_code, emp_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_emp_taskmaster_booking_his') and constid = object_id('ts_emp_taskmaster_booking_his_PKey'))
begin
	alter table ts_emp_taskmaster_booking_his add constraint ts_emp_taskmaster_booking_his_PKey primary key clustered (solutioncenter_code, project_code, activity_code, task_code, emp_code, Seq_No)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_emp_taskmaster_his') and constid = object_id('ts_emp_taskmaster_his_PKey'))
begin
	alter table ts_emp_taskmaster_his add constraint ts_emp_taskmaster_his_PKey primary key clustered (solutioncenter_code, project_code, activity_code, task_code, emp_code, plan_id, seq_no)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_empmaster') and constid = object_id('ts_empmaster_PKey'))
begin
	alter table ts_empmaster add constraint ts_empmaster_PKey primary key clustered (emp_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_management_preferance') and constid = object_id('ts_management_preferance_PKey'))
begin
	alter table ts_management_preferance add constraint ts_management_preferance_PKey primary key clustered (emp_code, solutioncenter_code, project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_Primarysupervisor_emp_map') and constid = object_id('ts_Primarysupervisor_emp_map_pkey'))
begin
	alter table ts_Primarysupervisor_emp_map add constraint ts_Primarysupervisor_emp_map_pkey primary key clustered (project_code, emp_code, Primary_supervisor, effective_from_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_project_emp_cost') and constid = object_id('ts_project_emp_cost_PKey'))
begin
	alter table ts_project_emp_cost add constraint ts_project_emp_cost_PKey primary key clustered (solutioncenter_code, project_code, emp_code, effective_from_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_project_ref_forcosting_metadata') and constid = object_id('ts_project_ref_forcosting_metadata_PKey'))
begin
	alter table ts_project_ref_forcosting_metadata add constraint ts_project_ref_forcosting_metadata_PKey primary key clustered (project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_project_solutioncenter_map') and constid = object_id('ts_project_solutioncenter_map_PKey'))
begin
	alter table ts_project_solutioncenter_map add constraint ts_project_solutioncenter_map_PKey primary key clustered (project_code, solutioncenter_code, effective_from_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_projectmaster') and constid = object_id('ts_projectmaster_PKey'))
begin
	alter table ts_projectmaster add constraint ts_projectmaster_PKey primary key clustered (project_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_quickcode_met') and constid = object_id('ts_quickcode_met_PKey'))
begin
	alter table ts_quickcode_met add constraint ts_quickcode_met_PKey primary key clustered (parameter_type, parameter_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_solutioncenter') and constid = object_id('ts_solutioncenter_PKey'))
begin
	alter table ts_solutioncenter add constraint ts_solutioncenter_PKey primary key clustered (solutioncenter_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_solutioncenter_project_emp_map') and constid = object_id('ts_solutioncenter_project_emp_map_PKey'))
begin
	alter table ts_solutioncenter_project_emp_map add constraint ts_solutioncenter_project_emp_map_PKey primary key clustered (solutioncenter_code, project_code, emp_code)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_supervisor_emp_map') and constid = object_id('ts_supervisor_emp_map_PKey'))
begin
	alter table ts_supervisor_emp_map add constraint ts_supervisor_emp_map_PKey primary key clustered (repempcode, emp_code, project_code, effective_from_date)
end

if not exists (select 'x' from sysconstraints where id = object_id('ts_timebooking') and constid = object_id('ts_timebooking_PKey'))
begin
	alter table ts_timebooking add constraint ts_timebooking_PKey primary key clustered (booking_id)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_APP_PREF') and constid = object_id('XPKVID_APP_PREF'))
begin
	alter table VID_APP_PREF add constraint XPKVID_APP_PREF primary key clustered (PCODE, SCODE)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CHART_CONFIG_TMP') and constid = object_id('pk_VID_CHART_CONFIG_TMP'))
begin
	alter table VID_CHART_CONFIG_TMP add constraint pk_VID_CHART_CONFIG_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ChartName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CHART_SERIES_TMP') and constid = object_id('pk_VID_CHART_SERIES_TMP'))
begin
	alter table VID_CHART_SERIES_TMP add constraint pk_VID_CHART_SERIES_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ChartName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CHART_XAXIS_TMP') and constid = object_id('pk_VID_CHART_XAXIS_TMP'))
begin
	alter table VID_CHART_XAXIS_TMP add constraint pk_VID_CHART_XAXIS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ChartName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CHART_YAXIS_TMP') and constid = object_id('pk_VID_CHART_YAXIS_TMP'))
begin
	alter table VID_CHART_YAXIS_TMP add constraint pk_VID_CHART_YAXIS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ChartName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CHARTS_TMP') and constid = object_id('pk_VID_CHARTS_TMP'))
begin
	alter table VID_CHARTS_TMP add constraint pk_VID_CHARTS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, id)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_CONTROLS_TMP') and constid = object_id('pk_VID_CONTROLS_TMP'))
begin
	alter table VID_CONTROLS_TMP add constraint pk_VID_CONTROLS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ControlName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_ENUMVALUES_TMP') and constid = object_id('pk_VID_ENUMVALUES_TMP'))
begin
	alter table VID_ENUMVALUES_TMP add constraint pk_VID_ENUMVALUES_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ControlName, ENumCode)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_GRIDCOLUMNS_TMP') and constid = object_id('pk_VID_GRIDCOLUMNS_TMP'))
begin
	alter table VID_GRIDCOLUMNS_TMP add constraint pk_VID_GRIDCOLUMNS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ControlName, ColumnName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_ILBO_TMP') and constid = object_id('pk_VID_ILBO_TMP'))
begin
	alter table VID_ILBO_TMP add constraint pk_VID_ILBO_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('vid_obj_base') and constid = object_id('XPKvid_obj_base'))
begin
	alter table vid_obj_base add constraint XPKvid_obj_base primary key clustered (CustomerName, ProjectName, doc_no, ProcessName, ComponentName, ActivityName, UiName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_PAGES_TMP') and constid = object_id('pk_VID_PAGES_TMP'))
begin
	alter table VID_PAGES_TMP add constraint pk_VID_PAGES_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_RADIOBUTTONS_TMP') and constid = object_id('pk_VID_RADIOBUTTONS_TMP'))
begin
	alter table VID_RADIOBUTTONS_TMP add constraint pk_VID_RADIOBUTTONS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, ControlName, ButtonName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_SECTIONS_TMP') and constid = object_id('pk_VID_SECTIONS_TMP'))
begin
	alter table VID_SECTIONS_TMP add constraint pk_VID_SECTIONS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_TREE_NTS_TMP') and constid = object_id('pk_VID_TREE_NTS_TMP'))
begin
	alter table VID_TREE_NTS_TMP add constraint pk_VID_TREE_NTS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, TreeId, Name)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_TREECONTROLS_TMP') and constid = object_id('pk_VID_TREECONTROLS_TMP'))
begin
	alter table VID_TREECONTROLS_TMP add constraint pk_VID_TREECONTROLS_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, id)
end

if not exists (select 'x' from sysconstraints where id = object_id('VID_TREENODES_TMP') and constid = object_id('pk_VID_TREENODES_TMP'))
begin
	alter table VID_TREENODES_TMP add constraint pk_VID_TREENODES_TMP primary key clustered (TRNID, Customer, Project, ComponentName, ActivityName, ILBOName, PageName, SectionName, TreeName, id)
end


-- Added for Request TECH-43307 Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('ep_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_ep_ui_section_refinement'))
	BEGIN
		ALTER TABLE ep_ui_section_refinement ADD CONSTRAINT PK_ep_ui_section_refinement 
		PRIMARY KEY (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('ep_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_ep_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE ep_responsive_sec_weightage ADD CONSTRAINT PK_ep_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, req_no, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('re_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_re_ui_section_refinement'))
	BEGIN
		ALTER TABLE re_ui_section_refinement ADD CONSTRAINT PK_re_ui_section_refinement 
		PRIMARY KEY(customer_name, project_name,  process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('re_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_re_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE re_responsive_sec_weightage ADD CONSTRAINT PK_re_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_ui_section_refinement') AND CONSTID = OBJECT_ID('PK_de_ui_section_refinement'))
	BEGIN
		ALTER TABLE de_ui_section_refinement ADD CONSTRAINT PK_de_ui_section_refinement 
		PRIMARY KEY (customer_name, project_name,  process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, section_bt_synonym)
	END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE id = OBJECT_ID('de_responsive_sec_weightage') AND CONSTID = OBJECT_ID('PK_de_responsive_sec_weightage'))
	BEGIN
		ALTER TABLE de_responsive_sec_weightage ADD CONSTRAINT PK_de_responsive_sec_weightage 
		PRIMARY KEY (customer_name, project_name, process_name, component_name, activity_name, ui_name, Formfactor, page_bt_synonym, parent_section, section_bt_synonym)
	END
GO

-- Added for Request TECH-43307 Ends

/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	25 Feb 2020
Purpose 		For Creating Primary Key Constraints
********************************************************************************/

if not exists (select 'x' from sysconstraints where id = object_id('de_fw_des_processsection_br_is') and constid = object_id('de_fw_des_processsection_br_is_pkey'))
begin
	alter table de_fw_des_processsection_br_is add constraint de_fw_des_processsection_br_is_pkey primary key clustered (customer_name, project_name, process_name, component_name, ServiceName, SectionName, SequenceNo)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_pathoperationparameter_serv_map') and constid = object_id('PK_fw_des_api_pathoperationparameter_serv_map'))
begin
	alter table fw_des_api_pathoperationparameter_serv_map add constraint PK_fw_des_api_pathoperationparameter_serv_map primary key clustered (CustomerName, ProjectName, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_pathoperationparameter_task_map') and constid = object_id('PK_fw_des_api_pathoperationparameter_task_map'))
begin
	alter table fw_des_api_pathoperationparameter_task_map add constraint PK_fw_des_api_pathoperationparameter_task_map primary key clustered (CustomerName, ProjectName, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_pathparameter_serv_map') and constid = object_id('PK_fw_des_api_pathparameter_serv_map'))
begin
	alter table fw_des_api_pathparameter_serv_map add constraint PK_fw_des_api_pathparameter_serv_map primary key clustered (CustomerName, ProjectName, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_pathparameter_task_map') and constid = object_id('PK_fw_des_api_pathparameter_task_map'))
begin
	alter table fw_des_api_pathparameter_task_map add constraint PK_fw_des_api_pathparameter_task_map primary key clustered (CustomerName, ProjectName, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, ParameterName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_request_serv_map') and constid = object_id('PK_fw_des_api_request_serv_map'))
begin
	alter table fw_des_api_request_serv_map add constraint PK_fw_des_api_request_serv_map primary key clustered (CustomerName, ProjectName, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_request_task_map') and constid = object_id('PK_fw_des_api_request_task_map'))
begin
	alter table fw_des_api_request_task_map add constraint PK_fw_des_api_request_task_map primary key clustered (CustomerName, ProjectName, ComponentName, ActivityName, UIName, TaskName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_response_serv_map') and constid = object_id('PK_fw_des_api_response_serv_map'))
begin
	alter table fw_des_api_response_serv_map add constraint PK_fw_des_api_response_serv_map primary key clustered (CustomerName, ProjectName, ComponentName, ServiceName, SectionName, SequenceNo, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ResponseCode, ParentSchemaName, SchemaName)
end

if not exists (select 'x' from sysconstraints where id = object_id('fw_des_api_response_task_map') and constid = object_id('PK_fw_des_api_response_task_map'))
begin
	alter table fw_des_api_response_task_map add constraint PK_fw_des_api_response_task_map primary key clustered (CustomerName, ProjectName, ComponentName, ActivityName, UIName, TaskName, SpecID, SpecName, Version, Path, OperationVerb, MediaType, ResponseCode, ParentSchemaName, SchemaName)
end

-- Added for Elastic search & UPE
IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_listedit_map'))
BEGIN
	ALTER TABLE  de_els_query_listedit_map ADD  CONSTRAINT    PK_de_els_query_listedit_map PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 



IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  de_els_query_listedit_input ADD  CONSTRAINT  PK_de_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID,ParameterName)
END
GO 

IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  de_els_query_listedit_result ADD  CONSTRAINT    PK_de_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 

IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_ps_map'))
BEGIN
	ALTER TABLE  de_els_query_ps_map ADD  CONSTRAINT    PK_de_els_query_ps_map PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_ps_input'))
BEGIN
	ALTER TABLE  de_els_query_ps_input  ADD  CONSTRAINT    PK_de_els_query_ps_input PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq,ParameterName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_els_query_ps_result'))
BEGIN
	ALTER TABLE  de_els_query_ps_result    ADD  CONSTRAINT    PK_de_els_query_ps_result PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ServiceName, ProcessSectionName,ProcessSectionSeq,ResultColumn)
END
GO 


IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_els_query_ListEdit_map'))
BEGIN
	ALTER TABLE  ep_els_query_listedit_map ADD  CONSTRAINT  PK_ep_els_query_ListEdit_map   PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  ep_els_query_listedit_input ADD  CONSTRAINT    PK_ep_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ParameterName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_ep_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  ep_els_query_listedit_result ADD  CONSTRAINT    PK_ep_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 


IF NOT  EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_els_query_ListEdit_map'))
BEGIN
	ALTER TABLE  re_els_query_listedit_map ADD  CONSTRAINT  PK_re_els_query_ListEdit_map   PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_els_query_ListEdit_input'))
BEGIN
	ALTER TABLE  re_els_query_listedit_input ADD  CONSTRAINT    PK_re_els_query_ListEdit_input  PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ParameterName)
END
GO 



IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_re_els_query_ListEdit_result'))
BEGIN
	ALTER TABLE  re_els_query_listedit_result ADD  CONSTRAINT    PK_re_els_query_ListEdit_result PRIMARY KEY (CustomerName, ProjectName,
	 ProcessName, ComponentName, ActivityName, UiName, ListControlID, ListViewname, QueryID, ResultColumnName)
END
GO 

IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_upe_control'))
BEGIN
	ALTER TABLE  de_upe_control ADD  CONSTRAINT    PK_de_upe_control PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName,UIName, PageName, SectionName, ControlID, ViewName)
END
GO 


IF NOT EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('PK_de_upe_control_parameters'))
BEGIN
	ALTER TABLE  de_upe_control_parameters ADD  CONSTRAINT    PK_de_upe_control_parameters PRIMARY KEY (CustomerName, ProjectName, 
	ProcessName, ComponentName, ActivityName,UIName, PageName, SectionName, ControlID, ViewName,ParameterType,ParameterName)
END
GO 

----TECH-60451  starts-----

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_ui_grid_extension') AND CONSTID = OBJECT_ID('PK_ep_ui_grid_extension'))
BEGIN
	ALTER TABLE ep_ui_grid_extension ADD CONSTRAINT PK_ep_ui_grid_extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_ui_grid_extension') AND CONSTID = OBJECT_ID('PK_re_ui_grid_extension'))
BEGIN
	ALTER TABLE re_ui_grid_extension ADD CONSTRAINT PK_re_ui_grid_extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_ui_grid_Extension') AND CONSTID = OBJECT_ID('PK_de_ui_grid_Extension'))
BEGIN
	ALTER TABLE de_ui_grid_Extension ADD CONSTRAINT PK_de_ui_grid_Extension PRIMARY KEY CLUSTERED (Customer_Name,Project_Name,Component_Name,Process_Name,Activity_Name,UI_Name,
	Page_BT_Synonym,Section_BT_Synonym,Control_ID,View_Name,ParameterName)
END
GO

----TECH-60451 ends-------------------------------------------------------------------------

-----Code Added For New Feature-Task API Mapping  TECH-61144  starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('plf_api_info') AND CONSTID = OBJECT_ID('PK_plf_api_info'))
BEGIN
	ALTER TABLE plf_api_info ADD CONSTRAINT PK_plf_api_info PRIMARY KEY CLUSTERED ( ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('plf_api_Parameter_info') AND CONSTID = OBJECT_ID('PK_plf_api_Parameter_info'))
BEGIN
	ALTER TABLE plf_api_Parameter_info ADD CONSTRAINT PK_plf_api_Parameter_info PRIMARY KEY CLUSTERED ( ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ParameterLocation, ParameterName, NodeID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('plf_api_Request_info') AND CONSTID = OBJECT_ID('PK_plf_api_Request_info'))
BEGIN
	ALTER TABLE plf_api_Request_info ADD CONSTRAINT PK_plf_api_Request_info PRIMARY KEY CLUSTERED (ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName, FlattenedSchemaName, NodeID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('plf_api_response_info') AND CONSTID = OBJECT_ID('PK_plf_api_response_info'))
BEGIN
	ALTER TABLE plf_api_response_info ADD CONSTRAINT PK_plf_api_response_info PRIMARY KEY CLUSTERED (ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName, FlattenedSchemaName, NodeID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_api_mapping') AND CONSTID = OBJECT_ID('PK_de_task_api_mapping'))
BEGIN
	ALTER TABLE de_task_api_mapping ADD CONSTRAINT PK_de_task_api_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_api_subtask') AND CONSTID = OBJECT_ID('PK_de_task_api_subtask'))
BEGIN
	ALTER TABLE de_task_api_subtask ADD CONSTRAINT PK_de_task_api_subtask PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, SubTaskName, SubTaskSequence )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_api_parameter_map') AND CONSTID = OBJECT_ID('PK_de_task_api_parameter_map'))
BEGIN
	ALTER TABLE de_task_api_parameter_map ADD CONSTRAINT PK_de_task_api_parameter_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ParameterLocation, ParameterName, NodeID )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_api_request_map') AND CONSTID = OBJECT_ID('PK_de_task_api_request_map'))
BEGIN
	ALTER TABLE de_task_api_request_map ADD CONSTRAINT PK_de_task_api_request_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ApiExecSequence, ApiSpecID, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName, FlattenedSchemaName, NodeID )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_api_response_map') AND CONSTID = OBJECT_ID('PK_de_task_api_response_map'))
BEGIN
	ALTER TABLE de_task_api_response_map ADD CONSTRAINT PK_de_task_api_response_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, 
	ApiExecSequence, ApiSpecID, ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ControlID, ViewName, NodeID )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_subtask') AND CONSTID = OBJECT_ID('PK_de_subtask'))
BEGIN
	ALTER TABLE de_subtask ADD CONSTRAINT PK_de_subtask PRIMARY KEY CLUSTERED (CustomerName, ProjectName, DocNo, ProcessName, ComponentName, ActivityName, UIName, SubTaskName)
END
GO
-----Code Added For New Feature-Task API Mapping  TECH-61144  Ends

-----Code Added For Feature Task API Mapping  TECH-61907  starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_service_api_parameter_map') AND CONSTID = OBJECT_ID('PK_de_service_api_parameter_map'))
BEGIN
	ALTER TABLE de_service_api_parameter_map ADD CONSTRAINT PK_de_service_api_parameter_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID,
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, ParameterName,	ParameterLocation )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_service_api_request_map') AND CONSTID = OBJECT_ID('PK_de_service_api_request_map'))
BEGIN
	ALTER TABLE de_service_api_request_map ADD CONSTRAINT PK_de_service_api_request_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID,
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID, SchemaName,	FlattenedSchemaName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_service_api_response_map') AND CONSTID = OBJECT_ID('PK_de_service_api_response_map'))
BEGIN
	ALTER TABLE de_service_api_response_map ADD CONSTRAINT PK_de_service_api_response_map PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ServiceName, ProcessSection , Sequence, ApiExecSequence, ApiSpecID, 
	ApiSpecName, ApiVersion, ApiPath, ApiOperationVerb, ApiOperationID,  SegmentName, DataItemName )
END
GO

-----Code Added For Feature Task API Mapping  TECH-61907  Ends

-----Code Added For Feature Gql operation TECH-63474  Starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_query') AND CONSTID = OBJECT_ID('PK_fw_graphql_query'))
BEGIN
	ALTER TABLE fw_graphql_query ADD CONSTRAINT PK_fw_graphql_query PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version], QueryName, QueryType)
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_sdl') AND CONSTID = OBJECT_ID('PK_fw_graphql_sdl'))
BEGIN
	ALTER TABLE fw_graphql_sdl ADD CONSTRAINT PK_fw_graphql_sdl PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version] )
END
GO


IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_arguments') AND CONSTID = OBJECT_ID('PK_fw_graphql_arguments'))
BEGIN
	ALTER TABLE fw_graphql_arguments ADD CONSTRAINT PK_fw_graphql_arguments PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version], FlattenedArgumentName )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_fields') AND CONSTID = OBJECT_ID('PK_fw_graphql_fields'))
BEGIN
	ALTER TABLE fw_graphql_fields ADD CONSTRAINT PK_fw_graphql_fields PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version], FlattenedFieldName )
END
GO

--31Mar2022
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_mapping') AND CONSTID = OBJECT_ID('PK_de_task_gql_mapping'))
BEGIN
--	ALTER TABLE de_task_gql_mapping ADD CONSTRAINT PK_de_task_gql_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName )
	ALTER TABLE de_task_gql_mapping ADD CONSTRAINT PK_de_task_gql_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, KeyField )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_argument_mapping') AND CONSTID = OBJECT_ID('PK_de_task_gql_argument_mapping'))
BEGIN
	--ALTER TABLE de_task_gql_argument_mapping ADD CONSTRAINT PK_de_task_gql_argument_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, FlattenedArgumentName )
	ALTER TABLE de_task_gql_argument_mapping ADD CONSTRAINT PK_de_task_gql_argument_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, KeyField, FlattenedArgumentName )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_field_mapping') AND CONSTID = OBJECT_ID('PK_de_task_gql_field_mapping'))
BEGIN
	--ALTER TABLE de_task_gql_field_mapping ADD CONSTRAINT PK_de_task_gql_field_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, ControlID, ViewName,FieldName )
	ALTER TABLE de_task_gql_field_mapping ADD CONSTRAINT PK_de_task_gql_field_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, KeyField, ControlID, ViewName, FieldName, MapType )
END
GO
--31Mar2022

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_gql_Schema') AND CONSTID = OBJECT_ID('PK_de_gql_Schema'))
BEGIN
	ALTER TABLE de_gql_Schema ADD CONSTRAINT PK_de_gql_Schema PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version] )
END
GO


-----Code Added For Feature Gql operation TECH-63474  Ends

--Code added for the defect id : TECH-64197 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_arg_fields') AND CONSTID = OBJECT_ID('PK_fw_graphql_arg_fields'))
BEGIN
	ALTER TABLE fw_graphql_arg_fields ADD CONSTRAINT PK_fw_graphql_arg_fields PRIMARY KEY CLUSTERED ( customername,projectname,processname,componentname,importversion,queryname,[key],category)
END
GO

--Code added for the defect id : TECH-64197 ends


--Code added for the defect id : TECH-64865 starts

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_field_mapping') AND CONSTID = OBJECT_ID('PK_de_task_gql_field_mapping'))
BEGIN
	ALTER TABLE de_task_gql_field_mapping ADD CONSTRAINT PK_de_task_gql_field_mapping PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, QuerySequence, QueryName, ControlID, ViewName, FieldName, MapType)
END

--Code added for the defect id : TECH-64865 ends

--Code Added for the Defect-Id : TECH-66583 Starts
if not exists (select 'x' from sysconstraints where id = object_id('re_comp_ctrl_type_mst') and constid = object_id('re_comp_ctrl_type_mst_pkey'))
begin
	alter table re_comp_ctrl_type_mst add constraint re_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_comp_ctrl_type_mst_extn') and constid = object_id('re_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table re_comp_ctrl_type_mst_extn add constraint re_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('re_comp_task_type_mst') and constid = object_id('re_comp_task_type_mst_pkey'))
begin
	alter table re_comp_task_type_mst add constraint re_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, task_type_name)
end

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if not exists (select 'x' from sysconstraints where id = object_id('de_comp_ctrl_type_mst') and constid = object_id('de_comp_ctrl_type_mst_pkey'))
begin
	alter table de_comp_ctrl_type_mst add constraint de_comp_ctrl_type_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_comp_ctrl_type_mst_extn') and constid = object_id('de_comp_ctrl_type_mst_extn_pkey'))
begin
	alter table de_comp_ctrl_type_mst_extn add constraint de_comp_ctrl_type_mst_extn_pkey primary key clustered (customer_name, project_name, process_name, component_name, ctrl_type_name)
end

if not exists (select 'x' from sysconstraints where id = object_id('de_comp_task_type_mst') and constid = object_id('de_comp_task_type_mst_pkey'))
begin
	alter table de_comp_task_type_mst add constraint de_comp_task_type_mst_pkey primary key clustered (customer_name, project_name, process_name, component_name, task_type_name)
end
--Code Added for the Defect-Id : TECH-66583 Ends


--code added for defectid TECH-67697 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_arg_fields_history') AND CONSTID = OBJECT_ID('PK_fw_graphql_arg_fields_history'))
BEGIN
	ALTER TABLE fw_graphql_arg_fields_history ADD CONSTRAINT PK_fw_graphql_arg_fields_history PRIMARY KEY CLUSTERED ( customername, projectname, processname, componentname, importversion, queryname, [key], category, Historyversion )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_query_history') AND CONSTID = OBJECT_ID('PK_fw_graphql_query_history'))
BEGIN
	ALTER TABLE fw_graphql_query_history ADD CONSTRAINT PK_fw_graphql_query_history PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version], QueryName, QueryType, HistoryVersion )
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('fw_graphql_sdl_history') AND CONSTID = OBJECT_ID('PK_fw_graphql_sdl_history'))
BEGIN
	ALTER TABLE fw_graphql_sdl_history ADD CONSTRAINT PK_fw_graphql_sdl_history PRIMARY KEY CLUSTERED ( CustomerName, ProjectName, ProcessName, ComponentName, [Version] , HistoryVersion)
END
GO
--code added for defectid TECH-67697 ends

--Code Added for the DefectId TECH-67339 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ezwiz_wizard_step') AND CONSTID = OBJECT_ID('ezwiz_wizard_step_pk'))
BEGIN
	ALTER TABLE ezwiz_wizard_step ADD CONSTRAINT ezwiz_wizard_step_pk 
	PRIMARY KEY(customer_name, project_name, wizard_name, step_desc)
END
GO
--Code Added for the DefectId TECH-67339 Ends

--Code Added for the DefectId TECH-69624 Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_ui_control_customaction') AND CONSTID = OBJECT_ID('ep_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE ep_ui_control_customaction ADD CONSTRAINT ep_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_ui_control_customaction') AND CONSTID = OBJECT_ID('re_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE re_ui_control_customaction ADD CONSTRAINT re_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_ui_control_customaction') AND CONSTID = OBJECT_ID('de_ui_control_customaction_pk'))
BEGIN
	ALTER TABLE de_ui_control_customaction ADD CONSTRAINT de_ui_control_customaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, control_bt_synonym, ActionControlBTSynonym)
END
GO
--Code Added for the DefectId TECH-69624 Ends

--Code Added for the DefectId TECH-70687 Starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('ep_ui_section_Titleaction') AND CONSTID = OBJECT_ID('ep_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE ep_ui_section_Titleaction ADD CONSTRAINT ep_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	req_no,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('re_ui_section_Titleaction') AND CONSTID = OBJECT_ID('re_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE re_ui_section_Titleaction ADD CONSTRAINT re_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	rcnno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_ui_section_Titleaction') AND CONSTID = OBJECT_ID('de_ui_section_Titleaction_pk'))
BEGIN
	ALTER TABLE de_ui_section_Titleaction ADD CONSTRAINT de_ui_section_Titleaction_pk 
	PRIMARY KEY(customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym, section_bt_synonym, TitleControlBTSynonym)
END
GO
--Code Added for the DefectId TECH-70687 Ends

--Code added for TECH-72114 starts
IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_report') AND CONSTID = OBJECT_ID('PK_de_task_gql_report'))
BEGIN
	ALTER TABLE de_task_gql_report ADD CONSTRAINT PK_de_task_gql_report 
	PRIMARY KEY(CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_report_param') AND CONSTID = OBJECT_ID('PK_de_task_gql_report_param'))
BEGIN
	ALTER TABLE de_task_gql_report_param ADD CONSTRAINT PK_de_task_gql_report_param 
	PRIMARY KEY(CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName, ParameterName)
END 
GO
--Code added for TECH-72114 ends

