
if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'MultiSelectCombo')
begin				
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop)

values
	(	'MultiSelectCombo',	'MultiSelectCombo',	'ListView',		'n',				'y',
		'y',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'MultiSelectCombo',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'MobileGrid')
begin	
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop)

values
	(	'MobileGrid',	'MobileGrid',			'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'MobileGrid',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'HorizontalCarousel')
begin
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	 Datagrid,			Carousel_Req,		Orientation)

values
	(	'HorizontalCarousel',	'HorizontalCarousel',			'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'HorizontalCarousel',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n',
		 'Y',				'Y',				'Horizontal')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'VerticalCarsousel')
begin
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	 Datagrid,			Carousel_Req,		Orientation)

values
	(	'VerticalCarsousel',	'VerticalCarsousel',			'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'VerticalCarsousel',
		'Left',				'n',				'Left',			 1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n',
		 'Y',				'Y',				'Vertical')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'HorizontalTile')
begin
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	 Datagrid,			Carousel_Req,		Orientation)

values
	(	'HorizontalTile',	'HorizontalTile',	'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'HorizontalTile',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n',
		 'Y',				'N',				'Horizontal')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'VerticalTile')
begin
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	 Datagrid,			Carousel_Req,		Orientation)

values
	(	'VerticalTile',	'VerticalTile',			'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'VerticalTile',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'n',
		 'Y',				'N',				'Vertical')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'HiddenButton')
begin
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop )

values
	(	'HiddenButton',	'Hidden Button',		'Button',		'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'y',			'n',				'Hidden Button',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			5,
		'',					'',					'Left',			'n',				'y')
end


if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'Chips')
begin				
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	renderas )

values
	(	'Chips',			'Chips',			'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'Chips',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			25,
		'',					'',					'Left',			'n',				'n',
		'Chips')
end

if not exists(select 'x'
				from	es_ctrl_type_met(nolock)
				where	ctrl_type_name	=	'Tag')
begin				
insert into es_ctrl_type_met
(	ctrl_type_name,		ctrl_type_descr,	base_ctrl_type,		mandatory_flag,		visisble_flag,
	editable_flag,		caption_req,		select_flag,		zoom_req,			insert_req,
	delete_req,			help_req,			event_handling_req,	ellipses_req,		ctrl_type_doc,
	caption_alignment,	caption_wrap,		caption_position,	timestamp,
	createdby,			createddate,		modifiedby,			modifieddate,		visisble_rows,
	label_class,		ctrl_class,			ctrl_position,		password_char,		Auto_tab_stop,
	renderas )

values
	(	'Tag',				'Tag',				'Grid',			'n',				'y',
		'n',				'n',				'n',			'n',				'n',
		'n',				'n',				'n',			'n',				'Chips',
		'Left',				'n',				'Left',			1,
		'Admin',			getdate(),			'Admin',		getdate(),			25,
		'',					'',					'Left',			'n',				'y',
		'Tag')
end

