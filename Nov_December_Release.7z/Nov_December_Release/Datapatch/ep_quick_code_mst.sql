SET NOCOUNT ON

IF NOT EXISTS (SELECT 'X' 
FROM	ep_quick_code_mst (nolock)
WHERE	quick_code_type		= 'SECTION_TYPE'
AND		quick_code			= '22'
AND		quick_code_value	= 'Stepper Linear')
BEGIN
	INSERT INTO ep_quick_code_mst 
				(timestamp,		quick_code_type,	quick_code,		quick_code_value,	createdby,	createddate,	modifiedby,		modifieddate)
	VALUES 
				(1,				'SECTION_TYPE',		'22',			'Stepper Linear',		'11536',	GETDATE(),		'5077',			getdate())
END
	
IF NOT EXISTS (SELECT 'X' 
FROM	ep_quick_code_mst (nolock)
WHERE	quick_code_type		= 'SECTION_TYPE'
AND		quick_code			= '23'
AND		quick_code_value	= 'Stepper Non-Linear')
BEGIN
	INSERT INTO ep_quick_code_mst 
				(timestamp,		quick_code_type,	quick_code,		quick_code_value,	createdby,	createddate,	modifiedby,		modifieddate)
	VALUES 
				(1,				'SECTION_TYPE',		'23',			'Stepper Non-Linear',		'11536',	GETDATE(),		'5077',			getdate())
END


IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'Orientation'  
AND quick_code = 'Horizontal'
AND quick_code_value = 'Horizontal')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'Orientation',  'Horizontal', 'Horizontal', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'Orientation'  
AND quick_code = 'Vertical'
AND quick_code_value = 'Vertical')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'Orientation',  'Vertical', 'Vertical', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO


IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Positive'
AND quick_code_value = 'Positive')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Positive', 'Positive', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Negative'
AND quick_code_value = 'Negative')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Negative', 'Negative', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Primary'
AND quick_code_value = 'Primary')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Primary', 'Primary', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Custom'
AND quick_code_value = 'Custom')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Custom', 'Custom', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Default Outline'
AND quick_code_value = 'Default Outline')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Default Outline', 'Default Outline', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Positive Outline'
AND quick_code_value = 'Positive Outline')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Positive Outline', 'Positive Outline', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Negative Outline'
AND quick_code_value = 'Negative Outline')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Negative Outline', 'Negative Outline', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Primary Outline'
AND quick_code_value = 'Primary Outline')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Primary Outline', 'Primary Outline', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'ButtonNature'  
AND quick_code = 'Custom Outline'
AND quick_code_value = 'Custom Outline')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'ButtonNature',  'Custom Outline', 'Custom Outline', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO
 --
IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'IconPosition'  
AND quick_code = 'Bottom'
AND quick_code_value = 'Bottom')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'IconPosition',  'Bottom', 'Bottom', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'IconPosition'  
AND quick_code = 'Left'
AND quick_code_value = 'Left')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'IconPosition',  'Left', 'Left', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'IconPosition'  
AND quick_code = 'Right'
AND quick_code_value = 'Right')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'IconPosition',  'Right', 'Right', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO

IF NOT EXISTS 
(SELECT 'X' 
FROM ep_quick_code_mst WITH (NOLOCK)  
WHERE quick_code_type = 'IconPosition'  
AND quick_code = 'Top'
AND quick_code_value = 'Top')  
BEGIN  
	INSERT INTO ep_quick_code_mst (timestamp, quick_code_type, quick_code, quick_code_value,  createdby, createddate,  modifiedby, modifieddate)  
	VALUES (1, 'IconPosition',  'Top', 'Top', 'Admin',  getdate(), 'Admin',  getdate() )  
END  
GO
SET NOCOUNT OFF

	