Begin tran

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperLinear'
			AND		seq_no		=	1)					
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperLinear',	1,			'Control',			'[sectionprefix]',	
							'Previous',			'Button',	'Previous button for linear stepper','StpL_',    
							'_Prev',			'Y',		NULL,			NULL,
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperLinear'
			AND		seq_no		=	2)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperLinear',	2,			'Control',			'[sectionprefix]',	
							'Next',				'Button',	'Next button for linear stepper','StpL_' ,    
							'_Next',			'Y',		NULL,				NULL,
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperLinear'
			AND		seq_no		=	3)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperLinear',	3,			'Control',			'[sectionprefix]',	
							'From Tab',			'HiddenEdit','Hidden Control for tab from - linear stepper','StpL_' ,    
							'_TabFrm',			'N',		'nvarchar-60',		'char',
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperLinear'
			AND		seq_no		=	4)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperLinear',	4,			'Control',			'[sectionprefix]',	
							'To Tab',			'HiddenEdit','Hidden Control for tab to - linear stepper','StpL_' ,    
							'_TabTo',			'N',		'nvarchar-60',		'char',
							 NULL,				NULL,		'',					'N')
			END
GO

----------------------------------------------------------------------------------------------------------------------------


IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperNonLinear'
			AND		seq_no		=	1)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperNonLinear',	1,			'Control',			'[sectionprefix]',	
							'Previous',			'Button',	'Previous button for linear stepper','StpNL_' ,    
							'_Prev',			'Y',		NULL,			NULL,
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperNonLinear'
			AND		seq_no		=	2)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperNonLinear',	2,			'Control',			'[sectionprefix]',	
							'Next',				'Button',	'Next button for linear stepper','StpNL_' ,    
							'_Next',			'Y',		NULL,				NULL,
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperNonLinear'
			AND		seq_no		=	3)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperNonLinear',	3,			'Control',			'[sectionprefix]',	
							'Complete',			'Button',	'Complete button for linear stepper','StpNL_' ,    
							'_Comp',			'Y',		NULL,				NULL,
							 NULL,				NULL,		'',					'N')
			END
GO


IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperNonLinear'
			AND		seq_no		=	4)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperNonLinear',	4,			'Control',			'[sectionprefix]',	
							'From Tab',			'HiddenEdit','Hidden Control for tab from - linear stepper','StpNL_' ,    
							'_TabFrm',			'N',		'nvarchar-60',		'char',
							 NULL,				NULL,		'',					'N')
			END
GO

IF NOT EXISTS 
		(	SELECT 'X' 
			FROM ep_systemdefined_views WITH(NOLOCK)
			WHERE	createdfor	=	'StepperNonLinear'
			AND		seq_no		=	5)	
			BEGIN
				INSERT INTO ep_systemdefined_views
				         (	CreatedFor,		seq_no,			ViewCode,		ViewName,	
							ViewCaption,	control_type,	Remarks,		prefix,		
							suffix,			TaskReqd,		BTName,			DataType,
							VisibleRows,	TimeStamp,		RenderAs,		Editable)
				   VALUES  
						(	'StepperNonLinear',	5,			'Control',			'[sectionprefix]',	
							'To Tab',			'HiddenEdit','Hidden Control for tab to - linear stepper','StpNL_' ,    
							'_TabTo',			'N',		'nvarchar-60',		'char',
							 NULL,				NULL,		'',					'N')
			END
GO

		SELECT	*
		FROM	ep_systemdefined_views (nolock)
		WHERE	ViewCode		= 'Control'			
		order by createdfor,seq_no

rollback
--commit