IF NOT EXISTS ( SELECT 'X'
FROM rmt_publish_db_met (NOLOCK)
WHERE Table_name = 'de_published_task_gql_report'
AND PublishDB_Name = 'RVW20PublishDB' )
BEGIN
INSERT INTO rmt_publish_db_met (Table_name,PublishDB_Name,Type)
SELECT 'de_published_task_gql_report','RVW20PublishDB', 'U'
END

IF NOT EXISTS ( SELECT 'X'
FROM rmt_publish_db_met (NOLOCK)
WHERE Table_name = 'de_published_task_gql_report_param'
AND PublishDB_Name = 'RVW20PublishDB' )
BEGIN
INSERT INTO rmt_publish_db_met (Table_name,PublishDB_Name,Type)
SELECT 'de_published_task_gql_report_param','RVW20PublishDB', 'U'
END