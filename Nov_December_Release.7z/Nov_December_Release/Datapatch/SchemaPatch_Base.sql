if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'Load')
begin
	alter table de_task_control_map add Load engg_flag null
end
go

if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_task_control_map' and name = 'Control_type')
begin
	alter table de_task_control_map add Control_type engg_name null
end
go

if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_fw_des_service' and name = 'ApplyRefinements')
begin
	alter table de_fw_des_service add ApplyRefinements engg_flag null
end
go


if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 'de_comp_task_type_mst' and name = 'BubbleMessage')
begin
	alter table de_comp_task_type_mst add BubbleMessage engg_flag null
end
go

if not exists (select 'x' from syscolumns (nolock) where object_name(id) = 're_comp_task_type_mst' and name = 'BubbleMessage')
begin
	alter table re_comp_task_type_mst add BubbleMessage engg_flag null
end
go

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='PullToRefresh' and name = 'PullToRefresh')
BEGIN
    ALTER TABLE ep_ui_mst add PullToRefresh    engg_flag   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='PullToRefresh' and name = 'PullToRefresh')
BEGIN
    ALTER TABLE re_ui add PullToRefresh    engg_flag   NULL
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCOLUMNS WHERE OBJECT_NAME(ID) ='PullToRefresh' and name = 'PullToRefresh')
BEGIN
    ALTER TABLE de_ui add PullToRefresh    engg_flag   NULL
END
GO

--
IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_section_dtl' AND NAME = 'Orientation' )
BEGIN
	ALTER TABLE ep_ui_section_dtl ADD Orientation engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_section' AND NAME = 'Orientation' )
BEGIN
	ALTER TABLE re_ui_section ADD Orientation engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_ui_section' AND NAME = 'Orientation' )
BEGIN
	ALTER TABLE de_ui_section ADD Orientation engg_name NULL
END
GO


--

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Control_dtl' AND NAME = 'ButtonNature' )
BEGIN
	ALTER TABLE ep_ui_Control_dtl ADD ButtonNature engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_Control' AND NAME = 'ButtonNature' )
BEGIN
	ALTER TABLE re_ui_Control ADD ButtonNature engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_ui_Control' AND NAME = 'ButtonNature' )
BEGIN
	ALTER TABLE de_ui_Control ADD ButtonNature engg_name NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'ep_ui_Control_dtl' AND NAME = 'InlineStyle' )
BEGIN
	ALTER TABLE ep_ui_Control_dtl ADD InlineStyle Engg_Nvarchar_Max NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 're_ui_Control' AND NAME = 'InlineStyle' )
BEGIN
	ALTER TABLE re_ui_Control ADD InlineStyle Engg_Nvarchar_Max NULL
END
GO

IF NOT EXISTS ( SELECT 'X' FROM SYSCOLUMNS (NOLOCK) WHERE OBJECT_NAME(ID) = 'de_ui_Control' AND NAME = 'InlineStyle' )
BEGIN
	ALTER TABLE de_ui_Control ADD InlineStyle Engg_Nvarchar_Max NULL
END
GO