		IF NOT EXISTS	(SELECT 'X' FROM es_ctrl_task_met WITH(NOLOCK)
						WHERE	quick_code_value	=	'Caption Required'
						AND		quick_code			=	'ListView'	
						AND		quick_code_type		=	'Control'
					)
	BEGIN
			INSERT INTO es_ctrl_task_met
			         (quick_code_type,	quick_code,	quick_code_value,	timestamp, createddate,
					createdby,		modifiedby,			modifieddate)
		    VALUES    (	'Control',	    'ListView',	        'Caption Required',        1,		GetDate(),
						'Admin',		'Admin',		GetDate())
	END
	GO