
	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask
									 )

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'MultiSelectCombo',			'MultiSelectCombo',			'ListView',					'N',						'Y',	
									'Y',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,						'MultiSelectCombo',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'MultiSelectCombo'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd,		EyeIconforPassword,	Signature,			KeyupSearch,
		 Stepper,			LiveClock,			ClearTask,			ShowAnimation,		PreventMultipleRowSelection,
		 PreviousCount )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'MultiSelectCombo',		'MultiSelectCombo',		'ListView',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL 
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'MultiSelectCombo'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask
									 )

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'MobileGrid',				'MobileGrid',				'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,						'MobileGrid',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'MobileGrid'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd,		EyeIconforPassword,	Signature,			KeyupSearch,
		 Stepper,			LiveClock,			ClearTask,			ShowAnimation,		PreventMultipleRowSelection,
		 PreviousCount )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'MobileGrid',			'MobileGrid',			'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'MobileGrid'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 Datagrid,					Carousel_Req,				Orientation)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'HorizontalCarousel',		'HorizontalCarousel',		'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,						'HorizontalCarousel',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL,
									 'Y',						'Y',						'Horizontal'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'HorizontalCarousel'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'HorizontalCarousel',	'HorizontalCarousel',	'Grid',			NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					'Horizontal',		NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'HorizontalCarousel'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 Datagrid,					Carousel_Req,				Orientation)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'VerticalCarsousel',		'VerticalCarsousel',		'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,						'VerticalCarsousel',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL,
									 'Y',						'Y',						'Vertical'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'VerticalCarsousel'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'VerticalCarsousel','VerticalCarsousel',		'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					'Vertical',			NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'VerticalCarsousel'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 Datagrid,					Carousel_Req,				Orientation)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'HorizontalTile',			'HorizontalTile',			'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,							'HorizontalTile',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL,
									 'Y',						'N',						'Horizontal'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'HorizontalTile'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'HorizontalTile',		'HorizontalTile',		'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					'Horizontal',		NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'HorizontalTile'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 Datagrid,					Carousel_Req,				Orientation)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'VerticalTile',				'VerticalTile',				'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 5,							'VerticalTile',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'N',
									 'N',						'',							'',							'N',						NULL,
									 'Y',						'N',						'Vertical'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'VerticalTile'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'VerticalTile',			'VerticalTile',			'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					'Vertical',			NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'VerticalTile'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask
									 )

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'HiddenButton',				'Hidden Button',			'Button',					'N',						'N',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'Y',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 25,						'Hidden Button',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'Y',
									 'N',						'',							'',							'N',						NULL
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'HiddenButton'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, CalendarControl,	ListItemExpander,
		 Zoom,				PaginationReqd)
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'HiddenButton',			'Hidden Button',		'Button',			NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					'N',				'N',				NULL,  
		 NULL,					NULL,					NULL,				'N',				NULL, 
		 NULL,					'N',					'N',				'N',				'N',
		 'N',					'N'
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'HiddenButton'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 renderas)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'Chips',					'Chips',					'Grid',						'N',						'Y',	
									'N',						'Y',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 25,						'Chips',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'Y',
									 'N',						'',							'',							'N',						NULL,
									 'Chips'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'Chips'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, 	CalendarControl,ListItemExpander,
		 Zoom,				PaginationReqd,		EyeIconforPassword,	Signature,			KeyupSearch,
		 Stepper,			LiveClock,			ClearTask,			ShowAnimation,		PreventMultipleRowSelection,
		 PreviousCount )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'Chips',				'Chips',				'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL 
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'Chips'
                   )
GO

	INSERT INTO es_comp_ctrl_type_mst 
									(customer_name,				project_name,				req_no,					process_name,				component_name,
									 ctrl_type_name,			ctrl_type_descr,			base_ctrl_type,			mandatory_flag,				visisble_flag,
									 editable_flag,				caption_req,				select_flag,			zoom_req,					insert_req,
									 delete_req,				help_req,					event_handling_req,		ellipses_req,				comp_ctrl_type_sysid,
									 timestamp,					createdby,					createddate,			modifiedby,					modifieddate,
									 caption_alignment,			caption_position,			caption_wrap,			visisble_rows,				ctrl_type_doc,
									 ctrl_position,				label_class,				ctrl_class,				password_char,				tskimg_class,
									 hlpimg_class,				disponlycmb_req,			html_txt_area,			report_req,					Auto_tab_stop,
									 Spin_required,				Spin_up_image,				Spin_down_image,		InPlace_Calendar,			EditMask,
									 renderas)

			SELECT DISTINCT			customer_name,				project_name,				req_no,						process_name,				component_name,
									'Tag',						'Tag',						'Grid',						'N',						'Y',	
									'N',						'N',						'N',						'N',						'N',	
									'N',						'N',						'N',						'N',						'N',
									 1,						    'Admin',					GETDATE(),					'Admin',					GETDATE(),	
									'Left',						'Left',						'N',						 25,						'Tag',	
									'Left',						''	,						'',							'N',						'',
									 '',						'N',						'N',						'N',						'Y',
									 'N',						'',							'',							'N',						NULL,
									 'Tag'
		FROM ep_ui_req_dtl dtl (NOLOCK)
		WHERE req_no = 'BASE'
              AND NOT EXISTS (SELECT  'X'
                   FROM es_comp_ctrl_Type_mst  mst (NOLOCK)
                   WHERE mst.customer_name         =  dtl.customer_name
                   AND mst.project_name            =  dtl.project_name
                   AND mst.req_no                  =  'base'
                   AND mst.process_name            =  dtl.process_name
                   AND mst.component_name          =  dtl.component_name
                   AND mst.ctrl_type_name          =  'Tag'
                    )
GO


INSERT es_comp_ctrl_Type_mst_extn 
		(customer_name,		project_name,		req_no,				process_name,		component_name, 
		 ctrl_type_name,	ctrl_type_descr,	base_ctrl_type,		Configuration,		timestamp, 
		 createdby,			createddate,		modifiedby,			modifieddate,		SliderType, 
		 SliderBehaviour,	RenderType,			Orientation,		Startvalue,			Endvalue, 
		 Minvalue,			Maxvalue,			Stepvalue,			SliderValue,		Showvalue, 
		 ShowTooltip,		Rangelabel,			Rangevalue,			Rangetooltip,		RangeSelect, 
		 ValueShown,		ExpandEvent,		ExpandAllEvent,		CollapseEvent,		CollapseAllEvent, 
		 ClickEvent,		DDToolTip,			ZoomMin,			ZoomMax,			DefaultZoom, 
		 ZoomStep,			NodeWidth,			NodeHeight,			DefaultFile,		IsOrgChart, 
		 checkevent,		bufferedrows,		SparkChartType,		ChartType,			Delayedpwdmask, 
		 preserve_gridposition, Dynamicfileupload, ServerSidePrint, MultiFileSelect,	NoofCtrlPerLine, 
		 FormWidth,			ControlWidth,		LabelWidth,			MetaDataBasedLink,	LabelAlignment, 
		 Scan,				Autoselect,			IsList,				MultiSelect,		SelectedRowcount,  
		 NFCEnabled,		AutoScan,			IsToggle,			NodeIconReqd,		NodeCustomClass, 
		 IsDocked,			RuleBuilder,		MultiSelectComboforRB, 	CalendarControl,ListItemExpander,
		 Zoom,				PaginationReqd,		EyeIconforPassword,	Signature,			KeyupSearch,
		 Stepper,			LiveClock,			ClearTask,			ShowAnimation,		PreventMultipleRowSelection,
		 PreviousCount )
SELECT DISTINCT 
		customer_name,			project_name,			'base',				process_name,		component_name, 
		'Tag',					'Tag',					'Grid',				NULL,				1, 
		'Admin',				getdate(),				'Admin',			getdate(),			NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				'Left', 
		 NULL,					NULL,					NULL,				NULL,				NULL,  
		 NULL,					NULL,					NULL,				NULL,				NULL, 
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL,					NULL,					NULL,				NULL,				NULL,
		 NULL 
FROM ep_ui_req_dtl dtl (NOLOCK)
WHERE req_no = 'BASE'
AND NOT EXISTS (SELECT  'X'
					FROM	es_comp_ctrl_Type_mst_extn  extn (nolock)
					WHERE	extn.customer_name				= dtl.customer_name
					AND		extn.project_name               = dtl.project_name
					AND		extn.req_no                     = 'base'
					AND		extn.process_name               = dtl.process_name
					AND		extn.component_name             = dtl.component_name
					AND		extn.ctrl_type_name             = 'Tag'
                   )
GO
