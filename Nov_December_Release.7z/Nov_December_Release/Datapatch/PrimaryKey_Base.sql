IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_report') AND CONSTID = OBJECT_ID('PK_de_task_gql_report'))
BEGIN
	ALTER TABLE de_task_gql_report ADD CONSTRAINT PK_de_task_gql_report 
	PRIMARY KEY(CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName)
END
GO

IF NOT EXISTS (SELECT 'X' FROM SYSCONSTRAINTS WHERE ID = OBJECT_ID('de_task_gql_report_param') AND CONSTID = OBJECT_ID('PK_de_task_gql_report_param'))
BEGIN
	ALTER TABLE de_task_gql_report_param ADD CONSTRAINT PK_de_task_gql_report_param 
	PRIMARY KEY(CustomerName, ProjectName, ProcessName, ComponentName, ActivityName, UIName, TaskName, ReportName, ParameterName)
END 
GO