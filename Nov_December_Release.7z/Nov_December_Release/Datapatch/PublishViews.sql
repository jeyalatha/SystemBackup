IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'ep_published_ui_mst' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'ep_published_ui_mst'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 're_published_ui' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 're_published_ui'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'de_published_ui' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'de_published_ui'
END
GO

--
IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'ep_Published_ui_section_dtl' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'ep_Published_ui_section_dtl'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 're_published_ui_Section' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 're_published_ui_Section'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'de_published_ui_Section' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'de_published_ui_Section'
END
GO
--
IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'ep_Published_ui_Control_dtl' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'ep_Published_ui_Control_dtl'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 're_published_ui_Control' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 're_published_ui_Control'
END
GO

IF EXISTS ( SELECT 'x' from rmt_publish_db_met (NOLOCK) WHERE table_name = 'de_published_ui_Control' and TYPE = 'U')
BEGIN
EXEC Rmt_PublishDB_ViewCreation 'de_published_ui_Control'
END
GO

--

if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'de_published_task_control_map' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'de_published_task_control_map'
End
Go



if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'de_fw_des_publish_service' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'de_fw_des_publish_service'
End
Go


if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'ep_published_comp_task_type_mst' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'ep_published_comp_task_type_mst'
End
Go


if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 're_published_comp_task_type_mst' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 're_published_comp_task_type_mst'
End
Go


if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'de_published_comp_task_type_mst' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'de_published_comp_task_type_mst'
End
Go

if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'de_published_task_gql_report' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'de_published_task_gql_report'
End
Go

if exists ( select 'x' from rmt_publish_db_met (nolock) where table_name = 'de_published_task_gql_report_param' and type = 'U')
Begin
exec Rmt_PublishDB_ViewCreation 'de_published_task_gql_report_param'
End
Go
