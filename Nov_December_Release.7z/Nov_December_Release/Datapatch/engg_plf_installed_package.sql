
IF NOT EXISTS ( SELECT 'X'
FROM	engg_plf_installed_package (nolock)
WHERE	ProductGroup	=	'Platform'
AND		Version			=	'PLF_2.0.3.021'
)

INSERT INTO engg_plf_installed_package 
					(	ProductGroup,		Version,			MajorVersion,		MinorVersion,
						RevisionVersion,	BuildVersion,		ReleasePath,		
						UpdatedUser,		UpdatedDate )
VALUES
					(	'Platform',			'PLF_2.0.3.020',	2,					22,
							012,				001,				'\\172.16.7.21\TES\TECHRELEASE\HotFixes\PLF\2.0.3.0\PLF_2.0.3.021.zip',
						 'Admin',			Getdate())



