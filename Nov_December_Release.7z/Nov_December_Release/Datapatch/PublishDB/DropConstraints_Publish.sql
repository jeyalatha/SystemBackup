IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report'))
BEGIN
	ALTER TABLE  de_published_task_gql_report DROP CONSTRAINT PK_de_published_task_gql_report
END
GO

IF EXISTS (SELECT 'X' FROM sysobjects WHERE id = object_id('de_published_task_gql_report_param'))
BEGIN
	ALTER TABLE  de_published_task_gql_report_param DROP CONSTRAINT PK_de_published_task_gql_report_param
END
GO