IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_devcon_wcf_getsegments' AND TYPE = 'P')
	DROP PROC engg_devcon_wcf_getsegments
GO
/*------------------------------------------------------------------------------------------*/
/*      V E R S I O N      :  2 . 0 . 4                 									*/
/*      Released By        :  PTech                  										*/
/*      Release Comments   :                       											*/
/*******************************************************************************************/
/* procedure    : engg_devcon_wcf_getsegments                               				*/
/* description  :                        													*/
/*******************************************************************************************/
/* author       : Ramachandran.T                                                      		*/
/* date         : 05/04/2012                                                       			*/
/* BugId        : PNR2.0_36329                                                     			*/
/* Description  : Changes in PLN_WCFCodeGen dll for changes related                			*/
/*                            to converting segment of request / response as type based     */
/*                            Since the entire implementation is changes inline comments not*/
/*                            provided               										*/
/********************************************************************************************/
/* Modified by  :	Ramachandran.T                                                   		*/
/* Date         :	15 Mar 2012                                                				*/
/* Case ID  	:   PLF2.0_00711    --Fix Released against the callid : PLF2.0_00701		*/
/* Description  :   Changes for WCF Web Service In/Out Segment        						*/
/********************************************************************************************/
/* Modified by  :	Madhan Sekar.M                                                   		*/
/* Date         :	06 Jan 2015                                               				*/
/* Case ID  	:   PLF2.0_11168															*/
/* Description  :   column to get mandatory flag for segment        						*/
/********************************************************************************************/
/* Modified by  : Manoj S		                                                            */  
/* Date         : 05 Dec 2022                                                               */  
/* Case ID      : TECH-75296															    */  
/********************************************************************************************/  

CREATE procedure engg_devcon_wcf_getsegments
	@customer  		engg_name,
	@project  		engg_name,
	@ecrno   		engg_name,
	@servicename 	engg_name,
	@flowattribute 	engg_name
as
begin
	set nocount on

	declare @flow1   engg_flag, --PLF2.0_00711 
			@flow2   engg_flag
	
	if @flowattribute = 'in'
	begin
		--PLF2.0_00711
		select @flow1 = '0',
			   @flow2 = '2'
	end
	else if @flowattribute = 'out'
	begin
		--PLF2.0_00711
		select @flow1 = '1',
			   @flow2 = '2'
	end
	else if @flowattribute = 'inout'
	begin
		--PLF2.0_00711
		select @flow1 = '2',
			   @flow2 = '2'
	end

	select  distinct
			lower(a.servicename)  as servicename,
			lower(a.segmentname)  as segmentname,
			a.instanceflag		  as instanceflag,
			''					  as 'InOutSeg',
			a.mandatoryflag		  as mandatoryflag	--PLF2.0_11168
	into 	#fw_des_wcf_segment
	from  	de_fw_des_publish_service_segment_vw_fn(@customer, @project, @ecrno) a,
			de_fw_des_publish_service_dataitem_vw_fn(@customer, @project, @ecrno) b
	
	where a.customername  = @customer
	and  a.projectname  = @project
	and  a.ecrno   = @ecrno
	and  a.servicename  = @servicename
	and  a.segmentname <> 'fw_context'
	and  (b.flowattribute = @flow1 or b.flowattribute = @flow2) --PLF2.0_00711
	
	and  a.customername = b.customername
	and  a.projectname = b.projectname
	and  a.ecrno   = b.ecrno
	and  a.processname  = b.processname
	and  a.componentname = b.componentname
	and  a.servicename  = b.servicename
	and  a.segmentname  = b.segmentname
	
	--order by a.servicename, a.segmentname, a.instanceflag,	a.mandatoryflag	--PLF2.0_11168 ----commented against TECH-75296
order by 1, 2, 3,4  --Added against TECH-75296

	Update 	#fw_des_wcf_segment
	set  	InOutSeg = 'Y'
	from 	#fw_des_wcf_segment a,
			de_fw_des_publish_service_dataitem_vw_fn(@customer, @project, @ecrno) b
	where 	b.flowattribute= 2
	and  	a.servicename  = b.servicename
	and  	a.segmentname  = b.segmentname

	select  distinct servicename, segmentname, instanceflag, InOutSeg,	mandatoryflag	--PLF2.0_11168
	from 	#fw_des_wcf_segment
	--PLF2.0_00711
	order by instanceflag, segmentname

	set nocount off
end
IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_devcon_wcf_getsegments' AND TYPE = 'P')
	GRANT EXEC ON engg_devcon_wcf_getsegments TO PUBLIC
GO	
