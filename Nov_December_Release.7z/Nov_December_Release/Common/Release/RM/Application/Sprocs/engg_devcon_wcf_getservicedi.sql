IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_devcon_wcf_getservicedi' AND TYPE = 'P')
	DROP PROC engg_devcon_wcf_getservicedi
GO
/*------------------------------------------------------------------------------------------*/
/*      V E R S I O N      :  2 . 0 . 4                          */
/*      Released By        :  PTech                            */
/*      Release Comments   :                                  */
/*******************************************************************************************/
/* procedure    : engg_devcon_wcf_getservicedi                                   */
/* description  :                                     */
/********************************************************************************************/
/* author       : Ramachandran.T                                                       */
/* date         : 05/04/2012                                                          */
/* BugId        : PNR2.0_36329                                                        */
/* Description  : Changes in PLN_WCFCodeGen dll for changes related                   */
/*                            to converting segment of request / response as type based     */
/*                            Since the entire implementation is changes inline comments not*/
/*                            provided                         */
/********************************************************************************************/
/* Modified by  : Ramachandran.T                                                     */
/* Date         : 15 Mar 2012                                                    */
/* Case ID   :   PLF2.0_00711 --Fix Released against the callid : PLF2.0_00701           */
/* Description  :   Changes for WCF Web Service In/Out Segment              */
/********************************************************************************************/
/* Modified by  : Madhan Sekar.M                                                     */
/* Date         : 06 Jan 2015                                                   */
/* Case ID   :   PLF2.0_11168               */
/* Description  :   column to get mandatory flag for segment              */
/********************************************************************************************/
/* Modified by  : Ramachandran T                                                     */
/* Date         : 19 Mar 2015                                                   */
/* Case ID   :   PLF2.0_12171               */
/* Description  :   To include in/out dataitems                           */
/********************************************************************************************/
/* Modified by  : Madhan Sekar M															*/
/* Date         : 15 May 2019																*/
/* Case ID		: TECH-34047																*/
/* Description  : default values															*/
/********************************************************************************************/
/* Modified by  : Manoj S		                                                            */  
/* Date         : 05 Dec 2022                                                               */  
/* Case ID      : TECH-75296															    */  
/********************************************************************************************/ 
Create Procedure engg_devcon_wcf_getservicedi
	@customer     engg_name,
	@project     engg_name,
	@ecrno      engg_name,
	@servicename   engg_name,
	@segmentname   engg_name,
	@flowattribute   engg_name
as
begin
	set nocount on

	declare @flow1   engg_flag, --PLF2.0_00711
	@flow2   engg_flag --PLF2.0_12171

	if @flowattribute = 'in'
	begin
	--PLF2.0_00711
	select @flow1 = '0',
	@flow2 = '2' --PLF2.0_12171
	end
	else if @flowattribute = 'out'
	begin
	--PLF2.0_00711
	select @flow1 = '1',
	@flow2 = '2' --PLF2.0_12171
	end
	else if @flowattribute = 'inout'
	begin
	--PLF2.0_00711
	select @flow1 = '2',
	@flow2 = '2' --PLF2.0_12171
	end

	select  distinct ltrim(rtrim(lower(a.servicename))) as servicename,
	ltrim(rtrim(lower(a.segmentname))) as segmentname,
	ltrim(rtrim(a.instanceflag)) as instanceflag,
	ltrim(rtrim(lower(b.dataitemname))) as dataitemname,
	ltrim(rtrim(lower(bt.datatype))) as datatype,
	b.mandatoryflag as mandatoryflag, --PLF2.0_11168
	b.defaultvalue as defaultvalue --TECH-34047
	from   de_fw_des_publish_service_segment_vw_fn(@customer, @project, @ecrno) a,
	de_fw_des_publish_service_dataitem_vw_fn(@customer, @project, @ecrno) b,
	--PLF2.0_00711
	-- de_fw_des_publish_di_parameter_vw_fn(@customer, @project, @ecrno) c,
	-- de_fw_des_publish_br_logical_parameter_vw_fn(@customer, @project, @ecrno) d,
	de_fw_req_publish_bterm_synonym bs (nolock),
	de_fw_req_publish_bterm bt (nolock)

	where b.customername=a.customername
	and   b.projectname=a.projectname
	and   b.ecrno=a.ecrno
	and   b.processname = a.processname
	and   b.componentname = a.componentname
	and   b.servicename = a.servicename
	and   b.segmentname = a.segmentname

	--PLF2.0_00711
	-- and  c.customername=b.customername
	-- and  c.projectname=b.projectname
	-- and  c.ecrno=b.ecrno
	-- and  c.processname=b.processname
	-- and  c.componentname=b.componentname
	-- and  c.servicename=b.servicename
	-- and  c.segmentname=b.segmentname
	-- and  c.dataitemname=b.dataitemname
	--
	--
	-- and  d.customername = c.customername
	-- and  d.projectname = c.projectname
	-- and  d.ecrno=c.ecrno
	-- and  d.processname=c.processname
	-- and  d.componentname=c.componentname
	-- and  d.methodid=c.methodid
	-- and  d.logicalparametername = c.parametername

	and  b.customername = bs.customername
	and  b.projectname = bs.projectname
	and  b.ecrno = bs.ecrno
	and  b.processname = bs.processname
	and  b.componentname = bs.componentname
	and  b.dataitemname = bs.btsynonym

	and  bs.customername = bt.customername
	and  bs.projectname = bt.projectname
	and  bs.ecrno = bt.ecrno
	and  bs.processname = bt.processname
	and  bs.componentname = bt.componentname
	and  bs.btname = bt.btname


	and  (b.flowattribute = @flow1 or b.flowattribute = @flow2) --PLF2.0_12171
	and  a.customername = @customer
	and  a.projectname = @project
	and  a.ecrno = @ecrno
	and  a.servicename = @servicename
	and  a.segmentname = @segmentname
	--PLF2.0_00711
	--and  c.segmentname<> 'fw_context'
	and  a.segmentname<> 'fw_context'

	--order by a.servicename, a.instanceflag, a.segmentname, b.dataitemname, b.mandatoryflag --PLF2.0_11168 ----commented against TECH-75296
	order by 1,3,2,4,6 --Added against TECH-75296

	set nocount off
end

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_devcon_wcf_getservicedi' AND TYPE = 'P')
	GRANT EXEC ON engg_devcon_wcf_getservicedi TO PUBLIC
GO	