IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_mr_Preview_population_203_2_2' AND TYPE = 'P')
BEGIN
  DROP PROC engg_mr_Preview_population_203_2_2
  END
GO
/************************************************************************************      
procedure name and id    engg_mr_Preview_population_203_2_2      
description              This stored proc is used to populate the preview level tables      
       from the DE published tables for reconstruction purpose.      
      
name of the author       Nupur Agrawal      
      
date created             11/02/06      
************************************************************************************       
modifications history         
************************************************************************************      
modified by             : Makesh prabu. R      
modified date           : 15-July-2008      
modified purpose        : for the bug_id PNR2.0_18447 (adding new features)      
*************************************************************************************/       
/* modified by          : Makesh prabu.R           */      
/* modified date        :  08-April-2009           */      
/* modified purpose     :  PNR2.0_21056 --Extjs Relese, New columns, tables added */      
/************************************************************************************/      
/* modified by          : Makesh prabu.R           */      
/* modified date        :  08-Oct-2009            */      
/* modified purpose     :  PNR2.0_24235 -- State Migration       */      
/****************************************************************************************/      
/* Modified by   : Senthil Kumar S      */      
/* Modified date : 02/Nov/2009       */      
/* Description   : New column added in state tables.    */      
/* BugID  : PNR2.0_23622       */      
/****************************************************************************************/        
/* modified by  : Makesh prabu. R             */      
/* date         : 05-November-2009             */      
/* BugID  : PNR2.0_24649 (Schema changes - Cross fix)       */      
/************************************************************************************/      
/* modified by  : Makesh Prabu. R                                          */      
/* date         : 17/March/2010                                            */      
/* description  : phase3 & phase4 Release cross fixing        */      
/* BugID  : PNR2.0_26143              */      
/************************************************************************************/        
/* modified by  : Makesh Prabu. R                                          */      
/* date         : 30-March-2010                                            */      
/* description  : To add phase3 & phase4 Release missing tables      */      
/* BugID   : PNR2.0_26376               */      
/************************************************************************************/      
/* modified by  : Makesh Prabu. R                                           */      
/* date         : 09/April/2010                                             */      
/* description  : cross fixing               */      
/* BugID  : PNR2.0_26526               */      
/****************************************************************************************/        
/* modified by  : Makesh Prabu R              */      
/* date         : 10-Aug-2010               */      
/* description  : cross fixing -- resolvelist_data_map tables       */      
/* BugID  : PNR2.0_26755                */      
/****************************************************************************************/      
/* modified by  : Gankan. G                */      
/* date         : 29-November-2010              */      
/* description  : Modified to add new column for existing table       */      
/* BugID  : PNR2.0_26940                */      
/****************************************************************************************/      
/*  Modified By : Gankan. G                */      
/*  Call ID  : PNR2.0_28990               */      
/*  Date  : 30-November-2010              */      
/*  Description : script modified to include new columns for Solutioning Tables   */      
/****************************************************************************************/      
/* modified by  : Gankan. G                */      
/* date         : 01-July-2011               */      
/* description  : Code Modified to add new column for existing table     */      
/* BugID  : PNR2.0_31428                */      
/****************************************************************************************/      
/* modified by  : Gankan. G                */      
/* date         : 01-July-2011               */      
/* description  : Code Modified to add new column for existing table     */      
/* BugID  : PNR2.0_31306                */      
/* Fix sent against Primary BugID : PNR2.0_31428          */      
/****************************************************************************************/      
/* modified by  : Gankan. G                */      
/* date         : 01-July-2011               */      
/* description  : Code Modified to add new table for page events      */      
/* BugID  : PNR2.0_30052                */      
/* Fix sent against Primary BugID : PNR2.0_31428          */      
/****************************************************************************************/      
/* modified by  : Gankan. G                */      
/* date         : 20-July-2011               */      
/* description  : Code Modified to avoid page-prefix duplication      */      
/* BugID  : PNR2.0_32470                */      
/****************************************************************************************/      
/*  Modified By : Gankan. G                */      
/*  Call ID  : PNR2.0_35430               */      
/*  Date  : 02-Feb-2012               */      
/*  Description : script modified to include new column for model table     */      
/****************************************************************************************/      
/*  Modified By : Muthupandi S                */      
/*  Call ID  : PLF2.0_05296               */      
/*  Date  : 05-Jul-2013               */      
/*  Description : alias name added for the width column     */      
/****************************************************************************************/      
--- ep_language_met insert has been commented.      
/****************************************************************************************/      
/*  Modified By : SRIKANTH                */      
/*  Call ID  : TECH-46328               */      
/*  Date  : 16-05-2020               */      
/*  Description : Handling Grid Column grouping, calendar , responsive section,         */      
/*      Sync view,focus control for state          */      
/****************************************************************************************/      
/*******************************************************************************************/                                 
/*modified by      :S.Srikanth */                                   
/*date modified      :21/05/2020     */            
/*call-id            :TECH-46556 */            
/*modified purpose   :Handling tables for OffTask ,MDCF template ,Elastic Search       
      ,UPE, Section refinement in Model Reconstruction RVW 2.0 Migration. */                              
/*********************************************************************************************/        
/*******************************************************************************************/                               
/*modified by      :S.Srikanth */                                 
/*date modified      :26/07/2020     */          
/*call-id            :TECH-47484 */          
/*modified purpose   :Synonym name is not populated in ngplf_wr_glossary */  
/*& ngplf_wr_glossary_local_info table while migrating Glance UI with   
modified target component , target activity & target UI name.*/  
/*********************************************************************************************/      
/*modified by		 :Manoj S																 */                                   
/*date modified      :27-Oct-2022															 */            
/*Defect id          :TECH-73972															 */        
/*********************************************************************************************/  
create procedure  engg_mr_Preview_population_203_2_2      
 @dst_customer_name  engg_name,      
 @dst_project_name  engg_name,       
 @temp_ecr_no   engg_name,      
 @reqno     engg_name,      
 @dst_process_name  engg_name,      
 @dst_component_name  engg_name,      
 @user     engg_name,      
 @time     engg_date,      
 @mig_id     engg_name      
as      
begin      
 set nocount on      
      
 -- declaration of temporary variables      
      
   declare  @functionid  engg_name      
         
 --Temporary and formal parameters mapping      
 select @dst_customer_name  = ltrim(rtrim(@dst_customer_name))      
 select  @dst_project_name       = ltrim(rtrim(@dst_project_name))      
 select  @dst_process_name  = ltrim(rtrim(@dst_process_name))       
 select  @dst_component_name  = ltrim(rtrim(@dst_component_name))       
 select  @temp_ecr_no   = ltrim(rtrim(@temp_ecr_no))       
      
 select @functionid  = functionid      
 from fw_bpt_function_component (nolock)      
 where CustomerID  = @dst_customer_name      
 and  ProjectID  = @dst_project_name      
 and  BPID   = @dst_process_name      
 and  componentname = @dst_component_name      
      
 --Populating the Ep level Tables      
 ---commented by senthil       
 --insert into ep_language_met (      
 --  customer_name,   quick_code_type,  quick_code,   quick_code_value,      
 --  timestamp,    createdby,    createddate,  modifiedby,      
 --  modifieddate,   lang_settings)       /*columns added by Makesh prabu for the CallID: PNR2.0_21056*/      
 --select @dst_customer_name,  quick_code_type,  quick_code,   quick_code_value,      
 --  timestamp,    @user,                  @time,     @user,      
 --  @time,     ''       /*columns added by Makesh prabu for the CallID: PNR2.0_21056*/      
 --from es_language_met  a (nolock)      
 --where not exists (      
 --      select 'x'      
 --      from ep_language_met  c (nolock)      
 --      where   c.quick_code_type = a.quick_code_type      
 --      and  c.quick_code  = a.quick_code)      
             
-- /*code added by Makesh prabu for the CallID: PNR2.0_21056-- starts*/      
-- SET QUOTED_IDENTIFIER OFF      
--      
-- update ep_language_met      
-- set lang_settings =     "&lt;html dir='rtl' lang='ar' xml:lang='ar' xmlns='http://www.w3.org/1999/xhtml'&gt;"      
-- where quick_code_value = 'Arabic'      
-- /*code added by Makesh prabu for the CallID: PNR2.0_21056-- ends*/      
      
 insert into ep_quick_code_mst (      
   timestamp,    quick_code_type,  quick_code,   quick_code_value,      
   createdby,    createddate,   modifiedby,   modifieddate)      
 select timestamp,    quick_code_type,  quick_code,   quick_code_value,      
   @user,                 @time,      @user,    @time      
 from es_quick_code_mst a (nolock)      
 where not exists (      
      select 'x'      
      from ep_quick_code_mst c (nolock)      
      where c.quick_code_type = a.quick_code_type      
      and  c.quick_code  = a.quick_code)      
      
      
 insert into ep_review (      
   customer_name,   project_name,   reviewset_no,  workrequest_no,      
   reviewset_date,   reviewpoint,   timestamp,   createdby,      
   createddate,   modifiedby,    modifieddate,  purpose,      
   reviewsetstatus)      
 select @dst_customer_name,  @dst_project_name,  reviewset_no,  @reqno,      
   reviewset_date,   reviewpoint,   timestamp,   @user,      
   @time,      @user,     @time,    purpose,      
   reviewstatus      
 from es_review   a (nolock)       
 where a.customer_name       = @dst_customer_name      
 and  a.project_name    = @dst_project_name       
 and  not exists (      
      select 'x'    
      from ep_review c (nolock)      
      where c.customer_name  = @dst_customer_name      
      and  c.project_name  = @dst_project_name      
      and  c.reviewset_no  =  a.reviewset_no      
      and  c.workrequest_no = @reqno      
      and  c.reviewpoint  = a.reviewpoint)      
      
       
 insert into ep_review_dtl(      
   customer_name,   project_name,   reviewset_no,  review_type,      
   deliverable_type,  level1,     level2,    level3,      
   reviewsetstatus,  timestamp,    createdby,   createddate,      
   modifiedby,    modifieddate)      
 select @dst_customer_name,  @dst_project_name,  reviewset_no,  review_type,      
   deliverable_type,  level1,     level2,    level3,      
   reviewsetstatus,  timestamp,    @user,    @time,      
   @user,     @time      
 from es_review_dtl   a (nolock)       
 where a.customer_name       = @dst_customer_name      
 and  a.project_name    = @dst_project_name       
 and  not exists (      
      select 'x'      
      from ep_review_dtl c (nolock)      
      where c.customer_name  = @dst_customer_name      
      and  c.project_name  = @dst_project_name      
      and  c.reviewset_no  =  a.reviewset_no      
      and  c.review_type  =  a.review_type      
      and  c.deliverable_type = a.deliverable_type      
      and  c.level1   = a.level1            
      and  c.level2   = a.level2      
      and  c.level3   = a.level3)      
            
 insert into ep_review_type(      
   customer_name,   project_name,   reviewset_no,  review_type,      
   timestamp,    createdby,    createddate,  modifiedby,      
   modifieddate)      
 select @dst_customer_name,  @dst_project_name,  reviewset_no,  review_type,      
   timestamp,    @user,     @time,    @user,      
   @time      
 from es_review_type  a (nolock)       
 where a.customer_name       = @dst_customer_name      
 and  a.project_name    = @dst_project_name       
 and  not exists (      
      select 'x'      
      from ep_review_type c (nolock)      
      where c.customer_name  = @dst_customer_name      
      and  c.project_name  = @dst_project_name      
      and  c.reviewset_no  =  a.reviewset_no      
      and  c.review_type  =  a.review_type)      
       
 update  a       
 set  a.ref_bt_synonym_name = null      
 from de_published_glossary a(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  RTrim(IsNull(a.ref_bt_synonym_name, '')) = ''      
      
  --insert into ep_glossary_mst (      
  --  customer_name,   project_name,   req_no,      bt_synonym_name,      
  --  data_type,    length,     bt_synonym_caption,   glossary_sysid,      
  --  timestamp,    createdby,    createddate,    modifiedby,      
  --  modifieddate,   ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
  --  synonym_status,   singleinst_sample_data, multiinst_sample_data)      
  --select distinct      
  --  customer_name,   project_name,   'base',      a.bt_synonym_name,      
  --  data_type,    length,     bt_synonym_caption,   newid(),      
  --  timestamp,    @user,     @time,      @user,      
  --  @time,     ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
  --  synonym_status,   singleinst_sample_data, multiinst_sample_data      
  --from de_published_glossary a (nolock)      
  --where a.customer_name  = @dst_customer_name       
  --and  a.project_name   = @dst_project_name      
  --and  a.process_name   = @dst_process_name      
  --and  a.component_name  = @dst_component_name      
  --and  a.ecrno    = @temp_ecr_no      
  --and  not exists (      
  --     select 'x'      
  --     from ep_glossary_mst  c (nolock)      
  --     where c.customer_name  = a.customer_name       
  --     and  c.project_name   = a.project_name      
  --     and  c.req_no    = 'base'      
  --     and  c.bt_synonym_name = a.bt_synonym_name)      
       
  --insert into ep_glossary_mst (      
  --  customer_name,   project_name,   req_no,      bt_synonym_name,      
  --  data_type,    length,     bt_synonym_caption,   glossary_sysid,      
  --  timestamp,    createdby,    createddate,    modifiedby,      
  --  modifieddate,   ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
  --  synonym_status,   singleinst_sample_data, multiinst_sample_data)      
  --select distinct      
 --  a.customerid,   a.projectid,   'base',      a.activityid,      
  --  'char',     '40',     a.activityname,    newid(),       
  --  1,      @user,     @time,      @user,      
  --  @time,     null,     a.ActivityDesc,    null,      
  --  'R',     null,     null      
  --from fw_bpt_activity    a (nolock),      
  --  fw_bpt_function_component b (nolock)      
  --where a.CustomerID = @dst_customer_name      
  --and  a.ProjectID  = @dst_project_name      
  --and  a.BPID   = @dst_process_name      
  --and  a.FunctionID = @functionid      
  --and  a.CustomerID = b.CustomerID      
  --and  a.ProjectID  = b.ProjectID      
  --and  a.BPID   = b.BPID      
  --and  a.FunctionID = b.FunctionID      
  --and  b.componentname = @dst_component_name      
  --and  not exists (      
  --      select 'x'      
  --      from ep_glossary_mst  c (nolock)      
  --      where c.customer_name  = a.CustomerID       
  --      and  c.project_name   = a.ProjectID      
  --      and  c.req_no    = 'base'      
  --      and  c.bt_synonym_name = a.activityid)       
      
      
 update  a       
 set  a.ref_bt_synonym_name = null      
 from de_published_glossary_lng_extn a(nolock)      
 where a.customer_name  = @dst_customer_name      
and  a.project_name  = @dst_project_name      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  RTrim(IsNull(a.ref_bt_synonym_name, '')) = ''      
      
--  insert into ep_glossary_mst_lng_extn(      
--    customer_name,   project_name,   req_no,      bt_synonym_name,      
--    data_type,    length,     bt_synonym_caption,   glossary_sysid,      
--    timestamp,    createdby,    createddate,    modifiedby,      
--    modifieddate,   ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
--    synonym_status,   singleinst_sample_data, multiinst_sample_data,  languageid)      
--  select customer_name,   project_name,   'base',      a.bt_synonym_name,      
--    data_type,    length,     bt_synonym_caption,   newid(),      
--    timestamp,    @user,     @time,      @user,      
--    @time,     ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
--    synonym_status,   singleinst_sample_data, multiinst_sample_data,  a.languageid      
--  from de_published_glossary_lng_extn a (nolock)      
--  where a.customer_name  = @dst_customer_name       
--  and  a.project_name   = @dst_project_name      
--  and  a.process_name   = @dst_process_name      
--  and  a.component_name  = @dst_component_name      
--  and  a.ecrno    = @temp_ecr_no      
--  and  not exists (      
--       select 'x'      
--       from ep_glossary_mst_lng_extn  c (nolock)      
--       where c.customer_name  = a.customer_name       
--       and  c.project_name   = a.project_name      
--       and  c.req_no    = 'base'      
--       and  c.bt_synonym_name = a.bt_synonym_name       
--       and  c.languageid  = a.languageid)      
--       
--  insert into ep_glossary_mst_lng_extn(      
--    customer_name,   project_name,   req_no,      bt_synonym_name,      
--    data_type,    length,     bt_synonym_caption,   glossary_sysid,      
--    timestamp,    createdby,    createddate,    modifiedby,      
--    modifieddate,   ref_bt_synonym_name, bt_synonym_doc,    bt_name,      
--    synonym_status,   singleinst_sample_data, multiinst_sample_data,  languageid)      
--  select a.customerid,   a.projectid,   'base',      a.activityid,         
--    'char',     '40',     a.activityname,    newid(),          
--    1,      @user,     @time,      @user,          
--    @time,     null,     a.ActivityDesc,    null,          
--    'R',     null,     null,      a.LangID         
--  from fw_bpt_activity    a (nolock),      
--    fw_bpt_function_component b (nolock)      
--  where a.CustomerID = @dst_customer_name      
--  and  a.ProjectID  = @dst_project_name      
--  and  a.BPID   = @dst_process_name      
--  and  a.FunctionID = @functionid      
--  and  a.CustomerID = b.CustomerID      
--  and  a.ProjectID  = b.ProjectID      
--  and  a.BPID   = b.BPID      
--  and  a.FunctionID = b.FunctionID      
--  and  b.componentname = @dst_component_name      
--  and  not exists (      
--       select 'x'      
--       from ep_glossary_mst_lng_extn  c (nolock)      
--       where c.customer_name  = a.CustomerID       
--       and  c.project_name   = a.ProjectID      
--       and  c.req_no    = 'base'      
--       and  c.bt_synonym_name = a.activityid      
--       and  c.languageid  = a.langid)      
       
      
--  select 'insert into ep_component_glossary_mst table'      
 insert into ep_component_glossary_mst (      
   customer_name,   project_name,   req_no,    process_name,      
   component_name,   bt_synonym_name,  data_type,   length,      
   bt_synonym_caption,  glossary_sysid,   timestamp,   createdby,      
   createddate,   modifiedby,    modifieddate,  ref_bt_synonym_name,      
   bt_synonym_doc,   bt_name,    synonym_status,  singleinst_sample_data,      
   multiinst_sample_data  )      
 select a.customer_name,  a.project_name,   'base',    a.process_name,      
   a.component_name,  a.bt_synonym_name,  a.data_type,  a.length,      
   a.bt_synonym_caption, a.glossary_sysid,  a.timestamp,  @user,      
   @time,     @user,     @time,    a.ref_bt_synonym_name,      
   a.bt_synonym_doc,  a.bt_name,    a.synonym_status, a.singleinst_sample_data,     
   a.multiinst_sample_data        
 from de_published_glossary a (nolock)      
 where a.customer_name  = @dst_customer_name       
 and  a.project_name   = @dst_project_name      
 and  a.process_name   = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  not exists  ( select '*'      
        from ep_component_glossary_mst c (nolock)      
        where c.customer_name  = a.customer_name       
        and  c.project_name   = a.project_name      
        and  c.req_no    = 'base'      
        and  c.process_name   = a.process_name      
        and  c.component_name  = a.component_name      
        and  c.bt_synonym_name = a.bt_synonym_name      
       )      
      
 -- code modified by kalai on April 12 2007      
      
 insert into ep_component_glossary_mst (      
   customer_name,   project_name,   req_no,    process_name,      
   component_name,   bt_synonym_name,  data_type,   length,      
   bt_synonym_caption,  glossary_sysid,   timestamp,   createdby,      
   createddate,   modifiedby,    modifieddate,  ref_bt_synonym_name,      
   bt_synonym_doc,   bt_name,    synonym_status,  singleinst_sample_data,      
   multiinst_sample_data  )      
 select a.customerid,   a.projectid,   'base',    a.bpid,      
   a.componentname,  a.componentname,  'char',    '40',      
   a.componentname,  newid(),    1,     @user,      
   @time,     @user,     @time,    null,      
   a.componentname,  null,     'R',    null,      
   null      
 from fw_bpt_function_component a (nolock)      
 where a.CustomerID = @dst_customer_name      
 and  a.ProjectID  = @dst_project_name      
 and  a.BPID   = @dst_process_name      
 and  a.ComponentName = @dst_component_name      
 and  not exists  ( select '*'      
        from ep_component_glossary_mst c (nolock)      
        where c.customer_name  = a.CustomerID      
        and  c.project_name   = a.ProjectID      
        and  c.req_no    = 'base'      
        and  c.process_name   = a.BPID      
        and  c.component_name  = a.ComponentName      
        and  c.bt_synonym_name = @dst_component_name      
       )      
      
 insert into ep_component_glossary_mst (      
   customer_name,   project_name,   req_no,    process_name,      
   component_name,   bt_synonym_name,  data_type,   length,      
   bt_synonym_caption,  glossary_sysid,   timestamp,   createdby,      
   createddate,   modifiedby,    modifieddate,  ref_bt_synonym_name,      
   bt_synonym_doc,   bt_name,    synonym_status,  singleinst_sample_data,      
   multiinst_sample_data  )      
 select a.customerid,   a.projectid,   'base',    a.bpid,      
   b.componentname,  a.activityid,   'char',    '40',      
   a.activityname,   newid(),    1,     @user,      
   @time,     @user,     @time,    null,      
   a.ActivityDesc,   null,     'R',    null,      
   null      
 from fw_bpt_activity    a (nolock),      
   fw_bpt_function_component b (nolock)      
 where a.CustomerID = @dst_customer_name      
 and  a.ProjectID  = @dst_project_name      
 and  a.BPID   = @dst_process_name      
 and  a.FunctionID = @functionid      
 and  a.CustomerID = b.CustomerID      
 and  a.ProjectID  = b.ProjectID      
 and  a.BPID   = b.BPID      
 and  a.FunctionID = b.FunctionID      
 and  b.componentname = @dst_component_name      
 and  not exists ( select '*'      
       from ep_component_glossary_mst gls (nolock)      
       where gls.customer_name = a.customerid      
       and  gls.project_name = a.projectid      
       and  gls.req_no   = 'base'      
       and  gls.process_name = a.bpid      
       and  gls.component_name = b.componentname      
       and  gls.bt_synonym_name = a.activityid      
      )      
       
-- code added by kalai on 27 Sep 2006      
       
 insert into ep_component_glossary_mst (      
   customer_name,   project_name,   req_no,    process_name,      
   component_name,   bt_synonym_name,  data_type,   length,      
   bt_synonym_caption,  glossary_sysid,   timestamp,   createdby,      
   createddate,   modifiedby,    modifieddate,  ref_bt_synonym_name,      
   bt_synonym_doc,   bt_name,    synonym_status,  singleinst_sample_data,      
   multiinst_sample_data  )      
 select a.customerid,   a.projectid,   'base',    a.bpid,      
   b.componentname,  a.UIID,     'char',    '40',      
   a.UIName,    newid(),    1,     @user,      
   @time,     @user,     @time,    null,      
   a.UIDesc,    null,     'R',    null,      
   null      
 from fw_bpt_ui    a (nolock),      
   fw_bpt_function_component b (nolock)      
 where a.CustomerID = @dst_customer_name      
 and  a.ProjectID  = @dst_project_name      
 and  a.BPID   = @dst_process_name      
 and  a.FunctionID = @functionid      
 and  a.CustomerID = b.CustomerID      
 and  a.ProjectID  = b.ProjectID      
 and  a.BPID   = b.BPID      
 and  a.FunctionID = b.FunctionID      
 and  b.componentname = @dst_component_name      
 and  not exists ( select '*'      
       from ep_component_glossary_mst gls (nolock)      
       where gls.customer_name = a.customerid      
       and  gls.project_name = a.projectid      
       and  gls.req_no   = 'base'      
       and  gls.process_name = a.bpid      
       and  gls.component_name = b.componentname      
       and  gls.bt_synonym_name = a.UIID      
      )      
-- code ends here      
      
--  select 'insert into ep_component_glossary_mst_lng_extn table'      
-- insert into ep_component_glossary_mst_lng_extn      
--   ( customer_name,    project_name,   req_no,    process_name,      
--    component_name,    bt_synonym_name,  data_type,   length,      
--    bt_synonym_caption,   glossary_sysid,   languageid,   timestamp,      
--    createdby,     createddate,   modifiedby,   modifieddate,      
--    ref_bt_synonym_name,  bt_synonym_doc,   bt_name,   synonym_status,      
--    singleinst_sample_data,  multiinst_sample_data      
--   )      
-- select  a.customer_name,   a.project_name,   'base',    a.process_name,      
--    a.component_name,   a.bt_synonym_name,  a.data_type,  a.length,      
--    a.bt_synonym_caption,  a.glossary_sysid,  a.languageid,  a.timestamp,      
--    @user,      @time,     @user,    @time,      
--    a.ref_bt_synonym_name,  a.bt_synonym_doc,  a.bt_name,   a.synonym_status,      
--    a.singleinst_sample_data, a.multiinst_sample_data      
-- from  de_published_glossary_lng_extn a (nolock)      
-- where  a.customer_name  = @dst_customer_name       
-- and   a.project_name   = @dst_project_name      
-- and   a.process_name   = @dst_process_name      
-- and   a.component_name  = @dst_component_name      
-- and   a.ecrno    = @temp_ecr_no      
-- and   not exists  ( select '*'      
--         from ep_component_glossary_mst_lng_extn c (nolock)      
--         where c.customer_name  = a.customer_name       
--         and  c.project_name   = a.project_name      
--         and  c.req_no    = 'base'      
--         and  c.process_name   = a.process_name      
--         and  c.component_name  = a.component_name      
--         and  c.bt_synonym_name = a.bt_synonym_name      
--        )      
      
-- insert into ep_component_glossary_mst_lng_extn      
--   ( customer_name,    project_name,   req_no,    process_name,      
--    component_name,    bt_synonym_name,  data_type,   length,      
--    bt_synonym_caption,   glossary_sysid,   languageid,   timestamp,      
--    createdby,     createddate,   modifiedby,   modifieddate,      
--    ref_bt_synonym_name,  bt_synonym_doc,   bt_name,   synonym_status,      
--    singleinst_sample_data,  multiinst_sample_data      
--   )      
-- select  a.customerid,    a.projectid,   'base',    a.bpid,      
--    b.componentname,   a.activityid,   'char',    '40',      
--    a.activityname,    newid(),    a.LangID,   1,      
--    @user,      @time,     @user,    @time,      
--    null,      a.ActivityDesc,   null,    'R',          
--    null,      null      
-- from  fw_bpt_activity    a (nolock),      
--    fw_bpt_function_component b (nolock)      
-- where  a.CustomerID = @dst_customer_name      
-- and   a.ProjectID  = @dst_project_name      
-- and   a.BPID   = @dst_process_name      
-- and   a.FunctionID = @functionid      
-- and   a.CustomerID = b.CustomerID      
-- and   a.ProjectID  = b.ProjectID      
-- and   a.BPID   = b.BPID      
-- and   a.FunctionID = b.FunctionID      
-- and   b.componentname = @dst_component_name      
-- and   not exists ( select '*'      
--        from ep_component_glossary_mst_lng_extn gls (nolock)      
--        where gls.customer_name = a.customerid      
--        and  gls.project_name = a.projectid      
--        and  gls.req_no   = 'base'      
--        and  gls.process_name = a.bpid      
--        and  gls.component_name = b.componentname      
--        and  gls.bt_synonym_name = a.activityid      
--        and  gls.languageid  = a.langid      
--       )      
      
---- code modified by kalai 27 Sep 2006      
      
-- insert into ep_component_glossary_mst_lng_extn      
--   ( customer_name,    project_name,   req_no,    process_name,      
--    component_name,    bt_synonym_name,  data_type,   length,      
--    bt_synonym_caption,   glossary_sysid,   languageid,   timestamp,      
--    createdby,     createddate,   modifiedby,   modifieddate,      
--    ref_bt_synonym_name,  bt_synonym_doc,   bt_name,   synonym_status,      
--    singleinst_sample_data,  multiinst_sample_data      
--   )      
-- select  a.customerid,    a.projectid,   'base',    a.bpid,      
--    b.componentname,   a.UIID,     'char',    '40',      
--    a.UIName,     newid(),    a.LangID,   1,      
--    @user, @time,     @user,    @time,      
--    null,      a.UIDesc,    null,    'R',          
--    null,      null      
-- from  fw_bpt_ui     a (nolock),      
--    fw_bpt_function_component b (nolock)      
-- where  a.CustomerID = @dst_customer_name      
-- and   a.ProjectID  = @dst_project_name      
-- and   a.BPID   = @dst_process_name      
-- and   a.FunctionID = @functionid      
-- and   a.CustomerID = b.CustomerID      
-- and   a.ProjectID  = b.ProjectID      
-- and   a.BPID   = b.BPID      
-- and   a.FunctionID = b.FunctionID      
-- and   b.componentname = @dst_component_name      
-- and   not exists ( select '*'      
--        from ep_component_glossary_mst_lng_extn gls (nolock)      
--        where gls.customer_name = a.customerid      
--        and  gls.project_name = a.projectid      
--        and  gls.req_no   = 'base'      
--        and  gls.process_name = a.bpid      
--        and  gls.component_name = b.componentname      
--        and  gls.bt_synonym_name = a.UIID      
--        and  gls.languageid  = a.langid      
--       )      
      
-- code ends here      
      
--  select 'insert into ep_ui_mst table'      
 insert into ep_ui_mst      
     (customer_name,              project_name,               req_no,               process_name,      
   component_name,             activity_name,              ui_name,                    ui_descr,      
   ui_type,                    ui_format,                  caption_alignment,          trail_bar,      
   tab_height,                 ui_sysid,                   timestamp,                  createdby,      
   createddate,                modifiedby,                 modifieddate,               current_req_no,      
   ui_doc,                     base_component_name,        base_activity_name,         base_ui_name,      
   grid_type,     state_processing,   wrkreqno,     callout_type , --ExtJs Release      
   taskpane_req ,    New_Line_Ui,    Tab_Type,     TabPosition,      
   PostLaunchTask,    SmartHide,     Is_device,     HideIlbotitlemenu_req,      
   personalization,   Exclude_Systemtabindex,  DeviceType,     TabStyle,      
   IsDesktop,     Hide_Print,     Layout,      XYCoordinates,      
   ColumnLayWidth,    TabHeaderPostion,   TabRotation,    isglance,   /* New column added by Gankan.G for the CaseId: PNR2.0_30052*/ /*13705 for adding isglance for id -TECH-46028 */      
   hide_imp_defaults   ,ui_subtype     ,DBName      ,NativeApplication --By SRIKANTH for TECH-46328      
   ,Conditional_popupclose  ,Titlebar_Search)--By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,      
   a.component_name,           a.activity_name,            a.ui_name,                  a.ui_descr,      
   a.ui_type,                  a.ui_format,                a.caption_alignment,        a.trail_bar,      
   a.tab_height,               newid(),                   a.timestamp,                @user,      
   @time,      @user,                    @time,                   @reqno,      
   a.ui_doc,                   a.base_component_name,      a.base_activity_name,       a.base_ui_name,      
   grid_type,     state_processing,   '',       callout_type, --ExtJs Release      
   taskpane_req  ,    New_Line_Ui,    Tab_Type,     TabPosition,      
   PostLaunchTask,    SmartHide,     Is_device,     HideIlbotitlemenu_req,      
   personalization,   Exclude_Systemtabindex,  DeviceType,     TabStyle,      
   IsDesktop,     Hide_Print,     Layout,      XYCoordinates,      
   ColumnLayWidth,    TabHeaderPostion,   TabRotation,    a.isglance,/* New column added by Gankan.G for the CaseId: PNR2.0_30052*/ /*13705 for adding isglance for id -TECH-46028 */      
   hide_imp_defaults   ,ui_subtype     ,DBName      ,NativeApplication --By SRIKANTH for TECH-46328      
   ,Conditional_popupclose  ,Titlebar_Search --By SRIKANTH for TECH-46328      
 from de_published_ui    a (nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name   = @dst_project_name      
 and  a.process_name   = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  not exists ( select 'x'      
       from ep_ui_mst  c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
      )      
      
--  select 'insert into ep_ui_mst_lng_extn table'      
 insert into ep_ui_mst_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    ui_descr,              
   ui_type,                    ui_format,                  caption_alignment,          trail_bar,                       
   tab_height,                 ui_sysid,                   languageid,                 timestamp,                       
   createdby,                  createddate,                modifiedby,                 modifieddate,                    
   current_req_no,             ui_doc,                     base_component_name,        base_activity_name,              
   base_ui_name      
  )      
 select a.customer_name,             a.project_name,            'base',                     a.process_name,                    
   a.component_name,            a.activity_name,           a.ui_name,                  a.ui_descr,              
   a.ui_type,                   a.ui_format,               a.caption_alignment,        a.trail_bar,                       
   a.tab_height,                newid(),                   a.languageid,               a.timestamp,                       
   @user,                     @time,                @user,                    @time,             
   a.current_req_no,            a.ui_doc,                  a.base_component_name,      a.base_activity_name,              
   a.base_ui_name      
 from de_published_ui_lng_extn  a (nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name   = @dst_project_name      
 and  a.process_name   = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  not exists ( select 'x'      
       from ep_ui_mst_lng_extn c (nolock)      
       where   c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name         
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name      = a.component_name           
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.languageid           = a.languageid      
       )      
      
--  select 'insert into ep_ui_req_dtl table'       
      
 insert into ep_ui_req_dtl      
     (customer_name,              project_name,               req_no,               process_name,                    
   component_name,           activity_name,              ui_name,                  req_descr,                       
   process_descr,              component_descr,            activity_descr,           ui_descr,                        
   ui_status,                  req_status,                 req_download_date,        req_sysid,                       
   ui_sysid,                   timestamp,                  createdby,                createddate,                     
   modifiedby,                 modifieddate,               req_publish_date)      
 select distinct       
   a.customer_name,            a.project_name,             @reqno,                a.process_name,        
   a.component_name,           a.activity_name,            a.ui_name,                'WorkReq for '+a.component_name,      
   c.process_descr,            c.component_descr,          c.activity_descr,         a.ui_descr,           
--   'C',      'C',         @time,        left(right(a.activity_name,15)+left(a.ui_name,15)+right(@reqno,10),40),      
   'C',      'C',         @time,        newid(),      
   b.ui_sysid,     a.timestamp,                @user,                   @time,                     
   @user,                    @time,                ''        
 from de_published_ui   a  (nolock),      
   ep_ui_mst    b  (nolock),      
   fw_bpt_re_namedesc_vw c  (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno        = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name      
 and  b.customer_name    = c.customer_name      
 and  b.project_name    = c.project_name      
 and  b.process_name    = c.process_name      
 and  b.component_name   = c.component_name      
 and  b.activity_name    = c.activity_name      
 and  b.ui_name     = c.ui_name      
 and  not exists ( select 'x'      
       from ep_ui_req_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = @reqno      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       )      
      
 update a      
 set  a.req_descr     = 'BASE'      
 from ep_ui_req_dtl     a (nolock),      
   engg_mr_ui_mst_203_1 b (nolock)      
 where a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  a.req_no   = 'Base'      
 and  a.customer_name  = b.dst_customer_name      
 and  a.project_name  = b.dst_project_name      
 and  a.process_name  = b.dst_process_name      
 and  a.component_name = b.dst_component_name      
 and  a.activity_name  = b.dst_activity_name      
 and  a.ui_name   = b.dst_ui_name      
 and  b.act_mig_flag  = 1        
 and  b.mig_id   = @mig_id      
      
      
  --select 'insert into ep_ui_page_dtl table'       
 insert into ep_ui_page_dtl      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   horder,                     vorder,                     ui_page_sysid,              ui_sysid,                        
   timestamp,                  createdby,                  createddate,                modifiedby,                      
   modifieddate,               page_doc,                   page_prefix,    wrkreqno,      
   PageClass,     page_Type,          pageimage,                  width,      
   HeaderPosition,    TabRotation,    TabTitleStyle,    TabIconPosition,      
   PageLayout,     XYCoordinates,    ColumnLayWidth   )  --ExtJs Release  /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,      
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,        
   a.horder,                   a.vorder,                   newid(),               b.ui_sysid,                        
   a.timestamp,                @user,                  @time,                  @user,                      
   @time,                a.page_doc,                 a.page_prefix,    '',      
   a.PageClass,    a.page_Type,             a.pageimage,    width, --ExtJs Release  /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
   a.HeaderPosition,   a.TabRotation,    a.TabTitleStyle,   a.TabIconPosition,      
   a.PageLayout,    a.XYCoordinates,   a.ColumnLayWidth        
 from de_published_ui_page a (nolock),      
   ep_ui_mst    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  not exists ( select 'x'      
       from ep_ui_page_dtl c (nolock)      
       where  c.customer_name   = a.customer_name          
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       )      
       
--  select 'insert into ep_ui_page_dtl_lng_extn table'        
 insert into ep_ui_page_dtl_lng_extn      
     (customer_name,              project_name,      req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   horder,                     vorder,                     ui_page_sysid,              ui_sysid,                        
   languageid,       timestamp,        createdby,                  createddate,                     
   modifiedby,                 modifieddate,               page_doc,                   page_prefix,      
   wrkreqno,     PageClass,     page_Type,     pageimage,                        
   width) /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,               
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.horder,                   a.vorder,                   newid(),               b.ui_sysid,                        
   a.languageid,               a.timestamp,                @user,                  @time,                   
   @user,                  @time,                 a.page_doc,                 a.page_prefix,      
   '',       PageClass,                  page_Type,                  pageimage,             
   width /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
 from de_published_ui_page_lng_extn a (nolock),      
   ep_ui_mst      b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name     = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  not exists ( select 'x'      
       from ep_ui_page_dtl_lng_extn c (nolock)      
       where  c.customer_name  = a.customer_name              
       and  c.project_name   = a.project_name        
       and  c.req_no        = 'base'      
       and  c.process_name      = a.process_name      
       and  c.component_name    = a.component_name            
       and  c.activity_name     = a.activity_name            
       and  c.ui_name           = a.ui_name      
       and  c.page_bt_synonym   = a.page_bt_synonym      
       and  c.languageid        = a.languageid      
       )      
             
/*Code modified by Gankan.G for the CaseId:PNR2.0_32470 to avoid page-prefix duplication starts*/      
 exec engg_mr_gen_page_prefix_203_2_2  @mig_id      
       
 Update a      
 set a.page_prefix = b.page_prefix      
 from ep_ui_page_dtl_lng_extn a(nolock),      
   ep_ui_page_dtl b(nolock),      
   engg_mr_ui_mst_203_1 c(nolock)      
 where a.customer_name  = b.customer_name        
 and  a.project_name  = b.project_name        
 and  a.process_name  = b.process_name        
 and  a.component_name = b.component_name       
 and  a.activity_name  = b.activity_name        
 and  a.ui_name   = b.ui_name         
 and  a.page_bt_synonym = b.page_bt_synonym       
 and  a.customer_name  = c.dst_customer_name        
 and  a.project_name  = c.dst_project_name      
 and  a.process_name  = c.dst_process_name        
 and  a.component_name = c.dst_component_name       
 and  a.activity_name  = c.dst_activity_name        
 and  a.ui_name   = c.dst_ui_name       
 and  c.mig_id   = @mig_id        
       
/*Code modified by Gankan.G for the CaseId:PNR2.0_32470 to avoid page-prefix duplication ends*/      
       
       
--  select 'insert into ep_ui_section_dtl table'         
 insert into ep_ui_section_dtl      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         visisble_flag,              title_required,             border_required,                 
   title_alignment,            parent_section,             horder,                     vorder,                          
   ui_section_sysid,           page_sysid,                 timestamp,                  createdby,                       
   createddate,                modifiedby,                 modifieddate,               section_doc,      
   width,      height,      section_type,    ctrl_caption_align,      
   SectionPrefixClass,   caption_Format,    Section_width_Scalemode, Section_height_Scalemode,      
   wrkreqno,     section_prefix ,   Associated_control,   splitter_pos,            
   NColSpan,     NRowSpan,     section_collapse,   section_collapsemode,      
   CarouselNavigation,         cell_spacing,    cell_padding,    Region,      
   TitlePosition,    CollapseDir,    SectionLayout,    XYCoordinates,          
   ColumnLayWidth,    IsPlatform     ,Slidingbar_height   ,IsResponsive --code added for the bugid:PNR2.0_35430 --By SRIKANTH for TECH-46328      
   ,mob_pop_fullview)  --By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.visisble_flag,            a.title_required,           a.border_required,              
   a.title_alignment,          a.parent_section,           a.horder,                   a.vorder,                          
   newid(),             b.ui_page_sysid,            a.timestamp,                a.createdby,                       
   @time,                 @user,                  @time,       a.section_doc,      
   a.width,     a.height,     a.section_type,    a.ctrl_caption_align,--Code modified by Muthupandi S for the call PLF2.0_05296      
   a.SectionPrefixClass,  a.caption_Format,   a.Setion_width_Scalemode, a.Setion_height_Scalemode,      
   '',       a.section_prefix,   a.Associated_control,  a.splitter_pos ,      
   a.NColSpan,     a.NRowSpan,     a.section_collapse,   a.section_collapsemode,      
   a.CarouselNavigation,  a.cell_spacing,    a.cell_padding,    a.Region,      
   a.TitlePosition,   a.CollapseDir,    a.SectionLayout,   a.XYCoordinates,          
   a.ColumnLayWidth,   a.IsPlatform      ,a.Slidingbar_height     ,a.IsResponsive --code added for the bugid:PNR2.0_35430 --By SRIKANTH for TECH-46328      
     ,a.mob_pop_fullview  --By SRIKANTH for TECH-46328       
 from de_published_ui_section a (nolock),      
   ep_ui_page_dtl   b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name   = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  not exists ( select 'x'      
       from ep_ui_section_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name         
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name          
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       )      
      
--  select 'insert into ep_ui_section_dtl_lng_extn table'          
 insert into ep_ui_section_dtl_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                 page_bt_synonym,                 
   section_bt_synonym,         visisble_flag,              title_required,             border_required,                 
   title_alignment,            parent_section,             horder,             vorder,                          
   ui_section_sysid,           page_sysid,                 languageid,                 timestamp,                       
   createdby,                  createddate,                modifiedby,                 modifieddate,                    
   section_doc,    Associated_control,   splitter_pos,    NColSpan,        
   NRowSpan) --code added for the bugid:PNR2.0_35430      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                a.page_bt_synonym,                 
   a.section_bt_synonym,       a.visisble_flag,            a.title_required, a.border_required,                 
   a.title_alignment,          a.parent_section,           a.horder,             a.vorder,                          
   newid(),             b.ui_page_sysid,            a.languageid,               a.timestamp,                       
   @user,          @time,                  @user,                  @time,                    
   section_doc,    Associated_control,   splitter_pos,    NColSpan,        
   NRowSpan  --code added for the bugid:PNR2.0_35430      
 from de_published_ui_section_lng_extn  a (nolock),      
   ep_ui_page_dtl      b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  not exists ( select 'x'      
       from ep_ui_section_dtl_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.languageid   = a.languageid)      
       
--  select 'insert into ep_ui_control_dtl table'           
 insert into ep_ui_control_dtl      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,           ui_name,                 page_bt_synonym,                 
   section_bt_synonym,      control_bt_synonym,         control_type,               horder,                          
   vorder,                     order_seq,                  data_column_width,          label_column_width,              
   ui_control_sysid,           ui_section_sysid,           timestamp,                  createdby,                       
   createddate,                modifiedby,                 modifieddate,               control_id,                      
   view_name,                  visisble_length,            proto_tooltip,              sample_data,               control_doc,               control_prefix,             label_control_id,          label_column_scalemode,          
/*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008 starts*/      
   data_column_scalemode,  tab_seq,     help_tabstop,    LabelClass,      
   ControlClass,    LabelImageClass,   ControlImageClass,   wrkreqno,      
   Set_User_Pref,    AccessKey,     freezecount,    controlimage,          
   colspan,     rowspan,     TemplateID,     Preserve_visible_length,      
   Auto_width_column,   TemplateCategory,   TemplateSpecific,   Control_class_ext6, /*columns added by Gankan. G for bug_id: PNR2.0_26940 on 29-Nov-2010*/ /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008 ends*/      
   icon_position    ,icon_class     ,sensitivedata    ,IsPlatform --By SRIKANTH for TECH-46328      
   ,DynamicStyle    ,ImageAsData    ,MoreEventEnabled   ,UpeSetFocusEnabled) --By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.control_type,             a.horder,                          
   a.vorder,                   a.order_seq,                a.data_column_width,        a.label_column_width,              
   newid(),       b.ui_section_sysid,         a.timestamp,                @user,                       
   @time,                @user,                  @time,                  a.control_id,                      
   a.view_name,                a.visisble_length,          a.proto_tooltip,            a.sample_data,                   
   a.control_doc,              a.control_prefix,           label_control_id,   a.label_column_scalemode,          
/*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008 starts*/      
   a.data_column_scalemode, tab_seq,     help_tabstop,    LabelClass,      
   ControlClass,    LabelImageClass,   ControlImageClass,   '',      
   Set_User_Pref,    AccessKey,     freezecount,    controlimage,               /*columns added by Gankan. G for bug_id: PNR2.0_26940 on 29-Nov-2010*/       
   colspan,                    rowspan,     TemplateID,     Preserve_visible_length,      
   Auto_width_column,   a.TemplateCategory,   a.TemplateSpecific,   a.Control_class_ext6,/*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008 ends*/      
   a.icon_position    ,a.icon_class    ,a.sensitivedata   ,a.IsPlatform --By SRIKANTH for TECH-46328      
   ,a.DynamicStyle    ,a.ImageAsData    ,a.MoreEventEnabled   ,a.UpeSetFocusEnabled --By SRIKANTH for TECH-46328      
           
         
 from de_published_ui_control a (nolock),      
   ep_ui_section_dtl  b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym not in ('HdnWFOrgUnit', 'HdnWFDocKey')      
 and  not exists ( select 'x'      
       from ep_ui_control_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name      = a.process_name      
       and  c.component_name       = a.component_name          
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       )      
 union      
 select d.customer_name,   d.project_name,    'base',      d.process_name,      
   d.component_name,   d.activity_name,   d.ui_name,     d.page_bt_synonym,      
   d.section_bt_synonym,  d.control_bt_synonym,  d.control_type,    d.horder,      
   d.vorder,     d.order_seq,    d.data_column_width,  d.label_column_width,      
   newid(),     b.ui_section_sysid,   d.timestamp,    @user,      
   @time,      @user,      @time,      d.control_id,      
   d.view_name,    d.visisble_length,   d.proto_tooltip,   d.sample_data,      
   d.control_doc,    d.control_prefix,   Null,      d.label_column_scalemode,      
/*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008 starts*/      
    d.data_column_scalemode, '',       '',       '',      
   '',       '',       '',       '',      
   '',       '',       '',       '', /*columns added by Gankan. G for bug_id: PNR2.0_26940 on 29-Nov-2010*/       
            '',       '',       '',       '',      
            '',       '',       '',       '',      
   '',       '',       '',       '',  
   '',       '',       '',       ''      
   --'',       '',       '',       ''      
 from de_published_non_ui_control  d (nolock),      
   ep_ui_section_dtl  b (nolock)      
 where  d.customer_name       = @dst_customer_name      
 and  d.project_name        = @dst_project_name      
 and  d.process_name        = @dst_process_name      
 and  d.component_name      = @dst_component_name      
 and  d.ecrno      = @temp_ecr_no      
 and  d.customer_name    = b.customer_name      
 and  d.project_name    = b.project_name      
 and  d.process_name    = b.process_name      
 and  d.component_name   = b.component_name      
 and  d.activity_name    = b.activity_name      
 and  d.ui_name     = b.ui_name       
 and  d.page_bt_synonym   = b.page_bt_synonym      
 and  d.section_bt_synonym  = b.section_bt_synonym      
 and  d.control_bt_synonym not in ('HdnWFOrgUnit', 'HdnWFDocKey')      
 and  not exists ( select 'x'      
       from ep_ui_control_dtl c (nolock)      
       where  c.customer_name   = d.customer_name              
       and  c.project_name    = d.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name      = d.process_name      
       and  c.component_name       = d.component_name          
       and  c.activity_name      = d.activity_name            
       and  c.ui_name              = d.ui_name      
       and  c.page_bt_synonym      = d.page_bt_synonym      
       and  c.section_bt_synonym   = d.section_bt_synonym      
       and  c.control_bt_synonym   = d.control_bt_synonym      
       )      
       
--  select 'insert into ep_ui_control_dtl_lng_extn table'            
 insert into ep_ui_control_dtl_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         control_type,               horder,                          
   vorder,                     order_seq,                  data_column_width,          label_column_width,              
   ui_control_sysid,           ui_section_sysid,           languageid,                 timestamp,                       
   createdby,                  createddate,                modifiedby,                 modifieddate,                    
   control_id,                 view_name,                  visisble_length,            proto_tooltip,                   
   sample_data,                control_doc,              control_prefix,        label_column_scalemode,           
   data_column_scalemode,  label_control_id,   controlimage,    colspan,                           
   rowspan )      
       
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.control_type,             a.horder,                     
   a.vorder,                   a.order_seq,                a.data_column_width,        a.label_column_width,              
   newid(),             b.ui_section_sysid,   a.languageid,           a.timestamp,                       
   @user,                  @time,                 @user,                  @time,                    
   a.control_id,               a.view_name,                a.visisble_length,          a.proto_tooltip,                   
   a.sample_data,              a.control_doc,              a.control_prefix,   null,              
   null,                       label_control_id,   controlimage,               colspan,      
   rowspan      
 from de_published_ui_control_lng_extn  a (nolock),      
   ep_ui_section_dtl     b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym not in ('HdnWFOrgUnit', 'HdnWFDocKey')      
 and  not exists ( select 'x'      
       from ep_ui_control_dtl_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name         
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name       
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.languageid           = a.languageid      
       )      
       
--  select 'insert into ep_ui_grid_dtl table'      
 insert into ep_ui_grid_dtl      
     (customer_name,              project_name,              req_no,                     process_name,                    
   component_name,             activity_name,          ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,        column_bt_synonym,          column_type,                     
   column_no,                  grid_sysid,                ui_control_sysid,           timestamp,                       
   createdby,                  createddate,               modifiedby,                 modifieddate,                    
   control_id,                 view_name,                 visible_length,             proto_tooltip,                   
   sample_data,                col_doc,                   column_prefix,    wrkreqno, /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
   Set_User_Pref ,    default_required,   ColumnClass,    visible,            
   Forcefit,     TemplateID,     iskey,      Kyseq_no,      
   TemplateCategory,   TemplateSpecific,   Column_class_ext6 , /* New column added by Gankan.G for the CaseId: PNR2.0_31306 */      
   RowExpander     ,GridToForm     ,icon_position,icon_class ,TreeColumn --By SRIKANTH for TECH-46328      
   ,column_Transformas   ,sensitivedata    ,IsPlatform     ,CompactView, --By SRIKANTH for TECH-46328      
   MoreEventEnabled   ,UpeSetFocusEnabled ) --By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,            'base',                     a.process_name,                    
   a.component_name,           a.activity_name,   a.ui_name,                   a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,  a.column_bt_synonym,         a.column_type,                     
   a.column_no,                newid(),     b.ui_control_sysid,          a.timestamp,       
   @user,                  @time,                   @user,                  @time,                      
   a.control_id,               a.view_name,    a.visible_length,            a.proto_tooltip,                   
   a.sample_data,              a.col_doc,     a.column_prefix,    '',  /*colums added by makesh prabu. R for the bug_id PNR2.0_18447 on 15-July-2008*/      
   a.Set_User_Pref ,   a.default_required,   a.ColumnClass,    a.visible,            
   a.Forcefit,     a.TemplateID,    a.iskey,     a.Kyseq_no,      
   a.TemplateCategory,   a.TemplateSpecific,   a.Column_class_ext6,  /* New column added by Gankan.G for the CaseId: PNR2.0_31306 */      
   a.RowExpander    ,a.GridToForm    ,a.icon_position   ,a.icon_class --By SRIKANTH for TECH-46328      
   ,a.TreeColumn    ,a.column_Transformas  ,a.sensitivedata   ,a.IsPlatform --By SRIKANTH for TECH-46328      
   ,a.CompactView    ,a.MoreEventEnabled   ,a.UpeSetFocusEnabled --By SRIKANTH for TECH-46328      
      
 from de_published_ui_grid a (nolock),      
   ep_ui_control_dtl  b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym  = b.control_bt_synonym      
 and  not exists ( select 'x'      
       from ep_ui_grid_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.column_bt_synonym    = a.column_bt_synonym      
       )      
       
--  select 'insert into ep_ui_grid_dtl_lng_extn table'       
 insert into ep_ui_grid_dtl_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         column_bt_synonym,          column_type,                     
   column_no,                  grid_sysid,                 ui_control_sysid,           languageid,                      
   timestamp,                  createdby,                  createddate,                modifiedby,                      
   modifieddate,               control_id,                 view_name,                  visible_length,                  
   proto_tooltip,              sample_data,                col_doc,                    column_prefix             )      
       
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.column_bt_synonym,        a.column_type,                     
   a.column_no,                newid(),                 b.ui_control_sysid,         a.languageid,                      
   a.timestamp,                @user,                  @time,                    @user,                      
   @time,                a.control_id,               a.view_name,                a.visible_length,                  
   a.proto_tooltip,            a.sample_data,      a.col_doc,                  a.column_prefix        
 from de_published_ui_grid_lng_extn a (nolock),      
   ep_ui_control_dtl    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym  = b.control_bt_synonym      
 and  not exists ( select 'x'      
       from ep_ui_grid_dtl_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no    = 'base'      
       and  c.process_name      = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.column_bt_synonym    = a.column_bt_synonym      
       and  c.languageid           = a.languageid      
       )      
       
--  select 'insert into ep_radio_button_dtl table'        
 insert into ep_radio_button_dtl      
     (customer_name,      project_name,      req_no,                    process_name,                    
   component_name,             activity_name,              ui_name,                   page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         button_code,               seq_no,                          
   button_caption,             default_flag,               horder,                    vorder,                          
   radio_button_sysid,         ui_control_sysid,           timestamp,                 createdby,                       
   createddate,                modifiedby,                 modifieddate)      
        
 select a.customer_name,            a.project_name,             'base',                    a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                 a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.button_code,             a.seq_no,                          
   a.button_caption,           a.default_flag,         a.horder,                  a.vorder,                          
   newid(),           b.ui_control_sysid,         a.timestamp,               @user,                       
   @time,                 @user,                  @time         
 from de_published_radio_button a (nolock),      
   ep_ui_control_dtl   b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym  = b.control_bt_synonym      
 and  not exists ( select 'x'      
       from ep_radio_button_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.button_code          = a.button_code      
       )      
       
--  select 'insert into ep_radio_button_dtl_lng_extn table'         
 insert into ep_radio_button_dtl_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         button_code,                seq_no,                          
   button_caption,             default_flag,               horder,                     vorder,                          
   radio_button_sysid,         ui_control_sysid,           languageid,                 timestamp,                       
   createdby,                  createddate,                modifiedby,           modifieddate          
   )      
       
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.button_code,              a.seq_no,                          
   a.button_caption,           a.default_flag,             a.horder,                   a.vorder,                          
   newid(),           b.ui_control_sysid,         a.languageid,           a.timestamp,                
   @user,                  @time,                   @user,                  @time      
 from de_published_radio_button_lng_extn  a  (nolock),      
   ep_ui_control_dtl     b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  a.control_bt_synonym  = b.control_bt_synonym      
 and  not exists ( select 'x'      
       from ep_radio_button_dtl_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name      = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.button_code          = a.button_code      
       and  c.languageid           = a.languageid      
       )      
       
--  select 'insert into ep_enum_value_dtl table'      
 insert into ep_enum_value_dtl      
     (customer_name,              project_name,               req_no,                process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         enum_code,                  enum_caption,                    
   default_flag,               seq_no,             enum_value_sysid,           ui_section_sysid,                
   timestamp,      createdby,                  createddate,          modifiedby,                      
   modifieddate)      
       
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.enum_code,                a.enum_caption,                    
   a.default_flag,             seq_no,             NEWID(),             b.ui_section_sysid,                
   a.timestamp,      @user,                  @time,            @user,                      
   @time      
 from de_published_enum_value  a (nolock),      
   ep_ui_section_dtl   b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym = b.section_bt_synonym      
 and  not exists ( select 'x'      
       from ep_enum_value_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
      and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.enum_code            = a.enum_code      
       )      
       
--  select 'insert into ep_enum_value_dtl_lng_extn table'       
 insert into ep_enum_value_dtl_lng_extn      
     (customer_name,              project_name,              req_no,                     process_name,                    
   component_name,             activity_name,             ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,        enum_code,                  enum_caption,                    
   default_flag,               seq_no,                    enum_value_sysid,           ui_section_sysid,                
   languageid,                 timestamp,                 createdby,                  createddate,                     
   modifiedby,                 modifieddate)      
      
 select a.customer_name,            a.project_name,            'base',                     a.process_name,                    
   a.component_name,         a.activity_name,           a.ui_name,                   a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,      a.enum_code,                 a.enum_caption,                    
   a.default_flag,             a.seq_no,                  newid(),    b.ui_section_sysid,                
   a.languageid,               a.timestamp,               @user,            @time,                     
   @user,                  @time      
 from de_published_enum_value_lng_extn a (nolock),      
   ep_ui_section_dtl     b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.section_bt_synonym  = b.section_bt_synonym      
 and  not exists ( select 'x'      
       from ep_enum_value_dtl_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.enum_code            = a.enum_code      
       and  c.languageid           = a.languageid      
       )      
       
--  select 'insert into ep_ui_traversal_dtl table'        
 insert into ep_ui_traversal_dtl      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   section_bt_synonym,         control_bt_synonym,         link_type,                  treaversal_sysid,                
   ui_page_sysid,              timestamp,                  createdby,                  createddate,                     
   modifiedby,                 modifieddate,               linked_component,           linked_activity,                 
   linked_ui,     associated_ctrl_bt_synonym, wrkreqno,     trvsl_seq,      
   Width,                      Height,                     Toolbar_notreq,    LinkLaunchType) /* Code added By Makesh Prabu R For PNR2.0_26526 on 09-April-2010 */ --By SRIKANTH for TECH-46328      
      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,    a.page_bt_synonym,                 
   a.section_bt_synonym,       a.control_bt_synonym,       a.link_type,                newid(),                
   b.ui_page_sysid,            a.timestamp,                @user,                  @time,                     
   @user,                  @time,               linked_component,           a.linked_activity,                 
   a.linked_ui,    associated_ctrl_bt_synonym, '',       trvsl_seq,      
   a.Width,                   Height,                     Toolbar_notreq,   LinkLaunchType/* Code added By Makesh Prabu R For PNR2.0_26526 on 09-April-2010 */ --By SRIKANTH for TECH-46328      
 from de_published_ui_traversal a (nolock),      
   ep_ui_page_dtl    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  not exists ( select 'x'      
       from ep_ui_traversal_dtl c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.section_bt_synonym   = a.section_bt_synonym      
       and  c.control_bt_synonym   = a.control_bt_synonym      
       and  c.link_type            = a.link_type      
       )      
       
--  select 'insert into ep_action_mst table'        
 insert into ep_action_mst      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                 
   task_name,         task_descr,                 task_seq,           task_pattern,                    
   timestamp,                  createdby,            createddate,               modifiedby,                      
   modifieddate,               primary_control_bts,        task_sysid,                 ui_sysid,       
   task_type,     Act_flag,     task_confirm_msg,   task_status_msg, --ExtJs Release      
   wrkreqno,     usageid,     ddt_page_bt_synonym,  ddt_control_bt_synonym,  --ExtJs Release      
   ddt_control_id,    ddt_view_name,    task_process_msg,   PopUp_section,        --ExtJs Release      
   PopUp_close,    IsCallout,     QR_sourceCtrl,    QR_targetCtrl,      
   Barcode_sourceCtrl,   Barcode_targetCtrl,   browse_control,    QR_sourceCtrl_Page,      
   QR_targetCtrl_Page,   Barcode_sourceCtrl_Page, Barcode_targetCtrl_Page, browse_control_Page,      
   group_name,     Buttonbar_primary_section, Popup_onclick_close, /* New column added by Gankan.G for the CaseId: PNR2.0_31306 */      
   PopUp_page_bt_synonym  ,Autoupload     ,sectionlaunchtype   ,QuickTask --By SRIKANTH for TECH-46328      
   ,SystemTaskType) --By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,             'base',                    a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.task_name,        a.task_descr,               a.task_seq,           a.task_pattern,                    
   a.timestamp,                @user,                  @time,                @user,                      
   @time,                a.primary_control_bts,      newid(),                 b.ui_sysid,       
   a.task_type,    null,      task_confirm_msg,   task_status_msg, --ExtJs Release      
   '',       usageid,     ddt_page_bt_synonym,  ddt_control_bt_synonym,  --ExtJs Release      
   ddt_control_id,    ddt_view_name,    task_process_msg,   a.PopUp_section,   --ExtJs Release      
   a.PopUp_close,    a.IsCallout,    a.QR_sourceCtrl,   a.QR_targetCtrl,      
   a.Barcode_sourceCtrl,  a.Barcode_targetCtrl,  a.browse_control,   a.QR_sourceCtrl_Page,      
   a.QR_targetCtrl_Page,  a.Barcode_sourceCtrl_Page, a.Barcode_targetCtrl_Page, a.browse_control_Page,      
   a.group_name,    a.Buttonbar_primary_section, a.Popup_onclick_close, /* New column added by Gankan.G for the CaseId: PNR2.0_31306 */      
   a.PopUp_page_bt_synonym  ,a.Autoupload     ,a.sectionlaunchtype ,a.QuickTask --By SRIKANTH for TECH-46328      
   ,a.SystemTaskType --By SRIKANTH for TECH-46328      
 from de_published_action  a (nolock),      
   ep_ui_mst    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  not exists ( select 'x'      
       from ep_action_mst c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name      = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.task_name            = a.task_name      
       )      
       
--  select 'insert into ep_action_mst_lng_extn table'        
 insert into ep_action_mst_lng_extn      
     (customer_name,              project_name,           req_no,            process_name,                    
   component_name,             activity_name,          ui_name,          page_bt_synonym,                 
   task_name,                  task_descr,             task_seq,                   task_pattern,                    
   languageid,                 timestamp,              createdby,                  createddate,        
   modifiedby,                 modifieddate,           primary_control_bts,        task_sysid,                      
   ui_sysid,                   task_type,    task_confirm_msg,   task_status_msg, --ExtJs Release      
   wrkreqno,     usageid,    ddt_page_bt_synonym,  ddt_control_bt_synonym, --ExtJs Release      
   ddt_control_id,    ddt_view_name,               --ExtJs Release      
   task_process_msg,           PopUp_page_bt_synonym,  PopUp_section,              PopUp_close, IsCallout,      
   QR_sourceCtrl,              QR_targetCtrl,          Barcode_sourceCtrl,         Barcode_targetCtrl,      
   browse_control,             QR_sourceCtrl_Page,     QR_targetCtrl_Page,         Barcode_sourceCtrl_Page,       
   Barcode_targetCtrl_Page,    browse_control_Page,    group_name,                 Buttonbar_primary_section,      
   Popup_onclick_close   ,Autoupload) /* New column added by Gankan.G for the CaseId: PNR2.0_31306 */ --By SRIKANTH for TECH-46328      
 select a.customer_name,            a.project_name,         'base',                     a.process_name,                    
   a.component_name,           a.activity_name,        a.ui_name,                  a.page_bt_synonym,                 
   a.task_name,                a.task_descr,           a.task_seq,               a.task_pattern,                    
   a.languageid,               a.timestamp,            @user,                  @time,                   
   @user,                  @time,               a.primary_control_bts,      newid(),                      
   b.ui_sysid,                 a.task_type,   task_confirm_msg,   task_status_msg, --ExtJs Release      
   '',       usageid,    ddt_page_bt_synonym,  ddt_control_bt_synonym, --ExtJs Release      
   ddt_control_id,    ddt_view_name,                --ExtJs Release      
   task_process_msg,           PopUp_page_bt_synonym,  PopUp_section,              PopUp_close, IsCallout,      
   QR_sourceCtrl,              QR_targetCtrl,          Barcode_sourceCtrl,         Barcode_targetCtrl,      
   browse_control,             QR_sourceCtrl_Page,     QR_targetCtrl_Page,         Barcode_sourceCtrl_Page,       
   Barcode_targetCtrl_Page,    browse_control_Page,    group_name,                 Buttonbar_primary_section,      
   Popup_onclick_close,  Autoupload --By SRIKANTH for TECH-46328      
 from de_published_action_lng_extn a (nolock),      
   ep_ui_mst      b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  not exists ( select 'x'      
       from ep_action_mst_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name      = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name)      
      
--  select 'insert into ep_action_section_map table'        
 insert into ep_action_section_map      
     (customer_name,    project_name,    req_no,      process_name,        
   component_name,    activity_name,    ui_name,     page_bt_synonym,       
   task_name,     section_bt_synonym,   task_section_sysid,   task_sysid,      
   createdby,     createddate,    modifiedby,     modifieddate,        
   timestamp,     section_page_bt_synonym      
   )       
 select a.customer_name,   a.project_name,    'base',      a.process_name,        
   a.component_name,   a.activity_name,   a.ui_name,     a.page_bt_synonym,       
   a.task_name,    a.section_bt_synonym,  newid(),     a.task_sysid,      
   @user,                  @time,      @user,                  @time,       
   a.timestamp,    a.section_page_bt_synonym      
 from de_published_action_section_map a (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  not exists ( select 'x'      
       from ep_action_section_map c (nolock)      
       where  c.customer_name    = a.customer_name              
       and  c.project_name     = a.project_name        
       and  c.req_no                = 'base'      
       and  c.process_name          = a.process_name      
       and  c.component_name        = a.component_name            
       and  c.activity_name       = a.activity_name            
       and  c.ui_name            = a.ui_name      
       and  c.page_bt_synonym   = a.page_bt_synonym      
       and  c.task_name     = a.task_name      
       and  c.section_page_bt_synonym  = a.section_page_bt_synonym      
       and  c.section_bt_synonym  = a.section_bt_synonym      
       and  c.task_section_sysid  = a.task_section_sysid)      
      
--  select 'insert into ep_flowbr_mst table'         
 insert into ep_flowbr_mst      
     (customer_name,              project_name,              req_no,                     process_name,                    
   component_name,             activity_name,        ui_name,                    page_bt_synonym,                 
   task_name,                  flowbr_name,                flowbr_descr,               flowbr_sequence,                 
   flowbr_sysid,               task_sysid,                 timestamp,                  createdby,                       
   createddate,                modifiedby,                 modifieddate,               map_flag,                        
   control_id,                 view_name,                  event_name)      
       
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.task_name,                a.flowbr_name,              a.flowbr_descr,             a.flowbr_sequence,                 
   newid(),                b.task_sysid,               a.timestamp,                @user,                       
   @time,                 @user,                  @time,                a.map_flag,                        
   a.control_id,               a.view_name,                a.event_name      
 from de_published_flowbr  a (nolock),      
   ep_action_mst   b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.task_name     = b.task_name      
 and  not exists ( select 'x'      
       from ep_flowbr_mst c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.task_name            = a.task_name      
       and  c.flowbr_name          = a.flowbr_name      
       )      
       
--  select 'insert into ep_flowbr_mst_lng_extn table'         
 insert into ep_flowbr_mst_lng_extn      
     (customer_name,              project_name,               req_no,                     process_name,                    
   component_name,             activity_name,              ui_name,                    page_bt_synonym,                
   task_name,                  flowbr_name,                flowbr_descr,               flowbr_sequence,                 
   flowbr_sysid,               task_sysid,                 languageid,                 timestamp,       
   createdby,     createddate,    modifiedby,     modifieddate,      
     control_id,                 view_name,                  event_name,     map_flag                     
   )      
      
 select a.customer_name,            a.project_name,             'base',                     a.process_name,                    
   a.component_name,           a.activity_name,            a.ui_name,                  a.page_bt_synonym,                 
   a.task_name,                a.flowbr_name,              a.flowbr_descr,        a.flowbr_sequence,        
   newid(),      b.task_sysid,               a.languageid,               a.timestamp,       
   @user,                  @time,      @user,                  @time,      
     a.control_id,               a.view_name,                a.event_name,    map_flag         
 from de_published_flowbr_lng_extn a (nolock),      
   ep_action_mst     b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  a.customer_name    = b.customer_name      
 and  a.project_name    = b.project_name      
 and  a.process_name    = b.process_name      
 and  a.component_name   = b.component_name      
 and  a.activity_name    = b.activity_name      
 and  a.ui_name     = b.ui_name       
 and  a.page_bt_synonym   = b.page_bt_synonym      
 and  a.task_name     = b.task_name      
 and  not exists ( select 'x'      
       from ep_flowbr_mst_lng_extn c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.req_no               = 'base'      
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym      = a.page_bt_synonym      
       and  c.task_name            = a.task_name      
       and  c.flowbr_name          = a.flowbr_name      
       and  c.languageid           = a.languageid      
       )      
      
--  select 'Population of EP tables completed'      
      
 /*Code added by makesh prabu.R for State tables on 08/Oct/2009 starts -- PNR2.0_24235*/      
      
 insert into ep_ui_state_dtl      
 (customer_name, project_name, req_no,  process_name,  component_name,      
 activity_name, ui_name,  state_id, state_descr,  system_state,      
 createdby,  createddate, modifiedby, modifieddate,  wrkreqno,  focus_control) --By SRIKANTH for TECH-46328      
      
 select customer_name,project_name,'base', process_name,  component_name,      
 activity_name, ui_name,  state_id, state_descr,  system_state,      
 createdby,  createddate, modifiedby, modifieddate,  '',    focus_control --By SRIKANTH for TECH-46328      
      
 from de_published_ui_state a(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  not exists (select 'M' from ep_ui_state_dtl x(nolock)      
     where x.customer_name = a.customer_name      
     and  x.project_name  = a.project_name      
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name      
     and  x.component_name = a.component_name      
     and  x.activity_name = a.activity_name      
     and  x.ui_name   = a.ui_name      
     and  x.state_id   = a.state_id )      
      
      
 insert into ep_ui_state_section_dtl      
 (customer_name, project_name, req_no,  process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym,state_id,  section_bt_synonym,      
 collapse,  visible,  enable,  createdby,   createddate,      
 modifiedby,  modifieddate, wrkreqno)      
      
 select a.customer_name, a.project_name, 'base',  a.process_name,  a.component_name,      
 a.activity_name,  a.ui_name, a.page_bt_synonym,state_id,  a.section_bt_synonym,      
 collapse,  a.visible,  enable,  a.createdby,   a.createddate,      
 a.modifiedby, a.modifieddate, ''      
 from de_published_ui_state_section a(nolock),      
   de_published_ui_section  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and   a.customer_name  = b.customer_name      
 and   a.project_name  = b.project_name      
 and   a.process_name  = b.process_name      
 and  a.ecrno    = b.ecrno      
 and   a.component_name = b.component_name      
 and   a.activity_name  = b.activity_name      
 and   a.ui_name   = b.ui_name      
 and   a.page_bt_synonym = b.page_bt_synonym      
 and   a.section_bt_synonym= b.section_bt_synonym      
 and  not exists (select 'M' from ep_ui_state_section_dtl x(nolock)      
      where x.customer_name = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.state_id   = a.state_id      
      and  x.section_bt_synonym= a.section_bt_synonym )      
      
      
 insert into ep_ui_state_control_dtl      
 (customer_name, project_name, req_no,   process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym,state_id,   section_bt_synonym,      
 control_bt_synonym,visible,  enable,   createdby,   createddate,      
 modifiedby,  modifieddate, wrkreqno)      
      
 select a.customer_name, a.project_name, 'base', a.process_name, a.component_name,      
 a.activity_name, a.ui_name,  a.page_bt_synonym,state_id,  a.section_bt_synonym,      
 a.control_bt_synonym,visible,  enable,   a.createdby,  a.createddate,      
 a.modifiedby,  a.modifieddate, ''      
 from de_published_ui_state_control a(nolock),      
   de_published_ui_control  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and   a.customer_name  = b.customer_name      
 and   a.project_name  = b.project_name      
 and   a.process_name  = b.process_name      
 and  a.ecrno    = b.ecrno      
 and   a.component_name = b.component_name      
 and   a.activity_name  = b.activity_name      
 and   a.ui_name   = b.ui_name      
 and   a.page_bt_synonym = b.page_bt_synonym      
 and   a.section_bt_synonym= b.section_bt_synonym      
 and   a.control_bt_synonym= b.control_bt_synonym      
 and  not exists (select 'M' from ep_ui_state_control_dtl x(nolock)      
      where x.customer_name = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.state_id   = a.state_id      
      and  x.section_bt_synonym= a.section_bt_synonym      
      and  x.control_bt_synonym= a.control_bt_synonym )      
      
      
 insert into ep_ui_state_task_dtl      
 (customer_name, project_name, req_no,  process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym, state_id,  task_name,      
 task_descr,  rt_state,  focus_control,createdby,  createddate,      
 modifiedby,  modifieddate, wrkreqno)      
      
 select customer_name, project_name, 'base', process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym, state_id,  task_name,      
 task_descr,  rt_state,  focus_control,createdby,  createddate,      
 modifiedby,  modifieddate, ''      
 from de_published_ui_state_task a(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  not exists (select 'M' from ep_ui_state_task_dtl x(nolock)      
     where x.customer_name = a.customer_name      
     and  x.project_name  = a.project_name      
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name      
     and  x.component_name = a.component_name      
     and  x.activity_name = a.activity_name      
     and  x.ui_name = a.ui_name      
     and  x.page_bt_synonym = a.page_bt_synonym      
     and  x.task_name  = a.task_name )      
      
      
 insert into ep_ui_state_task_mst      
 (customer_name, project_name, req_no,  process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym, state_id,  task_name,      
 task_descr,  createdby,  createddate, modifiedby,  modifieddate,       
 wrkreqno)      
      
 select customer_name, project_name, 'base', process_name,  component_name,      
 activity_name, ui_name,  page_bt_synonym, state_id,  task_name,      
 task_descr,  createdby,  createddate, modifiedby,  modifieddate,       
 ''      
 from de_published_ui_state_task_mst a(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  not exists (select 'M' from ep_ui_state_task_mst x(nolock)      
     where x.customer_name = a.customer_name      
     and  x.project_name  = a.project_name      
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name      
     and  x.component_name = a.component_name      
     and  x.activity_name = a.activity_name      
     and  x.ui_name   = a.ui_name      
     and  x.page_bt_synonym = a.page_bt_synonym      
     and  x.task_name  = a.task_name      
     and  x.state_id   = a.state_id )      
      
 /*Code added by makesh prabu.R for State tables on 08/Oct/2009 starts -- PNR2.0_24235*/      
      
/*code added by Makesh prabu.R for ext_JS feature on 08/April/2009 --PNR2.0_21056 starts */      
 insert into ep_ext_js_section_dtl      
  (customer_name,    project_name,   req_no,     process_name,      
  component_name,    activity_name,   ui_name,    page_bt_synonym,      
  section_bt_synonym,   section_type,   Section_Width,   Section_Height,      
  Section_Class,    RVW_Task,    Callout_Task,   Direction,      
  Scroll_Behaviour,   Scroll_Delay,   Fade_Delay,    No_Of_Columns,      
  Report_Item_Class,   Property_Class,   Value_Class,   sample_data,      
  wrkreqno,     createdby,    createddate,   modifiedby,      
  modifieddate)      
 select distinct a.customer_name,a.project_name,   'base',     a.process_name,      
  a.component_name,   a.activity_name,  a.ui_name,    a.page_bt_synonym,      
  a.section_bt_synonym,  a.section_type,   Section_Width,   Section_Height,      
  Section_Class,    RVW_Task,    Callout_Task,   Direction,      
  Scroll_Behaviour,   Scroll_Delay,   Fade_Delay,    No_Of_Columns,      
  Report_Item_Class,   Property_Class,   Value_Class,   sample_data,      
  'base',      @user,     @time,     @user,      
  @time      
 from de_published_ext_js_section a(nolock),      
   ep_ui_section_dtl b(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.section_bt_synonym= b.section_bt_synonym      
 and  a.section_type  = b.section_type      
 and  not exists (select 'M' from ep_ext_js_section_dtl x(nolock)      
      where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym= a.section_bt_synonym )      
      
      
 insert into ep_ext_js_section_column_dtl      
  (customer_name,     project_name,   req_no,     process_name,      
  component_name,     activity_name,   ui_name,    page_bt_synonym,      
  section_bt_synonym,    section_type,   control_bt_synonym,  Column_Sequence,      
  Column_BT_Synonym,    IS_Key,     Datatype,    Grouping,      
  Grouping_Function,    Grouping_Synonym,  RVW_Task,    Callout_Task,      
  Label_Class,     Control_Class,   sample_data,   wrkreqno,      
  createdby,      createddate,   modifiedby,    modifieddate,      
  FieldList,      Default_Dragoption,  column_type,   pivot_sequence,      
  visible_length,     image_column)      
 select distinct a.customer_name,a.project_name,  'base',     a.process_name,      
  a.component_name,    a.activity_name,  a.ui_name,    a.page_bt_synonym,      
  a.section_bt_synonym,   a.section_type,   control_bt_synonym,  Column_Sequence,      
  Column_BT_Synonym,    IS_Key,     Datatype,    Grouping,      
  Grouping_Function,    Grouping_Synonym,  a.RVW_Task,    a.Callout_Task,      
  Label_Class,     Control_Class,   a.sample_data,   'Base',      
  @user,       @time,     @user,     @time,      
  FieldList,      Default_Dragoption,  column_type,   pivot_sequence,      
  a.visible_length,    a.image_column      
 from de_published_ext_js_section_column a(nolock),      
   ep_ext_js_section_dtl  b(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.section_bt_synonym= b.section_bt_synonym      
 and  a.section_type  = b.section_type      
 and  not exists (select 'M' from ep_ext_js_section_column_dtl x(nolock)      
      where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym= a.section_bt_synonym      
      and  x.section_type  = a.section_type      
      and  x.control_bt_synonym= a.control_bt_synonym      
      and  x.Column_BT_Synonym = a.Column_BT_Synonym )      
      
 insert into ep_ext_js_control_dtl      
  (customer_name,    project_name,   req_no,     process_name,      
  component_name,    activity_name,   ui_name,    page_bt_synonym,      
  section_bt_synonym,   control_bt_synonym,  Extjs_Ctrl_type,  Ctrl_height,      
  ctrl_width,     Control_Class,   RVW_Task,    Callout_Task,      
  Type_Delay,     Type_Direction,   Fade_Delay,    Fade_Direction,      
  Loop_Count,     sample_data,   wrkreqno,    createdby,      
  createddate,    modifiedby,    modifieddate,   feature_name )      
 select distinct a.customer_name,a.project_name,   'base',     a.process_name,      
  a.component_name,   a.activity_name,  a.ui_name,    a.page_bt_synonym,      
  a.section_bt_synonym,  control_bt_synonym,  Extjs_Ctrl_type,  Ctrl_height,      
  ctrl_width,     Control_Class,   RVW_Task,    Callout_Task,      
  Type_Delay,     Type_Direction,   Fade_Delay,    Fade_Direction,      
  Loop_Count,     sample_data,   '',      @user,      
  @time,      @user,     @time,     feature_name      
 from de_published_ext_js_control  a(nolock),      
   ep_ui_section_dtl   b(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.section_bt_synonym= b.section_bt_synonym      
 and  not exists (select 'M' from ep_ext_js_control_dtl x(nolock)      
      where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym= a.section_bt_synonym      
      and  x.control_bt_synonym= a.control_bt_synonym )      
      
      
 insert into ep_ui_state_page_dtl      
  (customer_name,   project_name,  req_no,   process_name,      
  component_name,   activity_name,  ui_name,  state_id,      
  page_bt_synonym,  visible,  enable,   createdby,      
  createddate,   modifiedby,  modifieddate,  wrkreqno,      
  focus )           --code modified for Bug ID:PNR2.0_23622      
 select a.customer_name, a.project_name,  'base',    a.process_name,      
  a.component_name, a.activity_name, a.ui_name,   state_id,      
  a.page_bt_synonym, visible,  enable,    @user,      
  @time,   @user,   @time,    '',      
  a.focus           --code modified for Bug ID:PNR2.0_23622      
 from de_published_ui_state_page a(nolock),      
   ep_ui_page_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecr_no   = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and not exists ( select '*' from ep_ui_state_page_dtl x(nolock)      
     where x.customer_name  = a.customer_name       
     and  x.project_name  = a.project_name       
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name       
     and  x.component_name = a.component_name      
     and  x.activity_name  = a.activity_name       
     and  x.ui_name   = a.ui_name        
     and  x.state_id   = a.state_id        
     and  x.page_bt_synonym = a.page_bt_synonym )      
      
      
 insert into ep_ui_state_column_dtl      
  (customer_name,   project_name,  req_no,    process_name,      
  component_name,   activity_name,  ui_name,   state_id,      
  page_bt_synonym,  section_bt_synonym, control_bt_synonym, column_bt_synonym,      
  column_no,    visible,   createdby,   createddate,      
  modifiedby,    modifieddate,  wrkreqno,   enable)      
 select a.customer_name, a.project_name,  'base',    a.process_name,      
  a.component_name,  a.activity_name, a.ui_name,   state_id,      
  a.page_bt_synonym,  a.section_bt_synonym,a.control_bt_synonym,a.column_bt_synonym,      
  column_no,    visible,   @user,    @time,      
  @user,     @time,    '',     enable      
 from de_published_ui_state_column a(nolock),      
   ep_ui_control_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecr_no   = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.section_bt_synonym= b.section_bt_synonym      
 and  a.control_bt_synonym= b.control_bt_synonym      
 and not exists ( select '*' from ep_ui_state_column_dtl x(nolock)      
     where x.customer_name  = a.customer_name       
     and  x.project_name  = a.project_name       
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name       
     and  x.component_name = a.component_name      
     and  x.activity_name  = a.activity_name       
     and  x.ui_name   = a.ui_name        
     and  x.page_bt_synonym = a.page_bt_synonym      
     and  x.state_id   = a.state_id        
     and  x.section_bt_synonym = a.section_bt_synonym      
     and  x.control_bt_synonym = a.control_bt_synonym      
     and  x.column_bt_synonym = a.column_bt_synonym      
     and  x.column_no   = a.column_no )      
      
      
 insert into ep_layout_ezeeview_sp       
  (customer_name,   project_name,  req_no,    process_name,      
  component_name,   activity_name,  ui_name,   page_bt_synonym,      
  Link_ControlName,  Target_SPName,  Link_Caption,  Linked_Component,      
  Linked_Activity,  Linked_ui,   timestamp,   createdby,      
  createddate,   modifiedby,   modifieddate,  Linked_Task, wrkreqno) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/      
 select a.customer_name, a.project_name,  'base',    a.process_name,      
  a.component_name,  a.activity_name, a.ui_name,   a.page_bt_synonym,      
  Link_ControlName,  Target_SPName,  Link_Caption,  Linked_Component,      
  Linked_Activity,  Linked_ui,   a.timestamp,  @user,      
  @time,     @user,    @time,    Linked_Task, wrkreqno /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/      
 from de_published_ezeeview_sp a(nolock),      
   ep_ui_control_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.Link_ControlName = b.control_bt_synonym      
 and not exists ( select '*' from ep_layout_ezeeview_sp x(nolock)      
     where x.customer_name  = a.customer_name       
     and  x.project_name  = a.project_name       
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name       
     and  x.component_name = a.component_name      
     and  x.activity_name  = a.activity_name       
     and  x.ui_name   = a.ui_name        
     and  x.page_bt_synonym = a.page_bt_synonym       
     and  x.Link_ControlName = a.Link_ControlName )      
      
      
 insert into ep_layout_ezeeview_spparamlist       
  (customer_name,   project_name,  req_no,    process_name,      
  component_name,   activity_name,  ui_name,   page_bt_synonym,      
  Link_ControlName,  Target_SPName,  ParameterName,  Mapped_Control,      
  Link_Caption,   timestamp,   createdby,   createddate,      
  modifiedby,    modifieddate,  control_page_name,  /*--Column added for PNR2.0_24649 */  
  wrkreqno)  /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/      
 select a.customer_name, a.project_name,  'base',    a.process_name,      
  a.component_name,  a.activity_name, a.ui_name,   a.page_bt_synonym,      
  Link_ControlName,  Target_SPName,  ParameterName,  Mapped_Control,      
  Link_Caption,   a.timestamp,  @user,    @time,      
  @user,     @time,    control_page_name,  /*--Column added for PNR2.0_24649 */      
  wrkreqno  /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/      
 from de_published_ezeeview_spparamlist a(nolock),      
   ep_ui_control_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  a.customer_name  = b.customer_name      
 and  a.project_name  = b.project_name      
 and  a.process_name  = b.process_name      
 and  a.component_name = b.component_name      
 and  a.activity_name  = b.activity_name      
 and  a.ui_name   = b.ui_name       
 and  a.page_bt_synonym = b.page_bt_synonym      
 and  a.Link_ControlName = b.control_bt_synonym      
 and not exists ( select '*' from ep_layout_ezeeview_spparamlist x(nolock)      
     where x.customer_name  = a.customer_name       
     and  x.project_name  = a.project_name       
     and  x.req_no   = 'Base'      
     and  x.process_name  = a.process_name       
     and  x.component_name = a.component_name      
     and  x.activity_name  = a.activity_name       
     and  x.ui_name   = a.ui_name        
     and  x.page_bt_synonym = a.page_bt_synonym       
     and  x.Link_ControlName = a.Link_ControlName )      
      
 /*code added by Makesh prabu.R for ext_JS feature on 08/April/2009 --PNR2.0_21056 ends */      
      
 /* Code added by Makesh prabu For phase3 & phase4 Release cross fixing on 17-March-2010 starts -- PNR2.0_26143 */      
 /* Code added by Makesh prabu For phase3 & phase4 Release tables on 31-March-2010 starts -- PNR2.0_26376 */      
 insert into ep_listedit_control_map      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, mapped_bt_synonym,   listedit_synonym,  workreqno,      
 control_id,   view_name,     createdby,    createddate,      
 listedit_controlid, listedit_viewname)      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, mapped_bt_synonym,   listedit_synonym,  '',      
 control_id,   view_name,     @user,     @time,      
 listedit_controlid, listedit_viewname      
 From de_published_listedit_control_map a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_listedit_control_map x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym = a.section_bt_synonym      
      and  x.mapped_bt_synonym = a.mapped_bt_synonym      
      and  x.listedit_synonym = a.listedit_synonym )      
      
      
 insert into ep_listedit_column_dtl      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    listedit_synonym,      
 listedit_column_synonym, listedit_column_seqno, listedit_controlid,  listedit_viewname,      
 workreqno,   column_prefix,    createdby,    createddate,      
 visible_length )      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    listedit_synonym,      
 listedit_column_synonym, listedit_column_seqno, listedit_controlid,  listedit_viewname,      
 '',     column_prefix,    @user,     @time,      
 visible_length      
 From de_published_listedit_column a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_listedit_column_dtl x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.listedit_synonym = a.listedit_synonym      
      and  x.listedit_column_synonym = a.listedit_column_synonym )      
 /* Code added by Makesh prabu For phase3 & phase4 Release tables on 31-March-2010 End -- PNR2.0_26376 */      
      
 insert into ep_resolvelist_data_map      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    listedit_synonym,      
 mapped_bt_synonym, listedit_column_synonym, page_bt_synonym,  section_bt_synonym,      
 data_mapped_synonym,primary_search_column,  list_index_search,  control_id,      
 view_name,   visible,     createdby,   createddate,       
 workreqno,   mapped_bt_syn_page ) /* Code Added By Makesh Prabu R For PNR2.0_26755 */      
   Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    listedit_synonym,      
 mapped_bt_synonym, listedit_column_synonym, page_bt_synonym,  section_bt_synonym,      
 data_mapped_synonym,primary_search_column,  list_index_search,  control_id,      
 view_name,   visible,     @user,     @time,       
 '',     mapped_bt_syn_page  /* Code Added By Makesh Prabu R For PNR2.0_26755 */      
 From de_published_resolvelist_data_map a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_resolvelist_data_map x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.mapped_bt_syn_page= a.mapped_bt_syn_page /* Code Added By Makesh Prabu R For PNR2.0_26755 */      
      and  x.mapped_bt_synonym = a.mapped_bt_synonym      
      and  x.listedit_synonym = a.listedit_synonym      
      and  x.listedit_column_synonym = a.listedit_column_synonym )      
      
      
 insert into ep_contextual_links      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_name,  control_bt_synonym,   contextual_link_name, contextual_link_seq,      
 task_description, extend_as,     source_from,   tolltiptext,      
 linked_componentname,linked_activityname,  linked_uiname,   subscription_name,      
 task_name,   task_type,     createdby,    createddate,      
 modifiedby,   modifieddate,    wrkreqno)      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_name,  control_bt_synonym,   contextual_link_name, contextual_link_seq,      
 task_description, extend_as,     source_from,   tolltiptext,      
 linked_componentname,linked_activityname,  linked_uiname,   subscription_name,      
 task_name,   task_type,     @user,     @time,      
 @user,    @time,      ''      
 From de_published_contextual_links a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_contextual_links x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_name  = a.section_name      
      and  x.control_bt_synonym = a.control_bt_synonym      
      and  x.contextual_link_name = a.contextual_link_name )      
      
      
 insert into ep_control_extensions      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_name,  control_bt_synonym,   controlextension_name, controlextension_seq,      
 task_description, extend_as,     source_from,   image_path,      
 tooltiptext,  linked_componentname,  linked_activityname, linked_uiname,      
 subscription_name, task_name,     createdby,    createddate,      
 modifiedby,   modifieddate,    wrkreqno,    task_type)      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_name,  control_bt_synonym,   controlextension_name, controlextension_seq,      
 task_description, extend_as,     source_from,   image_path,      
 tooltiptext,  linked_componentname,  linked_activityname, linked_uiname,      
 subscription_name, task_name,     @user,     @time,      
 @user,    @time,      '',      task_type      
 From de_published_control_extensions a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_control_extensions x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_name  = a.section_name      
      and  x.control_bt_synonym = a.control_bt_synonym      
      and  x.controlextension_name = a.controlextension_name )      
      
      
 insert into ep_date_highlight_control_map      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, control_bt_synonym,   listedit_synonym,  controlid,      
 viewname,   listedit_controlid,   listedit_viewname,  createdby,      
 createddate,  wrkreqno )      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, control_bt_synonym,   listedit_synonym,  controlid,      
 viewname,   listedit_controlid,   listedit_viewname,  @user,      
 @time,    ''      
 From de_published_date_highlight_control_map a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_date_highlight_control_map x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym = a.section_bt_synonym      
      and  x.control_bt_synonym = a.control_bt_synonym      
      and  x.listedit_synonym = a.listedit_synonym )      
      
      
 insert into ep_dynamic_sec_control_map      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, control_bt_synonym,   controlid,    viewname,      
 createdby,   createddate,    wrkreqno )      
      
 Select Distinct customer_name, project_name, 'base',     process_name,      
 component_name,  activity_name,    ui_name,    page_bt_synonym,      
 section_bt_synonym, control_bt_synonym,   controlid,    viewname,      
 @user,    @time,      ''      
 From de_published_dynamic_sec_control_map a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_dynamic_sec_control_map x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.page_bt_synonym = a.page_bt_synonym      
      and  x.section_bt_synonym = a.section_bt_synonym      
      and  x.control_bt_synonym = a.control_bt_synonym      
      and  x.controlid   = a.controlid )      
      
      
 insert into ep_ui_displaytext_lang_extn      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    group_task_name,      
 display_text,  lang_id,     createdby,    createddate,       
 wrkreqno,   group_name )      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    group_task_name,      
 display_text,  lang_id,     @user,     @time,       
 '',     group_name      
 From de_published_ui_displaytext_lang_extn a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_ui_displaytext_lang_extn x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.group_task_name = a.group_task_name      
      and  x.lang_id   = a.lang_id )      
      
      
 insert into ep_ui_toolbar_dtl      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    group_name,      
 group_task_name, task_seqno,     class_name,    display_text,      
 createdby,   createddate,    modifiedby,    modifieddate,      
 wrkreqno,   group_task_desc,   group_node_task )      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    group_name,      
 group_task_name, task_seqno,     class_name,    display_text,      
 @user,    @time,      @user,     @time,      
 '',     group_task_desc,            group_node_task      
 From de_published_ui_toolbar a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_ui_toolbar_dtl x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.group_name  = a.group_name      
      and  x.group_task_name = a.group_task_name )      
      
      
 insert into ep_ui_toolbar_group_dtl      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    group_name,      
 createdby,   createddate,    modifiedby,    modifieddate,      
 wrkreqno,   group_descr )      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    group_name,      
 @user,    @time,      @user,     @time,      
 '',     group_descr      
 From de_published_ui_toolbar_group a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_ui_toolbar_group_dtl x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.group_name  = a.group_name )      
      
      
 insert into ep_ui_toolbar_mapping_dtl      
 (customer_name,  project_name,    req_no,     process_name,      
 component_name,  activity_name,    ui_name,    toolbar_id,      
 group_task_name, display_seqno,    class_name,    display_text,      
 caption_req,  control_req,    createdby,    createddate,      
 modifiedby,   modifieddate,    wrkreqno )      
      
 Select customer_name, project_name,   'base',     process_name,      
 component_name,  activity_name,    ui_name,    toolbar_id,      
 group_task_name, display_seqno,    class_name,    display_text,      
 caption_req,  control_req,    @user,     @time,      
 @user,    @time,      ''      
 From de_published_ui_toolbar_mapping a(nolock)      
 where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name   
 and  not exists (Select 'M' From ep_ui_toolbar_mapping_dtl x(nolock)      
      Where x.customer_name  = a.customer_name      
      and  x.project_name  = a.project_name      
      and  x.req_no   = 'Base'      
      and  x.process_name  = a.process_name      
      and  x.component_name = a.component_name      
      and  x.activity_name  = a.activity_name      
      and  x.ui_name   = a.ui_name      
      and  x.toolbar_id  = a.toolbar_id      
      and  x.group_task_name = a.group_task_name )      
      
 /* Code added by Makesh prabu For phase3 & phase4 Release cross fixing on 17-March-2010 ends -- PNR2.0_26143 */      
      
 /*Code added by Gankan.G for the CaseId: PNR2.0_31306 to add new table starts*/      
      
 insert into ep_ui_pageevents_dtl      
     (customer_name,              project_name,               process_name,    component_name,       
      activity_name,             ui_name,               page_bt_synonym,   horder,      
      vorder,                    EventRequired,              Task_Onclick,    SystemGenerated,      
      timestamp,                 createdby,                  createddate,    modifiedby,      
      modifieddate )      
 select a.customer_name,            a.project_name,             a.process_name,    a.component_name,      
   a.activity_name,            a.ui_name,                  a.page_bt_synonym,   a.horder,      
   a.vorder,     a.EventRequired,   a.Task_Onclick,    a.SystemGenerated,      
   a.timestamp,                @user,      @time,      @user,      
   @time      
 from de_published_ui_pageevents  a (nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name   = @dst_project_name      
 and  a.process_name   = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  a.ecrno    = @temp_ecr_no      
 and  not exists ( select 'x'      
       from ep_ui_pageevents_dtl  c (nolock)      
       where  c.customer_name   = a.customer_name              
       and  c.project_name    = a.project_name        
       and  c.process_name         = a.process_name      
       and  c.component_name       = a.component_name            
       and  c.activity_name      = a.activity_name            
       and  c.ui_name              = a.ui_name      
       and  c.page_bt_synonym     = a.page_bt_synonym            
       and  c.EventRequired         = a.EventRequired      
       and  c.Task_Onclick      = a.Task_Onclick            
       )      
      
 /*Code added by Gankan.G for the CaseId: PNR2.0_31306 to add new table ends */      
      
 /* code added by Karthik M*/      
      
      
 insert into ep_custom_listedit       
(      
customer_name,project_name,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,listedit_synonym,list_search_id,      
list_search_context,list_index_search,list_recurrent_search,list_search_delay,      
list_select_column,list_result_column,list_width)      
select      
 a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,      
a.ui_name,a.page_bt_synonym,a.listedit_synonym,a.list_search_id,      
a.list_search_context,a.list_index_search,a.list_recurrent_search,a.list_search_delay,      
a.list_select_column,a.list_result_column,a.list_width      
from   de_published_custom_listedit  a    (nolock),      
        ep_ui_page_dtl       b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name    = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
 and  b.page_bt_synonym   = a.page_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_custom_listedit c (nolock)      
                                                where  c.customer_name             = a.customer_name                                                   
                                                and    c.project_name             = a.project_name              
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
                                                and    c.listedit_synonym         = a.listedit_synonym        
                               )      
insert into ep_ui_combolink_dtl        
(      
customer_name,project_name,req_no,process_name,component_name,      
a.activity_name,a.ui_name,a.Combo_control_bt_synonym,link_control_bt_synonym,      
link_control_caption,Display_seqno,separatelink_req,map)      
select a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.Combo_control_bt_synonym,a.link_control_bt_synonym,      
a.link_control_caption,a.Display_seqno,a.separatelink_req,a.map      
from   de_published_ui_combolink  a      (nolock),      
        ep_ui_mst    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
       and           not exists (  select 'x'      
                                                from   ep_ui_combolink_dtl c (nolock)      
                                                where  c.customer_name             = a.customer_name                                                   
                                                and    c.project_name             = a.project_name              
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                     and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.Combo_control_bt_synonym = a.Combo_control_bt_synonym      
                                                and    c.link_control_bt_synonym  = a.link_control_bt_synonym        
                                          )      
      
insert into ep_ui_device_grid_dtl          
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,      
column_bt_synonym,attributevalue,attributename)      
select      
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,      
a.column_bt_synonym,a.attributevalue,a.attributename      
from   de_published_ui_device_grid  a      (nolock),      
        ep_ui_mst    b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
       and           not exists (  select 'x'      
                                                from   ep_ui_device_grid_dtl c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name              
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name         = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
            and    c.section_bt_synonym       = a.section_bt_synonym      
            and    c.page_bt_synonym          = a.page_bt_synonym      
                                                and    c.control_bt_synonym       = a.control_bt_synonym      
            and    c.column_bt_synonym        = a.column_bt_synonym      
                                                and    c.attributename            = a.attributename        
                                                )      
                  
insert into ep_ui_device_control_dtl           
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,      
attributename,attributevalue,control_id,view_name)      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,      
a.attributename,a.attributevalue,a.controlid,a.viewname      
from   de_published_ui_device_control  a      (nolock),      
        ep_ui_section_dtl  b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
 and  b.page_bt_synonym   = a.page_bt_synonym      
 and  b.section_bt_synonym  = a.section_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_ui_device_control_dtl c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name        = a.project_name         
            and    c.req_no                    = 'Base'          
                             and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
                                                and    c.section_bt_synonym       = a.section_bt_synonym        
            and    c.control_bt_synonym        = a.control_bt_synonym      
                                                and    c.attributename             = a.attributename        
                                                )      
insert into ep_ui_device_page_dtl             
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,attributename,attributevalue)      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.attributename,a.attributevalue      
      
from   de_published_ui_device_page  a      (nolock),      
        ep_ui_mst      b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
       and           not exists (  select 'x'      
                                                from   ep_ui_device_page_dtl c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name         
            and    c.req_no                    = 'Base'          
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
                                                and    c.attributename             = a.attributename        
                                                )      
      
                  
      
      
insert into ep_ui_device_grid_dtl            
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,      
column_bt_synonym,attributename,attributevalue,control_id,view_name)      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,      
a.column_bt_synonym,a.attributename,a.attributevalue,a.controlid,a.viewname      
from   de_published_ui_device_grid  a      (nolock),      
        ep_ui_control_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  b.customer_name  = a.customer_name      
 and  b.project_name  = a.project_name      
 and  b.process_name  = a.process_name      
 and  b.component_name = a.component_name      
 and  b.activity_name  = a.activity_name      
 and  b.ui_name   = a.ui_name       
 and  b.page_bt_synonym = a.page_bt_synonym      
 and  b.control_bt_synonym = a.control_bt_synonym      
       and           not exists (  select 'x'      
                               from   ep_ui_device_grid_dtl c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name         
            and    c.req_no                    = 'Base'          
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name   = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
                                    and    c.section_bt_synonym       = a.section_bt_synonym        
            and    c.control_bt_synonym        = a.control_bt_synonym      
            and    c.column_bt_synonym        = a.column_bt_synonym      
                                                and    c.attributename             = a.attributename        
                                                )      
insert into ep_ui_device_section_dtl             
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,attributename,attributevalue)      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,      
a.attributename,a.attributevalue      
from    de_published_ui_device_section  a      (nolock),      
        ep_ui_page_dtl       b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
 and  b.page_bt_synonym   = a.page_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_ui_device_section_DTL  c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name         
            and    c.req_no                    = 'Base'          
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
                                                and    c.section_bt_synonym       = a.section_bt_synonym        
                                                and    c.attributename             = a.attributename        
                                                )      
      
       
      
insert into ep_ui_placeholder_dtl_lng_extn             
(      
customer_name,process_name,component_name,activity_name,ui_name,      
control_bt_synonym,placeholder,control_id,view_name,timestamp,      
languageid,project_name,req_no)--iskey,--Kyseq_no      
select       
a.customer_name,a.process_name,a.component_name,a.activity_name,a.ui_name,      
a.control_bt_synonym,a.placeholder,a.control_id,a.view_name,a.timestamp,      
a.languageid,a.project_name,--a.ecrno 
'Base' -- Added against TECH-73972             
      
from    de_published_ui_placeholder_lng_extn  a      (nolock),      
        ep_ui_control_dtl  b(nolock)      
 where a.customer_name   = @dst_customer_name      
 and  a.project_name   = @dst_project_name      
 and  a.ecrno     = @temp_ecr_no      
 and  a.process_name   = @dst_process_name      
 and  a.component_name  = @dst_component_name      
 and  b.customer_name   = a.customer_name      
 and  b.project_name   = a.project_name      
 and  b.process_name   = a.process_name      
 and  b.component_name  = a.component_name      
 and  b.activity_name   = a.activity_name      
 and  b.ui_name    = a.ui_name       
 --and  b.page_bt_synonym  = a.page_bt_synonym      
 and  b.control_bt_synonym = a.control_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_ui_placeholder_dtl_lng_extn  c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name         
            and    c.req_no                    = 'Base'          
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.control_bt_synonym       = a.control_bt_synonym      
                                                and    c.languageid                = a.languageid       
                                                )      
        
         
insert into ep_ui_section_control_map_dtl             
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,      
control_bt_synonym,control_id,view_name)      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,      
a.control_bt_synonym,a.control_id,a.view_name      
      
from    de_published_ui_section_control_map  a      (nolock),      
        ep_ui_section_dtl  b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
 and  b.page_bt_synonym   = a.page_bt_synonym      
 and  b.section_bt_synonym = a.section_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_ui_section_control_map_dtl  c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name         
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and  c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym           = a.page_bt_synonym      
            and    c.section_bt_synonym        = a.section_bt_synonym      
            and    c.control_bt_synonym       = a.control_bt_synonym        
                                                  )       
                  
insert into ep_ui_tooltip_dtl_lng_extn             
(      
customer_name,project_name,req_no,process_name,component_name,      
activity_name,ui_name,page_bt_synonym,section_bt_synonym,      
control_bt_synonym,column_bt_synonym,tooltip,control_id,      
view_name,timestamp,languageid)--iskey,--Kyseq_no      
select       
a.customer_name,a.project_name,a.ecrno,a.process_name,a.component_name,      
a.activity_name,a.ui_name,a.page_bt_synonym,a.section_bt_synonym,      
a.control_bt_synonym,a.column_bt_synonym,a.tooltip,a.control_id,      
a.view_name,a.timestamp,a.languageid      
      
from       de_published_ui_tooltip_lng_extn  a      (nolock),      
        ep_ui_control_dtl  b(nolock)      
 where a.customer_name  = @dst_customer_name      
 and  a.project_name  = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name  = @dst_process_name      
 and  a.component_name = @dst_component_name      
 and  b.customer_name  = a.customer_name      
 and  b.project_name  = a.project_name      
 and  b.process_name  = a.process_name      
 and  b.component_name = a.component_name      
 and  b.activity_name  = a.activity_name      
 and  b.ui_name   = a.ui_name       
 and  b.page_bt_synonym = a.page_bt_synonym      
 and  b.control_bt_synonym= a.control_bt_synonym      
       and           not exists (  select 'x'      
                                                from   ep_ui_tooltip_dtl_lng_extn  c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                                                and    c.project_name             = a.project_name        
            and    c.req_no                   = 'base'         
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym           = a.page_bt_synonym      
            and    c.section_bt_synonym        = a.section_bt_synonym      
            and    c.control_bt_synonym       = a.control_bt_synonym        
            and    c.column_bt_synonym        = a.column_bt_synonym      
            and    c.languageid                = a.languageid        
            )       
      
       
insert into ep_user_section_dtl             
(      
customer_name,project_name,process_name,component_name,activity_name,      
ui_name,page_bt_synonym,section_bt_synonym,type,include_text,      
include_value,languageid,reqno)      
select       
a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,      
a.ui_name,a.page_bt_synonym,a.section_bt_synonym,a.type,a.include_text,      
a.include_value,a.languageid,a.ecrno      
      
from       de_published_user_section  a      (nolock),      
        ep_ui_section_dtl  b (nolock)      
 where  a.customer_name       = @dst_customer_name      
 and  a.project_name        = @dst_project_name      
 and  a.process_name        = @dst_process_name      
 and  a.component_name      = @dst_component_name      
 and  a.ecrno      = @temp_ecr_no      
 and  b.customer_name    = a.customer_name      
 and  b.project_name    = a.project_name      
 and  b.process_name    = a.process_name      
 and  b.component_name   = a.component_name      
 and  b.activity_name    = a.activity_name      
 and  b.ui_name     = a.ui_name       
 and  b.page_bt_synonym   = a.page_bt_synonym      
 and  b.section_bt_synonym =  a.section_bt_synonym      
       and           not exists (  select 'x'      
                    from   ep_user_section_dtl  c (nolock)      
                                                where  c.customer_name            = a.customer_name                                                   
                  and    c.project_name             = a.project_name        
            and    c.reqno       = 'base'         
                                                and    c.process_name             = a.process_name      
                                                and    c.component_name           = a.component_name                                           
                                                and    c.activity_name            = a.activity_name            
                                                and    c.ui_name                  = a.ui_name      
                                                and    c.page_bt_synonym          = a.page_bt_synonym      
            and    c.section_bt_synonym        = a.section_bt_synonym      
            and    c.type                      = a.type        
            and    c.languageid                = a.languageid      
            and    c.include_value             = a.include_value        
            )        
                  
   /* code added by Karthik M*/      
      
/* NEW TABLES ADDED BY SRIKANTH FOR TECH-46328 --starts */      
INSERT INTO ep_sync_view        
     (Customer_name   ,Project_name   ,req_no      ,process_name,        
     component_name   ,activity_name   ,ui_name     ,map_le_controlid,        
     page_bt_synonym  ,section_bt_synonym  ,legrid_control_bt_syonym ,legrid_control_id,      
  legrid_view_name  ,map_le_synonym   ,map_le_column_synonym  ,map_le_viewname,      
  map_legrid_view_name,  createdby    ,createddate    ,modIFiedby,         
  modIFieddate,    legrid_column_bt_synonym, map_legrid_column_bt_synonym )        
 SELECT DISTINCT      
     Customer_name   ,Project_name   ,'base'      ,process_name,        
     component_name   ,activity_name   ,ui_name     ,map_le_controlid,        
     page_bt_synonym  ,section_bt_synonym  ,legrid_control_bt_syonym ,legrid_control_id,      
  legrid_view_name  ,map_le_synonym   ,map_le_column_synonym  ,map_le_viewname,      
  map_legrid_view_name,  createdby    ,created_date    ,modIFiedby,         
  modIFieddate,    legrid_column_bt_synonym, map_legrid_column_bt_synonym      
 from de_published_sync_view a(nolock)      
    where  a.customer_name     = @dst_customer_name      
 and  a.project_name      = @dst_project_name      
 and  a.ecrno    = @temp_ecr_no      
 and  a.process_name      = @dst_process_name      
 and  a.component_name    = @dst_component_name      
 and  not exists (Select 'M' From ep_sync_view x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name    = a.ui_name      
      and  x.page_bt_synonym   = a.page_bt_synonym      
      and  x.section_bt_synonym   = a.section_bt_synonym      
      and  x.legrid_control_id   = a.legrid_control_id      
      and  x.legrid_view_name   = a.legrid_view_name       
      and  x.map_le_column_synonym  = a.map_le_column_synonym)      
           
            
insert into ep_responsive_sec_weightage       
  (customer_name  ,project_name  ,req_no    ,process_name,      
   component_name  ,activity_name  ,ui_name   ,Formfactor      
   ,page_bt_synonym ,parent_section  ,section_bt_synonym ,Weightage,      
   SectionWidth  ,timestamp   ,createdby   ,createddate,      
   modifiedby   ,modifieddate)      
 select DISTINCT      
   customer_name  ,project_name  ,'base'    ,process_name,      
   component_name  ,activity_name  ,ui_name   ,Formfactor      
   ,page_bt_synonym ,parent_section  ,section_bt_synonym ,Weightage,      
   SectionWidth  ,timestamp   ,createdby   ,createddate,      
   modifiedby   ,modifieddate      
 from de_published_responsive_sec_weightage a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_responsive_sec_weightage x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and  x.Formfactor    = a.Formfactor      
      and  x.page_bt_synonym   = a.page_bt_synonym      
      and  x.parent_section   = a.parent_section      
      and  x.section_bt_synonym   = a.section_bt_synonym)      
      
      
insert into ep_Calendar_configure        
   (customer_name  ,project_name  ,Req_no   ,Process_name      
    ,Component_name  ,Activity_name  ,ui_name  ,page_name,      
    section_name  ,DefaultTemplate ,detailspane ,doubletap_req,        
 doubletap_event  ,drag_req   ,dragevent  ,editable,       
 eventstyle   ,listview_req  ,month_nav_event,month_nav_req,       
 monthview_cal  ,tap_req   ,tapevent  ,week_nav_req,       
 week_nav_event  ,weekview_cal  ,timestamp  ,createdby,        
    createddate   ,modifiedby   ,modifieddate  )      
 select distinct       
    customer_name  ,project_name  ,'base'   ,Process_name      
    ,Component_name  ,Activity_name  ,ui_name  ,page_name,      
    section_name  ,DefaultTemplate ,detailspane ,doubletap_req,        
 doubletap_event  ,drag_req   ,dragevent  ,editable,       
 eventstyle   ,listview_req  ,month_nav_event,month_nav_req,       
 monthview_cal  ,tap_req   ,tapevent  ,week_nav_req,       
 week_nav_event  ,weekview_cal  ,timestamp  ,createdby,        
    createddate   ,modifiedby   ,modifieddate       
 from de_published_calendar_configure a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_Calendar_configure x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.page_name     = a.page_name      
      and  x.section_name    = a.section_name)      
      
-- 11537 code changes starts      
      
insert into ep_ui_columngroup        
   (customer_name  ,project_name,    Req_no   ,Process_name      
    ,Component_name  ,Activity_name,    ui_name   ,Page_bt_synonym,      
    section_bt_synonym, grid_control_bt_synonym, Group_name,  Group_caption,      
wrkreqno,   timestamp,     createdby,  createddate,      
 modifiedby,   modifieddate,    grouplevel,  groupseqno,      
 parentgroup,  parentgroupseq )      
       
 select distinct       
 customer_name  ,project_name,    'base'   ,Process_name      
    ,Component_name  ,Activity_name,    ui_name   ,Page_bt_synonym,      
    section_bt_synonym, grid_control_bt_synonym, Group_name,  Group_caption,      
 '',     timestamp,     createdby,  createddate,      
 modifiedby,   modifieddate,    grouplevel,  groupseqno,      
 parentgroup,  parentgroupseq      
 from de_published_ui_columngroup a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_ui_columngroup x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.Page_bt_synonym   = a.Page_bt_synonym      
      and  x.section_bt_synonym  = a.section_bt_synonym      
      and  x.grid_control_bt_synonym = a.grid_control_bt_synonym      
      and  x.Group_name    = a.Group_name )      
      
      
      
insert into ep_ui_column_group_mapping        
   (customer_name  ,project_name,    Req_no   ,Process_name      
    ,Component_name  ,Activity_name,    ui_name   ,Page_bt_synonym,      
    section_bt_synonym, grid_control_bt_synonym, Group_name,  column_bt_synonym,      
 SequenceNo,   mapped_entity,    wrkreqno,  timestamp,      
 createdby,   createddate,    modifiedby,  modifieddate )      
       
 select distinct       
 customer_name  ,project_name,    'base'   ,Process_name      
    ,Component_name  ,Activity_name,    ui_name   ,Page_bt_synonym,      
    section_bt_synonym, grid_control_bt_synonym, Group_name,  column_bt_synonym,      
 SequenceNo,   mapped_entity,    '',    timestamp,      
 createdby,   createddate,    modifiedby,  modifieddate       
      
 from de_published_ui_column_group_mapping a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_ui_column_group_mapping x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.Page_bt_synonym   = a.Page_bt_synonym      
      and  x.section_bt_synonym  = a.section_bt_synonym      
      and  x.grid_control_bt_synonym = a.grid_control_bt_synonym      
      and  x.Group_name    = a.Group_name )      
      
       
insert into ep_pivot_configure        
   (customer_name  ,project_name,   Req_no   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, configpan_pos,   rowgrandtot_pos, rowsubtot_pos,      
 colgrandtot_pos, colsubtot_pos,   rowgrandtot_text, colgrandtot_text,      
 rowsubtot_text,  colsubtot_text,   timestamp,   createdby,      
 createddate,  modifiedby,    modifieddate )      
       
 select distinct       
 customer_name  ,project_name,   'base'   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, configpan_pos,   rowgrandtot_pos, rowsubtot_pos,      
 colgrandtot_pos, colsubtot_pos,   rowgrandtot_text, colgrandtot_text,      
 rowsubtot_text,  colsubtot_text,   timestamp,   createdby,      
 createddate,  modifiedby,    modifieddate      
 from de_published_pivot_configure a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_pivot_configure x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.page_name     = a.page_name      
      and  x.Control_bt_synonym  = a.Control_bt_synonym )      
      
       
insert into ep_pivot_fields        
   (customer_name  ,project_name,   Req_no   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, column_bt_synonym,  rowlabel,   columnlabel,      
 fieldValue,   rowlabelseq,   columnlabelseq, valueseq,      
 ValueFunction,  rowlabelsorting,  columnlabelsorting, timestamp,      
 createdby,   createddate,   modifiedby,   modifieddate
 --collable,   Value,     collabelseq,  collablesorting      
 )      
       
 select distinct       
 customer_name  ,project_name,   'base'   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, column_bt_synonym,  rowlabel,   columnlabel,      
 fieldValue,   rowlabelseq,   columnlabelseq,  valueseq,      
 ValueFunction,  rowlabelsorting,  columnlabelsorting, timestamp,      
 createdby,   createddate,   modifiedby,   modifieddate--,      
 --collable,   Value,     collabelseq,  collablesorting      
 from de_published_pivot_fields a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_pivot_fields x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.page_name     = a.page_name      
      and  x.Control_bt_synonym  = a.Control_bt_synonym )      
      
insert into ep_pivot_lang_extn        
   (customer_name  ,project_name,   Req_no   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, DisplayField,   Languageid,   DisplayText,      
 timestamp,   createdby,    createddate,  modifiedby,      
 modifieddate      
 )      
       
 select distinct       
 customer_name  ,project_name,   'base'   , Process_name      
    ,Component_name  ,Activity_name,   ui_name   , page_name,      
 Control_bt_synonym, DisplayField,   Languageid,   DisplayText,      
 timestamp,   createdby,    createddate,  modifiedby,      
 modifieddate      
 from de_published_pivot_lang_extn a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_pivot_lang_extn x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.page_name     = a.page_name      
      and  x.Control_bt_synonym  = a.Control_bt_synonym      
      and  x.DisplayField    = a.DisplayField      
      and  x.Languageid    = a.Languageid )      
                        
-- 11537 code changes starts      
      
/* NEW TABLES ADDED BY SRIKANTH FOR TECH-46328 --ends */      
      
/*Code added by Srikanth for the call id TECH-46556 --starts  */       
insert into ep_els_query_listedit_input        
   (      
  CustomerName,  ProjectName,  Reqno,   ProcessName,      
  ComponentName,  ActivityName,  UiName,   ListControlSynonym,      
  ListControlID,  ListViewname,  QueryID,  ParameterName,      
  MappedSynonym,  MappedControlID, MappedViewName, Createdby,      
  Createddate,  Modifedby,   Modifieddate      
   )      
       
 select distinct       
  CustomerName,  ProjectName,  'base',   ProcessName,      
  ComponentName,  ActivityName,  UiName,   ListControlSynonym,      
  ListControlID,  ListViewname,  QueryID,  ParameterName,      
  MappedSynonym,  MappedControlID, MappedViewName, Createdby,      
  Createddate,  Modifedby,   Modifieddate      
  from de_published_els_query_listedit_input a(nolock)      
  where  a.CustomerName     = @dst_customer_name      
  and  a.ProjectName      = @dst_project_name      
  and  a.Ecrno    = @temp_ecr_no      
  and  a.ProcessName      = @dst_process_name      
  and  a.ComponentName    = @dst_component_name      
  and  not exists (Select 'M' From ep_els_query_listedit_input x(nolock)      
      Where x.CustomerName    = a.CustomerName      
      and  x.ProjectName    = a.ProjectName      
      and  x.Reqno     = 'Base'      
      and  x.ProcessName    = a.ProcessName      
      and  x.ComponentName   = a.ComponentName      
      and  x.ActivityName    = a.ActivityName      
      and  x.UiName     = a.UiName      
      and     x.ListControlID     = a.ListControlID      
      and     x.ListViewname     = a.ListViewname      
      and     x.QueryID     = a.QueryID      
      and  x.ParameterName  = a.ParameterName )      
            
insert into ep_els_query_listedit_map        
   (      
  CustomerName,  ProjectName,  Reqno,  ProcessName,      
  ComponentName,  ActivityName,  UiName,  ListControlSynonym,      
  ListControlID,  ListViewname,  QueryID, SearchIndex,      
  Pagesize,   Createdby,   Createddate,Modifedby,  Modifieddate      
   )      
       
 select distinct       
  CustomerName,  ProjectName,  'base',  ProcessName,      
  ComponentName,  ActivityName,  UiName,  ListControlSynonym,      
  ListControlID,  ListViewname,  QueryID, SearchIndex,      
  Pagesize,   Createdby,   Createddate,Modifedby, Modifieddate      
  from de_published_els_query_listedit_map a(nolock)      
  where  a.CustomerName     = @dst_customer_name      
  and  a.ProjectName      = @dst_project_name      
  and  a.Ecrno    = @temp_ecr_no      
  and  a.ProcessName      = @dst_process_name      
  and  a.ComponentName    = @dst_component_name      
  and  not exists (Select 'M' From ep_els_query_listedit_map x(nolock)      
      Where x.CustomerName    = a.CustomerName      
      and  x.ProjectName    = a.ProjectName      
      and  x.Reqno     = 'Base'      
      and  x.ProcessName    = a.ProcessName      
      and  x.ComponentName   = a.ComponentName      
      and  x.ActivityName    = a.ActivityName      
      and  x.UiName     = a.UiName      
      and     x.ListControlID     = a.ListControlID      
      and     x.ListViewname     = a.ListViewname      
      and     x.QueryID     = a.QueryID )      
            
insert into ep_els_query_listedit_result        
   (      
  CustomerName,  ProjectName,  Reqno,   ProcessName,      
  ComponentName,  ActivityName,  UiName,   ListControlSynonym,      
  ListControlID,  ListViewname,  QueryID,  ResultColumnName,      
  MappedSynonym,  MappedControlID, MappedViewName, ParameterCaption,      
  Width,    IsVisible,   Createdby,  Createddate,      
  Modifedby,   Modifieddate,  Seqno      
   )      
       
 select distinct       
  CustomerName,  ProjectName,  'base',   ProcessName,      
  ComponentName,  ActivityName,   UiName,  ListControlSynonym,      
  ListControlID,  ListViewname,   QueryID,  ResultColumnName,      
  MappedSynonym,  MappedControlID,  MappedViewName,ParameterCaption,      
  Width,    IsVisible,    Createdby,  Createddate,      
  Modifedby,   Modifieddate,   Seqno      
  from de_published_els_query_listedit_result a(nolock)      
  where  a.CustomerName     = @dst_customer_name      
  and  a.ProjectName      = @dst_project_name      
  and  a.Ecrno    = @temp_ecr_no      
  and  a.ProcessName      = @dst_process_name      
  and  a.ComponentName    = @dst_component_name      
  and  not exists (Select 'M' From ep_els_query_listedit_result x(nolock)      
      Where x.CustomerName    = a.CustomerName      
      and  x.ProjectName    = a.ProjectName      
      and  x.Reqno     = 'Base'      
      and  x.ProcessName    = a.ProcessName      
      and  x.ComponentName   = a.ComponentName      
      and  x.ActivityName    = a.ActivityName      
      and  x.UiName     = a.UiName      
      and     x.ListControlID     = a.ListControlID      
      and     x.ListViewname     = a.ListViewname      
      and     x.QueryID     = a.QueryID       
      and     x.ResultColumnName   = a.ResultColumnName )      
      
insert into ep_ui_section_refinement        
   (      
  customer_name,  project_name,  req_no,   process_name,      
  component_name,  activity_name,  ui_name,  Formfactor,      
  page_bt_synonym, section_bt_synonym, visible_flag, timestamp,      
  createdby,   createddate,  modifiedby,  modifieddate      
   )      
       
 select distinct       
  customer_name,  project_name,  'base',   process_name,      
  component_name,  activity_name,  ui_name,  Formfactor,      
  page_bt_synonym, section_bt_synonym, visible_flag, timestamp,      
  createdby,   createddate,  modifiedby,  modifieddate      
  from de_published_ui_section_refinement a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_ui_section_refinement x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.Formfactor    = a.Formfactor      
      and     x.page_bt_synonym   = a.page_bt_synonym      
      and     x.section_bt_synonym  = a.section_bt_synonym )      
      
insert into ep_nativeapp_mapping        
   (      
  customer_name,  project_name,    req_no,     process_name,      
  component_name,  activity_name,    ui_name,    page_bt_synonym,      
  section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym,control_hiddenview,      
  control_id,   view_name,     GridControlID,   GridViewName,      
  timestamp,   createdby,     createddate,   modifiedby,  modifieddate      
   )      
       
 select distinct       
  customer_name,  project_name,    'base',     process_name,      
  component_name,  activity_name,    ui_name,    page_bt_synonym,      
  section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym,control_hiddenview,      
  control_id,   view_name,     GridControlID,   GridViewName,      
  timestamp,   createdby,     createddate,   modifiedby,  modifieddate      
  from de_published_nativeapp_mapping a(nolock)      
  where  a.customer_name     = @dst_customer_name      
  and  a.project_name      = @dst_project_name      
  and  a.ecrno    = @temp_ecr_no      
  and  a.process_name      = @dst_process_name      
  and  a.component_name    = @dst_component_name      
  and  not exists (Select 'M' From ep_nativeapp_mapping x(nolock)      
      Where x.customer_name    = a.customer_name      
      and  x.project_name    = a.project_name      
      and  x.req_no     = 'Base'      
      and  x.process_name    = a.process_name      
      and  x.component_name   = a.component_name      
      and  x.activity_name    = a.activity_name      
      and  x.ui_name     = a.ui_name      
      and     x.control_Hidden_bt_synonym = a.control_Hidden_bt_synonym      
      and     x.MappedGridColumnSynonym = a.MappedGridColumnSynonym      
      and     x.page_bt_synonym   = a.page_bt_synonym      
      and     x.section_bt_synonym  = a.section_bt_synonym )      
      
               
      
/*Code added by Srikanth for the call id TECH-46556 --ends  */      
  
/* Code added by Srikanth for the call id TECH-47484 --starts */  
    
if exists (select 'x' from ep_ui_mst a(nolock),    
              engg_mr_ui_mst_203_1 c (NOLOCK)           
WHERE  a.Customer_name            =      @dst_customer_name         
AND           a.Project_name             =      @dst_project_name    
AND           a.process_name   =      @dst_process_name --changes    AND           a.component_name=      @dst_component_name --changes    
AND           c.mig_id                   =      @mig_id     
AND           a.Customer_name            =      c.dst_customer_name    
AND           a.project_name             =      c.dst_project_name     
AND           a.process_name             =      c.dst_process_name    
AND           a.component_name     =      c.dst_component_name     
AND           a.Activity_Name            =      c.dst_activity_name     
AND           a.UI_Name                  =      c.dst_ui_name     
AND           c.act_mig_flag             =      1    
AND           c.ISGlance                 =      'y')    
    
begin     
    
    
INSERT INTO ngplf_wr_glossary              
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   BTSynonymCaption,DataType,    
DataTypeLength,   DecimalLength,   BTName, BTSynDocumentation ,    
ModeFlag,    TimeStamp,  CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )     
     
select a.customerid,   a.projectid,   'base',    a.bpid,      
a.componentname,  a.componentname,a.componentname  ,    'char',      
'40',  null,         null,  a.componentname,    
'',     '1',     @user,    @time,      
@user,@time    
from fw_bpt_function_component a (nolock)      
where a.CustomerID = @dst_customer_name      
and  a.ProjectID  = @dst_project_name      
and  a.BPID   = @dst_process_name      
and  a.ComponentName = @dst_component_name      
and  not exists  ( select '*'      
from ngplf_wr_glossary c (nolock)      
where c.customerid  = a.CustomerID      
and  c.projectid   = a.ProjectID      
and  c.DocNo    = 'base'      
and  c.ProcessName   = a.BPID      
and  c.ComponentName  = a.ComponentName      
and  c.BTSynonymName = @dst_component_name      
)  --doubt    
        
INSERT INTO ngplf_wr_glossary              
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   BTSynonymCaption,DataType,    
DataTypeLength,   DecimalLength,   BTName, BTSynDocumentation ,    
ModeFlag,    TimeStamp,  CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )     
select a.customerid,   a.projectid,   'base',    a.bpid,      
b.componentname, a.activityid,a.activityname,'char',    
'40',null, null ,a.ActivityDesc,    
null, '1', @user,@time,    
@user,@time    
        
from fw_bpt_activity    a (nolock),      
fw_bpt_function_component b (nolock)      
where a.CustomerID = @dst_customer_name      
and  a.ProjectID  = @dst_project_name      
and  a.BPID   = @dst_process_name      
and  a.FunctionID = @functionid      
and  a.CustomerID = b.CustomerID      
and  a.ProjectID  = b.ProjectID      
and  a.BPID   = b.BPID      
and  a.FunctionID = b.FunctionID      
and  b.componentname = @dst_component_name      
and  not exists ( select '*'      
from ngplf_wr_glossary gls (nolock)      
where gls.CustomerID = a.customerid      
and  gls.ProjectID = a.projectid      
and  gls.DocNo   = 'base'      
and  gls.ProcessName = a.bpid      
and  gls.ComponentName = b.componentname      
and  gls.BTSynonymName = a.activityid      
)      
       
INSERT INTO ngplf_wr_glossary              
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   BTSynonymCaption,DataType,    
DataTypeLength,   DecimalLength,   BTName, BTSynDocumentation ,    
ModeFlag,    TimeStamp,  CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )    
    
select a.customerid,   a.projectid,   'base',    a.bpid,      
b.componentname,  a.UIID, a.UIName ,'char',    
'40',null , null ,a.UIDesc,    
null, '1',@user,@time,    
@user,@time    
from fw_bpt_ui    a (nolock),      
fw_bpt_function_component b (nolock)      
where a.CustomerID = @dst_customer_name      
and  a.ProjectID  = @dst_project_name      
and  a.BPID   = @dst_process_name      
and  a.FunctionID = @functionid      
and  a.CustomerID = b.CustomerID      
and  a.ProjectID  = b.ProjectID      
and  a.BPID   = b.BPID      
and  a.FunctionID = b.FunctionID      
and  b.componentname = @dst_component_name      
and  not exists ( select '*'      
from ngplf_wr_glossary gls (nolock)      
where gls.CustomerID = a.customerid      
and  gls.ProjectID = a.projectid      
and  gls.DocNo   = 'base'      
and  gls.ProcessName = a.bpid      
and  gls.ComponentName = b.componentname      
and  gls.BTSynonymName = a.UIID      
)      
     
     
    
--   ngplf_wr_glossary_local_info starts --    
INSERT INTO ngplf_wr_glossary_local_info       
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   LanguageID,  BTSynonymCaption,     
BTSynDocumentation,  TimeStamp,CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )     
select a.customerid,    a.projectid,   'base',    a.bpid,     
a.componentname,a.componentname,a.langid,a.componentname,    
a.componentname , '1',@user ,@time,    
@user,@time    
from Fw_Bpt_Function_Component a(nolock)    
where a.CustomerID = @dst_customer_name      
and  a.ProjectID  = @dst_project_name      
and  a.BPID   = @dst_process_name      
and  a.ComponentName = @dst_component_name     
and not exists ( select '*'      
from ngplf_wr_glossary_local_info gls (nolock)      
where gls.CustomerID = a.customerid      
and  gls.ProjectID = a.projectid      
and  gls.DocNo   = 'base'      
and  gls.ProcessName = a.bpid      
and  gls.ComponentName = a.componentname      
and  gls.BTSynonymName = a.ComponentName     
and  gls.LanguageID  = a.langid      
)      
INSERT INTO ngplf_wr_glossary_local_info       
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   LanguageID,  BTSynonymCaption,     
BTSynDocumentation,  TimeStamp,CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )     
select a.customerid,    a.projectid,   'base',    a.bpid,      
b.componentname,   a.activityid,a.LangID,a.activityname,    
a.ActivityDesc, '1', @user, @time,    
@user ,@time    
    
from  fw_bpt_activity    a (nolock),      
fw_bpt_function_component b (nolock)      
where  a.CustomerID = @dst_customer_name      
and   a.ProjectID  = @dst_project_name      
and   a.BPID   = @dst_process_name      
and   a.FunctionID = @functionid      
and   a.CustomerID = b.CustomerID      
and   a.ProjectID  = b.ProjectID      
and   a.BPID   = b.BPID      
and   a.FunctionID = b.FunctionID      
and   b.componentname = @dst_component_name      
and   not exists ( select '*'      
from ngplf_wr_glossary_local_info gls (nolock)      
where gls.CustomerID = a.customerid      
and  gls.ProjectID = a.projectid      
and  gls.DocNo   = 'base'      
and  gls.ProcessName = a.bpid      
and  gls.ComponentName = b.componentname      
and  gls.BTSynonymName = a.activityid      
and  gls.LanguageID  = a.langid      
)      
        
INSERT INTO ngplf_wr_glossary_local_info       
( CustomerID,    ProjectID,    DocNo, ProcessName,    
ComponentName,   BTSynonymName,   LanguageID,  BTSynonymCaption,     
BTSynDocumentation,  TimeStamp,CreatedBy,CreatedDate,    
ModifiedBy,    ModifiedDate )     
select a.customerid,    a.projectid,   'base',    a.bpid,      
b.componentname,   a.UIID,a.LangID,a.UIName,    
a.UIDesc, '1', @user,@time,    
@user, @time    
        
from  fw_bpt_ui     a (nolock),      
fw_bpt_function_component b (nolock)      
where  a.CustomerID = @dst_customer_name      
and   a.ProjectID  = @dst_project_name      
and   a.BPID   = @dst_process_name      
and   a.FunctionID = @functionid      
and   a.CustomerID = b.CustomerID      
and   a.ProjectID  = b.ProjectID      
and   a.BPID   = b.BPID      
and   a.FunctionID = b.FunctionID      
and   b.componentname = @dst_component_name      
and   not exists ( select '*'      
from ngplf_wr_glossary_local_info gls (nolock)      
where gls.CustomerID = a.customerid      
and  gls.ProjectID = a.projectid      
and  gls.DocNo   = 'base'      
and  gls.ProcessName = a.bpid      
and  gls.ComponentName = b.componentname      
and  gls.BTSynonymName = a.UIID      
and  gls.LanguageID  = a.langid      
)    
    
      
end    
/* Code added by Srikanth for the call id TECH-47484 --ends */  
    
set nocount off    
    
end    
  
GO
IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'engg_mr_Preview_population_203_2_2' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON engg_mr_Preview_population_203_2_2 TO PUBLIC
END
GO
