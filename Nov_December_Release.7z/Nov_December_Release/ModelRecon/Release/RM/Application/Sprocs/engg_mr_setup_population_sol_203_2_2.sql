IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='engg_mr_setup_population_sol_203_2_2' AND TYPE = 'P')
    Begin
        Drop PROC engg_mr_setup_population_sol_203_2_2
    End
GO
/***************************************************************************************    
Procedure Name And Id              :      engg_mr_setup_population_sol_203_2_2    
Description                       :    
Name Of The Author                 :      Kalaiarasan.K/Nupur    
Date Created                      :      07/02/2006    
Query File Name                  :      engg_mr_setup_population_sol_203_2_2.sql    
Modified By                       :    
Modified Date                     :    
modified purpose                  :    
Detailed Description               :     This SP is used to populate ES Level Tables with not exists logic,    
Because if we use delete and insert concept means may lot of new changes made in    
destination server may be lost.    
Modifications History              :    
*****************************************************************************************/    
/* modified by          : Makesh prabu.R            */    
/* modified date        :  08-April-2009            */    
/* modified purpose     :  PNR2.0_21056 --Extjs Relese, New columns, tables added  */    
/****************************************************************************************/    
/* modified by          : Makesh prabu.R            */    
/* modified date        :  27-April-2009            */    
/* modified purpose     :  PNR2.0_21991 --Adding New Columns       */    
/****************************************************************************************/    
/* modified by  : Makesh Prabu. R                                           */    
/* date         : 30-March-2010                                             */    
/* description  : For adding new columns added in phase3&4 releases      */    
/* BugID   : PNR2.0_26376                */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_28339               */    
/*  Date  : 25-November-2010              */    
/*  Description : script modified to include new  columns         */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_28990               */    
/*  Date  : 30-November-2010              */    
/*  Description : script modified to include new columns for Engg setup Tables   */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_32094               */    
/*  Date  : 05-Sep-2011               */    
/*  Description : script modified to include new column for Setup Tables    */    
/* Fix sent against Primary BugID : PNR2.0_32434          */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_32803               */    
/*  Date  : 05-Sep-2011               */    
/*  Description : script modified to include new column for Setup Tables    */    
/* Fix sent against Primary BugID : PNR2.0_32434          */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_34059               */    
/*  Date  : 11-Nov-2011               */    
/*  Description : script modified to include new column for Setup Tables    */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PNR2.0_35203               */    
/*  Date  : 02-Feb-2012               */    
/*  Description : script modified to include new column for model table     */    
/* Fix sent against Primary BugID : PNR2.0_35430   */    
/****************************************************************************************/    
/*  Modified By : Gankan. G                */    
/*  Call ID  : PLF2.0_00187               */    
/*  Date  : 15-May-2012               */    
/*  Description : script modified to include new column for model table     */    
/****************************************************************************************/    
/****************************************************************************************/    
/* MODIFIED BY  :GANESH PRABHU S /S.SRIKANTH(13705) */    
/* DATE      :09-05-2020 */    
/* Description  :Columns added for component split migration.  */    
/****************************************************************************************/    
/***********************************************************************************************/
/*modified by      :S.Srikanth */                               
/*date modified      :02/08/2020     */        
/*call-id            :TECH-47407 */  
/*1)Handling Glance schema in Model reconstruction tool.
2)Report_Type column added in sp based report segment table in Model migration
3)Es_comp_ctrl_type_mst_extn columns added in Model migration
4)UPEControlExpr column addition in de_fw_des_processsection_br_is table in Model migration
5)UPEComboFilling column addition in de_fw_des_service_segment table in Model migration
6)Handling migration schema for the defect id -TECH-47978 */
/**************************************************************************************************/   
/* Modified by : Manoj S   			Date: 04-Nov-2022  Defect ID: TECH-74235 				  	  */
/**************************************************************************************************/    
CREATE procedure  engg_mr_setup_population_sol_203_2_2        
@customername       engg_name,    
@projectname        engg_name,    
@processname       engg_name,    
@componentname        engg_name,    
@user           engg_ctxt_user,    
@time        engg_name,    
@link_server    engg_name,    
@link_db     engg_name,    
@link_user     engg_name,    
@tmp_ecr     engg_name,    
@mig_type     engg_name,    
@mig_id      engg_name    
as    
begin    
    
set nocount on    
    
declare   @ssql       nvarchar(max)  ,    
@dst_customer_name  engg_name,    
@dst_project_name  engg_name,    
@dst_process_name  engg_name,    
@dst_component_name  engg_name,    
@miguser    engg_name,    
@remarks    engg_description,    
@migdate    engg_date    
    
--SELECTING DESTINATION PROCESS AND COMPONENT DETAILS    
select @dst_customer_name  =  dst_customer_name,    
@dst_project_name  = dst_project_name,    
@dst_process_name   =  dst_process_name,    
@dst_component_name  = dst_component_name    
from engg_mr_ui_mst_203_1 a (nolock)    
where a.src_customer_name  = @customername    
and  a.src_project_name  = @projectname    
and  a.src_process_name   = @processname    
and  a.src_component_name = @componentname    
and  a.mig_id    =  @MIG_ID    
    
select @miguser = @user,    
@migdate = @time,    
@remarks = @mig_id,    
@time  = cast(@time as varchar)    
    
--select 'Debug start'        
--return        
    
if @mig_type = 'C'    
begin    
    
exec Engg_mr_Setup_History_Population_sol_203_2_2 @dst_customer_name,@dst_project_name,@dst_process_name,@dst_component_name,@miguser,@migdate,@remarks    
    
exec engg_mr_setup_del_sol_203_2_2  @dst_customer_name,@dst_project_name,@dst_process_name,@dst_component_name    
end    
    
--  select @ssql = ''    
--  select @ssql = @ssql + '  insert  into  es_business_term('   + char(10)    
--  select @ssql = @ssql + '      customer_name,       project_name,     bt_name,'   + char(10)    
--  select @ssql = @ssql + '      bt_descr,         data_type,       bt_sysid,'   + char(10)    
--  select @ssql = @ssql + '      timestamp,         createdby,       createddate,'  + char(10)    
--  select @ssql = @ssql + '      modifiedby,        modifieddate,     length,'   + char(10)    
--  select @ssql = @ssql + '      precision_type)'    + char(10)    
--  select @ssql = @ssql + '  select  '''+@dst_customer_name+''',  '''+@dst_project_name+''', bt_name,'   + char(10)    
--  select @ssql = @ssql + '      bt_descr,         data_type,       left(bt_name+bt_descr+data_type,40),'   + char(10)    
--  select @ssql = @ssql + '      timestamp,         '''+@user+''',       '''+@time+''',' + char(10)    
--  select @ssql = @ssql + '      '''+@user+''',        '''+@time+''',       length,'   + char(10)    
--  select @ssql = @ssql + '      precision_type'    + char(10)    
--  select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_business_term  a ' + char(10)    
--  select @ssql = @ssql + '  where  a.customer_name     = '''+ @customername + ''''  + char(10)    
--  select @ssql = @ssql + '  and    a.project_name     = '''+ @projectname + ''''   + char(10)    
--  select @ssql = @ssql + '  and    not exists ( '      + char(10)    
--  select @ssql = @ssql + '             select  ''x'' ' + char(10)    
--  select @ssql = @ssql + '             from   es_business_term c (nolock)'     + char(10)    
--  select @ssql = @ssql + '             where   c.customer_name   = '''+@dst_customer_name+''' '  + char(10)    
--  select @ssql = @ssql + '             and    c.project_name   = '''+@dst_project_name+''' '  + char(10)    
--  select @ssql = @ssql + '             and    c.bt_name     = a.bt_name) '    + char(10)    
--  exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_language_met('   + char(10)    
select @ssql = @ssql + '  customer_name,   quick_code_type,    quick_code, '   + char(10)    
select @ssql = @ssql + '  quick_code_value,   timestamp,      createdby, '   + char(10)    
select @ssql = @ssql + '  createddate,    modifiedby,      modifieddate )'   + char(10)    
select @ssql = @ssql + '  select distinct '''+@dst_customer_name+''', quick_code_type,  quick_code, '  + char(10)    
select @ssql = @ssql + '  quick_code_value,   timestamp,      '''+@user+''','  + char(10)    
select @ssql = @ssql + '  '''+@time+''',   '''+@user+''',         '''+@time+''''  + char(10)    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_language_met  a ' + char(10)    
select @ssql = @ssql + '  where    not exists ( '      + char(10)    
select @ssql = @ssql + '             select  ''x'' ' + char(10)    
select @ssql = @ssql + '             from   es_language_met c (nolock)'     + char(10)    
select @ssql = @ssql + '             where    c.quick_code_type   = a.quick_code_type  '  + char(10)    
select @ssql = @ssql + '             and    c.quick_code  = a.quick_code '  + char(10)    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_language_met('   + char(10)    
select @ssql = @ssql + '  customer_name,   quick_code_type,    quick_code, '   + char(10)    
select @ssql = @ssql + '  quick_code_value,   timestamp,      createdby, '   + char(10)    
select @ssql = @ssql + '  createddate,    modifiedby,      modifieddate)'   + char(10)    
select @ssql = @ssql + '  select distinct customername, ''language_code'',   a.langid, '  + char(10)    
select @ssql = @ssql + '  langdesc,     timestamp,      '''+@user+''','  + char(10)    
select @ssql = @ssql + '  '''+@time+''',   '''+@user+''',         '''+@time+''''  + char(10)    
select @ssql = @ssql + '  from de_fw_req_publish_language  a ' + char(10)    
select @ssql = @ssql + '  where  a.customername     = '''+@dst_customer_name+''''  + char(10)    
select @ssql = @ssql + '  and   a.projectname   = '''+@dst_project_name+''''  + char(10)    
select @ssql = @ssql + '  and   a.ecrno     = '''+@tmp_ecr+''''    + char(10)    
select @ssql = @ssql + '  and    not exists ( '      + char(10)    
select @ssql = @ssql + '             select  ''x'' ' + char(10)    
select @ssql = @ssql + '             from   es_language_met c (nolock)'     + char(10)    
select @ssql = @ssql + '             where   c.quick_code_type   = ''language_code''  '  + char(10)    
select @ssql = @ssql + '             and    c.quick_code  = a.langid '  + char(10)    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_ctrl_type_mst( '    + char(10)    
select @ssql = @ssql + '      customer_name,    project_name,    req_no,       ctrl_type_name,'    + char(10)    
select @ssql = @ssql + '      ctrl_type_descr,   base_ctrl_type,    mandatory_flag,   visisble_flag,'    + char(10)    
select @ssql = @ssql + '      editable_flag,    caption_req,     select_flag,    zoom_req,'      + char(10)    
select @ssql = @ssql + '      insert_req,      delete_req,      help_req,     event_handling_req,'   + char(10)    
select @ssql = @ssql + '      ellipses_req,    caption_alignment,  caption_wrap,    project_ctrl_type_sysid,' + char(10)    
select @ssql = @ssql + '      caption_position,   timestamp,      createdby,     createddate,'     + char(10)    
select @ssql = @ssql + '      modifiedby,      modifieddate,    visisble_rows,   ctrl_type_doc,'    + char(10)    
select @ssql = @ssql + '      ctrl_position,    label_class,     ctrl_class,   password_char,'    + char(10)    
/*Columns added by Makesh prabu. R for the CallID: PNR2.0_21056 -start*/    
select @ssql = @ssql + '      tskimg_class,    hlpimg_class,  report_req,   disponlycmb_req, '    + char(10)    
select @ssql = @ssql + '      html_txt_area,  Auto_tab_stop,  Spin_required,  Spin_up_image, '    + char(10)    
select @ssql = @ssql + '      Spin_down_image, EditMask,   InPlace_Calendar, NoofLinesPerRow, '    + char(10)    
select @ssql = @ssql + '      RowHeight,   Vscrollbar_Req,  Is_Extjs_Control, Extjs_Ctrl_type,'    + char(10)    
/*Columns added by Makesh prabu. R for phase3 & 4 Relese for the CaseID: PNR2.0_26376 --starts*/    
select @ssql = @ssql + '      gridlite_req,  bulletlink_req,  buttoncombo_req, associatedlist_req,'   + char(10)  -- added for PNR2.0_21991 by Makesh Prabu. R    
/*Columns added by Makesh prabu. R for the CallID: PNR2.0_21056 -end*/    
select @ssql = @ssql + '      onfocustask_req, listrefilltask_req, attach_document, image_upload,'     + char(10)    
select @ssql = @ssql + '      inplace_image,  listedit_noofcolumns, image_row_height, relative_url_path,'   + char(10)    
select @ssql = @ssql + '      relative_document_path,relative_image_path,save_doc_content_to_db,save_image_content_to_db,' + char(10)    
select @ssql = @ssql + '      dataascaption,  image_icon,   Date_highlight,  ezee_report,'    + char(10)    
/*Columns added by Makesh prabu. R for phase3 & 4 Relese for the CaseID: PNR2.0_26376 -- End */    
/*Columns added by Gankan.G for the CallID: PNR2.0_28339 -starts*/    
select @ssql = @ssql + '   Lite_Attach_Document, Browse_Button_Enable, Delete_Button_Enable, image_row_width,'  + char(10)    
select @ssql = @ssql + '   image_preview_height, image_preview_width, Image_Preview_Req, Image_Accept_Type,'     + char(10)    
select @ssql = @ssql + '   Lite_Attach_Image, image_preview_required '            + char(10)    
/*Columns added by Gankan.G for the CallID: PNR2.0_28339 -ends*/    
select @ssql = @ssql + '   ,timezone , autoexpand ' /* Code modified for the bugid:PNR2.0_32094 */      + char(10)    
--select @ssql = @ssql + '   , Disp_Only_Apply_Len ) ' /* Code modified for the bugid:PNR2.0_32803 */      + char(10)/* Code modified for the bugid:PNR2.0_34059 */    
--select @ssql = @ssql + '   , Disp_Only_Apply_Len ,editcombo_req) ' /* Code modified for the bugid:PNR2.0_34059 */      + char(10)/* Code commented for the bugid:PLF2.0_00187 */    
select @ssql = @ssql + '   , Disp_Only_Apply_Len ,editcombo_req, label_link ) ' /* Code modified for the bugid:PLF2.0_00187 */  + char(10)    
select @ssql = @ssql + ' select  '''+@dst_customer_name+''',  '''+@dst_project_name+''', ''base'',    ctrl_type_name,'+ char(10)    
select @ssql = @ssql + '      ctrl_type_descr,   base_ctrl_type,    mandatory_flag,   visisble_flag,'    + char(10)    
select @ssql = @ssql + '      editable_flag,   caption_req,     select_flag,    zoom_req,'      + char(10)    
select @ssql = @ssql + '      insert_req,      delete_req,      help_req,     event_handling_req,'   + char(10)    
select @ssql = @ssql + '      ellipses_req,    caption_alignment,  caption_wrap,    left(req_no+ctrl_type_name+ctrl_type_descr,40),'+ char(10)    
select @ssql = @ssql + '      caption_position,   timestamp,      '''+@user+''',   '''+@time+''','    + char(10)    
select @ssql = @ssql + '      '''+@user+''',      '''+@time+''',      visisble_rows,   ctrl_type_doc,'    + char(10)    
select @ssql = @ssql + '   ctrl_position,    label_class,     ctrl_class,     password_char,'    + char(10)    
/*Columns added by Makesh prabu. R for the CallID: PNR2.0_21056 -start*/    
select @ssql = @ssql + '      tskimg_class,    hlpimg_class,  report_req,   disponlycmb_req, '    + char(10)    
select @ssql = @ssql + '      html_txt_area,  Auto_tab_stop,  Spin_required,  Spin_up_image, '    + char(10)    
select @ssql = @ssql + '      Spin_down_image, EditMask,   InPlace_Calendar, NoofLinesPerRow, '    + char(10)    
select @ssql = @ssql + '      RowHeight,   Vscrollbar_Req,  Is_Extjs_Control, Extjs_Ctrl_type,'    + char(10)    
/*Columns added by Makesh prabu. R for phase3 & 4 Relese for the CaseID: PNR2.0_26376 --starts*/    
select @ssql = @ssql + '      gridlite_req,  bulletlink_req,  buttoncombo_req, associatedlist_req,'   + char(10)  -- added for PNR2.0_21991 by Makesh Prabu. R    
/*Columns added by Makesh prabu. R for the CallID: PNR2.0_21056 -end*/    
select @ssql = @ssql + '      onfocustask_req, listrefilltask_req, attach_document, image_upload,'     + char(10)    
select @ssql = @ssql + '      inplace_image,  listedit_noofcolumns, image_row_height, relative_url_path,'   + char(10)    
select @ssql = @ssql + '      relative_document_path,relative_image_path,save_doc_content_to_db,save_image_content_to_db,' + char(10)    
select @ssql = @ssql + '      dataascaption,  image_icon,   Date_highlight,  ezee_report,'    + char(10)    
/*Columns added by Makesh prabu. R for phase3 & 4 Relese for the CaseID: PNR2.0_26376 -- End */    
/*Columns added by Gankan.G for the CallID: PNR2.0_28339 -starts*/    
select @ssql = @ssql + '   Lite_Attach_Document, Browse_Button_Enable, Delete_Button_Enable, image_row_width,'  + char(10)    
select @ssql = @ssql + '   image_preview_height, image_preview_width, Image_Preview_Req, Image_Accept_Type,'     + char(10)    
select @ssql = @ssql + '   Lite_Attach_Image, image_preview_required '            + char(10)    
/*Columns added by Gankan.G for the CallID: PNR2.0_28339 -ends*/    
select @ssql = @ssql + '   ,timezone , autoexpand ' /* Code modified for the bugid:PNR2.0_32094 */      + char(10)    
--select @ssql = @ssql + '   , Disp_Only_Apply_Len  ' /* Code modified for the bugid:PNR2.0_32803 */      + char(10)/* Code modified for the bugid:PNR2.0_34059 */    
--select @ssql = @ssql + '   , Disp_Only_Apply_Len ,editcombo_req ' /* Code modified for the bugid:PNR2.0_34059 */      + char(10) /* Code commented for the bugid:PLF2.0_00187 */    
select @ssql = @ssql + '   , Disp_Only_Apply_Len ,editcombo_req , label_link' /* Code modified for the bugid:PLF2.0_00187 */ + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_ctrl_type_mst  a '    + char(10)    
select @ssql = @ssql + ' where   a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and    a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and    not exists ( '     + char(10)    
select @ssql = @ssql + '           select  ''x'' ' + char(10)    
select @ssql = @ssql + '           from   es_ctrl_type_mst c (nolock)'     + char(10)    
select @ssql = @ssql + '           where   c.customer_name   = '''+@dst_customer_name+''''  + char(10)    
select @ssql = @ssql + '            and    c.project_name   = '''+@dst_project_name+''''  + char(10)    
select @ssql = @ssql + '           and    c.req_no      = ''base'''    + char(10)    
select @ssql = @ssql + '           and    c.ctrl_type_name  = a.ctrl_type_name)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_proj_hdn_ctrl_dtl('          + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,    req_no,'     + char(10)    
select @ssql = @ssql + '     bt_synonym_name,   allow_deletion,    proj_hdn_ctrl_sysid,'  + char(10)    
select @ssql = @ssql + '     timestamp,      createdby,      createddate,'    + char(10)    
select @ssql = @ssql + '     modifiedby,    modifieddate)' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''',   ''base'','  + char(10)    
select @ssql = @ssql + '     bt_synonym_name,   allow_deletion,    proj_hdn_ctrl_sysid,'  + char(10)    
select @ssql = @ssql + '     timestamp,      '''+@user+''',      '''+@time+''','   + char(10)    
select @ssql = @ssql + '     '''+@user+''',      '''+@time+'''' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_proj_hdn_ctrl_dtl  a ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + ' and   not exists ('     + char(10)    
select @ssql = @ssql + '          select  ''x'''  + char(10)    
select @ssql = @ssql + '          from   es_proj_hdn_ctrl_dtl c (nolock)'    + char(10)    
select @ssql = @ssql + '          where   c.customer_name   = '''+@dst_customer_name+''''  + char(10)    
select @ssql = @ssql + '           and    c.project_name   = '''+@dst_project_name+''''  + char(10)    
select @ssql = @ssql + '          and    c.req_no      = ''base'''    + char(10)    
select @ssql = @ssql + ' and    c.bt_synonym_name  = a.bt_synonym_name)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_project_param_mst('          + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,   req_no,'     + char(10)    
select @ssql = @ssql + '     param_category,    param_text,      param_type,'   + char(10)    
select @ssql = @ssql + '     project_param_sysid,timestamp,      createdby,'    + char(10)    
select @ssql = @ssql + '     createddate,     modifiedby,      modifieddate,'    + char(10)    
select @ssql = @ssql + '     default_value,    current_value,    res_naming_convention,' + char(10)    
select @ssql = @ssql + '     param_doc)' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''', ''base'','  + char(10)    
select @ssql = @ssql + '     param_category,    param_text,      param_type,'    + char(10)    
select @ssql = @ssql + '     left(req_no+param_category+param_text,40), timestamp,      '''+@user+''','   + char(10)    
select @ssql = @ssql + '     '''+@time+''',      '''+@user+''',      '''+@time+''','   + char(10)    
select @ssql = @ssql + '     default_value,    current_value,    res_naming_convention,' + char(10)    
select @ssql = @ssql + '     param_doc'  + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_project_param_mst  a ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and   not exists ( '     + char(10)    
select @ssql = @ssql + '          select  ''x'''  + char(10)    
select @ssql = @ssql + '          from   es_project_param_mst c (nolock)'   + char(10)    
select @ssql = @ssql + '          where   c.customer_name   = '''+@dst_customer_name+''''+ char(10)    
select @ssql = @ssql + '           and    c.project_name   = '''+@dst_project_name+'''' + char(10)    
select @ssql = @ssql + '          and    c.req_no      = ''base'''   + char(10)    
select @ssql = @ssql + '          and    c.param_category  = a.param_category)'+ char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_project_stylesheet(' + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,    req_no,'   + char(10)    
select @ssql = @ssql + '     stylesheet_name,   stylesheet_descr,   timestamp,'  + char(10)    
select @ssql = @ssql + '     createdby,      createddate,     modifiedby,'  + char(10)    
select @ssql = @ssql + '     modifieddate)'      + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''',   ''base'','  + char(10)    
select @ssql = @ssql + '     stylesheet_name,   stylesheet_descr,   timestamp,'    + char(10)    
select @ssql = @ssql + '     '''+@user+''',      '''+@time+''',      '''+@user+''','   + char(10)    
select @ssql = @ssql + '     '''+@time+''''      + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_project_stylesheet  a ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + ' and   not exists ('      + char(10)    
select @ssql = @ssql + '          select  ''x'''   + char(10)    
select @ssql = @ssql + '          from   es_project_stylesheet c (nolock)'    + char(10)    
select @ssql = @ssql + '          where   c.customer_name   = '''+@dst_customer_name+''''  + char(10)    
select @ssql = @ssql + '           and    c.project_name   = '''+@dst_project_name+''''  + char(10)    
select @ssql = @ssql + '          and    c.req_no      = ''base'''    + char(10)    
select @ssql = @ssql + '        and    c.stylesheet_name  = a.stylesheet_name)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_pt_mst(' + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,    pt_name,'     + char(10)    
select @ssql = @ssql + '     pt_descr,      pt_sysid,      timestamp,'    + char(10)    
select @ssql = @ssql + '     createdby,      createddate,     modifiedby,'    + char(10)    
select @ssql = @ssql + '     modifieddate,    total_length,    decimal_length)'   + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''',   pt_name,'  + char(10)    
select @ssql = @ssql + '     pt_descr,      left(pt_name+pt_descr,40),    timestamp,'    + char(10)    
select @ssql = @ssql + '     '''+@user+''',      '''+@time+''',      '''+@user+''','   + char(10)    
select @ssql = @ssql + '     '''+@time+''',      total_length,    decimal_length'   + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_pt_mst  a ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name     = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name     = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and   not exists ('     + char(10)    
select @ssql = @ssql + '          select  ''x'''  + char(10)    
select @ssql = @ssql + '          from   es_pt_mst c (nolock)'       + char(10)    
select @ssql = @ssql + '          where   c.customer_name   = '''+@dst_customer_name+''''  + char(10)    
select @ssql = @ssql + '           and    c.project_name   = '''+@dst_project_name+''''  + char(10)    
select @ssql = @ssql + '          and    c.pt_name     = a.pt_name)'    + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_quick_code_mst('  + char(10)    
select @ssql = @ssql + '     timestamp,     quick_code_type,   quick_code,'  + char(10)    
select @ssql = @ssql + '     createdby,     createddate,     modifiedby,'  + char(10)    
select @ssql = @ssql + '     modifieddate,   quick_code_value)'      + char(10)    
select @ssql = @ssql + ' select timestamp,     quick_code_type,   quick_code,'  + char(10)    
select @ssql = @ssql + '     '''+@user+''',  '''+@time+''',      '''+@user+''',' + char(10)    
select @ssql = @ssql + '     '''+@time+''',  quick_code_value'      + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_quick_code_mst  a ' + char(10)    
select @ssql = @ssql + ' where  not exists ('     + char(10)    
select @ssql = @ssql + '          select  ''x'''  + char(10)    
select @ssql = @ssql + '          from   es_quick_code_mst c (nolock)'     + char(10)    
select @ssql = @ssql + '          where   c.quick_code_type   = a.quick_code_type' + char(10)    
select @ssql = @ssql + '           and    c.quick_code     = a.quick_code)'   + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert  into  es_task_type_mst(' + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,    req_no,       task_type_name,'   + char(10)    
select @ssql = @ssql + '     task_type_descr,   default_for,     refresh_on_save,  valid_on_init,'   + char(10)    
select @ssql = @ssql + '     err_handle_method,  incl_place_holder,  cond_ml_fetch,   clr_on_page_save,'   + char(10)    
select @ssql = @ssql + '     hdr_fetch_req,   ml_fet_req,      hdr_ref_req,  hdr_check_req,'   + char(10)    
select @ssql = @ssql + '     proc_sel_rows,    usr_role_map,    trn_scope_req,   task_type_sysid,'   + char(10)    
select @ssql = @ssql + '     timestamp,     createdby,      createddate,    modifiedby,'    + char(10)    
select @ssql = @ssql + '     modifieddate,    task_type_doc,    hdr_save_req,    ml_save_req,'    + char(10)    
select @ssql = @ssql + '     fprowno_req,     cbdef_req,      no_placeholder,  data_save_req,'   + char(10)    
select @ssql = @ssql + '     print_req,      task_confirmation, Logic_Extensions, process_updrows, '  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/  --code modified for the bugid:PNR2.0_35203    
select @ssql = @ssql + '     alternate_db )'  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''',   ''base'', task_type_name,'   + char(10)    
select @ssql = @ssql + '     task_type_descr,   default_for,     refresh_on_save,  valid_on_init,'   + char(10)    
select @ssql = @ssql + '     err_handle_method,  incl_place_holder,  cond_ml_fetch,   clr_on_page_save,'   + char(10)    
select @ssql = @ssql + '     hdr_fetch_req,    ml_fet_req,      hdr_ref_req,    hdr_check_req,'   + char(10)    
select @ssql = @ssql + '     proc_sel_rows,    usr_role_map,    trn_scope_req,   left(req_no+task_type_name+task_type_descr,40),'+ char(10)    
select @ssql = @ssql + '     timestamp,      '''+@user+''',      '''+@time+''',     '''+@user+''','   + char(10)    
select @ssql = @ssql + '     '''+@time+''',      task_type_doc,    hdr_save_req,    ml_save_req,'    + char(10)    
select @ssql = @ssql + '     fprowno_req,     cbdef_req,      no_placeholder,   data_save_req,'   + char(10)    
select @ssql = @ssql + '     print_req,      task_confirmation, Logic_Extensions, process_updrows'  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/    
select @ssql = @ssql + '     ,alternate_db '  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_task_type_mst  a '   + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and   not exists (' + char(10)    
select @ssql = @ssql + '          select  ''x'''          + char(10)    
select @ssql = @ssql + '          from   es_task_type_mst c (nolock)'    + char(10)    
select @ssql = @ssql + '          where   c.customer_name   = '''+@dst_customer_name+''''+ char(10)    
select @ssql = @ssql + '           and    c.project_name   = '''+@dst_project_name+'''' + char(10)    
select @ssql = @ssql + '          and    c.req_no      = ''base'''   + char(10)    
select @ssql = @ssql + '          and    c.task_type_name  = a.task_type_name)'+ char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_glossary(' + char(10)    
select @ssql = @ssql + '   customer_name,   project_name,   bt_synonym_name,   data_type,' + char(10)    
select @ssql = @ssql + '   length,     bt_synonym_caption,  glossary_sysid,    timestamp,' + char(10)    
select @ssql = @ssql + '   createdby,    createddate,   modifiedby,     modifieddate,' + char(10)    
select @ssql = @ssql + '   ref_bt_synonym_name, bt_synonym_doc,   bt_name,     synonym_status )' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''', bt_synonym_name, data_type,' + char(10)    
select @ssql = @ssql + '   length,     bt_synonym_caption,  glossary_sysid,    timestamp,' + char(10)    
select @ssql = @ssql + '   '''+@user+''',   '''+@time+''',   '''+@user+''',    '''+@time+''',' + char(10)    
select @ssql = @ssql + '   ref_bt_synonym_name, bt_synonym_doc,   bt_name,     synonym_status' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_glossary  a '   + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and not exists( select ''x''' + char(10)    
select @ssql = @ssql + '     from es_glossary  b(nolock)' + char(10)    
select @ssql = @ssql + '     where b.customer_name  = a.customer_name ' + char(10)    
select @ssql = @ssql + '     and  b.project_name  = a.project_name ' + char(10)    
select @ssql = @ssql + '     and  b.bt_synonym_name = a.bt_synonym_name )' + char(10)    
exec(@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_glossary_lng_extn(' + char(10)    
select @ssql = @ssql + '   customer_name,   project_name,   bt_synonym_name,   data_type,' + char(10)    
select @ssql = @ssql + '   length,     bt_synonym_caption,  glossary_sysid,    timestamp,' + char(10)    
select @ssql = @ssql + '   createdby,    createddate,   modifiedby,     modifieddate,' + char(10)    
select @ssql = @ssql + '   ref_bt_synonym_name, bt_synonym_doc,   bt_name,     synonym_status,' + char(10)    
select @ssql = @ssql + '   languageid )' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''',  '''+@dst_project_name+''', bt_synonym_name, data_type,' + char(10)    
select @ssql = @ssql + '   length,     bt_synonym_caption,  glossary_sysid,    timestamp,' + char(10)    
select @ssql = @ssql + '   '''+@user+''',   '''+@time+''',   '''+@user+''',    '''+@time+''',' + char(10)    
select @ssql = @ssql + '   ref_bt_synonym_name, bt_synonym_doc,   bt_name,     synonym_status,' + char(10)    
select @ssql = @ssql + '   languageid ' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_glossary_lng_extn  a '   + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and not exists( select ''x''' + char(10)    
select @ssql = @ssql + '     from es_glossary_lng_extn b(nolock)' + char(10)    
select @ssql = @ssql + '     where b.customer_name  = a.customer_name ' + char(10)    
select @ssql = @ssql + '     and  b.project_name  = a.project_name ' + char(10)    
select @ssql = @ssql + '     and  b.bt_synonym_name = a.bt_synonym_name' + char(10)    
select @ssql = @ssql + '     and  b.languageid  = a.languageid )' + char(10)    
exec(@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_review(' + char(10)    
select @ssql = @ssql + '  customer_name,    project_name,    reviewset_no,  reviewpoint, ' + char(10)    
select @ssql = @ssql + '  reviewset_date,    purpose,     timestamp,   createdby,  ' + char(10)    
select @ssql = @ssql + '  createddate,    modifiedby,     modifieddate,  reviewstatus ) ' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''', '''+@dst_project_name+''', reviewset_no,  reviewpoint, ' + char(10)    
select @ssql = @ssql + '  reviewset_date,    purpose,     timestamp,   '''+@user+''', ' + char(10)    
select @ssql = @ssql + '  '''+@time+''',    '''+@user+''',    '''+@time+''',  reviewstatus  ' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_review  a    ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and not exists( select ''x''' + char(10)    
select @ssql = @ssql + '     from es_review c(nolock)' + char(10)    
select @ssql = @ssql + '     where c.customer_name = '''+@dst_customer_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.project_name = '''+@dst_project_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.reviewset_no = a.reviewset_no' + char(10)    
select @ssql = @ssql + '     and  c.reviewpoint = a.reviewpoint )' + char(10)    
exec(@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_review_dtl(' + char(10)    
select @ssql = @ssql + '  customer_name,    project_name,    reviewset_no,   review_type,' + char(10)    
select @ssql = @ssql + '  deliverable_type,   level1,      level2,     level3,' + char(10)    
select @ssql = @ssql + '  reviewsetstatus,   timestamp,     createdby,    createddate,' + char(10)    
select @ssql = @ssql + '  modifiedby,     modifieddate )' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''', '''+@dst_project_name+''', reviewset_no,   review_type,' + char(10)    
select @ssql = @ssql + '  deliverable_type,   level1,      level2,     level3,' + char(10)    
select @ssql = @ssql + '  reviewsetstatus,   timestamp,     '''+@user+''',    '''+@time+''',' + char(10)    
select @ssql = @ssql + '  '''+@user+''',    '''+@time+''' ' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_review_dtl  a    ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''+ char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''+ char(10)    
select @ssql = @ssql + ' and not exists( select ''x''' + char(10)    
select @ssql = @ssql + '     from es_review_dtl c(nolock)' + char(10)    
select @ssql = @ssql + '     where c.customer_name  = '''+@dst_customer_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.project_name  = '''+@dst_project_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.reviewset_no  = a.reviewset_no' + char(10)    
select @ssql = @ssql + '     and  c.review_type  = a.review_type' + char(10)    
select @ssql = @ssql + '     and  c.deliverable_type = a.deliverable_type' + char(10)    
select @ssql = @ssql + '     and  c.level1   = a.level1' + char(10)    
select @ssql = @ssql + '     and  c.level2   = a.level2' + char(10)    
select @ssql = @ssql + '     and  c.level3   = a.level3 )' + char(10)    
exec(@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_review_type(' + char(10)    
select @ssql = @ssql + '  customer_name,    project_name,    reviewset_no,   review_type,' + char(10)    
select @ssql = @ssql + '  timestamp,     createdby,     createddate,   modifiedby,' + char(10)    
select @ssql = @ssql + '  modifieddate )' + char(10)    
select @ssql = @ssql + ' select '''+@dst_customer_name+''', '''+@dst_project_name+''', reviewset_no,   review_type,' + char(10)    
select @ssql = @ssql + '  timestamp,     '''+@user+''',    '''+@time+''',   '''+@user+''',' + char(10)    
select @ssql = @ssql + '  '''+@time+'''' + char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_review_type  a    ' + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name    = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and not exists( select ''x''' + char(10)    
select @ssql = @ssql + '     from es_review_type c(nolock)' + char(10)    
select @ssql = @ssql + '     where c.customer_name  = '''+@dst_customer_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.project_name  = '''+@dst_project_name+'''' + char(10)    
select @ssql = @ssql + '     and  c.reviewset_no  = a.reviewset_no' + char(10)    
select @ssql = @ssql + '     and  c.review_type  = a.review_type )' + char(10)    
exec(@ssql)    
    
    
If @mig_type = 'U'    
begin    
    
    
-- Modified By Bakiaraj V on 25 Aug 2006    
--    delete  es_comp_ctrl_type_mst_mr_203_1    
--    where Customer_Name  = @customername    
--    and  Project_Name = @projectname    
--    and  process_name = @processname    
--    and  component_name = @componentname    
    
--  11537 Starts    
    
delete es_comp_ctrl_type_mst_mr_203_1      
where customer_name = @dst_customer_name      
and  project_name = @dst_project_name      
and  process_name = @dst_process_name      
and  component_name  = @dst_component_name      
    
    
select @ssql = ''          
select @ssql = @ssql + '  insert  into  es_comp_ctrl_type_mst_mr_203_1( ' + char(10)          
select @ssql = @ssql + ' customer_name,   project_name,    req_no,     process_name, '   + char(10)          
select @ssql = @ssql + '    component_name,   ctrl_type_name,    ctrl_type_descr, base_ctrl_type, '  + char(10)          
select @ssql = @ssql + '    mandatory_flag,   visisble_flag,    editable_flag,   caption_req, '   + char(10)          
select @ssql = @ssql + '    select_flag,   zoom_req,     insert_req,    delete_req, '   + char(10)          
select @ssql = @ssql + '    help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid, ' + char(10)          
select @ssql = @ssql + ' timestamp,    createdby,     createddate,   modifiedby, '   + char(10)          
select @ssql = @ssql + ' modifieddate,   caption_alignment,   caption_position,  caption_wrap, '   + char(10)          
select @ssql = @ssql + '    visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class, '   + char(10)          
select @ssql = @ssql + '    ctrl_class,    password_char,    tskimg_class,   hlpimg_class,'   + char(10)          
select @ssql = @ssql + ' new_ctrl_type,   mig_id,      disponlycmb_req,  html_txt_area,'   + char(10)          
select @ssql = @ssql + '    report_req,    Auto_tab_stop,    Spin_required,   Spin_up_image,  '  + char(10)          
select @ssql = @ssql + '    EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,'  + char(10)          
select @ssql = @ssql + '    Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,'  + char(10) -- added for PNR2.0_21991 by Makesh Prabu. R          
select @ssql = @ssql + ' buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,' + char(10)          
select @ssql = @ssql + ' attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,' + char(10)          
select @ssql = @ssql + ' image_row_height,  relative_url_path,   relative_document_path, relative_image_path,' + char(10)          
select @ssql = @ssql + ' save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,'   + char(10)          
select @ssql = @ssql + ' Date_highlight,   ezee_report,    IsListBox,    Toolbar_Not_Req, '      + char(10)          
select @ssql = @ssql + ' ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,'   +char(10)        
select @ssql = @ssql + ' ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit,'    +char(10)         
select @ssql = @ssql + ' columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,' +char(10)        
select @ssql = @ssql + ' Lite_Attach_Document, Browse_Button_Enable,  Delete_Button_Enable, image_row_width,'  + char(10)          
select @ssql = @ssql + ' image_preview_height, image_preview_width,  image_preview_req,  image_Accept_Type,'     + char(10)          
select @ssql = @ssql + ' Lite_Attach_Image ,  timezone ,     autoexpand,    Disp_Only_Apply_Len, ' + char(10)          
select @ssql = @ssql + '    editcombo_req ,   label_link,     Map_In_Req,    Map_Out_Req,'   + char(10)  --old        
select @ssql = @ssql + ' Accept_Type,   file_Accept_Type,   combo_link,    QR_Image,    '  + char(10)        
select @ssql = @ssql + ' Barcode_Image,   Accpet_Type,    FileSize,    Isfallback,    '  + char(10)        
select @ssql = @ssql + ' config_parameter,  config_value,    upload,     Is_Varbinary,  '  + char(10)        
select @ssql = @ssql + ' EMail,     Phone,      StaticCaption,   Datagrid,      '  + char(10)        
select @ssql = @ssql + ' MoveFirst,    Move_PrevSet,     Move_Previous,   Move_Next,     '  + char(10)        
select @ssql = @ssql + ' Move_NextSet,   Move_Last,     Carousel_Req,   Orientation,   '  + char(10)        
select @ssql = @ssql + ' WrapCount,    Box_Type,     ISDeviceInfo,   ListControl,   '  + char(10)        
select @ssql = @ssql + ' col_caption_align,  Gridheaderstyle,   Gridtoolbarstyle,  preevent,      '  + char(10)        
select @ssql = @ssql + ' postevent,    col_data_align,    norowstodisplay_notreq, avn_download,  '  + char(10)        
select @ssql = @ssql + ' PreventDownload,  spin_system_task,    enabledefault,   hideinsert,    '  + char(10)        
select @ssql = @ssql + ' hidedelete,    hidecopy,     hidecut,    hidefilterdata,'  + char(10)        
select @ssql = @ssql + ' hidepdf,    hidereport,     hidehtml,    hideexportexcel,'  + char(10)        
select @ssql = @ssql + ' hideexportcsv,    hideexporttext,    hideimportdata,   hidechart,     '  + char(10)        
select @ssql = @ssql + ' hideexportopenoffice, hidepersonalize ,   hidefiltercolumn,  searchhide,    '  + char(10)        
select @ssql = @ssql + ' autolist_not_req,  hideselect,     ishijri,    AutoHeight,    '  + char(10)        
select @ssql = @ssql + ' QlikLink,    IsPivot,     slider_type,   max_value,     '  + char(10)        
select @ssql = @ssql + ' min_value,    step_value,     RangeMinimum,   RangeMaximum,  '  + char(10)        
select @ssql = @ssql + ' RangeStartValue,  RangeEndValue,    RangeStep,    RangeLabel,    '  + char(10)        
select @ssql = @ssql + ' RangeSelect,   ValueShown,     Style,     SystemGeneratedFileId,' + char(10)        
select @ssql = @ssql + ' IsAssorted,    IsMarquee,     RatingType,    CaptchaData, '   + char(10)        
select @ssql = @ssql + ' RenderAs,    AttachmentWithDesc,   preserve_gridposition, noofrowsselected_req ,controlstyle)' + char(10)           -- TECH-74235
        
select @ssql = @ssql + 'select distinct dst_customer_name,  dst_project_name,  ''base'',    dst_process_name,'  + char(10)          
select @ssql = @ssql + '    dst_component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type, '  + char(10)          
select @ssql = @ssql + '    mandatory_flag,   visisble_flag,    editable_flag,   caption_req, '   + char(10)          
select @ssql = @ssql + '    select_flag,   zoom_req,     insert_req,    delete_req, '   + char(10)          
select @ssql = @ssql + '    help_req,    event_handling_req,   ellipses_req,   left(req_no+ctrl_type_name+cast(getdate() as varchar(20)),40),'+ char(10)         
select @ssql = @ssql + ' timestamp,    '''+@user+''',   '''+@time+''',   '''+@user+''','   + char(10)          
select @ssql = @ssql + ' '''+@time+''',   caption_alignment,   caption_position,  caption_wrap, '   + char(10)          
select @ssql = @ssql + '    visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class, '   + char(10)          
select @ssql = @ssql + '    ctrl_class,    password_char,    tskimg_class,   hlpimg_class,'   + char(10)          
select @ssql = @ssql + ' '''',     '''+@mig_id+''',   disponlycmb_req,  html_txt_area,'   + char(10)          
select @ssql = @ssql + '    report_req,    Auto_tab_stop,    Spin_required,   Spin_up_image,  '  + char(10)          
select @ssql = @ssql + '    EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,'  + char(10)          
select @ssql = @ssql + '    Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,'  + char(10) -- added for PNR2.0_21991 by Makesh Prabu. R          
select @ssql = @ssql + ' buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,' + char(10)          
select @ssql = @ssql + ' attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,' + char(10)          
select @ssql = @ssql + ' image_row_height,  relative_url_path,   relative_document_path, relative_image_path,' + char(10)          
select @ssql = @ssql + ' save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,'   + char(10)          
select @ssql = @ssql + ' Date_highlight,   ezee_report,    IsListBox,    Toolbar_Not_Req, '      + char(10)          
select @ssql = @ssql + ' ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,'   +char(10)        
select @ssql = @ssql + ' ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit,'    +char(10)         
select @ssql = @ssql + ' columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,' +char(10)        
select @ssql = @ssql + ' Lite_Attach_Document, Browse_Button_Enable,  Delete_Button_Enable, image_row_width,'  + char(10)          
select @ssql = @ssql + ' image_preview_height, image_preview_width,  image_preview_req,  image_Accept_Type,'     + char(10)          
select @ssql = @ssql + ' Lite_Attach_Image ,  timezone ,     autoexpand,    Disp_Only_Apply_Len, ' + char(10)          
select @ssql = @ssql + '    editcombo_req ,   label_link,     Map_In_Req,    Map_Out_Req,'   + char(10)  --old        
select @ssql = @ssql + ' Accept_Type,   file_Accept_Type,  combo_link,    QR_Image,    '  + char(10)        
select @ssql = @ssql + ' Barcode_Image,   Accpet_Type,    FileSize,    Isfallback,    '  + char(10)        
select @ssql = @ssql + ' config_parameter,  config_value,    upload,     Is_Varbinary,  '  + char(10)        
select @ssql = @ssql + ' EMail,     Phone,      StaticCaption,   Datagrid,      '  + char(10)        
select @ssql = @ssql + ' MoveFirst,    Move_PrevSet,     Move_Previous,   Move_Next,     '  + char(10)        
select @ssql = @ssql + ' Move_NextSet,   Move_Last,     Carousel_Req,   Orientation,   '  + char(10)        
select @ssql = @ssql + ' WrapCount,    Box_Type,     ISDeviceInfo,   ListControl,   '  + char(10)        
select @ssql = @ssql + ' col_caption_align,  Gridheaderstyle,   Gridtoolbarstyle,  preevent,      '  + char(10)        
select @ssql = @ssql + ' postevent,    col_data_align,    norowstodisplay_notreq, avn_download,  '  + char(10)        
select @ssql = @ssql + ' PreventDownload,  spin_system_task,    enabledefault,   hideinsert,    '  + char(10)        
select @ssql = @ssql + ' hidedelete,    hidecopy,     hidecut,    hidefilterdata,'  + char(10)        
select @ssql = @ssql + ' hidepdf,    hidereport,     hidehtml,    hideexportexcel,'  + char(10)        
select @ssql = @ssql + ' hideexportcsv,    hideexporttext,    hideimportdata,   hidechart,     '  + char(10)        
select @ssql = @ssql + ' hideexportopenoffice, hidepersonalize ,   hidefiltercolumn,  searchhide,    '  + char(10)        
select @ssql = @ssql + ' autolist_not_req,  hideselect,     ishijri,    AutoHeight,    '  + char(10)        
select @ssql = @ssql + ' QlikLink,    IsPivot,     slider_type,   max_value,     '  + char(10)        
select @ssql = @ssql + ' min_value,    step_value,     RangeMinimum,   RangeMaximum,  '  + char(10)        
select @ssql = @ssql + ' RangeStartValue,  RangeEndValue,    RangeStep,    RangeLabel,    '  + char(10)        
select @ssql = @ssql + ' RangeSelect,   ValueShown,     Style,     SystemGeneratedFileId,' + char(10)        
select @ssql = @ssql + ' IsAssorted,    IsMarquee,     RatingType,    CaptchaData, '   + char(10)        
select @ssql = @ssql + ' RenderAs,    AttachmentWithDesc,   preserve_gridposition, noofrowsselected_req ,controlstyle '+ char(10)    --TECH-74235        
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_ctrl_type_mst  a ,'   + char(10)          
select @ssql = @ssql + '     engg_mr_ui_mst_203_1 b (nolock)'    + char(10)          
select @ssql = @ssql + ' where  a.customer_name  = ''' + @customername + ''''  + char(10)          
select @ssql = @ssql + ' and    a.project_name   = ''' + @projectname + ''''  + char(10)          
select @ssql = @ssql + ' and    a.process_name   = ''' +@processname+''''   + char(10)          
select @ssql = @ssql + ' and    a.component_name = ''' +@componentname+''''   + char(10)          
select @ssql = @ssql + ' and    a.customer_name  = b.src_customer_name '   + char(10)          
select @ssql = @ssql + ' and    a.project_name   = b.src_project_name '    + char(10)          
select @ssql = @ssql + ' and    a.process_name   = b.src_process_name '    + char(10)          
select @ssql = @ssql + ' and    a.component_name = b.src_component_name '   + char(10)          
select @ssql = @ssql + ' and    b.act_mig_flag = 1'       + char(10)          
select @ssql = @ssql + ' and    b.mig_id   = '''+@mig_id+''''      + char(10)          
exec(@ssql)          
      
update a          
set  a.new_ctrl_type  = a.ctrl_type_name           
from es_comp_ctrl_type_mst_mr_203_1 a (nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name            
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
          
          
insert  into  es_comp_ctrl_type_mst(          
customer_name,   project_name,    req_no,     process_name,          
component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type,          
mandatory_flag,   visisble_flag,    editable_flag,   caption_req,          
select_flag,   zoom_req,     insert_req,    delete_req,          
help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid,         
timestamp,    createdby,     createddate,   modifiedby,          
modifieddate,   caption_alignment,   caption_position,  caption_wrap,          
visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class,          
ctrl_class,    password_char,    tskimg_class,   hlpimg_class,          
disponlycmb_req,  html_txt_area,    report_req,    auto_tab_stop,          
spin_required,   spin_up_image,    spin_down_image,  InPlace_Calendar,          
EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,          
Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,   -- added for PNR2.0_21991 by Makesh Prabu. R          
buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,          
attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,          
image_row_height,  relative_url_path,   relative_document_path, relative_image_path,          
save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,          
Date_highlight,   ezee_report,    Lite_Attach_Document, Browse_Button_Enable,        
Delete_Button_Enable, image_row_width,   image_preview_height, image_preview_width,         
image_preview_req,  image_Accept_Type,   Lite_Attach_Image,  Disp_Only_Apply_Len ,        
editcombo_req ,   label_link,     IsListBox,    Toolbar_Not_Req,        
ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,        
ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit ,        
columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,        
Map_In_Req ,   Map_Out_Req ,    Accept_Type ,   file_Accept_Type,        
combo_link,    QR_Image,     Barcode_Image ,   Accpet_Type,        
FileSize,    Isfallback,     config_parameter,  config_value,        
upload ,    Is_Varbinary,    EMail,     Phone,        
StaticCaption,   Datagrid,     MoveFirst,    Move_PrevSet ,        
Move_Previous ,   Move_Next,     Move_NextSet,   Move_Last ,        
Carousel_Req,   Orientation,    WrapCount,    Box_Type ,        
ISDeviceInfo,   ListControl,    col_caption_align,  Gridheaderstyle,        
Gridtoolbarstyle,  preevent,     postevent,    col_data_align,        
norowstodisplay_notreq, avn_download,    PreventDownload,  spin_system_task,         
enabledefault,   hideinsert,     hidedelete,    hidecopy,        
hidecut,    hidefilterdata,    hidepdf,    hidereport,        
hidehtml,    hideexportexcel,   hideexportcsv,   hideexporttext,        
hideimportdata,   hidechart,     hideexportopenoffice, hidepersonalize ,        
hidefiltercolumn,  searchhide,     autolist_not_req,  hideselect,         
ishijri,    AutoHeight,     QlikLink ,    IsPivot,        
slider_type,   max_value,     min_value,    step_value,        
RangeMinimum,   RangeMaximum,    RangeStartValue,  RangeEndValue,         
RangeStep,    RangeLabel,     RangeSelect,   ValueShown,Style,        
SystemGeneratedFileId, IsAssorted,     IsMarquee,    RatingType,        
CaptchaData,   RenderAs,     AttachmentWithDesc,        
preserve_gridposition, noofrowsselected_req  /*Columns addedby 13705 for component split migration --end*/            
,controlstyle )--added by Manoj for TECH-74235   
        
select distinct          
customer_name,   project_name,    'base',     process_name,          
component_name,   new_ctrl_type,    ctrl_type_descr,  base_ctrl_type,          
mandatory_flag,   visisble_flag,    editable_flag,   caption_req,          
select_flag,   zoom_req,     insert_req,    delete_req,          
help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid,          
timestamp,    createdby,     getdate(),    modifiedby,          
getdate(),    case caption_alignment  when 'cente' then 'center'  else caption_alignment  end,           
             caption_position,  caption_wrap,          
visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class,          
ctrl_class,    password_char,    tskimg_class,   hlpimg_class,          
disponlycmb_req,  html_txt_area,    report_req,    auto_tab_stop,          
spin_required,   spin_up_image,    spin_down_image,  InPlace_Calendar,          
EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,          
Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,   -- added for PNR2.0_21991 by Makesh Prabu. R          
buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,          
attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,          
image_row_height,  relative_url_path,   relative_document_path, relative_image_path,          
save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,          
Date_highlight,   ezee_report,    Lite_Attach_Document, Browse_Button_Enable,        
Delete_Button_Enable, image_row_width,   image_preview_height, image_preview_width,         
image_preview_req,  image_Accept_Type,   Lite_Attach_Image,  Disp_Only_Apply_Len ,        
editcombo_req ,   label_link,     IsListBox,    Toolbar_Not_Req,        
ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,        
ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit ,        
columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,        
Map_In_Req ,   Map_Out_Req ,    Accept_Type ,   file_Accept_Type,        
combo_link,    QR_Image,     Barcode_Image ,   Accpet_Type,        
FileSize,    Isfallback,     config_parameter,  config_value,        
upload ,    Is_Varbinary,    EMail,     Phone,        
StaticCaption,   Datagrid,     MoveFirst,    Move_PrevSet ,        
Move_Previous ,   Move_Next,     Move_NextSet,   Move_Last ,        
Carousel_Req,   Orientation,    WrapCount,    Box_Type ,        
ISDeviceInfo,   ListControl,    col_caption_align,  Gridheaderstyle,        
Gridtoolbarstyle,  preevent,     postevent,    col_data_align,        
norowstodisplay_notreq, avn_download,    PreventDownload,  spin_system_task,         
enabledefault,   hideinsert,     hidedelete,    hidecopy,        
hidecut,    hidefilterdata,    hidepdf,    hidereport,        
hidehtml,    hideexportexcel,   hideexportcsv,   hideexporttext,        
hideimportdata,   hidechart,     hideexportopenoffice, hidepersonalize ,        
hidefiltercolumn,  searchhide,     autolist_not_req,  hideselect,         
ishijri,    AutoHeight,     QlikLink ,    IsPivot,        
slider_type,   max_value,     min_value,    step_value,        
RangeMinimum,   RangeMaximum,    RangeStartValue,  RangeEndValue,         
RangeStep,    RangeLabel,     RangeSelect,   ValueShown,Style,        
SystemGeneratedFileId, IsAssorted,     IsMarquee,    RatingType,        
CaptchaData,   RenderAs,     AttachmentWithDesc,        
preserve_gridposition, noofrowsselected_req        
,controlstyle          --TECH-74235 
        
from es_comp_ctrl_type_mst_mr_203_1 a(nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.req_no   = 'base'          
and  not exists   ( select 'x'          
from    es_comp_ctrl_type_mst b (nolock)          
where    b.customer_name  = a.customer_name          
and     b.project_name  = a.project_name          
and     b.req_no   = a.req_no          
and     b.process_name  = a.process_name          
and     b.component_name = a.component_name          
and     b.ctrl_type_name = a.new_ctrl_type )          
          
          
delete a          
from es_comp_ctrl_type_mst_mr_203_1 a(nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.req_no   = 'base'          
and  a.ctrl_type_name not in        
( select b.ctrl_type_name          
from es_comp_ctrl_type_mst  b(nolock)          
where b.customer_name  = @dst_customer_name          
and  b.project_name  = @dst_project_name          
and  b.process_name  = @dst_process_name          
and  b.component_name = @dst_component_name)          
          
update a          
set  a.new_ctrl_type  = a.ctrl_type_name          
from es_comp_ctrl_type_mst_mr_203_1 a (nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
          
          
update a          
set  a.new_ctrl_type  = left(a.ctrl_type_name + '_' + @mig_id, 40)          
from es_comp_ctrl_type_mst_mr_203_1 a (nolock),          
  es_comp_ctrl_type_mst   b (nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.req_no   = 'base'          
and  a.customer_name  = b.customer_name          
and  a.project_name  = b.project_name          
and  a.process_name  = b.process_name          
and  a.component_name = b.component_name          
and  a.ctrl_type_name = b.ctrl_type_name          
and  (a.mandatory_flag <> b.mandatory_flag          
or  a.visisble_flag  <> b.visisble_flag          
or  a.editable_flag  <> b.editable_flag          
or  a.caption_req  <> b.caption_req          
or  a.select_flag  <> b.select_flag          
or  a.zoom_req   <> b.zoom_req          
or  a.insert_req  <> b.insert_req          
or  a.delete_req  <> b.delete_req          
or  a.help_req   <> b.help_req          
or  a.event_handling_req<> b.event_handling_req          
or  a.ellipses_req  <> b.ellipses_req )          
          
          
insert  into  es_comp_ctrl_type_mst(          
customer_name,   project_name,    req_no,     process_name,          
component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type,          
mandatory_flag,   visisble_flag,    editable_flag,   caption_req,          
select_flag,   zoom_req,     insert_req,    delete_req,          
help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid,          
timestamp,    createdby,     createddate,   modifiedby,          
modifieddate,   caption_alignment,   caption_position,  caption_wrap,          
visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class,          
ctrl_class,    password_char,    tskimg_class,   hlpimg_class,          
disponlycmb_req,  html_txt_area,    report_req,    auto_tab_stop,          
spin_required,   spin_up_image,    spin_down_image,  InPlace_Calendar,          
EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,          
Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,   -- added for PNR2.0_21991 by Makesh Prabu. R          
buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,          
attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,          
image_row_height,  relative_url_path,   relative_document_path, relative_image_path,          
save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,          
Date_highlight,   ezee_report,    Lite_Attach_Document, Browse_Button_Enable,        
Delete_Button_Enable, image_row_width,   image_preview_height, image_preview_width,         
image_preview_req,  image_Accept_Type,   Lite_Attach_Image,  Disp_Only_Apply_Len ,        
editcombo_req ,   label_link,     IsListBox,    Toolbar_Not_Req,        
ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,        
ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit ,        
columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,        
Map_In_Req ,   Map_Out_Req ,    Accept_Type ,   file_Accept_Type,        
combo_link,    QR_Image,     Barcode_Image ,   Accpet_Type,        
FileSize,    Isfallback,     config_parameter,  config_value,        
upload ,    Is_Varbinary,    EMail,     Phone,        
StaticCaption,   Datagrid,     MoveFirst,    Move_PrevSet ,        
Move_Previous ,   Move_Next,     Move_NextSet,   Move_Last ,        
Carousel_Req,   Orientation,    WrapCount,    Box_Type ,        
ISDeviceInfo,   ListControl,    col_caption_align,  Gridheaderstyle,        
Gridtoolbarstyle,  preevent,     postevent,    col_data_align,        
norowstodisplay_notreq, avn_download,    PreventDownload,  spin_system_task,         
enabledefault,   hideinsert,     hidedelete,    hidecopy,        
hidecut,    hidefilterdata,    hidepdf,    hidereport,        
hidehtml,    hideexportexcel,   hideexportcsv,   hideexporttext,        
hideimportdata,   hidechart,     hideexportopenoffice, hidepersonalize ,        
hidefiltercolumn,  searchhide,     autolist_not_req,  hideselect,         
ishijri,    AutoHeight,     QlikLink ,    IsPivot,        
slider_type,   max_value,     min_value,    step_value,        
RangeMinimum, RangeMaximum,    RangeStartValue,  RangeEndValue,         
RangeStep,    RangeLabel,     RangeSelect,   ValueShown,Style,        
SystemGeneratedFileId, IsAssorted,     IsMarquee,    RatingType,        
CaptchaData,   RenderAs,     AttachmentWithDesc,        
preserve_gridposition, noofrowsselected_req )/* columns added by 13705 for component split migration --ends*/        
        
select distinct          
customer_name,   project_name,    'base',     process_name,          
component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type,          
mandatory_flag,   visisble_flag,    editable_flag,   caption_req,          
select_flag,   zoom_req,     insert_req,    delete_req,          
help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid,          
timestamp,    createdby,     getdate(),    modifiedby,          
getdate(),    case caption_alignment  when 'cente' then 'center'  else caption_alignment  end,           
             caption_position,  caption_wrap,          
visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class,          
ctrl_class,    password_char,    tskimg_class,   hlpimg_class,          
disponlycmb_req,  html_txt_area,    report_req,    auto_tab_stop,          
spin_required,   spin_up_image,    spin_down_image,  InPlace_Calendar,          
EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,          
Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,   -- added for PNR2.0_21991 by Makesh Prabu. R          
buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,          
attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,          
image_row_height,  relative_url_path,   relative_document_path, relative_image_path,          
save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,          
Date_highlight,   ezee_report,    Lite_Attach_Document, Browse_Button_Enable,        
Delete_Button_Enable, image_row_width,   image_preview_height, image_preview_width,         
image_preview_req,  image_Accept_Type,   Lite_Attach_Image,  Disp_Only_Apply_Len ,        
editcombo_req ,   label_link,     IsListBox,    Toolbar_Not_Req,        
ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,        
ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit ,        
columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,        
Map_In_Req ,   Map_Out_Req ,    Accept_Type ,   file_Accept_Type,        
combo_link,    QR_Image,     Barcode_Image ,   Accpet_Type,        
FileSize,    Isfallback,     config_parameter,  config_value,        
upload ,    Is_Varbinary,    EMail,     Phone,        
StaticCaption,   Datagrid,     MoveFirst,    Move_PrevSet ,        
Move_Previous ,   Move_Next,     Move_NextSet,   Move_Last ,        
Carousel_Req,   Orientation,    WrapCount,    Box_Type ,        
ISDeviceInfo,   ListControl,    col_caption_align,  Gridheaderstyle,        
Gridtoolbarstyle,  preevent,     postevent,    col_data_align,        
norowstodisplay_notreq, avn_download,    PreventDownload,  spin_system_task,         
enabledefault,   hideinsert,     hidedelete,    hidecopy,        
hidecut,    hidefilterdata,    hidepdf,    hidereport,        
hidehtml,    hideexportexcel,   hideexportcsv,   hideexporttext,        
hideimportdata,   hidechart,     hideexportopenoffice, hidepersonalize ,        
hidefiltercolumn,  searchhide,     autolist_not_req,  hideselect,         
ishijri,    AutoHeight,     QlikLink ,    IsPivot,        
slider_type,   max_value,     min_value,    step_value,        
RangeMinimum,   RangeMaximum,    RangeStartValue,  RangeEndValue,         
RangeStep,    RangeLabel,     RangeSelect,   ValueShown,Style,        
SystemGeneratedFileId, IsAssorted,     IsMarquee,    RatingType,        
CaptchaData,   RenderAs,     AttachmentWithDesc,        
preserve_gridposition, noofrowsselected_req        
        
from es_comp_ctrl_type_mst_mr_203_1 a(nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.req_no   = 'base'          
and  not exists( select 'x'         
from es_comp_ctrl_type_mst b (nolock)          
where b.customer_name  = a.customer_name          
and  b.project_name  = a.project_name          
and  b.req_no   = a.req_no          
and  b.process_name  = a.process_name          
and  b.component_name = a.component_name          
and  b.ctrl_type_name = a.new_ctrl_type )          
          
update a          
set  a.control_type = b.new_ctrl_type          
from es_comp_ctrl_type_mst_mr_203_1 b (nolock),          
  de_published_ui_control   a (nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.ecrno    = @tmp_ecr          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.customer_name  = b.customer_name          
and  a.project_name  = b.project_name          
and  a.process_name  = b.process_name          
and  a.component_name = b.component_name          
and  a.control_type  = b.ctrl_type_name          
          
update a          
set  a.column_type = b.new_ctrl_type          
from es_comp_ctrl_type_mst_mr_203_1 b (nolock),          
  de_published_ui_grid a (nolock)          
where a.customer_name  = @dst_customer_name          
and  a.project_name  = @dst_project_name          
and  a.ecrno    = @tmp_ecr          
and  a.process_name  = @dst_process_name          
and  a.component_name = @dst_component_name          
and  a.customer_name  = b.customer_name          
and  a.project_name  = b.project_name          
and  a.process_name  = b.process_name          
and  a.component_name = b.component_name          
and  a.column_type  = b.ctrl_type_name          
         
           
           
--es_comp_ctrl_type_mst_extn table starts          
--/*Code added by 13705 for component split migration -starts */         
       
          
delete  es_comp_ctrl_type_mst_extn_mr_203_1             
where customer_name  = @dst_customer_name              
and project_name  = @dst_project_name              
and process_name  = @dst_process_name              
and component_name = @dst_component_name          
        
      
        
select @ssql =''          
select @ssql = @ssql +'insert into es_comp_ctrl_type_mst_extn_mr_203_1(' + char(10)          
select @ssql = @ssql +'customer_name    ,project_name    ,req_no    ,process_name  ,component_name,'+ char(10)          
select @ssql = @ssql +'ctrl_type_name ,mig_id,         ctrl_type_descr ,base_ctrl_type  ,Configuration,'+ char(10)          
select @ssql = @ssql +'timestamp     ,createdby     ,createddate  ,modifiedby   ,modifieddate,'+ char(10)          
select @ssql = @ssql +'SliderType     ,SliderBehaviour   ,RenderType   ,Orientation  ,Startvalue,'+ char(10)          
select @ssql = @ssql +'Endvalue      ,Minvalue     ,Maxvalue   ,Stepvalue   ,SliderValue,'+ char(10)          
select @ssql = @ssql +'Showvalue     ,ShowTooltip    ,Rangelabel   ,Rangevalue   ,Rangetooltip,'+ char(10)          
select @ssql = @ssql +'RangeSelect     ,ValueShown     ,ExpandEvent  ,ExpandAllEvent  ,CollapseEvent,'+ char(10)          
select @ssql = @ssql +'CollapseAllEvent    ,ClickEvent     ,DDToolTip   ,ZoomMin   ,ZoomMax,'+ char(10)          
select @ssql = @ssql +'DefaultZoom     ,ZoomStep     ,NodeWidth   ,NodeHeight   ,DefaultFile,'+ char(10)          
select @ssql = @ssql +'IsOrgChart     ,checkevent     ,bufferedrows  ,SparkChartType  ,ChartType,'+ char(10)          
select @ssql = @ssql +'Delayedpwdmask    ,preserve_gridposition  ,Dynamicfileupload ,ServerSidePrint ,MultiFileSelect,'+ char(10)          
select @ssql = @ssql +'NoofCtrlPerLine    ,FormWidth     ,ControlWidth  ,LabelWidth   ,MetaDataBasedLink,'+ char(10)          
select @ssql = @ssql +'LabelAlignment    ,Scan      ,Autoselect   ,IsList    ,MultiSelect,'+ char(10)          
select @ssql = @ssql +'SelectedRowcount    ,NFCEnabled     ,AutoScan   ,IsToggle,'+ char(10)          
select @ssql = @ssql +'NodeIconReqd     ,NodeCustomClass   ,IsDocked   ,RuleBuilder  ,MultiSelectComboforRB,'+ char(10)          
select @ssql = @ssql +'CalendarControl    ,Setfocusevent    ,Leavefocusevent ,GanttControl  ,AutoSync,'+ char(10)          
select @ssql = @ssql +'SetFocusEventOccurence  ,LeaveFocusEventOccurence ,IsChips   ,IsSpellcheck  ,DirectPrint,'+ char(10)          
select @ssql = @ssql +'ListItemExpander    ,ReadOnly     ,ShowTodayLine  ,ShowRollupTasks ,ShowProjectLines,'+ char(10)          
select @ssql = @ssql +'SkipWeekendsDuringDragDrop ,LockedGridWidth   ,RowHeight   ,BottomLabelField ,TopLabelField,'+ char(10)          
select @ssql = @ssql +'LeftLabelField    ,RightLabelField   ,RollupLabelField ,Baseline   ,ScrollToDateCentered,'+ char(10)          
select @ssql = @ssql +'Zoom       ,Fit      ,Export    ,Highlight   ,Indent,'+ char(10)          
select @ssql = @ssql +'ContextMenu     ,PopupTaskEditor   ,GanttShift   ,GanttExpand  ,GanttInsert,'+ char(10)          
select @ssql = @ssql +'GanttDelete     ,Calendar     ,  IsScheduler, new_ctrl_type ,'+ char(10)    
select @ssql = @ssql +'ListItemType , IsSelectionReqdList , RowAlwaysExpanded ,IsMobile,'+ char(10)-- added by S.Srikanth for TECH-47407  
select @ssql = @ssql +'PaginationReqd , UpdateTaskReqd ,  DeleteTaskReqd ,DockedItem)'+ char(10)-- added by S.Srikanth for TECH-47407  
        
       
select @ssql = @ssql +'select distinct dst_customer_name   ,dst_project_name,   ''base'',   dst_process_name, '+ char(10)       
select @ssql = @ssql +'dst_component_name, '+ char(10)              
select @ssql = @ssql +'ctrl_type_name,   '''+@mig_id+''',    ctrl_type_descr, base_ctrl_type,  Configuration,'+ char(10)           
select @ssql = @ssql +'timestamp,     '''+@user+''',    '''+@time+''',  '''+@user+''',  '''+@time+''',' + char(10)             
select @ssql = @ssql +'SliderType     ,SliderBehaviour   ,RenderType   ,Orientation  ,Startvalue,'+ char(10)          
select @ssql = @ssql +'Endvalue      ,Minvalue     ,Maxvalue   ,Stepvalue   ,SliderValue,'+ char(10)          
select @ssql = @ssql +'Showvalue     ,ShowTooltip    ,Rangelabel   ,Rangevalue   ,Rangetooltip,'+ char(10)          
select @ssql = @ssql +'RangeSelect     ,ValueShown     ,ExpandEvent  ,ExpandAllEvent  ,CollapseEvent,'+ char(10)          
select @ssql = @ssql +'CollapseAllEvent    ,ClickEvent     ,DDToolTip   ,ZoomMin   ,ZoomMax,'+ char(10)          
select @ssql = @ssql +'DefaultZoom     ,ZoomStep     ,NodeWidth   ,NodeHeight   ,DefaultFile,'+ char(10)     
select @ssql = @ssql +'IsOrgChart     ,checkevent     ,bufferedrows  ,SparkChartType  ,ChartType,'+ char(10)          
select @ssql = @ssql +'Delayedpwdmask    ,preserve_gridposition  ,Dynamicfileupload ,ServerSidePrint ,MultiFileSelect,'+ char(10)          
select @ssql = @ssql +'NoofCtrlPerLine    ,FormWidth     ,ControlWidth  ,LabelWidth   ,MetaDataBasedLink,'+char(10)          
select @ssql = @ssql +'LabelAlignment    ,Scan      ,Autoselect   ,IsList    ,MultiSelect,'+ char(10)          
select @ssql = @ssql +'SelectedRowcount    ,NFCEnabled     ,AutoScan   ,IsToggle,'+ char(10)          
select @ssql = @ssql +'NodeIconReqd     ,NodeCustomClass   ,IsDocked   ,RuleBuilder  ,MultiSelectComboforRB,'+ char(10)          
select @ssql = @ssql +'CalendarControl    ,Setfocusevent    ,Leavefocusevent ,GanttControl  ,AutoSync,'+ char(10)          
select @ssql = @ssql +'SetFocusEventOccurence  ,LeaveFocusEventOccurence ,IsChips   ,IsSpellcheck  ,DirectPrint,'+ char(10)          
select @ssql = @ssql +'ListItemExpander    ,ReadOnly     ,ShowTodayLine  ,ShowRollupTasks ,ShowProjectLines,'+ char(10)          
select @ssql = @ssql +'SkipWeekendsDuringDragDrop ,LockedGridWidth   ,RowHeight   ,BottomLabelField ,TopLabelField,'+ char(10)          
select @ssql = @ssql +'LeftLabelField    ,RightLabelField   ,RollupLabelField ,Baseline   ,ScrollToDateCentered,'+ char(10)          
select @ssql = @ssql +'Zoom       ,Fit      ,Export    ,Highlight   ,Indent,'+ char(10)          
select @ssql = @ssql +'ContextMenu     ,PopupTaskEditor   ,GanttShift   ,GanttExpand  ,GanttInsert,'+ char(10)          
select @ssql = @ssql +'GanttDelete     ,Calendar     ,IsScheduler, '''',' + char(10)     
select @ssql = @ssql +'ListItemType , IsSelectionReqdList , RowAlwaysExpanded ,IsMobile,'+ char(10)-- added by S.Srikanth for TECH-47407  
select @ssql = @ssql +'PaginationReqd , UpdateTaskReqd ,  DeleteTaskReqd ,DockedItem'+ char(10) -- added by S.Srikanth for TECH-47407  
          
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_ctrl_type_mst_extn  a (nolock) ,'+char(10)          
select @ssql = @ssql + '     engg_mr_ui_mst_203_1 b (nolock)'+char(10)          
select @ssql = @ssql + ' where  a.customer_name  = ''' + @customername + ''''  + char(10)          
select @ssql = @ssql + ' and    a.project_name   = ''' + @projectname + ''''  + char(10)          
select @ssql = @ssql + ' and    a.process_name   = ''' +@processname +''''   + char(10)          
select @ssql = @ssql + ' and    a.component_name = ''' +@componentname +''''   + char(10)          
select @ssql = @ssql + ' and    a.customer_name  = b.src_customer_name '   + char(10)          
select @ssql = @ssql + ' and    a.project_name   = b.src_project_name '    + char(10)          
select @ssql = @ssql + ' and    a.process_name   = b.src_process_name '    + char(10)          
select @ssql = @ssql + ' and    a.component_name = b.src_component_name '   + char(10)          
select @ssql = @ssql + ' and    b.act_mig_flag = 1'       + char(10)          
select @ssql = @ssql + ' and    b.mig_id   = '''+@mig_id+''''      + char(10)            
        
exec(@ssql)        
         
        
update a              
set  a.new_ctrl_type  = a.ctrl_type_name              
from es_comp_ctrl_type_mst_extn_mr_203_1 a (nolock)              
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name              
        
insert into es_comp_ctrl_type_mst_extn(        
customer_name     ,project_name   ,req_no    ,process_name   ,component_name        
,ctrl_type_name     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp        
,createdby      ,createddate   ,modifiedby   ,modifieddate   ,SliderType        
,SliderBehaviour    ,RenderType    ,Orientation  ,Startvalue    ,Endvalue        
,Minvalue      ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue        
,ShowTooltip     ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect        
,ValueShown      ,ExpandEvent   ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent        
,ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom        
,ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart        
,checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask        
,preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine        
,FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment        
,Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount        
,NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd        
,NodeCustomClass    ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl        
,Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence        
,LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander        
,ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop        
,LockedGridWidth    ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField             
,RightLabelField    ,RollupLabelField  ,Baseline   ,ScrollToDateCentered ,Zoom               
,Fit       ,Export     ,Highlight   ,Indent     ,ContextMenu             
,PopupTaskEditor    ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete        
,Calendar      ,IsScheduler,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded ,  -- added by S.Srikanth for TECH-47407  
IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem)        -- added by S.Srikanth for TECH-47407  
        
select distinct           
customer_name     ,project_name   ,'base'    ,process_name   ,component_name        
,new_ctrl_type     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp        
,createdby      ,getdate()    ,modifiedby   ,getdate()    ,SliderType        
,SliderBehaviour    ,RenderType    ,Orientation  ,Startvalue    ,Endvalue        
,Minvalue      ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue        
,ShowTooltip     ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect        
,ValueShown      ,ExpandEvent   ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent        
,ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom        
,ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart        
,checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask        
,preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine        
,FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment        
,Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount        
,NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd        
,NodeCustomClass    ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl        
,Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence        
,LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander        
,ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop        
,LockedGridWidth    ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField             
,RightLabelField    ,RollupLabelField  ,Baseline   ,ScrollToDateCentered ,Zoom               
,Fit       ,Export     ,Highlight   ,Indent     ,ContextMenu             
,PopupTaskEditor    ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete        
,Calendar      ,IsScheduler  ,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded , -- added by S.Srikanth for TECH-47407  
IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem    -- added by S.Srikanth for TECH-47407  
        
from es_comp_ctrl_type_mst_extn_mr_203_1 a(nolock)          
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name              
and  a.req_no   = 'base'          
and  not exists( select 'x'              
from es_comp_ctrl_type_mst_extn b (nolock)              
where b.customer_name  = a.customer_name              
and  b.project_name  = a.project_name              
and  b.req_no   = a.req_no              
and  b.process_name  = a.process_name              
and  b.component_name = a.component_name              
and  b.ctrl_type_name = a.new_ctrl_type )            
        
delete a          
from es_comp_ctrl_type_mst_extn_mr_203_1 a(nolock)              
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name         
and  a.req_no   = 'base'              
and  a.ctrl_type_name not in( select b.ctrl_type_name              
from es_comp_ctrl_type_mst_extn  b(nolock)              
where b.customer_name  = @dst_customer_name              
and  b.project_name  = @dst_project_name              
and  b.process_name  = @dst_process_name              
and  b.component_name = @dst_component_name)          
        
        
--update a           
--set a.new_ctrl_type=a.ctrl_type_name          
--from es_comp_ctrl_type_mst_extn_mr_203_1 a (nolock)          
--where a.customer_name  = @dst_customer_name              
--and  a.project_name  = @dst_project_name              
--and  a.process_name  = @dst_process_name              
--and  a.component_name = @dst_component_name              
         
        
--update a          
--set a.new_ctrl_type=left(a.ctrl_type_name + '_' + @mig_id, 40)     --test123    
--from es_comp_ctrl_type_mst_extn_mr_203_1 a (nolock),          
--es_comp_ctrl_type_mst_extn b(nolock)          
--where a.customer_name  = @dst_customer_name              
--and  a.project_name  = @dst_project_name              
--and  a.process_name  = @dst_process_name              
--and  a.component_name = @dst_component_name              
--and  a.req_no   = 'base'              
--and  a.customer_name  = b.customer_name              
--and  a.project_name  = b.project_name              
--and  a.process_name  = b.process_name              
--and  a.component_name = b.component_name              
--and  a.ctrl_type_name = b.ctrl_type_name     
--and a.base_ctrl_type  = b.base_ctrl_type             
----and  (a.mandatory_flag <> b.mandatory_flag              
----or  a.visisble_flag  <> b.visisble_flag              
----or  a.editable_flag  <> b.editable_flag              
----or  a.caption_req  <> b.caption_req              
----or  a.select_flag  <> b.select_flag              
----or  a.zoom_req   <> b.zoom_req              
----or  a.insert_req  <> b.insert_req              
----or  a.delete_req  <> b.delete_req              
----or  a.help_req   <> b.help_req              
----or  a.event_handling_req<> b.event_handling_req              
----or  a.ellipses_req  <> b.ellipses_req )              
        
         
insert into es_comp_ctrl_type_mst_extn(          
customer_name     ,project_name   ,req_no    ,process_name   ,component_name        
,ctrl_type_name     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp        
,createdby      ,createddate   ,modifiedby   ,modifieddate   ,SliderType        
,SliderBehaviour    ,RenderType    ,Orientation  ,Startvalue    ,Endvalue        
,Minvalue      ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue        
,ShowTooltip     ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect        
,ValueShown      ,ExpandEvent ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent        
,ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom        
,ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart        
,checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask        
,preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine        
,FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment        
,Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount        
,NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd        
,NodeCustomClass    ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl        
,Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence        
,LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander        
,ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop        
,LockedGridWidth    ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField             
,RightLabelField    ,RollupLabelField  ,Baseline   ,ScrollToDateCentered ,Zoom               
,Fit       ,Export     ,Highlight   ,Indent     ,ContextMenu             
,PopupTaskEditor    ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete        
,Calendar      ,IsScheduler,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded ,  -- added by S.Srikanth for TECH-47407  
IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem)       -- added by S.Srikanth for TECH-47407  
        
select distinct         
customer_name     ,project_name   ,'base'    ,process_name   ,component_name        
,new_ctrl_type     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp        
,createdby      ,getdate()    ,modifiedby   ,getdate()    ,SliderType        
,SliderBehaviour    ,RenderType    ,Orientation  ,Startvalue    ,Endvalue        
,Minvalue      ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue        
,ShowTooltip     ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect        
,ValueShown      ,ExpandEvent   ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent        
,ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom        
,ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart        
,checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask        
,preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine        
,FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment        
,Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount        
,NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd        
,NodeCustomClass    ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl        
,Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence        
,LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander        
,ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop        
,LockedGridWidth    ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField             
,RightLabelField    ,RollupLabelField  ,Baseline ,ScrollToDateCentered ,Zoom               
,Fit       ,Export     ,Highlight   ,Indent     ,ContextMenu             
,PopupTaskEditor    ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete        
,Calendar      ,IsScheduler  ,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded ,  -- added by S.Srikanth for TECH-47407  
IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem   -- added by S.Srikanth for TECH-47407  
        
        
from es_comp_ctrl_type_mst_extn_mr_203_1  a (nolock)          
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name              
and  a.req_no   = 'base'              
and  not exists( select 'x'              
from es_comp_ctrl_type_mst_extn b (nolock)              
where b.customer_name  = a.customer_name              
and  b.project_name  = a.project_name              
and  b.req_no   = a.req_no              
and  b.process_name  = a.process_name              
and  b.component_name = a.component_name              
and  b.ctrl_type_name = a.new_ctrl_type )          
          
/*        
update a              
set  a.control_type = b.new_ctrl_type              
from es_comp_ctrl_type_mst_extn_mr_203_1 b (nolock),        
de_published_ui_control   a (nolock)              
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.ecrno    = @tmp_ecr              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name              
and  a.customer_name  = b.customer_name              
and  a.project_name  = b.project_name              
and  a.process_name  = b.process_name              
and  a.component_name = b.component_name              
and  a.control_type  = b.ctrl_type_name              
        
update a              
set  a.column_type = b.new_ctrl_type              
from es_comp_ctrl_type_mst_extn_mr_203_1 b (nolock),              
de_published_ui_grid   a (nolock)              
where a.customer_name  = @dst_customer_name              
and  a.project_name  = @dst_project_name              
and  a.ecrno    = @tmp_ecr              
and  a.process_name  = @dst_process_name              
and  a.component_name = @dst_component_name              
and  a.customer_name  = b.customer_name              
and  a.project_name  = b.project_name              
and  a.process_name  = b.process_name              
and  a.component_name = b.component_name              
and  a.column_type  = b.ctrl_type_name              
          
 */         
         
--/*Code added by 13705 for component split migration -ends */             
     
  
    
    
-- Modified By Bakiaraj V on 25 Aug 2006    
--    delete es_comp_task_type_mst_mr_203_1    
--    where Customer_Name  = @customername    
--    and  Project_Name = @projectname    
--    and  process_name = @processname    
--    and  component_name = @componentname    
    
delete es_comp_task_type_mst_mr_203_1    
where Customer_Name  = @dst_customer_name    
and  Project_Name = @dst_project_name    
and  process_name = @dst_process_name    
and  component_name = @dst_component_name    
    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_comp_task_type_mst_mr_203_1(' + char(10)    
select @ssql = @ssql + '      customer_name,    project_name,      req_no,       process_name,'   + char(10)    
select @ssql = @ssql + '      component_name,    task_type_name,      task_type_descr,   default_for,'   + char(10)    
select @ssql = @ssql + '      refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,' + char(10)    
select @ssql = @ssql + '      cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,'   + char(10)    
select @ssql = @ssql + '      hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,'   + char(10)    
select @ssql = @ssql + '      trn_scope_req,    comp_task_type_sysid,   timestamp,      createdby,'   + char(10)    
select @ssql = @ssql + '      createddate,     modifiedby,       modifieddate,    task_type_doc,'  + char(10)    
select @ssql = @ssql + '      hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,'   + char(10)    
select @ssql = @ssql + '      no_placeholder,    data_save_req,      print_req,      task_confirmation, new_task_type,' + char(10)    
--select @ssql = @ssql + '      Logic_Extensions, process_updrows )'  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/   --code commented for the bugid:PNR2.0_35203    
select @ssql = @ssql + '      Logic_Extensions, process_updrows,   alternate_db )'  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + '  select  distinct dst_customer_name, dst_project_name,   ''base'',      dst_process_name,'  + char(10)    
select @ssql = @ssql + '      dst_component_name,  task_type_name,      task_type_descr,   default_for,'   + char(10)    
select @ssql = @ssql + '      refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,' + char(10)    
select @ssql = @ssql + '      cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,'   + char(10)    
select @ssql = @ssql + '      hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,'   + char(10)    
select @ssql = @ssql + '      trn_scope_req,    left(left(component_name,10)+req_no+task_type_name+task_type_descr,40),timestamp,'''+@user+''',' + char(10)    
select @ssql = @ssql + '      '''+@time+''',      '''+@user+''',       '''+@time+''',      task_type_doc,'  + char(10)    
select @ssql = @ssql + '      hdr_save_req,     ml_save_req,      fprowno_req,   cbdef_req,'   + char(10)    
select @ssql = @ssql + '      no_placeholder,    data_save_req,      print_req,      task_confirmation, '''' '  + char(10)    
--select @ssql = @ssql + '      ,Logic_Extensions,  process_updrows '  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/  --code commented for the bugid:PNR2.0_35203    
select @ssql = @ssql + '      ,Logic_Extensions, process_updrows,   alternate_db '  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_task_type_mst  a ,'   + char(10)    
select @ssql = @ssql + '      engg_mr_ui_mst_203_1 b (nolock)'    + char(10)    
select @ssql = @ssql + '  where  a.customer_name    = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + '  and    a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + '  and    a.process_name    = ''' +@processname+''''   + char(10)    
select @ssql = @ssql + '  and    a.component_name   = ''' +@componentname+''''   + char(10)    
select @ssql = @ssql + '  and    a.customer_name    = b.src_customer_name'    + char(10)    
select @ssql = @ssql + '  and    a.project_name    = b.src_project_name   '   + char(10)    
select @ssql = @ssql + '  and    a.process_name    = b.src_process_name'    + char(10)    
select @ssql = @ssql + '  and    a.component_name   = b.src_component_name'   + char(10)    
select @ssql = @ssql + '  and  b.act_mig_flag = 1'       + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
    
exec(@ssql)    
    
update a    
set  a.new_task_type  = a.task_type_name    
from es_comp_task_type_mst_mr_203_1 a (nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
    
insert  into  es_comp_task_type_mst(    
customer_name,    project_name,      req_no,       process_name,    
component_name,    task_type_name,      task_type_descr,   default_for,    
refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,    
cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,    
hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,    
trn_scope_req,    comp_task_type_sysid,   timestamp,      createdby,    
createddate,     modifiedby,       modifieddate,    task_type_doc,    
hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,    
no_placeholder,    data_save_req,      print_req,      task_confirmation,    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 starts */    
Logic_Extensions,  process_updrows--) --code commented for the bugid:PNR2.0_35203    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 ends */    
,alternate_db ) --code added for the bugid:PNR2.0_35203    
select distinct    
customer_name,    project_name,      req_no,       process_name,    
component_name,    new_task_type,      task_type_descr,   default_for,    
refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,    
cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,    
hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,    
trn_scope_req,    new_task_type,    timestamp,      createdby,    
getdate(),     modifiedby,       getdate(),     task_type_doc,    
hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,    
no_placeholder,    data_save_req,      print_req,      task_confirmation,    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 starts */    
Logic_Extensions,  process_updrows    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 ends */    
,alternate_db  --code added for the bugid:PNR2.0_35203    
from es_comp_task_type_mst_mr_203_1 a(nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
and  not exists( select 'x'    
from es_comp_task_type_mst b (nolock)    
where b.customer_name  = a.customer_name    
and  b.project_name  = a.project_name    
and  b.req_no   = a.req_no    
and  b.process_name  = a.process_name    
and  b.component_name = a.component_name    
and  b.task_type_name = a.new_task_type )    
    
delete a    
from es_comp_task_type_mst_mr_203_1 a(nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
and  a.task_type_name not in( select b.task_type_name    
from es_comp_task_type_mst  b(nolock)    
where b.customer_name  = @dst_customer_name    
and  b.project_name  = @dst_project_name    
and  b.process_name  = @dst_process_name    
and  b.component_name = @dst_component_name )    
    
update a    
set  a.new_task_type  = a.task_type_name    
from es_comp_task_type_mst_mr_203_1 a (nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
    
update a    
set  a.new_task_type  = left(a.task_type_name + '_' + @mig_id, 40)    
from es_comp_task_type_mst_mr_203_1 a (nolock),    
es_comp_task_type_mst   b (nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
and  a.customer_name  = b.customer_name    
and  a.project_name  = b.project_name    
and  a.process_name  = b.process_name    
and  a.component_name = b.component_name    
and  a.task_type_name = b.task_type_name    
and  (a.refresh_on_save <> b.refresh_on_save    
or  a.valid_on_init  <> b.valid_on_init    
or  a.err_handle_method <> b.err_handle_method    
or  a.incl_place_holder <> b.incl_place_holder    
or  a.cond_ml_fetch  <> b.cond_ml_fetch    
or  a.clr_on_page_save <> b.clr_on_page_save    
or  a.hdr_fetch_req  <> b.hdr_fetch_req    
or  a.ml_fet_req  <> b.ml_fet_req    
or  a.hdr_ref_req  <> b.hdr_ref_req    
or  a.hdr_check_req  <> b.hdr_check_req    
or  a.proc_sel_rows  <> b.proc_sel_rows    
or  a.usr_role_map  <> b.usr_role_map    
or  a.trn_scope_req  <> b.trn_scope_req    
or  a.data_save_req  <> b.data_save_req    
or  a.print_req   <> b.print_req    
or  a.task_confirmation <> b.task_confirmation )    
    
    
insert  into  es_comp_task_type_mst(    
customer_name,    project_name,      req_no,       process_name,    
component_name,    task_type_name,      task_type_descr,   default_for,    
refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,    
cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,    
hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,    
trn_scope_req,    comp_task_type_sysid,   timestamp,      createdby,    
createddate,     modifiedby,       modifieddate,    task_type_doc,    
hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,    
no_placeholder,    data_save_req,      print_req,      task_confirmation,    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 starts */    
Logic_Extensions,  process_updrows--) --code commented for the bugid:PNR2.0_35203    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 ends */    
,alternate_db ) --code added for the bugid:PNR2.0_35203    
select distinct    
customer_name,    project_name,      req_no,       process_name,    
component_name,    new_task_type,      task_type_descr,   default_for,    
refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,    
cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,    
hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,    
trn_scope_req,    new_task_type,   timestamp,      createdby,    
getdate(),     modifiedby,       getdate(),     task_type_doc,    
hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,    
no_placeholder,    data_save_req,      print_req,      task_confirmation,    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 starts */    
Logic_Extensions,  process_updrows    
/*Code Modified by Gankan.G to include new columns for bug_id:PNR2.0_28990 ends */    
,alternate_db  --code added for the bugid:PNR2.0_35203    
from es_comp_task_type_mst_mr_203_1 a(nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.req_no   = 'base'    
and  not exists( select 'x'    
from es_comp_task_type_mst b (nolock)    
where b.customer_name  = a.customer_name    
and  b.project_name  = a.project_name    
and  b.req_no   = a.req_no    
and  b.process_name  = a.process_name    
and  b.component_name = a.component_name    
and  b.task_type_name = a.new_task_type )    
    
update a    
set  a.task_pattern  = b.new_task_type    
from es_comp_task_type_mst_mr_203_1 b (nolock),    
de_published_action    a (nolock)    
where a.customer_name  = @dst_customer_name    
and  a.project_name  = @dst_project_name    
and  a.ecrno    = @tmp_ecr    
and  a.process_name  = @dst_process_name    
and  a.component_name = @dst_component_name    
and  a.customer_name  = b.customer_name    
and  a.project_name  = b.project_name    
and  a.process_name  = b.process_name    
and  a.component_name = b.component_name    
and  a.task_pattern  = b.task_type_name    
    
end    
else    
begin    
    
select @ssql = ''        
select @ssql = @ssql + '  insert  into  es_comp_ctrl_type_mst( ' + char(10)        
select @ssql = @ssql + ' customer_name,   project_name,    req_no,     process_name, '   + char(10)          
select @ssql = @ssql + '    component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type, '  + char(10)          
select @ssql = @ssql + '    mandatory_flag,   visisble_flag,    editable_flag,   caption_req, '   + char(10)          
select @ssql = @ssql + '    select_flag,   zoom_req,     insert_req,    delete_req, '   + char(10)          
select @ssql = @ssql + '    help_req,    event_handling_req,   ellipses_req,   comp_ctrl_type_sysid, ' + char(10)          
select @ssql = @ssql + ' timestamp,    createdby,     createddate,   modifiedby, '   + char(10)          
select @ssql = @ssql + ' modifieddate,   caption_alignment,   caption_position,  caption_wrap, '   + char(10)          
select @ssql = @ssql + '    visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class, '   + char(10)          
select @ssql = @ssql + '    ctrl_class,    password_char,    tskimg_class,   hlpimg_class,'   + char(10)          
select @ssql = @ssql + '    disponlycmb_req,  html_txt_area,'   + char(10)          
select @ssql = @ssql + '    report_req,    Auto_tab_stop,    Spin_required,   Spin_up_image,  '  + char(10)          
select @ssql = @ssql + '    EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,'  + char(10)          
select @ssql = @ssql + '    Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,'  + char(10) -- added for PNR2.0_21991 by Makesh Prabu. R          
select @ssql = @ssql + ' buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,' + char(10)          
select @ssql = @ssql + ' attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,' + char(10)          
select @ssql = @ssql + ' image_row_height,  relative_url_path,   relative_document_path, relative_image_path,' + char(10)          
select @ssql = @ssql + ' save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,'   + char(10)          
select @ssql = @ssql + ' Date_highlight,   ezee_report,    IsListBox,    Toolbar_Not_Req, '      + char(10)          
select @ssql = @ssql + ' ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,'   +char(10)        
select @ssql = @ssql + ' ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit,'    +char(10)         
select @ssql = @ssql + ' columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,' +char(10)        
select @ssql = @ssql + ' Lite_Attach_Document, Browse_Button_Enable,  Delete_Button_Enable, image_row_width,'  + char(10)          
select @ssql = @ssql + ' image_preview_height, image_preview_width,  image_preview_req,  image_Accept_Type,'     + char(10)          
select @ssql = @ssql + ' Lite_Attach_Image ,  timezone ,     autoexpand,    Disp_Only_Apply_Len, ' + char(10)          
select @ssql = @ssql + '    editcombo_req ,   label_link,     Map_In_Req,    Map_Out_Req,'   + char(10)  --old        
select @ssql = @ssql + ' Accept_Type,   file_Accept_Type,   combo_link,    QR_Image,    '  + char(10)        
select @ssql = @ssql + ' Barcode_Image,   Accpet_Type,    FileSize,    Isfallback,    '  + char(10)        
select @ssql = @ssql + ' config_parameter,  config_value,    upload,     Is_Varbinary,  '  + char(10)        
select @ssql = @ssql + ' EMail,     Phone,      StaticCaption,   Datagrid,      '  + char(10)        
select @ssql = @ssql + ' MoveFirst,    Move_PrevSet,     Move_Previous,   Move_Next,     '  + char(10)        
select @ssql = @ssql + ' Move_NextSet,   Move_Last,     Carousel_Req,   Orientation,   '  + char(10)        
select @ssql = @ssql + ' WrapCount,    Box_Type,     ISDeviceInfo,   ListControl, '  + char(10)       
select @ssql = @ssql + ' col_caption_align,  Gridheaderstyle,   Gridtoolbarstyle,  preevent,      '  + char(10)        
select @ssql = @ssql + ' postevent,    col_data_align,    norowstodisplay_notreq, avn_download,  '  + char(10)        
select @ssql = @ssql + ' PreventDownload,  spin_system_task,    enabledefault,   hideinsert,    '  + char(10)        
select @ssql = @ssql + ' hidedelete,    hidecopy,     hidecut,    hidefilterdata,'  + char(10)        
select @ssql = @ssql + ' hidepdf,    hidereport,     hidehtml,    hideexportexcel,'  + char(10)        
select @ssql = @ssql + ' hideexportcsv,    hideexporttext,    hideimportdata,  hidechart,     '  + char(10)        
select @ssql = @ssql + ' hideexportopenoffice, hidepersonalize ,   hidefiltercolumn,  searchhide,    '  + char(10)        
select @ssql = @ssql + ' autolist_not_req,  hideselect,     ishijri,    AutoHeight,    '  + char(10)        
select @ssql = @ssql + ' QlikLink,    IsPivot,     slider_type,   max_value,     '  + char(10)        
select @ssql = @ssql + ' min_value,    step_value,     RangeMinimum,   RangeMaximum,  '  + char(10)        
select @ssql = @ssql + ' RangeStartValue,  RangeEndValue,    RangeStep,    RangeLabel,    '  + char(10)        
select @ssql = @ssql + ' RangeSelect,   ValueShown,     Style,     SystemGeneratedFileId,' + char(10)        
select @ssql = @ssql + ' IsAssorted,    IsMarquee,     RatingType,    CaptchaData, '   + char(10)        
select @ssql = @ssql + ' RenderAs,    AttachmentWithDesc,   preserve_gridposition, noofrowsselected_req ) '+ char(10)        
        
select @ssql = @ssql + 'select distinct dst_customer_name, dst_project_name, ''base'',    dst_process_name,'  + char(10)        
select @ssql = @ssql + '    component_name,   ctrl_type_name,    ctrl_type_descr,  base_ctrl_type, '  + char(10)          
select @ssql = @ssql + '    mandatory_flag,   visisble_flag,    editable_flag,   caption_req, '   + char(10)          
select @ssql = @ssql + '    select_flag,   zoom_req,     insert_req,    delete_req, '   + char(10)          
select @ssql = @ssql + '    help_req,    event_handling_req,   ellipses_req,   left(req_no+ctrl_type_name+cast(getdate() as varchar(20)),40),'+ char(10)         
select @ssql = @ssql + ' timestamp,    '''+@user+''',   '''+@time+''',   '''+@user+''','   + char(10)          
select @ssql = @ssql + ' '''+@time+''',   caption_alignment,   caption_position,  caption_wrap, '   + char(10)          
select @ssql = @ssql + '    visisble_rows,   ctrl_type_doc,    ctrl_position,   label_class, '   + char(10)          
select @ssql = @ssql + '    ctrl_class,    password_char,    tskimg_class,   hlpimg_class,'   + char(10)          
select @ssql = @ssql + 'disponlycmb_req,  html_txt_area,'   + char(10)          
select @ssql = @ssql + '    report_req,    Auto_tab_stop,    Spin_required,   Spin_up_image,  '  + char(10)          
select @ssql = @ssql + '    EditMask,    NoofLinesPerRow,   RowHeight,    Vscrollbar_Req,'  + char(10)          
select @ssql = @ssql + '    Is_Extjs_Control,  Extjs_Ctrl_type,   gridlite_req,   bulletlink_req,'  + char(10) -- added for PNR2.0_21991 by Makesh Prabu. R          
select @ssql = @ssql + ' buttoncombo_req,  associatedlist_req,   onfocustask_req,  listrefilltask_req,' + char(10)          
select @ssql = @ssql + ' attach_document,  image_upload,    inplace_image,   listedit_noofcolumns,' + char(10)          
select @ssql = @ssql + ' image_row_height,  relative_url_path,   relative_document_path, relative_image_path,' + char(10)          
select @ssql = @ssql + ' save_doc_content_to_db, save_image_content_to_db, dataascaption,   image_icon,'   + char(10)          
select @ssql = @ssql + ' Date_highlight,   ezee_report,    IsListBox,    Toolbar_Not_Req, '      + char(10)          
select @ssql = @ssql + ' ColumnBorder_Not_Req, RowBorder_Not_Req,   PagenavigationOnly,  RowNO_Not_Req,'   +char(10)        
select @ssql = @ssql + ' ButtonHome_Req,   ButtonPrevious_Req,   Tooltip_Not_Req,  Forcefit,'    +char(10)         
select @ssql = @ssql + ' columncaption_Not_Req, Border_Not_Req,    IsModal,    Alternate_Color_Req,' +char(10)        
select @ssql = @ssql + ' Lite_Attach_Document, Browse_Button_Enable,  Delete_Button_Enable, image_row_width,'  + char(10)          
select @ssql = @ssql + ' image_preview_height, image_preview_width,  image_preview_req,  image_Accept_Type,'     + char(10)          
select @ssql = @ssql + ' Lite_Attach_Image ,  timezone ,     autoexpand,    Disp_Only_Apply_Len, ' + char(10)          
select @ssql = @ssql + '    editcombo_req ,   label_link,     Map_In_Req,    Map_Out_Req,'   + char(10)  --old        
select @ssql = @ssql + ' Accept_Type,   file_Accept_Type,   combo_link,  QR_Image,   '  + char(10)        
select @ssql = @ssql + ' Barcode_Image,   Accpet_Type,    FileSize,    Isfallback,    '  + char(10)        
select @ssql = @ssql + ' config_parameter,  config_value,    upload,     Is_Varbinary,  '  + char(10)        
select @ssql = @ssql + ' EMail,     Phone,      StaticCaption,   Datagrid,      '  + char(10)        
select @ssql = @ssql + ' MoveFirst,    Move_PrevSet,     Move_Previous,   Move_Next,     '  + char(10)        
select @ssql = @ssql + ' Move_NextSet,   Move_Last,     Carousel_Req,   Orientation,   '  + char(10)        
select @ssql = @ssql + ' WrapCount,    Box_Type,     ISDeviceInfo,   ListControl,   '  + char(10)        
select @ssql = @ssql + ' col_caption_align,  Gridheaderstyle,   Gridtoolbarstyle,  preevent,      '  + char(10)        
select @ssql = @ssql + ' postevent,    col_data_align,    norowstodisplay_notreq, avn_download,  '  + char(10)        
select @ssql = @ssql + ' PreventDownload,  spin_system_task,    enabledefault,   hideinsert,    '  + char(10)        
select @ssql = @ssql + ' hidedelete,    hidecopy,     hidecut,    hidefilterdata,'  + char(10)        
select @ssql = @ssql + ' hidepdf,    hidereport,     hidehtml,    hideexportexcel,'  + char(10)        
select @ssql = @ssql + ' hideexportcsv,    hideexporttext,    hideimportdata,   hidechart,     '  + char(10)        
select @ssql = @ssql + ' hideexportopenoffice, hidepersonalize ,   hidefiltercolumn,  searchhide,    '  + char(10)        
select @ssql = @ssql + ' autolist_not_req,  hideselect,     ishijri,    AutoHeight,    '  + char(10)        
select @ssql = @ssql + ' QlikLink,    IsPivot,     slider_type,   max_value,     '  + char(10)        
select @ssql = @ssql + ' min_value,    step_value,     RangeMinimum,   RangeMaximum,  '  + char(10)        
select @ssql = @ssql + ' RangeStartValue,  RangeEndValue,    RangeStep,    RangeLabel,    '  + char(10)        
select @ssql = @ssql + ' RangeSelect,   ValueShown,     Style,     SystemGeneratedFileId,' + char(10)        
select @ssql = @ssql + ' IsAssorted,    IsMarquee,     RatingType,    CaptchaData, '   + char(10)        
select @ssql = @ssql + ' RenderAs,    AttachmentWithDesc,   preserve_gridposition, noofrowsselected_req ' + char(10)        
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_ctrl_type_mst  a ,'   + char(10)        
select @ssql = @ssql + '    engg_mr_ui_mst_203_1 b (nolock)'    + char(10)        
select @ssql = @ssql + ' where a.customer_name  = ''' + @customername + ''''  + char(10)        
select @ssql = @ssql + ' and  a.project_name   = ''' + @projectname + ''''  + char(10)        
select @ssql = @ssql + ' and  a.process_name   = ''' +@processname+''''   + char(10)        
select @ssql = @ssql + ' and  a.component_name = ''' +@componentname+''''   + char(10)        
select @ssql = @ssql + ' and  a.customer_name  = b.src_customer_name '   + char(10)        
select @ssql = @ssql + ' and  a.project_name   = b.src_project_name '    + char(10)        
select @ssql = @ssql + ' and  a.process_name   = b.src_process_name '    + char(10)        
select @ssql = @ssql + ' and  a.component_name = b.src_component_name '   + char(10)        
select @ssql = @ssql + ' and  b.act_mig_flag  = 1'       + char(10)        
select @ssql = @ssql + ' and  b.mig_id   = '''+@mig_id+''''      + char(10)        
select @ssql = @ssql + ' and    not exists ( '     + char(10)        
select @ssql = @ssql + '            select  ''x'' ' + char(10)        
select @ssql = @ssql + '            from  es_comp_ctrl_type_mst c (nolock)'    + char(10)        
select @ssql = @ssql + '            where   c.customer_name = dst_customer_name  '  + char(10)        
select @ssql = @ssql + '            and    c.project_name   = dst_project_name  '  + char(10)        
select @ssql = @ssql + '            and    c.req_no      = ''base''    '   + char(10)        
select @ssql = @ssql + '            and    c.process_name   = dst_process_name '  + char(10)        
select @ssql = @ssql + '            and    c.component_name  = dst_component_name '  + char(10)        
select @ssql = @ssql + '            and    c.ctrl_type_name  = a.ctrl_type_name) '  + char(10)        
exec (@ssql)       
      
        
----/*Code added by 13705 for component split migration -starts */          
select @ssql = ''          
select @ssql = @ssql + '  insert  into  es_comp_ctrl_type_mst_extn( ' + char(10)              
select @ssql = @ssql +'customer_name     ,project_name  ,req_no    ,process_name   ,component_name' +char(10)         
select @ssql = @ssql +',ctrl_type_name     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp' +char(10)         
select @ssql = @ssql +',createdby      ,createddate   ,modifiedby   ,modifieddate   ,SliderType' +char(10)         
select @ssql = @ssql +',SliderBehaviour     ,RenderType    ,Orientation  ,Startvalue    ,Endvalue' +char(10)         
select @ssql = @ssql +',Minvalue      ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue' +char(10)         
select @ssql = @ssql +',ShowTooltip      ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect' +char(10)         
select @ssql = @ssql +',ValueShown      ,ExpandEvent   ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent' +char(10)         
select @ssql = @ssql +',ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom' +char(10)         
select @ssql = @ssql +',ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart' +char(10)         
select @ssql = @ssql +',checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask' +char(10)         
select @ssql = @ssql +',preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine' +char(10)         
select @ssql = @ssql +',FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment' +char(10)         
select @ssql = @ssql +',Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount' +char(10)         
select @ssql = @ssql +',NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd' +char(10)         
select @ssql = @ssql +',NodeCustomClass     ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl' +char(10)         
select @ssql = @ssql +',Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence' +char(10)         
select @ssql = @ssql +',LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander' +char(10)         
select @ssql = @ssql +',ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop' +char(10)         
select @ssql = @ssql +',LockedGridWidth     ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField' +char(10)         
select @ssql = @ssql +',RightLabelField     ,RollupLabelField  ,Baseline   ,ScrollToDateCentered ,Zoom       ' +char(10)         
select @ssql = @ssql +',Fit        ,Export     ,Highlight   ,Indent     ,ContextMenu' +char(10)         
select @ssql = @ssql +',PopupTaskEditor     ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete' +char(10)         
select @ssql = @ssql +',Calendar      ,IsScheduler,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded ,' +char(10) -- added by S.Srikanth for TECH-47407  
select @ssql = @ssql +'IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem)' +char(10)  -- added by S.Srikanth for TECH-47407  
  
                
        
        
select @ssql = @ssql + 'select  distinct '+char(10)        
select @ssql = @ssql +'dst_customer_name    ,dst_project_name  ,''base''   ,dst_process_name  ,dst_component_name'   + char(10)            
select @ssql = @ssql + ',ctrl_type_name     ,ctrl_type_descr  ,base_ctrl_type  ,Configuration   ,timestamp'   + char(10)               
select @ssql = @ssql +','''+@user+'''     ,'''+@time+'''   ,'''+@user+'''  ,'''+@time+'''   ,SliderType'   + char(10)          
select @ssql = @ssql +',SliderBehaviour     ,RenderType    ,Orientation  ,Startvalue    ,Endvalue' +char(10)         
select @ssql = @ssql +',Minvalue  ,Maxvalue    ,Stepvalue   ,SliderValue   ,Showvalue' +char(10)         
select @ssql = @ssql +',ShowTooltip      ,Rangelabel    ,Rangevalue   ,Rangetooltip   ,RangeSelect' +char(10)         
select @ssql = @ssql +',ValueShown      ,ExpandEvent   ,ExpandAllEvent  ,CollapseEvent   ,CollapseAllEvent' +char(10)         
select @ssql = @ssql +',ClickEvent      ,DDToolTip    ,ZoomMin   ,ZoomMax    ,DefaultZoom' +char(10)         
select @ssql = @ssql +',ZoomStep      ,NodeWidth    ,NodeHeight   ,DefaultFile   ,IsOrgChart' +char(10)         
select @ssql = @ssql +',checkevent      ,bufferedrows   ,SparkChartType  ,ChartType    ,Delayedpwdmask' +char(10)         
select @ssql = @ssql +',preserve_gridposition   ,Dynamicfileupload  ,ServerSidePrint ,MultiFileSelect  ,NoofCtrlPerLine' +char(10)         
select @ssql = @ssql +',FormWidth      ,ControlWidth   ,LabelWidth   ,MetaDataBasedLink  ,LabelAlignment' +char(10)         
select @ssql = @ssql +',Scan       ,Autoselect    ,IsList    ,MultiSelect   ,SelectedRowcount' +char(10)         
select @ssql = @ssql +',NFCEnabled      ,AutoScan    ,IsToggle   ,NodeIconReqd' +char(10)         
select @ssql = @ssql +',NodeCustomClass     ,IsDocked    ,RuleBuilder  ,MultiSelectComboforRB ,CalendarControl' +char(10)         
select @ssql = @ssql +',Setfocusevent     ,Leavefocusevent  ,GanttControl  ,AutoSync    ,SetFocusEventOccurence' +char(10)         
select @ssql = @ssql +',LeaveFocusEventOccurence  ,IsChips    ,IsSpellcheck  ,DirectPrint   ,ListItemExpander' +char(10)         
select @ssql = @ssql +',ReadOnly      ,ShowTodayLine   ,ShowRollupTasks ,ShowProjectLines  ,SkipWeekendsDuringDragDrop' +char(10)         
select @ssql = @ssql +',LockedGridWidth     ,RowHeight    ,BottomLabelField ,TopLabelField   ,LeftLabelField' +char(10)         
select @ssql = @ssql +',RightLabelField     ,RollupLabelField  ,Baseline   ,ScrollToDateCentered ,Zoom       ' +char(10)         
select @ssql = @ssql +',Fit        ,Export     ,Highlight   ,Indent     ,ContextMenu' +char(10)         
select @ssql = @ssql +',PopupTaskEditor     ,GanttShift    ,GanttExpand  ,GanttInsert   ,GanttDelete' +char(10)         
select @ssql = @ssql +',Calendar      ,IsScheduler,ListItemType ,IsSelectionReqdList , RowAlwaysExpanded ,' +char(10)  -- added by S.Srikanth for TECH-47407  
select @ssql = @ssql +'IsMobile,PaginationReqd , UpdateTaskReqd ,DeleteTaskReqd ,DockedItem' +char(10) -- added by S.Srikanth for TECH-47407  
      
        
select @ssql = @ssql + 'from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_ctrl_type_mst_extn  a ,'   + char(10)            
select @ssql = @ssql + 'engg_mr_ui_mst_203_1 b (nolock)'    + char(10)              
select @ssql = @ssql + '  where  a.customer_name  = ''' + @customername + ''''  + char(10)              
select @ssql = @ssql + '  and    a.project_name   = ''' + @projectname + ''''  + char(10)              
select @ssql = @ssql + '  and    a.process_name   = ''' +@processname+''''   + char(10)              
select @ssql = @ssql + '  and    a.component_name = ''' +@componentname+''''   + char(10)              
select @ssql = @ssql + '  and    a.customer_name  = b.src_customer_name '   + char(10)              
select @ssql = @ssql + '  and    a.project_name   = b.src_project_name '    + char(10)              
select @ssql = @ssql + '  and    a.process_name   = b.src_process_name '    + char(10)              
select @ssql = @ssql + '  and    a.component_name = b.src_component_name '   + char(10)              
select @ssql = @ssql + '  and  b.act_mig_flag  = 1'       + char(10)              
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)              
select @ssql = @ssql + '  and    not exists ( '     + char(10)              
select @ssql = @ssql + '            select  ''x'' ' + char(10)              
select @ssql = @ssql + '            from  es_comp_ctrl_type_mst_extn c (nolock)'    + char(10)              
select @ssql = @ssql + '            where   c.customer_name   = dst_customer_name  '  + char(10)              
select @ssql = @ssql + '            and    c.project_name   = dst_project_name  '  + char(10)              
select @ssql = @ssql + '            and    c.req_no      = ''base''    '   + char(10)              
select @ssql = @ssql + '            and    c.process_name   = dst_process_name '  + char(10)              
select @ssql = @ssql + '            and    c.component_name  = dst_component_name '  + char(10)              
select @ssql = @ssql + '            and    c.ctrl_type_name  = a.ctrl_type_name) '  + char(10)              
exec (@ssql)            
        
--/*Code added for component split migration -ends */          
    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_comp_task_type_mst(' + char(10)    
select @ssql = @ssql + '      customer_name,    project_name,      req_no,       process_name,'   + char(10)    
select @ssql = @ssql + '      component_name,    task_type_name,      task_type_descr,   default_for,'   + char(10)    
select @ssql = @ssql + '      refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,' + char(10)    
select @ssql = @ssql + '      cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,'   + char(10)    
select @ssql = @ssql + '      hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,'   + char(10)    
select @ssql = @ssql + '      trn_scope_req,    comp_task_type_sysid,   timestamp,      createdby,'   + char(10)    
select @ssql = @ssql + '      createddate,     modifiedby,       modifieddate,    task_type_doc,'  + char(10)    
select @ssql = @ssql + '      hdr_save_req,     ml_save_req,      fprowno_req,     cbdef_req,'   + char(10)    
select @ssql = @ssql + '      no_placeholder,    data_save_req,      print_req,      task_confirmation,' + char(10)    
--select @ssql = @ssql + '      Logic_Extensions,  process_updrows )'  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/  --code commented for the bugid:PNR2.0_35203    
select @ssql = @ssql + '      Logic_Extensions,  process_updrows,  alternate_db )'  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + '  select  distinct dst_customer_name, dst_project_name,   ''base'',       dst_process_name,'  + char(10)    
select @ssql = @ssql + '      dst_component_name,  task_type_name,      task_type_descr,   default_for,'   + char(10)    
select @ssql = @ssql + '      refresh_on_save,   valid_on_init,      err_handle_method,  incl_place_holder,' + char(10)    
select @ssql = @ssql + '      cond_ml_fetch,    clr_on_page_save,    hdr_fetch_req,    ml_fet_req,'   + char(10)    
select @ssql = @ssql + '      hdr_ref_req,     hdr_check_req,      proc_sel_rows,    usr_role_map,'   + char(10)    
select @ssql = @ssql + '      trn_scope_req,    left(left(component_name,10)+req_no+task_type_name+task_type_descr,40),timestamp,'''+@user+''',' + char(10)    
select @ssql = @ssql + '      '''+@time+''',      '''+@user+''',       '''+@time+''',      task_type_doc,'  + char(10)    
select @ssql = @ssql + '      hdr_save_req,     ml_save_req,      fprowno_req,   cbdef_req,'   + char(10)    
select @ssql = @ssql + '      no_placeholder,    data_save_req,      print_req,      task_confirmation,'  + char(10)    
--select @ssql = @ssql + '      Logic_Extensions,  process_updrows '  + char(10) /*Code modified by Gankan.G for bug_id:PNR2.0_28990 on 30-Nov-2010*/  --code commented for the bugid:PNR2.0_35203    
select @ssql = @ssql + '      Logic_Extensions,  process_updrows,  alternate_db '  + char(10) --code added for the bugid:PNR2.0_35203    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_task_type_mst  a ,'   + char(10)    
select @ssql = @ssql + '      engg_mr_ui_mst_203_1 b (nolock)'    + char(10)    
select @ssql = @ssql + '  where  a.customer_name    = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + '  and    a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + '  and    a.process_name    = ''' +@processname+''''   + char(10)    
select @ssql = @ssql + '  and    a.component_name   = ''' +@componentname+''''   + char(10)    
select @ssql = @ssql + '  and    a.customer_name    = b.src_customer_name'    + char(10)    
select @ssql = @ssql + '  and    a.project_name    = b.src_project_name   '   + char(10)    
select @ssql = @ssql + '  and    a.process_name    = b.src_process_name'    + char(10)    
select @ssql = @ssql + '  and    a.component_name   = b.src_component_name'   + char(10)    
select @ssql = @ssql + '  and  b.act_mig_flag = 1'       + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
select @ssql = @ssql + '  and    not exists ('     + char(10)    
select @ssql = @ssql + '            select  ''x'''  + char(10)    
select @ssql = @ssql + '            from   es_comp_task_type_mst c (nolock)'    + char(10)    
select @ssql = @ssql + '            where   c.customer_name   = dst_customer_name'  + char(10)    
select @ssql = @ssql + '            and    c.project_name   = dst_project_name'  + char(10)    
select @ssql = @ssql + '            and    c.req_no      = ''base'''    + char(10)    
select @ssql = @ssql + '            and    c.process_name   = dst_process_name'  + char(10)    
select @ssql = @ssql + '            and    c.component_name  = dst_component_name'  + char(10)    
select @ssql = @ssql + '            and    c.task_type_name  = a.task_type_name)'  + char(10)    
exec (@ssql)    
    
End    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_comp_hdn_ctrl_dtl( ' + char(10)    
select @ssql = @ssql + '      customer_name,    project_name,      req_no,    '   + char(10)    
select @ssql = @ssql + '      process_name,     component_name,      bt_synonym_name, '  + char(10)    
select @ssql = @ssql + '      allow_deletion,    comp_hdn_ctrl_sysid,   timestamp,   '   + char(10)    
select @ssql = @ssql + '      createdby,      createddate,      modifiedby,   '  + char(10)    
select @ssql = @ssql + '      modifieddate) '    + char(10)    
select @ssql = @ssql + '  select  distinct dst_customer_name, dst_project_name,   ''base'',    '   + char(10)    
select @ssql = @ssql + '      dst_process_name,   dst_component_name,    bt_synonym_name, '  + char(10)    
select @ssql = @ssql + '      allow_deletion,    left(left(dst_component_name,10)+bt_synonym_name+req_no,40),         timestamp,   '   + char(10)    
select @ssql = @ssql + '      '''+@user+''',      '''+@time+''',       '''+@user+''',    ' + char(10)    
select @ssql = @ssql + '      '''+@time+''''     + char(10)    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_hdn_ctrl_dtl  a ,     ' + char(10)    
select @ssql = @ssql + '     engg_mr_ui_mst_203_1 b (nolock)'  + char(10)    
select @ssql = @ssql + '  where  a.customer_name    = '''+@customername+''''  + char(10)    
select @ssql = @ssql + '  and    a.project_name   = '''+@projectname+''''  + char(10)    
select @ssql = @ssql + '  and    a.process_name    = '''+@processname+''''  + char(10)    
select @ssql = @ssql + '  and    a.component_name   = '''+@componentname+''''  + char(10)    
select @ssql = @ssql + '  and    a.customer_name    = b.src_customer_name'   + char(10)    
select @ssql = @ssql + '  and    a.project_name    = b.src_project_name '   + char(10)    
select @ssql = @ssql + '  and    a.process_name    = b.src_process_name'   + char(10)    
select @ssql = @ssql + '  and    a.component_name   = b.src_component_name'  + char(10)    
select @ssql = @ssql + '  and  b.act_mig_flag = 1'      + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
select @ssql = @ssql + '  and    not exists ( '     + char(10)    
select @ssql = @ssql + '            select  ''x'' ' + char(10)    
select @ssql = @ssql + '            from  es_comp_hdn_ctrl_dtl c (nolock)'     + char(10)    
select @ssql = @ssql + '            where c.customer_name  = dst_customer_name'  + char(10)    
select @ssql = @ssql + '            and    c.project_name   = dst_project_name'  + char(10)    
select @ssql = @ssql + '            and    c.req_no      = ''base'''    + char(10)    
select @ssql = @ssql + '            and    c.process_name   = dst_process_name'  + char(10)    
select @ssql = @ssql + '            and    c.component_name  = dst_component_name'  + char(10)    
select @ssql = @ssql + '            and    c.bt_synonym_name  = a.bt_synonym_name)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_comp_param_mst( ' + char(10)    
select @ssql = @ssql + '      customer_name,    project_name,      req_no,'    + char(10)    
select @ssql = @ssql + '      process_name,     component_name,      param_category,'  + char(10)    
select @ssql = @ssql + '      param_text,      param_type,       comp_param_sysid,'  + char(10)    
select @ssql = @ssql + '      timestamp,      createdby,        createddate,'   + char(10)    
select @ssql = @ssql + '      modifiedby,      modifieddate,      default_value,'  + char(10)    
select @ssql = @ssql + '      current_value,    res_naming_convention,  param_doc)'   + char(10)    
select @ssql = @ssql + '  select  distinct dst_customer_name, dst_project_name,   ''base'', '   + char(10)    
select @ssql = @ssql + '      dst_process_name,   dst_component_name,    param_category,'  + char(10)    
select @ssql = @ssql + '      param_text,      param_type,       left(req_no+param_category+component_name,40),'+ char(10)    
select @ssql = @ssql + '      timestamp,      '''+@user+''',       '''+@time+''','  + char(10)    
select @ssql = @ssql + '      '''+@user+''',      '''+@time+''',       default_value,'  + char(10)    
select @ssql = @ssql + '      current_value,    res_naming_convention,  param_doc'    + char(10)    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_param_mst  a ,' + char(10)    
select @ssql = @ssql + '      engg_mr_ui_mst_203_1 b (nolock) '    + char(10)    
select @ssql = @ssql + '  where  a.customer_name  = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + '  and    a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + '  and    a.process_name    = ''' +@processname+''''   + char(10)    
select @ssql = @ssql + '  and    a.component_name   = ''' +@componentname+''''   + char(10)    
select @ssql = @ssql + '  and    a.customer_name    = b.src_customer_name'    + char(10)    
select @ssql = @ssql + '  and    a.project_name    = b.src_project_name '    + char(10)    
select @ssql = @ssql + '  and    a.process_name    = b.src_process_name'    + char(10)    
select @ssql = @ssql + '  and    a.component_name   = b.src_component_name'   + char(10)    
select @ssql = @ssql + '  and  b.act_mig_flag = 1'       + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
select @ssql = @ssql + '  and    not exists (' + char(10)    
select @ssql = @ssql + '            select  ''x''      '        + char(10)    
select @ssql = @ssql + '            from  es_comp_param_mst c (nolock)'    + char(10)    
select @ssql = @ssql + '            where  c.customer_name = dst_customer_name'  + char(10)    
select @ssql = @ssql + '            and  c.project_name  = dst_project_name'  + char(10)    
select @ssql = @ssql + '            and    c.req_no     = ''base'''    + char(10)    
select @ssql = @ssql + '            and    c.process_name  = dst_process_name'  + char(10)    
select @ssql = @ssql + '            and    c.component_name= dst_component_name'  + char(10)    
select @ssql = @ssql + '            and    c.param_category= a.param_category)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + '  insert  into  es_comp_stylesheet( '  + char(10)    
select @ssql = @ssql + '     customer_name,    project_name,      req_no,'    + char(10)    
select @ssql = @ssql + '     process_name,     component_name, stylesheet_name,'  + char(10)    
select @ssql = @ssql + '     stylesheet_descr,   comp_stylesheet_sysid,  timestamp,'   + char(10)    
select @ssql = @ssql + '     createdby,      createddate,      modifiedby,'   + char(10)    
select @ssql = @ssql + '     modifieddate)'      + char(10)    
select @ssql = @ssql + '  select distinct dst_customer_name,  dst_project_name,  ''base'', '   + char(10)    
select @ssql = @ssql + '     dst_process_name,   dst_component_name,    stylesheet_name,'  + char(10)    
select @ssql = @ssql + '     stylesheet_descr,    left(left(component_name,10)+stylesheet_name+stylesheet_descr,40),        timestamp,'   + char(10)    
select @ssql = @ssql + '     '''+@user+''',      '''+@time+''',       '''+@user+''','  + char(10)    
select @ssql = @ssql + '     '''+@time+''''      + char(10)    
select @ssql = @ssql + '  from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_comp_stylesheet  a ,' + char(10)    
select @ssql = @ssql + '      engg_mr_ui_mst_203_1 b (nolock)'    + char(10)    
select @ssql = @ssql + '  where  a.customer_name    = ''' + @customername + ''''  + char(10)    
select @ssql = @ssql + '  and    a.project_name    = ''' + @projectname + ''''  + char(10)    
select @ssql = @ssql + '  and    a.process_name    = ''' +@processname+''''   + char(10)    
select @ssql = @ssql + '  and    a.component_name   = ''' +@componentname+''''   + char(10)    
select @ssql = @ssql + '  and    a.customer_name    = b.src_customer_name'    + char(10)    
select @ssql = @ssql + '  and    a.project_name    = b.src_project_name   '   + char(10)    
select @ssql = @ssql + '  and    a.process_name    = b.src_process_name'    + char(10)    
select @ssql = @ssql + '  and    a.component_name   = b.src_component_name'   + char(10)    
select @ssql = @ssql + '  and  b.act_mig_flag = 1'       + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
select @ssql = @ssql + '  and    not exists ('     + char(10)    
select @ssql = @ssql + '            select  ''x''' + char(10)    
select @ssql = @ssql + '            from   es_comp_stylesheet c (nolock)'     + char(10)    
select @ssql = @ssql + '            where   c.customer_name   = dst_customer_name'  + char(10)    
select @ssql = @ssql + '             and    c.project_name   = dst_project_name'  + char(10)    
select @ssql = @ssql + '            and    c.req_no     = ''base'''    + char(10)    
select @ssql = @ssql + '            and    c.process_name   = dst_process_name'  + char(10)    
select @ssql = @ssql + '            and    c.component_name  = dst_component_name'  + char(10)    
select @ssql = @ssql + '            and    c.stylesheet_name  = a.stylesheet_name)'  + char(10)    
exec (@ssql)    
    
select @ssql = ''    
select @ssql = @ssql + ' insert into es_fun_comp_map( '+ char(10)    
select @ssql = @ssql + '   customer_name,   project_name,   process_name,   process_descr,'+ char(10)    
select @ssql = @ssql + '   function_name,   function_descr,   component_name,   component_descr,'+ char(10)    
select @ssql = @ssql + '   timestamp,    createdby,    createddate,   modifiedby,'+ char(10)    
select @ssql = @ssql + '   modifieddate )'+ char(10)    
select @ssql = @ssql + ' select distinct dst_customer_name, dst_project_name, dst_process_name,  dst_process_description,'+ char(10)    
select @ssql = @ssql + '   dst_functionid,   dst_functionname,  dst_component_name,  dst_component_descr,'+ char(10)    
select @ssql = @ssql + '   timestamp,    '''+@user+''',   '''+@time+''',   '''+@user+''','+ char(10)    
select @ssql = @ssql + '   '''+@time+'''                  '+ char(10)    
select @ssql = @ssql + ' from ['+@link_server+'].['+@link_db+'].['+@link_user+'].es_fun_comp_map  a ,'   + char(10)    
select @ssql = @ssql + '     engg_mr_ui_mst_203_1 b (nolock)'     + char(10)    
select @ssql = @ssql + ' where  a.customer_name    = ''' + @customername + ''''   + char(10)    
select @ssql = @ssql + ' and   a.project_name   = ''' + @projectname + ''''   + char(10)    
select @ssql = @ssql + ' and   a.process_name   = ''' +@processname+''''   + char(10)    
select @ssql = @ssql + ' and   a.component_name = ''' +@componentname+''''   + char(10)    
select @ssql = @ssql + ' and  a.customer_name  = b.src_customer_name '   + char(10)    
select @ssql = @ssql + ' and   a.project_name   = b.src_project_name '    + char(10)    
select @ssql = @ssql + ' and   a.process_name   = b.src_process_name '    + char(10)    
select @ssql = @ssql + ' and   a.component_name = b.src_component_name '   + char(10)    
select @ssql = @ssql + ' and b.act_mig_flag = 1'       + char(10)    
select @ssql = @ssql + '  and  b.mig_id   = '''+@mig_id+''''      + char(10)    
select @ssql = @ssql + ' and not exists( select ''x'''  + char(10)    
select @ssql = @ssql + '           from es_fun_comp_map  c(nolock) '  + char(10)    
select @ssql = @ssql + '           where   c.customer_name   = dst_customer_name'  + char(10)    
select @ssql = @ssql + '           and    c.project_name   = dst_project_name'  + char(10)    
select @ssql = @ssql + '           and    c.process_name   = dst_process_name'  + char(10)    
select @ssql = @ssql + '           and    c.component_name  = dst_component_name )' + char(10)    
exec(@ssql)    
    
set nocount off    
    
end    
GO   
    
    
    
    
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'engg_mr_setup_population_sol_203_2_2' AND TYPE = 'P')  
BEGIN  
 GRANT EXEC ON engg_mr_setup_population_sol_203_2_2 TO PUBLIC  
END 
GO