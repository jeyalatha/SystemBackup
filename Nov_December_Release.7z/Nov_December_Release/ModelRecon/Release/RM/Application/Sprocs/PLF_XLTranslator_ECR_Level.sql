IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='PLF_XLTranslator_ECR_Level' AND TYPE='P')
   BEGIN
        DROP PROC PLF_XLTranslator_ECR_Level
   END
GO 
/******************************************************************************/
/* Procedure					: PLF_XLTranslator_ECR_Level				  */
/* Description					: 											  */
/******************************************************************************/
/* Modified by : Manoj S													  */
/* Modified on : 22-11-2022				 									  */
/* Defect	Id : TECH-74842													  */ 
/******************************************************************************/
CREATE PROCEDURE PLF_XLTranslator_ECR_Level  
 @customer_name    engg_name,    
 @project_name    engg_name,    
 @process_name    engg_name,    
 @component_name    engg_name,    
 @ecrno      engg_name,    
 @target_language_id   engg_name    
    
AS    
BEGIN    
 SET NOCOUNT ON    
    
  if not exists ( select 'x' from de_published_ui (nolock)    
      where customer_name   = @customer_name    
      and  project_name   = @project_name    
      and  process_name   = @process_name    
      and  component_name   = @component_name    
      and  ecrno     = @ecrno)    
    
  begin     
   raiserror ('Provided ECR got purged , Data not available for this ECR !!!',16,1)    
   return    
  end    
    
  --if not exists ( select 'x' from de_published_glossary_lng_extn (nolock)    
  --    where customer_name  = @customer_name    
  --    and  project_name  = @project_name    
  --    and  process_name  = @process_name    
  --    and  component_name  = @component_name    
  --    and  ecrno    = @ecrno    
  --    and  languageid   = @target_language_id)    
    
  --begin     
  -- raiserror ('Provided Target language id is Not available in this ECR. ',16,1)    
  -- return    
  --end    
    
  Declare @de_glossary_lng_extn Table     
   (customer_name VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),    
    component_name VARCHAR(60),bt_synonym_name VARCHAR(64),bt_synonym_caption Nvarchar(max),data_type VARCHAR(60),length int,ecrno VARCHAR(60),    
    singleinst_sample_data Nvarchar(255),multiinst_sample_data Nvarchar(255), bt_name VARCHAR(60),languageid int     
    PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name,ecrno,languageid))    
    
 Declare @de_glossary Table     
 (customer_name VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),    
 component_name VARCHAR(60),bt_synonym_name VARCHAR(64),bt_synonym_caption Nvarchar(255),data_type VARCHAR(60),length int,ecrno VARCHAR(60),    
 singleinst_sample_data Nvarchar(255),multiinst_sample_data Nvarchar(255), bt_name VARCHAR(60)    
 PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name,ecrno))    
    
    
insert into @de_glossary (customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,data_type,length,ecrno,singleinst_sample_data,multiinst_sample_data,bt_name)    
select distinct a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,a.bt_synonym_caption,a.data_type,a.length,@ecrno,singleinst_sample_data,multiinst_sample_data,bt_name    
from de_glossary a (nolock)    
where a.customer_name  = @customer_name    
and  a.project_name  = @project_name    
and  a.process_name  = @process_name    
and  a.component_name = @component_name    
    
insert into @de_glossary_lng_extn(customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)    
select distinct a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,    
(case when isnull(b.Targetcaption,'')='' then a.bt_synonym_caption  else b.Targetcaption  end ) ,    
a.data_type,a.length,@ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,c.quick_code     
from @de_glossary a  left join     
  PLF_XLTranslated_Meta_Master b (nolock)    
      
on  a.customer_name  = b.customer_name    
and  a.project_name  = b.project_name    
and  a.bt_synonym_caption= b.Sourcecaption    
and     a.customer_name  = @customer_name    
and  a.project_name  = @project_name    
and  a.process_name  = @process_name    
and  a.component_name = @component_name    
join ep_language_met c(nolock)    
on      b.Targetlanguageid  =   c.quick_code    
and  c.quick_code  = @target_language_id    
    
insert into @de_glossary_lng_extn(customer_name,project_name,process_name,component_name,bt_synonym_name,    
bt_synonym_caption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)    
select customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,    
data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,'1'    
from   @de_glossary    
    
    
  Update b    
  set  b.bt_synonym_caption = a.bt_synonym_caption,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_glossary_lng_extn a,    
    de_published_glossary_lng_extn  b(nolock)    
  where a.customer_name   = @customer_name    
  and  a.project_name   = @project_name    
  and  a.process_name   = @process_name    
  and  a.component_name  = @component_name    
  and  b.ecrno     = @ecrno    
  and  a.languageid    = @target_language_id     
  and  a.customer_name   = b.customer_name    
  and  a.project_name   = b.project_name    
  and  a.process_name   = b.process_name    
  and  a.component_name  = b.component_name    
  and  a.bt_synonym_name  = b.bt_synonym_name    
  and  a.languageid   = b.languageid    
    
  Update b    
  set  b.task_confirm_msg = a.task_confirm_msg,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_action_lng_extn a,    
    de_published_action_lng_extn  b(nolock)    
  where a.customer_name   = @customer_name    
  and  a.project_name   = @project_name    
  and  a.process_name   = @process_name    
  and  a.component_name  = @component_name    
  and  b.ecrno     = @ecrno    
  and  a.languageid    = @target_language_id     
  and  a.customer_name   = b.customer_name    
  and  a.project_name   = b.project_name    
  and  a.process_name   = b.process_name    
  and  a.component_name  = b.component_name    
  and  a.activity_name   = b.activity_name    
  and  a.ui_name    = b.ui_name    
  and  a.page_bt_synonym  = b.page_bt_synonym    
  and  a.task_name    = b.task_name    
  and  a.languageid   = b.languageid    
    
  Update b    
  set  b.enum_caption = a.enum_caption,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_enum_value_lng_extn a,    
    de_published_enum_value_lng_extn  b(nolock)    
  where b.customer_name   = @customer_name    
  and  b.project_name   = @project_name    
  and  b.process_name   = @process_name    
  and  b.component_name  = @component_name    
  and  b.ecrno     = @ecrno    
  and  b.languageid    = @target_language_id     
  and  a.customer_name   = b.customer_name    
  and  a.project_name   = b.project_name    
  and  a.process_name   = b.process_name    
  and  a.component_name  = b.component_name    
  and  a.activity_name   = b.activity_name      
  and  a.ui_name    = b.ui_name      
  and  a.page_bt_synonym  = b.page_bt_synonym      
  and  a.section_bt_synonym = b.section_bt_synonym      
  and  a.control_bt_synonym = b.control_bt_synonym      
  and  a.enum_code    = b.enum_code     
  and  a.languageid   = b.languageid    
      
  Update b    
  set  b.errormessage = a.errormessage,b.detaileddesc = a.detaileddesc,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_fw_des_err_det_local_info a,    
    de_fw_des_publish_err_det_local_info  b(nolock)    
  where b.customername   = @customer_name    
  and  b.projectname   = @project_name    
  and  b.processname   = @process_name    
  and  b.componentname   = @component_name    
  and  b.ecrno     = @ecrno    
  and  b.langid     = @target_language_id     
  and  a.customer_name   = b.customername    
  and  a.project_name   = b.projectname    
  and  a.process_name   = b.processname    
  and  a.component_name  = b.componentname    
  and  a.errorid    = b.errorid    
  and  a.langid    = b.langid    
      
  Update b    
  set  b.button_caption = a.button_caption,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_radio_button_lng_extn a,    
    de_published_radio_button_lng_extn  b(nolock)    
  where b.customer_name   = @customer_name    
  and  b.project_name   = @project_name    
  and  b.process_name   = @process_name    
  and  b.component_name  = @component_name    
  and  b.ecrno     = @ecrno    
  and  b.languageid    = @target_language_id     
  and  a.customer_name   = b.customer_name    
  and  a.project_name   = b.project_name    
  and  a.process_name   = b.process_name    
  and  a.component_name  = b.component_name    
  and  a.activity_name   = b.activity_name      
  and  a.ui_name    = b.ui_name      
  and  a.page_bt_synonym  = b.page_bt_synonym      
  and  a.section_bt_synonym = b.section_bt_synonym      
  and  a.control_bt_synonym = b.control_bt_synonym      
  and  a.button_code   = b.button_code     
  and  a.languageid   = b.languageid    
    
/*      
insert de_published_glossary_lng_extn(bt_name,bt_synonym_caption,bt_synonym_doc,bt_synonym_name,component_name,createdby,createddate,customer_name,data_type,ecrno,glossary_sysid,languageid,length,modifiedby,modifieddate,multiinst_sample_data,process_name,
  
  
    
    
project_name,ref_bt_synonym_name,singleinst_sample_data,synonym_status,timestamp,req_no)    
select bt_name,bt_synonym_caption,bt_synonym_doc,bt_synonym_name,component_name,'tesuser',getdate(),customer_name,data_type,@ecrno,glossary_sysid,languageid,length,'tesuser',getdate(),multiinst_sample_data,process_name,project_name,ref_bt_synonym_name,sin
  
  
    
    
gleinst_sample_data,synonym_status,timestamp,''    
from de_glossary_lng_extn a (nolock)    
where customer_name  = @customer_name     
and project_name   = @project_name    
and process_name   = @process_name    
and component_name   = @component_name    
and languageid          = @target_language_id      
and not exists  (select 'K'    
       from de_published_glossary_lng_extn b     
       where a.customer_name   = b.customer_name    
       and    a.project_name  = b.project_name    
       and  a.process_name  = b.process_name    
       and a.component_name   = b.component_name    
       and a.bt_synonym_name  = b.bt_synonym_name    
       and a.languageid   = b.languageid    
       and b.ecrno     = @ecrno )  ;     
    
*/    
    
--declare  @de_fw_req_publish_lang_bterm_synonym table    
--(customer_name       VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),    
--                     component_name VARCHAR(60),btsynonym VARCHAR(64),ecrno VARCHAR(60),langid int    
--PRIMARY KEY (customer_name,project_name,process_name,component_name,btsynonym,langid,ecrno))    
    
--insert into @de_fw_req_publish_lang_bterm_synonym(customer_name,project_name,process_name,component_name,btsynonym,langid,ecrno)    
--select customername,projectname,processname,componentname,btsynonym,langid,@ecrno    
--from de_fw_req_publish_lang_bterm_synonym (nolock)    
--where ecrno  = @ecrno    
--and  customername  = @customer_name        
--and     projectname  = @project_name        
--and  processname  =  @process_name        
--and  componentname  = @component_name        
    
declare  @de_fw_req_publish_bterm_synonym table    
(customer_name       VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),    
                     component_name VARCHAR(60),btsynonym VARCHAR(64),ecrno VARCHAR(60)    
PRIMARY KEY (customer_name,project_name,process_name,component_name,btsynonym,ecrno))    
    
insert into @de_fw_req_publish_bterm_synonym(customer_name,project_name,process_name,component_name,btsynonym,ecrno)    
select customername,projectname,processname,componentname,btsynonym,@ecrno    
from de_fw_req_publish_bterm_synonym (nolock)    
where ecrno    = @ecrno  
and  customername  = @customer_name        
and     projectname  = @project_name        
and  processname  =  @process_name        
and  componentname  = @component_name        
  
    
insert into de_fw_req_publish_lang_bterm_synonym        
(btsynonym,   langid,    foreignname,  longpltext,        
shortpltext,  shortdesc,   longdesc,   upduser,        
updtime,   customername,  projectname,  timestamp,        
createdby,   createddate,  processname,  componentname,ecrno)        
select  distinct        
bt_synonym_name, languageid,   bt_synonym_name, bt_synonym_caption,        
bt_synonym_caption, bt_synonym_caption, bt_synonym_caption, 'XL_Translator',        
getdate(),   customer_name,  project_name,  1,       
'XL_Translator',   getdate(),   process_name,  component_name, @ecrno        
from @de_glossary_lng_extn     a    
where a.customer_name  = @customer_name        
and     a.project_name  = @project_name        
and  a.process_name  =  @process_name        
and  a.component_name  = @component_name        
and  isnull(bt_name,'') <> ''        
-- code modified For BugId : PNR2.0_7453        
and  bt_synonym_name not in ('modeflag')        
and  len(bt_synonym_name) < 31        
and  len(bt_synonym_caption) < 61 -- Code modified by Gowrisankar M for PNR2.0_16448 on 10-Jan-2008        
--Code Added by Sangeetha L fro BugID:pnr2.0_5489        
and   customer_name+project_name+process_name+component_name+bt_synonym_name        
in (select customer_name+project_name+process_name+component_name+btsynonym        
from  @de_fw_req_publish_bterm_synonym    
where customer_name  = @customer_name        
and     project_name  = @project_name        
and  process_name  =  @process_name        
and  component_name  = @component_name    
and  ecrno = @ecrno)        
--Code Added by Sangeetha L fro BugID:pnr2.0_5489        
--chan        
and   not exists  (select 'X'        
from  de_fw_req_publish_lang_bterm_synonym  c  
where a.customer_name  = c.customername      
and     a.project_name  = c.projectname      
and  a.process_name  = c.processname      
and  a.component_name = c.componentname  
and  a.ecrno = c.ecrno    
and  a.bt_synonym_name =c.btsynonym  
and  a.languageid  =c.langid  
)        
  
  
  Declare @de_published_action_lng_extn Table   
  (customer_name VARCHAR(60), project_name VARCHAR(60), process_name VARCHAR(60),   
  component_name VARCHAR(60), activity_name VARCHAR(60), ui_name VARCHAR(60),   
  page_bt_synonym VARCHAR(60), task_name VARCHAR(60), languageid int,task_descr nvarchar(510),  
  task_seq varchar(60),task_pattern varchar(60),timestamp int,createdby varchar(60),createddate datetime,modifiedby varchar(60),  
  modifieddate datetime,primary_control_bts varchar(60),task_sysid varchar(60),ui_sysid varchar(60),task_type varchar(60),  
  task_confirm_msg varchar(510),task_status_msg varchar(510),usageid varchar(60),ddt_page_bt_synonym varchar(60),  
  ddt_control_bt_synonym varchar(60),ddt_control_id varchar(60),ddt_view_name varchar(60),task_process_msg varchar(510),  
  PopUp_page_bt_synonym varchar(60),PopUp_section varchar(60),PopUp_close varchar(60),IsCallout varchar(60),QR_sourceCtrl varchar(60),  
  QR_targetCtrl varchar(60),Barcode_sourceCtrl varchar(60),Barcode_targetCtrl varchar(60),browse_control varchar(60),  
  QR_sourceCtrl_Page varchar(60),QR_targetCtrl_Page varchar(60),Barcode_sourceCtrl_Page varchar(60),  
  Barcode_targetCtrl_Page varchar(60),browse_control_Page varchar(60),group_name varchar(60),Buttonbar_primary_section varchar(60),  
  Popup_onclick_close varchar(60),Autoupload varchar(60),ecrno varchar(60)  
  PRIMARY KEY (customer_name, project_name,process_name, component_name, activity_name, ui_name,page_bt_synonym, task_name,ecrno,languageid))  
  
  INSERT INTO @de_published_action_lng_extn  
  (customer_name, project_name,process_name, component_name, activity_name, ui_name,  
  page_bt_synonym, task_name,ecrno,languageid,task_descr,task_seq,task_pattern,timestamp,createdby,createddate,modifiedby,modifieddate,  
  primary_control_bts,task_sysid,ui_sysid,task_type,task_confirm_msg,task_status_msg,usageid,  
  ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,  
  PopUp_page_bt_synonym,PopUp_section,PopUp_close,IsCallout,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,  
  Barcode_targetCtrl,browse_control,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,  
  Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload)       
  SELECT   
    a.customer_name,a.project_name,a.process_name,a.component_name,activity_name,ui_name,page_bt_synonym,task_name,latest_pub_ecr_no,languageid,task_descr,  
    task_seq,task_pattern,timestamp,a.createdby,a.createddate,a.modifiedby,a.modifieddate,  
    primary_control_bts,task_sysid,ui_sysid,task_type,task_confirm_msg,task_status_msg,usageid,  
    ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,  
    PopUp_page_bt_synonym,PopUp_section,PopUp_close,IsCallout,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,  
    Barcode_targetCtrl,browse_control,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,  
    Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload  
  FROM de_published_action_lng_extn a WITH(NOLOCK),  
    de_comp_doc_status d (nolock)    
  WHERE a.customer_name  = @customer_name  
  and  a.project_name  = @project_name  
  and  a.activity_name  <> 'IntegrationActivity'  
  and  a.ui_name   <> 'IntegrationUI'  
  and     a.component_name = isnull(@component_name,a.component_name)  
  and  a.languageid in (1,@target_language_id)  
  and  a.customer_name  = d.customer_name  
  and  a.project_name  = d.project_name  
  and  a.process_name  = d.process_name  
  and  a.component_name = d.component_name  
  and  a.ecrno    = d.latest_pub_ecr_no  
  
   
  insert into de_published_action_lng_extn    
  (customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,  
  task_name,task_descr,task_seq,task_pattern,languageid,timestamp,createdby,createddate,modifiedby,modifieddate,  
  primary_control_bts,task_sysid,ui_sysid,task_type,task_confirm_msg,task_status_msg,ecrno,usageid,  
  ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,  
  PopUp_page_bt_synonym,PopUp_section,PopUp_close,IsCallout,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,  
  Barcode_targetCtrl,browse_control,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,  
  Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload  
  )    
  select  distinct    
  @customer_name,@project_name,a.process_name,a.component_name,activity_name,ui_name,page_bt_synonym,  
  task_name,task_descr,task_seq,task_pattern,@target_language_id,timestamp,'XLTRANSLATOR',getdate(),'XLTRANSLATOR',getdate(),  
  primary_control_bts,newid(),newid(),task_type,task_confirm_msg,task_status_msg,ecrno,usageid,  
  ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,  
  PopUp_page_bt_synonym,PopUp_section,PopUp_close,IsCallout,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,  
  Barcode_targetCtrl,browse_control,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,  
  Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload  
  from   @de_published_action_lng_extn a  
  where   a.languageid   = 1  
  and not exists (  select  's'    
  from @de_published_action_lng_extn c   
  where  c.customer_name  = a.customer_name    
  and  c.project_name  = a.project_name    
  and     c.ecrno    = a.ecrno  
  and  c.process_name  = a.process_name    
  and  c.component_name = a.component_name    
  and  c.activity_name  = a.activity_name    
  and  c.ui_name   = a.ui_name    
  and  c.page_bt_synonym = a.page_bt_synonym    
  and  c.task_name   = a.task_name  
  and  c.languageid  = @target_language_id)   
  --TECH-74842 starts
  Update b    
  set  b.componentdesc = a.componentdesc,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_fw_req_component_local_info a,    
    de_fw_req_publish_component_local_info  b(nolock)    
  where a.customer_name   = @customer_name    
  and  a.project_name   = @project_name    
  and  a.process_name   = @process_name    
  and  a.componentname  = @component_name    
  and  b.ecrno     = @ecrno    
  and  a.langid    = @target_language_id     
  and  a.customer_name   = b.customername    
  and  a.project_name   = b.projectname    
  and  a.process_name   = b.processname    
  and  a.componentname  = b.componentname      
  and  a.langid   = b.langid    
  and  a.componentdesc <> b.componentdesc

  Update b    
  set  b.activitydesc = a.activitydesc,b.modifiedby='XLTRANSLATOR',b.modifieddate=getdate()    
  from de_fw_req_activity_local_info a,    
    de_fw_req_publish_activity_local_info  b(nolock)    
  where a.customer_name   = @customer_name    
  and  a.project_name   = @project_name    
  and  a.process_name   = @process_name    
  and  a.component_name  = @component_name    
  and  b.ecrno     = @ecrno    
  and  a.langid    = @target_language_id     
  and  a.customer_name   = b.customername    
  and  a.project_name   = b.projectname    
  and  a.process_name   = b.processname    
  and  a.component_name  = b.componentname      
  and  a.langid   = b.langid    
  and  a.activitydesc <> b.activitydesc

  --TECH-74842 ends


    
SET NOCOUNT OFF    
    
END    
    
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'PLF_XLTranslator_ECR_Level' AND TYPE = 'P')    
BEGIN    
 GRANT EXEC ON PLF_XLTranslator_ECR_Level TO PUBLIC    
END    