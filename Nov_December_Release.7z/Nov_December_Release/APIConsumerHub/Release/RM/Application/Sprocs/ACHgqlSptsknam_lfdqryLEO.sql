IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ACHgqlSptsknam_lfdqryLEO' AND TYPE = 'P')
    Begin
        Drop PROC ACHgqlSptsknam_lfdqryLEO
    End
GO
/********************************************************************************/
/* Procedure                               : ACHgqlSptsknam_lfdqryLEO			*/
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Rajeswari M / Jeya Latha K			*/
/* Date                                    : 20-OCT-2021                        */
/* rTrack ID                               : TECH-63474                         */
/* Description							   : New Feature--GQL Operations	    */
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
/* Author                                  : Rajeswari M / Jeya Latha K			*/
/* Date                                    : 24-NOV-2021                        */
/* rTrack ID                               : TECH-64197                         */
/* Description							   : GQL Operations						*/
/********************************************************************************/  
/* Modified By	: Ponmalar A / Priyadharshini U									*/
/* Defect ID	: TECH-67697													*/
/* Modified on	: 31Mar2022														*/
/* Description	: GQL Changes.													*/
/********************************************************************************/
/* Modified By	: Ponmalar A/Jeya Latha K										*/
/* Defect ID	: TECH-68063													*/
/* Modified on	: 21-Apr-2022													*/
/* Description	: Provision to map captions for control,column, section and Page
				  in gql engineering..											*/
/********************************************************************************/
/* Modified By	: Priyadharshini U												*/
/* Defect ID	: TECH-72114													*/
/* Modified on	: 22-Aug-2022													*/
/* Description	: 	Report modeling enablement in platform model for GQL based
																user interfaces	*/
/********************************************************************************/
CREATE PROCEDURE ACHgqlSptsknam_lfdqryLEO  
 @ctxt_ouinstance        ctxt_ouinstance, --Input   
 @ctxt_user              ctxt_user, --Input   
 @ctxt_language          ctxt_language, --Input   
 @ctxt_service           ctxt_service, --Input   
 @emgg_arg_qrytype       engg_type, --Input   
 @engg_arg_qry           vw_plf_desc, --Input   
 @engg_arg_qryalias      engg_type, --Input   
 @engg_arg_qryseq        engg_seqno, --Input   
 @engg_arg_qryversion    engg_version, --Input   
 @engg_fld_qry           vw_plf_desc, --Input   
 @engg_fld_qryalias      engg_type, --Input   
 @engg_fld_qryseq        engg_seqno, --Input   
 @engg_fld_qrytype       engg_type, --Input   
 @engg_fld_qry_version   engg_version, --Input   
 @engg_gqhdr_actdescr    engg_description, --Input   
 @engg_gqhdr_actname     engg_name, --Input   
 @engg_gqhdr_cmpdescr    engg_description, --Input   
 @engg_gqhdr_cmpname     engg_name, --Input   
 @engg_gqhdr_cust        engg_name, --Input   
 @engg_gqhdr_ecrno       engg_name, --Input   
 @engg_gqhdr_prcname     engg_name, --Input   
 @engg_gqhdr_prodescr    engg_description, --Input   
 @engg_gqhdr_proj        engg_name, --Input   
 @engg_gqhdr_taskdescr   engg_description, --Input   
 @engg_gqhdr_tasktype    engg_type, --Input   
 @engg_gqhdr_tskname     engg_name, --Input   
 @engg_gqhdr_uidescr     engg_description, --Input   
 @engg_gqhdr_uiname      engg_name, --Input
 @engg_arg_qryhdnkeyfield engg_name, --Input	--13639
 @engg_fld_qryhdnkeyfield engg_name, --Input   --13639
 @engg_gqfld_IncLayoutCtrls	engg_seqno, --TECH-68063
 --Code Added for the Defect Id Tech-72114 starts
 @engg_gq_rep_launchmode			engg_type,
 @engg_gq_rep_oufrmt				engg_type,
 @engg_gq_rep_reportname			engg_name,	
 --Code Added for the Defect Id Tech-72114 ends
 @m_errorid              int output --To Return Execution Status  
as Begin  
 -- nocount should be switched on to prevent phantom rows  
 Set nocount on  
 -- @m_errorid should be 0 to Indicate Success  
 Set @m_errorid = 0  
  --declaration of temporary variables   
  --temporary and formal parameters mapping   
 Set @ctxt_user              = ltrim(rtrim(@ctxt_user))  
 Set @ctxt_service           = ltrim(rtrim(@ctxt_service))  
 Set @emgg_arg_qrytype       = ltrim(rtrim(@emgg_arg_qrytype))  
 Set @engg_arg_qry           = ltrim(rtrim(@engg_arg_qry))  
 Set @engg_arg_qryalias      = ltrim(rtrim(@engg_arg_qryalias))  
 Set @engg_arg_qryversion    = ltrim(rtrim(@engg_arg_qryversion))  
 Set @engg_fld_qry           = ltrim(rtrim(@engg_fld_qry))  
 Set @engg_fld_qryalias      = ltrim(rtrim(@engg_fld_qryalias))  
 Set @engg_fld_qrytype       = ltrim(rtrim(@engg_fld_qrytype))  
 Set @engg_fld_qry_version   = ltrim(rtrim(@engg_fld_qry_version))  
 Set @engg_gqhdr_actdescr    = ltrim(rtrim(@engg_gqhdr_actdescr))  
 Set @engg_gqhdr_actname     = ltrim(rtrim(@engg_gqhdr_actname))  
 Set @engg_gqhdr_cmpdescr    = ltrim(rtrim(@engg_gqhdr_cmpdescr))  
 Set @engg_gqhdr_cmpname     = ltrim(rtrim(@engg_gqhdr_cmpname))  
 Set @engg_gqhdr_cust        = ltrim(rtrim(@engg_gqhdr_cust))  
 Set @engg_gqhdr_ecrno       = ltrim(rtrim(@engg_gqhdr_ecrno))  
 Set @engg_gqhdr_prcname     = ltrim(rtrim(@engg_gqhdr_prcname))  
 Set @engg_gqhdr_prodescr    = ltrim(rtrim(@engg_gqhdr_prodescr))  
 Set @engg_gqhdr_proj        = ltrim(rtrim(@engg_gqhdr_proj))  
 Set @engg_gqhdr_taskdescr   = ltrim(rtrim(@engg_gqhdr_taskdescr))  
 Set @engg_gqhdr_tasktype    = ltrim(rtrim(@engg_gqhdr_tasktype))  
 Set @engg_gqhdr_tskname     = ltrim(rtrim(@engg_gqhdr_tskname))  
 Set @engg_gqhdr_uidescr     = ltrim(rtrim(@engg_gqhdr_uidescr))  
 Set @engg_gqhdr_uiname      = ltrim(rtrim(@engg_gqhdr_uiname))  
  --null checking   
 IF @ctxt_ouinstance = -915   Select @ctxt_ouinstance = null     
 IF @ctxt_user = '~#~'    Select @ctxt_user = null     
 IF @ctxt_language = -915   Select @ctxt_language = null     
 IF @ctxt_service = '~#~'    Select @ctxt_service = null     
 IF @emgg_arg_qrytype = '~#~'    Select @emgg_arg_qrytype = null     
 IF @engg_arg_qry = '~#~'    Select @engg_arg_qry = null     
 IF @engg_arg_qryalias = '~#~'    Select @engg_arg_qryalias = null     
 IF @engg_arg_qryseq = -915   Select @engg_arg_qryseq = null     
 IF @engg_arg_qryversion = '~#~'    Select @engg_arg_qryversion = null     
 IF @engg_fld_qry = '~#~'    Select @engg_fld_qry = null     
 IF @engg_fld_qryalias = '~#~'    Select @engg_fld_qryalias = null     
 IF @engg_fld_qryseq = -915   Select @engg_fld_qryseq = null     
 IF @engg_fld_qrytype = '~#~'    Select @engg_fld_qrytype = null     
 IF @engg_fld_qry_version = '~#~'    Select @engg_fld_qry_version = null     
 IF @engg_gqhdr_actdescr = '~#~'    Select @engg_gqhdr_actdescr = null     
 IF @engg_gqhdr_actname = '~#~'    Select @engg_gqhdr_actname = null     
 IF @engg_gqhdr_cmpdescr = '~#~'    Select @engg_gqhdr_cmpdescr = null     
 IF @engg_gqhdr_cmpname = '~#~'    Select @engg_gqhdr_cmpname = null     
 IF @engg_gqhdr_cust = '~#~'    Select @engg_gqhdr_cust = null     
 IF @engg_gqhdr_ecrno = '~#~'    Select @engg_gqhdr_ecrno = null     
 IF @engg_gqhdr_prcname = '~#~'    Select @engg_gqhdr_prcname = null     
 IF @engg_gqhdr_prodescr = '~#~'    Select @engg_gqhdr_prodescr = null     
 IF @engg_gqhdr_proj = '~#~'    Select @engg_gqhdr_proj = null     
 IF @engg_gqhdr_taskdescr = '~#~'    Select @engg_gqhdr_taskdescr = null     
 IF @engg_gqhdr_tasktype = '~#~'    Select @engg_gqhdr_tasktype = null     
 IF @engg_gqhdr_tskname = '~#~'    Select @engg_gqhdr_tskname = null     
 IF @engg_gqhdr_uidescr = '~#~'    Select @engg_gqhdr_uidescr = null     
 IF @engg_gqhdr_uiname = '~#~'    Select @engg_gqhdr_uiname = null   
 
	EXEC DE_GQL_Fld_LELd_Qry
			@ctxt_language           =	@ctxt_language, 
		    @ctxt_ouinstance         =	@ctxt_ouinstance,  
		    @ctxt_service            =	@ctxt_service,   
		    @ctxt_user               =	@ctxt_user,    
			@customername            =	@engg_gqhdr_cust,  
			@projectname             =	@engg_gqhdr_proj,   
			@ecrno                   =	@engg_gqhdr_ecrno,   
			@processname             =  @engg_gqhdr_prcname,  
			@componentname           =  @engg_gqhdr_cmpname, 
			@taskname				 = @engg_gqhdr_tskname,
			@m_errorid               =	@m_errorid   OUTPUT  


 /*   --OutputList   Select  
  null 'engg_gqfld_qryalias',   
  null 'engg_gqfld_qryname',   
  null 'engg_gqfld_qryseq',   
  null 'engg_gqfld_qrytype',   
  null 'engg_gqfld_qryversion',   
 */  
  Set nocount off   
End 





GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ACHgqlSptsknam_lfdqryLEO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  ACHgqlSptsknam_lfdqryLEO TO PUBLIC
END
GO



