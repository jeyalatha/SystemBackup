if exists ( Select 'y' from sysobjects where name = 'DE_GQL_Rep_LELd_BTSyn' and type = 'P')
    begin
        drop proc DE_GQL_Rep_LELd_BTSyn
    end
go


/********************************************************************************/
/* Procedure                               : DE_GQL_Rep_LELd_BTSyn				*/
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U					*/
/* Date                                    : 10-Aug-2022                        */
/* rTrack ID                               : TECH-72114		                    */
/* Description							   : Report modeling enablement in 
												platform model for GQL based
																user interfaces */
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/

CREATE PROCEDURE DE_GQL_Rep_LELd_BTSyn  
@Ctxt_Language          ctxt_language,
@Ctxt_OUInstance        ctxt_ouinstance,  
@Ctxt_Service           ctxt_service,
@Ctxt_User              ctxt_user,   
@CustomerName           engg_name,    
@ProjectName            engg_name,     
@EcrNo                  engg_name,     
@ProcessName            engg_name,    
@ComponetName           engg_name,    
@ActivityName           engg_name,  
@UIName                 engg_name,  
@m_errorid              INT OUTPUT    
 AS    
BEGIN     
	SET NOCOUNT ON    
    
	SET @m_errorid = 0    
    
	--temporary and formal parameters mapping

	SET @ctxt_user        = LTRIM(RTRIM(@ctxt_user))
	SET @ctxt_service     = LTRIM(RTRIM(@ctxt_service))
	SET @CustomerName     = LTRIM(RTRIM(@CustomerName))
	SET @ProjectName	  = LTRIM(RTRIM(@ProjectName))
	SET @EcrNo			  = LTRIM(RTRIM(@EcrNo))
	SET @ProcessName      = LTRIM(RTRIM(@ProcessName))
	SET @ComponetName     = LTRIM(RTRIM(@ComponetName))
	SET @ActivityName	  = LTRIM(RTRIM(@ActivityName))
	SET @UIName			  = LTRIM(RTRIM(@UIName))
	
	IF @ctxt_ouinstance = -915
		SELECT @ctxt_ouinstance = NULL  

	IF @ctxt_user = '~#~' 
		SELECT @ctxt_user = NULL  

	IF @ctxt_language = -915
		SELECT @ctxt_language = NULL  

	IF @ctxt_service = '~#~' 
		SELECT @ctxt_service = NULL 

	IF @CustomerName = '~#~' 
		SELECT @CustomerName = NULL 

	IF @ProjectName = '~#~' 
		SELECT @ProjectName = NULL 

	IF @EcrNo = '~#~' 
		SELECT @EcrNo = NULL 

	IF @ProcessName = '~#~' 
		SELECT @ProcessName = NULL 

	IF @ComponetName = '~#~' 
		SELECT @ComponetName = NULL 

	IF @ActivityName = '~#~' 
		SELECT @ActivityName = NULL 
	
	IF @UIName = '~#~' 
	  SELECT @UIName	=	NULL

	SELECT DISTINCT   
			''			             'engg_gq_rep_lecontrolbtsyn', 
		    ''			             'engg_gq_rep_lecaption',
		    ''			             'engg_gq_rep_lecontroltype',  
		    ''		                 'engg_gq_rep_ledatatype',
		    ''		                 'engg_gq_rep_lecontrolid',
		    ''                       'engg_gq_rep_leviewname' , 
		    ''                       'engg_gq_rep_lesectionname',
		    ''                       'engg_gq_rep_lepagename'  
   UNION  
   SELECT DISTINCT   
		   ctl.control_bt_synonym     'engg_gq_rep_lecontrolbtsyn', 
		   glo.bt_synonym_caption	  'engg_gq_rep_lecaption',
		   ctl.control_type			  'engg_gq_rep_lecontroltype',  
		   glo.data_type			  'engg_gq_rep_ledatatype',
		   ctl.control_id			  'engg_gq_rep_lecontrolid',
		   ctl.view_name              'engg_gq_rep_leviewname' , 
		   ctl.section_bt_synonym     'engg_gq_rep_lesectionname',
		   ctl.page_bt_synonym        'engg_gq_rep_lepagename'
 FROM  de_ui_control AS ctl WITH (NOLOCK)  
 INNER JOIN de_glossary AS glo  WITH (NOLOCK)
 ON    ctl.customer_name			=	glo.customer_name
 AND   ctl.project_name				=   glo.project_name
 AND   ctl.process_name				=	glo.process_name
 AND   ctl.component_name			=	glo.component_name
 AND   ctl.control_bt_synonym		=	glo.bt_synonym_name
 WHERE ctl.customer_name			=	RTRIM(@CustomerName)  
 AND   ctl.project_name				=	RTRIM(@ProjectName)  
 AND   ctl.process_name				=	RTRIM(@ProcessName) 
 AND   ctl.component_name			=	RTRIM(@ComponetName)
 AND   ctl.activity_name			=	RTRIM(@ActivityName)  
 AND   ctl.ui_name					=	RTRIM(@UIName)  
 AND   ctl.control_type NOT IN ('Button','Link','Label','Filler','Filler2' ,'HiddentreeEdit','grid')
 UNION
 SELECT DISTINCT   
		   grd.column_bt_synonym      'engg_gq_rep_lecontrolbtsyn', 
		   glo.bt_synonym_caption	  'engg_gq_rep_lecaption',
		   grd.column_type			  'engg_gq_rep_lecontroltype',  
		   glo.data_type			  'engg_gq_rep_ledatatype',
		   grd.control_id			  'engg_gq_rep_lecontrolid',
		   grd.view_name              'engg_gq_rep_leviewname' , 
		   grd.section_bt_synonym     'engg_gq_rep_lesectionname',
		   grd.page_bt_synonym        'engg_gq_rep_lepagename'
 FROM  de_ui_grid AS grd WITH (NOLOCK)  
 INNER JOIN de_ui_control AS ctl WITH (NOLOCK)
 ON  grd.customer_name				=	ctl.customer_name
 AND grd.project_name				=	ctl.project_name
 AND grd.process_name				=	ctl.process_name
 AND grd.component_name				=	ctl.component_name
 AND grd.activity_name				=	ctl.activity_name
 AND grd.ui_name					=	ctl.ui_name
 AND grd.control_bt_synonym			=	ctl.control_bt_synonym
 INNER JOIN de_glossary AS glo  WITH (NOLOCK)
 ON    grd.customer_name			=	glo.customer_name
 AND   grd.project_name				=   glo.project_name
 AND   grd.process_name				=	glo.process_name
 AND   grd.component_name			=	glo.component_name
 AND   grd.column_bt_synonym		=	glo.bt_synonym_name
 WHERE grd.customer_name			=	RTRIM(@CustomerName)  
 AND   grd.project_name				=	RTRIM(@ProjectName)  
 AND   grd.process_name				=	RTRIM(@ProcessName) 
 AND   grd.component_name			=	RTRIM(@ComponetName)
 AND   grd.activity_name			=	RTRIM(@ActivityName)  
 AND   grd.ui_name					=	RTRIM(@UIName)  
 AND   grd.column_type  NOT IN ('Filler','Filler2','label')
 UNION

 
 SELECT  DISTINCT  
		   hdn.hidden_view_bt_synonym	'engg_gq_rep_lecontrolbtsyn', 
		   glo.bt_synonym_caption		'engg_gq_rep_lecaption',
		   ctl.control_type				'engg_gq_rep_lecontroltype',  
		   glo.data_type				'engg_gq_rep_ledatatype',
		   hdn.control_id				'engg_gq_rep_lecontrolid',
		   hdn.view_name				'engg_gq_rep_leviewname' , 
		   hdn.section_name				'engg_gq_rep_lesectionname',
		   hdn.page_name				'engg_gq_rep_lepagename'
 FROM  de_hidden_view AS hdn  WITH (NOLOCK)
  INNER JOIN de_glossary AS glo  WITH (NOLOCK)
 ON    hdn.customer_name			=	glo.customer_name
 AND   hdn.project_name				=   glo.project_name
 AND   hdn.process_name				=	glo.process_name
 AND   hdn.component_name			=	glo.component_name
 AND hdn.hidden_view_bt_synonym	=	glo.bt_synonym_name
 INNER JOIN de_ui_control AS ctl WITH (NOLOCK)
 ON		hdn.customer_name			=	ctl.customer_name
 AND   hdn.project_name				=   ctl.project_name
 AND   hdn.process_name				=	ctl.process_name
 AND   hdn.component_name			=	ctl.component_name
 AND	hdn.activity_name			=	ctl.activity_name
 AND	hdn.ui_name					=	ctl.ui_name
 AND	hdn.control_bt_synonym		=	ctl.control_bt_synonym
 WHERE hdn.customer_name			=	RTRIM(@customername)  
 AND   hdn.project_name				=	RTRIM(@ProjectName)
 AND   hdn.process_name				=	RTRIM(@ProcessName) 
 AND   hdn.component_name			=	RTRIM(@ComponetName)
 AND   ctl.activity_name			=	RTRIM(@ActivityName)  
 AND   ctl.ui_name					=	RTRIM(@uiname)  
 UNION

  SELECT  DISTINCT  
		   hdn.hidden_view_bt_synonym	'engg_gq_rep_lecontrolbtsyn', 
		   glo.bt_synonym_caption		'engg_gq_rep_lecaption',
		   grd.column_type				'engg_gq_rep_lecontroltype',  
		   glo.data_type				'engg_gq_rep_ledatatype',
		   hdn.control_id				'engg_gq_rep_lecontrolid',
		   hdn.view_name				'engg_gq_rep_leviewname' , 
		   hdn.section_name				'engg_gq_rep_lesectionname',
		   hdn.page_name				'engg_gq_rep_lepagename'
 FROM  de_hidden_view AS hdn  WITH (NOLOCK)
  INNER JOIN de_glossary AS glo  WITH (NOLOCK)
 ON    hdn.customer_name			=	glo.customer_name
 AND   hdn.project_name				=   glo.project_name
 AND   hdn.process_name				=	glo.process_name
 AND   hdn.component_name			=	glo.component_name
 AND   hdn.hidden_view_bt_synonym	=	glo.bt_synonym_name
 INNER JOIN de_ui_grid AS grd WITH (NOLOCK)
 ON		hdn.customer_name			=	grd.customer_name
 AND   hdn.project_name				=   grd.project_name
 AND   hdn.process_name				=	grd.process_name
 AND   hdn.component_name			=	grd.component_name
 AND	hdn.activity_name			=	grd.activity_name
 AND	hdn.ui_name					=	grd.ui_name
 AND	hdn.control_bt_synonym		=	grd.column_bt_synonym
 WHERE hdn.customer_name			=	RTRIM(@customername)  
 AND   hdn.project_name				=	RTRIM(@ProjectName)
 AND   hdn.process_name				=	RTRIM(@ProcessName) 
 AND   hdn.component_name			=	RTRIM(@ComponetName)
 AND   grd.activity_name			=	RTRIM(@ActivityName)  
 AND   grd.ui_name					=	RTRIM(@uiname)  
 UNION



 SELECT DISTINCT   
		   grd.control_id	+' - '+ 'modeflag'      'engg_gq_rep_lecontrolbtsyn', 
		   'modeflag' 								'engg_gq_rep_lecaption',
		   ''										'engg_gq_rep_lecontroltype',  
		   ''										'engg_gq_rep_ledatatype',
		   grd.control_id							'engg_gq_rep_lecontrolid',
		   'modeflag'								'engg_gq_rep_leviewname' , 
		   ''										'engg_gq_rep_lesectionname',
		   ''										'engg_gq_rep_lepagename'
 FROM  de_ui_grid AS grd WITH (NOLOCK)  
 INNER JOIN de_ui_control AS ctl WITH (NOLOCK)
 ON  grd.customer_name				=	ctl.customer_name
 AND grd.project_name				=	ctl.project_name
 AND grd.process_name				=	ctl.process_name
 AND grd.component_name				=	ctl.component_name
 AND grd.activity_name				=	ctl.activity_name
 AND grd.ui_name					=	ctl.ui_name
 AND grd.control_bt_synonym			=	ctl.control_bt_synonym
 INNER JOIN de_glossary AS glo  WITH (NOLOCK)
 ON    grd.customer_name			=	glo.customer_name
 AND   grd.project_name				=   glo.project_name
 AND   grd.process_name				=	glo.process_name
 AND   grd.component_name			=	glo.component_name
 AND   grd.column_bt_synonym		=	glo.bt_synonym_name
 WHERE grd.customer_name			=	RTRIM(@CustomerName)  
 AND   grd.project_name				=	RTRIM(@ProjectName)
  AND  grd.process_name				=	RTRIM(@ProcessName) 
 AND   grd.component_name			=	RTRIM(@ComponetName)
 AND   grd.activity_name			=	RTRIM(@ActivityName)  
 AND   grd.ui_name					=	RTRIM(@UIName)  
 AND   grd.column_type  NOT IN ('Filler','Filler2','label')

 

SET NOCOUNT OFF    
END 

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'DE_GQL_Rep_LELd_BTSyn' AND TYPE='P')
BEGIN
    GRANT EXEC ON  DE_GQL_Rep_LELd_BTSyn TO PUBLIC
END
GO 