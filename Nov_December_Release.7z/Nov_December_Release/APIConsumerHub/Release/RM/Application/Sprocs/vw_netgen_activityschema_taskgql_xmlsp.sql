IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'vw_netgen_activityschema_taskgql_xmlsp' AND TYPE = 'P')
BEGIN
	DROP PROC vw_netgen_activityschema_taskgql_xmlsp
END
GO
/*
BEGIN TRAN
EXEC vw_netgen_activityschema_taskgql_xmlsp 'Ramco','SysTesting','SAO_ECR_00032','SalesShiping','SaleOrder','SalesHub','SalesHubUI'
ROLLBACK
*/
/****************************************************************************************/
/* Procedure                               : vw_netgen_activityschema_taskgql_xmlsp		*/
/* Description                             :                                            */
/****************************************************************************************/
/* Development history                     :                                            */
/****************************************************************************************/
/* Author                                  :  Venkatesan K                              */
/* Date                                    :  21-Oct-2021                               */
/****************************************************************************************/
/* Modified By	: Priyadharshini U														*/
/* Defect ID	: TECH-72114															*/
/* Modified on	: 22-Aug-2022															*/
/* Description	: Report modeling enablement in platform model for GQL based 
user interfaces																			*/
/****************************************************************************************/
/* Modified By	: Venkatesan K															*/
/* Defect ID	: TECH-67697															*/
/* Modified on	: 31Mar2022																*/
/* Description	: GQL Changes.															*/
/****************************************************************************************/
CREATE PROC  vw_netgen_activityschema_taskgql_xmlsp 
	@CustomerName	ENGG_NAME, 
	@ProjectName	ENGG_NAME, 
	@EcrNo          ENGG_NAME,
	@ProcessName	ENGG_NAME,
	@ComponentName	ENGG_NAME,
	@ActivityName	ENGG_NAME,
	@UIName			ENGG_NAME
AS 
  BEGIN 
      SET NOCOUNT ON 

		DECLARE @langId INT

		SET @langId  =	1


	--CREATE TABLE #fw_des_publish_gql_query	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, QueryType	VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, Version VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, QueryText	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS )

	--CREATE TABLE #fw_des_publish_gql_argument	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,  QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, ImportVersion VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, Name VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, parentkey VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, [key]	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS,	category	VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS,	typename	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS,	typekind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS,	oftypename	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS, oftypekind	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS, typerequired	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS, oftyperequired	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS,	DefaultValue	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS	)

	--CREATE TABLE #fw_des_publish_gql_field	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,  QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, ImportVersion VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, Name VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, parentkey VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, [key]	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS,	category	VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS,	typename	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS,	typekind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS,	oftypename	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS, oftypekind	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS, typerequired	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS, oftyperequired	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS,	DefaultValue	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS	)

	--CREATE TABLE #fw_des_publish_gql_Schema	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, Version VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, IntrospectionJSON	VARCHAR(100) COLLATE SQL_Latin1_General_CP1_CI_AS, IntrospectionJSONDbc	NVARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS, SDLSchema	VARCHAR(100) COLLATE SQL_Latin1_General_CP1_CI_AS, SDLSchemaDbc	NVARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS, SDLText NVARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS )

	CREATE TABLE #fw_des_publish_task_gql_mapping	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, QuerySequence	INT, QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, QueryType	VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, Version VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, QueryAlias	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskType VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS, ChildQueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS )

	CREATE TABLE #fw_des_publish_task_gql_argument_mapping	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, QuerySequence	INT, QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, Version VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, Argument	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, ControlID	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	ArgumentType	VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS,	DataType	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	IsMandatory	VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS,	BTSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	DefaultValue	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, FlattenedArgumentName	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS,	TypeKind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeName	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeKind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, TypeRequired	VARCHAR(3) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeRequired	VARCHAR(3) COLLATE SQL_Latin1_General_CP1_CI_AS, ChildQueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessingType  VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS)	--code added by 13639 on 04Mar2022

	CREATE TABLE #fw_des_publish_task_gql_field_mapping	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, QuerySequence	INT, QueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, Version VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, ControlID	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	FieldName	VARCHAR(1000) COLLATE SQL_Latin1_General_CP1_CI_AS,	FieldAlias	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	BTSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	DataType	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TypeKind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeName	VARCHAR(2000) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeKind	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, TypeRequired	VARCHAR(3) COLLATE SQL_Latin1_General_CP1_CI_AS, OfTypeRequired	VARCHAR(3) COLLATE SQL_Latin1_General_CP1_CI_AS, ImmediateParentType VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS, MapType VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS	, ChildQueryName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS	)

	CREATE TABLE #fw_des_publish_glossary	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, BTSynonymName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, Caption	VARCHAR(500) COLLATE SQL_Latin1_General_CP1_CI_AS, DataType	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, Data_Length	INT, BTName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, PrecisionType VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, DecimalLength INT )

	CREATE TABLE #fw_des_publish_hidden_view	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, PageName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, SectionName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, ControlID	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, BTSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	HiddenViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	HiddenViewSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	DataType	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, Data_Length	INT, BTName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, PrecisionType VARCHAR(8) COLLATE SQL_Latin1_General_CP1_CI_AS, DecimalLength INT	)

	CREATE TABLE #fw_des_publish_subscription_dataitem	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	BTSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, LinkId	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS,	LinkType	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS,  TargetComponent	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TargetActivity	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TargetIlbo	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, SubscriptionName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DataItemName VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, FlowDirection VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS, SubscriptionControlID VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	SubscriptionViewName VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS )

	CREATE TABLE #fw_des_publish_publication_dataitem	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, PublicationName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, LinkId	VARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AS, DataItemName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, ControlID	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	FlowDirection	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS,	IsMultiInstance	VARCHAR(5) COLLATE SQL_Latin1_General_CP1_CI_AS	)
	--TECH-72114
	CREATE TABLE #fw_published_task_gql_report	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ReportName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, OutputFormat	VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS, LaunchMode	VARCHAR(20) COLLATE SQL_Latin1_General_CP1_CI_AS)

	CREATE TABLE #fw_published_task_gql_report_param	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ActivityName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, UIName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, TaskName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ReportName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ParameterName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, BTSynonym	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS,	ControlID	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ViewName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DefaultValue	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS)
	--TECH-72114

	CREATE TABLE #fw_des_publish_gql_schema	( CustomerName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProjectName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ProcessName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, ComponentName	VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, DocNo VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, SchemaName	VARCHAR(60)	COLLATE SQL_Latin1_General_CP1_CI_AS, SchemaVersion	VARCHAR(10) COLLATE SQL_Latin1_General_CP1_CI_AS , IntrospectionJson VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, IntrospectionJsonDBC	VARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS,SDLSchema VARCHAR(60) COLLATE SQL_Latin1_General_CP1_CI_AS, SDLSchemaDBC	VARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS, SDLText VARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS)

	--INSERT INTO #fw_des_publish_gql_query
	--			(	CustomerName,			ProjectName,			DocNo,			ProcessName,
	--				ComponentName,			QueryName,				QueryType,		Version,
	--				QueryText ) 
	--	SELECT DISTINCT
	--				CustomerName,			ProjectName,			DocNo,			ProcessName,
	--				ComponentName,			QueryName,				QueryType,		Version,
	--				QueryText
	--		FROM	fw_des_publish_gql_query_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName) 


	--INSERT INTO #fw_des_publish_gql_argument
	--			(	CustomerName,			ProjectName,		DocNo,				ProcessName,
	--				ComponentName,			QueryName,			importversion,		name,
	--				parentkey,				[key],				oftypename,			oftypekind,		
	--				typekind,				defaultvalue,		typerequired,		oftyperequired	)	
	--		SELECT DISTINCT
	--				CustomerName,			ProjectName,		DocNo,				ProcessName,
	--				ComponentName,			QueryName,			importversion,		name,
	--				parentkey,				[key],				oftypename,			oftypekind,		
	--				typekind,				defaultvalue,		typerequired,		oftyperequired
	--		FROM	fw_des_publish_gql_argument_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName) 

	--	INSERT INTO #fw_des_publish_gql_field
	--			(	CustomerName,			ProjectName,		DocNo,				ProcessName,
	--				ComponentName,			QueryName,			importversion,		name,
	--				parentkey,				[key],				oftypename,			oftypekind,		
	--				typekind,				defaultvalue,		typerequired,		oftyperequired	)	
	--		SELECT DISTINCT
	--				CustomerName,			ProjectName,		DocNo,				ProcessName,
	--				ComponentName,			QueryName,			importversion,		name,
	--				parentkey,				[key],				oftypename,			oftypekind,		
	--				typekind,				defaultvalue,		typerequired,		oftyperequired
	--		FROM	fw_des_publish_gql_field_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName)

	--	--GraphQL Schema Info

	--INSERT INTO #fw_des_publish_gql_Schema 
	--				(	CustomerName,		ProjectName,	DocNo,				ProcessName,
	--					ComponentName,		Version,		IntrospectionJSON,	
	--					IntrospectionJSONDbc,
	--					SDLSchema,			SDLSchemaDbc,	SDLText		)
	--		SELECT DISTINCT
	--					CustomerName,		ProjectName,	DocNo,				ProcessName,
	--					ComponentName,		Version,		IntrospectionJSON,	
	--					dbo.[de_fn_Base64_to_String](IntrospectionJSONDbc),
	--					SDLSchema,			SDLSchemaDbc,	SDL_Text
	--			FROM	fw_des_publish_gql_Schema_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName	) 
	--	Schema info

	INSERT INTO #fw_des_publish_gql_schema
				(	CustomerName,			ProjectName,			DocNo,			ProcessName,
					ComponentName,			SchemaName,				SchemaVersion,		
					IntrospectionJson,		IntrospectionJsonDBC,	SDLSchema,		SDLSchemaDBC,
					SDLText ) 
		SELECT DISTINCT
					CustomerName,			ProjectName,			DocNo,			ProcessName,
					ComponentName,			NULL,					Version,		
					IntrospectionJson,		IntrospectionJsonDBC,	SDLSchema,		SDLSchemaDBC,
					SDL_Text
			FROM	fw_des_publish_gql_Schema_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName) 

		--GraphQL Task Query Mapping

	INSERT INTO #fw_des_publish_task_gql_mapping
					(	CustomerName,			ProjectName,			DocNo,			ProcessName,
						ComponentName,			ActivityName,			UIName,			TaskName,
						QuerySequence,			QueryName,				QueryType,		Version,
						QueryAlias,				TaskType,				ChildQueryName )  
			SELECT DISTINCT
						CustomerName,			ProjectName,			DocNo,			ProcessName,
						ComponentName,			ActivityName,			UIName,			TaskName,
						QuerySequence,			QueryName,				QueryType,		Version,
						QueryAlias,				Task_Type,				ChildQueryName
				FROM	fw_des_publish_task_gql_mapping_xml_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName, @ActivityName, @UIName) 

	--GraphQL Task Query Arugument Mapping

	INSERT INTO #fw_des_publish_task_gql_argument_mapping
					(	CustomerName,		ProjectName,		DocNo,			ProcessName,
						ComponentName,		ActivityName,		UIName,			TaskName,
						QuerySequence,		QueryName,			Argument,		ControlID,
						ViewName,			ArgumentType,		DataType,		IsMandatory,
						BTSynonym,			DefaultValue,		Version,		FlattenedArgumentName,
						typekind,			oftypename,			oftypekind,		typerequired,
						oftyperequired,		ChildQueryName,		ProcessingType )	--code added by 13639 on 04Mar2022
			SELECT DISTINCT
						CustomerName,		ProjectName,		DocNo,			ProcessName,
						ComponentName,		ActivityName,		UIName,			TaskName,
						QuerySequence,		QueryName,			Argument,		ControlID,
						ViewName,			ArgumentType,		DataType,		IsMandatory,
						BTSynonym,			DefaultValue,		Version,		FlattenedArgumentName,
						typekind,			oftypename,			oftypekind,		typerequired,
						oftyperequired,		ChildQueryName,		ProcessingType		--code added by 13639 on 04Mar2022
				FROM	fw_des_publish_task_gql_argument_mapping_xml_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName, @ActivityName, @UIName)
		update d
		set		d.ViewName		=	c.viewname
		from	de_published_ui_control a (NOLOCK),
				de_published_enum_value b (NOLOCK),
				de_fw_req_publish_ilbo_view c (NOLOCK),
				#fw_des_publish_task_gql_argument_mapping d (NOLOCK)
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
		AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.control_bt_synonym	=	b.control_bt_synonym
		
		AND		a.customer_name			=	c.customername
		AND		a.project_name			=	c.projectname
		AND		a.process_name			=	c.processname
		AND		a.component_name		=	c.componentname
		AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.control_bt_synonym	=	c.control_bt_synonym
		
		AND		a.customer_name			=	d.CustomerName		COLLATE DATABASE_DEFAULT
		AND		a.project_name			=	d.ProjectName		COLLATE DATABASE_DEFAULT
		AND		a.process_name			=	d.ProcessName		COLLATE DATABASE_DEFAULT
		AND		a.component_name		=	d.ComponentName		COLLATE DATABASE_DEFAULT
		AND		a.ecrno					=	d.DocNo				COLLATE DATABASE_DEFAULT
		AND		a.activity_name			=	d.ActivityName		COLLATE DATABASE_DEFAULT
		AND		a.ui_name				=	d.UIName			COLLATE DATABASE_DEFAULT
		AND		a.control_id			=	d.ControlID			COLLATE DATABASE_DEFAULT
		AND		a.view_name				=	d.ViewName			COLLATE DATABASE_DEFAULT
		
		AND		a.customer_name			=	@customername
		AND		a.project_name			=	@projectname
		AND		a.process_name			=	@ProcessName
		AND		a.component_name		=	@ComponentName
		AND		a.ecrno					=	@ecrno
		AND		a.activity_name			=	@ActivityName
		AND		a.ui_name				=	@UIName

		AND		c.DisplayFlag			=	'F'

		update d
		set d.ViewName		=	c.viewname
		from	de_published_ui_grid a (NOLOCK),
				de_published_enum_value b (NOLOCK),
				de_fw_req_publish_ilbo_view c (NOLOCK),
				#fw_des_publish_task_gql_argument_mapping d (NOLOCK)
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
		AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.column_bt_synonym		=	b.control_bt_synonym
		
		AND		a.customer_name			=	c.customername
		AND		a.project_name			=	c.projectname
		AND		a.process_name			=	c.processname
		AND		a.component_name		=	c.componentname
		AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.column_bt_synonym		=	c.control_bt_synonym
		
		AND		a.customer_name			=	d.CustomerName		  COLLATE DATABASE_DEFAULT
		AND		a.project_name			=	d.ProjectName		  COLLATE DATABASE_DEFAULT
		AND		a.process_name			=	d.ProcessName		  COLLATE DATABASE_DEFAULT
		AND		a.component_name		=	d.ComponentName		  COLLATE DATABASE_DEFAULT
		AND		a.ecrno					=	d.DocNo				  COLLATE DATABASE_DEFAULT
		AND		a.activity_name			=	d.ActivityName		  COLLATE DATABASE_DEFAULT
		AND		a.ui_name				=	d.UIName			  COLLATE DATABASE_DEFAULT
		AND		a.control_id			=	d.ControlID			  COLLATE DATABASE_DEFAULT
		AND		a.view_name				=	d.ViewName			  COLLATE DATABASE_DEFAULT
		
		AND		a.customer_name			=	@customername
		AND		a.project_name			=	@projectname
		AND		a.process_name			=	@ProcessName
		AND		a.component_name		=	@ComponentName
		AND		a.ecrno					=	@ecrno
		AND		a.activity_name			=	@ActivityName
		AND		a.ui_name				=	@UIName

		AND		c.DisplayFlag			=	'F'

	--GraphQL Task Query Field Mapping

	INSERT INTO #fw_des_publish_task_gql_field_mapping
					(	CustomerName,		ProjectName,		DocNo,			ProcessName,
						ComponentName,		ActivityName,		UIName,			TaskName,
						QuerySequence,		QueryName,			ControlID,		ViewName,
						FieldName,			FieldAlias,			BTSynonym,		Version,
						typekind,			oftypename,			oftypekind,		typerequired,
						oftyperequired,		DataType,			MapType,		ChildQueryName )  
			SELECT DISTINCT
						CustomerName,		ProjectName,		DocNo,			ProcessName,
						ComponentName,		ActivityName,		UIName,			TaskName,
						QuerySequence,		QueryName,			ControlID,		ViewName,
						FieldName,			FieldAlias,			BTSynonym,		Version,
						typekind,			oftypename,			oftypekind,		typerequired,
						oftyperequired,		typename,			MapType,		ChildQueryName
				FROM	fw_des_publish_task_gql_field_mapping_xml_vw_fn (@customername, @projectname, @ecrno, @ProcessName, @ComponentName, @ActivityName, @UIName)

			UPDATE		a
			SET			a.ImmediateParentType		=	c.typekind
			FROM		#fw_des_publish_task_gql_field_mapping	a (NOLOCK)
			INNER JOIN	fw_published_graphql_arg_fields b (NOLOCK)
			ON			a.CustomerName				=	b.customername	  COLLATE database_default 
			AND			a.ProjectName				=	b.projectname	  COLLATE database_default 
			AND			a.ProcessName				=	b.processname	  COLLATE database_default 
			AND			a.ComponentName				=	b.componentname	  COLLATE database_default 
			AND			a.DocNo						=	b.DocNo			  COLLATE database_default 
			AND			a.Version					=	b.importversion	  COLLATE database_default 
			AND			(('Query.' + a.FieldName	=	 b.[key] COLLATE database_default  ) OR ('Mutation.' + a.FieldName	=	 b.[key] COLLATE database_default  ) ) 
			INNER JOIN	fw_published_graphql_arg_fields c (NOLOCK)
			ON			b.CustomerName				=	c.customername
			AND			b.ProjectName				=	c.projectname
			AND			b.ProcessName				=	c.processname
			AND			b.ComponentName				=	c.componentname
			AND			b.DocNo						=	c.DocNo
			AND			b.importversion				=	c.importversion
			AND			b.parentkey					=	c.[key]

			--UPDATE	a
			--SET		a.ImmediateParentType		=	b.typekind
			--FROM	#fw_des_publish_task_gql_field_mapping	a (NOLOCK),
			--		#fw_des_publish_task_gql_field_mapping_temp b (NOLOCK)
			--WHERE	a.CustomerName			=	b.CustomerName
			--AND		a.ProjectName			=	b.ProjectName
			--AND		a.ProcessName			=	b.ProcessName
			--AND		a.ComponentName			=	b.ComponentName
			--AND		a.DocNo					=	b.DocNo
			--AND		a.ActivityName			=	b.ActivityName
			--AND		a.UIName				=	b.UIName
			--AND		a.TaskName				=	b.TaskName
			--AND		a.QueryName				=	b.QueryName
			--AND		a.QuerySequence			=	b.QuerySequence
			--AND		a.FieldName				=	b.FieldName
		update d
		set d.ViewName		=	c.viewname
		from	de_published_ui_control a (NOLOCK),
				de_published_enum_value b (NOLOCK),
				de_fw_req_publish_ilbo_view c (NOLOCK),
				#fw_des_publish_task_gql_field_mapping d (NOLOCK)
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
		AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.control_bt_synonym	=	b.control_bt_synonym
		
		AND		a.customer_name			=	c.customername
		AND		a.project_name			=	c.projectname
		AND		a.process_name			=	c.processname
		AND		a.component_name		=	c.componentname
		AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.control_bt_synonym	=	c.control_bt_synonym
		
		AND		a.customer_name			=	d.CustomerName			 COLLATE DATABASE_DEFAULT
		AND		a.project_name			=	d.ProjectName			 COLLATE DATABASE_DEFAULT
		AND		a.process_name			=	d.ProcessName			 COLLATE DATABASE_DEFAULT
		AND		a.component_name		=	d.ComponentName			 COLLATE DATABASE_DEFAULT
		AND		a.ecrno					=	d.DocNo					 COLLATE DATABASE_DEFAULT
		AND		a.activity_name			=	d.ActivityName			 COLLATE DATABASE_DEFAULT
		AND		a.ui_name				=	d.UIName				 COLLATE DATABASE_DEFAULT
		AND		a.control_id			=	d.ControlID				 COLLATE DATABASE_DEFAULT
		AND		a.view_name				=	d.ViewName				 COLLATE DATABASE_DEFAULT
		
		AND		a.customer_name			=	@customername
		AND		a.project_name			=	@projectname
		AND		a.process_name			=	@ProcessName
		AND		a.component_name		=	@ComponentName
		AND		a.ecrno					=	@ecrno
		AND		a.activity_name			=	@ActivityName
		AND		a.ui_name				=	@UIName

		AND		c.DisplayFlag			=	'F'

		update d
		set d.ViewName		=	c.viewname
		from	de_published_ui_grid a (NOLOCK),
				de_published_enum_value b (NOLOCK),
				de_fw_req_publish_ilbo_view c (NOLOCK),
				#fw_des_publish_task_gql_field_mapping d (NOLOCK)
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
		AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.column_bt_synonym		=	b.control_bt_synonym
		
		AND		a.customer_name			=	c.customername
		AND		a.project_name			=	c.projectname
		AND		a.process_name			=	c.processname
		AND		a.component_name		=	c.componentname
		AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.column_bt_synonym		=	c.control_bt_synonym
		
		AND		a.customer_name			=	d.CustomerName				 COLLATE DATABASE_DEFAULT
		AND		a.project_name			=	d.ProjectName				 COLLATE DATABASE_DEFAULT
		AND		a.process_name			=	d.ProcessName				 COLLATE DATABASE_DEFAULT
		AND		a.component_name		=	d.ComponentName				 COLLATE DATABASE_DEFAULT
		AND		a.ecrno					=	d.DocNo						 COLLATE DATABASE_DEFAULT
		AND		a.activity_name			=	d.ActivityName				 COLLATE DATABASE_DEFAULT
		AND		a.ui_name				=	d.UIName					 COLLATE DATABASE_DEFAULT
		AND		a.control_id			=	d.ControlID					 COLLATE DATABASE_DEFAULT
		AND		a.view_name				=	d.ViewName					 COLLATE DATABASE_DEFAULT
		
		AND		a.customer_name			=	@customername
		AND		a.project_name			=	@projectname
		AND		a.process_name			=	@ProcessName
		AND		a.component_name		=	@ComponentName
		AND		a.ecrno					=	@ecrno
		AND		a.activity_name			=	@ActivityName
		AND		a.ui_name				=	@UIName

		AND		c.DisplayFlag			=	'F'


	----GraphQL Query Master

	--SELECT DISTINCT
	--				CustomerName		 'CustomerName',
	--				ProjectName			 'ProjectName',
	--				ProcessName			 'ProcessName',
	--				ComponentName		 'ComponentName',
	--				QueryName			 'QueryName',
	--				Version				 'Version',
	--				QueryType			 'QueryType',
	--				QueryText			 'QueryText'
	--		FROM	fw_published_graphql_query (NOLOCK)
	--		WHERE	CustomerName		=	@CustomerName
	--		AND		ProjectName			=	@ProjectName
	--		AND		DocNo				=	@EcrNo	
	--		AND		ComponentName		=	@ComponentName

	----GraphQL Query Argument Mapping

	--		SELECT DISTINCT
	--					CustomerName				'CustomerName',
	--					ProjectName					'ProjectName',
	--					ProcessName					'ProcessName',
	--					ComponentName				'ComponentName',
	--					QueryName					'QueryName',
	--					ImportVersion				'Version',
	--					name						'name',
	--					parentkey					'parentkey',				
	--					[key]						'key',				
	--					oftypename					'oftypename',			
	--					oftypekind					'oftypekind',		
	--					typekind					'typekind',				
	--					defaultvalue				'defaultvalue',		
	--					typerequired				'typerequired',		
	--					oftyperequired				'oftyperequired'
	--			FROM	#fw_des_publish_gql_argument (NOLOCK)
	--			WHERE	CustomerName		=	@CustomerName
	--			AND		ProjectName			=	@ProjectName
	--			AND		DocNo				=	@EcrNo	
	--			AND		ComponentName		=	@ComponentName

	----GraphQL Query Field Mapping

	--SELECT DISTINCT
	--				CustomerName				'CustomerName',
	--				ProjectName					'ProjectName',
	--				ProcessName					'ProcessName',
	--				ComponentName				'ComponentName',
	--				QueryName					'QueryName',
	--				ImportVersion				'Version',
	--				name						'name',
	--				parentkey					'parentkey',				
	--				[key]						'key',				
	--				oftypename					'oftypename',			
	--				oftypekind					'oftypekind',		
	--				typekind					'typekind',				
	--				defaultvalue				'defaultvalue',		
	--				typerequired				'typerequired',		
	--				oftyperequired				'oftyperequired'
	--		FROM	#fw_des_publish_gql_field (NOLOCK)
	--		WHERE	CustomerName		=	@CustomerName
	--		AND		ProjectName			=	@ProjectName
	--		AND		DocNo				=	@EcrNo	
	--		AND		ComponentName		=	@ComponentName

	----GraphQL Schema info

	--			SELECT DISTINCT
	--					CustomerName			'CustomerName',		
	--					ProjectName				'ProjectName',	
	--					DocNo					'DocNo',				
	--					ProcessName				'ProcessName',
	--					ComponentName			'ComponentName',		
	--					Version					'Version',		
	--					--IntrospectionJSON		'IntrospectionJSON',	
	--					--IntrospectionJSONDbc	'IntrospectionJSONDbc',
	--					--SDLSchema				'SDLSchema',			
	--					--SDLSchemaDbc			'SDLSchemaDbc',
	--					IntrospectionJSONDBC	'IntrospectionJSON',
	--					SDLText					'SDLSchema'
	--			FROM	#fw_des_publish_gql_Schema (NOLOCK)

	--GraphQL Task Query Mapping

				SELECT	DISTINCT
						LTRIM(RTRIM(LOWER(CustomerName)))			'CustomerName',
						LTRIM(RTRIM(LOWER(ProjectName)))			'ProjectName',
						LTRIM(RTRIM(LOWER(ProcessName)))			'ProcessName',
						LTRIM(RTRIM(LOWER(ComponentName)))			'ComponentName',
						LTRIM(RTRIM(LOWER(ActivityName)))			'ActivityName',
						LTRIM(RTRIM(LOWER(UIName)))					'UIName',
						LTRIM(RTRIM(LOWER(TaskName)))				'TaskName',
						[dbo].[InitCap] ( TaskType )				'TaskType',
						QuerySequence								'QuerySequence',
						--QueryName									'QueryName',
						--REPLACE (REPLACE(QueryName,'Query.',''),'Mutation.','')	'QueryName',
						CASE WHEN ISNULL(ChildQueryName,'') = '' THEN QueryName ELSE
						ISNULL(QueryName,'')	+ '.' + ISNULL(ChildQueryName,'')	END AS	'QueryName',
						QueryType									'QueryType',
						Version										'Version',
						ISNULL(QueryAlias,NULL)						'QueryAlias'
				FROM	#fw_des_publish_task_gql_mapping (NOLOCK)

		--GraphQL Task Query Argument Mapping

					SELECT DISTINCT
							LTRIM(RTRIM(LOWER(CustomerName)))			'CustomerName',
							LTRIM(RTRIM(LOWER(ProjectName)))			'ProjectName',
							LTRIM(RTRIM(LOWER(ProcessName)))			'ProcessName',
							LTRIM(RTRIM(LOWER(ComponentName)))			'ComponentName',
							LTRIM(RTRIM(LOWER(ActivityName)))			'ActivityName',
							LTRIM(RTRIM(LOWER(UIName)))					'UIName',
							LTRIM(RTRIM(LOWER(TaskName)))				'TaskName',
							QuerySequence								'QuerySequence',
							Version										'Version',
							--QueryName									'QueryName',
							--REPLACE (REPLACE(QueryName,'Query.',''),'Mutation.','')	'QueryName',
							CASE WHEN ISNULL(ChildQueryName,'') = '' THEN QueryName ELSE
						ISNULL(QueryName,'')	+ '.' + ISNULL(ChildQueryName,'')	END AS	'QueryName',	
							--Argument									'Argument',
							LTRIM(RTRIM(LOWER(ControlID)))				'ControlID',
							LTRIM(RTRIM(LOWER(ViewName)))				'ViewName',
							ArgumentType								'ArgumentType',
							--LTRIM(RTRIM(LOWER(DataType)))				'DataType',
							DataType									'DataType',
							LTRIM(RTRIM(LOWER(IsMandatory)))			'IsMandatory',
							LTRIM(RTRIM(LOWER(BTSynonym)))				'BTSynonym',
							FlattenedArgumentName						'ArgumentName',
							--DefaultValue								'DefaultValue',
							ISNULL(DefaultValue,NULL)					'DefaultValue',
							typekind									'TypeKind',			
							oftypename									'OfTypeName',			
							oftypekind									'OfTypeKind',		
							typerequired								'TypeRequired',
							oftyperequired								'OfTypeRequired',
							ProcessingType								'ProcessingType' --Code added by 13639 on 04Mar2022
					FROM	#fw_des_publish_task_gql_argument_mapping (NOLOCK)

	--GraphQL Task Query Field Mapping 

					SELECT DISTINCT
							LTRIM(RTRIM(LOWER(CustomerName)))			'CustomerName',
							LTRIM(RTRIM(LOWER(ProjectName)))			'ProjectName',
							LTRIM(RTRIM(LOWER(ProcessName)))			'ProcessName',
							LTRIM(RTRIM(LOWER(ComponentName)))			'ComponentName',
							LTRIM(RTRIM(LOWER(ActivityName)))			'ActivityName',
							LTRIM(RTRIM(LOWER(UIName)))					'UIName',
							LTRIM(RTRIM(LOWER(TaskName)))				'TaskName',
							QuerySequence								'QuerySequence',
							--QueryName									'QueryName',
							--REPLACE (REPLACE(QueryName,'Query.',''),'Mutation.','')	'QueryName',
							CASE WHEN ISNULL(ChildQueryName,'') = '' THEN QueryName ELSE
						ISNULL(QueryName,'')	+ '.' + ISNULL(ChildQueryName,'')	END AS	'QueryName',
							Version										'Version',
							LTRIM(RTRIM(LOWER(ControlID)))				'ControlID',
							LTRIM(RTRIM(LOWER(ViewName)))				'ViewName',
							FieldName									'FieldName',
							--FieldAlias									'FieldAlias',
							ISNULL(FieldAlias,NULL)						'FieldAlias',
							LTRIM(RTRIM(LOWER(BTSynonym)))				'BTSynonym',
							--LTRIM(RTRIM(LOWER(DataType)))				'DataType',
							DataType									'DataType',
							typekind									'TypeKind',			
							oftypename									'OfTypeName',			
							oftypekind									'OfTypeKind',		
							typerequired								'TypeRequired',
							oftyperequired								'OfTypeRequired',
							ImmediateParentType							'ImmediateParentType',
							LOWER(MapType)								'MapType'
					FROM	#fw_des_publish_task_gql_field_mapping (NOLOCK)

		----Glossary

		--INSERT INTO	#fw_des_publish_glossary
		--		(	CustomerName,			ProjectName,		ProcessName,				ComponentName,		
		--			DocNo,					BTSynonymName,		Caption,
		--			DataType,				BTName,				Data_Length )
		--SELECT DISTINCT
		--			customer_name,		project_name,			process_name,				@EcrNo,		
		--			component_name,		bt_synonym_name,		bt_synonym_caption,
		--			data_type,			bt_name,				length
		--	FROM	ngplf_de_published_glossary_lng_extn_vw_fn ( @CustomerName, @ProjectName, @EcrNo, @langId )	

		----Hidden Views

		INSERT INTO #fw_des_publish_hidden_view
					(	CustomerName,		ProjectName,		ProcessName,		ComponentName,		
						DocNo,				ActivityName,		UIName, 			PageName,			
						SectionName,		ControlID,			ViewName,			BTSynonym,	
						HiddenViewName,		HiddenViewSynonym,	DataType,			Data_Length, 
						BTName	)
			SELECT DISTINCT
						a.Customer_name,	a.Project_name,		a.process_name,		a.component_name,
						a.ecrno,			activity_name,		ui_name,			page_name,
						section_name,		control_id,			view_name,			control_bt_synonym,
						Hidden_View_Name,	hidden_view_bt_synonym,data_type,	length,
						bt_name				
				FROM	de_published_hidden_view_fn ( @CustomerName, @ProjectName, @EcrNo ) a,
						de_published_glossary_fn  ( @CustomerName, @ProjectName, @EcrNo ) b
				WHERE	a.Customer_name			=	b.customer_name
				and		a.project_name			=	b.project_name
				and		a.process_name			=	b.process_name
				and		a.component_name		=	b.component_name
				and		a.ecrno					=	b.ecrno
				and		a.hidden_view_bt_synonym = b.bt_synonym_name

				and		a.customer_name			=	@CustomerName
				AND		a.project_name			=	@ProjectName
				and		a.process_name			=	@ProcessName
				and		a.component_name		=	@ComponentName
				and		a.ecrno					=	@EcrNo		
		UNION
		SELECT DISTINCT
				a.Customer_name,	a.Project_name,		a.process_name,		a.component_name,
				a.ecrno,			a.activity_name,	a.ui_name,			a.page_bt_synonym,
						a.section_bt_synonym,	a.control_id,		a.view_name,		a.control_bt_synonym,
						c.viewname,				c.btsynonym,		data_type,	length,
						bt_name				
				FROM	de_published_ui_control a (NOLOCK),
						de_published_enum_value b (NOLOCK),
						de_fw_req_publish_ilbo_view c (NOLOCK),
						de_published_glossary_fn  ( @CustomerName, @ProjectName, @EcrNo ) d
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
				AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.control_bt_synonym	=	b.control_bt_synonym
		
				AND		a.customer_name			=	c.customername
				AND		a.project_name			=	c.projectname
				AND		a.process_name			=	c.processname
				AND		a.component_name		=	c.componentname
				AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.control_bt_synonym	=	c.control_bt_synonym
		
				AND		a.customer_name			=	d.Customer_Name			
				AND		a.project_name			=	d.Project_Name			
				AND		a.process_name			=	d.Process_Name			
				AND		a.component_name		=	d.Component_Name			
				AND		a.ecrno					=	d.ecrno					
				AND		a.Control_bt_synonym	=	d.bt_synonym_name						
				
				AND		a.customer_name			=	@customername
				AND		a.project_name			=	@projectname
				AND		a.process_name			=	@ProcessName
				AND		a.component_name		=	@ComponentName
				AND		a.ecrno					=	@ecrno
				AND		a.activity_name			=	@ActivityName
				AND		a.ui_name				=	@UIName
		AND		c.DisplayFlag			=	'F'
		UNION
		SELECT DISTINCT
				a.Customer_name,	a.Project_name,		a.process_name,		a.component_name,
				a.ecrno,			a.activity_name,	a.ui_name,			a.page_bt_synonym,
						a.section_bt_synonym,	a.control_id,		a.view_name,		a.control_bt_synonym,
						c.viewname,				c.btsynonym,		data_type,	length,
						bt_name				
				FROM	de_published_ui_grid a (NOLOCK),
						de_published_enum_value b (NOLOCK),
						de_fw_req_publish_ilbo_view c (NOLOCK),
						de_published_glossary_fn  ( @CustomerName, @ProjectName, @EcrNo ) d
		WHERE	a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
				AND		a.ecrno					=	b.ecrno
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.page_bt_synonym		=	b.page_bt_synonym
		AND		a.section_bt_synonym	=	b.section_bt_synonym
		AND		a.column_bt_synonym		=	b.control_bt_synonym
		
				AND		a.customer_name			=	c.customername
				AND		a.project_name			=	c.projectname
				AND		a.process_name			=	c.processname
				AND		a.component_name		=	c.componentname
				AND		a.ecrno					=	c.ecrno
		AND		a.ui_name				=	c.ilbocode
		AND		a.page_bt_synonym		=	c.page_bt_synonym
		AND		a.control_id			=	c.controlid
		AND		a.column_bt_synonym		=	c.control_bt_synonym
		
				AND		a.customer_name			=	d.Customer_Name			
				AND		a.project_name			=	d.Project_Name			
				AND		a.process_name			=	d.Process_Name			
				AND		a.component_name		=	d.Component_Name			
				AND		a.ecrno					=	d.ecrno					
				AND		a.column_bt_synonym		=	d.bt_synonym_name						
				
				AND		a.customer_name			=	@customername
				AND		a.project_name			=	@projectname
				AND		a.process_name			=	@ProcessName
				AND		a.component_name		=	@ComponentName
				AND		a.ecrno					=	@ecrno
				AND		a.activity_name			=	@ActivityName
				AND		a.ui_name				=	@UIName
		AND		c.DisplayFlag			=	'F'
		SELECT DISTINCT
				LTRIM(RTRIM(LOWER(CustomerName)))			'CustomerName',
				LTRIM(RTRIM(LOWER(ProjectName)))			'ProjectName',
				LTRIM(RTRIM(LOWER(ProcessName)))			'ProcessName',
				LTRIM(RTRIM(LOWER(ComponentName)))			'ComponentName',
				LTRIM(RTRIM(LOWER(ActivityName)))			'ActivityName',
				LTRIM(RTRIM(LOWER(UIName)))					'UIName',
				LTRIM(RTRIM(LOWER(PageName)))				'PageName',
				SectionName									'SectionName',
				LTRIM(RTRIM(LOWER(ControlID)))				'ControlID',
				LTRIM(RTRIM(LOWER(ViewName)))				'ViewName',
				LTRIM(RTRIM(LOWER(BTSynonym)))				'BTSynonym',
				HiddenViewName								'HiddenViewName',
				LTRIM(RTRIM(LOWER(HiddenViewSynonym)))		'HiddenViewSynonym',
				--LTRIM(RTRIM(LOWER(DataType)))				'DataType',
				DataType									'DataType',
				Data_Length									'Data_Length',			
				BTName										'BTName'
		FROM	#fw_des_publish_hidden_view (NOLOCK)
		WHERE	customername			=	@CustomerName
		AND		projectname				=	@ProjectName
		AND		processname				=	@ProcessName
		AND		componentname			=	@ComponentName
		AND		activityname			=	@ActivityName
		AND		uiname					=	@UIName

		--Subscription
		INSERT INTO #fw_des_publish_subscription_dataitem
			(	CustomerName,			ProjectName,			ProcessName,		ComponentName, 
				DocNo,					ActivityName,			UIName,						
				BTSynonym,				LinkType,				TargetComponent,	TargetActivity, 
				TargetIlbo,				SubscriptionName,		DataItemName,		FlowDirection, 
				SubscriptionControlID,	SubscriptionViewName )
		SELECT DISTINCT
				a.Customer_name,			a.Project_name,		a.process_name,				a.component_name,
				a.ecrno,					a.activity_name,	a.ui_name,								
				control_bt_synonym,			link_type,			sugg_publishing_comp_name,	sugg_publishing_act_name,
				sugg_publishing_ui_name,	a.subscription_name,published_bt_synonym,		published_flow_direction,
				subscribed_control_name,	subscribed_view_name				
				FROM	de_published_subscription a WITH (NOLOCK),
						de_published_resolved_link_Dataitem  b WITH (NOLOCK)
				WHERE	a.Customer_name			=	b.customer_name
				and		a.project_name			=	b.project_name
				and		a.process_name			=	b.process_name
				and		a.component_name		=	b.component_name
				and		a.ecrno					=	b.ecrno
				and		a.Activity_name			=	b.Activity_name
				and		a.Ui_name				=	b.ui_name
				and		a.subscription_name		=	b.subscription_name

				and		a.customer_name			=	@CustomerName
				AND		a.project_name			=	@ProjectName
				and		a.process_name			=	@ProcessName
				and		a.component_name		=	@ComponentName
				and		a.ecrno					=	@EcrNo	

		UPDATE	b
		SET		b.TaskName		=	a.Task_Name
		FROM	de_published_action a WITH (NOLOCK),
				#fw_des_publish_subscription_dataitem b WITH (NOLOCK)
		WHERE	a.Customer_name			=	b.customername		   COLLATE database_default 
		and		a.project_name			=	b.projectname		   COLLATE database_default 
		and		a.process_name			=	b.processname		   COLLATE database_default 
		and		a.component_name		=	b.componentname		   COLLATE database_default 
		and		a.ecrno					=	b.DocNo				   COLLATE database_default 
		and		a.Activity_name			=	b.Activityname		   COLLATE database_default 
		and		a.Ui_name				=	b.uiname			   COLLATE database_default 
		and		a.primary_control_bts	=	b.BTSynonym			   COLLATE database_default 

		and		a.customer_name			=	@CustomerName
		AND		a.project_name			=	@ProjectName
		and		a.process_name			=	@ProcessName
		and		a.component_name		=	@ComponentName
		AND		a.activity_name			=	@ActivityName
		AND		a.ui_name				=	@UIName
		and		a.ecrno					=	@EcrNo		

		UPDATE	b
		SET		b.LinkId		=	a.LinkId
		FROM	de_fw_req_publish_ilbo_linkuse_vw_fn ( @CustomerName, @ProjectName, @EcrNo ) a,
				#fw_des_publish_subscription_dataitem b WITH (NOLOCK)
		WHERE	a.Customername			=	b.customername		   COLLATE database_default 
		and		a.projectname			=	b.projectname		   COLLATE database_default 
		and		a.processname			=	b.processname		   COLLATE database_default 
		and		a.componentname			=	b.componentname		   COLLATE database_default 
		and		a.ecrno					=	b.DocNo				   COLLATE database_default 
		and		a.parentilbocode		=	b.uiname			   COLLATE database_default 
		and		a.taskname				=	b.taskname			   COLLATE database_default 

		and		b.customername			=	@CustomerName
		AND		b.projectname			=	@ProjectName
		and		b.processname			=	@ProcessName
		and		b.componentname			=	@ComponentName
		AND		b.activityname			=	@ActivityName
		AND		b.uiname				=	@UIName
		and		b.docno					=	@EcrNo	

		SELECT DISTINCT
				CustomerName								'CustomerName',
				ProjectName									'ProjectName',
				ProcessName									'ProcessName',
				ComponentName 								'ComponentName',
				DocNo										'DocNo',
				ActivityName								'ActivityName',
				UIName										'UIName',
				LTRIM(RTRIM(LOWER(TaskName)))				'TaskName',
				BTSynonym									'BTSynonym',
				LinkId										'LinkId',
				LinkType									'LinkType',
				LTRIM(RTRIM(LOWER(TargetComponent)))		'TargetComponent',
				LTRIM(RTRIM(LOWER(TargetActivity)))			'TargetActivity',
				LTRIM(RTRIM(LOWER(TargetIlbo)))				'TargetIlbo',
				LTRIM(RTRIM(LOWER(SubscriptionName)))		'SubscriptionName',
				LTRIM(RTRIM(LOWER(DataItemName)))			'DataItemName',
				--FlowDirection 								'FlowDirection',
				CASE WHEN FlowDirection = 'I' THEN '0'
						WHEN FlowDirection = 'o' THEN '1'
						WHEN FlowDirection = 'io' THEN '2' END AS 'FlowDirection', 
				LTRIM(RTRIM(LOWER(SubscriptionControlID)))	'SubscriptionControlID',
				LTRIM(RTRIM(LOWER(SubscriptionViewName)))	'SubscriptionViewName'
		FROM	#fw_des_publish_subscription_dataitem (NOLOCK)
		WHERE	customername			=	@CustomerName
		AND		projectname				=	@ProjectName
		AND		processname				=	@ProcessName
		AND		componentname			=	@ComponentName
		AND		activityname			=	@ActivityName
		AND		uiname					=	@UIName

		--Subscription
		INSERT INTO #fw_des_publish_publication_dataitem
			(	CustomerName,				ProjectName,			ProcessName,		ComponentName, 
				DocNo,						ActivityName,			UIName,				PublicationName,	
				linkid,						DataItemName,			ControlID,			ViewName, 
				FlowDirection,				IsMultiInstance )
		SELECT DISTINCT
				a.Customer_name,			a.Project_name,			a.process_name,				a.component_name,
				a.ecrno,					a.activity_name,		a.ui_name,					a.Publication_name,
				linkid,						published_bt_synonym,	published_control_name,		published_view_name, 
				published_flow_direction,	NULL				
				FROM	de_published_publication a WITH (NOLOCK),
						de_published_publication_Dataitem b WITH (NOLOCK)
				WHERE	a.Customer_name			=	b.customer_name
				and		a.project_name			=	b.project_name
				and		a.process_name			=	b.process_name
				and		a.component_name		=	b.component_name
				and		a.ecrno					=	b.ecrno
				and		a.Activity_name			=	b.Activity_name
				and		a.Ui_name				=	b.ui_name
				and		a.publication_name		=	b.publication_name

				and		a.customer_name			=	@CustomerName
				AND		a.project_name			=	@ProjectName
				and		a.process_name			=	@ProcessName
				and		a.component_name		=	@ComponentName
				and		a.ecrno					=	@EcrNo	
				and		b.published_bt_synonym	<> 'csou'
		UNION
		SELECT DISTINCT
				a.Customer_name,			a.Project_name,			a.process_name,				a.component_name,
				a.ecrno,					a.activity_name,		a.ui_name,					a.Publication_name,
				linkid,						published_bt_synonym,	'rvwrt_lctxt_ou',			'rvwrt_lctxt_ou', 
				published_flow_direction,	NULL				
				FROM	de_published_publication a WITH (NOLOCK),
						de_published_publication_Dataitem b WITH (NOLOCK)
				WHERE	a.Customer_name			=	b.customer_name
				and		a.project_name			=	b.project_name
				and		a.process_name			=	b.process_name
				and		a.component_name		=	b.component_name
				and		a.ecrno					=	b.ecrno
				and		a.Activity_name			=	b.Activity_name
				and		a.Ui_name				=	b.ui_name
				and		a.publication_name		=	b.publication_name

				and		a.customer_name			=	@CustomerName
				AND		a.project_name			=	@ProjectName
				and		a.process_name			=	@ProcessName
				and		a.component_name		=	@ComponentName
				and		a.ecrno					=	@EcrNo	
				and		b.published_bt_synonym	= 'csou'

		SELECT DISTINCT
				CustomerName						'CustomerName',
				ProjectName							'ProjectName',
				ProcessName							'ProcessName',
				ComponentName 						'ComponentName',
				DocNo								'DocNo',
				ActivityName						'ActivityName',
				UIName								'UIName',
				LTRIM(RTRIM(LOWER(PublicationName)))'PublicationName',
				linkid								'linkid',
				LTRIM(RTRIM(LOWER(DataItemName)))	'DataItemName',
				LTRIM(RTRIM(LOWER(ControlID	)))		'ControlID',
				LTRIM(RTRIM(LOWER(ViewName)))		'ViewName',
				--FlowDirection						'FlowDirection',
				CASE WHEN FlowDirection = 'I' THEN '0'
						WHEN FlowDirection = 'o' THEN '1'
						WHEN FlowDirection = 'io' THEN '2' END AS 'FlowDirection', 
				'no'							'IsMultiInstance'
		FROM	#fw_des_publish_publication_dataitem (NOLOCK)
		WHERE	customername			=	@CustomerName
		AND		projectname				=	@ProjectName
		AND		processname				=	@ProcessName
		AND		componentname			=	@ComponentName
		AND		activityname			=	@ActivityName
		AND		uiname					=	@UIName

		--Task info
		SELECT DISTINCT
				a.CustomerName							'CustomerName',
				a.ProjectName							'ProjectName',
				a.ProcessName							'ProcessName',
				a.ComponentName 						'ComponentName',
				a.EcrNo									'DocNo',
				b.Activity_Name							'ActivityName',
				parentilbocode							'UIName',
				LTRIM(RTRIM(LOWER(TaskName)))			'TaskName',
				--Task_Descr							'TaskDescription',
				--b.Task_Type								'TaskType',
				'PostHelp'								'TaskType',
				LTRIM(RTRIM(LOWER(post_task)))			'PostTask'--,
				--NULL									'PostTaskType'
		FROM	de_fw_req_publish_ilbo_linkuse_vw_fn  ( @CustomerName, @ProjectName, @EcrNo ) a
		INNER JOIN de_published_action b (NOLOCK)
		ON		a.Customername			=	b.customer_name
		and		a.projectname			=	b.project_name
		and		a.processname			=	b.process_name
		and		a.componentname			=	b.component_name
		and		a.ecrno					=	b.ecrno
		and		a.parentilbocode		=	b.ui_name
		and		a.TaskName				=	b.Task_Name

		WHERE	b.customer_name			=	@CustomerName
		AND		b.project_name			=	@ProjectName
		and		b.process_name			=	@ProcessName
		and		b.component_name		=	@ComponentName
		and		b.ecrno					=	@EcrNo	
		AND		b.Activity_Name			=	@ActivityName
		AND		b.UI_Name				=	@UIName
		AND		ISNULL(a.post_task,'') <> ''
		UNION
		SELECT DISTINCT
				a.CustomerName							'CustomerName',
				a.ProjectName							'ProjectName',
				a.ProcessName							'ProcessName',
				a.ComponentName 						'ComponentName',
				a.EcrNo									'DocNo',
				b.Activity_Name							'ActivityName',
				parentilbocode							'UIName',
				LTRIM(RTRIM(LOWER(TaskName)))			'TaskName',
				--Task_Descr							'TaskDescription',
				--b.Task_Type								'TaskType',
				'PostLink'								'TaskType',
				LTRIM(RTRIM(LOWER(post_linktask)))		'PostTask'--,
				--NULL									'PostTaskType'
		FROM	de_fw_req_publish_ilbo_linkuse_vw_fn  ( @CustomerName, @ProjectName, @EcrNo ) a
		INNER JOIN de_published_action b (NOLOCK)
		ON		a.Customername			=	b.customer_name
		and		a.projectname			=	b.project_name
		and		a.processname			=	b.process_name
		and		a.componentname			=	b.component_name
		and		a.ecrno					=	b.ecrno
		and		a.parentilbocode		=	b.ui_name
		and		a.TaskName				=	b.Task_Name

		WHERE	b.customer_name			=	@CustomerName
		AND		b.project_name			=	@ProjectName
		and		b.process_name			=	@ProcessName
		and		b.component_name		=	@ComponentName
		and		b.ecrno					=	@EcrNo	
		AND		b.Activity_Name			=	@ActivityName
		AND		b.UI_Name				=	@UIName
		AND		ISNULL(a.post_linktask,'') <> ''
		UNION
		SELECT DISTINCT
				Customer_Name						'CustomerName',
				Project_Name						'ProjectName',
				Process_Name						'ProcessName',
				Component_Name 						'ComponentName',
				EcrNo								'DocNo',
				Activity_Name						'ActivityName',
				UI_Name								'UIName',
				LTRIM(RTRIM(LOWER(Task_Name)))		'TaskName',
				--Task_Descr							'TaskDescription',
				Task_Type							'TaskType',
				NULL								'PostTask'--,
				--NULL								'PostTaskType'
		FROM	de_published_action (NOLOCK)
		WHERE	customer_name			=	@CustomerName
		AND		project_name			=	@ProjectName
		and		process_name			=	@ProcessName
		and		component_name			=	@ComponentName
		and		ecrno					=	@EcrNo	
		AND		Activity_Name			=	@ActivityName
		AND		UI_Name					=	@UIName
		AND		Task_Type				=	'Disposal'
	--TECH-72114
		INSERT INTO #fw_published_task_gql_report
			(	CustomerName,			ProjectName,			ProcessName,		ComponentName, 
				DocNo,					ActivityName,			UIName,						
				TaskName,				ReportName,				OutputFormat,		LaunchMode )
		SELECT DISTINCT
				CustomerName,			ProjectName,		processName,			ComponentName,
				DocNo,					activityName,		uiName,							
				TaskName,				ReportName,			OutputFormat,			LaunchMode
				FROM	de_published_task_gql_report  WITH (NOLOCK)
				WHERE	CustomerName			=	@CustomerName
				AND		ProjectName				=	@ProjectName
				and		ProcessName				=	@ProcessName
				and		ComponentName			=	@ComponentName
				and		DocNo					=	@EcrNo	

		SELECT DISTINCT
				LTRIM(RTRIM(LOWER(CustomerName)))	'CustomerName',
				LTRIM(RTRIM(LOWER(ProjectName)))	'ProjectName',
				LTRIM(RTRIM(LOWER(ProcessName)))	'ProcessName',
				LTRIM(RTRIM(LOWER(ComponentName))) 	'ComponentName',
				LTRIM(RTRIM(LOWER(DocNo)))			'DocNo',
				LTRIM(RTRIM(LOWER(ActivityName)))	'ActivityName',
				LTRIM(RTRIM(LOWER(UIName)))			'UIName',
				LTRIM(RTRIM(LOWER(TaskName)))		'TaskName',
				ReportName							'ReportName',
				OutputFormat						'OutputFormat',
				LaunchMode							'LaunchMode'
		FROM	#fw_published_task_gql_report (NOLOCK)
		WHERE	customername			=	@CustomerName
		AND		projectname				=	@ProjectName
		AND		processname				=	@ProcessName
		AND		componentname			=	@ComponentName
		AND		activityname			=	@ActivityName
		AND		uiname					=	@UIName

		INSERT INTO #fw_published_task_gql_report_param
			(	CustomerName,			ProjectName,			ProcessName,		ComponentName, 
				DocNo,					ActivityName,			UIName,						
				TaskName,				ReportName,				ParameterName,		BTSynonym,
				ControlID,				ViewName,				DefaultValue )
		SELECT DISTINCT
				CustomerName,			ProjectName,		processName,			componentName,
				DocNo,					activityName,		uiName,								
				TaskName,				ReportName,			ParameterName,			BTSynonym,
				ControlID,				ViewName,			DefaultValue
				FROM	de_published_task_gql_report_param a WITH (NOLOCK)
				WHERE	CustomerName			=	@CustomerName
				AND		ProjectName				=	@ProjectName
				and		ProcessName				=	@ProcessName
				and		ComponentName			=	@ComponentName
				and		DocNo					=	@EcrNo	

		SELECT DISTINCT
				LTRIM(RTRIM(LOWER(CustomerName)))	'CustomerName',
				LTRIM(RTRIM(LOWER(ProjectName)))	'ProjectName',
				LTRIM(RTRIM(LOWER(ProcessName)))	'ProcessName',
				LTRIM(RTRIM(LOWER(ComponentName))) 	'ComponentName',
				LTRIM(RTRIM(LOWER(DocNo)))			'DocNo',
				LTRIM(RTRIM(LOWER(ActivityName)))	'ActivityName',
				LTRIM(RTRIM(LOWER(UIName)))			'UIName',
				LTRIM(RTRIM(LOWER(TaskName)))		'TaskName',
				ReportName							'ReportName',
				ParameterName						'ParameterName',
				BTSynonym							'BTSynonym',
				ControlID							'ControlID',
				ViewName							'ViewName',
				DefaultValue						'DefaultValue'
		FROM	#fw_published_task_gql_report_param (NOLOCK)
		WHERE	customername			=	@CustomerName
		AND		projectname				=	@ProjectName
		AND		processname				=	@ProcessName
		AND		componentname			=	@ComponentName
		AND		activityname			=	@ActivityName
		AND		uiname					=	@UIName

	--TECH-72114

		--GraphQL Schema info

				SELECT DISTINCT TOP 1
						CustomerName			'CustomerName',		
						ProjectName				'ProjectName',	
						DocNo					'DocNo',				
						ProcessName				'ProcessName',
						ComponentName			'ComponentName',		
						SchemaVersion			'Version',		
						IntrospectionJSON		'IntrospectionJSON',	
						IntrospectionJSONDbc	'IntrospectionJSONDbc',
						SDLSchema				'SDLSchema',			
						SDLSchemaDbc			'SDLSchemaDbc',
						SDLText					'SDLSchema'
				FROM	#fw_des_publish_gql_Schema (NOLOCK)
				ORDER BY SchemaVersion desc

    SET NOCOUNT OFF 
END 

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'vw_netgen_activityschema_taskgql_xmlsp' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON vw_netgen_activityschema_taskgql_xmlsp TO PUBLIC
END
GO
