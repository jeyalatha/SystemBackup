IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ACHgqlSpactdes_fldnamLEO' AND TYPE = 'P')
    Begin
        Drop PROC ACHgqlSpactdes_fldnamLEO
    End
GO

/********************************************************************************/
/* Procedure                               : ACHgqlSpactdes_fldnamLEO			*/
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Ponmalar A/Jeya Latha K			*/
/* Date                                    : 11-JAN-2022						*/
/* rTrack ID                               : TECH-65386							*/
/* Description							   : GQL Operations						*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
/* Modified By	: Ponmalar A/Jeya Latha K										*/
/* Defect ID	: TECH-68063													*/
/* Modified on	: 21-Apr-2022													*/
/* Description	: Provision to map captions for control,column, section and Page
				  in gql engineering..											*/
/********************************************************************************/
/********************************************************************************/
/* Modified By	: Priyadharshini U												*/
/* Defect ID	: TECH-72114													*/
/* Modified on	: 22-Aug-2022													*/
/* Description	: 	Report modeling enablement in platform model for GQL based 
																user interfaces	*/
/********************************************************************************/
CREATE PROCEDURE ACHgqlSpactdes_fldnamLEO
	@ctxt_ouinstance             	ctxt_ouinstance, --Input 
	@ctxt_user                   	ctxt_user, --Input 
	@ctxt_language               	ctxt_language, --Input 
	@ctxt_service                	ctxt_service, --Input 
	@engg_gqhdr_actdescr         	engg_description, --Input 
	@engg_gqhdr_actname          	engg_name, --Input 
	@engg_gqhdr_cmpdescr         	engg_description, --Input 
	@engg_gqhdr_cmpname          	engg_name, --Input 
	@engg_gqhdr_cust             	engg_name, --Input 
	@engg_gqhdr_ecrno            	engg_name, --Input 
	@engg_gqhdr_prcname          	engg_name, --Input 
	@engg_gqhdr_prodescr         	engg_description, --Input 
	@engg_gqhdr_proj             	engg_name, --Input 
	@engg_gqhdr_taskdescr        	engg_description, --Input 
	@engg_gqhdr_tasktype         	engg_type, --Input 
	@engg_gqhdr_tskname          	engg_name, --Input 
	@engg_gqhdr_uidescr          	engg_description, --Input 
	@engg_gqhdr_uiname           	engg_name, --Input 
	@engg_gqfld_IncLayoutCtrls		engg_seqno,	--TECH-68063
	--Code Added for the Defect Id Tech-72114 starts
	@engg_gq_rep_launchmode			engg_type,
	@engg_gq_rep_oufrmt				engg_type,
	@engg_gq_rep_reportname			engg_name,	
	--Code Added for the Defect Id Tech-72114 ends
	@m_errorid                   	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	--declaration of temporary variables


	--temporary and formal parameters mapping

	Set @ctxt_user                    = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service                 = ltrim(rtrim(@ctxt_service))
	Set @engg_gqhdr_actdescr          = ltrim(rtrim(@engg_gqhdr_actdescr))
	Set @engg_gqhdr_actname           = ltrim(rtrim(@engg_gqhdr_actname))
	Set @engg_gqhdr_cmpdescr          = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cmpname           = ltrim(rtrim(@engg_gqhdr_cmpname))
	Set @engg_gqhdr_cust              = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno             = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_prcname           = ltrim(rtrim(@engg_gqhdr_prcname))
	Set @engg_gqhdr_prodescr          = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj              = ltrim(rtrim(@engg_gqhdr_proj))
	Set @engg_gqhdr_taskdescr         = ltrim(rtrim(@engg_gqhdr_taskdescr))
	Set @engg_gqhdr_tasktype          = ltrim(rtrim(@engg_gqhdr_tasktype))
	Set @engg_gqhdr_tskname           = ltrim(rtrim(@engg_gqhdr_tskname))
	Set @engg_gqhdr_uidescr           = ltrim(rtrim(@engg_gqhdr_uidescr))
	Set @engg_gqhdr_uiname            = ltrim(rtrim(@engg_gqhdr_uiname))

	--null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_gqhdr_actdescr = '~#~' 
		Select @engg_gqhdr_actdescr = null  

	IF @engg_gqhdr_actname = '~#~' 
		Select @engg_gqhdr_actname = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cmpname = '~#~' 
		Select @engg_gqhdr_cmpname = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_prcname = '~#~' 
		Select @engg_gqhdr_prcname = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  

	IF @engg_gqhdr_taskdescr = '~#~' 
		Select @engg_gqhdr_taskdescr = null  

	IF @engg_gqhdr_tasktype = '~#~' 
		Select @engg_gqhdr_tasktype = null  

	IF @engg_gqhdr_tskname = '~#~' 
		Select @engg_gqhdr_tskname = null  

	IF @engg_gqhdr_uidescr = '~#~' 
		Select @engg_gqhdr_uidescr = null  

	IF @engg_gqhdr_uiname = '~#~' 
		Select @engg_gqhdr_uiname = null  

	DECLARE @tmp_queryname		engg_description,
			@tmp_queryversion	engg_code
			

	EXEC DE_GQL_Fld_LELd_FLDName
		@ctxt_language 		= @ctxt_language,
		@ctxt_ouinstance 	= @ctxt_ouinstance,
		@ctxt_service 		= @ctxt_service,
		@ctxt_user 			= @ctxt_user,
		@CustomerName 		= @engg_gqhdr_cust,
		@ProjectName 		= @engg_gqhdr_proj,
		@EcrNo 				= @engg_gqhdr_ecrno,
		@ProcessName 		= @engg_gqhdr_prcname,
		@ComponentName 		= @engg_gqhdr_cmpname,
		@ActivityName		= @engg_gqhdr_actname,				
		@UIName				= @engg_gqhdr_uiname,
		@TaskName			= @engg_gqhdr_tskname,
		@QueryName 			= @tmp_queryname,
		@Version 			= @tmp_queryversion,
		@m_errorid 			= @m_errorid OUTPUT


	/* 
	--OutputList
		Select
		null 'engg_gqfld_datatype', 
		null 'engg_gqfld_flattenedfldname', 
		null 'engg_gqfld_ismandatoy', 
		null 'engg_gqfld_type', 
		null 'engg_gq_fieldname', 
	*/
	
Set nocount off

End




GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ACHgqlSpactdes_fldnamLEO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  ACHgqlSpactdes_fldnamLEO TO PUBLIC
END
GO



