IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DE_GQL_SaveML_Argument' AND TYPE = 'P')
    Begin
        Drop PROC DE_GQL_SaveML_Argument
    End
GO
/********************************************************************************/
/* Procedure                               : DE_GQL_SaveML_Argument			    */
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U / Jeya Latha K    */
/* Date                                    : 20-OCT-2021                        */
/* rTrack ID                               : TECH-63474                         */
/* Description							   : New Feature--GQL Operations	    */
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
/* Author                                  : Ponmalar A / Jeya Latha K			*/
/* Date                                    : 24-NOV-2021                        */
/* rTrack ID                               : TECH-64197                         */
/* Description							   : GQL Operations						*/
/********************************************************************************/  
/* Author                                  : Ponmalar A / Jeya Latha K		    */
/* Date                                    : 20-DEC-2021                        */
/* rTrack ID                               : TECH-64865                         */
/* Description							   : GQL Operations						*/
/********************************************************************************/
/* Author                                  : Ponmalar A/Jeya Latha K			*/
/* Date                                    : 11-JAN-2022						*/
/* rTrack ID                               : TECH-65386							*/
/* Description							   : GQL Operations						*/
/********************************************************************************/
/* Modified By	: Ponmalar A / Priyadharshini U									*/
/* Defect ID	: TECH-67697													*/
/* Modified on	: 31Mar2022														*/
/* Description	: GQL Changes.													*/
/********************************************************************************/
/* Modified By	: Priyadharshini U / Jeya Latha K								*/
/* Defect ID	: TECH-68063													*/
/* Modified on	: 19Apr2022														*/
/* Description	: Processing Type Validation Added.								*/
/********************************************************************************/
/* Modified By	: Ponmalar A													*/
/* Defect ID	: TECH-69326													*/
/* Modified on	: 27May2022														*/
/********************************************************************************/
CREATE PROCEDURE DE_GQL_SaveML_Argument
@Ctxt_Language                ctxt_language,
@Ctxt_OUInstance              ctxt_ouinstance,  
@Ctxt_Service                 ctxt_service,
@Ctxt_User                    ctxt_user,
@CustomerName                 engg_name,  
@ProjectName                  engg_name,   
@EcrNo                        engg_name,  
@ProcessDesc                  engg_Description,
@ProcessName                  engg_name,
@ComponentDesc                engg_Description,
@ComponentName                engg_name,
@ActivityDesc                 engg_Description,
@ActivityName                 engg_name,
@UIDesc                       engg_Description,
@UIName                       engg_name,
@TaskName                     engg_name,
@QuerySeq                     engg_seqno,
@QueryName                    engg_name,
@QueryType                    engg_code,
@QueryAlias					  engg_name,
@QueryVersion				  engg_version,
@Arguments					  engg_longdesc, 
@ArgumentsType         	      engg_type, 
@DataType     				  engg_type, 
@CtrlViewName 				  engg_varchar1000, 
@IsMandatory  				  engg_type,
@DefaultValue				  engg_name,	
@SchemaName					  engg_name,
@engg_argml_treegrd_nex       engg_name,
@engg_argml_treegrd_nid		  engg_varchar1000,
@engg_argml_treegrd_pnid	  engg_varchar1000,
@engg_gqargml_parschmaname	  engg_varchar1000,
@engg_gqargml_Protype		  engg_name,
@HdnKeyField				  engg_name,	--13639
@ModeFlag                     modeflag,
@FPRowno                      rowno,
@m_errorid				INT OUTPUT
AS
BEGIN

	SET NOCOUNT ON
	SET	@m_errorid	=	0
	
		--Temporary variable declaration
	DECLARE	@SysDate					DATETIME,
			@tmp_btsynonym				engg_name,
			@tmp_controlid				engg_name,
			@tmp_viewname				engg_name,
			@tmp_viewname_temp			engg_name,
			@tmp_ControlID_Pos			INT,
			@tmp_ViewName_Pos			INT,
			@tmp_BTSynonym_StartPos		INT,
			@tmp_BTSynonym_EndPos		INT,
			@Tmp_ControlDataType		ENGG_Name,
			@Tmp_ArgType				engg_name, --03122021
			@Tmp_Category				engg_name

	IF ISNULL(@engg_gqargml_Protype,'')= '~#~'   --16Mar2022
	BEGIN
	SELECT @engg_gqargml_Protype = NULL
	END

	SET		@SysDate	=	GETDATE()

	SELECT @FPRowno		=	 @FPRowno +1

	IF ISNULL(@engg_argml_treegrd_nid,'') <>	''
	BEGIN
		SELECT  @engg_argml_treegrd_nid	=	REPLACE (REPLACE(@engg_argml_treegrd_nid,'Query.',''),'Mutation.','')
	END

	IF ISNULL(@engg_gqargml_parschmaname,'') <>	''
	BEGIN
		SELECT  @engg_gqargml_parschmaname	=	REPLACE (REPLACE(@engg_gqargml_parschmaname,'Query.',''),'Mutation.','')
	END

	IF ISNULL (@CtrlViewName,'' ) LIKE '%-%'
	BEGIN

		SELECT @tmp_controlid			= LTRIM(RTRIM(LEFT(LTRIM(RTRIM(@CtrlViewName)), CHARINDEX('-', @CtrlViewName) - 1)))

		SELECT @tmp_viewname_temp		= LTRIM(RTRIM(RIGHT(LTRIM(RTRIM(@CtrlViewName)), LEN(LTRIM(RTRIM(@CtrlViewName))) - CHARINDEX('-', @CtrlViewName))))

		SELECT @tmp_viewname			= LEFT(@tmp_viewname_temp, (CHARINDEX('(', @tmp_viewname_temp) - 1))

		SELECT @tmp_viewname			= LTRIM(RTRIM(@tmp_viewname))

		SELECT @tmp_BTSynonym_StartPos	=	CHARINDEX ('(', @CtrlViewName) + 1

		SELECT @tmp_BTSynonym_EndPos	=	CHARINDEX (')', @CtrlViewName) - @tmp_BTSynonym_StartPos
	
		SELECT @tmp_btsynonym			=	SUBSTRING (@CtrlViewName, @tmp_BTSynonym_StartPos,@tmp_BTSynonym_EndPos)
	END

	ELSE IF ISNULL(@CtrlViewName,'' ) NOT LIKE '%-%'
	BEGIN
	   SELECT @tmp_controlid	=	@CtrlViewName,
	          @tmp_viewname		=	@CtrlViewName,
			  @tmp_btsynonym	=	@CtrlViewName
	 END

						
	--/Leaf node check  for Control ID - View Name*/
	IF ISNULL(@modeflag,'')	IN	('Y','U')
	BEGIN
		IF ISNULL( @CtrlViewName,'')	<>	'' AND  ISNULL (@SchemaName,'') <>  1
		BEGIN
			 RAISERROR('ControlID-ViewName should be mapped only for leaf nodes at rowno: %i',16,1,@FPRowno)
			 RETURN
		END
    END



	/*Null check for Query Name*/
	IF ISNULL(@QueryName,'')	=	''
	BEGIN
		 RAISERROR('Query Name cannot be blank at rowno: %i',16,1,@FPRowno)
		 RETURN
	END
  
  /*DataType Validation*/
	--14469
	IF @tmp_btsynonym IN ('Language','OUInstance','Role','Service','User')
	BEGIN
		SELECT @tmp_btsynonym = 'Ctxt_'+ @tmp_btsynonym
	END
	--14469
  	IF ISNULL(@modeflag,'')	IN	('Y','U') AND ISNULL(@SchemaName,'')	= '1' AND ISNULL(@CtrlViewName,'') <> ''
	BEGIN
	SELECT	@Tmp_ControlDataType	=	CASE WHEN data_type='char'	  THEN 'String' 
											 WHEN data_type='Integer' THEN 'Int' 
											 WHEN data_type='Numeric' THEN 'Int' 
											 WHEN data_type IN ('Date','Date-time') THEN 'LocalDateTime' 
										ELSE data_type END
	FROM	de_glossary	WITH (NOLOCK)
	WHERE	Customer_Name		=	@customername
	AND		Project_Name		=	@projectname
	AND		Process_Name		=	@processname
	AND		Component_Name		=	@componentname
	AND		bt_synonym_name		=	@tmp_btsynonym

	IF ISNULL (@DataType ,'') = 'Float'
	BEGIN
	     SELECT @DataType	=	'Int'
	END
	--14469
	IF ISNULL (@DataType ,'') = 'Decimal'
	BEGIN
	     SELECT @DataType	=	'Int'
	END
	--14469
	IF ISNULL (@DataType ,'') = 'Date'
	BEGIN
	     SELECT @DataType	=	'LocalDateTime'
	END

	IF ISNULL (@DataType ,'') = 'DateTime'
	BEGIN
	     SELECT @DataType	=	'LocalDateTime'
	END

	--select 'tt',@Tmp_ControlDataType,@DataType
	IF ISNULL(@Tmp_ControlDataType,'')	<>	@DataType AND @tmp_btsynonym NOT IN ('modeflag','rowno')  --15dec2021
	BEGIN
			RAISERROR('Datatype should be same as the Argument Datatype at rowno: %i',16,1,@FPRowno)
	RETURN
	END

	END
	
	DECLARE @tmpQueryname engg_name
	SELECT 	@tmpQueryname = CASE WHEN @QueryName like '%.%' THEN SUBSTRING(@QueryName,1,CHARINDEX('.',@QueryName)-1) ELSE @QueryName END	--28feb2022

	--Code Added for the DefectId TECH-68063 starts
	IF ISNULL (@ArgumentsType,'')	NOT IN ('Array','List') AND ISNULL(@engg_gqargml_protype,'')	IN ('PSR','PMR','PSMR')
		BEGIN
			RAISERROR('Processing type is applicable only for the datatype Array & List.',16,1)
			RETURN
		END
	--Code Added for the DefectId TECH-68063 Ends

	/* Code added by 14469 (03Dec2021)*/
	SELECT	@Tmp_Category = CASE WHEN category IN ( 'Arg', 'Field') THEN 'Argument' ELSE category END,   --   'Field' added on 19Jan2022 by 14469 --@Tmp_Category
			@Tmp_ArgType  =	typekind  --11May2022
	FROM	fw_graphql_arg_fields WITH (NOLOCK)
	WHERE CustomerName	=	@CustomerName
	AND   ProjectName	=	@ProjectName
	AND   ProcessName	=	@ProcessName
	AND   ComponentName	=	@ComponentName
	AND	  importversion	=	@QueryVersion
	--AND   QueryName		=	@QueryName
	AND	  REPLACE (REPLACE(QueryName,'Query.',''),'Mutation.','')	=	@tmpQueryname --@QueryName  --14469 (06Dec2021)
	AND	  REPLACE (REPLACE([key],'Query.',''),'Mutation.','')		=	@engg_argml_treegrd_nid  ---14dec2021
	/* Code added by 14469	(03Dec2021)*/



	IF ISNULL(@modeflag,'')	IN	('Y','U')
	BEGIN
			IF ISNULL(@SchemaName,'')	= '1' AND ISNULL(@CtrlViewName,'') <> '' and isnull(@DefaultValue,'') = ''     --Code added for TECH-65386 (@DefaultValue)
			BEGIN
					    IF NOT EXISTS( SELECT 'X'
						               FROM de_task_gql_argument_mapping WITH (NOLOCK)
									   WHERE CustomerName	=	@CustomerName
									   AND   ProjectName	=	@ProjectName
									   AND   ProcessName	=	@ProcessName
									   AND   ComponentName	=	@ComponentName
									   AND   ActivityName	=	@ActivityName
									   AND   UIName			=	@UIName
									   AND   TaskName		=	@TaskName
									   AND	 KeyField		=	@HdnKeyField	--TECH-67697
									   --AND   QuerySequence	=	@QuerySeq
									   --AND   QueryName		=	@tmpQueryname --28feb2022
									   AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid
									)
						BEGIN
							INSERT INTO de_task_gql_argument_mapping 
									(	CustomerName,				ProjectName,			DocNo,			ProcessName,	
										ComponentName,				ActivityName,			UIName,			TaskName,	
										QuerySequence,				QueryName,				Argument,		ControlID,
										ViewName,					ArgumentType,			DataType,		IsMandatory,	
										BTSynonym,					DefaultValue,			TimeStamp,		[Version],		
										CreatedBy,					CreatedDate,			ModifiedBy,		ModifiedDate,
										FlattenedArgumentName,		
										ChildQueryName,					--28feb2022
										ProcessingType,				KeyField,	--02Mar2022		--TECH-67697
										Category)                    --11May2022
							SELECT		@CustomerName,			    @ProjectName,		    @EcrNo,			@ProcessName,	
										@ComponentName,				@ActivityName,			@UIName,		@TaskName,	
										@QuerySeq,					@tmpQueryname,           --28feb2022  
										@Arguments,					@tmp_controlid,			
										@tmp_viewname,				@Tmp_Category,			@DataType,		@IsMandatory,   --	 Code added by 14469 (@Tmp_ArgType) on 03Dec2021
										@tmp_btsynonym,				@DefaultValue,			1,				@QueryVersion,	
										@ctxt_user,					@sysdate,				@ctxt_user,		@sysdate,
								      -- @engg_argml_treegrd_nid
									  @engg_gqargml_parschmaname,
									  CASE WHEN @QueryName like '%.%' THEN SUBSTRING(@QueryName,CHARINDEX('.',@QueryName)+1,LEN(@QueryName)) ELSE '' END, --28feb2022
									  @engg_gqargml_Protype,		@HdnKeyField,	--TECH-67697
									  @Tmp_Category



					   END

			ELSE  	IF EXISTS (	SELECT 'X'
								FROM  de_task_gql_argument_mapping WITH (NOLOCK)
								WHERE CustomerName	=	@CustomerName
								AND   ProjectName	=	@ProjectName
								AND   ProcessName	=	@ProcessName
								AND   ComponentName	=	@ComponentName
								AND   ActivityName	=	@ActivityName
								AND   UIName		=	@UIName
								AND   TaskName		=	@TaskName
								AND	  keyField		=	@HdnKeyField	--TECH-67697
								--AND   QuerySequence	=	@QuerySeq
								--AND   QueryName		=	@tmpQueryname --28feb2022	--TECH-67697
								AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid )
		   BEGIN
					UPDATE	de_task_gql_argument_mapping
					SET		ControlID		=	@tmp_controlid,
							ViewName		=	@tmp_viewname,
							BTSynonym		=	@tmp_btsynonym,
							DefaultValue	=   @DefaultValue,
							ProcessingType	=	@engg_gqargml_Protype,	--02Mar2022
							ModifiedBy		=	@ctxt_user,
							Modifieddate	=	@sysdate
					WHERE CustomerName		=	@CustomerName
					AND   ProjectName		=	@ProjectName
					AND   ProcessName		=	@ProcessName
					AND   ComponentName		=	@ComponentName
					AND   ActivityName		=	@ActivityName
					AND   UIName			=	@UIName
					AND   TaskName			=	@TaskName
					AND	  keyField			=	@HdnKeyField	--TECH-67697
					--AND   QuerySequence		=	@QuerySeq
				 --   AND   QueryName			=	@tmpQueryname --28feb2022	--TECH-67697
					AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid

		   END
	  END
	  	  	/*Code added for TECH-65386 starts*/

	  	  	IF ISNULL(@modeflag,'')	IN	('Y','U')
	BEGIN
			IF ISNULL(@SchemaName,'')	= '1' AND ISNULL(@CtrlViewName,'') <> '' and isnull(@DefaultValue,'') <> ''
			BEGIN
					    IF NOT EXISTS( SELECT 'X'
						               FROM de_task_gql_argument_mapping WITH (NOLOCK)
									   WHERE CustomerName	=	@CustomerName
									   AND   ProjectName	=	@ProjectName
									   AND   ProcessName	=	@ProcessName
									   AND   ComponentName	=	@ComponentName
									   AND   ActivityName	=	@ActivityName
									   AND   UIName			=	@UIName
									   AND   TaskName		=	@TaskName
									   AND	 KeyField		=	@HdnKeyField	--TECH-67697
									   --AND   QuerySequence	=	@QuerySeq
									   --AND   QueryName		=	@tmpQueryname		--28feb2022
									   AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid
									)
						BEGIN
							INSERT INTO de_task_gql_argument_mapping 
									(	CustomerName,				ProjectName,			DocNo,			ProcessName,	
										ComponentName,				ActivityName,			UIName,			TaskName,	
										QuerySequence,				QueryName,				
										Argument,					ControlID,
										ViewName,					ArgumentType,			DataType,		IsMandatory,	
										BTSynonym,					DefaultValue,			TimeStamp,		[Version],		
										CreatedBy,					CreatedDate,			ModifiedBy,		ModifiedDate,
										FlattenedArgumentName,		
										ChildQueryName,			--28feb2022
										ProcessingType,				KeyField,			--02Mar2022		--TECH-67697
										Category)  --11May2022		
							SELECT		@CustomerName,			    @ProjectName,		    @EcrNo,			@ProcessName,	
										@ComponentName,				@ActivityName,			@UIName,		@TaskName,	
										@QuerySeq,					@tmpQueryname, --28feb2022             
										@Arguments,					@tmp_controlid,			
										@tmp_viewname,				@Tmp_Category,			@DataType,		@IsMandatory,   --	 Code added by 14469 (@Tmp_ArgType) on 03Dec2021
										@tmp_btsynonym,				@DefaultValue,			1,				@QueryVersion,	
										@ctxt_user,					@sysdate,				@ctxt_user,		@sysdate,
								      -- @engg_argml_treegrd_nid
									  @engg_gqargml_parschmaname,	
									  CASE WHEN @QueryName like '%.%' THEN SUBSTRING(@QueryName,CHARINDEX('.',@QueryName)+1,LEN(@QueryName)) ELSE '' END, --28feb2022
									    @engg_gqargml_Protype,		@HdnKeyField,	--TECH-67697
										@Tmp_Category
					   END

			ELSE  	IF EXISTS (	SELECT 'X'
								FROM  de_task_gql_argument_mapping WITH (NOLOCK)
								WHERE CustomerName	=	@CustomerName
								AND   ProjectName	=	@ProjectName
								AND   ProcessName	=	@ProcessName
								AND   ComponentName	=	@ComponentName
								AND   ActivityName	=	@ActivityName
								AND   UIName		=	@UIName
								AND   TaskName		=	@TaskName
								AND   KeyField		=	@HdnKeyField	--TECH-67697
								--AND   QuerySequence	=	@QuerySeq
								--AND   QueryName		=	@tmpQueryname		--28feb2022
								AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid )
		   BEGIN
					UPDATE	de_task_gql_argument_mapping
					SET		ControlID		=	@tmp_controlid,
							ViewName		=	@tmp_viewname,
							BTSynonym		=	@tmp_btsynonym,
							DefaultValue	=   @DefaultValue,
							ProcessingType	=	@engg_gqargml_Protype,
							ModifiedBy		=	@ctxt_user,
							Modifieddate	=	@sysdate
					WHERE CustomerName		=	@CustomerName
					AND   ProjectName		=	@ProjectName
					AND   ProcessName		=	@ProcessName
					AND   ComponentName		=	@ComponentName
					AND   ActivityName		=	@ActivityName
					AND   UIName			=	@UIName
					AND   TaskName			=	@TaskName
					AND	  KeyField			=	@HdnKeyField	--TECH-67697
					--AND   QuerySequence		=	@QuerySeq		--13639
				 --   AND   QueryName			=	@tmpQueryname --28feb2022	--13639
					AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid

		   END
	  END
	  END


			
	IF ISNULL(@modeflag,'')	IN	('Y','U')
	BEGIN
			IF ISNULL(@SchemaName,'')	= '1' AND ISNULL(@CtrlViewName,'') = '' and isnull(@DefaultValue,'') <> ''
			BEGIN
					    IF NOT EXISTS( SELECT 'X'
						               FROM de_task_gql_argument_mapping WITH (NOLOCK)
									   WHERE CustomerName	=	@CustomerName
									   AND   ProjectName	=	@ProjectName
									   AND   ProcessName	=	@ProcessName
									   AND   ComponentName	=	@ComponentName
									   AND   ActivityName	=	@ActivityName
									   AND   UIName			=	@UIName
									   AND   TaskName		=	@TaskName
									   AND	 KeyField		=	@HdnKeyField	--TECH-67697
									   --AND   QuerySequence	=	@QuerySeq
									   --AND   QueryName		=	@tmpQueryname --28feb2022
									   AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid
									)
						BEGIN

							INSERT INTO de_task_gql_argument_mapping 
									(	CustomerName,				ProjectName,			DocNo,			ProcessName,	
										ComponentName,				ActivityName,			UIName,			TaskName,	
										QuerySequence,				QueryName,				
										Argument,					ControlID,
										ViewName,					ArgumentType,			DataType,		IsMandatory,	
										BTSynonym,					DefaultValue,			TimeStamp,		[Version],		
										CreatedBy,					CreatedDate,			ModifiedBy,		ModifiedDate,
										FlattenedArgumentName,		ChildQueryName,	 --28feb2022
										ProcessingType,				KeyField,	--02Mar2022		--TECH-67697
										Category)	--11May2022
							SELECT		@CustomerName,			    @ProjectName,		    @EcrNo,			@ProcessName,	
										@ComponentName,				@ActivityName,			@UIName,		@TaskName,	
										@QuerySeq,					@tmpqueryname, --28feb2022,             
										@Arguments,					@tmp_controlid,			
										@tmp_viewname,				@Tmp_Category,			@DataType,		@IsMandatory,   --	 Code added by 14469 (@Tmp_ArgType) on 03Dec2021
										@tmp_btsynonym,				@DefaultValue,			1,				@QueryVersion,	
										@ctxt_user,					@sysdate,				@ctxt_user,		@sysdate,
								      -- @engg_argml_treegrd_nid
									    @engg_gqargml_parschmaname,
										CASE WHEN @QueryName like '%.%' THEN SUBSTRING(@QueryName,CHARINDEX('.',@QueryName)+1,LEN(@QueryName)) ELSE '' END, --28feb2022
										@engg_gqargml_Protype,		@HdnKeyField,	--TECH-67697	
										@Tmp_Category


					   END
			ELSE  	IF EXISTS (	SELECT 'X'
								FROM  de_task_gql_argument_mapping WITH (NOLOCK)
								WHERE CustomerName	=	@CustomerName
								AND   ProjectName	=	@ProjectName
								AND   ProcessName	=	@ProcessName
								AND   ComponentName	=	@ComponentName
								AND   ActivityName	=	@ActivityName
								AND   UIName		=	@UIName
								AND   TaskName		=	@TaskName
								AND	  KeyField		=	@HdnKeyField	--TECH-67697
								--AND   QuerySequence	=	@QuerySeq
								--AND   QueryName		=	@tmpQueryname	--28feb2022
								AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid)
		   BEGIN
					UPDATE	de_task_gql_argument_mapping
					SET		ControlID		=	@tmp_controlid,
							ViewName		=	@tmp_viewname,
							BTSynonym		=	@tmp_btsynonym,
							DefaultValue	=   @DefaultValue,
							ProcessingType	=	@engg_gqargml_Protype,	--02Mar2022
							ModifiedBy		=	@ctxt_user,
							Modifieddate	=	@sysdate
					WHERE CustomerName		=	@CustomerName
					AND   ProjectName		=	@ProjectName
					AND   ProcessName		=	@ProcessName
					AND   ComponentName		=	@ComponentName
					AND   ActivityName		=	@ActivityName
					AND   UIName			=	@UIName
					AND   TaskName			=	@TaskName
					AND	  KeyField			=	@HdnKeyField	--TECH-67697
					--AND   QuerySequence		=	@QuerySeq
				 --   AND   QueryName			=	@tmpQueryname	--28feb2022
					AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid

		   END
		END
	END

/*Code added for TECH-65386 ends*/

	/* Code added for the Defect id TECH-67697 starts */
	IF ISNULL(@modeflag,'')	IN	('Y','U')
	BEGIN
			IF ISNULL(@SchemaName,'')	= '1' AND @engg_gqargml_Protype	<>	''AND ISNULL(@CtrlViewName,'')	= '' and isnull(@DefaultValue,'') = ''     --Code added for TECH-65386 (@DefaultValue)	--TECH-68063
			BEGIN

					    IF NOT EXISTS( SELECT 'X'
						               FROM de_task_gql_argument_mapping WITH (NOLOCK)
									   WHERE CustomerName	=	@CustomerName
									   AND   ProjectName	=	@ProjectName
									   AND   ProcessName	=	@ProcessName
									   AND   ComponentName	=	@ComponentName
									   AND   ActivityName	=	@ActivityName
									   AND   UIName			=	@UIName
									   AND   TaskName		=	@TaskName
									   AND	  KeyField		=	@HdnKeyField	
									   --AND   QuerySequence	=	@QuerySeq
									   --AND   QueryName		=	@tmpQueryname --28feb2022
									   AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid
									)
						BEGIN
							INSERT INTO de_task_gql_argument_mapping 
									(	CustomerName,				ProjectName,			DocNo,			ProcessName,	
										ComponentName,				ActivityName,			UIName,			TaskName,	
										QuerySequence,				QueryName,				Argument,		ControlID,
										ViewName,					ArgumentType,			DataType,		IsMandatory,	
										BTSynonym,					DefaultValue,			TimeStamp,		[Version],		
										CreatedBy,					CreatedDate,			ModifiedBy,		ModifiedDate,
										FlattenedArgumentName,		
										ChildQueryName,					--28feb2022
										ProcessingType,				KeyField,	--02Mar2022	--13639
										Category)	--11May2022
							SELECT		@CustomerName,			    @ProjectName,		    @EcrNo,			@ProcessName,	
										@ComponentName,				@ActivityName,			@UIName,		@TaskName,	
										@QuerySeq,					@tmpQueryname,           --28feb2022  
										@Arguments,					@tmp_controlid,			
										@tmp_viewname,				@Tmp_ArgType,			@DataType,		@IsMandatory,   --	 Code added by 14469 (@Tmp_ArgType) on 03Dec2021
										@tmp_btsynonym,				@DefaultValue,			1,				@QueryVersion,	
										@ctxt_user,					@sysdate,				@ctxt_user,		@sysdate,
								      -- @engg_argml_treegrd_nid
									  @engg_gqargml_parschmaname,
									  CASE WHEN @QueryName like '%.%' THEN SUBSTRING(@QueryName,CHARINDEX('.',@QueryName)+1,LEN(@QueryName)) ELSE '' END, --28feb2022
									  @engg_gqargml_Protype,		@HdnKeyField,	--13639
									  @Tmp_Category



					   END

			ELSE  	IF EXISTS (	SELECT 'X'
								FROM  de_task_gql_argument_mapping WITH (NOLOCK)
								WHERE CustomerName	=	@CustomerName
								AND   ProjectName	=	@ProjectName
								AND   ProcessName	=	@ProcessName
								AND   ComponentName	=	@ComponentName
								AND   ActivityName	=	@ActivityName
								AND   UIName		=	@UIName
								AND   TaskName		=	@TaskName
								AND	  KeyField		=	@HdnKeyField
								--AND   QuerySequence	=	@QuerySeq
								--AND   QueryName		=	@tmpQueryname --28feb2022
								AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid )
		   BEGIN
					UPDATE	de_task_gql_argument_mapping
					SET		ControlID		=	@tmp_controlid,
							ViewName		=	@tmp_viewname,
							BTSynonym		=	@tmp_btsynonym,
							DefaultValue	=   @DefaultValue,
							ProcessingType	=	@engg_gqargml_Protype,	--02Mar2022
							ModifiedBy		=	@ctxt_user,
							Modifieddate	=	@sysdate
					WHERE CustomerName		=	@CustomerName
					AND   ProjectName		=	@ProjectName
					AND   ProcessName		=	@ProcessName
					AND   ComponentName		=	@ComponentName
					AND   ActivityName		=	@ActivityName
					AND   UIName			=	@UIName
					AND   TaskName			=	@TaskName
					AND	  KeyField			=	@HdnKeyField	--13639
					--AND   QuerySequence		=	@QuerySeq
				 --   AND   QueryName			=	@tmpQueryname --28feb2022	--13639
					AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid

		   END
	  END
	END
	/* Code added for the Defect id TECH-67697 Ends*/


		IF ISNULL(@CtrlViewName,'')	=	''	AND		ISNULL(@DefaultValue,'')	=	''  AND ISNULL(@engg_gqargml_Protype,'')	=	'' ---Code modified for TECH-65386	--02Mar2022
		BEGIN
			IF  EXISTS( SELECT 'X'
						FROM de_task_gql_argument_mapping WITH (NOLOCK)
						WHERE CustomerName	=	@CustomerName
					    AND   ProjectName	=	@ProjectName
						AND   ProcessName	=	@ProcessName
						AND   ComponentName	=	@ComponentName
					    AND   ActivityName	=	@ActivityName
						AND   UIName		=	@UIName
						AND   TaskName		=	@TaskName
						AND	  KeyField		=	@HdnKeyField	--13639
						--AND   QuerySequence	=	@QuerySeq
						--AND   QueryName		=	@tmpQueryname	--28feb2022
						AND	  FlattenedArgumentName	=	@engg_argml_treegrd_nid )
            BEGIN
					  DELETE 
					  FROM	de_task_gql_argument_mapping
					  WHERE CustomerName	=	@CustomerName
					  AND   ProjectName		=	@ProjectName
					  AND   ProcessName		=	@ProcessName
					  AND   ComponentName	=	@ComponentName
					  AND   ActivityName	=	@ActivityName
					  AND   UIName			=	@UIName
					  AND   TaskName		=	@TaskName
					  AND	KeyField		=	@HdnKeyField	--TECH-67697
					  --AND   QuerySequence	=	@QuerySeq
					  --AND   QueryName		=	@tmpQueryname	--28feb2022	--TECH-67697
					  AND	FlattenedArgumentName	=	@engg_argml_treegrd_nid
		   END

	END
	END		
	
	SELECT @FPRowno 'fprowno'

SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DE_GQL_SaveML_Argument' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  DE_GQL_SaveML_Argument TO PUBLIC
END
GO









