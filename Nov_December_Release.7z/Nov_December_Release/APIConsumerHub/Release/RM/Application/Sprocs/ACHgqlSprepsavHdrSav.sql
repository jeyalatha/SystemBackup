IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ACHgqlSprepsavHdrSav' AND TYPE='P')
   BEGIN
        DROP PROC ACHgqlSprepsavHdrSav
   END
GO
/********************************************************************************/
/* Procedure                               :  ACHgqlSprepsavHdrSav              */
/* Description                             :                                    */
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :                                    */
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U        			*/
/* Date                                    : 20-Aug-2022                        */
/* rTrack ID                               : TECH-72114                         */
/* Description                             : Report modeling enablement in 
									platform model for GQL based user interfaces*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
create Procedure ACHgqlSprepsavHdrSav
	@ctxt_ouinstance        	ctxt_ouinstance, --Input 
	@ctxt_user              	ctxt_user, --Input 
	@ctxt_language          	ctxt_language, --Input 
	@ctxt_service           	ctxt_service, --Input 
	@engg_gqhdr_actdescr    	engg_description, --Input 
	@engg_gqhdr_actname     	engg_name, --Input 
	@engg_gqhdr_cmpdescr    	engg_description, --Input 
	@engg_gqhdr_cmpname     	engg_name, --Input 
	@engg_gqhdr_cust        	engg_name, --Input 
	@engg_gqhdr_ecrno       	engg_name, --Input 
	@engg_gqhdr_isgql       	engg_flag, --Input 
	@engg_gqhdr_prcname     	engg_name, --Input 
	@engg_gqhdr_prodescr    	engg_description, --Input 
	@engg_gqhdr_proj        	engg_name, --Input 
	@engg_gqhdr_taskdescr   	engg_description, --Input 
	@engg_gqhdr_tasktype    	engg_type, --Input 
	@engg_gqhdr_tskname     	engg_name, --Input 
	@engg_gqhdr_uidescr     	engg_description, --Input 
	@engg_gqhdr_uiname      	engg_name, --Input 
	@engg_gq_rep_launchmode 	engg_type, --Input 
	@engg_gq_rep_oufrmt     	engg_type, --Input 
	@engg_gq_rep_reportname 	engg_name, --Input 
	@m_errorid              	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user               = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service            = ltrim(rtrim(@ctxt_service))
	Set @engg_gqhdr_actdescr     = ltrim(rtrim(@engg_gqhdr_actdescr))
	Set @engg_gqhdr_actname      = ltrim(rtrim(@engg_gqhdr_actname))
	Set @engg_gqhdr_cmpdescr     = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cmpname      = ltrim(rtrim(@engg_gqhdr_cmpname))
	Set @engg_gqhdr_cust         = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno        = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_isgql        = ltrim(rtrim(@engg_gqhdr_isgql))
	Set @engg_gqhdr_prcname      = ltrim(rtrim(@engg_gqhdr_prcname))
	Set @engg_gqhdr_prodescr     = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj         = ltrim(rtrim(@engg_gqhdr_proj))
	Set @engg_gqhdr_taskdescr    = ltrim(rtrim(@engg_gqhdr_taskdescr))
	Set @engg_gqhdr_tasktype     = ltrim(rtrim(@engg_gqhdr_tasktype))
	Set @engg_gqhdr_tskname      = ltrim(rtrim(@engg_gqhdr_tskname))
	Set @engg_gqhdr_uidescr      = ltrim(rtrim(@engg_gqhdr_uidescr))
	Set @engg_gqhdr_uiname       = ltrim(rtrim(@engg_gqhdr_uiname))
	Set @engg_gq_rep_launchmode  = ltrim(rtrim(@engg_gq_rep_launchmode))
	Set @engg_gq_rep_oufrmt      = ltrim(rtrim(@engg_gq_rep_oufrmt))
	Set @engg_gq_rep_reportname  = ltrim(rtrim(@engg_gq_rep_reportname))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_gqhdr_actdescr = '~#~' 
		Select @engg_gqhdr_actdescr = null  

	IF @engg_gqhdr_actname = '~#~' 
		Select @engg_gqhdr_actname = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cmpname = '~#~' 
		Select @engg_gqhdr_cmpname = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_isgql = '~#~' 
		Select @engg_gqhdr_isgql = null  

	IF @engg_gqhdr_prcname = '~#~' 
		Select @engg_gqhdr_prcname = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  

	IF @engg_gqhdr_taskdescr = '~#~' 
		Select @engg_gqhdr_taskdescr = null  

	IF @engg_gqhdr_tasktype = '~#~' 
		Select @engg_gqhdr_tasktype = null  

	IF @engg_gqhdr_tskname = '~#~' 
		Select @engg_gqhdr_tskname = null  

	IF @engg_gqhdr_uidescr = '~#~' 
		Select @engg_gqhdr_uidescr = null  

	IF @engg_gqhdr_uiname = '~#~' 
		Select @engg_gqhdr_uiname = null  

	IF @engg_gq_rep_launchmode = '~#~' 
		Select @engg_gq_rep_launchmode = null  

	IF @engg_gq_rep_oufrmt = '~#~' 
		Select @engg_gq_rep_oufrmt = null  

	IF @engg_gq_rep_reportname = '~#~' 
		Select @engg_gq_rep_reportname = null  

	IF ISNULL(@engg_gq_rep_reportname,'')	=	''
		BEGIN
			RAISERROR('ReportName Cannot be Null',16,1)
			RETURN
		END
	
			--IF NOT EXISTS ( SELECT 'X'
			--				FROM	de_task_gql_report_param WITH (NOLOCK)
			--				WHERE	CustomerName	=	@engg_gqhdr_cust
			--				AND		ProjectName		=	@engg_gqhdr_proj
			--				AND		ProcessName		=	@engg_gqhdr_prcname
			--				AND		ComponentName	=	@engg_gqhdr_cmpname
			--				AND		ActivityName	=	@engg_gqhdr_actname
			--				AND		UIName			=	@engg_gqhdr_uiname
			--				AND		TaskName		=	@engg_gqhdr_tskname )
			--		BEGIN
			--		IF ISNULL(@engg_gq_rep_reportname,'')	=	'' AND ISNULL(@engg_gq_rep_oufrmt,'') =	''AND ISNULL(@engg_gq_rep_launchmode,'')	=	''
			--			BEGIN
			--				DELETE 
			--				FROM	de_task_gql_report
			--				WHERE	CustomerName	=	@engg_gqhdr_cust
			--				AND		ProjectName		=	@engg_gqhdr_proj
			--				AND		ProcessName		=	@engg_gqhdr_prcname
			--				AND		ComponentName	=	@engg_gqhdr_cmpname
			--				AND		ActivityName	=	@engg_gqhdr_actname
			--				AND		UIName			=	@engg_gqhdr_uiname
			--				AND		TaskName		=	@engg_gqhdr_tskname
			--			END
			--		END



	/* 
	-- OutputList
	Select
		null 'fprowno', 
	*/

	Set nocount off
End
GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ACHgqlSprepsavHdrSav' AND TYPE='P')
BEGIN
    GRANT EXEC ON  ACHgqlSprepsavHdrSav TO PUBLIC
END
GO





