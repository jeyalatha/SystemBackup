IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='ACHgqlSprepsavrepgrd' AND TYPE='P')
   BEGIN
        DROP PROC ACHgqlSprepsavrepgrd
   END
GO
/********************************************************************************/
/* Procedure                               : ACHgqlSprepsavrepgrd               */
/* Description                             :                                    */
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :                                    */
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U			        */
/* Date                                    : 20-Aug-2022                        */
/* rTrack ID                               : TECH-72114                         */
/* Description                             : Report modeling enablement in 
									platform model for GQL based user interfaces*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/

create Procedure ACHgqlSprepsavrepgrd
	@ctxt_ouinstance          	ctxt_ouinstance, --Input 
	@ctxt_user                	ctxt_user, --Input 
	@ctxt_language            	ctxt_language, --Input 
	@ctxt_service             	ctxt_service, --Input 
	@engg_gqhdr_actdescr      	engg_description, --Input 
	@engg_gqhdr_actname       	engg_name, --Input 
	@engg_gqhdr_cmpdescr      	engg_description, --Input 
	@engg_gqhdr_cmpname       	engg_name, --Input 
	@engg_gqhdr_cust          	engg_name, --Input 
	@engg_gqhdr_ecrno         	engg_name, --Input 
	@engg_gqhdr_isgql         	engg_flag, --Input 
	@engg_gqhdr_prcname       	engg_name, --Input 
	@engg_gqhdr_prodescr      	engg_description, --Input 
	@engg_gqhdr_proj          	engg_name, --Input 
	@engg_gqhdr_taskdescr     	engg_description, --Input 
	@engg_gqhdr_tasktype      	engg_type, --Input 
	@engg_gqhdr_tskname       	engg_name, --Input 
	@engg_gqhdr_uidescr       	engg_description, --Input 
	@engg_gqhdr_uiname        	engg_name, --Input 
	@engg_gq_rep_caption      	engg_description, --Input 
	@engg_gq_rep_controlbtsyn 	engg_name, --Input 
	@engg_gq_rep_ctrlid       	engg_name, --Input 
	@engg_gq_rep_defvalue     	engg_name, --Input 
	@engg_gq_rep_launchmode   	engg_type, --Input 
	@engg_gq_rep_oufrmt       	engg_type, --Input 
	@engg_gq_rep_paramname    	engg_name, --Input 
	@engg_gq_rep_reportname   	engg_name, --Input 
	@engg_gq_rep_viewname     	engg_name, --Input 
	@modeflag                 	modeflag, --Input 
	@fpRowNo					Rowno,		--Input 
	@m_errorid                	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                 = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service              = ltrim(rtrim(@ctxt_service))
	Set @engg_gqhdr_actdescr       = ltrim(rtrim(@engg_gqhdr_actdescr))
	Set @engg_gqhdr_actname        = ltrim(rtrim(@engg_gqhdr_actname))
	Set @engg_gqhdr_cmpdescr       = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cmpname        = ltrim(rtrim(@engg_gqhdr_cmpname))
	Set @engg_gqhdr_cust           = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno          = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_isgql          = ltrim(rtrim(@engg_gqhdr_isgql))
	Set @engg_gqhdr_prcname        = ltrim(rtrim(@engg_gqhdr_prcname))
	Set @engg_gqhdr_prodescr       = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj           = ltrim(rtrim(@engg_gqhdr_proj))
	Set @engg_gqhdr_taskdescr      = ltrim(rtrim(@engg_gqhdr_taskdescr))
	Set @engg_gqhdr_tasktype       = ltrim(rtrim(@engg_gqhdr_tasktype))
	Set @engg_gqhdr_tskname        = ltrim(rtrim(@engg_gqhdr_tskname))
	Set @engg_gqhdr_uidescr        = ltrim(rtrim(@engg_gqhdr_uidescr))
	Set @engg_gqhdr_uiname         = ltrim(rtrim(@engg_gqhdr_uiname))
	Set @engg_gq_rep_caption       = ltrim(rtrim(@engg_gq_rep_caption))
	Set @engg_gq_rep_controlbtsyn  = ltrim(rtrim(@engg_gq_rep_controlbtsyn))
	Set @engg_gq_rep_ctrlid        = ltrim(rtrim(@engg_gq_rep_ctrlid))
	Set @engg_gq_rep_defvalue      = ltrim(rtrim(@engg_gq_rep_defvalue))
	Set @engg_gq_rep_launchmode    = ltrim(rtrim(@engg_gq_rep_launchmode))
	Set @engg_gq_rep_oufrmt        = ltrim(rtrim(@engg_gq_rep_oufrmt))
	Set @engg_gq_rep_paramname     = ltrim(rtrim(@engg_gq_rep_paramname))
	Set @engg_gq_rep_reportname    = ltrim(rtrim(@engg_gq_rep_reportname))
	Set @engg_gq_rep_viewname      = ltrim(rtrim(@engg_gq_rep_viewname))
	Set @modeflag                  = ltrim(rtrim(@modeflag))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_gqhdr_actdescr = '~#~' 
		Select @engg_gqhdr_actdescr = null  

	IF @engg_gqhdr_actname = '~#~' 
		Select @engg_gqhdr_actname = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cmpname = '~#~' 
		Select @engg_gqhdr_cmpname = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_isgql = '~#~' 
		Select @engg_gqhdr_isgql = null  

	IF @engg_gqhdr_prcname = '~#~' 
		Select @engg_gqhdr_prcname = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  

	IF @engg_gqhdr_taskdescr = '~#~' 
		Select @engg_gqhdr_taskdescr = null  

	IF @engg_gqhdr_tasktype = '~#~' 
		Select @engg_gqhdr_tasktype = null  

	IF @engg_gqhdr_tskname = '~#~' 
		Select @engg_gqhdr_tskname = null  

	IF @engg_gqhdr_uidescr = '~#~' 
		Select @engg_gqhdr_uidescr = null  

	IF @engg_gqhdr_uiname = '~#~' 
		Select @engg_gqhdr_uiname = null  

	IF @engg_gq_rep_caption = '~#~' 
		Select @engg_gq_rep_caption = null  

	IF @engg_gq_rep_controlbtsyn = '~#~' 
		Select @engg_gq_rep_controlbtsyn = null  

	IF @engg_gq_rep_ctrlid = '~#~' 
		Select @engg_gq_rep_ctrlid = null  

	IF @engg_gq_rep_defvalue = '~#~' 
		Select @engg_gq_rep_defvalue = null  

	IF @engg_gq_rep_launchmode = '~#~' 
		Select @engg_gq_rep_launchmode = null  

	IF @engg_gq_rep_oufrmt = '~#~' 
		Select @engg_gq_rep_oufrmt = null  

	IF @engg_gq_rep_paramname = '~#~' 
		Select @engg_gq_rep_paramname = null  

	IF @engg_gq_rep_reportname = '~#~' 
		Select @engg_gq_rep_reportname = null  

	IF @engg_gq_rep_viewname = '~#~' 
		Select @engg_gq_rep_viewname = null  

	IF @modeflag = '~#~' 
		Select @modeflag = null  
	SELECT 	@FPRowno	=   @FPRowno +	1

	IF ISNULL(@engg_gq_rep_paramname,'')	=	''
		BEGIN
			RAISERROR('Parameter Name Cannot be Null',16,1)
			RETURN
		END

	IF ISNULL(@engg_gq_rep_controlbtsyn,'')	<>	''	AND ISNULL(@engg_gq_rep_defvalue,'')	<>	''
		BEGIN
			RAISERROR('Please give either Default Value or Control BtSynonym: %i',16,1,@FPRowno)
			RETURN
		END

	IF ISNULL(@engg_gq_rep_controlbtsyn,'')	=	''	AND ISNULL(@engg_gq_rep_defvalue,'')	=	''
		BEGIN
			RAISERROR('Please give either Default Value or Control BtSynonym: %i',16,1,@FPRowno)
			RETURN
		END

	IF ISNULL(@engg_gq_rep_reportname,'')	=	''
		BEGIN
			RAISERROR('ReportName Cannot be Null',16,1)
			RETURN
		END
	IF dbo.ep_check_spl_char(@engg_gq_rep_reportname) = 1
	BEGIN
			RAISERROR('ReportName Cannot Contains Special Characters',16,1)
			RETURN
	END

	IF ISNULL(@modeflag,'')	IN	('I','X')
	BEGIN
	IF EXISTS (	SELECT 'X'
				FROM	de_task_gql_report_param WITH(NOLOCK)
				WHERE	CustomerName	=	@engg_gqhdr_cust
				AND		ProjectName		=	@engg_gqhdr_proj
				AND		ProcessName		=	@engg_gqhdr_prcname
				AND		ComponentName	=	@engg_gqhdr_cmpname
				AND		ActivityName	=	@engg_gqhdr_actname
				AND		UIName			=	@engg_gqhdr_uiname
				AND		TaskName		=	@engg_gqhdr_tskname
				AND		ReportName		=	@engg_gq_rep_reportname
				AND		ParameterName	=	@engg_gq_rep_paramname )
		BEGIN
			RAISERROR('Parameter Name cannot be duplicated',16,1)
		END
	END

	IF ISNULL(@modeflag,'')	IN	('I','X')
	BEGIN
		IF NOT EXISTS (	SELECT 'X'
						FROM	de_task_gql_report WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname
						AND		ReportName		=	@engg_gq_rep_reportname )
			BEGIN
				INSERT INTO de_task_gql_report
						(	CustomerName,				ProjectName,			DocNo,						ProcessName,
							ComponentName,				ActivityName,			UIName,						TaskName,
							ReportName,					OutputFormat,			LaunchMode,					TimeStamp,
							CreatedBy,					CreatedDate,			ModifiedBy,					ModifiedDate)
				SELECT
							@engg_gqhdr_cust,			@engg_gqhdr_proj,		@engg_gqhdr_ecrno,			@engg_gqhdr_prcname,
							@engg_gqhdr_cmpname,		@engg_gqhdr_actname,	@engg_gqhdr_uiname,			@engg_gqhdr_tskname,
							@engg_gq_rep_reportname,	@engg_gq_rep_oufrmt,	@engg_gq_rep_launchmode,		1,
							@ctxt_user,					getdate(),				@ctxt_user,					getdate()			
				END
	

		IF NOT EXISTS (	SELECT 'X'
						FROM	de_task_gql_report_param WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname
						AND		ReportName		=	@engg_gq_rep_reportname 
						AND		ParameterName	=	@engg_gq_rep_paramname )
			BEGIN
				INSERT INTO de_task_gql_report_param
						(	CustomerName,				ProjectName,			DocNo,						ProcessName,
							ComponentName,				ActivityName,			UIName,						TaskName,
							ReportName,					ParameterName,			BTSynonym,					ControlID,
							ViewName,					DefaultValue,			TimeStamp,
							CreatedBy,					CreatedDate,			ModifiedBy,					ModifiedDate)
				SELECT
							@engg_gqhdr_cust,			@engg_gqhdr_proj,		@engg_gqhdr_ecrno,			@engg_gqhdr_prcname,
							@engg_gqhdr_cmpname,		@engg_gqhdr_actname,	@engg_gqhdr_uiname,			@engg_gqhdr_tskname,
							@engg_gq_rep_reportname,	@engg_gq_rep_paramname,	@engg_gq_rep_controlbtsyn,	@engg_gq_rep_ctrlid,
							@engg_gq_rep_viewname,		@engg_gq_rep_defvalue,		1,
							@ctxt_user,					getdate(),				@ctxt_user,					getdate()			
		END
	END

	----------------------
	IF EXISTS (	SELECT 'X'
						FROM	de_task_gql_report WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname)
	BEGIN
					UPDATE	de_task_gql_report
					SET		ReportName			=	@engg_gq_rep_reportname,
							LaunchMode			=	@engg_gq_rep_launchmode,
							OutputFormat		=	@engg_gq_rep_oufrmt,       
							ModifiedBy			=	@ctxt_user
					WHERE	CustomerName		=	@engg_gqhdr_cust
					AND		ProjectName			=	@engg_gqhdr_proj
					AND		ProcessName			=	@engg_gqhdr_prcname
					AND		ComponentName		=	@engg_gqhdr_cmpname
					AND		ActivityName		=	@engg_gqhdr_actname
					AND		UIName				=	@engg_gqhdr_uiname
					AND		TaskName			=	@engg_gqhdr_tskname
				
	END

	IF EXISTS (	SELECT 'X'
						FROM	de_task_gql_report_param WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname)
	BEGIN
					UPDATE	de_task_gql_report_param
					SET		ReportName			=	@engg_gq_rep_reportname,     
							ModifiedBy			=	@ctxt_user
					WHERE	CustomerName		=	@engg_gqhdr_cust
					AND		ProjectName			=	@engg_gqhdr_proj
					AND		ProcessName			=	@engg_gqhdr_prcname
					AND		ComponentName		=	@engg_gqhdr_cmpname
					AND		ActivityName		=	@engg_gqhdr_actname
					AND		UIName				=	@engg_gqhdr_uiname
					AND		TaskName			=	@engg_gqhdr_tskname
				
	END
	----------------------

		IF ISNULL(@modeflag,'') IN	('U','Y')
		BEGIN			
		IF EXISTS (	SELECT 'X'
						FROM	de_task_gql_report_param WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname 
						AND		ReportName		=	@engg_gq_rep_reportname
						AND		ParameterName	=	@engg_gq_rep_paramname)
			BEGIN
					UPDATE	de_task_gql_report_param
					SET		BTSynonym			=	@engg_gq_rep_controlbtsyn,
							ControlID			=	@engg_gq_rep_ctrlid,
							ViewName			=	@engg_gq_rep_viewname,
							DefaultValue		=	@engg_gq_rep_defvalue,
							ModifiedBy			=	@ctxt_user
					WHERE	CustomerName		=	@engg_gqhdr_cust
					AND		ProjectName			=	@engg_gqhdr_proj
					AND		ProcessName			=	@engg_gqhdr_prcname
					AND		ComponentName		=	@engg_gqhdr_cmpname
					AND		ActivityName		=	@engg_gqhdr_actname
					AND		UIName				=	@engg_gqhdr_uiname
					AND		TaskName			=	@engg_gqhdr_tskname
					AND		ReportName			=	@engg_gq_rep_reportname
					AND		ParameterName		=	@engg_gq_rep_paramname
			END

		IF EXISTS (	SELECT 'X'
						FROM	de_task_gql_report_param WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname 
						AND		ReportName		=	@engg_gq_rep_reportname
						AND		BTSynonym		=	@engg_gq_rep_controlbtsyn )
				BEGIN
					UPDATE	de_task_gql_report_param
					SET		ParameterName		=	@engg_gq_rep_paramname,
							ModifiedBy			=	@ctxt_user
					WHERE	CustomerName		=	@engg_gqhdr_cust
					AND		ProjectName			=	@engg_gqhdr_proj
					AND		ProcessName			=	@engg_gqhdr_prcname
					AND		ComponentName		=	@engg_gqhdr_cmpname
					AND		ActivityName		=	@engg_gqhdr_actname
					AND		UIName				=	@engg_gqhdr_uiname
					AND		TaskName			=	@engg_gqhdr_tskname 
					AND		ReportName			=	@engg_gq_rep_reportname
					AND		BTSynonym			=	@engg_gq_rep_controlbtsyn
				END
			END

	IF ISNULL(@modeflag,'') =	'D'
		BEGIN
				IF EXISTS (	SELECT 'X'
						FROM	de_task_gql_report_param WITH(NOLOCK)
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname
						AND		reportname		=	@engg_gq_rep_reportname
						AND		parametername	=	@engg_gq_rep_paramname )
					BEGIN
						DELETE 
						FROM	de_task_gql_report_param
						WHERE	CustomerName	=	@engg_gqhdr_cust
						AND		ProjectName		=	@engg_gqhdr_proj
						AND		ProcessName		=	@engg_gqhdr_prcname
						AND		ComponentName	=	@engg_gqhdr_cmpname
						AND		ActivityName	=	@engg_gqhdr_actname
						AND		UIName			=	@engg_gqhdr_uiname
						AND		TaskName		=	@engg_gqhdr_tskname 
						AND		reportname		=	@engg_gq_rep_reportname
						AND		parametername	=	@engg_gq_rep_paramname
					END		
		END	
				SELECT  @FPRowno 'fprowno'

	/* 
	-- OutputList
	Select
	*/

	Set nocount off
End

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ACHgqlSprepsavrepgrd' AND TYPE='P')
BEGIN
    GRANT EXEC ON  ACHgqlSprepsavrepgrd TO PUBLIC
END
GO  



