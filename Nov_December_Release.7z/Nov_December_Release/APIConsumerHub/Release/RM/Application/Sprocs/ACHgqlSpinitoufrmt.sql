if exists ( Select 'y' from sysobjects where name = 'ACHgqlSpinitoufrmt' and type = 'P')
    begin
        drop proc ACHgqlSpinitoufrmt
    end
go


/********************************************************************************/
/* Procedure                               : ACHgqlSpinitoufrmt					*/
/* Description                             :                                    */
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :                                    */
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U			        */
/* Date                                    : 20-OCT-2022                        */
/* rTrack ID                               : TECH-72114                         */
/* Description                             : Report modeling enablement in 
									platform model for GQL based user interfaces*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/


Create Procedure ACHgqlSpinitoufrmt
	@ctxt_ouinstance     	ctxt_ouinstance, --Input 
	@ctxt_user           	ctxt_user, --Input 
	@ctxt_language       	ctxt_language, --Input 
	@ctxt_service        	ctxt_service, --Input 
	@ctxt_role           	ctxt_role, --Input 
	@engg_gqhdr_cmpdescr 	engg_description, --Input 
	@engg_gqhdr_cust     	engg_name, --Input 
	@engg_gqhdr_ecrno    	engg_name, --Input 
	@engg_gqhdr_prodescr 	engg_description, --Input 
	@engg_gqhdr_proj     	engg_name, --Input 
	@m_errorid           	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user            = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service         = ltrim(rtrim(@ctxt_service))
	Set @ctxt_role            = ltrim(rtrim(@ctxt_role))
	Set @engg_gqhdr_cmpdescr  = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cust      = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno     = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_prodescr  = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj      = ltrim(rtrim(@engg_gqhdr_proj))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @ctxt_role = '~#~' 
		Select @ctxt_role = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  
		
	SELECT	''			'engg_gq_rep_oufrmt',
			0	timestamp
	UNION
	SELECT	quick_code	'engg_gq_rep_oufrmt',
			timestamp
	FROM	de_quick_code_mst WITH(NOLOCK)
	WHERE	quick_code_type	=	'OutputFormat'
	ORDER BY timestamp

	/* 
	-- OutputList
	Select
		null 'engg_gq_rep_oufrmt', 
	*/

	Set nocount off
End

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ACHgqlSpinitoufrmt' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  ACHgqlSpinitoufrmt TO PUBLIC
END
GO
