if exists ( Select 'y' from sysobjects where name = 'ACHgqlSptsknam_engg_eLEO' and type = 'P')
    begin
        drop proc ACHgqlSptsknam_engg_eLEO
    end
go

/********************************************************************************/
/* Procedure                               : ACHgqlSptsknam_engg_eLEO             */
/* Description                             :                                    */
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :                                    */
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U         			*/
/* Date                                    : 20-Aug-2022                        */
/* rTrack ID                               : TECH-72114                         */
/* Description                             : Report modeling enablement in 
									platform model for GQL based user interfaces*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/


Create Procedure ACHgqlSptsknam_engg_eLEO
	@ctxt_ouinstance            	ctxt_ouinstance, --Input 
	@ctxt_user                  	ctxt_user, --Input 
	@ctxt_language              	ctxt_language, --Input 
	@ctxt_service               	ctxt_service, --Input 
	@emgg_arg_qrytype           	engg_type, --Input 
	@engg_arg_qry               	vw_plf_desc, --Input 
	@engg_arg_qryalias          	engg_type, --Input 
	@engg_arg_qryhdnkeyfield    	engg_name, --Input 
	@engg_arg_qryseq            	engg_qry_seq, --Input 
	@engg_arg_qryversion        	engg_version, --Input 
	@engg_fld_qry               	vw_plf_desc, --Input 
	@engg_fld_qryalias          	engg_type, --Input 
	@engg_fld_qryhdnkeyfield    	engg_name, --Input 
	@engg_fld_qryseq            	engg_qry_seq, --Input 
	@engg_fld_qrytype           	engg_type, --Input 
	@engg_fld_qry_version       	engg_version, --Input 
	@engg_gqfld_inclayoutctrls  	engg_qry_seq, --Input 
	@engg_gqhdr_actdescr        	engg_description, --Input 
	@engg_gqhdr_actname         	engg_name, --Input 
	@engg_gqhdr_cmpdescr        	engg_description, --Input 
	@engg_gqhdr_cmpname         	engg_name, --Input 
	@engg_gqhdr_cust            	engg_name, --Input 
	@engg_gqhdr_ecrno           	engg_name, --Input 
	@engg_gqhdr_prcname         	engg_name, --Input 
	@engg_gqhdr_prodescr        	engg_description, --Input 
	@engg_gqhdr_proj            	engg_name, --Input 
	@engg_gqhdr_taskdescr       	engg_description, --Input 
	@engg_gqhdr_tasktype        	engg_type, --Input 
	@engg_gqhdr_tskname         	engg_name, --Input 
	@engg_gqhdr_uidescr         	engg_description, --Input 
	@engg_gqhdr_uiname          	engg_name, --Input 
	--Code Added for the Defect Id Tech-72114 starts
	@engg_gq_rep_launchmode     	engg_type, --Input 
	@engg_gq_rep_oufrmt         	engg_type, --Input 
	@engg_gq_rep_reportname     	engg_name, --Input 
	--Code Added for the Defect Id Tech-72114 ends
	@m_errorid                  	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                   = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service                = ltrim(rtrim(@ctxt_service))
	Set @emgg_arg_qrytype            = ltrim(rtrim(@emgg_arg_qrytype))
	Set @engg_arg_qry                = ltrim(rtrim(@engg_arg_qry))
	Set @engg_arg_qryalias           = ltrim(rtrim(@engg_arg_qryalias))
	Set @engg_arg_qryhdnkeyfield     = ltrim(rtrim(@engg_arg_qryhdnkeyfield))
	Set @engg_arg_qryversion         = ltrim(rtrim(@engg_arg_qryversion))
	Set @engg_fld_qry                = ltrim(rtrim(@engg_fld_qry))
	Set @engg_fld_qryalias           = ltrim(rtrim(@engg_fld_qryalias))
	Set @engg_fld_qryhdnkeyfield     = ltrim(rtrim(@engg_fld_qryhdnkeyfield))
	Set @engg_fld_qrytype            = ltrim(rtrim(@engg_fld_qrytype))
	Set @engg_fld_qry_version        = ltrim(rtrim(@engg_fld_qry_version))
	Set @engg_gqhdr_actdescr         = ltrim(rtrim(@engg_gqhdr_actdescr))
	Set @engg_gqhdr_actname          = ltrim(rtrim(@engg_gqhdr_actname))
	Set @engg_gqhdr_cmpdescr         = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cmpname          = ltrim(rtrim(@engg_gqhdr_cmpname))
	Set @engg_gqhdr_cust             = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno            = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_prcname          = ltrim(rtrim(@engg_gqhdr_prcname))
	Set @engg_gqhdr_prodescr         = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj             = ltrim(rtrim(@engg_gqhdr_proj))
	Set @engg_gqhdr_taskdescr        = ltrim(rtrim(@engg_gqhdr_taskdescr))
	Set @engg_gqhdr_tasktype         = ltrim(rtrim(@engg_gqhdr_tasktype))
	Set @engg_gqhdr_tskname          = ltrim(rtrim(@engg_gqhdr_tskname))
	Set @engg_gqhdr_uidescr          = ltrim(rtrim(@engg_gqhdr_uidescr))
	Set @engg_gqhdr_uiname           = ltrim(rtrim(@engg_gqhdr_uiname))
	Set @engg_gq_rep_launchmode      = ltrim(rtrim(@engg_gq_rep_launchmode))
	Set @engg_gq_rep_oufrmt          = ltrim(rtrim(@engg_gq_rep_oufrmt))
	Set @engg_gq_rep_reportname      = ltrim(rtrim(@engg_gq_rep_reportname))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @emgg_arg_qrytype = '~#~' 
		Select @emgg_arg_qrytype = null  

	IF @engg_arg_qry = '~#~' 
		Select @engg_arg_qry = null  

	IF @engg_arg_qryalias = '~#~' 
		Select @engg_arg_qryalias = null  

	IF @engg_arg_qryhdnkeyfield = '~#~' 
		Select @engg_arg_qryhdnkeyfield = null  

	IF @engg_arg_qryseq = -915
		Select @engg_arg_qryseq = null  

	IF @engg_arg_qryversion = '~#~' 
		Select @engg_arg_qryversion = null  

	IF @engg_fld_qry = '~#~' 
		Select @engg_fld_qry = null  

	IF @engg_fld_qryalias = '~#~' 
		Select @engg_fld_qryalias = null  

	IF @engg_fld_qryhdnkeyfield = '~#~' 
		Select @engg_fld_qryhdnkeyfield = null  

	IF @engg_fld_qryseq = -915
		Select @engg_fld_qryseq = null  

	IF @engg_fld_qrytype = '~#~' 
		Select @engg_fld_qrytype = null  

	IF @engg_fld_qry_version = '~#~' 
		Select @engg_fld_qry_version = null  

	IF @engg_gqfld_inclayoutctrls = -915
		Select @engg_gqfld_inclayoutctrls = null  

	IF @engg_gqhdr_actdescr = '~#~' 
		Select @engg_gqhdr_actdescr = null  

	IF @engg_gqhdr_actname = '~#~' 
		Select @engg_gqhdr_actname = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cmpname = '~#~' 
		Select @engg_gqhdr_cmpname = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_prcname = '~#~' 
		Select @engg_gqhdr_prcname = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  

	IF @engg_gqhdr_taskdescr = '~#~' 
		Select @engg_gqhdr_taskdescr = null  

	IF @engg_gqhdr_tasktype = '~#~' 
		Select @engg_gqhdr_tasktype = null  

	IF @engg_gqhdr_tskname = '~#~' 
		Select @engg_gqhdr_tskname = null  

	IF @engg_gqhdr_uidescr = '~#~' 
		Select @engg_gqhdr_uidescr = null  

	IF @engg_gqhdr_uiname = '~#~' 
		Select @engg_gqhdr_uiname = null  

	IF @engg_gq_rep_launchmode = '~#~' 
		Select @engg_gq_rep_launchmode = null  

	IF @engg_gq_rep_oufrmt = '~#~' 
		Select @engg_gq_rep_oufrmt = null  

	IF @engg_gq_rep_reportname = '~#~' 
		Select @engg_gq_rep_reportname = null  

		EXEC DE_GQL_Rep_LELd_BTSyn
		@Ctxt_Language			=	@ctxt_language,
		@Ctxt_OUInstance        =	@ctxt_ouinstance,  
		@Ctxt_Service           =	@ctxt_service,
		@Ctxt_User              =	@ctxt_user,   
		@CustomerName           =	@engg_gqhdr_cust,    
		@ProjectName            =	@engg_gqhdr_proj,     
		@EcrNo                  =	@engg_gqhdr_ecrno,     
		@ProcessName            =	@engg_gqhdr_prcname,    
		@ComponetName           =	@engg_gqhdr_cmpname,    
		@ActivityName           =	@engg_gqhdr_actname,  
		@UIName                 =	@engg_gqhdr_uiname,  
		@m_errorid              =	@m_errorid OUTPUT    

	/* 
	-- OutputList
	Select
		null 'engg_gq_rep_lecaption', 
		null 'engg_gq_rep_lecontrolbtsyn', 
		null 'engg_gq_rep_lecontrolid', 
		null 'engg_gq_rep_lecontroltype', 
		null 'engg_gq_rep_ledatatype', 
		null 'engg_gq_rep_lepagename', 
		null 'engg_gq_rep_lesectionname', 
		null 'engg_gq_rep_leviewname', 
	*/

	Set nocount off
End
GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ACHgqlSptsknam_engg_eLEO' AND TYPE='P')
BEGIN
    GRANT EXEC ON  ACHgqlSptsknam_engg_eLEO TO PUBLIC
END
GO  

