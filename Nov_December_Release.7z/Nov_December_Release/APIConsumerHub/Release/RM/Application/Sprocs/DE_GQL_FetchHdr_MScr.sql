IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DE_GQL_FetchHdr_MScr' AND TYPE = 'P')
    Begin
        Drop PROC DE_GQL_FetchHdr_MScr
    End
GO

/********************************************************************************/
/* Procedure                               : DE_GQL_FetchHdr_MScr				*/
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Ponmalar A / Jeya Latha K			*/
/* Date                                    : 20-OCT-2021                        */
/* rTrack ID                               : TECH-63474                         */
/* Description							   : New Feature--GQL Operations	    */
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
/* Author                                  : Rajeswari M / Jeya Latha K			*/
/* Date                                    : 24-NOV-2021                        */
/* rTrack ID                               : TECH-64197                         */
/* Description							   : GQL Operations						*/
/********************************************************************************/   
/* Modified By	: Ponmalar A/Priyadharshini U									*/
/* Defect ID	: TECH-67697													*/
/* Modified on	: 31Mar2022														*/
/* Description	: GQL Changes.													*/
/********************************************************************************/
/* Modified By	: Ponmalar A/Jeya Latha K										*/
/* Defect ID	: TECH-68063													*/
/* Modified on	: 21-Apr-2022													*/
/* Description	: Provision to map captions for control,column, section and Page
				  in gql engineering..											*/
/********************************************************************************/
/* Modified By	: Priyadharshini U												*/
/* Defect ID	: TECH-72114													*/
/* Modified on	: 22-Aug-2022													*/
/* Description	: 	Report modeling enablement in platform model for GQL based
																user interfaces	*/
/********************************************************************************/
CREATE PROCEDURE DE_GQL_FetchHdr_MScr
	@ctxt_language      	ctxt_language,			
	@ctxt_ouinstance    	ctxt_ouinstance,
	@ctxt_service       	ctxt_service,	
	@ctxt_user          	ctxt_user,				
	@CustomerName			engg_name,
    @ProjectName			engg_name,
	@ecrno                  engg_name,
	@ProcessDesc			engg_description,
	@ComponentDesc	        engg_description,
    @ActivityDesc			engg_description,
	@UiDesc					engg_description,
	@ProcessName			engg_name,
	@ComponentName			engg_name,
	@ActivityName			engg_name,
	@UiName					engg_name,
	@TaskName				engg_name,
	@TaskDesc				engg_description,
	@TaskType				engg_type,
	@QueryName				vw_plf_desc,
	@QueryType				engg_type,
	@QueryVersion			engg_version,
	@QueryAlias			    engg_name,
	@QuerySeq				engg_Seqno,
	@HdnKeyField			engg_name,		--13639
	@m_errorid              INT OUTPUT
AS
BEGIN
	
	SET NOCOUNT ON
	SET @M_ERRORID = 0

	
	DECLARE   @tmp_process_name				engg_name,
			  @tmp_component_name			engg_name,
			  @tmp_activity_name			engg_name,
	          @tmp_ui_name					engg_name,
			  @tmp_task_name				engg_name,
			  @tmp_task_Desc				engg_description,
			  @tmp_task_type				engg_description,
			  @tmp_arg_name					engg_name,
			  @tmp_arg_type					engg_type,
			  @tmp_arg_version				engg_version,
			  @tmp_arg_alias				engg_type,
			  @tmp_arg_seq				    engg_Seqno,
			  @tmp_engg_gqpopup_json		engg_description,
			  @tmp_engg_gqpopup_jsonDBC		engg_nvarchar_max,
			  @tmp_engg_gqpopup_schema		engg_description,
			  @tmp_engg_gqpopup_schemaDBC	engg_nvarchar_max,
			  @tmp_VersionNumber			engg_name,
			  @tmp_HdnKeyField				engg_name,	--13639
			  @tmp_sdl_text					engg_nvarchar_max,	--11536
			  @tmp_IncLayoutCtrls			engg_seqno,		--14469
			  @tmp_queryname				engg_description,
			  @tmp_childqueryname			engg_description,
			  @tmp_reportname				engg_name,
			  @tmp_launchmode				engg_type,
			  @tmp_oufrmt					engg_type	--Code Added for the Defect Id Tech-72114
		
	/*Validation for ECR Selection*/
	IF ISNULL(@ecrno,'')	=	''
	BEGIN
		RAISERROR('Please select the Engineering Request #.',16,1)
		RETURN
	END	
	

	SELECT 
		     @tmp_process_name		=	process_name,
			 @tmp_component_name	=	component_name
     FROM    de_ui_ico WITH(NOLOCK) 
	 WHERE  customer_name			=	@CustomerName  
	 AND    project_name			=	@ProjectName  
	 AND    ico_no				    =	@ecrno  
	 AND    process_descr			=   @ProcessDesc
     AND    component_descr			=	@ComponentDesc

	 IF @ctxt_service  =  ( 'achgqlsrfet' )
	 BEGIN 

		SELECT TOP 1 
		          @tmp_process_name		=	process_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_descr			=   @ProcessDesc
		  ORDER BY  process_descr

		  SELECT TOP 1 
		          @tmp_component_name	=	component_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_descr			=	@ComponentDesc
	    
		 SELECT TOP 1  
				  @tmp_activity_name	=	activity_name,  
				  @tmp_ui_name			=	ui_name  
		  FROM  de_ui_ico WITH(NOLOCK)      
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name		    =	@tmp_component_name 
		  AND   activity_descr			=	@ActivityDesc
		  AND   ui_descr				=	@UiDesc
		  ORDER BY activity_descr, ui_descr
		
	
		  SELECT TOP 1 
				 @tmp_task_name			=   task_name,
				 @tmp_task_Desc			=	task_descr,
				 @tmp_task_type			=	task_type
		  FROM   de_action WITH (NOLOCK)
		  WHERE  customer_name			=	@CustomerName  
		  AND    project_name			=	@ProjectName  
		  AND    process_name			=   @tmp_process_name
		  AND    component_name			=	@tmp_component_name 
		  AND    activity_name			=   @tmp_activity_name
		  AND    ui_name				=   @tmp_ui_name 
		  ORDER BY task_name
		
		SELECT TOP 1
				@tmp_arg_name			=	CASE WHEN ISNULL(ChildQueryName,'')<>'' THEN QueryName+'.'+ChildQueryName ELSE QueryName END,	--TECH-68063
				@tmp_arg_type			=	QueryType,
				@tmp_arg_version		=	[Version],
				@tmp_arg_alias			=	QueryAlias,
				@tmp_arg_seq			=	QuerySequence,
				@tmp_HdnKeyField		=	KeyField	--13639
		FROM	de_task_gql_mapping WITH (NOLOCK)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		ORDER BY QueryName

		--TECH-68063
		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END

		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_queryname
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
		--TECH-68063

	END

	ELSE IF  @ctxt_service = 'achgqlsractdes'
	BEGIN
		 

		  SELECT 
		          @tmp_activity_name	=	activity_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_descr			=	@ActivityDesc
	    
		 
		  SELECT TOP 1
				@tmp_ui_name			=	ui_name  
		  FROM  de_ui_ico WITH(NOLOCK)      
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name		    =	@tmp_component_name 
		  AND   activity_name           =   @tmp_activity_name
		  ORDER BY  ui_descr

		   SELECT TOP 1 
				 @tmp_task_name			=   task_name,
				 @tmp_task_Desc			=	task_descr,
				 @tmp_task_type			=	task_type
		  FROM   de_action WITH (NOLOCK)
		  WHERE  customer_name			=	@CustomerName  
		  AND    project_name			=	@ProjectName  
		  AND    process_name			=   @tmp_process_name
		  AND    component_name			=	@tmp_component_name 
		  AND    activity_name			=   @tmp_activity_name
		  AND    ui_name				=   @tmp_ui_name 
		  ORDER BY task_name

		 --Code Added for the Defect Id Tech-72114 starts
		 SELECT	@tmp_reportname		=	ReportName,
				@tmp_launchmode		=	LaunchMode,
				@tmp_oufrmt			=	Outputformat
		 FROM	de_task_gql_report WITH(NOLOCK)
		  WHERE		CustomerName		=	@CustomerName  
		  AND		ProjectName			=	@ProjectName  
		  AND		ProcessName			=   @tmp_process_name
		  AND		ComponentName		=	@tmp_component_name 
		  AND		ActivityName		=   @tmp_activity_name
		  AND		UIName				=   @tmp_ui_name 
		  AND		TaskName			=	@tmp_task_name
		 --Code Added for the Defect Id Tech-72114 ends

		  SELECT TOP 1
				@tmp_arg_name			=	CASE WHEN ISNULL(ChildQueryName,'')<>'' THEN QueryName+'.'+ChildQueryName ELSE QueryName END, 		--TECH-68063
				@tmp_arg_type			=	QueryType,
				@tmp_arg_version		=	[Version],
				@tmp_arg_alias			=	QueryAlias,
				@tmp_arg_seq			=	QuerySequence,
				@tmp_HdnKeyField		=	KeyField	--13639
		  FROM	de_task_gql_mapping WITH (NOLOCK)
		  WHERE	CustomerName			=	@CustomerName  
		  AND		ProjectName			=	@ProjectName  
		  AND		ProcessName			=   @tmp_process_name
		  AND		ComponentName		=	@tmp_component_name 
		  AND		ActivityName		=   @tmp_activity_name
		  AND		UIName				=   @tmp_ui_name 
		  ORDER BY QueryName

		  		--TECH-68063
		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END


		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_queryname
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
		--TECH-68063
		 
	END

	ELSE IF @ctxt_service	=	'achgqlsruides'
	BEGIN

		  SELECT 
		          @tmp_activity_name	=	activity_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_descr			=	@ActivityDesc
		 

		  SELECT 
		          @tmp_ui_name			=	ui_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_name			=	@tmp_activity_name
		  AND   ui_descr				=	@UiDesc
		
		  SELECT TOP 1 
				 @tmp_task_name			=   task_name,
				 @tmp_task_Desc			=	task_descr,
				 @tmp_task_type			=	task_type
		  FROM   de_action WITH (NOLOCK)
		  WHERE  customer_name			=	@CustomerName  
		  AND    project_name			=	@ProjectName  
		  AND    process_name			=   @tmp_process_name
		  AND    component_name			=	@tmp_component_name 
		  AND    activity_name			=   @tmp_activity_name
		  AND    ui_name				=   @tmp_ui_name 
		  ORDER BY task_name

		 --Code Added for the Defect Id Tech-72114 starts
		 SELECT	@tmp_reportname		=	ReportName,
				@tmp_launchmode		=	LaunchMode,
				@tmp_oufrmt			=	Outputformat
		 FROM	de_task_gql_report WITH(NOLOCK)
		  WHERE		CustomerName		=	@CustomerName  
		  AND		ProjectName			=	@ProjectName  
		  AND		ProcessName			=   @tmp_process_name
		  AND		ComponentName		=	@tmp_component_name 
		  AND		ActivityName		=   @tmp_activity_name
		  AND		UIName				=   @tmp_ui_name 
		  AND		TaskName			=	@tmp_task_name
		 --Code Added for the Defect Id Tech-72114 ends

		  SELECT TOP 1
				@tmp_arg_name			=	CASE WHEN ISNULL(ChildQueryName,'')<>'' THEN QueryName+'.'+ChildQueryName ELSE QueryName END,			--TECH-68063
				@tmp_arg_type			=	QueryType,
				@tmp_arg_version		=	[Version],
				@tmp_arg_alias			=	QueryAlias,
				@tmp_arg_seq			=	QuerySequence,
				@tmp_HdnKeyField		=	KeyField	--13639
		  FROM	de_task_gql_mapping WITH (NOLOCK)
		  WHERE	CustomerName			=	@CustomerName  
		  AND		ProjectName				=	@ProjectName  
		  AND		ProcessName				=   @tmp_process_name
		  AND		ComponentName			=	@tmp_component_name 
		  AND		ActivityName			=   @tmp_activity_name
		  AND		UIName					=   @tmp_ui_name 
		  ORDER BY QueryName

				--TECH-68063
		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END


		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_queryname
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
		--TECH-68063

	END
	ELSE IF @ctxt_service  IN ( 'achgqlsrtsknam')
	BEGIN
	
		  SELECT 
		          @tmp_activity_name	=	activity_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_descr			=	@ActivityDesc
		  
	
		  SELECT 
		          @tmp_ui_name			=	ui_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_name			=	@tmp_activity_name
		  AND   ui_descr				=	@UiDesc
	

	      SELECT	@tmp_task_name			=	@TaskName,
					@tmp_task_Desc			=	@TaskDesc,
					@tmp_task_type			=	@TaskType

		  SELECT TOP 1
				@tmp_arg_name			=	CASE WHEN ISNULL(ChildQueryName,'')<>'' THEN QueryName+'.'+ChildQueryName ELSE QueryName END,  --TECH-68063
				@tmp_arg_type			=	QueryType,
				@tmp_arg_version		=	[Version],
				@tmp_arg_alias			=	QueryAlias,
				@tmp_arg_seq			=	QuerySequence,
				@tmp_HdnKeyField		=	KeyField	--13639
		  FROM	de_task_gql_mapping WITH (NOLOCK)
		  WHERE	CustomerName			=	@CustomerName  
		  AND		ProjectName			=	@ProjectName  
		  AND		ProcessName			=   @tmp_process_name
		  AND		ComponentName		=	@tmp_component_name 
		  AND		ActivityName		=   @tmp_activity_name
		  AND		UIName				=   @tmp_ui_name 
		  AND       TaskName			=   @tmp_task_name
		  ORDER BY QueryName
		  
		 --TECH-68063

		 --Code Added for the Defect Id Tech-72114 starts
		 SELECT	@tmp_reportname		=	ReportName,
				@tmp_launchmode		=	LaunchMode,
				@tmp_oufrmt			=	Outputformat
		 FROM	de_task_gql_report WITH(NOLOCK)
		  WHERE		CustomerName		=	@CustomerName  
		  AND		ProjectName			=	@ProjectName  
		  AND		ProcessName			=   @tmp_process_name
		  AND		ComponentName		=	@tmp_component_name 
		  AND		ActivityName		=   @tmp_activity_name
		  AND		UIName				=   @tmp_ui_name 
		  AND		TaskName			=	@TaskName

		 --Code Added for the Defect Id Tech-72114 ends

		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END


		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_QueryName
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
		--TECH-68063
	END

	ELSE IF @ctxt_service  IN ( 'achgqlsrargqry')
	BEGIN
		SELECT 
		          @tmp_activity_name	=	activity_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_descr			=	@ActivityDesc
		 

		  SELECT 
		          @tmp_ui_name			=	ui_name
		  FROM    de_ui_ico WITH(NOLOCK) 
		  WHERE customer_name			=	@CustomerName  
	      AND   project_name			=	@ProjectName  
	      AND   ico_no				    =	@ecrno  
		  AND   process_name			=   @tmp_process_name
		  AND   component_name			=	@tmp_component_name
		  AND   activity_name			=	@tmp_activity_name
		  AND   ui_descr				=	@UiDesc

		  
	      SELECT	@tmp_task_name		=	@TaskName,
					@tmp_task_Desc		=	@TaskDesc,
					@tmp_task_type		=	@TaskType

		    SELECT @tmp_arg_name		=	@QueryName,
			       @tmp_arg_type		=	@QueryType,
				   @tmp_arg_version		=	@QueryVersion,
				   @tmp_arg_alias		=	@QueryAlias,
				   @tmp_arg_seq			=	@QuerySeq,
				   @tmp_HdnKeyField		=	@HdnKeyField	--13639

	END
	ELSE IF @ctxt_service  IN ( 'achgqlsrfldqry')
	BEGIN
	  SELECT @tmp_process_name		=	@ProcessName,
			 @tmp_component_name	=	@ComponentName,
			 @tmp_activity_name		=	@ActivityName,
		     @tmp_ui_name			=	@UiName
		  

		SELECT	 @tmp_task_name		=	@TaskName,
				 @tmp_task_Desc		=	@TaskDesc,
				 @tmp_task_type		=	@TaskType
				 
	   SELECT    @tmp_arg_name		=	@QueryName,
			     @tmp_arg_type		=	@QueryType,
				 @tmp_arg_version	=	@QueryVersion,
				 @tmp_arg_alias		=	@QueryAlias,
				 @tmp_arg_seq		=	@QuerySeq,
				 @tmp_HdnKeyField	=	@HdnKeyField	--13639
--TECH-68063
		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END

		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_queryname
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
		--TECH-68063

	END
	ELSE IF @ctxt_service  IN ( 'achgqlsrqrysav')
	BEGIN
	  SELECT @tmp_process_name		=	@ProcessName,
			 @tmp_component_name	=	@ComponentName,
			 @tmp_activity_name		=	@ActivityName,
		     @tmp_ui_name			=	@UiName
		  

		SELECT	 @tmp_task_name		=	@TaskName,
				 @tmp_task_Desc		=	@TaskDesc,
				 @tmp_task_type		=	@TaskType
				 
	   SELECT    @tmp_arg_name		=	@QueryName,
			     @tmp_arg_type		=	@QueryType,
				 @tmp_arg_version	=	@QueryVersion,
				 @tmp_arg_alias		=	@QueryAlias,
				 @tmp_arg_seq		=	@QuerySeq,
				 @tmp_HdnKeyField	=	@HdnKeyField	--13639
	END    
	ELSE IF @ctxt_service  IN ( 'achgqlsrargsav')
	BEGIN
	  SELECT @tmp_process_name		=	@ProcessName,
			 @tmp_component_name	=	@ComponentName,
			 @tmp_activity_name		=	@ActivityName,
		     @tmp_ui_name			=	@UiName
		  

		SELECT	 @tmp_task_name		=	@TaskName,
				 @tmp_task_Desc		=	@TaskDesc,
				 @tmp_task_type		=	@TaskType
				 
	   SELECT    @tmp_arg_name		=	@QueryName,
			     @tmp_arg_type		=	@QueryType,
				 @tmp_arg_version	=	@QueryVersion,
				 @tmp_arg_alias		=	@QueryAlias,
				 @tmp_arg_seq		=	@QuerySeq,
				 @tmp_HdnKeyField	=	@HdnKeyField	--13639
	END  
	ELSE IF @ctxt_service  IN ( 'achgqlsrfldsav')
	BEGIN
	  SELECT @tmp_process_name		=	@ProcessName,
			 @tmp_component_name	=	@ComponentName,
			 @tmp_activity_name		=	@ActivityName,
		     @tmp_ui_name			=	@UiName
		  

		SELECT	 @tmp_task_name		=	@TaskName,
				 @tmp_task_Desc		=	@TaskDesc,
				 @tmp_task_type		=	@TaskType
				 
	   SELECT    @tmp_arg_name		=	@QueryName,
			     @tmp_arg_type		=	@QueryType,
				 @tmp_arg_version	=	@QueryVersion,
				 @tmp_arg_alias		=	@QueryAlias,
				 @tmp_arg_seq		=	@QuerySeq,
				 @tmp_HdnKeyField	=	@HdnKeyField	--13639
--TECH-68063
		IF @tmp_arg_name LIKE '%.%' 
		BEGIN 
			SELECT @tmp_queryname		= SUBSTRING(@tmp_arg_name,1,charindex('.',@tmp_arg_name)-1),
				   @tmp_ChildQueryName	= SUBSTRING(@tmp_arg_name,charindex('.',@tmp_arg_name)+1,LEN(@tmp_arg_name))
		END
		ELSE
		BEGIN
			SELECT @tmp_queryname		= @tmp_arg_name,
				   @tmp_ChildQueryName	= ''
		END

		IF EXISTS(
		SELECT 'X'
		FROM de_task_gql_field_mapping (nolock)
		WHERE	CustomerName			=	@CustomerName  
		AND		ProjectName				=	@ProjectName  
		AND		ProcessName				=   @tmp_process_name
		AND		ComponentName			=	@tmp_component_name 
		AND		ActivityName			=   @tmp_activity_name
		AND		UIName					=   @tmp_ui_name 
		AND		TaskName				=	@tmp_task_name
		AND		QueryName				=	@tmp_queryname
		AND		ChildQueryName			=	@tmp_ChildQueryName
		AND		CaptionFor				IN	('Page','Section'))
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 1
		END
		ELSE 
		BEGIN
			SELECT @tmp_IncLayoutCtrls = 0
		END
--TECH-68063
	END  
	
	SELECT	@tmp_engg_gqpopup_json		=	IntrospectionJSONName,
			@tmp_engg_gqpopup_jsonDBC	=	IntrospectionJSONDbc,
			@tmp_engg_gqpopup_schema	=	SDLSchemaName,
			@tmp_engg_gqpopup_schemaDBC	=	SDLSchemaDbc,
			@tmp_VersionNumber			=	[Version],
			@tmp_sdl_text				=	sdl_text
	FROM	fw_graphql_sdl (NOLOCK)
	WHERE customername			=	@CustomerName  
	AND   projectname			=	@ProjectName  
	--AND   DocNo					=	@ecrno  
	AND   ProcessName			=   @tmp_process_name
	AND   ComponentName			=	@tmp_component_name	
	ORDER BY CREATEDDATE DESC	--13639 on 26thApr2022

	---Code Added by 13639 starts
	IF NOT EXISTS ( SELECT 'X'
					FROM	de_gql_comp_metadata WITH (NOLOCK)
					WHERE	CustomerName	=	@CustomerName
					AND		ProjectName		=	@ProjectName
					AND		ProcessName		=	@tmp_process_name
					AND		ComponentName	=	@tmp_component_name )
		BEGIN
			INSERT INTO de_gql_comp_metadata
							(	CustomerName,		ProjectName,	ProcessName,		ComponentName,
								QuerySplitLevel,	TimeStamp,
								CreatedBy,			CreatedDate,	ModifiedBy,			ModifiedDate )
			SELECT
								@CustomerName,		@ProjectName,	@tmp_process_name,	@tmp_component_name,
									2,					1,
								@ctxt_user,			getdate(),		@ctxt_user,			getdate() 
	---Code Added by 13639 Ends
	END
	SELECT 
		@CustomerName				'engg_gqhdr_cust',
		@ProjectName				'engg_gqhdr_proj',
		@ecrno						'engg_gqhdr_ecrno',
		@ProcessDesc				'engg_gqhdr_prodescr',
		@tmp_process_name			'engg_gqhdr_prcname',
		@ComponentDesc				'engg_gqhdr_cmpdescr',
		@tmp_component_name			'engg_gqhdr_cmpname',
		@ActivityDesc				'engg_gqhdr_actdescr',
		@tmp_activity_name			'engg_gqhdr_actname',
		@UiDesc						'engg_gqhdr_uidescr',
		@tmp_ui_name		        'engg_gqhdr_uiname',
		@tmp_task_name			    'engg_gqhdr_tskname',
		@tmp_task_Desc				'engg_gqhdr_taskdescr',
		@tmp_task_type				'engg_gqhdr_tasktype',
		@tmp_arg_name				'engg_arg_qry',
		@tmp_arg_type				'emgg_arg_qrytype',
		@tmp_arg_version			'engg_arg_qryversion',
		@tmp_arg_alias				'engg_arg_qryalias',
		@tmp_arg_seq				'engg_arg_qryseq',
		@tmp_arg_name				'engg_fld_qry',
		@tmp_arg_type				'engg_fld_qrytype',
		@tmp_arg_version			'engg_fld_qry_version',
		@tmp_arg_alias				'engg_fld_qryalias',
		@tmp_arg_seq				'engg_fld_qryseq',
		@tmp_engg_gqpopup_json		'engg_gqpopup_json',
		@tmp_engg_gqpopup_jsonDBC	'engg_gqpopup_jsonDBC',
		@tmp_engg_gqpopup_schema	'engg_gqpopup_schema',
		@tmp_engg_gqpopup_schemaDBC	'engg_gqpopup_schemaDBC',
		@tmp_VersionNumber			'version',
		'y'							'engg_gqhdr_isgql',		--07Mar2022
		@tmp_HdnKeyField			'engg_arg_qryhdnkeyfield',		--13639
		@tmp_HdnKeyField			'engg_fld_qryhdnkeyfield',		--13639
		@tmp_sdl_text				'schema',					--	11536
		@tmp_IncLayoutCtrls			'engg_gqfld_IncLayoutCtrls',  --TECH-68063
		@tmp_launchmode				'engg_gq_rep_launchmode',
		@tmp_oufrmt					'engg_gq_rep_oufrmt',	
		@tmp_reportname				'engg_gq_rep_reportname'	--Code Added for the Defect Id Tech-72114


	SET NOCOUNT OFF

END


GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DE_GQL_FetchHdr_MScr' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  DE_GQL_FetchHdr_MScr TO PUBLIC
END
GO



