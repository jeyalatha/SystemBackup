if exists ( Select 'y' from sysobjects where name = 'ACHgqlSpactdesrepgrdspO' and type = 'P')
    begin
        drop proc ACHgqlSpactdesrepgrdspO
    end
go


/********************************************************************************/
/* Procedure                               : ACHgqlSpactdesrepgrdspO             */
/* Description                             :                                    */
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :                                    */
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U / Jeya Latha K    */
/* Date                                    : 20-Aug-2022                        */
/* rTrack ID                               : TECH-72114                         */
/* Description                             : Report modeling enablement in 
									platform model for GQL based user interfaces*/
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/

Create Procedure ACHgqlSpactdesrepgrdspO
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@engg_gqfld_inclayoutctrls 	engg_qry_seq, --Input 
	@engg_gqhdr_actdescr       	engg_description, --Input 
	@engg_gqhdr_actname        	engg_name, --Input 
	@engg_gqhdr_cmpdescr       	engg_description, --Input 
	@engg_gqhdr_cmpname        	engg_name, --Input 
	@engg_gqhdr_cust           	engg_name, --Input 
	@engg_gqhdr_ecrno          	engg_name, --Input 
	@engg_gqhdr_prcname        	engg_name, --Input 
	@engg_gqhdr_prodescr       	engg_description, --Input 
	@engg_gqhdr_proj           	engg_name, --Input 
	@engg_gqhdr_taskdescr      	engg_description, --Input 
	@engg_gqhdr_tasktype       	engg_type, --Input 
	@engg_gqhdr_tskname        	engg_name, --Input 
	@engg_gqhdr_uidescr        	engg_description, --Input 
	@engg_gqhdr_uiname         	engg_name, --Input 
	@engg_gq_rep_launchmode    	engg_type, --Input 
	@engg_gq_rep_oufrmt        	engg_type, --Input 
	@engg_gq_rep_reportname    	engg_name, --Input 
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service               = ltrim(rtrim(@ctxt_service))
	Set @engg_gqhdr_actdescr        = ltrim(rtrim(@engg_gqhdr_actdescr))
	Set @engg_gqhdr_actname         = ltrim(rtrim(@engg_gqhdr_actname))
	Set @engg_gqhdr_cmpdescr        = ltrim(rtrim(@engg_gqhdr_cmpdescr))
	Set @engg_gqhdr_cmpname         = ltrim(rtrim(@engg_gqhdr_cmpname))
	Set @engg_gqhdr_cust            = ltrim(rtrim(@engg_gqhdr_cust))
	Set @engg_gqhdr_ecrno           = ltrim(rtrim(@engg_gqhdr_ecrno))
	Set @engg_gqhdr_prcname         = ltrim(rtrim(@engg_gqhdr_prcname))
	Set @engg_gqhdr_prodescr        = ltrim(rtrim(@engg_gqhdr_prodescr))
	Set @engg_gqhdr_proj            = ltrim(rtrim(@engg_gqhdr_proj))
	Set @engg_gqhdr_taskdescr       = ltrim(rtrim(@engg_gqhdr_taskdescr))
	Set @engg_gqhdr_tasktype        = ltrim(rtrim(@engg_gqhdr_tasktype))
	Set @engg_gqhdr_tskname         = ltrim(rtrim(@engg_gqhdr_tskname))
	Set @engg_gqhdr_uidescr         = ltrim(rtrim(@engg_gqhdr_uidescr))
	Set @engg_gqhdr_uiname          = ltrim(rtrim(@engg_gqhdr_uiname))
	Set @engg_gq_rep_launchmode     = ltrim(rtrim(@engg_gq_rep_launchmode))
	Set @engg_gq_rep_oufrmt         = ltrim(rtrim(@engg_gq_rep_oufrmt))
	Set @engg_gq_rep_reportname     = ltrim(rtrim(@engg_gq_rep_reportname))

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_gqfld_inclayoutctrls = -915
		Select @engg_gqfld_inclayoutctrls = null  

	IF @engg_gqhdr_actdescr = '~#~' 
		Select @engg_gqhdr_actdescr = null  

	IF @engg_gqhdr_actname = '~#~' 
		Select @engg_gqhdr_actname = null  

	IF @engg_gqhdr_cmpdescr = '~#~' 
		Select @engg_gqhdr_cmpdescr = null  

	IF @engg_gqhdr_cmpname = '~#~' 
		Select @engg_gqhdr_cmpname = null  

	IF @engg_gqhdr_cust = '~#~' 
		Select @engg_gqhdr_cust = null  

	IF @engg_gqhdr_ecrno = '~#~' 
		Select @engg_gqhdr_ecrno = null  

	IF @engg_gqhdr_prcname = '~#~' 
		Select @engg_gqhdr_prcname = null  

	IF @engg_gqhdr_prodescr = '~#~' 
		Select @engg_gqhdr_prodescr = null  

	IF @engg_gqhdr_proj = '~#~' 
		Select @engg_gqhdr_proj = null  

	IF @engg_gqhdr_taskdescr = '~#~' 
		Select @engg_gqhdr_taskdescr = null  

	IF @engg_gqhdr_tasktype = '~#~' 
		Select @engg_gqhdr_tasktype = null  

	IF @engg_gqhdr_tskname = '~#~' 
		Select @engg_gqhdr_tskname = null  

	IF @engg_gqhdr_uidescr = '~#~' 
		Select @engg_gqhdr_uidescr = null  

	IF @engg_gqhdr_uiname = '~#~' 
		Select @engg_gqhdr_uiname = null  

	IF @engg_gq_rep_launchmode = '~#~' 
		Select @engg_gq_rep_launchmode = null  

	IF @engg_gq_rep_oufrmt = '~#~' 
		Select @engg_gq_rep_oufrmt = null  

	IF @engg_gq_rep_reportname = '~#~' 
		Select @engg_gq_rep_reportname = null  

		SELECT	glo.bt_synonym_caption	'engg_gq_rep_caption', 
				rep.BTSynonym			'engg_gq_rep_controlbtsyn', 
				rep.ControlID			'engg_gq_rep_ctrlid', 
				rep.DefaultValue		'engg_gq_rep_defvalue', 
				rep.ParameterName		'engg_gq_rep_paramname', 
				rep.ViewName			'engg_gq_rep_viewname'
	FROM	de_task_gql_report_param rep WITH(NOLOCK) 
	LEFT JOIN	de_glossary	glo WITH(NOLOCK)
	ON		rep.CustomerName		=	glo.customer_name
	AND		rep.ProjectName			=	glo.project_name
	AND		rep.ProcessName			=	glo.Process_Name
	AND		rep.ComponentName		=	glo.component_name
	AND		rep.BTSynonym			=	glo.bt_synonym_name
	WHERE	rep.CustomerName		=	@engg_gqhdr_cust
	AND		rep.ProjectName			=	@engg_gqhdr_proj
	AND		rep.DocNo				=	@engg_gqhdr_ecrno
	AND		rep.ProcessName			=	@engg_gqhdr_prcname
	AND		rep.ComponentName		=	@engg_gqhdr_cmpname
	AND		rep.ActivityName		=	@engg_gqhdr_actname
	AND		rep.UIName				=	@engg_gqhdr_uiname
	AND		rep.TaskName			=	@engg_gqhdr_tskname


	/* 
	-- OutputList
	Select
		null 'engg_gq_rep_caption', 
		null 'engg_gq_rep_controlbtsyn', 
		null 'engg_gq_rep_defvalue', 
		null 'engg_gq_rep_paramname', 
	*/

	Set nocount off
End

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'ACHgqlSpactdesrepgrdspO' AND TYPE='P')
BEGIN
    GRANT EXEC ON  ACHgqlSpactdesrepgrdspO TO PUBLIC
END
GO
