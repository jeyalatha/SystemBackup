IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_des_publish_task_gql_argument_mapping_xml_vw_fn' AND TYPE = 'IF')
BEGIN
	DROP FUNCTION fw_des_publish_task_gql_argument_mapping_xml_vw_fn
END
GO
/******************************************************************************/
/* Procedure					: fw_des_publish_task_gql_argument_mapping_xml_vw_fn	  */
/* Description					: 								 			  */
/* Author						: Venkatesh K 								  */
/* Date							: 14-02-2020 09:00:00						  */
/******************************************************************************/
/* Modified By	: Priyadharshini U	/ JeyaLatha K								*/
/* Defect ID	: TECH-67697													*/
/* Modified on	: 31Mar2022														*/
/* Description	: GQL Changes.													*/
/********************************************************************************/

CREATE FUNCTION fw_des_publish_task_gql_argument_mapping_xml_vw_fn 
(
	@customer_name	engg_name, 
	@project_name	engg_name, 
	@ecr_no			engg_name,
	@processname	engg_name,
	@componentname	engg_name,
	@activityname	engg_name,
	@uiname			engg_name
)
RETURNS TABLE
AS
RETURN
	SELECT	a.CustomerName,			a.ProjectName,			a.DocNo,		a.ProcessName,
			a.ComponentName,		a.ActivityName,			a.UIName,		a.TaskName,
			a.QuerySequence,		a.QueryName,			a.Argument,		a.ControlID,
			a.ViewName,				a.ArgumentType,			a.DataType,		a.IsMandatory,
			a.BTSynonym,			a.DefaultValue,			a.Version,		a.FlattenedArgumentName,
			b.typekind,				b.oftypename,			b.oftypekind,	b.typerequired,
			b.oftyperequired,		a.ChildQueryName,		a.ProcessingType
	FROM	de_published_task_gql_argument_mapping a (NOLOCK)
	INNER JOIN	fw_published_graphql_arg_fields b (NOLOCK)
	ON		a.CustomerName	=	b.customername
	AND		a.ProjectName	=	b.projectname
	AND		a.ProcessName	=	b.processname
	AND		a.ComponentName	=	b.componentname
	AND		a.DocNo			=	b.docno
	--AND		a.QueryName		=	b.queryname
	AND		a.QueryName	=	REPLACE (REPLACE(b.QueryName,'Query.',''),'Mutation.','')
	--AND		a.QueryName		=	CASE WHEN b.querysplitlevel = 2 THEN REPLACE (REPLACE(b.parentkey,'Query.',''),'Mutation.','') 
	--								 ELSE REPLACE (REPLACE(b.QueryName,'Query.',''),'Mutation.','') END                --25feb2022
	AND		a.Version		=	b.importversion
	AND		a.FlattenedArgumentName			=	REPLACE (REPLACE(b.[key],'Query.',''),'Mutation.','')
	AND		b.category		IN	('InputField','Arg')

	WHERE	a.customername	=	@customer_name
	AND		a.projectname	=	@project_name
	AND		a.docno			=	@ecr_no
	AND		a.processname	=	@processname
	AND		a.componentname	=	@componentname
	AND		a.activityname	=	@activityname
	AND		a.uiname		=	@uiname
	UNION
	SELECT	a.CustomerName,			a.ProjectName,			a.DocNo,		a.ProcessName,
			a.ComponentName,		a.ActivityName,			a.UIName,		a.TaskName,
			a.QuerySequence,		a.QueryName,			a.Argument,		a.ControlID,
			a.ViewName,				a.ArgumentType,			a.DataType,		a.IsMandatory,
			a.BTSynonym,			a.DefaultValue,			a.Version,		a.FlattenedArgumentName,
			b.typekind,				b.oftypename,			b.oftypekind,	b.typerequired,
			b.oftyperequired,		a.ChildQueryName,		a.ProcessingType
	FROM	de_published_task_gql_argument_mapping a (NOLOCK)
	INNER JOIN	fw_published_graphql_arg_fields b (NOLOCK)
	ON		a.CustomerName	=	b.customername
	AND		a.ProjectName	=	b.projectname
	AND		a.ProcessName	=	b.processname
	AND		a.ComponentName	=	b.componentname
	AND		a.DocNo			=	b.docno
	--AND		a.QueryName		=	b.queryname
	AND		a.QueryName	=	REPLACE (REPLACE(b.QueryName,'Query.',''),'Mutation.','')
	AND		a.Version		=	b.importversion
	AND		a.FlattenedArgumentName			=	REPLACE (REPLACE(b.[key],'Query.',''),'Mutation.','')
	--AND		b.category		IN	('InputField','Arg')
	AND		ISNULL(a.ProcessingType,'') <> ''

	WHERE	a.customername	=	@customer_name
	AND		a.projectname	=	@project_name
	AND		a.docno			=	@ecr_no
	AND		a.processname	=	@processname
	AND		a.componentname	=	@componentname
	AND		a.activityname	=	@activityname
	AND		a.uiname		=	@uiname


--IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'fw_des_publish_task_gql_argument_mapping_xml_vw_fn' AND TYPE = 'P')
--BEGIN
--	GRANT EXEC ON fw_des_publish_task_gql_argument_mapping_xml_vw_fn TO PUBLIC
--END
--GO



