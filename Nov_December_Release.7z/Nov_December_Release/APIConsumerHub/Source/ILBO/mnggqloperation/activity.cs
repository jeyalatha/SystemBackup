/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   activity.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
[assembly: System.Reflection.AssemblyDescriptionAttribute("ramco/PLF/Engineering/ACH_ECR_00083/apiconsumerhub/TECHWARCNV56/06-12-2022 11:35:" +
    "51/1E293F9A-8FA8-4B56-B386-CCAC76ECEF9F")]
[assembly: System.Reflection.AssemblyTitleAttribute("ramco/PLF/Engineering/ACH_ECR_00083/apiconsumerhub/TECHWARCNV56/06-12-2022 11:35:" +
    "51/1E293F9A-8FA8-4B56-B386-CCAC76ECEF9F")]

namespace mnggqloperation
{
    using System;
    using System.Web;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;

    // <summary>
    // This class defines all the methods of Activity class
    // </summary>
    [Serializable()]
    public class activity : CActivity
    {
        private Dictionary<string, Object> htContextItems = new Dictionary<string, Object>();
        private de_graphqlstudio m_ode_graphqlstudio = null;
        private Dictionary<long, de_graphqlstudio> m_ode_graphqlstudio_Cyclic = new Dictionary<long, de_graphqlstudio>();
        private de_schemavisualizer m_ode_schemavisualizer = null;
        private Dictionary<long, de_schemavisualizer> m_ode_schemavisualizer_Cyclic = new Dictionary<long, de_schemavisualizer>();
        private de_task_gql m_ode_task_gql = null;
        private Dictionary<long, de_task_gql> m_ode_task_gql_Cyclic = new Dictionary<long, de_task_gql>();
        private zachfieldfldgrd m_ozachfieldfldgrd = null;
        private Dictionary<long, zachfieldfldgrd> m_ozachfieldfldgrd_Cyclic = new Dictionary<long, zachfieldfldgrd>();
        private zachqueryqrygrd m_ozachqueryqrygrd = null;
        private Dictionary<long, zachqueryqrygrd> m_ozachqueryqrygrd_Cyclic = new Dictionary<long, zachqueryqrygrd>();
        private zachreportrepgrd m_ozachreportrepgrd = null;
        private Dictionary<long, zachreportrepgrd> m_ozachreportrepgrd_Cyclic = new Dictionary<long, zachreportrepgrd>();
        public activity()
        {
            ComponentName = "apiconsumerhub";
            ActivityName = "mnggqloperation";
        }
        // <summary>
        // This method Creates/Gets the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	GetILBO
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Creates/Gets the Object Handle of the ILBO
        // ***************************************************************************
        public override IILBO GetILBO(string sILBOCode)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetILBO(sILBOCode = \"" + sILBOCode + "\")", "ACT0001");
                switch (sILBOCode)
                {
                    case "de_graphqlstudio":
                        if ((m_ode_graphqlstudio == null))
                        {
                            m_ode_graphqlstudio = new de_graphqlstudio();
                        }
                        return m_ode_graphqlstudio;
                    case "de_schemavisualizer":
                        if ((m_ode_schemavisualizer == null))
                        {
                            m_ode_schemavisualizer = new de_schemavisualizer();
                        }
                        return m_ode_schemavisualizer;
                    case "de_task_gql":
                        if ((m_ode_task_gql == null))
                        {
                            m_ode_task_gql = new de_task_gql();
                        }
                        return m_ode_task_gql;
                    case "zachfieldfldgrd":
                        if ((m_ozachfieldfldgrd == null))
                        {
                            m_ozachfieldfldgrd = new zachfieldfldgrd();
                        }
                        return m_ozachfieldfldgrd;
                    case "zachqueryqrygrd":
                        if ((m_ozachqueryqrygrd == null))
                        {
                            m_ozachqueryqrygrd = new zachqueryqrygrd();
                        }
                        return m_ozachqueryqrygrd;
                    case "zachreportrepgrd":
                        if ((m_ozachreportrepgrd == null))
                        {
                            m_ozachreportrepgrd = new zachreportrepgrd();
                        }
                        return m_ozachreportrepgrd;
                    default:
                        return base.GetILBO(sILBOCode);
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : GetILBO(sILBOCode=\"{0}\")", sILBOCode), "Act0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Disposes the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	DisposeILBO
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Disposes the Object Handle of the ILBO
        // ***************************************************************************
        public override void DisposeILBO(string sILBOCode)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "DisposeILBO(sILBOCode = \"" + sILBOCode + "\")", "ACT0002");
                switch (sILBOCode)
                {
                    case "de_graphqlstudio":
                        if ((m_ode_graphqlstudio != null))
                        {
                            m_ode_graphqlstudio = null;
                        }
                        break;
                    case "de_schemavisualizer":
                        if ((m_ode_schemavisualizer != null))
                        {
                            m_ode_schemavisualizer = null;
                        }
                        break;
                    case "de_task_gql":
                        if ((m_ode_task_gql != null))
                        {
                            m_ode_task_gql = null;
                        }
                        break;
                    case "zachfieldfldgrd":
                        if ((m_ozachfieldfldgrd != null))
                        {
                            m_ozachfieldfldgrd = null;
                        }
                        break;
                    case "zachqueryqrygrd":
                        if ((m_ozachqueryqrygrd != null))
                        {
                            m_ozachqueryqrygrd = null;
                        }
                        break;
                    case "zachreportrepgrd":
                        if ((m_ozachreportrepgrd != null))
                        {
                            m_ozachreportrepgrd = null;
                        }
                        break;
                    default:
                        base.DisposeILBO(sILBOCode);
                        break;
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : DisposeILBO(sILBOCode=\"{0}\")", sILBOCode), "Act0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Creates/Gets the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	GetILBOEx
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Creates/Gets the Object Handle of the ILBO
        // ***************************************************************************
        public override IILBO GetILBOEx(string sILBOCode, long lILBOIndex)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0003");
                switch (sILBOCode)
                {
                    case "de_graphqlstudio":
                        if ((m_ode_graphqlstudio_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ode_graphqlstudio_Cyclic.Add((lILBOIndex - 1), new de_graphqlstudio());
                        }
                        return m_ode_graphqlstudio_Cyclic[(lILBOIndex - 1)];
                    case "de_schemavisualizer":
                        if ((m_ode_schemavisualizer_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ode_schemavisualizer_Cyclic.Add((lILBOIndex - 1), new de_schemavisualizer());
                        }
                        return m_ode_schemavisualizer_Cyclic[(lILBOIndex - 1)];
                    case "de_task_gql":
                        if ((m_ode_task_gql_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ode_task_gql_Cyclic.Add((lILBOIndex - 1), new de_task_gql());
                        }
                        return m_ode_task_gql_Cyclic[(lILBOIndex - 1)];
                    case "zachfieldfldgrd":
                        if ((m_ozachfieldfldgrd_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ozachfieldfldgrd_Cyclic.Add((lILBOIndex - 1), new zachfieldfldgrd());
                        }
                        return m_ozachfieldfldgrd_Cyclic[(lILBOIndex - 1)];
                    case "zachqueryqrygrd":
                        if ((m_ozachqueryqrygrd_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ozachqueryqrygrd_Cyclic.Add((lILBOIndex - 1), new zachqueryqrygrd());
                        }
                        return m_ozachqueryqrygrd_Cyclic[(lILBOIndex - 1)];
                    case "zachreportrepgrd":
                        if ((m_ozachreportrepgrd_Cyclic.ContainsKey((lILBOIndex - 1)) != true))
                        {
                            m_ozachreportrepgrd_Cyclic.Add((lILBOIndex - 1), new zachreportrepgrd());
                        }
                        return m_ozachreportrepgrd_Cyclic[(lILBOIndex - 1)];
                    default:
                        return base.GetILBOEx(sILBOCode, lILBOIndex);
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "GetILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0003 - Exception - e.Message");
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Disposes the Object Handle of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	DisposeILBOEx
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Disposes the Object Handle of the ILBO
        // ***************************************************************************
        public override void DisposeILBOEx(string sILBOCode, long lILBOIndex)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "DisposeILBOEx(sILBOCode = \"" + sILBOCode + "\", lILBOIndex = \"" + lILBOIndex + "\")", "ACT0004");
                switch (sILBOCode)
                {
                    case "de_graphqlstudio":
                        if ((lILBOIndex > 0))
                        {
                            m_ode_graphqlstudio_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ode_graphqlstudio_Cyclic.Clear();
                        }
                        break;
                    case "de_schemavisualizer":
                        if ((lILBOIndex > 0))
                        {
                            m_ode_schemavisualizer_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ode_schemavisualizer_Cyclic.Clear();
                        }
                        break;
                    case "de_task_gql":
                        if ((lILBOIndex > 0))
                        {
                            m_ode_task_gql_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ode_task_gql_Cyclic.Clear();
                        }
                        break;
                    case "zachfieldfldgrd":
                        if ((lILBOIndex > 0))
                        {
                            m_ozachfieldfldgrd_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ozachfieldfldgrd_Cyclic.Clear();
                        }
                        break;
                    case "zachqueryqrygrd":
                        if ((lILBOIndex > 0))
                        {
                            m_ozachqueryqrygrd_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ozachqueryqrygrd_Cyclic.Clear();
                        }
                        break;
                    case "zachreportrepgrd":
                        if ((lILBOIndex > 0))
                        {
                            m_ozachreportrepgrd_Cyclic.Remove((lILBOIndex - 1));
                        }
                        else
                        {
                            m_ozachreportrepgrd_Cyclic.Clear();
                        }
                        break;
                    default:
                        base.DisposeILBOEx(sILBOCode, lILBOIndex);
                        break;
                }//ENDSWITCH
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : DisposeILBOEx(sILBOCode=\"{0}\")", sILBOCode), "Act0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value Information
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value Information
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "GetContextValue(sContextName = \"" + sContextName + "\")", "ACT0005");
                return this.htContextItems[sContextName];
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : GetContextValue(sContextName=\"{0}\")", sContextName), "Act0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Sets the Context Value Information
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Sets the Context Value Information
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "SetContextValue(sContextName = \"" + sContextName + "\", sContextValue = \"" + sContextValue + "\")", "ACT0006");
                htContextItems[sContextName] = sContextValue;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("activity : SetContextValue(sContextName=\"{0}\",sContextValue=\"{1}\")", sContextName, sContextValue), "Act0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "FillMessageObject(sMethod = \"" + sMethod + "\", sErrNumber = \"" + sErrNumber + "\", sErrMessage = \"" + sErrMessage + "\")", "");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "FillMessageObject(sMethod = \"" + sMethod + "\", sErrNumber = \"" + sErrNumber + "\", sErrMessage = \"" + sErrMessage + "\")", " - Exception - e.Message");
                throw new Exception(e.Message, e);
            }
        }
    }
}

