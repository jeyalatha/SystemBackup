/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   de_graphqlstudio.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace mnggqloperation
{
    using System;
    using System.Web;
    using System.Xml;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;
    using Ramco.VW.RT.Web.Controls;
    using Ramco.VW.RT.Web.Core.Controls.LayoutControls;
    using Ramco.VW.RT.AsyncResult;
    using Ramco.VW.RT.State;
    using Plf.Ui.Ramco.Utility;
    using System.Reflection;

    // <summary>
    // This class defines all the methods of de_graphqlstudio class
    // </summary>
    [Serializable()]
    internal sealed class de_graphqlstudio : CILBO
    {
        private Dictionary<String, Object> htContextItems = new Dictionary<String, Object>();
        private Edit m_conhdnhdncustomer = new Edit();
        private Edit m_conhdnhdnproject = new Edit();
        private Edit m_conhdniframesec_txt = new Edit();
        private Edit m_conhdnprj_hdn_ctrl = new Edit();
        private Edit m_contxtactivityname_hdr = new Edit();
        private Edit m_contxtcomponentname = new Edit();
        private Edit m_contxtcustomername_hdr = new Edit();
        private Edit m_contxtcustominput = new Edit();
        private Edit m_contxtdocno_hdr = new Edit();
        private Edit m_contxtprocessname_hdr = new Edit();
        private Edit m_contxtprojectname_hdr = new Edit();
        private Edit m_contxtuiname = new Edit();
        private Button _btnsave = new Button();
        private Section _iframesec = new Section();
        private Section _prjhdnsection = new Section();
        private Section _sechdn_save_sec = new Section();
        private Section _sechiddensec = new Section();
        private Tab _mainpage = new Tab();
        private Edit m_conrvwrt_cctxt_component = new Edit();
        private Edit m_conrvwrt_cctxt_ou = new Edit();
        private Edit m_conrvwrt_lctxt_ou = new Edit();
        // <summary>
        // This method Calls the AddViewInfo and InitializeControls
        // </summary>
        // **************************************************************************
        // Function Name		:	de_graphqlstudio
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Calls the AddViewInfo and InitializeControls
        // ***************************************************************************
        public de_graphqlstudio()
        {
            IsPreProcess1 = true;
            IsPreProcess3 = true;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "de_graphqlstudio()", "de_graphqlstudio");
                this.SetContextValue("ICT_COMPONENTNAME", "apiconsumerhub");
                this.SetContextValue("ICT_COMPONENTDESCRIPTION", "API Consumer HUB");
                this.SetContextValue("ICT_ACTIVITYNAME", "mnggqloperation");
                this.SetContextValue("ICT_ACTIVITYDESCRIPTION", "Manage GQL Operations");
                this.SetContextValue("ICT_ILBOCODE", "de_graphqlstudio");
                this.SetContextValue("ICT_ILBODESCRIPTION", "GraphQL Studio");
                base.LoadILBODefinition("apiconsumerhub", "mnggqloperation", "de_graphqlstudio");
                this.InitializeTabControls();
                this.InitializeLayoutControls();
                this.AddViewInfo();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "de_graphqlstudio()", "de_graphqlstudio");
                throw new System.Exception(e.Message, e);
            }
        }
        public void Clear()
        {
        }
        // <summary>
        // This method Initializes the controls of Enumerated datatype.
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes the controls of Enumerated datatype.
        // ***************************************************************************
        private new void InitializeControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeControls()", "de_graphqlstudio");
                m_conhdnhdncustomer.SetIdentity("hdnhdncustomer", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdncustomer");
                m_conhdnhdnproject.SetIdentity("hdnhdnproject", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdnproject");
                m_conhdniframesec_txt.SetIdentity("hdniframesec_txt", ControlType.RSTextArea);
                _mainpage.AddControl("hdniframesec_txt");
                m_conhdnprj_hdn_ctrl.SetIdentity("hdnprj_hdn_ctrl", ControlType.RSEdit);
                _mainpage.AddControl("hdnprj_hdn_ctrl");
                m_contxtactivityname_hdr.SetIdentity("txtactivityname_hdr", ControlType.RSEdit);
                _mainpage.AddControl("txtactivityname_hdr");
                m_contxtcomponentname.SetIdentity("txtcomponentname", ControlType.RSEdit);
                _mainpage.AddControl("txtcomponentname");
                m_contxtcustomername_hdr.SetIdentity("txtcustomername_hdr", ControlType.RSEdit);
                _mainpage.AddControl("txtcustomername_hdr");
                m_contxtcustominput.SetIdentity("txtcustominput", ControlType.RSEdit);
                _mainpage.AddControl("txtcustominput");
                m_contxtdocno_hdr.SetIdentity("txtdocno_hdr", ControlType.RSEdit);
                _mainpage.AddControl("txtdocno_hdr");
                m_contxtprocessname_hdr.SetIdentity("txtprocessname_hdr", ControlType.RSEdit);
                _mainpage.AddControl("txtprocessname_hdr");
                m_contxtprojectname_hdr.SetIdentity("txtprojectname_hdr", ControlType.RSEdit);
                _mainpage.AddControl("txtprojectname_hdr");
                m_contxtuiname.SetIdentity("txtuiname", ControlType.RSEdit);
                _mainpage.AddControl("txtuiname");
                if (iEDKEIExists)
                {
                    base.InitializeControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : InitializeControls()", "ILBO0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets all the controls of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets all the controls of the ILBO
        // ***************************************************************************
        public override void ResetControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetControls()", "de_graphqlstudio");
                m_conhdnhdncustomer.ClearAll();
                m_conhdnhdnproject.ClearAll();
                m_conhdniframesec_txt.ClearAll();
                m_conhdnprj_hdn_ctrl.ClearAll();
                m_contxtactivityname_hdr.ClearAll();
                m_contxtcomponentname.ClearAll();
                m_contxtcustomername_hdr.ClearAll();
                m_contxtcustominput.ClearAll();
                m_contxtdocno_hdr.ClearAll();
                m_contxtprocessname_hdr.ClearAll();
                m_contxtprojectname_hdr.ClearAll();
                m_contxtuiname.ClearAll();
                this.ResetLayoutControls();
                this.ResetTabControls();
                if (iEDKEIExists)
                {
                    base.ResetControls();
                }
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : ResetControls()", "ILBO0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method adds view information to the controls.
        // </summary>
        // **************************************************************************
        // Function Name		:	AddViewInfo
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	adds view information to the controls.
        // ***************************************************************************
        private new void AddViewInfo()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "AddViewInfo()", "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                m_conhdnhdncustomer.AddView("hdnhdncustomer", true, "char", String.Empty, String.Empty);
                m_conhdnhdnproject.AddView("hdnhdnproject", true, "char", String.Empty, String.Empty);
                m_conhdniframesec_txt.AddView("hdniframesec_txt", true, "char", String.Empty, String.Empty);
                m_conhdnprj_hdn_ctrl.AddView("hdnprj_hdn_ctrl", true, "char", String.Empty, String.Empty);
                m_contxtactivityname_hdr.AddView("txtactivityname_hdr", true, "char", String.Empty, String.Empty);
                m_contxtcomponentname.AddView("txtcomponentname", true, "char", String.Empty, String.Empty);
                m_contxtcustomername_hdr.AddView("txtcustomername_hdr", true, "char", String.Empty, String.Empty);
                m_contxtcustominput.AddView("txtcustominput", true, "char", String.Empty, String.Empty);
                m_contxtdocno_hdr.AddView("txtdocno_hdr", true, "char", String.Empty, String.Empty);
                m_contxtprocessname_hdr.AddView("txtprocessname_hdr", true, "char", String.Empty, String.Empty);
                m_contxtprojectname_hdr.AddView("txtprojectname_hdr", true, "char", String.Empty, String.Empty);
                m_contxtuiname.AddView("txtuiname", true, "char", String.Empty, String.Empty);
                m_conrvwrt_lctxt_ou.AddView("rvwrt_lctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_ou.AddView("rvwrt_cctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_component.AddView("rvwrt_cctxt_component", false, "char", String.Empty, String.Empty);
                if (iEDKEIExists)
                {
                    base.AddViewInfo();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : AddViewInfo()", "ILBO0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method creates/gets the Object Handle of the Control
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControlX
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	creates/gets the Object Handle of the Control
        // ***************************************************************************
        public override IControl GetControlX(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControlX(sControlID = \"{0}\")", sControlID), "de_graphqlstudio");
                switch (sControlID.ToLower())
                {
                    case "hdnhdncustomer":
                        return this.m_conhdnhdncustomer;
                    case "hdnhdnproject":
                        return this.m_conhdnhdnproject;
                    case "hdniframesec_txt":
                        return this.m_conhdniframesec_txt;
                    case "hdnprj_hdn_ctrl":
                        return this.m_conhdnprj_hdn_ctrl;
                    case "txtactivityname_hdr":
                        return this.m_contxtactivityname_hdr;
                    case "txtcomponentname":
                        return this.m_contxtcomponentname;
                    case "txtcustomername_hdr":
                        return this.m_contxtcustomername_hdr;
                    case "txtcustominput":
                        return this.m_contxtcustominput;
                    case "txtdocno_hdr":
                        return this.m_contxtdocno_hdr;
                    case "txtprocessname_hdr":
                        return this.m_contxtprocessname_hdr;
                    case "txtprojectname_hdr":
                        return this.m_contxtprojectname_hdr;
                    case "txtuiname":
                        return this.m_contxtuiname;
                    case "rvwrt_cctxt_component":
                        return this.m_conrvwrt_cctxt_component;
                    case "rvwrt_cctxt_ou":
                        return this.m_conrvwrt_cctxt_ou;
                    case "rvwrt_lctxt_ou":
                        return this.m_conrvwrt_lctxt_ou;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.GetControlX(sControlID);
                        }
                        else
                        {
                            return null;
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetControlX(sControlID = \"{0}\")", sControlID), "ILBO0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override IControl GetControl(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControl(sControlID = \"{0}\")", sControlID), "de_graphqlstudio");
                IControl control = this.GetControlX(sControlID);
                if ((control != null))
                {
                    return control;
                }
                else
                {
                    throw new Exception("String.Format(\"Invalid ControlID - {0}\", sControlID)");
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetControl(sControlID = \"{0}\")", sControlID), "ILBO0005", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem
        // ***************************************************************************
        public override string GetDataItem(string sLinkID, string sDataItemName, long nInstance)
        {
            string sRetData = String.Empty;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "de_graphqlstudio");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItem(sLinkID, sDataItemName, nInstance);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\"), nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "ILBO0006", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem Instances.
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItemInstances
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem Instances.
        // ***************************************************************************
        public override long GetDataItemInstances(string sLinkID, string sDataItemName)
        {
            long sRetData = 0;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "de_graphqlstudio");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItemInstances(sLinkID, sDataItemName);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "ILBO0007", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method sets the DataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	SetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	sets the DataItem
        // ***************************************************************************
        public override void SetDataItem(string sLinkID, string sDataItemName, long nInstance, string sValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\",nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance, sValue), "de_graphqlstudio");
                bool bFlag = false;
                switch (sLinkID)
                {
                    case "ezeeview":
                        return;
                    case "12587":
                        if ((sDataItemName == "activityname_hdr"))
                        {
                            m_contxtactivityname_hdr.SetControlValue("txtactivityname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "componentname"))
                        {
                            m_contxtcomponentname.SetControlValue("txtcomponentname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "csou"))
                        {
                            m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "customername_hdr"))
                        {
                            m_contxtcustomername_hdr.SetControlValue("txtcustomername_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "custominput"))
                        {
                            m_contxtcustominput.SetControlValue("txtcustominput", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "docno_hdr"))
                        {
                            m_contxtdocno_hdr.SetControlValue("txtdocno_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdncustomer"))
                        {
                            m_conhdnhdncustomer.SetControlValue("hdnhdncustomer", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdnproject"))
                        {
                            m_conhdnhdnproject.SetControlValue("hdnhdnproject", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "iframesec_txt"))
                        {
                            m_conhdniframesec_txt.SetControlValue("hdniframesec_txt", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "prj_hdn_ctrl"))
                        {
                            m_conhdnprj_hdn_ctrl.SetControlValue("hdnprj_hdn_ctrl", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "processname_hdr"))
                        {
                            m_contxtprocessname_hdr.SetControlValue("txtprocessname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "projectname_hdr"))
                        {
                            m_contxtprojectname_hdr.SetControlValue("txtprojectname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "uiname"))
                        {
                            m_contxtuiname.SetControlValue("txtuiname", sValue, 0);
                            return;
                        }
                        break;
                    default:
                        break;
                }
                if ((iEDKEIExists && !bFlag))
                {
                    base.SetDataItem(sLinkID, sDataItemName, nInstance, sValue);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance.ToString(), sValue.ToString()), "ILBO0008", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the GlobalVariable handle
        // </summary>
        // **************************************************************************
        // Function Name		:	GetVariable
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the GlobalVariable handle
        // ***************************************************************************
        public override IGlobalVariable GetVariable(string sVariable)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetVariable(sVariable = \"{0}\")", sVariable), "de_graphqlstudio");
                if (iEDKEIExists)
                {
                    return base.GetVariable(sVariable);
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetVariable(sVariable = \"{0}\")", sVariable), "ILBO0009", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool PerformTask(string sControlID, string sEventName, string sEventDetails, out string sTargetURL)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "de_graphqlstudio");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                sTargetURL = string.Empty;
                switch (sEventName.ToLower())
                {
                    default:
                        if (iEDKEIExists)
                        {
                            return base.PerformTask(sControlID, sEventName, sEventDetails, out sTargetURL);
                        }
                        break;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "ILBO0010", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override IAsyncResult BeginPerformTask(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_graphqlstudio");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                bool bExecFlag = base.PreTaskExecution(reqState);
                if ((bExecFlag == false))
                {
                    return ISManager.SetAsyncException(null);
                }
                switch (reqState.TaskName.ToLower())
                {
                    default:
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        break;
                }
                return ISManager.SetAsyncCompleted(new VWResponseState());
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0011", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool EndPerformTask(IAsyncResult ar)
        {
            VWAsyncResult result = ar as VWAsyncResult;
            VWRequestState reqState = result.AsyncState as VWRequestState;
            VWResponseState resState = result.ResponseState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                long lSubscriptionID = 0;
                bool bServiceResult = true;
                string sTargetURL = string.Empty;
                switch (reqState.TaskName.ToLower())
                {
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndPerformTask(ar);
                        }
                        break;
                }
                if (bServiceResult)
                {
                    bServiceResult = base.PostTaskExecution(reqState.TaskName);
                }
                return bServiceResult;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0012", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method initializes Scripts for Data Transfer
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess1
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	initializes Scripts for Data Transfer
        // ***************************************************************************
        public override bool PreProcess1()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess1", "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IObjectBroker IobjBroker = ISManager.GetObjectBroker();
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_graphqlstudio");
                if (iEDKEIExists)
                {
                    return base.PreProcess1();
                }
                else
                {
                    return true;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : PreProcess1()", "ILBO0013", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool PreProcess2()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess2", "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                // No Initialization Tasks are defined for the ILBO.
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_graphqlstudio");
                if (iEDKEIExists)
                {
                    bReturn = base.PreProcess2();
                    return bReturn;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : PreProcess2()", "ILBO0014 ", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess2(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess2()", "de_graphqlstudio");
                // No Initialize Tasks are defined for the ILBO.
                if (iEDKEIExists)
                {
                    return base.BeginPreProcess2(cb, reqState);
                }
                throw new Exception("No Initialization Tasks are defined for the ILBO.");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : BeginPreProcess2()", "ILBO0015", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool EndPreProcess2(IAsyncResult ar)
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess2()", "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                if (iEDKEIExists)
                {
                    bReturn = base.EndPreProcess2(ar);
                    return bReturn;
                }
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_graphqlstudio");
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : EndPreProcess2()", "ILBO0016", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool PreProcess3()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess3()", "de_graphqlstudio");
                bReturn = this.ExecuteService("achgqlstdsrfet");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess3();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : PreProcess3()", "ILBO0017", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess3(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess3()", "de_graphqlstudio");
                reqState.ServiceName = "achgqlstdsrfet";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : BeginPreProcess3()", "ILBO0018", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool EndPreProcess3(IAsyncResult ar)
        {
            bool bReturn = false;
            object[] upeControlDetails;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess3()", "de_graphqlstudio");
                bReturn = this.EndExecuteService(ar);
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : EndPreProcess3()", "ILBO0019", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetContextValue(sContextName = \"{0}\")", sContextName), "de_graphqlstudio");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    if (htContextItems.ContainsKey(sContextName))
                    {
                        return htContextItems[sContextName];
                    }
                    else
                    {
                        return null;
                    }
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    return m_conrvwrt_cctxt_component.GetControlValue("rvwrt_cctxt_component");
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    return m_conrvwrt_cctxt_ou.GetControlValue("rvwrt_cctxt_ou");
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    return m_conrvwrt_lctxt_ou.GetControlValue("rvwrt_lctxt_ou");
                }
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetContextValue(sContextName = \"{0}\")", sContextName), "ILBO0020", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Adds/Sets the Context Value to the collection based on the contextname
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Adds/Sets the Context Value to the collection based on the contextname
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "de_graphqlstudio");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    htContextItems[sContextName] = sContextValue;
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    m_conrvwrt_cctxt_component.SetControlValue("rvwrt_cctxt_component", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    m_conrvwrt_cctxt_ou.SetControlValue("rvwrt_cctxt_ou", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", (string)sContextValue);
                    return;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "ILBO0021", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        public override void GetTaskData(string sTabName, string sTaskName, System.Xml.XmlNode nodeScreenInfo)
        {
            string sOutMTD = string.Empty;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_graphqlstudio");
                if ((string.CompareOrdinal(GetContextValue("ICT_INLINE_TAB") as String, "1") == 0))
                {
                    ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                    IContext ISMContext = ISManager.GetContextObject();
                    IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                    System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                    System.Xml.XmlElement eltContextName;
                    System.Xml.XmlElement eltIlboInfo = null;
                    System.Xml.XmlElement eltDTabs = null;
                    System.Xml.XmlElement eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    System.Xml.XmlElement eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                    if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                    {
                        eltIlboInfo = xmlDom.CreateElement("ii");
                        nodeScreenInfo.AppendChild(eltIlboInfo);
                    }
                    else
                    {
                        eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    }
                    switch (sTaskName.ToLower())
                    {
                    }
                    base.GetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
                else
                {
                    this.ObsoleteGetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0022", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Add DirtyTab
        // </summary>
        // **************************************************************************
        // Function Name		:	AddDirtyTab
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Add DirtyTab
        // ***************************************************************************
        private void AddDirtyTab(XmlDocument xmlDom, XmlElement eltDTabs, string sTabName)
        {
            Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("AddDirtyTab(sTabName = \"{0}\")", sTabName), "de_graphqlstudio");
            System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
            eltDTabs = xmlDom.SelectSingleNode("//dtabs") as XmlElement;
            if ((eltDTabs == null))
            {
                eltDTabs = xmlDom.CreateElement("dtabs");
                eltIlboInfo.AppendChild(eltDTabs);
            }
            System.Xml.XmlElement eltDTab = xmlDom.SelectSingleNode("//dtabs/t[@n='" + sTabName + "']") as XmlElement;
            if ((eltDTab == null))
            {
                eltDTab = xmlDom.CreateElement("t");
                eltDTab.SetAttribute("n", sTabName);
                eltDTabs.AppendChild(eltDTab);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	ObsoleteGetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        private void ObsoleteGetTaskData(string sTabName, string sTaskName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_graphqlstudio");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0024", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the display URL based on the tab name
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDisplayURL
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the display URL based on the tab name
        // ***************************************************************************
        public override string GetDisplayURL(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDisplayURL(sTabName = \"{0}\")", sTabName), "de_graphqlstudio");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            return "mnggqloperation_de_graphqlstudio.htm";
                        }
                        else
                        {
                            if (iEDKEIExists)
                            {
                                return base.GetDisplayURL(sTabName);
                            }
                            else
                            {
                                throw new Exception("Invalid TabName");
                            }
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetDisplayURL(sTabName = \"{0}\")", sTabName), "ILBO0025", e.Message);
                throw new Exception(e.Message, e);
            }
            return "";
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	ExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool ExecuteService(string sServiceName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ExecuteService(sServiceName = \"{0}\")", sServiceName), "de_graphqlstudio");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (sServiceName.ToLower())
                {
                    case "achgqlstdsrfet":
                        sTaskName = "achmainsrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlstdsrfet", "mnggqloperation", "de_graphqlstudio");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtactivityname_hdr", "txtactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentname", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcomponentname", "txtcomponentname", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcustomername_hdr", "txtcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcustominput", "txtcustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtdocno_hdr", "txtdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("hdncustomer", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnhdncustomer", "hdnhdncustomer", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnproject", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnhdnproject", "hdnhdnproject", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesec_txt", FlowAttribute.flowInOut, "de_graphqlstudio", "hdniframesec_txt", "hdniframesec_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtprocessname_hdr", "txtprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtprojectname_hdr", "txtprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname", FlowAttribute.flowInOut, "de_graphqlstudio", "txtuiname", "txtuiname", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                }
                if (iEDKEIExists)
                {
                    return base.ExecuteService(null, sServiceName);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : ExecuteService(sServiceName = \"{0}\")", sServiceName), "ILBO0026", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override IAsyncResult BeginExecuteService(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_graphqlstudio");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                bExecFlag = base.PreServiceProcess(reqState.ServiceName, reqState.ServiceName);
                switch (reqState.ServiceName.ToLower())
                {
                    case "achgqlstdsrfet":
                        sTaskName = "achmainsrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlstdsrfet", "mnggqloperation", "de_graphqlstudio");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtactivityname_hdr", "txtactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentname", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcomponentname", "txtcomponentname", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcustomername_hdr", "txtcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_graphqlstudio", "txtcustominput", "txtcustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtdocno_hdr", "txtdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("hdncustomer", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnhdncustomer", "hdnhdncustomer", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnproject", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnhdnproject", "hdnhdnproject", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesec_txt", FlowAttribute.flowInOut, "de_graphqlstudio", "hdniframesec_txt", "hdniframesec_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "de_graphqlstudio", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtprocessname_hdr", "txtprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_graphqlstudio", "txtprojectname_hdr", "txtprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname", FlowAttribute.flowInOut, "de_graphqlstudio", "txtuiname", "txtuiname", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                }
                if (iEDKEIExists)
                {
                    return base.BeginExecuteService(cb, reqState, null);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : BeginExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0027", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool EndExecuteService(IAsyncResult ar)
        {
            bool bExecFlag = true;
            VWRequestState reqState = ar.AsyncState as VWRequestState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (reqState.ServiceName.ToLower())
                {
                    case "achgqlstdsrfet":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndExecuteService(ar);
                        }
                        break;
                }
                if (bExecFlag)
                {
                    bExecFlag = base.PostServiceProcess(reqState.TaskName, reqState.ServiceName);
                }
                return bExecFlag;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : EndExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0028", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes tab control
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes tab control
        // ***************************************************************************
        private new void InitializeTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeTabControls()", "de_graphqlstudio");
                _mainpage.SetIdentity("mainpage");
                base.AddTabControl(_mainpage);
                if (iEDKEIExists)
                {
                    base.InitializeTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : InitializeTabControls()", "ILBO0029", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes Layout Controls
        // ***************************************************************************
        private new void InitializeLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeLayoutControls()", "de_graphqlstudio");
                _btnsave.SetIdentity("btnsave");
                _mainpage.AddLayoutControl("btnsave");
                _iframesec.SetIdentity("iframesec");
                _mainpage.AddLayoutControl("iframesec");
                _prjhdnsection.SetIdentity("prjhdnsection");
                _mainpage.AddLayoutControl("prjhdnsection");
                _sechdn_save_sec.SetIdentity("sechdn_save_sec");
                _mainpage.AddLayoutControl("sechdn_save_sec");
                _sechiddensec.SetIdentity("sechiddensec");
                _mainpage.AddLayoutControl("sechiddensec");
                if (iEDKEIExists)
                {
                    base.InitializeLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : InitializeLayoutControls()", "ILBO0030", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Tab Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Tab Controls
        // ***************************************************************************
        public override void ResetTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetTabControls()", "de_graphqlstudio");
                _mainpage.Clear();
                if (iEDKEIExists)
                {
                    base.ResetTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : ResetTabControls()", "ILBO0031", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Layout Controls
        // ***************************************************************************
        public override void ResetLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetLayoutControls()", "de_graphqlstudio");
                _btnsave.Clear();
                _iframesec.Clear();
                _prjhdnsection.Clear();
                _sechdn_save_sec.Clear();
                _sechiddensec.Clear();
                if (iEDKEIExists)
                {
                    base.ResetLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_graphqlstudio : ResetLayoutControls()", "ILBO0032", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method 
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTabControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	
        // ***************************************************************************
        public override ITabControl GetTabControl(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTabControl(sTabName = \"{0}\")", sTabName), "de_graphqlstudio");
                switch (sTabName.ToLower())
                {
                    case "mainpage":
                    case "":
                        return this._mainpage;
                    default:
                        return base.GetTabControl(sTabName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetTabControl(sTabName= \"{0}\")", sTabName), "ILBO0033", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Get Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	GetLayoutControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Get Layout Controls
        // ***************************************************************************
        public override ILayoutControl GetLayoutControl(string sLayoutControlName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetLayoutControl(sLayoutControlName = \"{0}\")", sLayoutControlName), "de_graphqlstudio");
                switch (sLayoutControlName)
                {
                    case "btnsave":
                        return this._btnsave;
                    case "iframesec":
                        return this._iframesec;
                    case "prjhdnsection":
                        return this._prjhdnsection;
                    case "sechdn_save_sec":
                        return this._sechdn_save_sec;
                    case "sechiddensec":
                        return this._sechiddensec;
                    default:
                        return base.GetLayoutControl(sLayoutControlName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetLayoutControl(sLayoutControlName= \"{0}\")", sLayoutControlName), "ILBO0034", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Updates the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	UpdateScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Updates the screen data
        // ***************************************************************************
        public override void UpdateScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_graphqlstudio");
                base.UpdateScreenData(sTabName, nodeScreenInfo);
                return;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0035", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the screen data
        // ***************************************************************************
        public override void GetScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                IAuthorizedActivitiesAndOULists IAuthorizedInfo = ISManager.GetAuthorizedInfoObject();
                XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                System.Xml.XmlElement eltTask;
                System.Xml.XmlElement eltControlInfo;
                System.Xml.XmlElement eltLayoutControlInfo;
                System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                if ((eltIlboInfo == null))
                {
                    eltIlboInfo = xmlDom.CreateElement("ii");
                    nodeScreenInfo.AppendChild(eltIlboInfo);
                    eltIlboInfo.SetAttribute("dst", "1");
                    ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "0");
                    if ((sTabName == String.Empty))
                    {
                        eltIlboInfo.SetAttribute("at", (String)GetContextValue("ICT_ACTIVE_TAB"));
                        if ((((String)ISMContext.GetContextValue("SCT_LASTTASK_TYPE") == "HELP")
                                    && (GetContextValue("ICT_PARENTILBO") != null)))
                        {
                            if ((ISMContext.GetContextValue("ICT_HELPTASK_TYPE") == null))
                            {
                                this.SetContextValue("ICT_HELPTASK_TYPE", ISMContext.GetContextValue("SCT_LASTTASK_TYPE"));
                            }
                        }
                        if (((String)GetContextValue("ICT_HELPTASK_TYPE") == "HELP"))
                        {
                            eltIlboInfo.SetAttribute("ttype", "HELP");
                            ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "");
                        }
                        else
                        {
                            this.SetContextValue("ICT_HELPTASK_TYPE", "NOTHELP");
                            eltIlboInfo.SetAttribute("ttype", "NOTHELP");
                        }
                    }
                    System.Xml.XmlElement eltDsTaskInfo = nodeScreenInfo.OwnerDocument.CreateElement("dti");
                    nodeScreenInfo.AppendChild(eltDsTaskInfo);
                    eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                }
                else
                {
                    eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                }
                base.GetScreenData(sTabName, nodeScreenInfo);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_graphqlstudio : GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0036", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("de_graphqlstudio : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage), "de_graphqlstudio");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, e.Message, String.Format("de_graphqlstudio : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage));
            }
        }
    }
}

