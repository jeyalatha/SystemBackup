/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   de_schemavisualizer.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace mnggqloperation
{
    using System;
    using System.Web;
    using System.Xml;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;
    using Ramco.VW.RT.Web.Controls;
    using Ramco.VW.RT.Web.Core.Controls.LayoutControls;
    using Ramco.VW.RT.AsyncResult;
    using Ramco.VW.RT.State;
    using Plf.Ui.Ramco.Utility;
    using System.Reflection;

    // <summary>
    // This class defines all the methods of de_schemavisualizer class
    // </summary>
    [Serializable()]
    internal sealed class de_schemavisualizer : CILBO
    {
        private Dictionary<String, Object> htContextItems = new Dictionary<String, Object>();
        private Combo m_concmbactivityname_hdr = new Combo();
        private Combo m_concmbtaskname_hdr = new Combo();
        private Combo m_concmbuiname_hdr = new Combo();
        private Edit m_condspcomponentnamehdr = new Edit();
        private Edit m_condspcustomername_hdr = new Edit();
        private Edit m_condspdocno_hdr = new Edit();
        private Edit m_condspprocessname_hdr = new Edit();
        private Edit m_condspprojectname_hdr = new Edit();
        private Edit m_conhdncustominput = new Edit();
        private Edit m_conhdnhdncustomer = new Edit();
        private Edit m_conhdnhdnproject = new Edit();
        private Edit m_conhdniframesection_txt = new Edit();
        private Edit m_conhdnprj_hdn_ctrl = new Edit();
        private Edit m_contxtcustominput1 = new Edit();
        private Edit m_contxtcustominput2 = new Edit();
        private Edit m_contxtcustominput3 = new Edit();
        private Edit m_contxtcustomoutput1 = new Edit();
        private Edit m_contxtcustomoutput2 = new Edit();
        private Edit m_contxtcustomoutput3 = new Edit();
        private Edit m_contxtintrospection_mappedjson = new Edit();
        private Edit m_contxtintrospectionjson = new Edit();
        private ListEdit m_contxtschema = new ListEdit();
        private Edit m_contxtsdlschema = new Edit();
        private Edit m_contxtsdltext = new Edit();
        private Button _btnsave = new Button();
        private Section _headersection = new Section();
        private Section _hiddensection = new Section();
        private Section _iframesection = new Section();
        private Section _prjhdnsection = new Section();
        private Tab _mainpage = new Tab();
        private Edit m_conrvwrt_cctxt_component = new Edit();
        private Edit m_conrvwrt_cctxt_ou = new Edit();
        private Edit m_conrvwrt_lctxt_ou = new Edit();
        // <summary>
        // This method Calls the AddViewInfo and InitializeControls
        // </summary>
        // **************************************************************************
        // Function Name		:	de_schemavisualizer
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Calls the AddViewInfo and InitializeControls
        // ***************************************************************************
        public de_schemavisualizer()
        {
            IsPreProcess1 = true;
            IsPreProcess2 = true;
            IsPreProcess3 = true;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "de_schemavisualizer()", "de_schemavisualizer");
                this.SetContextValue("ICT_COMPONENTNAME", "apiconsumerhub");
                this.SetContextValue("ICT_COMPONENTDESCRIPTION", "API Consumer HUB");
                this.SetContextValue("ICT_ACTIVITYNAME", "mnggqloperation");
                this.SetContextValue("ICT_ACTIVITYDESCRIPTION", "Manage GQL Operations");
                this.SetContextValue("ICT_ILBOCODE", "de_schemavisualizer");
                this.SetContextValue("ICT_ILBODESCRIPTION", "Schema Visualizer");
                base.LoadILBODefinition("apiconsumerhub", "mnggqloperation", "de_schemavisualizer");
                this.InitializeTabControls();
                this.InitializeLayoutControls();
                this.AddViewInfo();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "de_schemavisualizer()", "de_schemavisualizer");
                throw new System.Exception(e.Message, e);
            }
        }
        public void Clear()
        {
        }
        // <summary>
        // This method Initializes the controls of Enumerated datatype.
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes the controls of Enumerated datatype.
        // ***************************************************************************
        private new void InitializeControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeControls()", "de_schemavisualizer");
                m_concmbactivityname_hdr.SetIdentity("cmbactivityname_hdr", ControlType.RSCombo);
                _mainpage.AddControl("cmbactivityname_hdr");
                m_concmbtaskname_hdr.SetIdentity("cmbtaskname_hdr", ControlType.RSCombo);
                _mainpage.AddControl("cmbtaskname_hdr");
                m_concmbuiname_hdr.SetIdentity("cmbuiname_hdr", ControlType.RSCombo);
                _mainpage.AddControl("cmbuiname_hdr");
                m_condspcomponentnamehdr.SetIdentity("dspcomponentnamehdr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspcomponentnamehdr");
                m_condspcustomername_hdr.SetIdentity("dspcustomername_hdr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspcustomername_hdr");
                m_condspdocno_hdr.SetIdentity("dspdocno_hdr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspdocno_hdr");
                m_condspprocessname_hdr.SetIdentity("dspprocessname_hdr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspprocessname_hdr");
                m_condspprojectname_hdr.SetIdentity("dspprojectname_hdr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspprojectname_hdr");
                m_conhdncustominput.SetIdentity("hdncustominput", ControlType.RSEdit);
                _mainpage.AddControl("hdncustominput");
                m_conhdnhdncustomer.SetIdentity("hdnhdncustomer", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdncustomer");
                m_conhdnhdnproject.SetIdentity("hdnhdnproject", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdnproject");
                m_conhdniframesection_txt.SetIdentity("hdniframesection_txt", ControlType.RSTextArea);
                _mainpage.AddControl("hdniframesection_txt");
                m_conhdnprj_hdn_ctrl.SetIdentity("hdnprj_hdn_ctrl", ControlType.RSEdit);
                _mainpage.AddControl("hdnprj_hdn_ctrl");
                m_contxtcustominput1.SetIdentity("txtcustominput1", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustominput1");
                m_contxtcustominput2.SetIdentity("txtcustominput2", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustominput2");
                m_contxtcustominput3.SetIdentity("txtcustominput3", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustominput3");
                m_contxtcustomoutput1.SetIdentity("txtcustomoutput1", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustomoutput1");
                m_contxtcustomoutput2.SetIdentity("txtcustomoutput2", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustomoutput2");
                m_contxtcustomoutput3.SetIdentity("txtcustomoutput3", ControlType.RSTextArea);
                _mainpage.AddControl("txtcustomoutput3");
                m_contxtintrospection_mappedjson.SetIdentity("txtintrospection_mappedjson", ControlType.RSTextArea);
                _mainpage.AddControl("txtintrospection_mappedjson");
                m_contxtintrospectionjson.SetIdentity("txtintrospectionjson", ControlType.RSTextArea);
                _mainpage.AddControl("txtintrospectionjson");
                m_contxtschema.SetIdentity("txtschema", ControlType.RSEdit);
                _mainpage.AddControl("txtschema");
                m_contxtsdlschema.SetIdentity("txtsdlschema", ControlType.RSTextArea);
                _mainpage.AddControl("txtsdlschema");
                m_contxtsdltext.SetIdentity("txtsdltext", ControlType.RSTextArea);
                _mainpage.AddControl("txtsdltext");
                if (iEDKEIExists)
                {
                    base.InitializeControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : InitializeControls()", "ILBO0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets all the controls of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets all the controls of the ILBO
        // ***************************************************************************
        public override void ResetControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetControls()", "de_schemavisualizer");
                m_concmbactivityname_hdr.ClearAll();
                m_concmbtaskname_hdr.ClearAll();
                m_concmbuiname_hdr.ClearAll();
                m_condspcomponentnamehdr.ClearAll();
                m_condspcustomername_hdr.ClearAll();
                m_condspdocno_hdr.ClearAll();
                m_condspprocessname_hdr.ClearAll();
                m_condspprojectname_hdr.ClearAll();
                m_conhdncustominput.ClearAll();
                m_conhdnhdncustomer.ClearAll();
                m_conhdnhdnproject.ClearAll();
                m_conhdniframesection_txt.ClearAll();
                m_conhdnprj_hdn_ctrl.ClearAll();
                m_contxtcustominput1.ClearAll();
                m_contxtcustominput2.ClearAll();
                m_contxtcustominput3.ClearAll();
                m_contxtcustomoutput1.ClearAll();
                m_contxtcustomoutput2.ClearAll();
                m_contxtcustomoutput3.ClearAll();
                m_contxtintrospection_mappedjson.ClearAll();
                m_contxtintrospectionjson.ClearAll();
                m_contxtschema.ClearAll();
                m_contxtsdlschema.ClearAll();
                m_contxtsdltext.ClearAll();
                this.ResetLayoutControls();
                this.ResetTabControls();
                if (iEDKEIExists)
                {
                    base.ResetControls();
                }
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : ResetControls()", "ILBO0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method adds view information to the controls.
        // </summary>
        // **************************************************************************
        // Function Name		:	AddViewInfo
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	adds view information to the controls.
        // ***************************************************************************
        private new void AddViewInfo()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "AddViewInfo()", "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                m_concmbactivityname_hdr.AddView("cmbactivityname_hdr", true, "char", String.Empty, String.Empty);
                m_concmbtaskname_hdr.AddView("cmbtaskname_hdr", true, "char", String.Empty, String.Empty);
                m_concmbuiname_hdr.AddView("cmbuiname_hdr", true, "char", String.Empty, String.Empty);
                m_condspcomponentnamehdr.AddView("dspcomponentnamehdr", true, "char", String.Empty, String.Empty);
                m_condspcustomername_hdr.AddView("dspcustomername_hdr", true, "char", String.Empty, String.Empty);
                m_condspdocno_hdr.AddView("dspdocno_hdr", true, "char", String.Empty, String.Empty);
                m_condspprocessname_hdr.AddView("dspprocessname_hdr", true, "char", String.Empty, String.Empty);
                m_condspprojectname_hdr.AddView("dspprojectname_hdr", true, "char", String.Empty, String.Empty);
                m_conhdncustominput.AddView("hdncustominput", true, "char", String.Empty, String.Empty);
                m_conhdnhdncustomer.AddView("hdnhdncustomer", true, "char", String.Empty, String.Empty);
                m_conhdnhdnproject.AddView("hdnhdnproject", true, "char", String.Empty, String.Empty);
                m_conhdniframesection_txt.AddView("hdniframesection_txt", true, "char", String.Empty, String.Empty);
                m_conhdnprj_hdn_ctrl.AddView("hdnprj_hdn_ctrl", true, "char", String.Empty, String.Empty);
                m_contxtcustominput1.AddView("txtcustominput1", true, "char", String.Empty, String.Empty);
                m_contxtcustominput2.AddView("txtcustominput2", true, "char", String.Empty, String.Empty);
                m_contxtcustominput3.AddView("txtcustominput3", true, "char", String.Empty, String.Empty);
                m_contxtcustomoutput1.AddView("txtcustomoutput1", true, "char", String.Empty, String.Empty);
                m_contxtcustomoutput2.AddView("txtcustomoutput2", true, "char", String.Empty, String.Empty);
                m_contxtcustomoutput3.AddView("txtcustomoutput3", true, "char", String.Empty, String.Empty);
                m_contxtintrospection_mappedjson.AddView("txtintrospection_mappedjson", true, "char", String.Empty, String.Empty);
                m_contxtintrospectionjson.AddView("txtintrospectionjson", true, "char", String.Empty, String.Empty);
                m_contxtschema.AddView("txtschema", true, "char", String.Empty, String.Empty);
                m_contxtsdlschema.AddView("txtsdlschema", true, "char", String.Empty, String.Empty);
                m_contxtsdltext.AddView("txtsdltext", true, "char", String.Empty, String.Empty);
                m_contxtschema.AddView("lstschemainfo1", false, "char", String.Empty, String.Empty);
                m_contxtschema.AddView("lstschemainfo2", false, "char", String.Empty, String.Empty);
                m_contxtschema.AddView("lstschemainfo3", false, "char", String.Empty, String.Empty);
                m_conrvwrt_lctxt_ou.AddView("rvwrt_lctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_ou.AddView("rvwrt_cctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_component.AddView("rvwrt_cctxt_component", false, "char", String.Empty, String.Empty);
                if (iEDKEIExists)
                {
                    base.AddViewInfo();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : AddViewInfo()", "ILBO0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method creates/gets the Object Handle of the Control
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControlX
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	creates/gets the Object Handle of the Control
        // ***************************************************************************
        public override IControl GetControlX(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControlX(sControlID = \"{0}\")", sControlID), "de_schemavisualizer");
                switch (sControlID.ToLower())
                {
                    case "cmbactivityname_hdr":
                        return this.m_concmbactivityname_hdr;
                    case "cmbtaskname_hdr":
                        return this.m_concmbtaskname_hdr;
                    case "cmbuiname_hdr":
                        return this.m_concmbuiname_hdr;
                    case "dspcomponentnamehdr":
                        return this.m_condspcomponentnamehdr;
                    case "dspcustomername_hdr":
                        return this.m_condspcustomername_hdr;
                    case "dspdocno_hdr":
                        return this.m_condspdocno_hdr;
                    case "dspprocessname_hdr":
                        return this.m_condspprocessname_hdr;
                    case "dspprojectname_hdr":
                        return this.m_condspprojectname_hdr;
                    case "hdncustominput":
                        return this.m_conhdncustominput;
                    case "hdnhdncustomer":
                        return this.m_conhdnhdncustomer;
                    case "hdnhdnproject":
                        return this.m_conhdnhdnproject;
                    case "hdniframesection_txt":
                        return this.m_conhdniframesection_txt;
                    case "hdnprj_hdn_ctrl":
                        return this.m_conhdnprj_hdn_ctrl;
                    case "txtcustominput1":
                        return this.m_contxtcustominput1;
                    case "txtcustominput2":
                        return this.m_contxtcustominput2;
                    case "txtcustominput3":
                        return this.m_contxtcustominput3;
                    case "txtcustomoutput1":
                        return this.m_contxtcustomoutput1;
                    case "txtcustomoutput2":
                        return this.m_contxtcustomoutput2;
                    case "txtcustomoutput3":
                        return this.m_contxtcustomoutput3;
                    case "txtintrospection_mappedjson":
                        return this.m_contxtintrospection_mappedjson;
                    case "txtintrospectionjson":
                        return this.m_contxtintrospectionjson;
                    case "txtschema":
                        return this.m_contxtschema;
                    case "txtsdlschema":
                        return this.m_contxtsdlschema;
                    case "txtsdltext":
                        return this.m_contxtsdltext;
                    case "rvwrt_cctxt_component":
                        return this.m_conrvwrt_cctxt_component;
                    case "rvwrt_cctxt_ou":
                        return this.m_conrvwrt_cctxt_ou;
                    case "rvwrt_lctxt_ou":
                        return this.m_conrvwrt_lctxt_ou;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.GetControlX(sControlID);
                        }
                        else
                        {
                            return null;
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetControlX(sControlID = \"{0}\")", sControlID), "ILBO0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override IControl GetControl(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControl(sControlID = \"{0}\")", sControlID), "de_schemavisualizer");
                IControl control = this.GetControlX(sControlID);
                if ((control != null))
                {
                    return control;
                }
                else
                {
                    throw new Exception("String.Format(\"Invalid ControlID - {0}\", sControlID)");
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetControl(sControlID = \"{0}\")", sControlID), "ILBO0005", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem
        // ***************************************************************************
        public override string GetDataItem(string sLinkID, string sDataItemName, long nInstance)
        {
            string sRetData = String.Empty;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "de_schemavisualizer");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItem(sLinkID, sDataItemName, nInstance);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\"), nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "ILBO0006", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem Instances.
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItemInstances
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem Instances.
        // ***************************************************************************
        public override long GetDataItemInstances(string sLinkID, string sDataItemName)
        {
            long sRetData = 0;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "de_schemavisualizer");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItemInstances(sLinkID, sDataItemName);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "ILBO0007", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method sets the DataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	SetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	sets the DataItem
        // ***************************************************************************
        public override void SetDataItem(string sLinkID, string sDataItemName, long nInstance, string sValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\",nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance, sValue), "de_schemavisualizer");
                bool bFlag = false;
                switch (sLinkID)
                {
                    case "ezeeview":
                        return;
                    case "12590":
                        if ((sDataItemName == "activityname_hdr"))
                        {
                            m_concmbactivityname_hdr.SetControlValue("cmbactivityname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "componentnamehdr"))
                        {
                            m_condspcomponentnamehdr.SetControlValue("dspcomponentnamehdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "csou"))
                        {
                            m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "customername_hdr"))
                        {
                            m_condspcustomername_hdr.SetControlValue("dspcustomername_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "custominput"))
                        {
                            m_conhdncustominput.SetControlValue("hdncustominput", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "custominput1"))
                        {
                            m_contxtcustominput1.SetControlValue("txtcustominput1", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "custominput2"))
                        {
                            m_contxtcustominput2.SetControlValue("txtcustominput2", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "custominput3"))
                        {
                            m_contxtcustominput3.SetControlValue("txtcustominput3", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "customoutput1"))
                        {
                            m_contxtcustomoutput1.SetControlValue("txtcustomoutput1", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "customoutput2"))
                        {
                            m_contxtcustomoutput2.SetControlValue("txtcustomoutput2", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "customoutput3"))
                        {
                            m_contxtcustomoutput3.SetControlValue("txtcustomoutput3", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "docno_hdr"))
                        {
                            m_condspdocno_hdr.SetControlValue("dspdocno_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdncustomer"))
                        {
                            m_conhdnhdncustomer.SetControlValue("hdnhdncustomer", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdnproject"))
                        {
                            m_conhdnhdnproject.SetControlValue("hdnhdnproject", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "iframesection_txt"))
                        {
                            m_conhdniframesection_txt.SetControlValue("hdniframesection_txt", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "introspection_mappedjson"))
                        {
                            m_contxtintrospection_mappedjson.SetControlValue("txtintrospection_mappedjson", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "introspectionjson"))
                        {
                            m_contxtintrospectionjson.SetControlValue("txtintrospectionjson", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "prj_hdn_ctrl"))
                        {
                            m_conhdnprj_hdn_ctrl.SetControlValue("hdnprj_hdn_ctrl", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "processname_hdr"))
                        {
                            m_condspprocessname_hdr.SetControlValue("dspprocessname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "projectname_hdr"))
                        {
                            m_condspprojectname_hdr.SetControlValue("dspprojectname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "schema"))
                        {
                            m_contxtschema.SetControlValue("txtschema", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "sdlschema"))
                        {
                            m_contxtsdlschema.SetControlValue("txtsdlschema", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "sdltext"))
                        {
                            m_contxtsdltext.SetControlValue("txtsdltext", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "taskname_hdr"))
                        {
                            m_concmbtaskname_hdr.SetControlValue("cmbtaskname_hdr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "uiname_hdr"))
                        {
                            m_concmbuiname_hdr.SetControlValue("cmbuiname_hdr", sValue, 0);
                            return;
                        }
                        break;
                    default:
                        break;
                }
                if ((iEDKEIExists && !bFlag))
                {
                    base.SetDataItem(sLinkID, sDataItemName, nInstance, sValue);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance.ToString(), sValue.ToString()), "ILBO0008", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the GlobalVariable handle
        // </summary>
        // **************************************************************************
        // Function Name		:	GetVariable
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the GlobalVariable handle
        // ***************************************************************************
        public override IGlobalVariable GetVariable(string sVariable)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetVariable(sVariable = \"{0}\")", sVariable), "de_schemavisualizer");
                if (iEDKEIExists)
                {
                    return base.GetVariable(sVariable);
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetVariable(sVariable = \"{0}\")", sVariable), "ILBO0009", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool PerformTask(string sControlID, string sEventName, string sEventDetails, out string sTargetURL)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "de_schemavisualizer");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                sTargetURL = string.Empty;
                switch (sEventName.ToLower())
                {
                    case "achmaincractiviui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achvissractivi");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmaincrsave1tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achvissrsav");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmaincrschem1ui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achvissrschm");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmaincrtasknaui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achvissrtaskna");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmaincruinameui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achvissruiname");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    default:
                        if (iEDKEIExists)
                        {
                            return base.PerformTask(sControlID, sEventName, sEventDetails, out sTargetURL);
                        }
                        break;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "ILBO0010", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override IAsyncResult BeginPerformTask(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_schemavisualizer");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                bool bExecFlag = base.PreTaskExecution(reqState);
                if ((bExecFlag == false))
                {
                    return ISManager.SetAsyncException(null);
                }
                switch (reqState.TaskName.ToLower())
                {
                    case "achmaincractiviui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achvissractivi";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmaincrsave1tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achvissrsav";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmaincrschem1ui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achvissrschm";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmaincrtasknaui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achvissrtaskna";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmaincruinameui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achvissruiname";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    default:
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        break;
                }
                return ISManager.SetAsyncCompleted(new VWResponseState());
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0011", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool EndPerformTask(IAsyncResult ar)
        {
            VWAsyncResult result = ar as VWAsyncResult;
            VWRequestState reqState = result.AsyncState as VWRequestState;
            VWResponseState resState = result.ResponseState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                long lSubscriptionID = 0;
                bool bServiceResult = true;
                string sTargetURL = string.Empty;
                switch (reqState.TaskName.ToLower())
                {
                    case "achmaincractiviui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmaincrsave1tr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmaincrschem1ui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmaincrtasknaui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmaincruinameui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndPerformTask(ar);
                        }
                        break;
                }
                if (bServiceResult)
                {
                    bServiceResult = base.PostTaskExecution(reqState.TaskName);
                }
                return bServiceResult;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0012", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method initializes Scripts for Data Transfer
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess1
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	initializes Scripts for Data Transfer
        // ***************************************************************************
        public override bool PreProcess1()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess1", "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IObjectBroker IobjBroker = ISManager.GetObjectBroker();
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_schemavisualizer");
                if (iEDKEIExists)
                {
                    return base.PreProcess1();
                }
                else
                {
                    return true;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : PreProcess1()", "ILBO0013", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool PreProcess2()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess2", "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                bReturn = this.ExecuteService("achvissrinit");
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_schemavisualizer");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess2();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : PreProcess2()", "ILBO0014 ", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess2(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess2()", "de_schemavisualizer");
                reqState.ServiceName = "achvissrinit";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : BeginPreProcess2()", "ILBO0015", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool EndPreProcess2(IAsyncResult ar)
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess2()", "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                bReturn = this.EndExecuteService(ar);
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.EndPreProcess2(ar);
                }
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_schemavisualizer");
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : EndPreProcess2()", "ILBO0016", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool PreProcess3()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess3()", "de_schemavisualizer");
                bReturn = this.ExecuteService("achvissrfet");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess3();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : PreProcess3()", "ILBO0017", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess3(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess3()", "de_schemavisualizer");
                reqState.ServiceName = "achvissrfet";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : BeginPreProcess3()", "ILBO0018", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool EndPreProcess3(IAsyncResult ar)
        {
            bool bReturn = false;
            object[] upeControlDetails;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess3()", "de_schemavisualizer");
                bReturn = this.EndExecuteService(ar);
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : EndPreProcess3()", "ILBO0019", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetContextValue(sContextName = \"{0}\")", sContextName), "de_schemavisualizer");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    if (htContextItems.ContainsKey(sContextName))
                    {
                        return htContextItems[sContextName];
                    }
                    else
                    {
                        return null;
                    }
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    return m_conrvwrt_cctxt_component.GetControlValue("rvwrt_cctxt_component");
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    return m_conrvwrt_cctxt_ou.GetControlValue("rvwrt_cctxt_ou");
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    return m_conrvwrt_lctxt_ou.GetControlValue("rvwrt_lctxt_ou");
                }
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetContextValue(sContextName = \"{0}\")", sContextName), "ILBO0020", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Adds/Sets the Context Value to the collection based on the contextname
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Adds/Sets the Context Value to the collection based on the contextname
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "de_schemavisualizer");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    htContextItems[sContextName] = sContextValue;
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    m_conrvwrt_cctxt_component.SetControlValue("rvwrt_cctxt_component", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    m_conrvwrt_cctxt_ou.SetControlValue("rvwrt_cctxt_ou", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", (string)sContextValue);
                    return;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "ILBO0021", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        public override void GetTaskData(string sTabName, string sTaskName, System.Xml.XmlNode nodeScreenInfo)
        {
            string sOutMTD = string.Empty;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_schemavisualizer");
                if ((string.CompareOrdinal(GetContextValue("ICT_INLINE_TAB") as String, "1") == 0))
                {
                    ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                    IContext ISMContext = ISManager.GetContextObject();
                    IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                    System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                    System.Xml.XmlElement eltContextName;
                    System.Xml.XmlElement eltIlboInfo = null;
                    System.Xml.XmlElement eltDTabs = null;
                    System.Xml.XmlElement eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    System.Xml.XmlElement eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                    if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                    {
                        eltIlboInfo = xmlDom.CreateElement("ii");
                        nodeScreenInfo.AppendChild(eltIlboInfo);
                    }
                    else
                    {
                        eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    }
                    switch (sTaskName.ToLower())
                    {
                        case "achmaincractiviui":
                            m_concmbactivityname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcomponentnamehdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcustomername_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspdocno_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprocessname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprojectname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdncustominput.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdniframesection_txt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospection_mappedjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospectionjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdlschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdltext.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbtaskname_hdr.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_concmbuiname_hdr.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            break;
                        case "achmaincrsave1tr":
                            m_concmbactivityname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbtaskname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbuiname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcomponentnamehdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcustomername_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspdocno_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprocessname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprojectname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdncustominput.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdniframesection_txt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospection_mappedjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospectionjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdlschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdltext.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            break;
                        case "achmaincrschem1ui":
                            m_concmbactivityname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbtaskname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbuiname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcomponentnamehdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcustomername_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspdocno_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprocessname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprojectname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdncustominput.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdniframesection_txt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospection_mappedjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospectionjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdlschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdltext.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            break;
                        case "achmaincrtasknaui":
                            m_concmbactivityname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbtaskname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbuiname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcomponentnamehdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcustomername_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspdocno_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprocessname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprojectname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdncustominput.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdniframesection_txt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospection_mappedjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospectionjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdlschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdltext.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            break;
                        case "achmaincruinameui":
                            m_concmbactivityname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbuiname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcomponentnamehdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspcustomername_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspdocno_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprocessname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspprojectname_hdr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdncustominput.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdniframesection_txt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustominput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput1.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput2.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtcustomoutput3.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospection_mappedjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtintrospectionjson.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdlschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtsdltext.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbtaskname_hdr.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            break;
                    }
                    base.GetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
                else
                {
                    this.ObsoleteGetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0022", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Add DirtyTab
        // </summary>
        // **************************************************************************
        // Function Name		:	AddDirtyTab
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Add DirtyTab
        // ***************************************************************************
        private void AddDirtyTab(XmlDocument xmlDom, XmlElement eltDTabs, string sTabName)
        {
            Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("AddDirtyTab(sTabName = \"{0}\")", sTabName), "de_schemavisualizer");
            System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
            eltDTabs = xmlDom.SelectSingleNode("//dtabs") as XmlElement;
            if ((eltDTabs == null))
            {
                eltDTabs = xmlDom.CreateElement("dtabs");
                eltIlboInfo.AppendChild(eltDTabs);
            }
            System.Xml.XmlElement eltDTab = xmlDom.SelectSingleNode("//dtabs/t[@n='" + sTabName + "']") as XmlElement;
            if ((eltDTab == null))
            {
                eltDTab = xmlDom.CreateElement("t");
                eltDTab.SetAttribute("n", sTabName);
                eltDTabs.AppendChild(eltDTab);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	ObsoleteGetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        private void ObsoleteGetTaskData(string sTabName, string sTaskName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_schemavisualizer");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0024", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the display URL based on the tab name
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDisplayURL
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the display URL based on the tab name
        // ***************************************************************************
        public override string GetDisplayURL(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDisplayURL(sTabName = \"{0}\")", sTabName), "de_schemavisualizer");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            return "mnggqloperation_de_schemavisualizer.htm";
                        }
                        else
                        {
                            if (iEDKEIExists)
                            {
                                return base.GetDisplayURL(sTabName);
                            }
                            else
                            {
                                throw new Exception("Invalid TabName");
                            }
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetDisplayURL(sTabName = \"{0}\")", sTabName), "ILBO0025", e.Message);
                throw new Exception(e.Message, e);
            }
            return "";
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	ExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool ExecuteService(string sServiceName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ExecuteService(sServiceName = \"{0}\")", sServiceName), "de_schemavisualizer");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (sServiceName.ToLower())
                {
                    case "achvissractivi":
                        sTaskName = "achmaincractiviui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissractivi", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("uinamecbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissrfet":
                        sTaskName = "achmaincrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrfet", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_schin", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("componentname", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo1", String.Empty);
                        ISExecutor.SetServiceDataSource("schemaname", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo2", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo3", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissrinit":
                        sTaskName = "achmaincrinit";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrinit", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("activicbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("uinamecbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissrsav":
                        sTaskName = "achmaincrsave1tr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrsav", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissrschm":
                        sTaskName = "achmaincrschem1ui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrschm", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissrtaskna":
                        sTaskName = "achmaincrtasknaui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrtaskna", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achvissruiname":
                        sTaskName = "achmaincruinameui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissruiname", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                }
                if (iEDKEIExists)
                {
                    return base.ExecuteService(null, sServiceName);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : ExecuteService(sServiceName = \"{0}\")", sServiceName), "ILBO0026", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override IAsyncResult BeginExecuteService(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_schemavisualizer");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                bExecFlag = base.PreServiceProcess(reqState.ServiceName, reqState.ServiceName);
                switch (reqState.ServiceName.ToLower())
                {
                    case "achvissractivi":
                        sTaskName = "achmaincractiviui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissractivi", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("uinamecbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissrfet":
                        sTaskName = "achmaincrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrfet", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_schin", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("componentname", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo1", String.Empty);
                        ISExecutor.SetServiceDataSource("schemaname", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo2", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowOut, "de_schemavisualizer", "txtschema", "lstschemainfo3", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissrinit":
                        sTaskName = "achmaincrinit";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrinit", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowIn, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("activicbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("uinamecbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissrsav":
                        sTaskName = "achmaincrsave1tr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrsav", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissrschm":
                        sTaskName = "achmaincrschem1ui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrschm", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissrtaskna":
                        sTaskName = "achmaincrtasknaui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissrtaskna", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achvissruiname":
                        sTaskName = "achmaincruinameui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achvissruiname", "mnggqloperation", "de_schemavisualizer");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("activityname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbactivityname_hdr", "cmbactivityname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("componentnamehdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcomponentnamehdr", "dspcomponentnamehdr", String.Empty);
                        ISExecutor.SetServiceDataSource("customername_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspcustomername_hdr", "dspcustomername_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput", FlowAttribute.flowInOut, "de_schemavisualizer", "hdncustominput", "hdncustominput", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput1", "txtcustominput1", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput2", "txtcustominput2", String.Empty);
                        ISExecutor.SetServiceDataSource("custominput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustominput3", "txtcustominput3", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput1", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput1", "txtcustomoutput1", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput2", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput2", "txtcustomoutput2", String.Empty);
                        ISExecutor.SetServiceDataSource("customoutput3", FlowAttribute.flowInOut, "de_schemavisualizer", "txtcustomoutput3", "txtcustomoutput3", String.Empty);
                        ISExecutor.SetServiceDataSource("docno_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspdocno_hdr", "dspdocno_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("iframesection_txt", FlowAttribute.flowInOut, "de_schemavisualizer", "hdniframesection_txt", "hdniframesection_txt", String.Empty);
                        ISExecutor.SetServiceDataSource("introspection_mappedjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospection_mappedjson", "txtintrospection_mappedjson", String.Empty);
                        ISExecutor.SetServiceDataSource("introspectionjson", FlowAttribute.flowInOut, "de_schemavisualizer", "txtintrospectionjson", "txtintrospectionjson", String.Empty);
                        ISExecutor.SetServiceDataSource("processname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprocessname_hdr", "dspprocessname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("projectname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "dspprojectname_hdr", "dspprojectname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtschema", "txtschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdlschema", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdlschema", "txtsdlschema", String.Empty);
                        ISExecutor.SetServiceDataSource("sdltext", FlowAttribute.flowInOut, "de_schemavisualizer", "txtsdltext", "txtsdltext", String.Empty);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        ISExecutor.SetServiceDataSource("uiname_hdr", FlowAttribute.flowInOut, "de_schemavisualizer", "cmbuiname_hdr", "cmbuiname_hdr", String.Empty);
                        ISExecutor.SetSegmentContext("tasknacbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("taskname_hdr", FlowAttribute.flowOut, "de_schemavisualizer", "cmbtaskname_hdr", "cmbtaskname_hdr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                }
                if (iEDKEIExists)
                {
                    return base.BeginExecuteService(cb, reqState, null);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : BeginExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0027", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool EndExecuteService(IAsyncResult ar)
        {
            bool bExecFlag = true;
            VWRequestState reqState = ar.AsyncState as VWRequestState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (reqState.ServiceName.ToLower())
                {
                    case "achvissractivi":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissrfet":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissrinit":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissrsav":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissrschm":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissrtaskna":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achvissruiname":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndExecuteService(ar);
                        }
                        break;
                }
                if (bExecFlag)
                {
                    bExecFlag = base.PostServiceProcess(reqState.TaskName, reqState.ServiceName);
                }
                return bExecFlag;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : EndExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0028", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes tab control
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes tab control
        // ***************************************************************************
        private new void InitializeTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeTabControls()", "de_schemavisualizer");
                _mainpage.SetIdentity("mainpage");
                base.AddTabControl(_mainpage);
                if (iEDKEIExists)
                {
                    base.InitializeTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : InitializeTabControls()", "ILBO0029", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes Layout Controls
        // ***************************************************************************
        private new void InitializeLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeLayoutControls()", "de_schemavisualizer");
                _btnsave.SetIdentity("btnsave");
                _mainpage.AddLayoutControl("btnsave");
                _headersection.SetIdentity("headersection");
                _mainpage.AddLayoutControl("headersection");
                _hiddensection.SetIdentity("hiddensection");
                _mainpage.AddLayoutControl("hiddensection");
                _iframesection.SetIdentity("iframesection");
                _mainpage.AddLayoutControl("iframesection");
                _prjhdnsection.SetIdentity("prjhdnsection");
                _mainpage.AddLayoutControl("prjhdnsection");
                if (iEDKEIExists)
                {
                    base.InitializeLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : InitializeLayoutControls()", "ILBO0030", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Tab Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Tab Controls
        // ***************************************************************************
        public override void ResetTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetTabControls()", "de_schemavisualizer");
                _mainpage.Clear();
                if (iEDKEIExists)
                {
                    base.ResetTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : ResetTabControls()", "ILBO0031", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Layout Controls
        // ***************************************************************************
        public override void ResetLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetLayoutControls()", "de_schemavisualizer");
                _btnsave.Clear();
                _headersection.Clear();
                _hiddensection.Clear();
                _iframesection.Clear();
                _prjhdnsection.Clear();
                if (iEDKEIExists)
                {
                    base.ResetLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_schemavisualizer : ResetLayoutControls()", "ILBO0032", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method 
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTabControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	
        // ***************************************************************************
        public override ITabControl GetTabControl(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTabControl(sTabName = \"{0}\")", sTabName), "de_schemavisualizer");
                switch (sTabName.ToLower())
                {
                    case "mainpage":
                    case "":
                        return this._mainpage;
                    default:
                        return base.GetTabControl(sTabName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetTabControl(sTabName= \"{0}\")", sTabName), "ILBO0033", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Get Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	GetLayoutControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Get Layout Controls
        // ***************************************************************************
        public override ILayoutControl GetLayoutControl(string sLayoutControlName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetLayoutControl(sLayoutControlName = \"{0}\")", sLayoutControlName), "de_schemavisualizer");
                switch (sLayoutControlName)
                {
                    case "btnsave":
                        return this._btnsave;
                    case "headersection":
                        return this._headersection;
                    case "hiddensection":
                        return this._hiddensection;
                    case "iframesection":
                        return this._iframesection;
                    case "prjhdnsection":
                        return this._prjhdnsection;
                    default:
                        return base.GetLayoutControl(sLayoutControlName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetLayoutControl(sLayoutControlName= \"{0}\")", sLayoutControlName), "ILBO0034", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Updates the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	UpdateScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Updates the screen data
        // ***************************************************************************
        public override void UpdateScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_schemavisualizer");
                base.UpdateScreenData(sTabName, nodeScreenInfo);
                return;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0035", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the screen data
        // ***************************************************************************
        public override void GetScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                IAuthorizedActivitiesAndOULists IAuthorizedInfo = ISManager.GetAuthorizedInfoObject();
                XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                System.Xml.XmlElement eltTask;
                System.Xml.XmlElement eltControlInfo;
                System.Xml.XmlElement eltLayoutControlInfo;
                System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                if ((eltIlboInfo == null))
                {
                    eltIlboInfo = xmlDom.CreateElement("ii");
                    nodeScreenInfo.AppendChild(eltIlboInfo);
                    eltIlboInfo.SetAttribute("dst", "1");
                    ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "0");
                    if ((sTabName == String.Empty))
                    {
                        eltIlboInfo.SetAttribute("at", (String)GetContextValue("ICT_ACTIVE_TAB"));
                        if ((((String)ISMContext.GetContextValue("SCT_LASTTASK_TYPE") == "HELP")
                                    && (GetContextValue("ICT_PARENTILBO") != null)))
                        {
                            if ((ISMContext.GetContextValue("ICT_HELPTASK_TYPE") == null))
                            {
                                this.SetContextValue("ICT_HELPTASK_TYPE", ISMContext.GetContextValue("SCT_LASTTASK_TYPE"));
                            }
                        }
                        if (((String)GetContextValue("ICT_HELPTASK_TYPE") == "HELP"))
                        {
                            eltIlboInfo.SetAttribute("ttype", "HELP");
                            ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "");
                        }
                        else
                        {
                            this.SetContextValue("ICT_HELPTASK_TYPE", "NOTHELP");
                            eltIlboInfo.SetAttribute("ttype", "NOTHELP");
                        }
                    }
                    System.Xml.XmlElement eltDsTaskInfo = nodeScreenInfo.OwnerDocument.CreateElement("dti");
                    nodeScreenInfo.AppendChild(eltDsTaskInfo);
                    eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                }
                else
                {
                    eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                }
                base.GetScreenData(sTabName, nodeScreenInfo);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_schemavisualizer : GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0036", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("de_schemavisualizer : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage), "de_schemavisualizer");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, e.Message, String.Format("de_schemavisualizer : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage));
            }
        }
    }
}

