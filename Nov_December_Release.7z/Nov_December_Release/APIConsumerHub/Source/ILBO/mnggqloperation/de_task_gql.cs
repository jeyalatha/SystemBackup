/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   de_task_gql.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace mnggqloperation
{
    using System;
    using System.Web;
    using System.Xml;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;
    using Ramco.VW.RT.Web.Controls;
    using Ramco.VW.RT.Web.Core.Controls.LayoutControls;
    using Ramco.VW.RT.AsyncResult;
    using Ramco.VW.RT.State;
    using Plf.Ui.Ramco.Utility;
    using System.Reflection;

    // <summary>
    // This class defines all the methods of de_task_gql class
    // </summary>
    [Serializable()]
    internal sealed class de_task_gql : CILBO
    {
        private Dictionary<String, Object> htContextItems = new Dictionary<String, Object>();
        private Check m_conchkengg_gqfld_inclayoutctrls = new Check();
        private Combo m_concmbengg_gq_rep_launchmode = new Combo();
        private Combo m_concmbengg_gq_rep_oufrmt = new Combo();
        private Combo m_concmbengg_gqhdr_actdescr = new Combo();
        private Combo m_concmbengg_gqhdr_uidescr = new Combo();
        private Edit m_condspemgg_arg_qrytype = new Edit();
        private Edit m_condspengg_arg_qryalias = new Edit();
        private Edit m_condspengg_arg_qryhdnkeyfield = new Edit();
        private Edit m_condspengg_arg_qryseq = new Edit();
        private Edit m_condspengg_arg_qryversion = new Edit();
        private Edit m_condspengg_fld_qry_version = new Edit();
        private Edit m_condspengg_fld_qryalias = new Edit();
        private Edit m_condspengg_fld_qryhdnkeyfield = new Edit();
        private Edit m_condspengg_fld_qryseq = new Edit();
        private Edit m_condspengg_fld_qrytype = new Edit();
        private Edit m_condspengg_gqhdr_actname = new Edit();
        private Edit m_condspengg_gqhdr_cmpdescr = new Edit();
        private Edit m_condspengg_gqhdr_cmpname = new Edit();
        private Edit m_condspengg_gqhdr_cust = new Edit();
        private Edit m_condspengg_gqhdr_ecrno = new Edit();
        private Edit m_condspengg_gqhdr_isgql = new Edit();
        private Edit m_condspengg_gqhdr_prcname = new Edit();
        private Edit m_condspengg_gqhdr_prodescr = new Edit();
        private Edit m_condspengg_gqhdr_proj = new Edit();
        private Edit m_condspengg_gqhdr_taskdescr = new Edit();
        private Edit m_condspengg_gqhdr_tasktype = new Edit();
        private Edit m_condspengg_gqhdr_uiname = new Edit();
        private Multiline m_congrdengg_gq_rep_grd = new Multiline();
        private Multiline m_congrdengg_gqfldml_grd = new Multiline();
        private Multiline m_congrdengg_gqqml_grd = new Multiline();
        private Edit m_conhdnhdncustomer = new Edit();
        private Edit m_conhdnhdnproject = new Edit();
        private Edit m_conhdnhdnrt_stcontrol = new Edit();
        private Edit m_conhdnprj_hdn_ctrl = new Edit();
        private Edit m_conimgengg_gqpopup_json = new Edit();
        private Edit m_conimgengg_gqpopup_schema = new Edit();
        private ListEdit m_conlstengg_arg_qry = new ListEdit();
        private ListEdit m_conlstengg_fld_qry = new ListEdit();
        private ListEdit m_conlstengg_gqhdr_tskname = new ListEdit();
        private TreeGrid m_contgdengg_argml_treegrd = new TreeGrid();
        private Edit m_contxaschema = new Edit();
        private Edit m_contxtengg_gq_rep_reportname = new Edit();
        private Edit m_contxtversion = new Edit();
        private Button _btnengg_gqfollowup_import = new Button();
        private Button _btnengg_gqpopup_upload = new Button();
        private Button _btnengg_gqarg_save = new Button();
        private Button _btnengg_fld_save = new Button();
        private Button _btnengg_gqfld_defctrls = new Button();
        private Button _btnengg_gqqry_save = new Button();
        private Button _btneng_gq_rep_save = new Button();
        private Link _lnkengg_gqhdr_upload = new Link();
        private Link _lnkengg_gql_followuptask = new Link();
        private Link _lnkengg_gql_schvisualizer = new Link();
        private Link _lnkengg_gqllaunch_sdl = new Link();
        private Link _lnkengg_gqllaunch_studio = new Link();
        private Section _hdnrt_stsection = new Section();
        private Section _popengg_gql_sdl_popup = new Section();
        private Section _popengg_gqpopup_sec = new Section();
        private Section _prjhdnsection = new Section();
        private Section _secengg_gq_hdrsec = new Section();
        private Section _secengg_gqlink_sec = new Section();
        private Section _secengg_gqtab_sec = new Section();
        private Section _tabcontrol = new Section();
        private Section _secengg_argml_sec = new Section();
        private Section _secengg_gqarg_hdrse = new Section();
        private Section _secengg_gqarg_save_sec = new Section();
        private Section _secengg_gqfld_save_sec = new Section();
        private Section _secengg_gqfldml_hdrsec = new Section();
        private Section _secengg_gqfldml_sec = new Section();
        private Section _secengg_gqqml_sec = new Section();
        private Section _secengg_gqqry_save_sec = new Section();
        private Section _tabitem_1661329961099_fr1c1 = new Section();
        private Section _secengg_gq_rep_ml = new Section();
        private Section _secengg_gq_rep_savesec = new Section();
        private Section _secengg_gq_rephdrsec = new Section();
        private Tab _mainpage = new Tab();
        private Tab _tblengg_gq_arguments = new Tab();
        private Tab _tblengg_gq_fields = new Tab();
        private Tab _tblengg_gq_query = new Tab();
        private Tab _tblengg_gq_reportdef = new Tab();
        private Edit m_conrvwrt_cctxt_component = new Edit();
        private Edit m_conrvwrt_cctxt_ou = new Edit();
        private Edit m_conrvwrt_lctxt_ou = new Edit();
        // <summary>
        // This method Calls the AddViewInfo and InitializeControls
        // </summary>
        // **************************************************************************
        // Function Name		:	de_task_gql
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Calls the AddViewInfo and InitializeControls
        // ***************************************************************************
        public de_task_gql()
        {
            base.AppStateControl = "hdnhdnrt_stcontrol";
            IsPreProcess1 = true;
            IsPreProcess2 = true;
            IsPreProcess3 = true;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "de_task_gql()", "de_task_gql");
                this.SetContextValue("ICT_COMPONENTNAME", "apiconsumerhub");
                this.SetContextValue("ICT_COMPONENTDESCRIPTION", "API Consumer HUB");
                this.SetContextValue("ICT_ACTIVITYNAME", "mnggqloperation");
                this.SetContextValue("ICT_ACTIVITYDESCRIPTION", "Manage GQL Operations");
                this.SetContextValue("ICT_ILBOCODE", "de_task_gql");
                this.SetContextValue("ICT_ILBODESCRIPTION", "Manage GQL Operations");
                this.SetContextValue("ICT_ACTIVE_TAB", "tblengg_gq_query");
                base.LoadILBODefinition("apiconsumerhub", "mnggqloperation", "de_task_gql");
                this.InitializeTabControls();
                this.InitializeLayoutControls();
                this.AddViewInfo();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "de_task_gql()", "de_task_gql");
                throw new System.Exception(e.Message, e);
            }
        }
        public void Clear()
        {
        }
        // <summary>
        // This method Initializes the controls of Enumerated datatype.
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes the controls of Enumerated datatype.
        // ***************************************************************************
        private new void InitializeControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeControls()", "de_task_gql");
                m_conchkengg_gqfld_inclayoutctrls.SetIdentity("chkengg_gqfld_inclayoutctrls", ControlType.RSCheck);
                _tblengg_gq_fields.AddControl("chkengg_gqfld_inclayoutctrls");
                m_conchkengg_gqfld_inclayoutctrls.SetContextValue("CCT_ON_STATE_VALUE", "1");
                m_conchkengg_gqfld_inclayoutctrls.SetContextValue("CCT_OFF_STATE_VALUE", "0");
                m_concmbengg_gq_rep_launchmode.SetIdentity("cmbengg_gq_rep_launchmode", ControlType.RSCombo);
                _tblengg_gq_reportdef.AddControl("cmbengg_gq_rep_launchmode");
                m_concmbengg_gq_rep_oufrmt.SetIdentity("cmbengg_gq_rep_oufrmt", ControlType.RSCombo);
                _tblengg_gq_reportdef.AddControl("cmbengg_gq_rep_oufrmt");
                m_concmbengg_gqhdr_actdescr.SetIdentity("cmbengg_gqhdr_actdescr", ControlType.RSCombo);
                _mainpage.AddControl("cmbengg_gqhdr_actdescr");
                m_concmbengg_gqhdr_uidescr.SetIdentity("cmbengg_gqhdr_uidescr", ControlType.RSCombo);
                _mainpage.AddControl("cmbengg_gqhdr_uidescr");
                m_condspemgg_arg_qrytype.SetIdentity("dspemgg_arg_qrytype", ControlType.RSDisplayOnly);
                _tblengg_gq_arguments.AddControl("dspemgg_arg_qrytype");
                m_condspengg_arg_qryalias.SetIdentity("dspengg_arg_qryalias", ControlType.RSDisplayOnly);
                _tblengg_gq_arguments.AddControl("dspengg_arg_qryalias");
                m_condspengg_arg_qryhdnkeyfield.SetIdentity("dspengg_arg_qryhdnkeyfield", ControlType.RSDisplayOnly);
                _tblengg_gq_arguments.AddControl("dspengg_arg_qryhdnkeyfield");
                m_condspengg_arg_qryseq.SetIdentity("dspengg_arg_qryseq", ControlType.RSDisplayOnly);
                _tblengg_gq_arguments.AddControl("dspengg_arg_qryseq");
                m_condspengg_arg_qryversion.SetIdentity("dspengg_arg_qryversion", ControlType.RSDisplayOnly);
                _tblengg_gq_arguments.AddControl("dspengg_arg_qryversion");
                m_condspengg_fld_qry_version.SetIdentity("dspengg_fld_qry_version", ControlType.RSDisplayOnly);
                _tblengg_gq_fields.AddControl("dspengg_fld_qry_version");
                m_condspengg_fld_qryalias.SetIdentity("dspengg_fld_qryalias", ControlType.RSDisplayOnly);
                _tblengg_gq_fields.AddControl("dspengg_fld_qryalias");
                m_condspengg_fld_qryhdnkeyfield.SetIdentity("dspengg_fld_qryhdnkeyfield", ControlType.RSDisplayOnly);
                _tblengg_gq_fields.AddControl("dspengg_fld_qryhdnkeyfield");
                m_condspengg_fld_qryseq.SetIdentity("dspengg_fld_qryseq", ControlType.RSDisplayOnly);
                _tblengg_gq_fields.AddControl("dspengg_fld_qryseq");
                m_condspengg_fld_qrytype.SetIdentity("dspengg_fld_qrytype", ControlType.RSDisplayOnly);
                _tblengg_gq_fields.AddControl("dspengg_fld_qrytype");
                m_condspengg_gqhdr_actname.SetIdentity("dspengg_gqhdr_actname", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_actname");
                m_condspengg_gqhdr_cmpdescr.SetIdentity("dspengg_gqhdr_cmpdescr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_cmpdescr");
                m_condspengg_gqhdr_cmpname.SetIdentity("dspengg_gqhdr_cmpname", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_cmpname");
                m_condspengg_gqhdr_cust.SetIdentity("dspengg_gqhdr_cust", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_cust");
                m_condspengg_gqhdr_ecrno.SetIdentity("dspengg_gqhdr_ecrno", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_ecrno");
                m_condspengg_gqhdr_isgql.SetIdentity("dspengg_gqhdr_isgql", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_isgql");
                m_condspengg_gqhdr_prcname.SetIdentity("dspengg_gqhdr_prcname", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_prcname");
                m_condspengg_gqhdr_prodescr.SetIdentity("dspengg_gqhdr_prodescr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_prodescr");
                m_condspengg_gqhdr_proj.SetIdentity("dspengg_gqhdr_proj", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_proj");
                m_condspengg_gqhdr_taskdescr.SetIdentity("dspengg_gqhdr_taskdescr", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_taskdescr");
                m_condspengg_gqhdr_tasktype.SetIdentity("dspengg_gqhdr_tasktype", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_tasktype");
                m_condspengg_gqhdr_uiname.SetIdentity("dspengg_gqhdr_uiname", ControlType.RSDisplayOnly);
                _mainpage.AddControl("dspengg_gqhdr_uiname");
                m_congrdengg_gq_rep_grd.SetIdentity("grdengg_gq_rep_grd", ControlType.RSGrid);
                _tblengg_gq_reportdef.AddControl("grdengg_gq_rep_grd");
                m_congrdengg_gq_rep_grd.SetZoomTask("tskzoomreportrepgrd");
                m_congrdengg_gqfldml_grd.SetIdentity("grdengg_gqfldml_grd", ControlType.RSGrid);
                _tblengg_gq_fields.AddControl("grdengg_gqfldml_grd");
                m_congrdengg_gqfldml_grd.SetZoomTask("tskzoomfieldfldgrd");
                m_congrdengg_gqfldml_grd.AddListItem("15", 1, "Selected Value");
                m_congrdengg_gqfldml_grd.AddListItem("15", 2, "Lookup Value");
                m_congrdengg_gqfldml_grd.AddListItem("15", 3, "Caption");
                m_congrdengg_gqfldml_grd.SetContextValue("CCT_DEFAULT_VALUE_17", "SV1");
                m_congrdengg_gqfldml_grd.AddListItem("17", 1, "SV1");
                m_congrdengg_gqfldml_grd.AddListItem("17", 2, "LV1");
                m_congrdengg_gqfldml_grd.AddListItem("17", 3, "CP1");
                m_congrdengg_gqqml_grd.SetIdentity("grdengg_gqqml_grd", ControlType.RSGrid);
                _tblengg_gq_query.AddControl("grdengg_gqqml_grd");
                m_congrdengg_gqqml_grd.SetZoomTask("tskzoomqueryqrygrd");
                m_congrdengg_gqqml_grd.SetContextValue("CCT_ON_STATE_VALUE_9", "1");
                m_congrdengg_gqqml_grd.SetContextValue("CCT_OFF_STATE_VALUE_9", "0");
                m_conhdnhdncustomer.SetIdentity("hdnhdncustomer", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdncustomer");
                m_conhdnhdnproject.SetIdentity("hdnhdnproject", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdnproject");
                m_conhdnhdnrt_stcontrol.SetIdentity("hdnhdnrt_stcontrol", ControlType.RSEdit);
                _mainpage.AddControl("hdnhdnrt_stcontrol");
                m_conhdnprj_hdn_ctrl.SetIdentity("hdnprj_hdn_ctrl", ControlType.RSEdit);
                _mainpage.AddControl("hdnprj_hdn_ctrl");
                m_conimgengg_gqpopup_json.SetIdentity("imgengg_gqpopup_json", ControlType.RSDisplayOnly);
                _mainpage.AddControl("imgengg_gqpopup_json");
                m_conimgengg_gqpopup_schema.SetIdentity("imgengg_gqpopup_schema", ControlType.RSDisplayOnly);
                _mainpage.AddControl("imgengg_gqpopup_schema");
                m_conlstengg_arg_qry.SetIdentity("lstengg_arg_qry", ControlType.RSEdit);
                _tblengg_gq_arguments.AddControl("lstengg_arg_qry");
                m_conlstengg_fld_qry.SetIdentity("lstengg_fld_qry", ControlType.RSEdit);
                _tblengg_gq_fields.AddControl("lstengg_fld_qry");
                m_conlstengg_gqhdr_tskname.SetIdentity("lstengg_gqhdr_tskname", ControlType.RSEdit);
                _mainpage.AddControl("lstengg_gqhdr_tskname");
                m_contgdengg_argml_treegrd.SetIdentity("tgdengg_argml_treegrd", ControlType.RSTreeGrid);
                _tblengg_gq_arguments.AddControl("tgdengg_argml_treegrd");
                m_contxaschema.SetIdentity("txaschema", ControlType.RSTextArea);
                _mainpage.AddControl("txaschema");
                m_contxtengg_gq_rep_reportname.SetIdentity("txtengg_gq_rep_reportname", ControlType.RSEdit);
                _tblengg_gq_reportdef.AddControl("txtengg_gq_rep_reportname");
                m_contxtversion.SetIdentity("txtversion", ControlType.RSEdit);
                _mainpage.AddControl("txtversion");
                if (iEDKEIExists)
                {
                    base.InitializeControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : InitializeControls()", "ILBO0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets all the controls of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets all the controls of the ILBO
        // ***************************************************************************
        public override void ResetControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetControls()", "de_task_gql");
                m_conchkengg_gqfld_inclayoutctrls.ClearAll();
                m_concmbengg_gq_rep_launchmode.ClearAll();
                m_concmbengg_gq_rep_oufrmt.ClearAll();
                m_concmbengg_gqhdr_actdescr.ClearAll();
                m_concmbengg_gqhdr_uidescr.ClearAll();
                m_condspemgg_arg_qrytype.ClearAll();
                m_condspengg_arg_qryalias.ClearAll();
                m_condspengg_arg_qryhdnkeyfield.ClearAll();
                m_condspengg_arg_qryseq.ClearAll();
                m_condspengg_arg_qryversion.ClearAll();
                m_condspengg_fld_qry_version.ClearAll();
                m_condspengg_fld_qryalias.ClearAll();
                m_condspengg_fld_qryhdnkeyfield.ClearAll();
                m_condspengg_fld_qryseq.ClearAll();
                m_condspengg_fld_qrytype.ClearAll();
                m_condspengg_gqhdr_actname.ClearAll();
                m_condspengg_gqhdr_cmpdescr.ClearAll();
                m_condspengg_gqhdr_cmpname.ClearAll();
                m_condspengg_gqhdr_cust.ClearAll();
                m_condspengg_gqhdr_ecrno.ClearAll();
                m_condspengg_gqhdr_isgql.ClearAll();
                m_condspengg_gqhdr_prcname.ClearAll();
                m_condspengg_gqhdr_prodescr.ClearAll();
                m_condspengg_gqhdr_proj.ClearAll();
                m_condspengg_gqhdr_taskdescr.ClearAll();
                m_condspengg_gqhdr_tasktype.ClearAll();
                m_condspengg_gqhdr_uiname.ClearAll();
                m_congrdengg_gq_rep_grd.ClearAll();
                m_congrdengg_gqfldml_grd.ClearAll();
                m_congrdengg_gqqml_grd.ClearAll();
                m_conhdnhdncustomer.ClearAll();
                m_conhdnhdnproject.ClearAll();
                m_conhdnhdnrt_stcontrol.ClearAll();
                m_conhdnprj_hdn_ctrl.ClearAll();
                m_conimgengg_gqpopup_json.ClearAll();
                m_conimgengg_gqpopup_schema.ClearAll();
                m_conlstengg_arg_qry.ClearAll();
                m_conlstengg_fld_qry.ClearAll();
                m_conlstengg_gqhdr_tskname.ClearAll();
                m_contgdengg_argml_treegrd.ClearAll();
                m_contxaschema.ClearAll();
                m_contxtengg_gq_rep_reportname.ClearAll();
                m_contxtversion.ClearAll();
                this.ResetLayoutControls();
                this.ResetTabControls();
                if (iEDKEIExists)
                {
                    base.ResetControls();
                }
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : ResetControls()", "ILBO0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method adds view information to the controls.
        // </summary>
        // **************************************************************************
        // Function Name		:	AddViewInfo
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	adds view information to the controls.
        // ***************************************************************************
        private new void AddViewInfo()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "AddViewInfo()", "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                m_conchkengg_gqfld_inclayoutctrls.AddView("chkengg_gqfld_inclayoutctrls", true, "integer", String.Empty, String.Empty);
                m_concmbengg_gq_rep_launchmode.AddView("cmbengg_gq_rep_launchmode", true, "char", String.Empty, String.Empty);
                m_concmbengg_gq_rep_oufrmt.AddView("cmbengg_gq_rep_oufrmt", true, "char", String.Empty, String.Empty);
                m_concmbengg_gqhdr_actdescr.AddView("cmbengg_gqhdr_actdescr", true, "char", String.Empty, String.Empty);
                m_concmbengg_gqhdr_uidescr.AddView("cmbengg_gqhdr_uidescr", true, "char", String.Empty, String.Empty);
                m_condspemgg_arg_qrytype.AddView("dspemgg_arg_qrytype", true, "char", String.Empty, String.Empty);
                m_condspengg_arg_qryalias.AddView("dspengg_arg_qryalias", true, "char", String.Empty, String.Empty);
                m_condspengg_arg_qryhdnkeyfield.AddView("dspengg_arg_qryhdnkeyfield", true, "char", String.Empty, String.Empty);
                m_condspengg_arg_qryseq.AddView("dspengg_arg_qryseq", true, "integer", String.Empty, String.Empty);
                m_condspengg_arg_qryversion.AddView("dspengg_arg_qryversion", true, "char", String.Empty, String.Empty);
                m_condspengg_fld_qry_version.AddView("dspengg_fld_qry_version", true, "char", String.Empty, String.Empty);
                m_condspengg_fld_qryalias.AddView("dspengg_fld_qryalias", true, "char", String.Empty, String.Empty);
                m_condspengg_fld_qryhdnkeyfield.AddView("dspengg_fld_qryhdnkeyfield", true, "char", String.Empty, String.Empty);
                m_condspengg_fld_qryseq.AddView("dspengg_fld_qryseq", true, "integer", String.Empty, String.Empty);
                m_condspengg_fld_qrytype.AddView("dspengg_fld_qrytype", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_actname.AddView("dspengg_gqhdr_actname", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_cmpdescr.AddView("dspengg_gqhdr_cmpdescr", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_cmpname.AddView("dspengg_gqhdr_cmpname", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_cust.AddView("dspengg_gqhdr_cust", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_ecrno.AddView("dspengg_gqhdr_ecrno", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_isgql.AddView("dspengg_gqhdr_isgql", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_prcname.AddView("dspengg_gqhdr_prcname", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_prodescr.AddView("dspengg_gqhdr_prodescr", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_proj.AddView("dspengg_gqhdr_proj", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_taskdescr.AddView("dspengg_gqhdr_taskdescr", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_tasktype.AddView("dspengg_gqhdr_tasktype", true, "char", String.Empty, String.Empty);
                m_condspengg_gqhdr_uiname.AddView("dspengg_gqhdr_uiname", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetPageRowCount((8 * 3));
                m_congrdengg_gq_rep_grd.SetVisibleRowCount(8);
                m_congrdengg_gq_rep_grd.AddView("1", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("1", "editbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("2", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("2", "editbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("3", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("3", "displayonly", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("4", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("4", "editbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("5", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("5", "displayonly", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("6", true, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("6", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.SetPageRowCount((7 * 3));
                m_congrdengg_gqfldml_grd.SetVisibleRowCount(7);
                m_congrdengg_gqfldml_grd.AddView("1", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("1", "editbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("10", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("10", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("11", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("11", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("12", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("12", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("13", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("13", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("15", true, "enumerated", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("15", "combobox", "17");
                m_congrdengg_gqfldml_grd.AddView("17", false, "enumerated", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.AddView("2", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("2", "editbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("4", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("4", "editbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("5", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("5", "editbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("6", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("6", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("7", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("7", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("8", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("8", "displayonly", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("9", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("9", "displayonly", String.Empty);
                m_congrdengg_gqqml_grd.SetPageRowCount((8 * 3));
                m_congrdengg_gqqml_grd.SetVisibleRowCount(8);
                m_congrdengg_gqqml_grd.AddView("1", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("1", "editbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("10", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("10", "combobox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("11", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("11", "displayonly", String.Empty);
                m_congrdengg_gqqml_grd.AddView("2", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("2", "editbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("3", true, "integer", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("3", "editbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("6", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("6", "displayonly", String.Empty);
                m_congrdengg_gqqml_grd.AddView("7", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("7", "displayonly", String.Empty);
                m_congrdengg_gqqml_grd.AddView("8", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("8", "displayonly", String.Empty);
                m_congrdengg_gqqml_grd.AddView("9", true, "integer", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("9", "checkbox", String.Empty);
                m_conhdnhdncustomer.AddView("hdnhdncustomer", true, "char", String.Empty, String.Empty);
                m_conhdnhdnproject.AddView("hdnhdnproject", true, "char", String.Empty, String.Empty);
                m_conhdnhdnrt_stcontrol.AddView("hdnhdnrt_stcontrol", true, "char", String.Empty, String.Empty);
                m_conhdnprj_hdn_ctrl.AddView("hdnprj_hdn_ctrl", true, "char", String.Empty, String.Empty);
                m_conimgengg_gqpopup_json.AddView("imgengg_gqpopup_json", true, "char", String.Empty, String.Empty);
                m_conimgengg_gqpopup_json.AddView("hdnengg_gqpopup_jsondbc", false, "char", String.Empty, String.Empty);
                m_conimgengg_gqpopup_schema.AddView("imgengg_gqpopup_schema", true, "char", String.Empty, String.Empty);
                m_conimgengg_gqpopup_schema.AddView("hdnengg_gqpopup_schemadbc", false, "char", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("lstengg_arg_qry", true, "char", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("lstengg_fld_qry", true, "char", String.Empty, String.Empty);
                m_conlstengg_gqhdr_tskname.AddView("lstengg_gqhdr_tskname", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.AddView("1", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("1", "editbox", String.Empty);
                m_contgdengg_argml_treegrd.AddView("10", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("10", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("11", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("11", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("12", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("12", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("13", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("13", "combobox", String.Empty);
                m_contgdengg_argml_treegrd.AddView("2", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("2", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("3", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("3", "combobox", String.Empty);
                m_contgdengg_argml_treegrd.AddView("5", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("5", "editbox", String.Empty);
                m_contgdengg_argml_treegrd.AddView("6", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("6", "editbox", String.Empty);
                m_contgdengg_argml_treegrd.AddView("7", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("7", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("8", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("8", "displayonly", String.Empty);
                m_contgdengg_argml_treegrd.AddView("9", true, "char", String.Empty, String.Empty);
                m_contgdengg_argml_treegrd.SetColumnProperties("9", "displayonly", String.Empty);
                m_contxaschema.AddView("txaschema", true, "char", String.Empty, String.Empty);
                m_contxtengg_gq_rep_reportname.AddView("txtengg_gq_rep_reportname", true, "char", String.Empty, String.Empty);
                m_contxtversion.AddView("txtversion", true, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn1", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn1", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn2", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn2", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn3", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn3", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn4", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn4", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn5", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn5", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn6", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn6", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn7", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn7", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gdfld_ctrlbtsyn8", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gdfld_ctrlbtsyn8", "listeditbox", String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry1", false, "char", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry2", false, "char", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry3", false, "char", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry4", false, "integer", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry5", false, "char", String.Empty, String.Empty);
                m_conlstengg_arg_qry.AddView("uiengg_gqarg_qry6", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gqfld_fieldname1", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gqfld_fieldname1", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gqfld_fieldname2", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gqfld_fieldname2", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gqfld_fieldname3", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gqfld_fieldname3", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gqfld_fieldname4", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gqfld_fieldname4", "listeditbox", String.Empty);
                m_congrdengg_gqfldml_grd.AddView("uiengg_gqfld_fieldname5", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqfldml_grd.SetColumnProperties("uiengg_gqfld_fieldname5", "listeditbox", String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry1", false, "char", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry2", false, "char", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry3", false, "char", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry4", false, "integer", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry5", false, "char", String.Empty, String.Empty);
                m_conlstengg_fld_qry.AddView("uiengg_gqfld_qry6", false, "char", String.Empty, String.Empty);
                m_conlstengg_gqhdr_tskname.AddView("uiengg_gqhdr_task1", false, "char", String.Empty, String.Empty);
                m_conlstengg_gqhdr_tskname.AddView("uiengg_gqhdr_task2", false, "char", String.Empty, String.Empty);
                m_conlstengg_gqhdr_tskname.AddView("uiengg_gqhdr_task3", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn1", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn1", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn2", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn2", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn3", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn3", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn4", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn4", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn5", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn5", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn6", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn6", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn7", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn7", "listeditbox", String.Empty);
                m_congrdengg_gq_rep_grd.AddView("uiengg_gqrep_ctrlbtsyn8", false, "char", String.Empty, String.Empty);
                m_congrdengg_gq_rep_grd.SetColumnProperties("uiengg_gqrep_ctrlbtsyn8", "listeditbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("uiengg_gqtsk_qry1", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("uiengg_gqtsk_qry1", "listeditbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("uiengg_gqtsk_qry4", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("uiengg_gqtsk_qry4", "listeditbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("uiengg_gqtsk_qry5", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("uiengg_gqtsk_qry5", "listeditbox", String.Empty);
                m_congrdengg_gqqml_grd.AddView("uiengg_gqtsk_qry6", false, "char", String.Empty, String.Empty);
                m_congrdengg_gqqml_grd.SetColumnProperties("uiengg_gqtsk_qry6", "listeditbox", String.Empty);
                m_conrvwrt_lctxt_ou.AddView("rvwrt_lctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_ou.AddView("rvwrt_cctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_component.AddView("rvwrt_cctxt_component", false, "char", String.Empty, String.Empty);
                if (iEDKEIExists)
                {
                    base.AddViewInfo();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : AddViewInfo()", "ILBO0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method creates/gets the Object Handle of the Control
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControlX
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	creates/gets the Object Handle of the Control
        // ***************************************************************************
        public override IControl GetControlX(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControlX(sControlID = \"{0}\")", sControlID), "de_task_gql");
                switch (sControlID.ToLower())
                {
                    case "chkengg_gqfld_inclayoutctrls":
                        return this.m_conchkengg_gqfld_inclayoutctrls;
                    case "cmbengg_gq_rep_launchmode":
                        return this.m_concmbengg_gq_rep_launchmode;
                    case "cmbengg_gq_rep_oufrmt":
                        return this.m_concmbengg_gq_rep_oufrmt;
                    case "cmbengg_gqhdr_actdescr":
                        return this.m_concmbengg_gqhdr_actdescr;
                    case "cmbengg_gqhdr_uidescr":
                        return this.m_concmbengg_gqhdr_uidescr;
                    case "dspemgg_arg_qrytype":
                        return this.m_condspemgg_arg_qrytype;
                    case "dspengg_arg_qryalias":
                        return this.m_condspengg_arg_qryalias;
                    case "dspengg_arg_qryhdnkeyfield":
                        return this.m_condspengg_arg_qryhdnkeyfield;
                    case "dspengg_arg_qryseq":
                        return this.m_condspengg_arg_qryseq;
                    case "dspengg_arg_qryversion":
                        return this.m_condspengg_arg_qryversion;
                    case "dspengg_fld_qry_version":
                        return this.m_condspengg_fld_qry_version;
                    case "dspengg_fld_qryalias":
                        return this.m_condspengg_fld_qryalias;
                    case "dspengg_fld_qryhdnkeyfield":
                        return this.m_condspengg_fld_qryhdnkeyfield;
                    case "dspengg_fld_qryseq":
                        return this.m_condspengg_fld_qryseq;
                    case "dspengg_fld_qrytype":
                        return this.m_condspengg_fld_qrytype;
                    case "dspengg_gqhdr_actname":
                        return this.m_condspengg_gqhdr_actname;
                    case "dspengg_gqhdr_cmpdescr":
                        return this.m_condspengg_gqhdr_cmpdescr;
                    case "dspengg_gqhdr_cmpname":
                        return this.m_condspengg_gqhdr_cmpname;
                    case "dspengg_gqhdr_cust":
                        return this.m_condspengg_gqhdr_cust;
                    case "dspengg_gqhdr_ecrno":
                        return this.m_condspengg_gqhdr_ecrno;
                    case "dspengg_gqhdr_isgql":
                        return this.m_condspengg_gqhdr_isgql;
                    case "dspengg_gqhdr_prcname":
                        return this.m_condspengg_gqhdr_prcname;
                    case "dspengg_gqhdr_prodescr":
                        return this.m_condspengg_gqhdr_prodescr;
                    case "dspengg_gqhdr_proj":
                        return this.m_condspengg_gqhdr_proj;
                    case "dspengg_gqhdr_taskdescr":
                        return this.m_condspengg_gqhdr_taskdescr;
                    case "dspengg_gqhdr_tasktype":
                        return this.m_condspengg_gqhdr_tasktype;
                    case "dspengg_gqhdr_uiname":
                        return this.m_condspengg_gqhdr_uiname;
                    case "grdengg_gq_rep_grd":
                        return this.m_congrdengg_gq_rep_grd;
                    case "grdengg_gqfldml_grd":
                        return this.m_congrdengg_gqfldml_grd;
                    case "grdengg_gqqml_grd":
                        return this.m_congrdengg_gqqml_grd;
                    case "hdnhdncustomer":
                        return this.m_conhdnhdncustomer;
                    case "hdnhdnproject":
                        return this.m_conhdnhdnproject;
                    case "hdnhdnrt_stcontrol":
                        return this.m_conhdnhdnrt_stcontrol;
                    case "hdnprj_hdn_ctrl":
                        return this.m_conhdnprj_hdn_ctrl;
                    case "imgengg_gqpopup_json":
                        return this.m_conimgengg_gqpopup_json;
                    case "imgengg_gqpopup_schema":
                        return this.m_conimgengg_gqpopup_schema;
                    case "lstengg_arg_qry":
                        return this.m_conlstengg_arg_qry;
                    case "lstengg_fld_qry":
                        return this.m_conlstengg_fld_qry;
                    case "lstengg_gqhdr_tskname":
                        return this.m_conlstengg_gqhdr_tskname;
                    case "tgdengg_argml_treegrd":
                        return this.m_contgdengg_argml_treegrd;
                    case "txaschema":
                        return this.m_contxaschema;
                    case "txtengg_gq_rep_reportname":
                        return this.m_contxtengg_gq_rep_reportname;
                    case "txtversion":
                        return this.m_contxtversion;
                    case "rvwrt_cctxt_component":
                        return this.m_conrvwrt_cctxt_component;
                    case "rvwrt_cctxt_ou":
                        return this.m_conrvwrt_cctxt_ou;
                    case "rvwrt_lctxt_ou":
                        return this.m_conrvwrt_lctxt_ou;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.GetControlX(sControlID);
                        }
                        else
                        {
                            return null;
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetControlX(sControlID = \"{0}\")", sControlID), "ILBO0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override IControl GetControl(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControl(sControlID = \"{0}\")", sControlID), "de_task_gql");
                IControl control = this.GetControlX(sControlID);
                if ((control != null))
                {
                    return control;
                }
                else
                {
                    throw new Exception("String.Format(\"Invalid ControlID - {0}\", sControlID)");
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetControl(sControlID = \"{0}\")", sControlID), "ILBO0005", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem
        // ***************************************************************************
        public override string GetDataItem(string sLinkID, string sDataItemName, long nInstance)
        {
            string sRetData = String.Empty;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "de_task_gql");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItem(sLinkID, sDataItemName, nInstance);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\"), nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "ILBO0006", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem Instances.
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItemInstances
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem Instances.
        // ***************************************************************************
        public override long GetDataItemInstances(string sLinkID, string sDataItemName)
        {
            long sRetData = 0;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "de_task_gql");
                if ((iEDKEIExists && !bFlag))
                {
                    return base.GetDataItemInstances(sLinkID, sDataItemName);
                }
                else
                {
                    return sRetData;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "ILBO0007", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method sets the DataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	SetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	sets the DataItem
        // ***************************************************************************
        public override void SetDataItem(string sLinkID, string sDataItemName, long nInstance, string sValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\",nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance, sValue), "de_task_gql");
                bool bFlag = false;
                switch (sLinkID)
                {
                    case "ezeeview":
                        return;
                    case "12586":
                        if ((sDataItemName == "csou"))
                        {
                            m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "emgg_arg_qrytype"))
                        {
                            m_condspemgg_arg_qrytype.SetControlValue("dspemgg_arg_qrytype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qry"))
                        {
                            m_conlstengg_arg_qry.SetControlValue("lstengg_arg_qry", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryalias"))
                        {
                            m_condspengg_arg_qryalias.SetControlValue("dspengg_arg_qryalias", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryseq"))
                        {
                            m_condspengg_arg_qryseq.SetControlValue("dspengg_arg_qryseq", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryversion"))
                        {
                            m_condspengg_arg_qryversion.SetControlValue("dspengg_arg_qryversion", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("tgdengg_argml_treegrd", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_nex"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__nodeexpand", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_nid"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__nodeid", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_pnid"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__parentnodeid", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qry"))
                        {
                            m_conlstengg_fld_qry.SetControlValue("lstengg_fld_qry", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qry_version"))
                        {
                            m_condspengg_fld_qry_version.SetControlValue("dspengg_fld_qry_version", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qryalias"))
                        {
                            m_condspengg_fld_qryalias.SetControlValue("dspengg_fld_qryalias", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qryseq"))
                        {
                            m_condspengg_fld_qryseq.SetControlValue("dspengg_fld_qryseq", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qrytype"))
                        {
                            m_condspengg_fld_qrytype.SetControlValue("dspengg_fld_qrytype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gdfldml_fldalias"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("4", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_arguments"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("1", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_ctrlviewname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("3", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_datatype"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("11", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_defvalue"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("5", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_field"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("6", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_ismandatory"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("12", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_kind"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("8", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_oftype"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("7", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_parschmaname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("10", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_schmaname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("9", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_type"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("2", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_caption"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("8", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrlbtsyn"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("1", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrlid"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("10", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrltype"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("9", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_defvalue"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("5", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_fldname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("2", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_pagname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("13", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_parschmaname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("7", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_schmaname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("6", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_secname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("12", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_viewname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("11", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_actdescr"))
                        {
                            m_concmbengg_gqhdr_actdescr.SetControlValue("cmbengg_gqhdr_actdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_actname"))
                        {
                            m_condspengg_gqhdr_actname.SetControlValue("dspengg_gqhdr_actname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cmpdescr"))
                        {
                            m_condspengg_gqhdr_cmpdescr.SetControlValue("dspengg_gqhdr_cmpdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cmpname"))
                        {
                            m_condspengg_gqhdr_cmpname.SetControlValue("dspengg_gqhdr_cmpname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cust"))
                        {
                            m_condspengg_gqhdr_cust.SetControlValue("dspengg_gqhdr_cust", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_ecrno"))
                        {
                            m_condspengg_gqhdr_ecrno.SetControlValue("dspengg_gqhdr_ecrno", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_prcname"))
                        {
                            m_condspengg_gqhdr_prcname.SetControlValue("dspengg_gqhdr_prcname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_prodescr"))
                        {
                            m_condspengg_gqhdr_prodescr.SetControlValue("dspengg_gqhdr_prodescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_proj"))
                        {
                            m_condspengg_gqhdr_proj.SetControlValue("dspengg_gqhdr_proj", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_taskdescr"))
                        {
                            m_condspengg_gqhdr_taskdescr.SetControlValue("dspengg_gqhdr_taskdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_tasktype"))
                        {
                            m_condspengg_gqhdr_tasktype.SetControlValue("dspengg_gqhdr_tasktype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_tskname"))
                        {
                            m_conlstengg_gqhdr_tskname.SetControlValue("lstengg_gqhdr_tskname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_uidescr"))
                        {
                            m_concmbengg_gqhdr_uidescr.SetControlValue("cmbengg_gqhdr_uidescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_uiname"))
                        {
                            m_condspengg_gqhdr_uiname.SetControlValue("dspengg_gqhdr_uiname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqlqml_qrytype"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("6", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqpopup_json"))
                        {
                            m_conimgengg_gqpopup_json.SetControlValue("imgengg_gqpopup_json", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqpopup_schema"))
                        {
                            m_conimgengg_gqpopup_schema.SetControlValue("imgengg_gqpopup_schema", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryalias"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("2", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryname"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("1", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qrytext"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("8", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryversion"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("7", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_seqno"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("3", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "hdncustomer"))
                        {
                            m_conhdnhdncustomer.SetControlValue("hdnhdncustomer", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdnproject"))
                        {
                            m_conhdnhdnproject.SetControlValue("hdnhdnproject", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "prj_hdn_ctrl"))
                        {
                            m_conhdnprj_hdn_ctrl.SetControlValue("hdnprj_hdn_ctrl", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "version"))
                        {
                            m_contxtversion.SetControlValue("txtversion", sValue, 0);
                            return;
                        }
                        break;
                    case "12592":
                        if ((sDataItemName == "csou"))
                        {
                            m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "emgg_arg_qrytype"))
                        {
                            m_condspemgg_arg_qrytype.SetControlValue("dspemgg_arg_qrytype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qry"))
                        {
                            m_conlstengg_arg_qry.SetControlValue("lstengg_arg_qry", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryalias"))
                        {
                            m_condspengg_arg_qryalias.SetControlValue("dspengg_arg_qryalias", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryhdnkeyfield"))
                        {
                            m_condspengg_arg_qryhdnkeyfield.SetControlValue("dspengg_arg_qryhdnkeyfield", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryseq"))
                        {
                            m_condspengg_arg_qryseq.SetControlValue("dspengg_arg_qryseq", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_arg_qryversion"))
                        {
                            m_condspengg_arg_qryversion.SetControlValue("dspengg_arg_qryversion", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("tgdengg_argml_treegrd", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_nex"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__nodeexpand", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_nid"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__nodeid", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_argml_treegrd_pnid"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("__parentnodeid", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qry"))
                        {
                            m_conlstengg_fld_qry.SetControlValue("lstengg_fld_qry", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qry_version"))
                        {
                            m_condspengg_fld_qry_version.SetControlValue("dspengg_fld_qry_version", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qryalias"))
                        {
                            m_condspengg_fld_qryalias.SetControlValue("dspengg_fld_qryalias", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qryhdnkeyfield"))
                        {
                            m_condspengg_fld_qryhdnkeyfield.SetControlValue("dspengg_fld_qryhdnkeyfield", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qryseq"))
                        {
                            m_condspengg_fld_qryseq.SetControlValue("dspengg_fld_qryseq", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_fld_qrytype"))
                        {
                            m_condspengg_fld_qrytype.SetControlValue("dspengg_fld_qrytype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gdfldml_fldalias"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("4", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_arguments"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("1", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_ctrlviewname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("3", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_datatype"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("11", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_defvalue"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("5", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_field"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("6", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_ismandatory"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("12", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_kind"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("8", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_oftype"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("7", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_parschmaname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("10", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_protype"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("13", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_schmaname"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("9", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqargml_type"))
                        {
                            m_contgdengg_argml_treegrd.SetControlValue("2", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfld_inclayoutctrls"))
                        {
                            m_conchkengg_gqfld_inclayoutctrls.SetControlValue("chkengg_gqfld_inclayoutctrls", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_caption"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("8", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrlbtsyn"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("1", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrlid"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("10", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_ctrltype"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("9", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_defvalue"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("5", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_fldname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("2", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_maptype"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("17", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_pagname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("13", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_parschmaname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("7", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_schmaname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("6", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_secname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("12", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqfldml_viewname"))
                        {
                            m_congrdengg_gqfldml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqfldml_grd.SetControlValue("11", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_actdescr"))
                        {
                            m_concmbengg_gqhdr_actdescr.SetControlValue("cmbengg_gqhdr_actdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_actname"))
                        {
                            m_condspengg_gqhdr_actname.SetControlValue("dspengg_gqhdr_actname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cmpdescr"))
                        {
                            m_condspengg_gqhdr_cmpdescr.SetControlValue("dspengg_gqhdr_cmpdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cmpname"))
                        {
                            m_condspengg_gqhdr_cmpname.SetControlValue("dspengg_gqhdr_cmpname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_cust"))
                        {
                            m_condspengg_gqhdr_cust.SetControlValue("dspengg_gqhdr_cust", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_ecrno"))
                        {
                            m_condspengg_gqhdr_ecrno.SetControlValue("dspengg_gqhdr_ecrno", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_isgql"))
                        {
                            m_condspengg_gqhdr_isgql.SetControlValue("dspengg_gqhdr_isgql", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_prcname"))
                        {
                            m_condspengg_gqhdr_prcname.SetControlValue("dspengg_gqhdr_prcname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_prodescr"))
                        {
                            m_condspengg_gqhdr_prodescr.SetControlValue("dspengg_gqhdr_prodescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_proj"))
                        {
                            m_condspengg_gqhdr_proj.SetControlValue("dspengg_gqhdr_proj", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_taskdescr"))
                        {
                            m_condspengg_gqhdr_taskdescr.SetControlValue("dspengg_gqhdr_taskdescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_tasktype"))
                        {
                            m_condspengg_gqhdr_tasktype.SetControlValue("dspengg_gqhdr_tasktype", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_tskname"))
                        {
                            m_conlstengg_gqhdr_tskname.SetControlValue("lstengg_gqhdr_tskname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_uidescr"))
                        {
                            m_concmbengg_gqhdr_uidescr.SetControlValue("cmbengg_gqhdr_uidescr", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqhdr_uiname"))
                        {
                            m_condspengg_gqhdr_uiname.SetControlValue("dspengg_gqhdr_uiname", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqlqml_qrytype"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("6", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqpopup_json"))
                        {
                            m_conimgengg_gqpopup_json.SetControlValue("imgengg_gqpopup_json", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqpopup_schema"))
                        {
                            m_conimgengg_gqpopup_schema.SetControlValue("imgengg_gqpopup_schema", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_cache"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("9", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_cache_ttl"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("10", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_hdnkeyfield"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("11", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryalias"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("2", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryname"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("1", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qrytext"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("8", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_qryversion"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("7", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "engg_gqqml_seqno"))
                        {
                            m_congrdengg_gqqml_grd.SetPagedControlValue("modeflag", string.Empty, nInstance);
                            m_congrdengg_gqqml_grd.SetControlValue("3", sValue, nInstance);
                            return;
                        }
                        if ((sDataItemName == "hdncustomer"))
                        {
                            m_conhdnhdncustomer.SetControlValue("hdnhdncustomer", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "hdnproject"))
                        {
                            m_conhdnhdnproject.SetControlValue("hdnhdnproject", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "prj_hdn_ctrl"))
                        {
                            m_conhdnprj_hdn_ctrl.SetControlValue("hdnprj_hdn_ctrl", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "schema"))
                        {
                            m_contxaschema.SetControlValue("txaschema", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "version"))
                        {
                            m_contxtversion.SetControlValue("txtversion", sValue, 0);
                            return;
                        }
                        break;
                    default:
                        break;
                }
                if ((iEDKEIExists && !bFlag))
                {
                    base.SetDataItem(sLinkID, sDataItemName, nInstance, sValue);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance.ToString(), sValue.ToString()), "ILBO0008", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the GlobalVariable handle
        // </summary>
        // **************************************************************************
        // Function Name		:	GetVariable
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the GlobalVariable handle
        // ***************************************************************************
        public override IGlobalVariable GetVariable(string sVariable)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetVariable(sVariable = \"{0}\")", sVariable), "de_task_gql");
                if (iEDKEIExists)
                {
                    return base.GetVariable(sVariable);
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetVariable(sVariable = \"{0}\")", sVariable), "ILBO0009", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool PerformTask(string sControlID, string sEventName, string sEventDetails, out string sTargetURL)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "de_task_gql");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                sTargetURL = string.Empty;
                switch (sEventName.ToLower())
                {
                    case "achmainsrengg_rui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsractdes");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblengengg_yui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsrargqry");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblengengg_vtr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrargsav");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblen_enggqftr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrflddef");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblen_enggldui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsrfldqry");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblen_enggfltr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrfldsav");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achgqlengg_otr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrfolimp");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmainsrengg_ptr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrimpsch");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achfieldengg_iui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsrinctrl");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblenqenggy_tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrqrysav");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achtblengeng_gqtr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        bServiceResult = this.ExecuteService("achgqlsrrepsav");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "1");
                            return true;
                        }
                    case "achmainsrengg_nui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsrtsknam");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achmainsrengg_iui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        bServiceResult = this.ExecuteService("achgqlsruides");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    case "achgqlengg__lk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "de_il_error", "de_il_followup_task", "12480");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_activity", FlowAttribute.flowIn, false, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_component", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_customer_name", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_ico_no", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_isgql", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_process_descr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_project_name", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_ui", FlowAttribute.flowIn, false, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr");
                        sTargetURL = IHandler.LaunchScreenObject("de_il_error", "de_il_followup_task", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    case "achgqlengg_slk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "de_schemavisualizer", "12590");
                        IDBroker.SubscribeData(lSubscriptionID, "activityname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname");
                        IDBroker.SubscribeData(lSubscriptionID, "componentnamehdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname");
                        IDBroker.SubscribeData(lSubscriptionID, "customername_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "docno_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "processname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname");
                        IDBroker.SubscribeData(lSubscriptionID, "projectname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "taskname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname");
                        IDBroker.SubscribeData(lSubscriptionID, "uiname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname");
                        sTargetURL = IHandler.LaunchScreenObject("mnggqloperation", "de_schemavisualizer", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    case "achgqmainengglllk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "de_graphqlstudio", "12587");
                        IDBroker.SubscribeData(lSubscriptionID, "activityname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname");
                        IDBroker.SubscribeData(lSubscriptionID, "componentname", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname");
                        IDBroker.SubscribeData(lSubscriptionID, "customername_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "docno_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "processname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname");
                        IDBroker.SubscribeData(lSubscriptionID, "projectname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "uiname", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname");
                        sTargetURL = IHandler.LaunchScreenObject("mnggqloperation", "de_graphqlstudio", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    case "achgqmainenggqllk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        bServiceResult = this.ExecuteService("achgqlsrsdl");
                        if ((bServiceResult == false))
                        {
                            return false;
                        }
                        return bServiceResult;
                    case "achmainsrengggqlk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        return true;
                        break;
                    case "tskzoomfieldfldgrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachfieldfldgrd", "12594");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d10", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "10");
                        IDBroker.SubscribeData(lSubscriptionID, "d11", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "11");
                        IDBroker.SubscribeData(lSubscriptionID, "d12", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "12");
                        IDBroker.SubscribeData(lSubscriptionID, "d13", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "13");
                        IDBroker.SubscribeData(lSubscriptionID, "d17", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "17");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d4", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "4");
                        IDBroker.SubscribeData(lSubscriptionID, "d5", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "5");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "6");
                        IDBroker.SubscribeData(lSubscriptionID, "d7", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "7");
                        IDBroker.SubscribeData(lSubscriptionID, "d8", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "8");
                        IDBroker.SubscribeData(lSubscriptionID, "d9", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "9");
                        sTargetURL = IHandler.LaunchScreenObject("mnggqloperation", "zachfieldfldgrd", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    case "tskzoomqueryqrygrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachqueryqrygrd", "12595");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d10", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "10");
                        IDBroker.SubscribeData(lSubscriptionID, "d11", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "11");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d3", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "3");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "6");
                        IDBroker.SubscribeData(lSubscriptionID, "d7", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "7");
                        IDBroker.SubscribeData(lSubscriptionID, "d8", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "8");
                        IDBroker.SubscribeData(lSubscriptionID, "d9", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "9");
                        sTargetURL = IHandler.LaunchScreenObject("mnggqloperation", "zachqueryqrygrd", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    case "tskzoomreportrepgrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachreportrepgrd", "12593");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d3", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "3");
                        IDBroker.SubscribeData(lSubscriptionID, "d4", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "4");
                        IDBroker.SubscribeData(lSubscriptionID, "d5", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "5");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "6");
                        sTargetURL = IHandler.LaunchScreenObject("mnggqloperation", "zachreportrepgrd", "mnggqloperation", "de_task_gql", sControlID);
                        return true;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.PerformTask(sControlID, sEventName, sEventDetails, out sTargetURL);
                        }
                        break;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "ILBO0010", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override IAsyncResult BeginPerformTask(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_task_gql");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                bool bExecFlag = base.PreTaskExecution(reqState);
                if ((bExecFlag == false))
                {
                    return ISManager.SetAsyncException(null);
                }
                switch (reqState.TaskName.ToLower())
                {
                    case "achmainsrengg_rui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsractdes";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblengengg_yui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsrargqry";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblengengg_vtr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrargsav";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblen_enggqftr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrflddef";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblen_enggldui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsrfldqry";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblen_enggfltr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrfldsav";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achgqlengg_otr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrfolimp";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmainsrengg_ptr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrimpsch";
                        reqState.TransactionScope = 2;
                        return this.BeginExecuteService(cb, reqState);
                    case "achfieldengg_iui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsrinctrl";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblenqenggy_tr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrqrysav";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achtblengeng_gqtr":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "TRANS");
                        reqState.ServiceName = "achgqlsrrepsav";
                        reqState.TransactionScope = 2;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmainsrengg_nui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsrtsknam";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmainsrengg_iui":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "UI");
                        reqState.ServiceName = "achgqlsruides";
                        reqState.TransactionScope = 0;
                        return this.BeginExecuteService(cb, reqState);
                    case "achgqlengg__lk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "de_il_error", "de_il_followup_task", "12480");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_activity", FlowAttribute.flowIn, false, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_component", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_customer_name", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_ico_no", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_isgql", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_process_descr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_project_name", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "engg_ui", FlowAttribute.flowIn, false, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr");
                        reqState.SetTraversal("de_il_error", "de_il_followup_task", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    case "achgqlengg_slk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "de_schemavisualizer", "12590");
                        IDBroker.SubscribeData(lSubscriptionID, "activityname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname");
                        IDBroker.SubscribeData(lSubscriptionID, "componentnamehdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname");
                        IDBroker.SubscribeData(lSubscriptionID, "customername_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "docno_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "processname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname");
                        IDBroker.SubscribeData(lSubscriptionID, "projectname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "taskname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname");
                        IDBroker.SubscribeData(lSubscriptionID, "uiname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname");
                        reqState.SetTraversal("mnggqloperation", "de_schemavisualizer", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    case "achgqmainengglllk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "de_graphqlstudio", "12587");
                        IDBroker.SubscribeData(lSubscriptionID, "activityname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname");
                        IDBroker.SubscribeData(lSubscriptionID, "componentname", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname");
                        IDBroker.SubscribeData(lSubscriptionID, "customername_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust");
                        IDBroker.SubscribeData(lSubscriptionID, "docno_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno");
                        IDBroker.SubscribeData(lSubscriptionID, "processname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname");
                        IDBroker.SubscribeData(lSubscriptionID, "projectname_hdr", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj");
                        IDBroker.SubscribeData(lSubscriptionID, "uiname", FlowAttribute.flowIn, false, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname");
                        reqState.SetTraversal("mnggqloperation", "de_graphqlstudio", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    case "achgqmainenggqllk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        reqState.ServiceName = "achgqlsrsdl";
                        reqState.TransactionScope = 2;
                        return this.BeginExecuteService(cb, reqState);
                    case "achmainsrengggqlk":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "LINK");
                        break;
                    case "tskzoomfieldfldgrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachfieldfldgrd", "12594");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d10", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "10");
                        IDBroker.SubscribeData(lSubscriptionID, "d11", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "11");
                        IDBroker.SubscribeData(lSubscriptionID, "d12", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "12");
                        IDBroker.SubscribeData(lSubscriptionID, "d13", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "13");
                        IDBroker.SubscribeData(lSubscriptionID, "d17", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "17");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d4", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "4");
                        IDBroker.SubscribeData(lSubscriptionID, "d5", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "5");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "6");
                        IDBroker.SubscribeData(lSubscriptionID, "d7", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "7");
                        IDBroker.SubscribeData(lSubscriptionID, "d8", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "8");
                        IDBroker.SubscribeData(lSubscriptionID, "d9", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqfldml_grd", "9");
                        reqState.SetTraversal("mnggqloperation", "zachfieldfldgrd", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    case "tskzoomqueryqrygrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachqueryqrygrd", "12595");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d10", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "10");
                        IDBroker.SubscribeData(lSubscriptionID, "d11", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "11");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d3", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "3");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "6");
                        IDBroker.SubscribeData(lSubscriptionID, "d7", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "7");
                        IDBroker.SubscribeData(lSubscriptionID, "d8", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "8");
                        IDBroker.SubscribeData(lSubscriptionID, "d9", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gqqml_grd", "9");
                        reqState.SetTraversal("mnggqloperation", "zachqueryqrygrd", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    case "tskzoomreportrepgrd":
                        ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "ZOOM");
                        lSubscriptionID = IDBroker.SubscribeLink("mnggqloperation", "de_task_gql", "mnggqloperation", "zachreportrepgrd", "12593");
                        IDBroker.SubscribeData(lSubscriptionID, "d1", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "1");
                        IDBroker.SubscribeData(lSubscriptionID, "d2", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "2");
                        IDBroker.SubscribeData(lSubscriptionID, "d3", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "3");
                        IDBroker.SubscribeData(lSubscriptionID, "d4", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "4");
                        IDBroker.SubscribeData(lSubscriptionID, "d5", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "5");
                        IDBroker.SubscribeData(lSubscriptionID, "d6", FlowAttribute.flowInOut, false, "de_task_gql", "grdengg_gq_rep_grd", "6");
                        reqState.SetTraversal("mnggqloperation", "zachreportrepgrd", "mnggqloperation", "de_task_gql");
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        else
                        {
                            return IHandler.BeginLaunchScreenObject(cb, reqState);
                        }
                    default:
                        if (iEDKEIExists)
                        {
                            return base.BeginPerformTask(cb, reqState);
                        }
                        break;
                }
                return ISManager.SetAsyncCompleted(new VWResponseState());
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : BeginPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0011", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public override bool EndPerformTask(IAsyncResult ar)
        {
            VWAsyncResult result = ar as VWAsyncResult;
            VWRequestState reqState = result.AsyncState as VWRequestState;
            VWResponseState resState = result.ResponseState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                long lSubscriptionID = 0;
                bool bServiceResult = true;
                string sTargetURL = string.Empty;
                switch (reqState.TaskName.ToLower())
                {
                    case "achmainsrengg_rui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblengengg_yui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblengengg_vtr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblen_enggqftr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblen_enggldui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblen_enggfltr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achgqlengg_otr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmainsrengg_ptr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achfieldengg_iui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblenqenggy_tr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achtblengeng_gqtr":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmainsrengg_nui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmainsrengg_iui":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achgqlengg__lk":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    case "achgqlengg_slk":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    case "achgqmainengglllk":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    case "achgqmainenggqllk":
                        bServiceResult = this.EndExecuteService(ar);
                        break;
                    case "achmainsrengggqlk":
                        break;
                    case "tskzoomfieldfldgrd":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    case "tskzoomqueryqrygrd":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    case "tskzoomreportrepgrd":
                        resState.TargetURL = IHandler.EndLaunchScreenObject(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndPerformTask(ar);
                        }
                        break;
                }
                if (bServiceResult)
                {
                    bServiceResult = base.PostTaskExecution(reqState.TaskName);
                }
                return bServiceResult;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : EndPerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", reqState.Control, reqState.EventName, reqState.EventDetails), "ILBO0012", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method initializes Scripts for Data Transfer
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess1
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	initializes Scripts for Data Transfer
        // ***************************************************************************
        public override bool PreProcess1()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess1", "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IObjectBroker IobjBroker = ISManager.GetObjectBroker();
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_task_gql");
                if (iEDKEIExists)
                {
                    return base.PreProcess1();
                }
                else
                {
                    return true;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : PreProcess1()", "ILBO0013", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool PreProcess2()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess2", "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                bReturn = this.ExecuteService("achgqlsrinit");
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_task_gql");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess2();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : PreProcess2()", "ILBO0014 ", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess2(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess2()", "de_task_gql");
                reqState.ServiceName = "achgqlsrinit";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : BeginPreProcess2()", "ILBO0015", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public override bool EndPreProcess2(IAsyncResult ar)
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess2()", "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                bReturn = this.EndExecuteService(ar);
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.EndPreProcess2(ar);
                }
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "de_task_gql");
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : EndPreProcess2()", "ILBO0016", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool PreProcess3()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess3()", "de_task_gql");
                bReturn = this.ExecuteService("achgqlsrfet");
                if ((bReturn && iEDKEIExists))
                {
                    bReturn = base.PreProcess3();
                }
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : PreProcess3()", "ILBO0017", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override IAsyncResult BeginPreProcess3(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "BeginPreProcess3()", "de_task_gql");
                reqState.ServiceName = "achgqlsrfet";
                reqState.TransactionScope = 0;
                return this.BeginExecuteService(cb, reqState);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : BeginPreProcess3()", "ILBO0018", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndPreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public override bool EndPreProcess3(IAsyncResult ar)
        {
            bool bReturn = false;
            object[] upeControlDetails;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "EndPreProcess3()", "de_task_gql");
                bReturn = this.EndExecuteService(ar);
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : EndPreProcess3()", "ILBO0019", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public override object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetContextValue(sContextName = \"{0}\")", sContextName), "de_task_gql");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    if (htContextItems.ContainsKey(sContextName))
                    {
                        return htContextItems[sContextName];
                    }
                    else
                    {
                        return null;
                    }
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    return m_conrvwrt_cctxt_component.GetControlValue("rvwrt_cctxt_component");
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    return m_conrvwrt_cctxt_ou.GetControlValue("rvwrt_cctxt_ou");
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    return m_conrvwrt_lctxt_ou.GetControlValue("rvwrt_lctxt_ou");
                }
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetContextValue(sContextName = \"{0}\")", sContextName), "ILBO0020", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Adds/Sets the Context Value to the collection based on the contextname
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Adds/Sets the Context Value to the collection based on the contextname
        // ***************************************************************************
        public override void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "de_task_gql");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    htContextItems[sContextName] = sContextValue;
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    m_conrvwrt_cctxt_component.SetControlValue("rvwrt_cctxt_component", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    m_conrvwrt_cctxt_ou.SetControlValue("rvwrt_cctxt_ou", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", (string)sContextValue);
                    return;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "ILBO0021", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        public override void GetTaskData(string sTabName, string sTaskName, System.Xml.XmlNode nodeScreenInfo)
        {
            string sOutMTD = string.Empty;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_task_gql");
                if ((string.CompareOrdinal(GetContextValue("ICT_INLINE_TAB") as String, "1") == 0))
                {
                    ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                    IContext ISMContext = ISManager.GetContextObject();
                    IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                    System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                    System.Xml.XmlElement eltContextName;
                    System.Xml.XmlElement eltIlboInfo = null;
                    System.Xml.XmlElement eltDTabs = null;
                    System.Xml.XmlElement eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    System.Xml.XmlElement eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                    if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                    {
                        eltIlboInfo = xmlDom.CreateElement("ii");
                        nodeScreenInfo.AppendChild(eltIlboInfo);
                    }
                    else
                    {
                        eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    }
                    switch (sTaskName.ToLower())
                    {
                        case "achfieldengg_iui":
                            break;
                        case "achgqlengg__lk":
                            break;
                        case "achgqlengg_otr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_isgql.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_json.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_schema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            break;
                        case "achgqlengg_slk":
                            break;
                        case "achgqmainengglllk":
                            break;
                        case "achgqmainenggqllk":
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxaschema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            break;
                        case "achmainsrengg_iui":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_arguments":
                                    m_contgdengg_argml_treegrd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_query":
                                    m_congrdengg_gqqml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_reportdef":
                                    m_concmbengg_gq_rep_launchmode.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_concmbengg_gq_rep_oufrmt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contxtengg_gq_rep_reportname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gq_rep_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                            }
                            break;
                        case "achmainsrengg_nui":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conhdnhdnrt_stcontrol.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_arguments":
                                    m_condspemgg_arg_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_arg_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contgdengg_argml_treegrd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qry_version.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_fld_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_query":
                                    m_congrdengg_gqqml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_reportdef":
                                    m_concmbengg_gq_rep_launchmode.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_concmbengg_gq_rep_oufrmt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contxtengg_gq_rep_reportname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gq_rep_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                            }
                            break;
                        case "achmainsrengg_ptr":
                            break;
                        case "achmainsrengg_rui":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_query":
                                    m_congrdengg_gqqml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                                case "tblengg_gq_reportdef":
                                    m_concmbengg_gq_rep_launchmode.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_concmbengg_gq_rep_oufrmt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contxtengg_gq_rep_reportname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gq_rep_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                            }
                            break;
                        case "achmainsrengggqlk":
                            break;
                        case "achtblen_enggfltr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qry_version.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_fld_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    break;
                            }
                            break;
                        case "achtblen_enggldui":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_json.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_schema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qry_version.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_fld_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    break;
                            }
                            break;
                        case "achtblen_enggqftr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_fields":
                                    m_conchkengg_gqfld_inclayoutctrls.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qry_version.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_fld_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gqfldml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    break;
                            }
                            break;
                        case "achtblengeng_gqtr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_isgql.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_reportdef":
                                    m_concmbengg_gq_rep_launchmode.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_concmbengg_gq_rep_oufrmt.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contxtengg_gq_rep_reportname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_congrdengg_gq_rep_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_reportdef");
                                    break;
                            }
                            break;
                        case "achtblengengg_vtr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_json.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_schema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_arguments":
                                    m_condspemgg_arg_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_arg_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contgdengg_argml_treegrd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    break;
                            }
                            break;
                        case "achtblengengg_yui":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_json.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conimgengg_gqpopup_schema.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_contxtversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_arguments":
                                    m_condspemgg_arg_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_arg_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_contgdengg_argml_treegrd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    break;
                            }
                            break;
                        case "achtblenqenggy_tr":
                            m_concmbengg_gqhdr_actdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_concmbengg_gqhdr_uidescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_actname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cmpname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_cust.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_ecrno.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prcname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_prodescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_proj.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_taskdescr.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_tasktype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_condspengg_gqhdr_uiname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            m_conlstengg_gqhdr_tskname.RenderAsXML(RenderType.renderModified, eltControlInfo);
                            switch (sTabName.ToLower())
                            {
                                case "tblengg_gq_arguments":
                                    m_condspemgg_arg_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_arg_qryversion.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_arg_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                                case "tblengg_gq_fields":
                                    m_condspengg_fld_qry_version.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryalias.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryhdnkeyfield.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qryseq.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_condspengg_fld_qrytype.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    m_conlstengg_fld_qry.RenderAsXML(RenderType.renderModified, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                                case "tblengg_gq_query":
                                    m_congrdengg_gqqml_grd.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    break;
                                default:
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_arguments");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_fields");
                                    this.AddDirtyTab(xmlDom, eltDTabs, "tblengg_gq_query");
                                    break;
                            }
                            break;
                        case "tskzoomfieldfldgrd":
                            break;
                        case "tskzoomqueryqrygrd":
                            break;
                        case "tskzoomreportrepgrd":
                            break;
                    }
                    base.GetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
                else
                {
                    this.ObsoleteGetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0022", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Add DirtyTab
        // </summary>
        // **************************************************************************
        // Function Name		:	AddDirtyTab
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Add DirtyTab
        // ***************************************************************************
        private void AddDirtyTab(XmlDocument xmlDom, XmlElement eltDTabs, string sTabName)
        {
            Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("AddDirtyTab(sTabName = \"{0}\")", sTabName), "de_task_gql");
            System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
            eltDTabs = xmlDom.SelectSingleNode("//dtabs") as XmlElement;
            if ((eltDTabs == null))
            {
                eltDTabs = xmlDom.CreateElement("dtabs");
                eltIlboInfo.AppendChild(eltDTabs);
            }
            System.Xml.XmlElement eltDTab = xmlDom.SelectSingleNode("//dtabs/t[@n='" + sTabName + "']") as XmlElement;
            if ((eltDTab == null))
            {
                eltDTab = xmlDom.CreateElement("t");
                eltDTab.SetAttribute("n", sTabName);
                eltDTabs.AppendChild(eltDTab);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	ObsoleteGetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        private void ObsoleteGetTaskData(string sTabName, string sTaskName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "de_task_gql");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0024", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the display URL based on the tab name
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDisplayURL
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the display URL based on the tab name
        // ***************************************************************************
        public override string GetDisplayURL(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDisplayURL(sTabName = \"{0}\")", sTabName), "de_task_gql");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            return "mnggqloperation_de_task_gql.htm";
                        }
                        else
                        {
                            if (iEDKEIExists)
                            {
                                return base.GetDisplayURL(sTabName);
                            }
                            else
                            {
                                throw new Exception("Invalid TabName");
                            }
                        }
                    case "tblengg_gq_arguments":
                        return "mnggqloperation_de_task_gql_tblengg_gq_arguments.htm";
                    case "tblengg_gq_fields":
                        return "mnggqloperation_de_task_gql_tblengg_gq_fields.htm";
                    case "tblengg_gq_query":
                        return "mnggqloperation_de_task_gql_tblengg_gq_query.htm";
                    case "tblengg_gq_reportdef":
                        return "mnggqloperation_de_task_gql_tblengg_gq_reportdef.htm";
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetDisplayURL(sTabName = \"{0}\")", sTabName), "ILBO0025", e.Message);
                throw new Exception(e.Message, e);
            }
            return "";
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	ExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool ExecuteService(string sServiceName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ExecuteService(sServiceName = \"{0}\")", sServiceName), "de_task_gql");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (sServiceName.ToLower())
                {
                    case "achgqlsractdes":
                        sTaskName = "achmainsrengg_rui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsractdes", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetSegmentContext("uidescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrargqry":
                        sTaskName = "achtblengengg_yui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrargqry", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrargsav":
                        sTaskName = "achtblengengg_vtr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrargsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrfet":
                        sTaskName = "achmainsrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfet", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("hdncustomer", FlowAttribute.flowInOut, "de_task_gql", "hdnhdncustomer", "hdnhdncustomer", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnproject", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnproject", "hdnhdnproject", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "de_task_gql", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_tskqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        ISExecutor.SetSegmentContext("plf_state_segment", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("hdnrt_stcontrol", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnrt_stcontrol", "hdnhdnrt_stcontrol", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrflddef":
                        sTaskName = "achtblen_enggqftr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrflddef", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrfldqry":
                        sTaskName = "achtblen_enggldui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfldqry", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrfldsav":
                        sTaskName = "achtblen_enggfltr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfldsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrfolimp":
                        sTaskName = "achgqlengg_otr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfolimp", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_tskqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrimpsch":
                        sTaskName = "achmainsrengg_ptr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrimpsch", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("qryml_seg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        ISExecutor.SetSegmentContext("schemasegment", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_version", FlowAttribute.flowIn, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnengg_gqpopup_jsondbc", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnengg_gqpopup_schemadbc", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrinctrl":
                        sTaskName = "achfieldengg_iui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrinctrl", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowIn, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowIn, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowIn, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowIn, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowIn, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrinit":
                        sTaskName = "achmainsrsrinit";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrinit", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetSegmentContext("actdescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetSegmentContext("argcvmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("laumodcbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetSegmentContext("oufrmtcbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetSegmentContext("protypmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetSegmentContext("qryttlmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetSegmentContext("uidescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrqrysav":
                        sTaskName = "achtblenqenggy_tr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrqrysav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrrepsav":
                        sTaskName = "achtblengeng_gqtr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrrepsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrsdl":
                        sTaskName = "achgqmainenggqllk";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrsdl", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_task_gql", "txaschema", "txaschema", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsrtsknam":
                        sTaskName = "achmainsrengg_nui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrtsknam", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_engg_e", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecaption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontrolbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontrolid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontroltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ledatatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lepagename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lesectionname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_leviewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("plf_state_segment", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("hdnrt_stcontrol", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnrt_stcontrol", "hdnhdnrt_stcontrol", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                    case "achgqlsruides":
                        sTaskName = "achmainsrengg_iui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsruides", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("argcvmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        if (iEDKEIExists)
                        {
                            bExecFlag = base.ExecuteService(ISExecutor, sServiceName);
                        }
                        else
                        {
                            bExecFlag = ISExecutor.ExecuteService();
                        }
                        return bExecFlag;
                }
                if (iEDKEIExists)
                {
                    return base.ExecuteService(null, sServiceName);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : ExecuteService(sServiceName = \"{0}\")", sServiceName), "ILBO0026", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	BeginExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override IAsyncResult BeginExecuteService(AsyncCallback cb, VWRequestState reqState)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("BeginExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_task_gql");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                bExecFlag = base.PreServiceProcess(reqState.ServiceName, reqState.ServiceName);
                switch (reqState.ServiceName.ToLower())
                {
                    case "achgqlsractdes":
                        sTaskName = "achmainsrengg_rui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsractdes", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetSegmentContext("uidescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrargqry":
                        sTaskName = "achtblengengg_yui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrargqry", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrargsav":
                        sTaskName = "achtblengengg_vtr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrargsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "tgdengg_argml_treegrd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrfet":
                        sTaskName = "achmainsrfth";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfet", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("hdncustomer", FlowAttribute.flowInOut, "de_task_gql", "hdnhdncustomer", "hdnhdncustomer", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnproject", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnproject", "hdnhdnproject", String.Empty);
                        ISExecutor.SetServiceDataSource("prj_hdn_ctrl", FlowAttribute.flowInOut, "de_task_gql", "hdnprj_hdn_ctrl", "hdnprj_hdn_ctrl", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_tskqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        ISExecutor.SetSegmentContext("plf_state_segment", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("hdnrt_stcontrol", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnrt_stcontrol", "hdnhdnrt_stcontrol", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrflddef":
                        sTaskName = "achtblen_enggqftr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrflddef", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrfldqry":
                        sTaskName = "achtblen_enggldui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfldqry", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrfldsav":
                        sTaskName = "achtblen_enggfltr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfldsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqfldml_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrfolimp":
                        sTaskName = "achgqlengg_otr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrfolimp", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_jsondbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schemadbc", FlowAttribute.flowInOut, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        ISExecutor.SetServiceDataSource("version", FlowAttribute.flowInOut, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_tskqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrimpsch":
                        sTaskName = "achmainsrengg_ptr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrimpsch", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("qryml_seg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqltsk_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qrycomp", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqtsk_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "uiengg_gqtsk_qry4", String.Empty);
                        ISExecutor.SetSegmentContext("schemasegment", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_json", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_json", "imgengg_gqpopup_json", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_schema", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_schema", "imgengg_gqpopup_schema", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqpopup_version", FlowAttribute.flowIn, "de_task_gql", "txtversion", "txtversion", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnengg_gqpopup_jsondbc", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_json", "hdnengg_gqpopup_jsondbc", String.Empty);
                        ISExecutor.SetServiceDataSource("hdnengg_gqpopup_schemadbc", FlowAttribute.flowIn, "de_task_gql", "imgengg_gqpopup_schema", "hdnengg_gqpopup_schemadbc", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrinctrl":
                        sTaskName = "achfieldengg_iui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrinctrl", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowIn, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowIn, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowIn, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowIn, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowIn, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowIn, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrinit":
                        sTaskName = "achmainsrsrinit";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrinit", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowIn, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetSegmentContext("actdescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetSegmentContext("argcvmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("laumodcbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetSegmentContext("oufrmtcbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetSegmentContext("protypmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetSegmentContext("qryttlmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetSegmentContext("uidescbseg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrqrysav":
                        sTaskName = "achtblenqenggy_tr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrqrysav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gqqml_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrrepsav":
                        sTaskName = "achtblengeng_gqtr";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrrepsav", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_isgql", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_isgql", "dspengg_gqhdr_isgql", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdml", "2", true, FlowAttribute.flowIn, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("modeflag", FlowAttribute.flowIn, "de_task_gql", "grdengg_gq_rep_grd", "modeflag", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrsdl":
                        sTaskName = "achgqmainenggqllk";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrsdl", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetServiceDataSource("schema", FlowAttribute.flowInOut, "de_task_gql", "txaschema", "txaschema", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsrtsknam":
                        sTaskName = "achmainsrengg_nui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsrtsknam", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("emgg_arg_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspemgg_arg_qrytype", "dspemgg_arg_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_arg_qry", "lstengg_arg_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryalias", "dspengg_arg_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryhdnkeyfield", "dspengg_arg_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryseq", "dspengg_arg_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_arg_qryversion", FlowAttribute.flowInOut, "de_task_gql", "dspengg_arg_qryversion", "dspengg_arg_qryversion", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry", FlowAttribute.flowInOut, "de_task_gql", "lstengg_fld_qry", "lstengg_fld_qry", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qry_version", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qry_version", "dspengg_fld_qry_version", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryalias", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryalias", "dspengg_fld_qryalias", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryhdnkeyfield", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryhdnkeyfield", "dspengg_fld_qryhdnkeyfield", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qryseq", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qryseq", "dspengg_fld_qryseq", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_fld_qrytype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_fld_qrytype", "dspengg_fld_qrytype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nex", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeexpand", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_nid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__nodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_argml_treegrd_pnid", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "__parentnodeid", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_arguments", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_datatype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_defvalue", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_field", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ismandatory", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_kind", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_oftype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_schmaname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_type", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "2", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gdfldml_fldalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_fldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_pagname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "13", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_parschmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_schmaname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "12", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "11", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_engg_e", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecaption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontrolbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontrolid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lecontroltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ledatatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lepagename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_lesectionname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_leviewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "uiengg_gqrep_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lfdqry", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_fld_qry", "uiengg_gqfld_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_lquery", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_garg_qrykeyfield", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryalias", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryname", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryseq", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qrytype", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqarg_qryversion", FlowAttribute.flowOut, "de_task_gql", "lstengg_arg_qry", "uiengg_gqarg_qry5", String.Empty);
                        ISExecutor.SetSegmentContext("plf_state_segment", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("hdnrt_stcontrol", FlowAttribute.flowInOut, "de_task_gql", "hdnhdnrt_stcontrol", "hdnhdnrt_stcontrol", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "6", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                    case "achgqlsruides":
                        sTaskName = "achmainsrengg_iui";
                        ISExecutor.SetExecutionContext("apiconsumerhub", "achgqlsruides", "mnggqloperation", "de_task_gql");
                        ISExecutor.SetSegmentContext("_hseg", "2", false, FlowAttribute.flowInOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_launchmode", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_launchmode", "cmbengg_gq_rep_launchmode", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_oufrmt", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gq_rep_oufrmt", "cmbengg_gq_rep_oufrmt", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_reportname", FlowAttribute.flowInOut, "de_task_gql", "txtengg_gq_rep_reportname", "txtengg_gq_rep_reportname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_inclayoutctrls", FlowAttribute.flowInOut, "de_task_gql", "chkengg_gqfld_inclayoutctrls", "chkengg_gqfld_inclayoutctrls", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actdescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_actdescr", "cmbengg_gqhdr_actdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_actname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_actname", "dspengg_gqhdr_actname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpdescr", "dspengg_gqhdr_cmpdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cmpname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cmpname", "dspengg_gqhdr_cmpname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_cust", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_cust", "dspengg_gqhdr_cust", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_ecrno", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_ecrno", "dspengg_gqhdr_ecrno", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prcname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prcname", "dspengg_gqhdr_prcname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_prodescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_prodescr", "dspengg_gqhdr_prodescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_proj", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_proj", "dspengg_gqhdr_proj", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskdescr", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_taskdescr", "dspengg_gqhdr_taskdescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tasktype", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_tasktype", "dspengg_gqhdr_tasktype", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskname", FlowAttribute.flowInOut, "de_task_gql", "lstengg_gqhdr_tskname", "lstengg_gqhdr_tskname", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uidescr", FlowAttribute.flowInOut, "de_task_gql", "cmbengg_gqhdr_uidescr", "cmbengg_gqhdr_uidescr", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_uiname", FlowAttribute.flowInOut, "de_task_gql", "dspengg_gqhdr_uiname", "dspengg_gqhdr_uiname", String.Empty);
                        ISExecutor.SetSegmentContext("argcvmlcbsg", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("argtgmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqargml_ctrlviewname", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqargml_protype", FlowAttribute.flowOut, "de_task_gql", "tgdengg_argml_treegrd", "13", String.Empty);
                        ISExecutor.SetSegmentContext("fldgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfldml_maptype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "17", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_btsyn", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqctrl_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrlid", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ctrltype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_pgename", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_secname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_viewname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gdfld_ctrlbtsyn6", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_fldnam", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gq_fieldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_datatype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_flattenedfldname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname5", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_ismandatoy", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqfld_type", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqfldml_grd", "uiengg_gqfld_fieldname2", String.Empty);
                        ISExecutor.SetSegmentContext("listedit_hdrtsk", "1", true, FlowAttribute.flowOut, true);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_taskname", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tskdescr", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqhdr_tsktype", FlowAttribute.flowOut, "de_task_gql", "lstengg_gqhdr_tskname", "uiengg_gqhdr_task3", String.Empty);
                        ISExecutor.SetSegmentContext("qrygrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gqlqml_qrytype", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "6", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "9", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_cache_ttl", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "10", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_hdnkeyfield", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "11", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryalias", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "1", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qrytext", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "8", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_qryversion", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "7", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gqqml_seqno", FlowAttribute.flowOut, "de_task_gql", "grdengg_gqqml_grd", "3", String.Empty);
                        ISExecutor.SetSegmentContext("repgrdmlout", "2", true, FlowAttribute.flowOut, false);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_caption", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "3", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_controlbtsyn", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "2", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_defvalue", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "4", String.Empty);
                        ISExecutor.SetServiceDataSource("engg_gq_rep_paramname", FlowAttribute.flowOut, "de_task_gql", "grdengg_gq_rep_grd", "1", String.Empty);
                        if (iEDKEIExists)
                        {
                            return base.BeginExecuteService(cb, reqState, ISExecutor);
                        }
                        return ISExecutor.BeginExecuteService(cb, reqState);
                }
                if (iEDKEIExists)
                {
                    return base.BeginExecuteService(cb, reqState, null);
                }
                throw new Exception("Invalid Service");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : BeginExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0027", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	EndExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected override bool EndExecuteService(IAsyncResult ar)
        {
            bool bExecFlag = true;
            VWRequestState reqState = ar.AsyncState as VWRequestState;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("EndExecuteService(ServiceName = \"{0}\")", reqState.ServiceName), "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                switch (reqState.ServiceName.ToLower())
                {
                    case "achgqlsractdes":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrargqry":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrargsav":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrfet":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrflddef":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrfldqry":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrfldsav":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrfolimp":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrimpsch":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrinctrl":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrinit":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrqrysav":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrrepsav":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrsdl":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsrtsknam":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    case "achgqlsruides":
                        bExecFlag = ISExecutor.EndExecuteService(ar);
                        break;
                    default:
                        if (iEDKEIExists)
                        {
                            return base.EndExecuteService(ar);
                        }
                        break;
                }
                if (bExecFlag)
                {
                    bExecFlag = base.PostServiceProcess(reqState.TaskName, reqState.ServiceName);
                }
                return bExecFlag;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : EndExecuteService(sServiceName = \"{0}\")", reqState.ServiceName), "ILBO0028", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes tab control
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes tab control
        // ***************************************************************************
        private new void InitializeTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeTabControls()", "de_task_gql");
                _mainpage.SetIdentity("mainpage");
                base.AddTabControl(_mainpage);
                _tblengg_gq_arguments.SetIdentity("tblengg_gq_arguments");
                base.AddTabControl(_tblengg_gq_arguments);
                _tblengg_gq_fields.SetIdentity("tblengg_gq_fields");
                base.AddTabControl(_tblengg_gq_fields);
                _tblengg_gq_query.SetIdentity("tblengg_gq_query");
                base.AddTabControl(_tblengg_gq_query);
                _tblengg_gq_reportdef.SetIdentity("tblengg_gq_reportdef");
                base.AddTabControl(_tblengg_gq_reportdef);
                if (iEDKEIExists)
                {
                    base.InitializeTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : InitializeTabControls()", "ILBO0029", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes Layout Controls
        // ***************************************************************************
        private new void InitializeLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeLayoutControls()", "de_task_gql");
                _btneng_gq_rep_save.SetIdentity("btneng_gq_rep_save");
                _tblengg_gq_reportdef.AddLayoutControl("btneng_gq_rep_save");
                _btnengg_fld_save.SetIdentity("btnengg_fld_save");
                _tblengg_gq_fields.AddLayoutControl("btnengg_fld_save");
                _btnengg_gqarg_save.SetIdentity("btnengg_gqarg_save");
                _tblengg_gq_arguments.AddLayoutControl("btnengg_gqarg_save");
                _btnengg_gqfld_defctrls.SetIdentity("btnengg_gqfld_defctrls");
                _tblengg_gq_fields.AddLayoutControl("btnengg_gqfld_defctrls");
                _btnengg_gqfollowup_import.SetIdentity("btnengg_gqfollowup_import");
                _mainpage.AddLayoutControl("btnengg_gqfollowup_import");
                _btnengg_gqpopup_upload.SetIdentity("btnengg_gqpopup_upload");
                _mainpage.AddLayoutControl("btnengg_gqpopup_upload");
                _btnengg_gqqry_save.SetIdentity("btnengg_gqqry_save");
                _tblengg_gq_query.AddLayoutControl("btnengg_gqqry_save");
                _lnkengg_gqhdr_upload.SetIdentity("lnkengg_gqhdr_upload");
                _mainpage.AddLayoutControl("lnkengg_gqhdr_upload");
                _lnkengg_gql_followuptask.SetIdentity("lnkengg_gql_followuptask");
                _mainpage.AddLayoutControl("lnkengg_gql_followuptask");
                _lnkengg_gql_schvisualizer.SetIdentity("lnkengg_gql_schvisualizer");
                _mainpage.AddLayoutControl("lnkengg_gql_schvisualizer");
                _lnkengg_gqllaunch_sdl.SetIdentity("lnkengg_gqllaunch_sdl");
                _mainpage.AddLayoutControl("lnkengg_gqllaunch_sdl");
                _lnkengg_gqllaunch_studio.SetIdentity("lnkengg_gqllaunch_studio");
                _mainpage.AddLayoutControl("lnkengg_gqllaunch_studio");
                _hdnrt_stsection.SetIdentity("hdnrt_stsection");
                _mainpage.AddLayoutControl("hdnrt_stsection");
                _popengg_gql_sdl_popup.SetIdentity("popengg_gql_sdl_popup");
                _mainpage.AddLayoutControl("popengg_gql_sdl_popup");
                _popengg_gqpopup_sec.SetIdentity("popengg_gqpopup_sec");
                _mainpage.AddLayoutControl("popengg_gqpopup_sec");
                _prjhdnsection.SetIdentity("prjhdnsection");
                _mainpage.AddLayoutControl("prjhdnsection");
                _secengg_argml_sec.SetIdentity("secengg_argml_sec");
                _tblengg_gq_arguments.AddLayoutControl("secengg_argml_sec");
                _secengg_gq_hdrsec.SetIdentity("secengg_gq_hdrsec");
                _mainpage.AddLayoutControl("secengg_gq_hdrsec");
                _secengg_gq_rep_ml.SetIdentity("secengg_gq_rep_ml");
                _tblengg_gq_reportdef.AddLayoutControl("secengg_gq_rep_ml");
                _secengg_gq_rep_savesec.SetIdentity("secengg_gq_rep_savesec");
                _tblengg_gq_reportdef.AddLayoutControl("secengg_gq_rep_savesec");
                _secengg_gq_rephdrsec.SetIdentity("secengg_gq_rephdrsec");
                _tblengg_gq_reportdef.AddLayoutControl("secengg_gq_rephdrsec");
                _secengg_gqarg_hdrse.SetIdentity("secengg_gqarg_hdrse");
                _tblengg_gq_arguments.AddLayoutControl("secengg_gqarg_hdrse");
                _secengg_gqarg_save_sec.SetIdentity("secengg_gqarg_save_sec");
                _tblengg_gq_arguments.AddLayoutControl("secengg_gqarg_save_sec");
                _secengg_gqfld_save_sec.SetIdentity("secengg_gqfld_save_sec");
                _tblengg_gq_fields.AddLayoutControl("secengg_gqfld_save_sec");
                _secengg_gqfldml_hdrsec.SetIdentity("secengg_gqfldml_hdrsec");
                _tblengg_gq_fields.AddLayoutControl("secengg_gqfldml_hdrsec");
                _secengg_gqfldml_sec.SetIdentity("secengg_gqfldml_sec");
                _tblengg_gq_fields.AddLayoutControl("secengg_gqfldml_sec");
                _secengg_gqlink_sec.SetIdentity("secengg_gqlink_sec");
                _mainpage.AddLayoutControl("secengg_gqlink_sec");
                _secengg_gqqml_sec.SetIdentity("secengg_gqqml_sec");
                _tblengg_gq_query.AddLayoutControl("secengg_gqqml_sec");
                _secengg_gqqry_save_sec.SetIdentity("secengg_gqqry_save_sec");
                _tblengg_gq_query.AddLayoutControl("secengg_gqqry_save_sec");
                _secengg_gqtab_sec.SetIdentity("secengg_gqtab_sec");
                _mainpage.AddLayoutControl("secengg_gqtab_sec");
                _tabcontrol.SetIdentity("tabcontrol");
                _mainpage.AddLayoutControl("tabcontrol");
                _tabitem_1661329961099_fr1c1.SetIdentity("tabitem_1661329961099_fr1c1");
                _tblengg_gq_query.AddLayoutControl("tabitem_1661329961099_fr1c1");
                if (iEDKEIExists)
                {
                    base.InitializeLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : InitializeLayoutControls()", "ILBO0030", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Tab Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetTabControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Tab Controls
        // ***************************************************************************
        public override void ResetTabControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetTabControls()", "de_task_gql");
                _mainpage.Clear();
                _tblengg_gq_arguments.Clear();
                _tblengg_gq_fields.Clear();
                _tblengg_gq_query.Clear();
                _tblengg_gq_reportdef.Clear();
                if (iEDKEIExists)
                {
                    base.ResetTabControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : ResetTabControls()", "ILBO0031", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetLayoutControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets Layout Controls
        // ***************************************************************************
        public override void ResetLayoutControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetLayoutControls()", "de_task_gql");
                _btneng_gq_rep_save.Clear();
                _btnengg_fld_save.Clear();
                _btnengg_gqarg_save.Clear();
                _btnengg_gqfld_defctrls.Clear();
                _btnengg_gqfollowup_import.Clear();
                _btnengg_gqpopup_upload.Clear();
                _btnengg_gqqry_save.Clear();
                _lnkengg_gqhdr_upload.Clear();
                _lnkengg_gql_followuptask.Clear();
                _lnkengg_gql_schvisualizer.Clear();
                _lnkengg_gqllaunch_sdl.Clear();
                _lnkengg_gqllaunch_studio.Clear();
                _hdnrt_stsection.Clear();
                _popengg_gql_sdl_popup.Clear();
                _popengg_gqpopup_sec.Clear();
                _prjhdnsection.Clear();
                _secengg_argml_sec.Clear();
                _secengg_gq_hdrsec.Clear();
                _secengg_gq_rep_ml.Clear();
                _secengg_gq_rep_savesec.Clear();
                _secengg_gq_rephdrsec.Clear();
                _secengg_gqarg_hdrse.Clear();
                _secengg_gqarg_save_sec.Clear();
                _secengg_gqfld_save_sec.Clear();
                _secengg_gqfldml_hdrsec.Clear();
                _secengg_gqfldml_sec.Clear();
                _secengg_gqlink_sec.Clear();
                _secengg_gqqml_sec.Clear();
                _secengg_gqqry_save_sec.Clear();
                _secengg_gqtab_sec.Clear();
                _tabcontrol.Clear();
                _tabitem_1661329961099_fr1c1.Clear();
                if (iEDKEIExists)
                {
                    base.ResetLayoutControls();
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("de_task_gql : ResetLayoutControls()", "ILBO0032", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method 
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTabControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	
        // ***************************************************************************
        public override ITabControl GetTabControl(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTabControl(sTabName = \"{0}\")", sTabName), "de_task_gql");
                switch (sTabName.ToLower())
                {
                    case "mainpage":
                    case "":
                        return this._mainpage;
                    case "tblengg_gq_arguments":
                        return this._tblengg_gq_arguments;
                    case "tblengg_gq_fields":
                        return this._tblengg_gq_fields;
                    case "tblengg_gq_query":
                        return this._tblengg_gq_query;
                    case "tblengg_gq_reportdef":
                        return this._tblengg_gq_reportdef;
                    default:
                        return base.GetTabControl(sTabName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetTabControl(sTabName= \"{0}\")", sTabName), "ILBO0033", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Get Layout Controls
        // </summary>
        // **************************************************************************
        // Function Name		:	GetLayoutControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Get Layout Controls
        // ***************************************************************************
        public override ILayoutControl GetLayoutControl(string sLayoutControlName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetLayoutControl(sLayoutControlName = \"{0}\")", sLayoutControlName), "de_task_gql");
                switch (sLayoutControlName)
                {
                    case "btneng_gq_rep_save":
                        return this._btneng_gq_rep_save;
                    case "btnengg_fld_save":
                        return this._btnengg_fld_save;
                    case "btnengg_gqarg_save":
                        return this._btnengg_gqarg_save;
                    case "btnengg_gqfld_defctrls":
                        return this._btnengg_gqfld_defctrls;
                    case "btnengg_gqfollowup_import":
                        return this._btnengg_gqfollowup_import;
                    case "btnengg_gqpopup_upload":
                        return this._btnengg_gqpopup_upload;
                    case "btnengg_gqqry_save":
                        return this._btnengg_gqqry_save;
                    case "lnkengg_gqhdr_upload":
                        return this._lnkengg_gqhdr_upload;
                    case "lnkengg_gql_followuptask":
                        return this._lnkengg_gql_followuptask;
                    case "lnkengg_gql_schvisualizer":
                        return this._lnkengg_gql_schvisualizer;
                    case "lnkengg_gqllaunch_sdl":
                        return this._lnkengg_gqllaunch_sdl;
                    case "lnkengg_gqllaunch_studio":
                        return this._lnkengg_gqllaunch_studio;
                    case "hdnrt_stsection":
                        return this._hdnrt_stsection;
                    case "popengg_gql_sdl_popup":
                        return this._popengg_gql_sdl_popup;
                    case "popengg_gqpopup_sec":
                        return this._popengg_gqpopup_sec;
                    case "prjhdnsection":
                        return this._prjhdnsection;
                    case "secengg_argml_sec":
                        return this._secengg_argml_sec;
                    case "secengg_gq_hdrsec":
                        return this._secengg_gq_hdrsec;
                    case "secengg_gq_rep_ml":
                        return this._secengg_gq_rep_ml;
                    case "secengg_gq_rep_savesec":
                        return this._secengg_gq_rep_savesec;
                    case "secengg_gq_rephdrsec":
                        return this._secengg_gq_rephdrsec;
                    case "secengg_gqarg_hdrse":
                        return this._secengg_gqarg_hdrse;
                    case "secengg_gqarg_save_sec":
                        return this._secengg_gqarg_save_sec;
                    case "secengg_gqfld_save_sec":
                        return this._secengg_gqfld_save_sec;
                    case "secengg_gqfldml_hdrsec":
                        return this._secengg_gqfldml_hdrsec;
                    case "secengg_gqfldml_sec":
                        return this._secengg_gqfldml_sec;
                    case "secengg_gqlink_sec":
                        return this._secengg_gqlink_sec;
                    case "secengg_gqqml_sec":
                        return this._secengg_gqqml_sec;
                    case "secengg_gqqry_save_sec":
                        return this._secengg_gqqry_save_sec;
                    case "secengg_gqtab_sec":
                        return this._secengg_gqtab_sec;
                    case "tabcontrol":
                        return this._tabcontrol;
                    case "tabitem_1661329961099_fr1c1":
                        return this._tabitem_1661329961099_fr1c1;
                    default:
                        return base.GetLayoutControl(sLayoutControlName);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetLayoutControl(sLayoutControlName= \"{0}\")", sLayoutControlName), "ILBO0034", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Updates the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	UpdateScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Updates the screen data
        // ***************************************************************************
        public override void UpdateScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_task_gql");
                base.UpdateScreenData(sTabName, nodeScreenInfo);
                return;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0035", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the screen data
        // ***************************************************************************
        public override void GetScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                IAuthorizedActivitiesAndOULists IAuthorizedInfo = ISManager.GetAuthorizedInfoObject();
                XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                System.Xml.XmlElement eltTask;
                System.Xml.XmlElement eltControlInfo;
                System.Xml.XmlElement eltLayoutControlInfo;
                System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                if ((eltIlboInfo == null))
                {
                    eltIlboInfo = xmlDom.CreateElement("ii");
                    nodeScreenInfo.AppendChild(eltIlboInfo);
                    eltIlboInfo.SetAttribute("dst", "1");
                    ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "0");
                    if ((sTabName == String.Empty))
                    {
                        eltIlboInfo.SetAttribute("at", (String)GetContextValue("ICT_ACTIVE_TAB"));
                        if ((((String)ISMContext.GetContextValue("SCT_LASTTASK_TYPE") == "HELP")
                                    && (GetContextValue("ICT_PARENTILBO") != null)))
                        {
                            if ((ISMContext.GetContextValue("ICT_HELPTASK_TYPE") == null))
                            {
                                this.SetContextValue("ICT_HELPTASK_TYPE", ISMContext.GetContextValue("SCT_LASTTASK_TYPE"));
                            }
                        }
                        if (((String)GetContextValue("ICT_HELPTASK_TYPE") == "HELP"))
                        {
                            eltIlboInfo.SetAttribute("ttype", "HELP");
                            ISMContext.SetContextValue("SCT_LASTTASK_TYPE", "");
                        }
                        else
                        {
                            this.SetContextValue("ICT_HELPTASK_TYPE", "NOTHELP");
                            eltIlboInfo.SetAttribute("ttype", "NOTHELP");
                        }
                    }
                    System.Xml.XmlElement eltDsTaskInfo = nodeScreenInfo.OwnerDocument.CreateElement("dti");
                    nodeScreenInfo.AppendChild(eltDsTaskInfo);
                    if ((IAuthorizedInfo.IsNavigationAuthorized("mnggqloperation", "de_il_error") == false))
                    {
                        eltTask = xmlDom.CreateElement("t");
                        eltTask.SetAttribute("n", "achgqlengg__lk");
                        eltDsTaskInfo.AppendChild(eltTask);
                    }
                    eltControlInfo = base.GetControlInfoElement(xmlDom, nodeScreenInfo);
                    eltLayoutControlInfo = base.GetLayoutControlInfoElement(xmlDom, nodeScreenInfo);
                }
                else
                {
                    eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                }
                base.GetScreenData(sTabName, nodeScreenInfo);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("de_task_gql : GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0036", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("de_task_gql : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage), "de_task_gql");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, e.Message, String.Format("de_task_gql : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage));
            }
        }
    }
}

