/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   zachqueryqrygrd.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Activity Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace mnggqloperation
{
    using System;
    using System.Web;
    using System.Xml;
    using System.Collections;
    using System.Diagnostics;
    using Ramco.VW.RT.Web.Core;
    using Ramco.VW.RT.Web.Controls;

    // <summary>
    // This class defines all the methods of zachqueryqrygrd class
    // </summary>
    [Serializable()]
    public class zachqueryqrygrd : IILBO
    {
        private System.Collections.Hashtable htContextItems = new System.Collections.Hashtable();
        private Edit m_conc1 = new Edit();
        private Combo m_conc10 = new Combo();
        private Edit m_conc11 = new Edit();
        private Edit m_conc2 = new Edit();
        private Edit m_conc3 = new Edit();
        private Edit m_conc6 = new Edit();
        private Edit m_conc7 = new Edit();
        private Edit m_conc8 = new Edit();
        private Check m_conc9 = new Check();
        private Edit m_conrvwrt_cctxt_component = new Edit();
        private Edit m_conrvwrt_cctxt_ou = new Edit();
        private Edit m_conrvwrt_lctxt_ou = new Edit();
        // <summary>
        // This method Calls the AddViewInfo and InitializeControls
        // </summary>
        // **************************************************************************
        // Function Name		:	zachqueryqrygrd
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Calls the AddViewInfo and InitializeControls
        // ***************************************************************************
        public zachqueryqrygrd()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "zachqueryqrygrd()", "zachqueryqrygrd");
                this.SetContextValue("ICT_COMPONENTNAME", "apiconsumerhub");
                this.SetContextValue("ICT_COMPONENTDESCRIPTION", "API Consumer HUB");
                this.SetContextValue("ICT_ACTIVITYNAME", "mnggqloperation");
                this.SetContextValue("ICT_ACTIVITYDESCRIPTION", "Manage GQL Operations");
                this.SetContextValue("ICT_ILBOCODE", "zachqueryqrygrd");
                this.SetContextValue("ICT_ILBODESCRIPTION", "Transposed View of Manage GQL Operations");
                this.AddViewInfo();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, "zachqueryqrygrd()", "zachqueryqrygrd");
                throw new System.Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initializes the controls of Enumerated datatype.
        // </summary>
        // **************************************************************************
        // Function Name		:	InitializeControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initializes the controls of Enumerated datatype.
        // ***************************************************************************
        private new void InitializeControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "InitializeControls()", "zachqueryqrygrd");
                m_conc1.SetIdentity("c1", ControlType.RSEdit);
                m_conc10.SetIdentity("c10", ControlType.RSCombo);
                m_conc11.SetIdentity("c11", ControlType.RSDisplayOnly);
                m_conc2.SetIdentity("c2", ControlType.RSEdit);
                m_conc3.SetIdentity("c3", ControlType.RSEdit);
                m_conc6.SetIdentity("c6", ControlType.RSDisplayOnly);
                m_conc7.SetIdentity("c7", ControlType.RSDisplayOnly);
                m_conc8.SetIdentity("c8", ControlType.RSDisplayOnly);
                m_conc9.SetIdentity("c9", ControlType.RSCheck);
                m_conc9.SetContextValue("CCT_ON_STATE_VALUE", "1");
                m_conc9.SetContextValue("CCT_OFF_STATE_VALUE", "0");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : InitializeControls()", "ILBO0001", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Resets all the controls of the ILBO
        // </summary>
        // **************************************************************************
        // Function Name		:	ResetControls
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Resets all the controls of the ILBO
        // ***************************************************************************
        public void ResetControls()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "ResetControls()", "zachqueryqrygrd");
                m_conc1.ClearAll();
                m_conc10.ClearAll();
                m_conc11.ClearAll();
                m_conc2.ClearAll();
                m_conc3.ClearAll();
                m_conc6.ClearAll();
                m_conc7.ClearAll();
                m_conc8.ClearAll();
                m_conc9.ClearAll();
                this.InitializeControls();
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : ResetControls()", "ILBO0002", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method adds view information to the controls.
        // </summary>
        // **************************************************************************
        // Function Name		:	AddViewInfo
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	adds view information to the controls.
        // ***************************************************************************
        private new void AddViewInfo()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "AddViewInfo()", "zachqueryqrygrd");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IContext ISMContext = ISManager.GetContextObject();
                m_conc1.AddView("v1", true, "char", String.Empty, String.Empty);
                m_conc10.AddView("v10", true, "char", String.Empty, String.Empty);
                m_conc11.AddView("v11", true, "char", String.Empty, String.Empty);
                m_conc2.AddView("v2", true, "char", String.Empty, String.Empty);
                m_conc3.AddView("v3", true, "integer", String.Empty, String.Empty);
                m_conc6.AddView("v6", true, "char", String.Empty, String.Empty);
                m_conc7.AddView("v7", true, "char", String.Empty, String.Empty);
                m_conc8.AddView("v8", true, "char", String.Empty, String.Empty);
                m_conc9.AddView("v9", true, "integer", String.Empty, String.Empty);
                m_conrvwrt_lctxt_ou.AddView("rvwrt_lctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_ou.AddView("rvwrt_cctxt_ou", false, "char", String.Empty, String.Empty);
                m_conrvwrt_cctxt_component.AddView("rvwrt_cctxt_component", false, "char", String.Empty, String.Empty);
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : AddViewInfo()", "ILBO0003", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method creates/gets the Object Handle of the Control
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControlX
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	creates/gets the Object Handle of the Control
        // ***************************************************************************
        public IControl GetControlX(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControlX(sControlID = \"{0}\")", sControlID), "zachqueryqrygrd");
                switch (sControlID.ToLower())
                {
                    case "c1":
                        return this.m_conc1;
                    case "c10":
                        return this.m_conc10;
                    case "c11":
                        return this.m_conc11;
                    case "c2":
                        return this.m_conc2;
                    case "c3":
                        return this.m_conc3;
                    case "c6":
                        return this.m_conc6;
                    case "c7":
                        return this.m_conc7;
                    case "c8":
                        return this.m_conc8;
                    case "c9":
                        return this.m_conc9;
                    case "rvwrt_cctxt_component":
                        return this.m_conrvwrt_cctxt_component;
                    case "rvwrt_cctxt_ou":
                        return this.m_conrvwrt_cctxt_ou;
                    case "rvwrt_lctxt_ou":
                        return this.m_conrvwrt_lctxt_ou;
                    default:
                        return null;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetControlX(sControlID = \"{0}\")", sControlID), "ILBO0004", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetControl
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public IControl GetControl(string sControlID)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetControl(sControlID = \"{0}\")", sControlID), "zachqueryqrygrd");
                IControl control = this.GetControlX(sControlID);
                if ((control != null))
                {
                    return control;
                }
                else
                {
                    throw new Exception("String.Format(\"Invalid ControlID - {0}\", sControlID)");
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetControl(sControlID = \"{0}\")", sControlID), "ILBO0005", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem
        // ***************************************************************************
        public string GetDataItem(string sLinkID, string sDataItemName, long nInstance)
        {
            string sRetData = String.Empty;
            bool bFlag = false;
            long lSelectedRowIndex = 0;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "zachqueryqrygrd");
                switch (sLinkID)
                {
                    case "12595":
                        if ((sDataItemName == "d1"))
                        {
                            return m_conc1.GetControlValue("v1");
                        }
                        if ((sDataItemName == "d10"))
                        {
                            return m_conc10.GetControlValue("v10");
                        }
                        if ((sDataItemName == "d11"))
                        {
                            return m_conc11.GetControlValue("v11");
                        }
                        if ((sDataItemName == "d2"))
                        {
                            return m_conc2.GetControlValue("v2");
                        }
                        if ((sDataItemName == "d3"))
                        {
                            return m_conc3.GetControlValue("v3");
                        }
                        if ((sDataItemName == "d6"))
                        {
                            return m_conc6.GetControlValue("v6");
                        }
                        if ((sDataItemName == "d7"))
                        {
                            return m_conc7.GetControlValue("v7");
                        }
                        if ((sDataItemName == "d8"))
                        {
                            return m_conc8.GetControlValue("v8");
                        }
                        if ((sDataItemName == "d9"))
                        {
                            return m_conc9.GetControlValue("v9");
                        }
                        break;
                    default:
                        break;
                }
                if (!bFlag)
                {
                    Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "Invalid Link ID.", "zachqueryqrygrd");
                }
                return sRetData;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\"), nInstance = \"{2}\")", sLinkID, sDataItemName, nInstance.ToString()), "ILBO0006", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method gets the dataItem Instances.
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDataItemInstances
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	gets the dataItem Instances.
        // ***************************************************************************
        public long GetDataItemInstances(string sLinkID, string sDataItemName)
        {
            long sRetData = 0;
            bool bFlag = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "zachqueryqrygrd");
                switch (sLinkID)
                {
                    case "12595":
                        if ((sDataItemName == "d1"))
                        {
                            return m_conc1.GetNumInstances();
                        }
                        if ((sDataItemName == "d10"))
                        {
                            return m_conc10.GetNumInstances();
                        }
                        if ((sDataItemName == "d11"))
                        {
                            return m_conc11.GetNumInstances();
                        }
                        if ((sDataItemName == "d2"))
                        {
                            return m_conc2.GetNumInstances();
                        }
                        if ((sDataItemName == "d3"))
                        {
                            return m_conc3.GetNumInstances();
                        }
                        if ((sDataItemName == "d6"))
                        {
                            return m_conc6.GetNumInstances();
                        }
                        if ((sDataItemName == "d7"))
                        {
                            return m_conc7.GetNumInstances();
                        }
                        if ((sDataItemName == "d8"))
                        {
                            return m_conc8.GetNumInstances();
                        }
                        if ((sDataItemName == "d9"))
                        {
                            return m_conc9.GetNumInstances();
                        }
                        break;
                    default:
                        break;
                }
                if (!bFlag)
                {
                    Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "Invalid Link ID.", "zachqueryqrygrd");
                }
                return sRetData;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetDataItemInstances(sLinkID = \"{0}\", sDataItemName = \"{1}\")", sLinkID, sDataItemName), "ILBO0007", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method sets the DataItem
        // </summary>
        // **************************************************************************
        // Function Name		:	SetDataItem
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	sets the DataItem
        // ***************************************************************************
        public void SetDataItem(string sLinkID, string sDataItemName, long nInstance, string sValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\",nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance, sValue), "zachqueryqrygrd");
                bool bFlag = false;
                switch (sLinkID)
                {
                    case "12595":
                        if ((sDataItemName == "d1"))
                        {
                            m_conc1.SetControlValue("v1", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d10"))
                        {
                            m_conc10.SetControlValue("v10", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d11"))
                        {
                            m_conc11.SetControlValue("v11", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d2"))
                        {
                            m_conc2.SetControlValue("v2", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d3"))
                        {
                            m_conc3.SetControlValue("v3", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d6"))
                        {
                            m_conc6.SetControlValue("v6", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d7"))
                        {
                            m_conc7.SetControlValue("v7", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d8"))
                        {
                            m_conc8.SetControlValue("v8", sValue, 0);
                            return;
                        }
                        if ((sDataItemName == "d9"))
                        {
                            m_conc9.SetControlValue("v9", sValue, 0);
                            return;
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : SetDataItem(sLinkID = \"{0}\", sDataItemName = \"{1}\", nInstance = \"{2}\", sValue = \"{3}\")", sLinkID, sDataItemName, nInstance.ToString(), sValue.ToString()), "ILBO0008", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the GlobalVariable handle
        // </summary>
        // **************************************************************************
        // Function Name		:	GetVariable
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the GlobalVariable handle
        // ***************************************************************************
        public IGlobalVariable GetVariable(string sVariable)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetVariable(sVariable = \"{0}\")", sVariable), "zachqueryqrygrd");
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetVariable(sVariable = \"{0}\")", sVariable), "ILBO0009", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Executes User defined tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PerformTask
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Executes User defined tasks
        // ***************************************************************************
        public bool PerformTask(string sControlID, string sEventName, string sEventDetails, out string sTargetURL)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "zachqueryqrygrd");
                long lSubscriptionID = 0;
                bool bServiceResult = false;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IScreenObjectLauncher IHandler = ISManager.GetScreenObjectLauncher();
                IMessage IMsg = ISManager.GetMessageObject();
                IContext ISMContext = ISManager.GetContextObject();
                IReportManager IRptManager = ISManager.GetReportManager();
                sTargetURL = string.Empty;
                switch (sEventName.ToLower())
                {
                    default:
                        break;
                }
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : PerformTask(sControlID = \"{0}\", sEventName = \"{1}\", sEventDetails = \"{2}\")", sControlID, sEventName, sEventDetails), "ILBO0010", e.Message);
                throw new Exception(e.Message, e);
                return false;
            }
        }
        // <summary>
        // This method Updates the screen data
        // </summary>
        // **************************************************************************
        // Function Name		:	UpdateScreenData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Updates the screen data
        // ***************************************************************************
        public void UpdateScreenData(string sTabName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "zachqueryqrygrd");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == String.Empty))
                        {
                            this.SetContextValue("ICT_FOCUSCONTROL", nodeScreenInfo.Attributes["fc"].Value);
                            this.SetContextValue("ICT_ILBOHSP", nodeScreenInfo.Attributes["ihsp"].Value);
                            this.SetContextValue("ICT_ILBOVSP", nodeScreenInfo.Attributes["ivsp"].Value);
                        }
                        else
                        {
                            throw new Exception("Invalid TabName");
                        }
                        break;
                }
                System.Xml.XmlNode nodeControlInfo = nodeScreenInfo.ChildNodes[0];
                for (int iControlCount = 1; (iControlCount <= nodeControlInfo.ChildNodes.Count); iControlCount = (iControlCount + 1))
                {
                    System.Xml.XmlNode nodeControl = nodeControlInfo.ChildNodes[iControlCount];
                    switch (nodeControl.Attributes["n"].Value)
                    {
                        case "c1":
                            this.m_conc1.UpdateControlData(nodeControl);
                            break;
                        case "c10":
                            this.m_conc10.UpdateControlData(nodeControl);
                            break;
                        case "c11":
                            this.m_conc11.UpdateControlData(nodeControl);
                            break;
                        case "c2":
                            this.m_conc2.UpdateControlData(nodeControl);
                            break;
                        case "c3":
                            this.m_conc3.UpdateControlData(nodeControl);
                            break;
                        case "c6":
                            this.m_conc6.UpdateControlData(nodeControl);
                            break;
                        case "c7":
                            this.m_conc7.UpdateControlData(nodeControl);
                            break;
                        case "c8":
                            this.m_conc8.UpdateControlData(nodeControl);
                            break;
                        case "c9":
                            this.m_conc9.UpdateControlData(nodeControl);
                            break;
                        default:
                            throw new Exception("Invalid ControlID");
                    }
                }
                return;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : UpdateScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "ILBO0035", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method initializes Scripts for Data Transfer
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess1
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	initializes Scripts for Data Transfer
        // ***************************************************************************
        public bool PreProcess1()
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess1", "zachqueryqrygrd");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                IObjectBroker IobjBroker = ISManager.GetObjectBroker();
                string sParentActivity = (String)GetContextValue("ICT_PARENTACTIVITY");
                string sParentILBO = (String)GetContextValue("ICT_PARENTILBO");
                string sParentControlID = (String)GetContextValue("ICT_PARENTCONTROL");
                string sValue = String.Empty;
                Multiline oMultilineControl;
                long lListItems;
                long lLoop;
                if ((sParentControlID == null))
                {
                    sParentControlID = (String)GetContextValue("ICT_GRID_CONTROL");
                }
                IILBO IilboHandle = IobjBroker.GetScreenObject(sParentActivity, sParentILBO);
                oMultilineControl = (Multiline)IilboHandle.GetControl(sParentControlID);
                lListItems = oMultilineControl.GetNumberOfListItems("10");
                for (lLoop = 1; (lLoop <= lListItems); lLoop = (lLoop + 1))
                {
                    sValue = oMultilineControl.GetListItemValue("10", lLoop);
                    m_conc10.AddListItem("v10", lLoop, sValue);
                }
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "zachqueryqrygrd");
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : PreProcess1()", "ILBO0013", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Init tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess2
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Init tasks
        // ***************************************************************************
        public bool PreProcess2()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess2", "zachqueryqrygrd");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IDataBroker IDBroker = ISManager.GetDataBroker();
                // No Initialization Tasks are defined for the ILBO.
                IDBroker.Transfer(TransferDirection.transferIn, "mnggqloperation", "zachqueryqrygrd");
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : PreProcess2()", "ILBO0014 ", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Initiates Fetch tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	PreProcess3
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Initiates Fetch tasks
        // ***************************************************************************
        public bool PreProcess3()
        {
            bool bReturn = false;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, "PreProcess3()", "zachqueryqrygrd");
                // No Fetch Tasks are defined for the ILBO.
                bReturn = true;
                return bReturn;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject("zachqueryqrygrd : PreProcess3()", "ILBO0017", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Context Value
        // </summary>
        // **************************************************************************
        // Function Name		:	GetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Context Value
        // ***************************************************************************
        public object GetContextValue(string sContextName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetContextValue(sContextName = \"{0}\")", sContextName), "zachqueryqrygrd");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    return htContextItems[sContextName];
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    return m_conrvwrt_cctxt_component.GetControlValue("rvwrt_cctxt_component");
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    return m_conrvwrt_cctxt_ou.GetControlValue("rvwrt_cctxt_ou");
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    return m_conrvwrt_lctxt_ou.GetControlValue("rvwrt_lctxt_ou");
                }
                return null;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetContextValue(sContextName = \"{0}\")", sContextName), "ILBO0020", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Adds/Sets the Context Value to the collection based on the contextname
        // </summary>
        // **************************************************************************
        // Function Name		:	SetContextValue
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Adds/Sets the Context Value to the collection based on the contextname
        // ***************************************************************************
        public void SetContextValue(string sContextName, object sContextValue)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "zachqueryqrygrd");
                if ((((sContextName != "ICT_PARENTOU")
                            && (sContextName != "ICT_PARENTCOMPONENT"))
                            && (sContextName != "ICT_LAUNCHINGOU")))
                {
                    htContextItems[sContextName] = sContextValue;
                }
                if ((sContextName == "ICT_PARENTCOMPONENT"))
                {
                    m_conrvwrt_cctxt_component.SetControlValue("rvwrt_cctxt_component", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_PARENTOU"))
                {
                    m_conrvwrt_cctxt_ou.SetControlValue("rvwrt_cctxt_ou", (string)sContextValue);
                    return;
                }
                if ((sContextName == "ICT_LAUNCHINGOU"))
                {
                    m_conrvwrt_lctxt_ou.SetControlValue("rvwrt_lctxt_ou", (string)sContextValue);
                    return;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : SetContextValue(sContextName = \"{0}\", sContextValue = \"{1}\")", sContextName, sContextValue), "ILBO0021", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	GetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        public void GetTaskData(string sTabName, string sTaskName, System.Xml.XmlNode nodeScreenInfo)
        {
            string sOutMTD = string.Empty;
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "zachqueryqrygrd");
                if ((string.CompareOrdinal(GetContextValue("ICT_INLINE_TAB") as String, "1") == 0))
                {
                    ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                    IContext ISMContext = ISManager.GetContextObject();
                    IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                    System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                    System.Xml.XmlElement eltContextName;
                    System.Xml.XmlElement eltIlboInfo = null;
                    System.Xml.XmlElement eltDTabs = null;
                    System.Xml.XmlElement eltControlInfo = null;
                    // Form control information
                    if ((xmlDom.SelectSingleNode("trpi/scri/ci") == null))
                    {
                        eltControlInfo = xmlDom.CreateElement("ci");
                        nodeScreenInfo.AppendChild(eltControlInfo);
                    }
                    else
                    {
                        eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                    }
                    if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                    {
                        eltIlboInfo = xmlDom.CreateElement("ii");
                        nodeScreenInfo.AppendChild(eltIlboInfo);
                    }
                    else
                    {
                        eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    }
                }
                else
                {
                    this.ObsoleteGetTaskData(sTabName, sTaskName, nodeScreenInfo);
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0022", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Add DirtyTab
        // </summary>
        // **************************************************************************
        // Function Name		:	AddDirtyTab
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Add DirtyTab
        // ***************************************************************************
        private void AddDirtyTab(XmlDocument xmlDom, XmlElement eltDTabs, string sTabName)
        {
            Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("AddDirtyTab(sTabName = \"{0}\")", sTabName), "zachqueryqrygrd");
            System.Xml.XmlElement eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
            eltDTabs = xmlDom.SelectSingleNode("//dtabs") as XmlElement;
            if ((eltDTabs == null))
            {
                eltDTabs = xmlDom.CreateElement("dtabs");
                eltIlboInfo.AppendChild(eltDTabs);
            }
            System.Xml.XmlElement eltDTab = xmlDom.SelectSingleNode("//dtabs/t[@n='" + sTabName + "']") as XmlElement;
            if ((eltDTab == null))
            {
                eltDTab = xmlDom.CreateElement("t");
                eltDTab.SetAttribute("n", sTabName);
                eltDTabs.AppendChild(eltDTab);
            }
        }
        // <summary>
        // This method Gets the Task specific data
        // </summary>
        // **************************************************************************
        // Function Name		:	ObsoleteGetTaskData
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the Task specific data
        // ***************************************************************************
        private void ObsoleteGetTaskData(string sTabName, string sTaskName, XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "zachqueryqrygrd");
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : ObsoleteGetTaskData(sTabName = \"{0}\", sTaskName = \"{1}\", nodeScreenInfo = \"{2}\")", sTabName, sTaskName, nodeScreenInfo.OuterXml), "ILBO0024", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Gets the display URL based on the tab name
        // </summary>
        // **************************************************************************
        // Function Name		:	GetDisplayURL
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Gets the display URL based on the tab name
        // ***************************************************************************
        public string GetDisplayURL(string sTabName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetDisplayURL(sTabName = \"{0}\")", sTabName), "zachqueryqrygrd");
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            return "mnggqloperation_zachqueryqrygrd.htm";
                        }
                        else
                        {
                            throw new Exception("Invalid TabName");
                        }
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : GetDisplayURL(sTabName = \"{0}\")", sTabName), "ILBO0025", e.Message);
                throw new Exception(e.Message, e);
            }
            return "";
        }
        // <summary>
        // This method executes services for Init, Fetch, Trans and Submit tasks
        // </summary>
        // **************************************************************************
        // Function Name		:	ExecuteService
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	executes services for Init, Fetch, Trans and Submit tasks
        // ***************************************************************************
        protected bool ExecuteService(string sServiceName)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("ExecuteService(sServiceName = \"{0}\")", sServiceName), "zachqueryqrygrd");
                string sOutMTD = null;
                string sTaskName = String.Empty;
                bool bExecFlag = true;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IServiceExecutor ISExecutor = ISManager.GetServiceExecutor();
                return true;
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(String.Format("zachqueryqrygrd : ExecuteService(sServiceName = \"{0}\")", sServiceName), "ILBO0026", e.Message);
                throw new Exception(e.Message, e);
            }
        }
        public void GetScreenData(string sTabName, System.Xml.XmlNode nodeScreenInfo)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("GetScreenData(sTabName = \"{0}\", nodeScreenInfo = \"{1}\")", sTabName, nodeScreenInfo.OuterXml), "zachqueryqrygrd");
                System.Xml.XmlDocument xmlDom = nodeScreenInfo.OwnerDocument;
                System.Xml.XmlElement eltIlboInfo;
                System.Xml.XmlElement eltDsTaskInfo;
                System.Xml.XmlElement eltControlInfo;
                System.Xml.XmlElement eltTask;
                IContext ISMContext;
                IAuthorizedActivitiesAndOULists IAuthorizedInfo;
                IObjectBroker IobjBroker;
                IILBO IilboHandle;
                Multiline oMultilineControl;
                string sParentActivity;
                string sParentILBO;
                string sParentControlID;
                long lTotalRows;
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                ISMContext = ISManager.GetContextObject();
                IAuthorizedInfo = ISManager.GetAuthorizedInfoObject();
                if ((xmlDom.SelectSingleNode("trpi/scri/ii") == null))
                {
                    IobjBroker = ISManager.GetObjectBroker();
                    sParentActivity = (string)GetContextValue("ICT_PARENTACTIVITY");
                    sParentILBO = (string)GetContextValue("ICT_PARENTILBO");
                    if ((this.GetContextValue("ICT_GRID_CONTROL") == null))
                    {
                        sParentControlID = (string)GetContextValue("ICT_PARENTCONTROL");
                        this.SetContextValue("ICT_GRID_CONTROL", sParentControlID);
                    }
                    IilboHandle = IobjBroker.GetScreenObject(sParentActivity, sParentILBO);
                    oMultilineControl = (Multiline)IilboHandle.GetControl((string)GetContextValue("ICT_GRID_CONTROL"));
                    lTotalRows = oMultilineControl.GetNumInstances();
                    // Form ILBO Information
                    eltIlboInfo = xmlDom.CreateElement("ii");
                    nodeScreenInfo.AppendChild(eltIlboInfo);
                    eltIlboInfo.SetAttribute("dst", "0");
                    ISMContext.SetContextValue("SCT_SETPAGE_STATUS", "0");
                    if ((sTabName == string.Empty))
                    {
                        eltIlboInfo.SetAttribute("at", (string)GetContextValue("ICT_ACTIVE_TAB"));
                        if ((((string)ISMContext.GetContextValue("SCT_LASTTASK_TYPE") == "HELP")
                                    && (this.GetContextValue("ICT_PARENTILBO") != null)))
                        {
                            if ((ISMContext.GetContextValue("ICT_HELPTASK_TYPE") == null))
                            {
                                this.SetContextValue("ICT_HELPTASK_TYPE", ISMContext.GetContextValue("SCT_LASTTASK_TYPE"));
                            }
                        }
                        if (((string)GetContextValue("ICT_HELPTASK_TYPE") == "HELP"))
                        {
                            eltIlboInfo.SetAttribute("ttype", "HELP");
                            ISMContext.SetContextValue("SCT_LASTTASK_TYPE", string.Empty);
                        }
                        else
                        {
                            this.SetContextValue("ICT_HELPTASK_TYPE", "NOTHELP");
                            eltIlboInfo.SetAttribute("ttype", "NOTHELP");
                        }
                        eltIlboInfo.SetAttribute("cr", (string)(oMultilineControl.GetContextValue("CCT_CURRENTROW")));
                        eltIlboInfo.SetAttribute("tr", lTotalRows.ToString());
                    }
                    // Form disabled task info
                    eltDsTaskInfo = xmlDom.CreateElement("dti");
                    nodeScreenInfo.AppendChild(eltDsTaskInfo);
                    // Form control information
                    if ((xmlDom.SelectSingleNode("trpi/scri/ci") == null))
                    {
                        eltControlInfo = xmlDom.CreateElement("ci");
                        nodeScreenInfo.AppendChild(eltControlInfo);
                    }
                    else
                    {
                        eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                    }
                }
                else
                {
                    eltIlboInfo = xmlDom.SelectSingleNode("trpi/scri/ii") as XmlElement;
                    eltControlInfo = xmlDom.SelectSingleNode("trpi/scri/ci") as XmlElement;
                }
                switch (sTabName.ToLower())
                {
                    default:
                        if ((sTabName == string.Empty))
                        {
                            eltIlboInfo.SetAttribute("fc", (string)GetContextValue("ICT_FOCUSCONTROL"));
                            eltIlboInfo.SetAttribute("ihsp", (string)GetContextValue("ICT_ILBOHSP"));
                            this.SetContextValue("ICT_ILBOHSP", "0");
                            eltIlboInfo.SetAttribute("ivsp", (string)GetContextValue("ICT_ILBOVSP"));
                            this.SetContextValue("ICT_ILBOVSP", "0");
                            m_conc1.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc10.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc11.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc2.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc3.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc6.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc7.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc8.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            m_conc9.RenderAsXML(RenderType.renderComplete, eltControlInfo);
                            try
                            {
                            }
                            catch (System.Exception stEx)
                            {
                                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, stEx.Message, "zachqueryqrygrd : GetScreenData");
                            }
                        }
                        else
                        {
                            throw new Exception("Invalid TabName");
                        }
                        break;
                }
            }
            catch (System.Exception e)
            {
                this.FillMessageObject(string.Format("zsta_whcap_ : GetScreenData(sTabName = {0}, nodeScreenInfo = {1}", sTabName, nodeScreenInfo.OuterXml), "ILBO0016", e.Message);
                throw new System.Exception(e.Message, e);
            }
        }
        // <summary>
        // This method Fills the Message object when an error occurs
        // </summary>
        // **************************************************************************
        // Function Name		:	FillMessageObject
        // Author				:	ILDotNetCodeGenerator
        // Date					:	06-12-2022
        // Description			:	Fills the Message object when an error occurs
        // ***************************************************************************
        private void FillMessageObject(string sMethod, string sErrNumber, string sErrMessage)
        {
            try
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceInfo, String.Format("zachqueryqrygrd : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage), "zachqueryqrygrd");
                ISessionManager ISManager = (ISessionManager)System.Web.HttpContext.Current.Session["SessionManager"];
                IMessage Imsg = ISManager.GetMessageObject();
                Imsg.AddMessage(sErrNumber, sErrMessage, sMethod, string.Empty, "5");
            }
            catch (System.Exception e)
            {
                Trace.WriteLineIf(SessionManager.m_ILActTraceSwitch.TraceError, e.Message, String.Format("zachqueryqrygrd : FillMessageObject(sMethod = \"{0}\",sErrNumber = \"{0}\",sErrMessage = \"{0}\")", sMethod, sErrNumber, sErrMessage));
            }
        }
    }
}

