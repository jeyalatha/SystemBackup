/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   ApiconsumerhubBR_Orac.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.br.orac
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ApiconsumerhubBR_Orac : IApiconsumerhubBR
    {
        public ApiconsumerhubBRTypes.Result achmtpopupimpsch(string szConnectionString, long ctxt_ouinstance, string ctxt_user, long ctxt_language, string ctxt_service, string ctxt_role, string engg_gqhdr_cust, string engg_gqhdr_proj, string engg_gqhdr_ecrno, string engg_gqpopup_version, string engg_gqpopup_json, string hdnengg_gqpopup_jsondbc, string hdnengg_gqpopup_schemadbc, string engg_gqpopup_schema)
        {
            ApiconsumerhubBRTypes.Result res = new ApiconsumerhubBRTypes.Result();
            return res;
        }
        public ApiconsumerhubBRTypes.Result achimpschmtimport(
                    string szConnectionString,
                    long ctxt_ouinstance,
                    string ctxt_user,
                    long ctxt_language,
                    string ctxt_service,
                    string ctxt_role,
                    string engg_imphdr_cust,
                    string engg_imphdr_prj,
                    string engg_imphdr_ecrno,
                    string engg_imphid_prcname,
                    string engg_imphid_cmpname,
                    string engg_imp_schname,
                    string engg_imp_schversion,
                    string engg_sch_importjson,
                    string engg_imp_importschema,
                    string engg_sch_importjsondbc,
                    string engg_imp_importschemadbc)
        {
            ApiconsumerhubBRTypes.Result res = new ApiconsumerhubBRTypes.Result();
            return res;
        }
        public ApiconsumerhubBRTypes.Achimpschmtmlimp achimpschmtmlimp(
                    string szConnectionString,
                    long ctxt_ouinstance,
                    string ctxt_user,
                    long ctxt_language,
                    string ctxt_service,
                    string ctxt_role,
                    string engg_imphdr_cust,
                    string engg_imphdr_prj,
                    string engg_imphdr_ecrno,
                    string engg_imphid_prcname,
                    string engg_imphid_cmpname,
                    string engg_imp_ml_schemaname,
                    string engg_imp_ml_schemaversion,
                    string engg_imp_ml_json,
                    string engg_imp_ml_sdlschema,
                    string engg_imp_ml_jsondbc,
                    string engg_imp_ml_sdlschemadbc,
                    string modeflag,
                    long fprowno)
        {
            ApiconsumerhubBRTypes.Achimpschmtmlimp spxs = new ApiconsumerhubBRTypes.Achimpschmtmlimp();
            return spxs;
        }
        public ApiconsumerhubBRTypes.Achvismttaskcustbr achvismttaskcustbr(
                    string szConnectionString,
                    long ctxt_ouinstance,
                    string ctxt_user,
                    long ctxt_language,
                    string ctxt_service,
                    string ctxt_role,
                    string customername_hdr,
                    string projectname_hdr,
                    string processname_hdr,
                    string componentnamehdr,
                    string docno_hdr,
                    string activityname_hdr,
                    string uiname_hdr,
                    string taskname_hdr,
                    string schema_version,
                    string custominput,
                    string custominput1,
                    string custominput2,
                    string custominput3)
        {
            ApiconsumerhubBRTypes.Achvismttaskcustbr spxs = new ApiconsumerhubBRTypes.Achvismttaskcustbr();
            return spxs;
        }
    }
}

