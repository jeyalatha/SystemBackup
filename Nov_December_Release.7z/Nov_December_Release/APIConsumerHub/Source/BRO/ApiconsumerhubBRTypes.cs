/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   ApiconsumerhubBRTypes.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.br
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public sealed class ApiconsumerhubBRTypes
    {
        public class Result
        {
            public int ErrorId;
        }
        public sealed class GetResetConnection : Result
        {
            public string connStr;
        }
        public sealed class Achimpschmtmlimp_RSet
        {
            public long fprowno;
        }
        public sealed class Achimpschmtmlimp : Result
        {
            public IList<Achimpschmtmlimp_RSet> resultSet;
        }
        public sealed class Achvismttaskcustbr : Result
        {
            public string introspectionjson;
            public string sdlschema;
            public string sdltext;
            public string introspection_mappedjson;
            public string customoutput1;
            public string customoutput2;
            public string customoutput3;
        }
    }
}

