/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   ApiconsumerhubBRFactory.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.br
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using com.ramco.vw.apiconsumerhub.br.sql;
    using com.ramco.vw.apiconsumerhub.br.orac;

    public sealed class ApiconsumerhubBRFactory
    {
        public static IApiconsumerhubBR GetApiconsumerhubBR(string provider)
        {
            switch (provider)
            {
                case "ORACLE":
                    return new ApiconsumerhubBR_Orac();
                default:
                    return new ApiconsumerhubBR_Sql();
            }
        }
    }
}

