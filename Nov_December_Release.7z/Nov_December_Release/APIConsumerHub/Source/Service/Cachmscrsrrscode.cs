/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cachmscrsrrscode.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.apiconsumerhub.ehs;

    public class Cachmscrsrrscode : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htRSPMLMLOUT = new System.Collections.Hashtable();
        private string modeFlagValue = string.Empty;
        public Cachmscrsrrscode()
        {
            base.iEDKESEngineInit("achmscrsrrscode", "apiconsumerhub");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htRSPMLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rspmlmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rspmlmlout");
                    this.writer.WriteAttributeString("RecordCount", htRSPMLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htRSPMLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRSPMLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("responseml_nex", System.Convert.ToString(nvcTmp["responseml_nex"]));
                            this.writer.WriteAttributeString("responseml_nid", System.Convert.ToString(nvcTmp["responseml_nid"]));
                            this.writer.WriteAttributeString("responseml_pnid", System.Convert.ToString(nvcTmp["responseml_pnid"]));
                            this.writer.WriteAttributeString("rs_controlid", System.Convert.ToString(nvcTmp["rs_controlid"]));
                            this.writer.WriteAttributeString("rs_ctrlbtsynonym", System.Convert.ToString(nvcTmp["rs_ctrlbtsynonym"]));
                            this.writer.WriteAttributeString("rs_dataitemname", System.Convert.ToString(nvcTmp["rs_dataitemname"]));
                            this.writer.WriteAttributeString("rs_displayname", System.Convert.ToString(nvcTmp["rs_displayname"]));
                            this.writer.WriteAttributeString("rs_identifier", System.Convert.ToString(nvcTmp["rs_identifier"]));
                            this.writer.WriteAttributeString("rs_ismandatory", System.Convert.ToString(nvcTmp["rs_ismandatory"]));
                            this.writer.WriteAttributeString("rs_parameterdatatype", System.Convert.ToString(nvcTmp["rs_parameterdatatype"]));
                            this.writer.WriteAttributeString("rs_parametername", System.Convert.ToString(nvcTmp["rs_parametername"]));
                            this.writer.WriteAttributeString("rs_parametertype", System.Convert.ToString(nvcTmp["rs_parametertype"]));
                            this.writer.WriteAttributeString("rs_parentschemaname", System.Convert.ToString(nvcTmp["rs_parentschemaname"]));
                            this.writer.WriteAttributeString("rs_schemacategory", System.Convert.ToString(nvcTmp["rs_schemacategory"]));
                            this.writer.WriteAttributeString("rs_schemaname", System.Convert.ToString(nvcTmp["rs_schemaname"]));
                            this.writer.WriteAttributeString("rs_schematype", System.Convert.ToString(nvcTmp["rs_schematype"]));
                            this.writer.WriteAttributeString("rs_schematypecategory", System.Convert.ToString(nvcTmp["rs_schematypecategory"]));
                            this.writer.WriteAttributeString("rs_segmentname", System.Convert.ToString(nvcTmp["rs_segmentname"]));
                            this.writer.WriteAttributeString("rs_viewname", System.Convert.ToString(nvcTmp["rs_viewname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rspmlmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "activitydesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "activityname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecversion":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "componentdesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "componentname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "custname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "customercls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "customername":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "doccls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "docnametpid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "docno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "documentno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ilbodesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "ilboname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationcls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationtpid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationtxt":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "pathname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "processdesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "processname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projectcls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projectname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psseqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_mediatype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_responsecode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "servicename":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "taskdesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "taskname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treemode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    type = 0;
                    break;
                case "rspmlmlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "rspmlmlout":
                    return htRSPMLMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "rspmlmlout":
                    return this.htRSPMLMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "rspmlmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmprspmlmlout = (NameValueCollection)htRSPMLMLOUT[lnInstNumber];
                        return nvcTmprspmlmlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                nvc_HSEG["activitydesc"] = (nvc_HSEG["activitydesc"] == null) ? "~#~" : nvc_HSEG["activitydesc"];
                nvc_HSEG["activityname"] = (nvc_HSEG["activityname"] == null) ? "~#~" : nvc_HSEG["activityname"];
                nvc_HSEG["apispecid"] = (nvc_HSEG["apispecid"] == null) ? "~#~" : nvc_HSEG["apispecid"];
                nvc_HSEG["apispecname"] = (nvc_HSEG["apispecname"] == null) ? "~#~" : nvc_HSEG["apispecname"];
                nvc_HSEG["apispecversion"] = (nvc_HSEG["apispecversion"] == null) ? "~#~" : nvc_HSEG["apispecversion"];
                nvc_HSEG["componentdesc"] = (nvc_HSEG["componentdesc"] == null) ? "~#~" : nvc_HSEG["componentdesc"];
                nvc_HSEG["componentname"] = (nvc_HSEG["componentname"] == null) ? "~#~" : nvc_HSEG["componentname"];
                nvc_HSEG["custname"] = (nvc_HSEG["custname"] == null) ? "~#~" : nvc_HSEG["custname"];
                nvc_HSEG["customercls"] = (nvc_HSEG["customercls"] == null) ? "~#~" : nvc_HSEG["customercls"];
                nvc_HSEG["customername"] = (nvc_HSEG["customername"] == null) ? "~#~" : nvc_HSEG["customername"];
                nvc_HSEG["doccls"] = (nvc_HSEG["doccls"] == null) ? "~#~" : nvc_HSEG["doccls"];
                nvc_HSEG["docnametpid"] = (nvc_HSEG["docnametpid"] == null) ? "~#~" : nvc_HSEG["docnametpid"];
                nvc_HSEG["docno"] = (nvc_HSEG["docno"] == null) ? "~#~" : nvc_HSEG["docno"];
                nvc_HSEG["documentno"] = (nvc_HSEG["documentno"] == null) ? "~#~" : nvc_HSEG["documentno"];
                nvc_HSEG["guid"] = (nvc_HSEG["guid"] == null) ? "~#~" : nvc_HSEG["guid"];
                nvc_HSEG["hdnrt_stcontrol"] = (nvc_HSEG["hdnrt_stcontrol"] == null) ? "~#~" : nvc_HSEG["hdnrt_stcontrol"];
                nvc_HSEG["ilbodesc"] = (nvc_HSEG["ilbodesc"] == null) ? "~#~" : nvc_HSEG["ilbodesc"];
                nvc_HSEG["ilboname"] = (nvc_HSEG["ilboname"] == null) ? "~#~" : nvc_HSEG["ilboname"];
                nvc_HSEG["operationcls"] = (nvc_HSEG["operationcls"] == null) ? "~#~" : nvc_HSEG["operationcls"];
                nvc_HSEG["operationtpid"] = (nvc_HSEG["operationtpid"] == null) ? "~#~" : nvc_HSEG["operationtpid"];
                nvc_HSEG["operationtxt"] = (nvc_HSEG["operationtxt"] == null) ? "~#~" : nvc_HSEG["operationtxt"];
                nvc_HSEG["pathname"] = (nvc_HSEG["pathname"] == null) ? "~#~" : nvc_HSEG["pathname"];
                nvc_HSEG["processdesc"] = (nvc_HSEG["processdesc"] == null) ? "~#~" : nvc_HSEG["processdesc"];
                nvc_HSEG["processname"] = (nvc_HSEG["processname"] == null) ? "~#~" : nvc_HSEG["processname"];
                nvc_HSEG["projectcls"] = (nvc_HSEG["projectcls"] == null) ? "~#~" : nvc_HSEG["projectcls"];
                nvc_HSEG["projectname"] = (nvc_HSEG["projectname"] == null) ? "~#~" : nvc_HSEG["projectname"];
                nvc_HSEG["projname"] = (nvc_HSEG["projname"] == null) ? "~#~" : nvc_HSEG["projname"];
                nvc_HSEG["psname"] = (nvc_HSEG["psname"] == null) ? "~#~" : nvc_HSEG["psname"];
                nvc_HSEG["psseqno"] = (nvc_HSEG["psseqno"] == null) ? "~#~" : nvc_HSEG["psseqno"];
                nvc_HSEG["rs_mediatype"] = (nvc_HSEG["rs_mediatype"] == null) ? "~#~" : nvc_HSEG["rs_mediatype"];
                nvc_HSEG["rs_responsecode"] = (nvc_HSEG["rs_responsecode"] == null) ? "~#~" : nvc_HSEG["rs_responsecode"];
                nvc_HSEG["servicename"] = (nvc_HSEG["servicename"] == null) ? "~#~" : nvc_HSEG["servicename"];
                nvc_HSEG["taskdesc"] = (nvc_HSEG["taskdesc"] == null) ? "~#~" : nvc_HSEG["taskdesc"];
                nvc_HSEG["taskname"] = (nvc_HSEG["taskname"] == null) ? "~#~" : nvc_HSEG["taskname"];
                nvc_HSEG["treemode"] = (nvc_HSEG["treemode"] == null) ? "~#~" : nvc_HSEG["treemode"];
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "ACH_ECR_00083", null);
                }
                base.WriteProfiler(String.Format("Service achmscrsrrscode Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service achmscrsrrscode Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsrscodepsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["activitydesc"];
                            base.Parameters("@activitydesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["activityname"];
                            base.Parameters("@activityname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentdesc"];
                            base.Parameters("@componentdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["customercls"];
                            base.Parameters("@customercls", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["customername"];
                            base.Parameters("@customername", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["doccls"];
                            base.Parameters("@doccls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docnametpid"];
                            base.Parameters("@docnametpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docno"];
                            base.Parameters("@docno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["ilbodesc"];
                            base.Parameters("@ilbodesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["ilboname"];
                            base.Parameters("@ilboname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["operationcls"];
                            base.Parameters("@operationcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtpid"];
                            base.Parameters("@operationtpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtxt"];
                            base.Parameters("@operationtxt", DBType.NVarchar, 100, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processdesc"];
                            base.Parameters("@processdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projectcls"];
                            base.Parameters("@projectcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["projectname"];
                            base.Parameters("@projectname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["rs_mediatype"];
                            base.Parameters("@rs_mediatype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["rs_responsecode"];
                            base.Parameters("@rs_responsecode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["taskdesc"];
                            base.Parameters("@taskdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["taskname"];
                            base.Parameters("@taskname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achmscrmtrscoderspmlmto", nLoop, nMax));
                        base.Execute_SP(true, "achmscrsprscoderspmlspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 124900, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 124900, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRSPMLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("responseml_nex");
                                    nvcTmp["responseml_nex"] = sValue;
                                    sValue = this.GetValue("responseml_nid");
                                    nvcTmp["responseml_nid"] = sValue;
                                    sValue = this.GetValue("responseml_pnid");
                                    nvcTmp["responseml_pnid"] = sValue;
                                    sValue = this.GetValue("rs_controlid");
                                    nvcTmp["rs_controlid"] = sValue;
                                    sValue = this.GetValue("rs_ctrlbtsynonym");
                                    nvcTmp["rs_ctrlbtsynonym"] = sValue;
                                    sValue = this.GetValue("rs_dataitemname");
                                    nvcTmp["rs_dataitemname"] = sValue;
                                    sValue = this.GetValue("rs_displayname");
                                    nvcTmp["rs_displayname"] = sValue;
                                    sValue = this.GetValue("rs_identifier");
                                    nvcTmp["rs_identifier"] = sValue;
                                    sValue = this.GetValue("rs_ismandatory");
                                    nvcTmp["rs_ismandatory"] = sValue;
                                    sValue = this.GetValue("rs_parameterdatatype");
                                    nvcTmp["rs_parameterdatatype"] = sValue;
                                    sValue = this.GetValue("rs_parametername");
                                    nvcTmp["rs_parametername"] = sValue;
                                    sValue = this.GetValue("rs_parametertype");
                                    nvcTmp["rs_parametertype"] = sValue;
                                    sValue = this.GetValue("rs_parentschemaname");
                                    nvcTmp["rs_parentschemaname"] = sValue;
                                    sValue = this.GetValue("rs_schemacategory");
                                    nvcTmp["rs_schemacategory"] = sValue;
                                    sValue = this.GetValue("rs_schemaname");
                                    nvcTmp["rs_schemaname"] = sValue;
                                    sValue = this.GetValue("rs_schematype");
                                    nvcTmp["rs_schematype"] = sValue;
                                    sValue = this.GetValue("rs_schematypecategory");
                                    nvcTmp["rs_schematypecategory"] = sValue;
                                    sValue = this.GetValue("rs_segmentname");
                                    nvcTmp["rs_segmentname"] = sValue;
                                    sValue = this.GetValue("rs_viewname");
                                    nvcTmp["rs_viewname"] = sValue;
                                    htRSPMLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 124900, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "rspmlmlout":
                            Localtable = (NameValueCollection)htRSPMLMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSachmscrsrrscode(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSachmscrsrrscode(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\achmscrsrrscode.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

