/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cachgqlsrfldqry.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.apiconsumerhub.ehs;

    public class Cachgqlsrfldqry : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htLISTEDIT_BTSYN = new System.Collections.Hashtable();
        public System.Collections.Hashtable htLISTEDIT_FLDNAM = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htFLDGRDMLOUT = new System.Collections.Hashtable();
        private string s_HSEGengg_fld_qryseq = "0";
        private string s_HSEGengg_gqfld_inclayoutctrls = "0";
        private string modeFlagValue = string.Empty;
        public Cachgqlsrfldqry()
        {
            base.iEDKESEngineInit("achgqlsrfldqry", "apiconsumerhub");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htLISTEDIT_BTSYN != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("listedit_btsyn", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("listedit_btsyn");
                    this.writer.WriteAttributeString("RecordCount", htLISTEDIT_BTSYN.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLISTEDIT_BTSYN.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLISTEDIT_BTSYN[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_gqctrl_datatype", System.Convert.ToString(nvcTmp["engg_gqctrl_datatype"]));
                            this.writer.WriteAttributeString("engg_gqfld_caption", System.Convert.ToString(nvcTmp["engg_gqfld_caption"]));
                            this.writer.WriteAttributeString("engg_gqfld_ctrlbtsyn", System.Convert.ToString(nvcTmp["engg_gqfld_ctrlbtsyn"]));
                            this.writer.WriteAttributeString("engg_gqfld_ctrlid", System.Convert.ToString(nvcTmp["engg_gqfld_ctrlid"]));
                            this.writer.WriteAttributeString("engg_gqfld_ctrltype", System.Convert.ToString(nvcTmp["engg_gqfld_ctrltype"]));
                            this.writer.WriteAttributeString("engg_gqfld_pgename", System.Convert.ToString(nvcTmp["engg_gqfld_pgename"]));
                            this.writer.WriteAttributeString("engg_gqfld_secname", System.Convert.ToString(nvcTmp["engg_gqfld_secname"]));
                            this.writer.WriteAttributeString("engg_gqfld_viewname", System.Convert.ToString(nvcTmp["engg_gqfld_viewname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("listedit_btsyn", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htLISTEDIT_FLDNAM != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("listedit_fldnam", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("listedit_fldnam");
                    this.writer.WriteAttributeString("RecordCount", htLISTEDIT_FLDNAM.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htLISTEDIT_FLDNAM.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htLISTEDIT_FLDNAM[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_gq_fieldname", System.Convert.ToString(nvcTmp["engg_gq_fieldname"]));
                            this.writer.WriteAttributeString("engg_gqfld_datatype", System.Convert.ToString(nvcTmp["engg_gqfld_datatype"]));
                            this.writer.WriteAttributeString("engg_gqfld_flattenedfldname", System.Convert.ToString(nvcTmp["engg_gqfld_flattenedfldname"]));
                            this.writer.WriteAttributeString("engg_gqfld_ismandatoy", System.Convert.ToString(nvcTmp["engg_gqfld_ismandatoy"]));
                            this.writer.WriteAttributeString("engg_gqfld_type", System.Convert.ToString(nvcTmp["engg_gqfld_type"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("listedit_fldnam", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("engg_fld_qry", System.Convert.ToString(nvc_HSEG["engg_fld_qry"]));
                    this.writer.WriteAttributeString("engg_fld_qry_version", System.Convert.ToString(nvc_HSEG["engg_fld_qry_version"]));
                    this.writer.WriteAttributeString("engg_fld_qryalias", System.Convert.ToString(nvc_HSEG["engg_fld_qryalias"]));
                    this.writer.WriteAttributeString("engg_fld_qryhdnkeyfield", System.Convert.ToString(nvc_HSEG["engg_fld_qryhdnkeyfield"]));
                    this.writer.WriteAttributeString("engg_fld_qryseq", System.Convert.ToString(nvc_HSEG["engg_fld_qryseq"]));
                    this.writer.WriteAttributeString("engg_fld_qrytype", System.Convert.ToString(nvc_HSEG["engg_fld_qrytype"]));
                    this.writer.WriteAttributeString("engg_gqfld_inclayoutctrls", System.Convert.ToString(nvc_HSEG["engg_gqfld_inclayoutctrls"]));
                    this.writer.WriteAttributeString("engg_gqhdr_actdescr", System.Convert.ToString(nvc_HSEG["engg_gqhdr_actdescr"]));
                    this.writer.WriteAttributeString("engg_gqhdr_actname", System.Convert.ToString(nvc_HSEG["engg_gqhdr_actname"]));
                    this.writer.WriteAttributeString("engg_gqhdr_cmpdescr", System.Convert.ToString(nvc_HSEG["engg_gqhdr_cmpdescr"]));
                    this.writer.WriteAttributeString("engg_gqhdr_cmpname", System.Convert.ToString(nvc_HSEG["engg_gqhdr_cmpname"]));
                    this.writer.WriteAttributeString("engg_gqhdr_cust", System.Convert.ToString(nvc_HSEG["engg_gqhdr_cust"]));
                    this.writer.WriteAttributeString("engg_gqhdr_ecrno", System.Convert.ToString(nvc_HSEG["engg_gqhdr_ecrno"]));
                    this.writer.WriteAttributeString("engg_gqhdr_prcname", System.Convert.ToString(nvc_HSEG["engg_gqhdr_prcname"]));
                    this.writer.WriteAttributeString("engg_gqhdr_prodescr", System.Convert.ToString(nvc_HSEG["engg_gqhdr_prodescr"]));
                    this.writer.WriteAttributeString("engg_gqhdr_proj", System.Convert.ToString(nvc_HSEG["engg_gqhdr_proj"]));
                    this.writer.WriteAttributeString("engg_gqhdr_taskdescr", System.Convert.ToString(nvc_HSEG["engg_gqhdr_taskdescr"]));
                    this.writer.WriteAttributeString("engg_gqhdr_tasktype", System.Convert.ToString(nvc_HSEG["engg_gqhdr_tasktype"]));
                    this.writer.WriteAttributeString("engg_gqhdr_tskname", System.Convert.ToString(nvc_HSEG["engg_gqhdr_tskname"]));
                    this.writer.WriteAttributeString("engg_gqhdr_uidescr", System.Convert.ToString(nvc_HSEG["engg_gqhdr_uidescr"]));
                    this.writer.WriteAttributeString("engg_gqhdr_uiname", System.Convert.ToString(nvc_HSEG["engg_gqhdr_uiname"]));
                    this.writer.WriteAttributeString("engg_gqpopup_json", System.Convert.ToString(nvc_HSEG["engg_gqpopup_json"]));
                    this.writer.WriteAttributeString("engg_gqpopup_jsondbc", System.Convert.ToString(nvc_HSEG["engg_gqpopup_jsondbc"]));
                    this.writer.WriteAttributeString("engg_gqpopup_schema", System.Convert.ToString(nvc_HSEG["engg_gqpopup_schema"]));
                    this.writer.WriteAttributeString("engg_gqpopup_schemadbc", System.Convert.ToString(nvc_HSEG["engg_gqpopup_schemadbc"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htFLDGRDMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("fldgrdmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("fldgrdmlout");
                    this.writer.WriteAttributeString("RecordCount", htFLDGRDMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htFLDGRDMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htFLDGRDMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("engg_gdfldml_fldalias", System.Convert.ToString(nvcTmp["engg_gdfldml_fldalias"]));
                            this.writer.WriteAttributeString("engg_gqfldml_caption", System.Convert.ToString(nvcTmp["engg_gqfldml_caption"]));
                            this.writer.WriteAttributeString("engg_gqfldml_ctrlbtsyn", System.Convert.ToString(nvcTmp["engg_gqfldml_ctrlbtsyn"]));
                            this.writer.WriteAttributeString("engg_gqfldml_ctrlid", System.Convert.ToString(nvcTmp["engg_gqfldml_ctrlid"]));
                            this.writer.WriteAttributeString("engg_gqfldml_ctrltype", System.Convert.ToString(nvcTmp["engg_gqfldml_ctrltype"]));
                            this.writer.WriteAttributeString("engg_gqfldml_defvalue", System.Convert.ToString(nvcTmp["engg_gqfldml_defvalue"]));
                            this.writer.WriteAttributeString("engg_gqfldml_fldname", System.Convert.ToString(nvcTmp["engg_gqfldml_fldname"]));
                            this.writer.WriteAttributeString("engg_gqfldml_maptype", System.Convert.ToString(nvcTmp["engg_gqfldml_maptype"]));
                            this.writer.WriteAttributeString("engg_gqfldml_pagname", System.Convert.ToString(nvcTmp["engg_gqfldml_pagname"]));
                            this.writer.WriteAttributeString("engg_gqfldml_parschmaname", System.Convert.ToString(nvcTmp["engg_gqfldml_parschmaname"]));
                            this.writer.WriteAttributeString("engg_gqfldml_schmaname", System.Convert.ToString(nvcTmp["engg_gqfldml_schmaname"]));
                            this.writer.WriteAttributeString("engg_gqfldml_secname", System.Convert.ToString(nvcTmp["engg_gqfldml_secname"]));
                            this.writer.WriteAttributeString("engg_gqfldml_viewname", System.Convert.ToString(nvcTmp["engg_gqfldml_viewname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("fldgrdmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "engg_fld_qry":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_fld_qry_version":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_fld_qryalias":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_fld_qryhdnkeyfield":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_fld_qryseq":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_fld_qrytype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqfld_inclayoutctrls":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "engg_gqhdr_actdescr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_actname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_cmpdescr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_cmpname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_cust":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_ecrno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_prcname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_prodescr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_proj":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_taskdescr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_tasktype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_tskname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_uidescr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqhdr_uiname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqpopup_json":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqpopup_jsondbc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqpopup_schema":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_gqpopup_schemadbc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_btsyn":
                    type = 1;
                    break;
                case "listedit_fldnam":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                case "fldgrdmlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_btsyn":
                    return htLISTEDIT_BTSYN.Count;
                    break;
                case "listedit_fldnam":
                    return htLISTEDIT_FLDNAM.Count;
                    break;
                case "fldgrdmlout":
                    return htFLDGRDMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "listedit_btsyn":
                    return this.htLISTEDIT_BTSYN;
                case "listedit_fldnam":
                    return this.htLISTEDIT_FLDNAM;
                case "fldgrdmlout":
                    return this.htFLDGRDMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "listedit_btsyn":
                        System.Collections.Specialized.NameValueCollection nvcTmplistedit_btsyn = (NameValueCollection)htLISTEDIT_BTSYN[lnInstNumber];
                        return nvcTmplistedit_btsyn[szDataItem];
                        break;
                    case "listedit_fldnam":
                        System.Collections.Specialized.NameValueCollection nvcTmplistedit_fldnam = (NameValueCollection)htLISTEDIT_FLDNAM[lnInstNumber];
                        return nvcTmplistedit_fldnam[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "fldgrdmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmpfldgrdmlout = (NameValueCollection)htFLDGRDMLOUT[lnInstNumber];
                        return nvcTmpfldgrdmlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "ACH_ECR_00083", null);
                }
                base.WriteProfiler(String.Format("Service achgqlsrfldqry Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service achgqlsrfldqry Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsfldqryhpsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_fld_qry"];
                            base.Parameters("@engg_fld_qry", DBType.NVarchar, 512, sValue);
                            sValue = nvc_HSEG["engg_fld_qryalias"];
                            base.Parameters("@engg_fld_qryalias", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qryhdnkeyfield"];
                            base.Parameters("@engg_fld_qryhdnkeyfield", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_fld_qryseq"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_fld_qryseq = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_fld_qryseq);
                            base.Parameters("@engg_fld_qryseq", DBType.Int, 32, s_HSEGengg_fld_qryseq);
                            sValue = nvc_HSEG["engg_fld_qrytype"];
                            base.Parameters("@engg_fld_qrytype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qry_version"];
                            base.Parameters("@engg_fld_qry_version", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqfld_inclayoutctrls"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_gqfld_inclayoutctrls = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_gqfld_inclayoutctrls);
                            base.Parameters("@engg_gqfld_inclayoutctrls", DBType.Int, 32, s_HSEGengg_gqfld_inclayoutctrls);
                            sValue = nvc_HSEG["engg_gqhdr_actdescr"];
                            base.Parameters("@engg_gqhdr_actdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_actname"];
                            base.Parameters("@engg_gqhdr_actname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpdescr"];
                            base.Parameters("@engg_gqhdr_cmpdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpname"];
                            base.Parameters("@engg_gqhdr_cmpname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cust"];
                            base.Parameters("@engg_gqhdr_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_ecrno"];
                            base.Parameters("@engg_gqhdr_ecrno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prcname"];
                            base.Parameters("@engg_gqhdr_prcname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prodescr"];
                            base.Parameters("@engg_gqhdr_prodescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_proj"];
                            base.Parameters("@engg_gqhdr_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_taskdescr"];
                            base.Parameters("@engg_gqhdr_taskdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tasktype"];
                            base.Parameters("@engg_gqhdr_tasktype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tskname"];
                            base.Parameters("@engg_gqhdr_tskname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uidescr"];
                            base.Parameters("@engg_gqhdr_uidescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uiname"];
                            base.Parameters("@engg_gqhdr_uiname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_json"];
                            base.Parameters("@engg_gqpopup_json", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_jsondbc"];
                            base.Parameters("@engg_gqpopup_jsondbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schema"];
                            base.Parameters("@engg_gqpopup_schema", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schemadbc"];
                            base.Parameters("@engg_gqpopup_schemadbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achgqlmtfldqryhdrref", nLoop, nMax));
                        base.Execute_SP(true, "achgqlspfldqryhdrref", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128640, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128640, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("engg_fld_qry");
                                nvc_HSEG["engg_fld_qry"] = sValue;
                                sValue = this.GetValue("engg_fld_qry_version");
                                nvc_HSEG["engg_fld_qry_version"] = sValue;
                                sValue = this.GetValue("engg_fld_qryalias");
                                nvc_HSEG["engg_fld_qryalias"] = sValue;
                                sValue = this.GetValue("engg_fld_qryhdnkeyfield");
                                nvc_HSEG["engg_fld_qryhdnkeyfield"] = sValue;
                                sValue = this.GetValue("engg_fld_qryseq");
                                nvc_HSEG["engg_fld_qryseq"] = sValue;
                                sValue = this.GetValue("engg_fld_qrytype");
                                nvc_HSEG["engg_fld_qrytype"] = sValue;
                                sValue = this.GetValue("engg_gqfld_inclayoutctrls");
                                nvc_HSEG["engg_gqfld_inclayoutctrls"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_actdescr");
                                nvc_HSEG["engg_gqhdr_actdescr"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_actname");
                                nvc_HSEG["engg_gqhdr_actname"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_cmpdescr");
                                nvc_HSEG["engg_gqhdr_cmpdescr"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_cmpname");
                                nvc_HSEG["engg_gqhdr_cmpname"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_cust");
                                nvc_HSEG["engg_gqhdr_cust"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_ecrno");
                                nvc_HSEG["engg_gqhdr_ecrno"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_prcname");
                                nvc_HSEG["engg_gqhdr_prcname"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_prodescr");
                                nvc_HSEG["engg_gqhdr_prodescr"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_proj");
                                nvc_HSEG["engg_gqhdr_proj"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_taskdescr");
                                nvc_HSEG["engg_gqhdr_taskdescr"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_tasktype");
                                nvc_HSEG["engg_gqhdr_tasktype"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_tskname");
                                nvc_HSEG["engg_gqhdr_tskname"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_uidescr");
                                nvc_HSEG["engg_gqhdr_uidescr"] = sValue;
                                sValue = this.GetValue("engg_gqhdr_uiname");
                                nvc_HSEG["engg_gqhdr_uiname"] = sValue;
                                sValue = this.GetValue("engg_gqpopup_json");
                                nvc_HSEG["engg_gqpopup_json"] = sValue;
                                sValue = this.GetValue("engg_gqpopup_jsondbc");
                                nvc_HSEG["engg_gqpopup_jsondbc"] = sValue;
                                sValue = this.GetValue("engg_gqpopup_schema");
                                nvc_HSEG["engg_gqpopup_schema"] = sValue;
                                sValue = this.GetValue("engg_gqpopup_schemadbc");
                                nvc_HSEG["engg_gqpopup_schemadbc"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128640, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsfldqrypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_fld_qry"];
                            base.Parameters("@engg_fld_qry", DBType.NVarchar, 512, sValue);
                            sValue = nvc_HSEG["engg_fld_qryalias"];
                            base.Parameters("@engg_fld_qryalias", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qryhdnkeyfield"];
                            base.Parameters("@engg_fld_qryhdnkeyfield", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_fld_qryseq"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_fld_qryseq = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_fld_qryseq);
                            base.Parameters("@engg_fld_qryseq", DBType.Int, 32, s_HSEGengg_fld_qryseq);
                            sValue = nvc_HSEG["engg_fld_qrytype"];
                            base.Parameters("@engg_fld_qrytype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qry_version"];
                            base.Parameters("@engg_fld_qry_version", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqfld_inclayoutctrls"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_gqfld_inclayoutctrls = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_gqfld_inclayoutctrls);
                            base.Parameters("@engg_gqfld_inclayoutctrls", DBType.Int, 32, s_HSEGengg_gqfld_inclayoutctrls);
                            sValue = nvc_HSEG["engg_gqhdr_actdescr"];
                            base.Parameters("@engg_gqhdr_actdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_actname"];
                            base.Parameters("@engg_gqhdr_actname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpdescr"];
                            base.Parameters("@engg_gqhdr_cmpdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpname"];
                            base.Parameters("@engg_gqhdr_cmpname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cust"];
                            base.Parameters("@engg_gqhdr_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_ecrno"];
                            base.Parameters("@engg_gqhdr_ecrno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prcname"];
                            base.Parameters("@engg_gqhdr_prcname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prodescr"];
                            base.Parameters("@engg_gqhdr_prodescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_proj"];
                            base.Parameters("@engg_gqhdr_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_taskdescr"];
                            base.Parameters("@engg_gqhdr_taskdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tasktype"];
                            base.Parameters("@engg_gqhdr_tasktype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tskname"];
                            base.Parameters("@engg_gqhdr_tskname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uidescr"];
                            base.Parameters("@engg_gqhdr_uidescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uiname"];
                            base.Parameters("@engg_gqhdr_uiname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_json"];
                            base.Parameters("@engg_gqpopup_json", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_jsondbc"];
                            base.Parameters("@engg_gqpopup_jsondbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schema"];
                            base.Parameters("@engg_gqpopup_schema", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schemadbc"];
                            base.Parameters("@engg_gqpopup_schemadbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achgqlmtfldqryfldgrdmto", nLoop, nMax));
                        base.Execute_SP(true, "achgqlspfldqryfldgrdspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128641, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128641, 2, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htFLDGRDMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_gdfldml_fldalias");
                                    nvcTmp["engg_gdfldml_fldalias"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_caption");
                                    nvcTmp["engg_gqfldml_caption"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_ctrlbtsyn");
                                    nvcTmp["engg_gqfldml_ctrlbtsyn"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_ctrlid");
                                    nvcTmp["engg_gqfldml_ctrlid"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_ctrltype");
                                    nvcTmp["engg_gqfldml_ctrltype"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_defvalue");
                                    nvcTmp["engg_gqfldml_defvalue"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_fldname");
                                    nvcTmp["engg_gqfldml_fldname"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_maptype");
                                    nvcTmp["engg_gqfldml_maptype"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_pagname");
                                    nvcTmp["engg_gqfldml_pagname"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_parschmaname");
                                    nvcTmp["engg_gqfldml_parschmaname"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_schmaname");
                                    nvcTmp["engg_gqfldml_schmaname"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_secname");
                                    nvcTmp["engg_gqfldml_secname"] = sValue;
                                    sValue = this.GetValue("engg_gqfldml_viewname");
                                    nvcTmp["engg_gqfldml_viewname"] = sValue;
                                    htFLDGRDMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128641, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 2  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsfldqrypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_fld_qry"];
                            base.Parameters("@engg_fld_qry", DBType.NVarchar, 512, sValue);
                            sValue = nvc_HSEG["engg_fld_qryalias"];
                            base.Parameters("@engg_fld_qryalias", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qryhdnkeyfield"];
                            base.Parameters("@engg_fld_qryhdnkeyfield", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_fld_qryseq"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_fld_qryseq = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_fld_qryseq);
                            base.Parameters("@engg_fld_qryseq", DBType.Int, 32, s_HSEGengg_fld_qryseq);
                            sValue = nvc_HSEG["engg_fld_qrytype"];
                            base.Parameters("@engg_fld_qrytype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qry_version"];
                            base.Parameters("@engg_fld_qry_version", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqfld_inclayoutctrls"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_gqfld_inclayoutctrls = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_gqfld_inclayoutctrls);
                            base.Parameters("@engg_gqfld_inclayoutctrls", DBType.Int, 32, s_HSEGengg_gqfld_inclayoutctrls);
                            sValue = nvc_HSEG["engg_gqhdr_actdescr"];
                            base.Parameters("@engg_gqhdr_actdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_actname"];
                            base.Parameters("@engg_gqhdr_actname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpdescr"];
                            base.Parameters("@engg_gqhdr_cmpdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpname"];
                            base.Parameters("@engg_gqhdr_cmpname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cust"];
                            base.Parameters("@engg_gqhdr_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_ecrno"];
                            base.Parameters("@engg_gqhdr_ecrno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prcname"];
                            base.Parameters("@engg_gqhdr_prcname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prodescr"];
                            base.Parameters("@engg_gqhdr_prodescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_proj"];
                            base.Parameters("@engg_gqhdr_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_taskdescr"];
                            base.Parameters("@engg_gqhdr_taskdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tasktype"];
                            base.Parameters("@engg_gqhdr_tasktype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tskname"];
                            base.Parameters("@engg_gqhdr_tskname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uidescr"];
                            base.Parameters("@engg_gqhdr_uidescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uiname"];
                            base.Parameters("@engg_gqhdr_uiname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_json"];
                            base.Parameters("@engg_gqpopup_json", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_jsondbc"];
                            base.Parameters("@engg_gqpopup_jsondbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schema"];
                            base.Parameters("@engg_gqpopup_schema", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schemadbc"];
                            base.Parameters("@engg_gqpopup_schemadbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achgqlmtfldqry_btsynleo", nLoop, nMax));
                        base.Execute_SP(true, "achgqlspfldqry_btsynleo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128642, 2, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128642, 2, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLISTEDIT_BTSYN.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_gqctrl_datatype");
                                    nvcTmp["engg_gqctrl_datatype"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_caption");
                                    nvcTmp["engg_gqfld_caption"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_ctrlbtsyn");
                                    nvcTmp["engg_gqfld_ctrlbtsyn"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_ctrlid");
                                    nvcTmp["engg_gqfld_ctrlid"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_ctrltype");
                                    nvcTmp["engg_gqfld_ctrltype"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_pgename");
                                    nvcTmp["engg_gqfld_pgename"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_secname");
                                    nvcTmp["engg_gqfld_secname"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_viewname");
                                    nvcTmp["engg_gqfld_viewname"] = sValue;
                                    htLISTEDIT_BTSYN[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128642, 2, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 2
                // Starting to execute the BR - 3  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsfldqrypsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            sValue = nvc_HSEG["engg_fld_qry"];
                            base.Parameters("@engg_fld_qry", DBType.NVarchar, 512, sValue);
                            sValue = nvc_HSEG["engg_fld_qryalias"];
                            base.Parameters("@engg_fld_qryalias", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qryhdnkeyfield"];
                            base.Parameters("@engg_fld_qryhdnkeyfield", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_fld_qryseq"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_fld_qryseq = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_fld_qryseq);
                            base.Parameters("@engg_fld_qryseq", DBType.Int, 32, s_HSEGengg_fld_qryseq);
                            sValue = nvc_HSEG["engg_fld_qrytype"];
                            base.Parameters("@engg_fld_qrytype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_fld_qry_version"];
                            base.Parameters("@engg_fld_qry_version", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqfld_inclayoutctrls"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGengg_gqfld_inclayoutctrls = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGengg_gqfld_inclayoutctrls);
                            base.Parameters("@engg_gqfld_inclayoutctrls", DBType.Int, 32, s_HSEGengg_gqfld_inclayoutctrls);
                            sValue = nvc_HSEG["engg_gqhdr_actdescr"];
                            base.Parameters("@engg_gqhdr_actdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_actname"];
                            base.Parameters("@engg_gqhdr_actname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpdescr"];
                            base.Parameters("@engg_gqhdr_cmpdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cmpname"];
                            base.Parameters("@engg_gqhdr_cmpname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_cust"];
                            base.Parameters("@engg_gqhdr_cust", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_ecrno"];
                            base.Parameters("@engg_gqhdr_ecrno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prcname"];
                            base.Parameters("@engg_gqhdr_prcname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_prodescr"];
                            base.Parameters("@engg_gqhdr_prodescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_proj"];
                            base.Parameters("@engg_gqhdr_proj", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_taskdescr"];
                            base.Parameters("@engg_gqhdr_taskdescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tasktype"];
                            base.Parameters("@engg_gqhdr_tasktype", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_tskname"];
                            base.Parameters("@engg_gqhdr_tskname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uidescr"];
                            base.Parameters("@engg_gqhdr_uidescr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_gqhdr_uiname"];
                            base.Parameters("@engg_gqhdr_uiname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_json"];
                            base.Parameters("@engg_gqpopup_json", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_jsondbc"];
                            base.Parameters("@engg_gqpopup_jsondbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schema"];
                            base.Parameters("@engg_gqpopup_schema", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvc_HSEG["engg_gqpopup_schemadbc"];
                            base.Parameters("@engg_gqpopup_schemadbc", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achgqlmtfldqry_fldnamleo", nLoop, nMax));
                        base.Execute_SP(true, "achgqlspfldqry_fldnamleo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128643, 2, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 128643, 2, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htLISTEDIT_FLDNAM.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_gq_fieldname");
                                    nvcTmp["engg_gq_fieldname"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_datatype");
                                    nvcTmp["engg_gqfld_datatype"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_flattenedfldname");
                                    nvcTmp["engg_gqfld_flattenedfldname"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_ismandatoy");
                                    nvcTmp["engg_gqfld_ismandatoy"] = sValue;
                                    sValue = this.GetValue("engg_gqfld_type");
                                    nvcTmp["engg_gqfld_type"] = sValue;
                                    htLISTEDIT_FLDNAM[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 128643, 2, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "listedit_btsyn":
                            Localtable = (NameValueCollection)htLISTEDIT_BTSYN[lInstance];
                            break;
                        case "listedit_fldnam":
                            Localtable = (NameValueCollection)htLISTEDIT_FLDNAM[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fldgrdmlout":
                            Localtable = (NameValueCollection)htFLDGRDMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSachgqlsrfldqry(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSachgqlsrfldqry(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\achgqlsrfldqry.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

