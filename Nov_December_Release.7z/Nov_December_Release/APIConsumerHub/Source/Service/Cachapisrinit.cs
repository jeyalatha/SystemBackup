/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cachapisrinit.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.apiconsumerhub.ehs;

    public class Cachapisrinit : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Hashtable htAPITRGCBSEG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPMCTVWMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htPMSGDIMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRQCTVWMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRQPRCTMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRQSGDIMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRSSCMBMLCBSG = new System.Collections.Hashtable();
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        private string modeFlagValue = string.Empty;
        public Cachapisrinit()
        {
            base.iEDKESEngineInit("achapisrinit", "apiconsumerhub");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.htAPITRGCBSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("apitrgcbseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("apitrgcbseg");
                    this.writer.WriteAttributeString("RecordCount", htAPITRGCBSEG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htAPITRGCBSEG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htAPITRGCBSEG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("engg_api_trigger", System.Convert.ToString(nvcTmp["engg_api_trigger"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("apitrgcbseg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPMCTVWMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pmctvwmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pmctvwmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htPMCTVWMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPMCTVWMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPMCTVWMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("p_controlview", System.Convert.ToString(nvcTmp["p_controlview"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pmctvwmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htPMSGDIMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("pmsgdimlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("pmsgdimlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htPMSGDIMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htPMSGDIMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htPMSGDIMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("p_segmentdataitem", System.Convert.ToString(nvcTmp["p_segmentdataitem"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("pmsgdimlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRQCTVWMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rqctvwmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rqctvwmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htRQCTVWMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRQCTVWMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRQCTVWMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("rq_controlview", System.Convert.ToString(nvcTmp["rq_controlview"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rqctvwmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRQPRCTMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rqprctmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rqprctmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htRQPRCTMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRQPRCTMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRQPRCTMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("rq_processing_type", System.Convert.ToString(nvcTmp["rq_processing_type"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rqprctmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRQSGDIMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rqsgdimlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rqsgdimlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htRQSGDIMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRQSGDIMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRQSGDIMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("rq_segmentdataitem", System.Convert.ToString(nvcTmp["rq_segmentdataitem"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rqsgdimlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if ((this.htRSSCMBMLCBSG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rsscmbmlcbsg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rsscmbmlcbsg");
                    this.writer.WriteAttributeString("RecordCount", htRSSCMBMLCBSG.Count.ToString());
                    this.writer.WriteAttributeString("seq", "1");
                    for (long reccount = 1; (reccount <= htRSSCMBMLCBSG.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRSSCMBMLCBSG[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I1");
                            this.writer.WriteAttributeString("rs_flattened_schema_cmb", System.Convert.ToString(nvcTmp["rs_flattened_schema_cmb"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rsscmbmlcbsg", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "apispecid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecversion":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "componentname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "custname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "documentno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_activity_name_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_desc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_desc_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_name_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "pathname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "processname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psseqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "servicename":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treemode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "apitrgcbseg":
                    type = 1;
                    break;
                case "pmctvwmlcbsg":
                    type = 1;
                    break;
                case "pmsgdimlcbsg":
                    type = 1;
                    break;
                case "rqctvwmlcbsg":
                    type = 1;
                    break;
                case "rqprctmlcbsg":
                    type = 1;
                    break;
                case "rqsgdimlcbsg":
                    type = 1;
                    break;
                case "rsscmbmlcbsg":
                    type = 1;
                    break;
                case "_hseg":
                    type = 0;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "apitrgcbseg":
                    return htAPITRGCBSEG.Count;
                    break;
                case "pmctvwmlcbsg":
                    return htPMCTVWMLCBSG.Count;
                    break;
                case "pmsgdimlcbsg":
                    return htPMSGDIMLCBSG.Count;
                    break;
                case "rqctvwmlcbsg":
                    return htRQCTVWMLCBSG.Count;
                    break;
                case "rqprctmlcbsg":
                    return htRQPRCTMLCBSG.Count;
                    break;
                case "rqsgdimlcbsg":
                    return htRQSGDIMLCBSG.Count;
                    break;
                case "rsscmbmlcbsg":
                    return htRSSCMBMLCBSG.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "apitrgcbseg":
                    return this.htAPITRGCBSEG;
                case "pmctvwmlcbsg":
                    return this.htPMCTVWMLCBSG;
                case "pmsgdimlcbsg":
                    return this.htPMSGDIMLCBSG;
                case "rqctvwmlcbsg":
                    return this.htRQCTVWMLCBSG;
                case "rqprctmlcbsg":
                    return this.htRQPRCTMLCBSG;
                case "rqsgdimlcbsg":
                    return this.htRQSGDIMLCBSG;
                case "rsscmbmlcbsg":
                    return this.htRSSCMBMLCBSG;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "apitrgcbseg":
                        System.Collections.Specialized.NameValueCollection nvcTmpapitrgcbseg = (NameValueCollection)htAPITRGCBSEG[lnInstNumber];
                        return nvcTmpapitrgcbseg[szDataItem];
                        break;
                    case "pmctvwmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmppmctvwmlcbsg = (NameValueCollection)htPMCTVWMLCBSG[lnInstNumber];
                        return nvcTmppmctvwmlcbsg[szDataItem];
                        break;
                    case "pmsgdimlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmppmsgdimlcbsg = (NameValueCollection)htPMSGDIMLCBSG[lnInstNumber];
                        return nvcTmppmsgdimlcbsg[szDataItem];
                        break;
                    case "rqctvwmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmprqctvwmlcbsg = (NameValueCollection)htRQCTVWMLCBSG[lnInstNumber];
                        return nvcTmprqctvwmlcbsg[szDataItem];
                        break;
                    case "rqprctmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmprqprctmlcbsg = (NameValueCollection)htRQPRCTMLCBSG[lnInstNumber];
                        return nvcTmprqprctmlcbsg[szDataItem];
                        break;
                    case "rqsgdimlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmprqsgdimlcbsg = (NameValueCollection)htRQSGDIMLCBSG[lnInstNumber];
                        return nvcTmprqsgdimlcbsg[szDataItem];
                        break;
                    case "rsscmbmlcbsg":
                        System.Collections.Specialized.NameValueCollection nvcTmprsscmbmlcbsg = (NameValueCollection)htRSSCMBMLCBSG[lnInstNumber];
                        return nvcTmprsscmbmlcbsg[szDataItem];
                        break;
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "ACH_ECR_00083", null);
                }
                base.WriteProfiler(String.Format("Service achapisrinit Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service achapisrinit Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitapitrg", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitapitrg", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127117, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127117, 1, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htAPITRGCBSEG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("engg_api_trigger");
                                    nvcTmp["engg_api_trigger"] = sValue;
                                    htAPITRGCBSEG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127117, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 2  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 2;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 2 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitpmctvw", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitpmctvw", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127118, 1, 2);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127118, 1, 2);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPMCTVWMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("p_controlview");
                                    nvcTmp["p_controlview"] = sValue;
                                    htPMCTVWMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 2", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127118, 1, 2);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 3  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 3;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 3 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitpmsgdi", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitpmsgdi", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127119, 1, 3);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127119, 1, 3);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htPMSGDIMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("p_segmentdataitem");
                                    nvcTmp["p_segmentdataitem"] = sValue;
                                    htPMSGDIMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 3", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127119, 1, 3);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 4  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 4;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 4 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitrqctvw", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitrqctvw", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127120, 1, 4);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127120, 1, 4);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRQCTVWMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("rq_controlview");
                                    nvcTmp["rq_controlview"] = sValue;
                                    htRQCTVWMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 4", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127120, 1, 4);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 4 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 5  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 5;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 5 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitrqprct", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitrqprct", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127121, 1, 5);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127121, 1, 5);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRQPRCTMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("rq_processing_type");
                                    nvcTmp["rq_processing_type"] = sValue;
                                    htRQPRCTMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 5", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127121, 1, 5);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 5 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 6  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 6;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 6 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitrqsgdi", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitrqsgdi", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127122, 1, 6);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127122, 1, 6);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRQSGDIMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("rq_segmentdataitem");
                                    nvcTmp["rq_segmentdataitem"] = sValue;
                                    htRQSGDIMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 6", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127122, 1, 6);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 6 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
                // Starting to execute default style process section 1
                // Starting to execute the BR - 7  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 7;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsinit");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 7 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtinitrsscmb", nLoop, nMax));
                        base.Execute_SP(true, "achapispinitrsscmb", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127123, 1, 7);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127123, 1, 7);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRSSCMBMLCBSG.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("rs_flattened_schema_cmb");
                                    nvcTmp["rs_flattened_schema_cmb"] = sValue;
                                    htRSSCMBMLCBSG[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 7", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127123, 1, 7);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 7 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "apitrgcbseg":
                            Localtable = (NameValueCollection)htAPITRGCBSEG[lInstance];
                            break;
                        case "pmctvwmlcbsg":
                            Localtable = (NameValueCollection)htPMCTVWMLCBSG[lInstance];
                            break;
                        case "pmsgdimlcbsg":
                            Localtable = (NameValueCollection)htPMSGDIMLCBSG[lInstance];
                            break;
                        case "rqctvwmlcbsg":
                            Localtable = (NameValueCollection)htRQCTVWMLCBSG[lInstance];
                            break;
                        case "rqprctmlcbsg":
                            Localtable = (NameValueCollection)htRQPRCTMLCBSG[lInstance];
                            break;
                        case "rqsgdimlcbsg":
                            Localtable = (NameValueCollection)htRQSGDIMLCBSG[lInstance];
                            break;
                        case "rsscmbmlcbsg":
                            Localtable = (NameValueCollection)htRSSCMBMLCBSG[lInstance];
                            break;
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSachapisrinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSachapisrinit(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\achapisrinit.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

