/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :apiconsumerhub_cr.cs
* Code Generated on         :12/06/2022 11:36:49
* Code Generated From       :ramco/PLF/ACH_ECR_00083/techwarcnv56\inst2/sa/Rvw20AppDB/TECHWARCNV56
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Diagnostics;
using System.Reflection;
using System.EnterpriseServices;
using com.ramco.vw.apiconsumerhub.trans;
using com.ramco.vw.tp.CRUtil;

[assembly: AssemblyDescription("ramco/PLF/Engineering/ACH_ECR_00083/apiconsumerhub/TECHWARCNV56/06-12-2022 11:35:51/1E293F9A-8FA8-4B56-B386-CCAC76ECEF9F")]
[assembly: AssemblyTitle("ramco/PLF/Engineering/ACH_ECR_00083/apiconsumerhub/TECHWARCNV56/06-12-2022 11:35:51/1E293F9A-8FA8-4B56-B386-CCAC76ECEF9F")]
[assembly:ApplicationActivation(ActivationOption.Server)]

[assembly:ApplicationAccessControlAttribute(false,AccessChecksLevel=AccessChecksLevelOption.ApplicationComponent)]
 
namespace com.ramco.vw.apiconsumerhub.cr
{
    [Transaction(TransactionOption.Supported, Isolation = TransactionIsolationLevel.ReadCommitted)]
    [EventTrackingEnabled(true)]

    public class Capiconsumerhub_cr : ServicedComponent
    {
        public const int ATMA_SUCCESS = 0;
        public const int ATMA_FAILURE = 999;
        public const int ATMA_INVALID_SERVICE = 998;
        DefaultTraceListener output = new DefaultTraceListener();

        public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, ref string szOutMtd)
        {
            try
            {
                szOutMtd = "";
                switch (szServiceName.ToLower().Trim())
                {
					case ("achapisrapitrg"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrapitrg service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrapitrg service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrinit"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrpmsave"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrpmsave service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrpmsave service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrrqsave"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrrqsave service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrrqsave service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrrssave"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrrssave service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrrssave service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisrservi1"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisrservi1 service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisrservi1 service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achapisruidesh"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achapisruidesh service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achapisruidesh service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achescrsrcustnm"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achescrsrcustnm service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achescrsrcustnm service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achescrsrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achescrsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achescrsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achescrsrinit"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achescrsrinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achescrsrinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achescrsrprojnm"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achescrsrprojnm service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achescrsrprojnm service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsractdes"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsractdes service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsractdes service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrargqry"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrargqry service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrargqry service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrargsav"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrargsav service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrargsav service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrflddef"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrflddef service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrflddef service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrfldqry"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrfldqry service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrfldqry service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrfldsav"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrfldsav service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrfldsav service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrfolimp"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrfolimp service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrfolimp service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrimpsch"):
                        using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                        {
                            if (apiconsumerhub0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrimpsch service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrimpsch service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrinctrl"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrinctrl service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrinctrl service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrinit"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrqrynam"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrqrynam service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrqrynam service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrqrysav"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrqrysav service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrqrysav service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrrepsav"):
                        using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                        {
                            if (apiconsumerhub0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrrepsav service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrrepsav service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrsdl"):
                        using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                        {
                            if (apiconsumerhub0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrsdl service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrsdl service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsrtsknam"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsrtsknam service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsrtsknam service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlsruides"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlsruides service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlsruides service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achgqlstdsrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achgqlstdsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achgqlstdsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achimpgqlsrimpfol"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achimpgqlsrimpfol service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achimpgqlsrimpfol service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achimpschsrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achimpschsrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achimpschsrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achimpschsrimpfol"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achimpschsrimpfol service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achimpschsrimpfol service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achimpschsrimport"):
                        using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                        {
                            if (apiconsumerhub0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achimpschsrimport service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achimpschsrimport service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achimpschsrmlimp"):
                        using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                        {
                            if (apiconsumerhub0.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achimpschsrmlimp service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achimpschsrmlimp service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achmscrsrrqmdtp"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achmscrsrrqmdtp service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achmscrsrrqmdtp service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achmscrsrrscode"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achmscrsrrscode service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achmscrsrrscode service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achmscrsrrsmdtp"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achmscrsrrsmdtp service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achmscrsrrsmdtp service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissractivi"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissractivi service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissractivi service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissrfet"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissrfet service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissrfet service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissrinit"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissrinit service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissrinit service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissrsav"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissrsav service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissrsav service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissrschm"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissrschm service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissrschm service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissrtaskna"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissrtaskna service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissrtaskna service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					case ("achvissruiname"):
                        using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                        {
                            if (apiconsumerhub1.ProcessDocument(szInMtd, szServiceName, szSessionToken, out szOutMtd) == 0)
                            {
                                output.WriteLine("APICONSUMERHUB.Capiconsumerhub_cr.ProcessDocument - achvissruiname service executed successfully.");
                                return ATMA_SUCCESS;
                            }
                            else
                            {
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - achvissruiname service executed with a failure.");
                                return ATMA_FAILURE;
                            }
                        }
					default:
                        int iType = -1;
                        string szPSXmlPath = string.Empty;
                        CRUtil.PassiveServiceCheck(szServiceName, ref iType, ref szPSXmlPath);
                        switch (iType)
                        {
                            case 0:
                                using (Capiconsumerhub0 apiconsumerhub0 = new Capiconsumerhub0())
                                {
                                    if (apiconsumerhub0.PassiveProcessDocument(szInMtd, szPSXmlPath, szSessionToken, out szOutMtd) == 0)
                                    {
                                        output.WriteLine("apiconsumerhub.Capiconsumerhub_cr.PassiveProcessDocument - " + szServiceName + " service executed successfully.");
                                        return ATMA_SUCCESS;
                                    }
                                    else
                                    {
                                        output.WriteLine("Capiconsumerhub_cr.PassiveProcessDocument - " + szServiceName + " service executed with a failure.");
                                        return ATMA_FAILURE;
                                    }
                                }
                            case 1:
                                using (Capiconsumerhub1 apiconsumerhub1 = new Capiconsumerhub1())
                                {
                                    if (apiconsumerhub1.PassiveProcessDocument(szInMtd, szPSXmlPath, szSessionToken, out szOutMtd) == 0)
                                    {
                                        output.WriteLine("apiconsumerhub.Capiconsumerhub_cr.ProcessDocument - " + szServiceName + " service executed successfully.");
                                        return ATMA_SUCCESS;
                                    }
                                    else
                                    {
                                        output.WriteLine("Capiconsumerhub_cr.PassiveProcessDocument - " + szServiceName + " service executed with a failure.");
                                        return ATMA_FAILURE;
                                    }
                                }
                            default:
                                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - Service referred Is Not part of the runtime component-" + szServiceName);
                                return ATMA_INVALID_SERVICE;
                        }
                }
            }
            catch (Exception e)
            {
                output.WriteLine("Capiconsumerhub_cr.ProcessDocument - General Exception :");
                output.WriteLine(e.Message);
                szOutMtd = "";
                return ATMA_FAILURE;
            }
            finally
            {
                base.Dispose(true);
            }
        }

        public Capiconsumerhub_cr()
        {
        }
    }
}
