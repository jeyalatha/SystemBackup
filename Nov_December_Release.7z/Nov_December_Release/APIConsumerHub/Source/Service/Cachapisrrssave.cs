/***********************************************************************************************************
Copyright @2004, RAMCO SYSTEMS,  All rights reserved
Author                   :   Ramco.VwPlf.DeveloperConsole
Application/Module Name  :   Cachapisrrssave.cs
Code Generated From      :   ramco\PLF\ACH_ECR_00083\techwarcnv56\inst2\sa\Rvw20AppDB\TECHWARCNV56
Revision/Version #       :   
Purpose                  :   Service Implementation
Modifications            :   
Modifier Name & Date     :   
***********************************************************************************************************/
namespace com.ramco.vw.apiconsumerhub.service
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using System.Xml;
    using com.ramco.vw.tp;
    using System.Reflection;
    using com.ramco.vw.apiconsumerhub.ehs;

    public class Cachapisrrssave : CUtil
    {
        private double result;
        private long lSPErrorID;
        private long nRecCount = 0;
        private long nLoop;
        private long nMax = 1;
        private long nErrMax = 0;
        private long lISLoop = 0;
        private long lISOutRecCount = 0;
        private long lInstExists = 0;
        private long lRetVal = 0;
        private long lValue = 0;
        private System.Nullable<double> dValue = 0;
        private string defaultValue = string.Empty;
        private string sISKeyValue = string.Empty;
        private string szErrorDesc;
        private string szErrSrc;
        private string sValue = string.Empty;
        private System.IO.MemoryStream mStream = null;
        private System.Collections.Specialized.NameValueCollection nvcTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmp = null;
        private System.Collections.Specialized.NameValueCollection nvcISTmpIS = null;
        private System.Collections.Specialized.NameValueCollection nvcFilterText = null;
        private System.Collections.Specialized.NameValueCollection nvcTmpCrtl = null;
        public System.Collections.Specialized.NameValueCollection nvc_HSEG = new System.Collections.Specialized.NameValueCollection();
        public System.Collections.Hashtable htRSMLML = new System.Collections.Hashtable();
        public System.Collections.Hashtable htRSMLMLOUT = new System.Collections.Hashtable();
        private string s_HSEGapiexecsequence = "0";
        private string s_HSEGrsml_fprowno = "0";
        private string modeFlagValue = string.Empty;
        public Cachapisrrssave()
        {
            base.iEDKESEngineInit("achapisrrssave", "apiconsumerhub");
        }
        private string GetBOD(bool allSegments)
        {
            string RetVal = string.Empty;
            System.IO.StreamReader read = null;
            try
            {
                base.WriteProfiler(String.Format("Executing GetBOD Method at " + System.DateTime.Now.ToString()));
                this.mStream = new System.IO.MemoryStream();
                this.writer = new System.Xml.XmlTextWriter(mStream, null);
                writer.WriteStartElement("VW-TD");
                base.BuildContextSegments();
                if (allSegments)
                {
                    this.BuildOutSegments();
                }
                base.BuildErrorSegments();
                this.writer.WriteEndElement();
                this.writer.Flush();
                mStream.Position = 0;
                read = new System.IO.StreamReader(this.mStream);
                RetVal = read.ReadToEnd();
                return RetVal;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in GetBOD - {0}", e.Message));
                throw new System.Exception(string.Format("General exception in GetBOD - {0}", e.Message));
            }
            finally
            {
                if ((read != null))
                {
                    read.Close();
                }
                if ((writer != null))
                {
                    writer.Close();
                }
                if ((mStream != null))
                {
                    mStream.Close();
                    mStream = null;
                }
            }
        }
        private void BuildOutSegments()
        {
            try
            {
                System.Collections.Specialized.NameValueCollection nvcTmp = null;
                bool iEDKESSegExists;
                base.WriteProfiler(String.Format("Executing BuildOutSegments Method at " + System.DateTime.Now.ToString()));
                if ((this.nvc_HSEG != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("_hseg", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("_hseg");
                    this.writer.WriteAttributeString("RecordCount", "1");
                    this.writer.WriteAttributeString("seq", "2");
                    this.writer.WriteStartElement("I2");
                    this.writer.WriteAttributeString("apiexecsequence", System.Convert.ToString(nvc_HSEG["apiexecsequence"]));
                    this.writer.WriteAttributeString("apioperationid", System.Convert.ToString(nvc_HSEG["apioperationid"]));
                    this.writer.WriteAttributeString("apispecid", System.Convert.ToString(nvc_HSEG["apispecid"]));
                    this.writer.WriteAttributeString("apispecname", System.Convert.ToString(nvc_HSEG["apispecname"]));
                    this.writer.WriteAttributeString("apispecversion", System.Convert.ToString(nvc_HSEG["apispecversion"]));
                    this.writer.WriteAttributeString("componentdesc", System.Convert.ToString(nvc_HSEG["componentdesc"]));
                    this.writer.WriteAttributeString("componentname", System.Convert.ToString(nvc_HSEG["componentname"]));
                    this.writer.WriteAttributeString("custname", System.Convert.ToString(nvc_HSEG["custname"]));
                    this.writer.WriteAttributeString("customercls", System.Convert.ToString(nvc_HSEG["customercls"]));
                    this.writer.WriteAttributeString("customername", System.Convert.ToString(nvc_HSEG["customername"]));
                    this.writer.WriteAttributeString("doccls", System.Convert.ToString(nvc_HSEG["doccls"]));
                    this.writer.WriteAttributeString("docnametpid", System.Convert.ToString(nvc_HSEG["docnametpid"]));
                    this.writer.WriteAttributeString("docno", System.Convert.ToString(nvc_HSEG["docno"]));
                    this.writer.WriteAttributeString("documentno", System.Convert.ToString(nvc_HSEG["documentno"]));
                    this.writer.WriteAttributeString("engg_activity_name_hdr", System.Convert.ToString(nvc_HSEG["engg_activity_name_hdr"]));
                    this.writer.WriteAttributeString("engg_api_trigger", System.Convert.ToString(nvc_HSEG["engg_api_trigger"]));
                    this.writer.WriteAttributeString("engg_task_desc", System.Convert.ToString(nvc_HSEG["engg_task_desc"]));
                    this.writer.WriteAttributeString("engg_task_name", System.Convert.ToString(nvc_HSEG["engg_task_name"]));
                    this.writer.WriteAttributeString("engg_task_type", System.Convert.ToString(nvc_HSEG["engg_task_type"]));
                    this.writer.WriteAttributeString("engg_ui_desc_hdr", System.Convert.ToString(nvc_HSEG["engg_ui_desc_hdr"]));
                    this.writer.WriteAttributeString("engg_ui_name_hdr", System.Convert.ToString(nvc_HSEG["engg_ui_name_hdr"]));
                    this.writer.WriteAttributeString("guid", System.Convert.ToString(nvc_HSEG["guid"]));
                    this.writer.WriteAttributeString("hdnrt_stcontrol", System.Convert.ToString(nvc_HSEG["hdnrt_stcontrol"]));
                    this.writer.WriteAttributeString("operationcls", System.Convert.ToString(nvc_HSEG["operationcls"]));
                    this.writer.WriteAttributeString("operationtpid", System.Convert.ToString(nvc_HSEG["operationtpid"]));
                    this.writer.WriteAttributeString("operationtxt", System.Convert.ToString(nvc_HSEG["operationtxt"]));
                    this.writer.WriteAttributeString("pathname", System.Convert.ToString(nvc_HSEG["pathname"]));
                    this.writer.WriteAttributeString("processdesc", System.Convert.ToString(nvc_HSEG["processdesc"]));
                    this.writer.WriteAttributeString("processname", System.Convert.ToString(nvc_HSEG["processname"]));
                    this.writer.WriteAttributeString("projectcls", System.Convert.ToString(nvc_HSEG["projectcls"]));
                    this.writer.WriteAttributeString("projectname", System.Convert.ToString(nvc_HSEG["projectname"]));
                    this.writer.WriteAttributeString("projname", System.Convert.ToString(nvc_HSEG["projname"]));
                    this.writer.WriteAttributeString("psname", System.Convert.ToString(nvc_HSEG["psname"]));
                    this.writer.WriteAttributeString("psseqno", System.Convert.ToString(nvc_HSEG["psseqno"]));
                    this.writer.WriteAttributeString("servicename", System.Convert.ToString(nvc_HSEG["servicename"]));
                    this.writer.WriteAttributeString("treemode", System.Convert.ToString(nvc_HSEG["treemode"]));
                    if (iEDKESSegExists)
                    {
                        base.BuildOutSegments("_hseg", nvc_HSEG);
                    }
                    this.writer.WriteEndElement();
                    this.writer.WriteEndElement();
                }
                if ((this.htRSMLMLOUT != null))
                {
                    iEDKESSegExists = false;
                    if (base.iEDKServiceES)
                    {
                        base.IsOutSegmentExists("rsmlmlout", out iEDKESSegExists);
                    }
                    this.writer.WriteStartElement("rsmlmlout");
                    this.writer.WriteAttributeString("RecordCount", htRSMLMLOUT.Count.ToString());
                    this.writer.WriteAttributeString("seq", "2");
                    for (long reccount = 1; (reccount <= htRSMLMLOUT.Count); reccount = (reccount + 1))
                    {
                        nvcTmp = (NameValueCollection)htRSMLMLOUT[reccount];
                        if ((nvcTmp != null))
                        {
                            this.writer.WriteStartElement("I2");
                            this.writer.WriteAttributeString("responseml_nex", System.Convert.ToString(nvcTmp["responseml_nex"]));
                            this.writer.WriteAttributeString("responseml_nid", System.Convert.ToString(nvcTmp["responseml_nid"]));
                            this.writer.WriteAttributeString("responseml_pnid", System.Convert.ToString(nvcTmp["responseml_pnid"]));
                            this.writer.WriteAttributeString("rs_constant", System.Convert.ToString(nvcTmp["rs_constant"]));
                            this.writer.WriteAttributeString("rs_control_type", System.Convert.ToString(nvcTmp["rs_control_type"]));
                            this.writer.WriteAttributeString("rs_controlid", System.Convert.ToString(nvcTmp["rs_controlid"]));
                            this.writer.WriteAttributeString("rs_ctrlbtsynonym", System.Convert.ToString(nvcTmp["rs_ctrlbtsynonym"]));
                            this.writer.WriteAttributeString("rs_dataitemname", System.Convert.ToString(nvcTmp["rs_dataitemname"]));
                            this.writer.WriteAttributeString("rs_flattened_schema", System.Convert.ToString(nvcTmp["rs_flattened_schema"]));
                            this.writer.WriteAttributeString("rs_flattened_schema_cmb", System.Convert.ToString(nvcTmp["rs_flattened_schema_cmb"]));
                            this.writer.WriteAttributeString("rs_identifier", System.Convert.ToString(nvcTmp["rs_identifier"]));
                            this.writer.WriteAttributeString("rs_ismandatory", System.Convert.ToString(nvcTmp["rs_ismandatory"]));
                            this.writer.WriteAttributeString("rs_page_btsynonym", System.Convert.ToString(nvcTmp["rs_page_btsynonym"]));
                            this.writer.WriteAttributeString("rs_parameterdatatype", System.Convert.ToString(nvcTmp["rs_parameterdatatype"]));
                            this.writer.WriteAttributeString("rs_parentschemaname", System.Convert.ToString(nvcTmp["rs_parentschemaname"]));
                            this.writer.WriteAttributeString("rs_schemacategory", System.Convert.ToString(nvcTmp["rs_schemacategory"]));
                            this.writer.WriteAttributeString("rs_schemaname", System.Convert.ToString(nvcTmp["rs_schemaname"]));
                            this.writer.WriteAttributeString("rs_schematype", System.Convert.ToString(nvcTmp["rs_schematype"]));
                            this.writer.WriteAttributeString("rs_schematypecategory", System.Convert.ToString(nvcTmp["rs_schematypecategory"]));
                            this.writer.WriteAttributeString("rs_sdi_flow_direction", System.Convert.ToString(nvcTmp["rs_sdi_flow_direction"]));
                            this.writer.WriteAttributeString("rs_section_btsynonym", System.Convert.ToString(nvcTmp["rs_section_btsynonym"]));
                            this.writer.WriteAttributeString("rs_segment_instance", System.Convert.ToString(nvcTmp["rs_segment_instance"]));
                            this.writer.WriteAttributeString("rs_segment_name", System.Convert.ToString(nvcTmp["rs_segment_name"]));
                            this.writer.WriteAttributeString("rs_segmentname", System.Convert.ToString(nvcTmp["rs_segmentname"]));
                            this.writer.WriteAttributeString("rs_viewname", System.Convert.ToString(nvcTmp["rs_viewname"]));
                            if (iEDKESSegExists)
                            {
                                base.BuildOutSegments("rsmlmlout", nvcTmp);
                            }
                            this.writer.WriteEndElement();
                        }
                        nvcTmp = null;
                    }
                    this.writer.WriteEndElement();
                }
                if (base.iEDKServiceES)
                {
                    base.BuildOutSegments(string.Empty, null);
                }
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(String.Format("General Exception in BuildOutSegments - " + e.Message));
                base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in BuildOutSegments - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                throw new Exception(e.Message, e);
            }
        }
        public override int getFieldValue(string SegName, long InstNumber, string DataItem, string DIValue)
        {
            try
            {
                bool IsMand = false;
                SegName = SegName.ToLower();
                DataItem = DataItem.ToLower().Trim();
                if ((DIValue == null))
                {
                    DIValue = string.Empty;
                }
                switch (SegName)
                {
                    case "_hseg":
                        switch (DataItem)
                        {
                            case "apiexecsequence":
                                IsMand = false;
                                defaultValue = "-915";
                                break;
                            case "apioperationid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "apispecversion":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "componentdesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "componentname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "custname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "customercls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "customername":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "doccls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "docnametpid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "docno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "documentno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_activity_name_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_api_trigger":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_desc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_task_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_desc_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "engg_ui_name_hdr":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "guid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "hdnrt_stcontrol":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationcls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationtpid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "operationtxt":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "pathname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "processdesc":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "processname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projectcls":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projectname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "projname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "psseqno":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "servicename":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "treemode":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                else
                                {
                                    base.WriteProfiler(string.Format("RVWException in getFieldValue - DataItem - {0}  is not part of the Service", DataItem));
                                    nvc_HSEG[DataItem] = DIValue;
                                }
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        nvc_HSEG[DataItem] = DIValue;
                        return 0;
                    case "rsmlml":
                        switch (DataItem)
                        {
                            case "modeflag":
                                IsMand = false;
                                defaultValue = "S";
                                break;
                            case "responseml_nex":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "responseml_nid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "responseml_pnid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_constant":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_control_type":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_controlid":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_ctrlbtsynonym":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_dataitemname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_flattened_schema":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_flattened_schema_cmb":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_identifier":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_ismandatory":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_page_btsynonym":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_parameterdatatype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_parentschemaname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_schemacategory":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_schemaname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_schematype":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_schematypecategory":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_sdi_flow_direction":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_section_btsynonym":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_segment_instance":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_segment_name":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_segmentname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            case "rs_viewname":
                                IsMand = false;
                                defaultValue = "~#~";
                                break;
                            default:
                                if (base.iEDKServiceES)
                                {
                                    return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                                }
                                this.nvcTmp = (NameValueCollection)htRSMLML[InstNumber];
                                if ((this.nvcTmp == null))
                                {
                                    nvcTmp = new NameValueCollection();
                                }
                                nvcTmp[DataItem] = DIValue;
                                htRSMLML[InstNumber] = nvcTmp;
                                nvcTmp = null;
                                return 0;
                                break;
                        }
                        if ((base.checkforvalidate(ref DIValue, IsMand, defaultValue) == false))
                        {
                            base.WriteProfiler(String.Format("RVWException in getFieldValue - No Value is passed for the mandatory DataItem - " + DataItem + " for the segment - " + SegName));
                            base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Value is passed for the Mandatory DataItem - " + DataItem + " for the segment - " + SegName), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            return 1;
                        }
                        this.nvcTmp = (NameValueCollection)htRSMLML[InstNumber];
                        if ((this.nvcTmp == null))
                        {
                            nvcTmp = new NameValueCollection();
                        }
                        nvcTmp[DataItem] = DIValue;
                        htRSMLML[InstNumber] = nvcTmp;
                        nvcTmp = null;
                        return 0;
                    default:
                        if (((base.iEDKServiceES == true)
                                    && (base.iEDKInSegment == true)))
                        {
                            if ((base.GetSegmentType(SegName) != -1))
                            {
                                return base.getFieldValue(SegName, InstNumber, DataItem, DIValue);
                            }
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("RVWException in getFieldValue - No Such Segment Name " + SegName + " is Found in the Service"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return 1;
                        break;
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General exception in getFieldValue - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getFieldValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return 1;
            }
        }
        public override int GetSegmentType(string szSegName)
        {
            int type = -1;
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    type = 0;
                    break;
                case "rsmlml":
                    type = 1;
                    break;
                case "rsmlmlout":
                    type = 1;
                    break;
                default:
                    return base.GetSegmentType(szSegName);
                    break;
            }
            return type;
        }
        public override long GetSegmentRecCount(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "rsmlml":
                    return htRSMLML.Count;
                    break;
                case "rsmlmlout":
                    return htRSMLMLOUT.Count;
                    break;
                default:
                    return base.GetSegmentRecCount(szSegName);
                    break;
            }
        }
        public override System.Collections.Hashtable GetMultiSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "rsmlml":
                    return this.htRSMLML;
                case "rsmlmlout":
                    return this.htRSMLMLOUT;
                default:
                    return base.GetMultiSegment(szSegName);
            }
        }
        public override System.Collections.Specialized.NameValueCollection GetSingleSegment(string szSegName)
        {
            szSegName = szSegName.ToLower().Trim();
            switch (szSegName)
            {
                case "_hseg":
                    return this.nvc_HSEG;
                default:
                    return base.GetSingleSegment(szSegName);
            }
        }
        public override string GetSegmentValue(string szSegName, long lnInstNumber, string szDataItem)
        {
            try
            {
                string szValue = string.Empty;
                szSegName = szSegName.ToLower().Trim();
                szDataItem = szDataItem.ToLower().Trim();
                switch (szSegName)
                {
                    case "fw_context":
                        return nvcFW_CONTEXT[szDataItem];
                    case "_hseg":
                        return nvc_HSEG[szDataItem];
                        break;
                    case "rsmlml":
                        System.Collections.Specialized.NameValueCollection nvcTmprsmlml = (NameValueCollection)htRSMLML[lnInstNumber];
                        return nvcTmprsmlml[szDataItem];
                        break;
                    case "rsmlmlout":
                        System.Collections.Specialized.NameValueCollection nvcTmprsmlmlout = (NameValueCollection)htRSMLMLOUT[lnInstNumber];
                        return nvcTmprsmlmlout[szDataItem];
                        break;
                    default:
                        szValue = base.GetSegmentValue(szSegName, lnInstNumber, szDataItem);
                        if ((szValue != null))
                        {
                            return szValue;
                        }
                        base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General Exception in GetSegmentValue"), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return string.Empty;
                        break;
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("RVWException in getSegmentValue - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return string.Empty;
            }
        }
        private int ValidateMandatorySegment()
        {
            return 0;
        }
        private int FillUnMappedDataItems()
        {
            try
            {
                if (base.iEDKServiceES)
                {
                    base.FillUnMappedDataItems();
                }
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, e.Source, CUtil.STOP_PROCESSING, string.Format("RVWException in FillUnMappedDataitem - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
            return 0;
        }
        public int ProcessService(string szInMtd, string szSessionToken, out string szOutMtd)
        {
            bool bServicePostResult = true;
            szOutMtd = string.Empty;
            try
            {
                Type myType = (this).GetType();
                PropertyInfo pDeliverableVersionInCUtil = myType.GetProperty("DeliverableVersion", BindingFlags.NonPublic | BindingFlags.Instance);
                if (((pDeliverableVersionInCUtil != null)
                            && (pDeliverableVersionInCUtil.CanWrite == true)))
                {
                    pDeliverableVersionInCUtil.SetValue(this, "ACH_ECR_00083", null);
                }
                base.WriteProfiler(String.Format("Service achapisrrssave Started at " + System.DateTime.Now.ToString()));
                if ((base.bIsInteg == false))
                {
                    base.unpackBOD(szInMtd);
                }
                base.Service_Pre_Process(string.Empty, szSessionToken, ref szComponentName, ref szServiceName, ref szLangID, ref szCompInst, ref szOUI, ref szSecToken, ref szUser, ref szConnectionString, ref szTxnID, ref szRole);
                this.ValidateMandatorySegment();
                if ((base.bIsInteg == false))
                {
                    this.FillUnMappedDataItems();
                }
                this.ProcessPS1();
                this.ProcessPS2();
                this.ProcessPS3();
                return ATMA_SUCCESS;
            }
            catch (CRVWException rvwe)
            {
                base.WriteProfiler(String.Format("General Exception in ProcessService - " + rvwe.Message));
                return ATMA_FAILURE;
            }
            catch (System.Exception e)
            {
                try
                {
                    base.Set_Error_Info(0, FRAMEWORK_ERROR, STOP_PROCESSING, String.Format("General exception in ProcessService - " + e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                catch (System.Exception)
                {
                    base.WriteProfiler(String.Format("General Exception in ProcessService - " + e.Message));
                }
                return ATMA_FAILURE;
            }
            finally
            {
                base.WriteProfiler("Before calling post process");
                try
                {
                    szOutMtd = string.Empty;
                    bServicePostResult = base.Service_Post_Process();
                    if ((base.bIsInteg == false))
                    {
                        szOutMtd = this.GetBOD(bServicePostResult);
                    }
                }
                catch (System.Exception e)
                {
                    szOutMtd = string.Empty;
                    base.WriteProfiler(e.Message);
                }
                base.WriteProfiler("Before exit of finally");
                base.WriteProfiler(String.Format("Service achapisrrssave Ended at  - " + System.DateTime.Now.ToString()));
                base.Out.Dispose();
            }
        }
        private void ProcessPS1()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 1;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 1
                // Starting to execute the BR - 1  under the process section - 1
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 1;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsrssave");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apiexecsequence"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGapiexecsequence = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGapiexecsequence);
                            base.Parameters("@apiexecsequence", DBType.Int, 32, s_HSEGapiexecsequence);
                            sValue = nvc_HSEG["apioperationid"];
                            base.Parameters("@apioperationid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentdesc"];
                            base.Parameters("@componentdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["customercls"];
                            base.Parameters("@customercls", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["customername"];
                            base.Parameters("@customername", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["doccls"];
                            base.Parameters("@doccls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docnametpid"];
                            base.Parameters("@docnametpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docno"];
                            base.Parameters("@docno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_api_trigger"];
                            base.Parameters("@engg_api_trigger", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["operationcls"];
                            base.Parameters("@operationcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtpid"];
                            base.Parameters("@operationtpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtxt"];
                            base.Parameters("@operationtxt", DBType.NVarchar, 100, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processdesc"];
                            base.Parameters("@processdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projectcls"];
                            base.Parameters("@projectcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["projectname"];
                            base.Parameters("@projectname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 1 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtrssavehdrsav", nLoop, nMax));
                        base.Execute_SP(true, "achapisprssavehdrsav", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127268, 1, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127268, 1, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("apiexecsequence");
                                nvc_HSEG["apiexecsequence"] = sValue;
                                sValue = this.GetValue("apioperationid");
                                nvc_HSEG["apioperationid"] = sValue;
                                sValue = this.GetValue("apispecid");
                                nvc_HSEG["apispecid"] = sValue;
                                sValue = this.GetValue("apispecname");
                                nvc_HSEG["apispecname"] = sValue;
                                sValue = this.GetValue("apispecversion");
                                nvc_HSEG["apispecversion"] = sValue;
                                sValue = this.GetValue("asctrl_fprowno");
                                nvc_HSEG["asctrl_fprowno"] = sValue;
                                sValue = this.GetValue("componentdesc");
                                nvc_HSEG["componentdesc"] = sValue;
                                sValue = this.GetValue("componentname");
                                nvc_HSEG["componentname"] = sValue;
                                sValue = this.GetValue("custname");
                                nvc_HSEG["custname"] = sValue;
                                sValue = this.GetValue("customercls");
                                nvc_HSEG["customercls"] = sValue;
                                sValue = this.GetValue("customername");
                                nvc_HSEG["customername"] = sValue;
                                sValue = this.GetValue("doccls");
                                nvc_HSEG["doccls"] = sValue;
                                sValue = this.GetValue("docnametpid");
                                nvc_HSEG["docnametpid"] = sValue;
                                sValue = this.GetValue("docno");
                                nvc_HSEG["docno"] = sValue;
                                sValue = this.GetValue("documentno");
                                nvc_HSEG["documentno"] = sValue;
                                sValue = this.GetValue("engg_activity_name_hdr");
                                nvc_HSEG["engg_activity_name_hdr"] = sValue;
                                sValue = this.GetValue("engg_api_trigger");
                                nvc_HSEG["engg_api_trigger"] = sValue;
                                sValue = this.GetValue("engg_task_desc");
                                nvc_HSEG["engg_task_desc"] = sValue;
                                sValue = this.GetValue("engg_task_name");
                                nvc_HSEG["engg_task_name"] = sValue;
                                sValue = this.GetValue("engg_task_type");
                                nvc_HSEG["engg_task_type"] = sValue;
                                sValue = this.GetValue("engg_ui_desc_hdr");
                                nvc_HSEG["engg_ui_desc_hdr"] = sValue;
                                sValue = this.GetValue("engg_ui_name_hdr");
                                nvc_HSEG["engg_ui_name_hdr"] = sValue;
                                sValue = this.GetValue("guid");
                                nvc_HSEG["guid"] = sValue;
                                sValue = this.GetValue("hdnrt_stcontrol");
                                nvc_HSEG["hdnrt_stcontrol"] = sValue;
                                sValue = this.GetValue("lstcol_fprowno");
                                nvc_HSEG["lstcol_fprowno"] = sValue;
                                sValue = this.GetValue("operationcls");
                                nvc_HSEG["operationcls"] = sValue;
                                sValue = this.GetValue("operationtpid");
                                nvc_HSEG["operationtpid"] = sValue;
                                sValue = this.GetValue("operationtxt");
                                nvc_HSEG["operationtxt"] = sValue;
                                sValue = this.GetValue("opestr_fprowno");
                                nvc_HSEG["opestr_fprowno"] = sValue;
                                sValue = this.GetValue("pathname");
                                nvc_HSEG["pathname"] = sValue;
                                sValue = this.GetValue("processdesc");
                                nvc_HSEG["processdesc"] = sValue;
                                sValue = this.GetValue("processname");
                                nvc_HSEG["processname"] = sValue;
                                sValue = this.GetValue("projectcls");
                                nvc_HSEG["projectcls"] = sValue;
                                sValue = this.GetValue("projectname");
                                nvc_HSEG["projectname"] = sValue;
                                sValue = this.GetValue("projname");
                                nvc_HSEG["projname"] = sValue;
                                sValue = this.GetValue("psname");
                                nvc_HSEG["psname"] = sValue;
                                sValue = this.GetValue("psseqno");
                                nvc_HSEG["psseqno"] = sValue;
                                sValue = this.GetValue("reqcvw_fprowno");
                                nvc_HSEG["reqcvw_fprowno"] = sValue;
                                sValue = this.GetValue("respar_fprowno");
                                nvc_HSEG["respar_fprowno"] = sValue;
                                sValue = this.GetValue("rsml_fprowno");
                                nvc_HSEG["rsml_fprowno"] = sValue;
                                sValue = this.GetValue("servicename");
                                nvc_HSEG["servicename"] = sValue;
                                sValue = this.GetValue("treemode");
                                nvc_HSEG["treemode"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 1 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127268, 1, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 1 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS2()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 2;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 2
                // Starting to execute the BR - 1  under the process section - 2
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 2;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 0;
                nMax = htRSMLML.Count;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsrssaversml");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        this.nvcTmp = (NameValueCollection)htRSMLML[nLoop];
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apiexecsequence"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGapiexecsequence = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGapiexecsequence);
                            base.Parameters("@apiexecsequence", DBType.Int, 32, s_HSEGapiexecsequence);
                            sValue = nvc_HSEG["apioperationid"];
                            base.Parameters("@apioperationid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentdesc"];
                            base.Parameters("@componentdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["customercls"];
                            base.Parameters("@customercls", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["customername"];
                            base.Parameters("@customername", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["doccls"];
                            base.Parameters("@doccls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docnametpid"];
                            base.Parameters("@docnametpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docno"];
                            base.Parameters("@docno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_api_trigger"];
                            base.Parameters("@engg_api_trigger", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["modeflag"];
                            base.Parameters("@modeflag", DBType.NVarchar, 2, sValue);
                            sValue = nvc_HSEG["operationcls"];
                            base.Parameters("@operationcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtpid"];
                            base.Parameters("@operationtpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtxt"];
                            base.Parameters("@operationtxt", DBType.NVarchar, 100, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processdesc"];
                            base.Parameters("@processdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projectcls"];
                            base.Parameters("@projectcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["projectname"];
                            base.Parameters("@projectname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["responseml_nex"];
                            base.Parameters("@responseml_nex", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["responseml_nid"];
                            base.Parameters("@responseml_nid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvcTmp["responseml_pnid"];
                            base.Parameters("@responseml_pnid", DBType.NVarchar, String.IsNullOrEmpty(sValue) ? 0 : sValue.Length, sValue);
                            sValue = nvcTmp["rs_constant"];
                            base.Parameters("@rs_constant", DBType.NVarchar, 100, sValue);
                            sValue = nvcTmp["rs_controlid"];
                            base.Parameters("@rs_controlid", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_control_type"];
                            base.Parameters("@rs_control_type", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_ctrlbtsynonym"];
                            base.Parameters("@rs_ctrlbtsynonym", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_dataitemname"];
                            base.Parameters("@rs_dataitemname", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_flattened_schema"];
                            base.Parameters("@rs_flattened_schema", DBType.NVarchar, 2000, sValue);
                            sValue = nvcTmp["rs_flattened_schema_cmb"];
                            base.Parameters("@rs_flattened_schema_cmb", DBType.NVarchar, 500, sValue);
                            sValue = nvcTmp["rs_identifier"];
                            base.Parameters("@rs_identifier", DBType.NVarchar, 20, sValue);
                            sValue = nvcTmp["rs_ismandatory"];
                            base.Parameters("@rs_ismandatory", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["rs_page_btsynonym"];
                            base.Parameters("@rs_page_btsynonym", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_parameterdatatype"];
                            base.Parameters("@rs_parameterdatatype", DBType.NVarchar, 20, sValue);
                            sValue = nvcTmp["rs_parentschemaname"];
                            base.Parameters("@rs_parentschemaname", DBType.NVarchar, 100, sValue);
                            sValue = nvcTmp["rs_schemacategory"];
                            base.Parameters("@rs_schemacategory", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["rs_schemaname"];
                            base.Parameters("@rs_schemaname", DBType.NVarchar, 100, sValue);
                            sValue = nvcTmp["rs_schematype"];
                            base.Parameters("@rs_schematype", DBType.NVarchar, 100, sValue);
                            sValue = nvcTmp["rs_schematypecategory"];
                            base.Parameters("@rs_schematypecategory", DBType.NVarchar, 5, sValue);
                            sValue = nvcTmp["rs_sdi_flow_direction"];
                            base.Parameters("@rs_sdi_flow_direction", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_section_btsynonym"];
                            base.Parameters("@rs_section_btsynonym", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_segmentname"];
                            base.Parameters("@rs_segmentname", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_segment_instance"];
                            base.Parameters("@rs_segment_instance", DBType.NVarchar, 60, sValue);
                            sValue = nvcTmp["rs_segment_name"];
                            base.Parameters("@rs_segment_name", DBType.NVarchar, 20, sValue);
                            sValue = nvcTmp["rs_viewname"];
                            base.Parameters("@rs_viewname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["rsml_fprowno"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGrsml_fprowno = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGrsml_fprowno);
                            base.Parameters("@rsml_fprowno", DBType.Int, 32, s_HSEGrsml_fprowno);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 2 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtrssaversml", nLoop, nMax));
                        base.Execute_SP(true, "achapisprssaversml", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127269, 2, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127269, 2, 1);
                            }
                        }
                        try
                        {
                            // Current instance
                            nRecCount = 0;
                            nRecCount = nLoop;
                            if ((base.IsDataReader_Accessible() && base.Read()))
                            {
                                if (((iEDKServiceES
                                            && (psIndex != -1))
                                            && ((brIndex != -1)
                                            && (cBROutExists != -1))))
                                {
                                    base.ESResultsetBinding(psIndex, brIndex, null);
                                }
                                sValue = this.GetValue("rsml_fprowno");
                                nvc_HSEG["rsml_fprowno"] = sValue;
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 2 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127269, 2, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 2 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 2 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void ProcessPS3()
        {
            bool bpsflag;
            bool bmtflag = false;
            bool bBRExec;
            int psIndex = 0;
            int brIndex = 0;
            int psSeqNo = 3;
            int brSeqNo = 0;
            bool sysfprowno = false;
            bool ExecuteSpFlag = false;
            try
            {
                // Starting to execute default style process section 3
                // Starting to execute the BR - 1  under the process section - 3
                psIndex = -1;
                brIndex = -1;
                psSeqNo = 3;
                brSeqNo = 1;
                bBRExec = true;
                ExecuteSpFlag = true;
                nMax = 1;
                try
                {
                    if (iEDKServiceES)
                    {
                        psIndex = base.IsProcessSectionExists("achpsrssavepsref");
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 0, 0);
                    }
                    int cBROutExists = -1;
                    int cBRInExists = -1;
                    if ((base.iEDKServiceES
                                && (psIndex != -1)))
                    {
                        base.PrepareCBRForExecution(psIndex, brSeqNo, out brIndex, out cBRInExists, out cBROutExists, ref nMax);
                    }
                    for (nLoop = 1; (nLoop <= nMax); nLoop = (nLoop + 1))
                    {
                        // Execute the Method
                        if (((iEDKServiceES
                                    && (psIndex != -1))
                                    && (brIndex != -1)))
                        {
                            bBRExec = true;
                            base.EvaluateBLForBR(psIndex, brIndex, nLoop, out bBRExec);
                            if ((bBRExec == false))
                            {
                                continue;
                            }
                        }
                        this.CreateCommand();
                        try
                        {
                            base.Parameters("@ctxt_ouinstance", DBType.NVarchar, 4, szOUI);
                            base.Parameters("@ctxt_user", DBType.NVarchar, 30, szUser);
                            base.Parameters("@ctxt_language", DBType.Int, 32, szLangID);
                            base.Parameters("@ctxt_service", DBType.NVarchar, 32, szServiceName);
                            base.Parameters("@ctxt_role", DBType.NVarchar, 30, szRole);
                            sValue = nvc_HSEG["apiexecsequence"];
                            // Code Added for Backward Compatibility with DNA. Model Related Issues , old value to be retained
                            s_HSEGapiexecsequence = (Double.TryParse(sValue, out result) == true ? sValue : s_HSEGapiexecsequence);
                            base.Parameters("@apiexecsequence", DBType.Int, 32, s_HSEGapiexecsequence);
                            sValue = nvc_HSEG["apioperationid"];
                            base.Parameters("@apioperationid", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["apispecid"];
                            base.Parameters("@apispecid", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["apispecname"];
                            base.Parameters("@apispecname", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["apispecversion"];
                            base.Parameters("@apispecversion", DBType.NVarchar, 4, sValue);
                            sValue = nvc_HSEG["componentdesc"];
                            base.Parameters("@componentdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["componentname"];
                            base.Parameters("@componentname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["custname"];
                            base.Parameters("@custname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["customercls"];
                            base.Parameters("@customercls", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["customername"];
                            base.Parameters("@customername", DBType.NVarchar, 300, sValue);
                            sValue = nvc_HSEG["doccls"];
                            base.Parameters("@doccls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docnametpid"];
                            base.Parameters("@docnametpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["docno"];
                            base.Parameters("@docno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["documentno"];
                            base.Parameters("@documentno", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_activity_name_hdr"];
                            base.Parameters("@engg_activity_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_api_trigger"];
                            base.Parameters("@engg_api_trigger", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_task_desc"];
                            base.Parameters("@engg_task_desc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_task_name"];
                            base.Parameters("@engg_task_name", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["engg_task_type"];
                            base.Parameters("@engg_task_type", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["engg_ui_desc_hdr"];
                            base.Parameters("@engg_ui_desc_hdr", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["engg_ui_name_hdr"];
                            base.Parameters("@engg_ui_name_hdr", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["guid"];
                            base.Parameters("@guid", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["hdnrt_stcontrol"];
                            base.Parameters("@hdnrt_stcontrol", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["operationcls"];
                            base.Parameters("@operationcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtpid"];
                            base.Parameters("@operationtpid", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["operationtxt"];
                            base.Parameters("@operationtxt", DBType.NVarchar, 100, sValue);
                            sValue = nvc_HSEG["pathname"];
                            base.Parameters("@pathname", DBType.NVarchar, 500, sValue);
                            sValue = nvc_HSEG["processdesc"];
                            base.Parameters("@processdesc", DBType.NVarchar, 255, sValue);
                            sValue = nvc_HSEG["processname"];
                            base.Parameters("@processname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projectcls"];
                            base.Parameters("@projectcls", DBType.NVarchar, 20, sValue);
                            sValue = nvc_HSEG["projectname"];
                            base.Parameters("@projectname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["projname"];
                            base.Parameters("@projname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psname"];
                            base.Parameters("@psname", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["psseqno"];
                            base.Parameters("@psseqno", DBType.NVarchar, 5, sValue);
                            sValue = nvc_HSEG["servicename"];
                            base.Parameters("@servicename", DBType.NVarchar, 60, sValue);
                            sValue = nvc_HSEG["treemode"];
                            base.Parameters("@treemode", DBType.NVarchar, 60, sValue);
                            if (((iEDKServiceES
                                        && (psIndex != -1))
                                        && ((brIndex != -1)
                                        && (cBRInExists != -1))))
                            {
                                base.Parameters(psIndex, brIndex, nLoop);
                            }
                        }
                        catch (System.Exception e)
                        {
                            base.Set_Error_Info(0, e.Source, STOP_PROCESSING, string.Format("General Exception during IN Parameter Binding of PS - 3 BR - 1 {0}", e.Message), String.Empty, String.Empty, 0, String.Empty, String.Empty);
                        }
                        base.WriteProfiler(string.Format("Executing-- {0}/{1} of achapimtrssaversmlmto", nLoop, nMax));
                        base.Execute_SP(true, "achapisprssaversmlspo", ref szErrorDesc, ref lSPErrorID, ref szErrSrc, SP_ERR_PROTOCOL_OUTPARAM);
                        // To handle stop error type / Raise errors
                        if ((lSPErrorID != 0))
                        {
                            if ((szErrSrc.ToUpper() == APP_ERROR))
                            {
                                this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127270, 3, 1);
                            }
                            else
                            {
                                this.Process_MethodError_Info(szErrorDesc, UNKNOWN_ERROR, lSPErrorID, nLoop, 127270, 3, 1);
                            }
                        }
                        try
                        {
                            // New instance
                            nRecCount = htRSMLMLOUT.Count;
                            if (base.IsDataReader_Accessible())
                            {
                                while (Read())
                                {
                                    nRecCount = (nRecCount + 1);
                                    if (((iEDKServiceES
                                                && (psIndex != -1))
                                                && ((brIndex != -1)
                                                && (cBROutExists != -1))))
                                    {
                                        base.ESResultsetBinding(psIndex, brIndex, nvcTmp);
                                    }
                                    nvcTmp = new NameValueCollection();
                                    sValue = this.GetValue("responseml_nex");
                                    nvcTmp["responseml_nex"] = sValue;
                                    sValue = this.GetValue("responseml_nid");
                                    nvcTmp["responseml_nid"] = sValue;
                                    sValue = this.GetValue("responseml_pnid");
                                    nvcTmp["responseml_pnid"] = sValue;
                                    sValue = this.GetValue("rs_constant");
                                    nvcTmp["rs_constant"] = sValue;
                                    sValue = this.GetValue("rs_control_type");
                                    nvcTmp["rs_control_type"] = sValue;
                                    sValue = this.GetValue("rs_controlid");
                                    nvcTmp["rs_controlid"] = sValue;
                                    sValue = this.GetValue("rs_ctrlbtsynonym");
                                    nvcTmp["rs_ctrlbtsynonym"] = sValue;
                                    sValue = this.GetValue("rs_dataitemname");
                                    nvcTmp["rs_dataitemname"] = sValue;
                                    sValue = this.GetValue("rs_flattened_schema");
                                    nvcTmp["rs_flattened_schema"] = sValue;
                                    sValue = this.GetValue("rs_flattened_schema_cmb");
                                    nvcTmp["rs_flattened_schema_cmb"] = sValue;
                                    sValue = this.GetValue("rs_identifier");
                                    nvcTmp["rs_identifier"] = sValue;
                                    sValue = this.GetValue("rs_ismandatory");
                                    nvcTmp["rs_ismandatory"] = sValue;
                                    sValue = this.GetValue("rs_page_btsynonym");
                                    nvcTmp["rs_page_btsynonym"] = sValue;
                                    sValue = this.GetValue("rs_parameterdatatype");
                                    nvcTmp["rs_parameterdatatype"] = sValue;
                                    sValue = this.GetValue("rs_parentschemaname");
                                    nvcTmp["rs_parentschemaname"] = sValue;
                                    sValue = this.GetValue("rs_schemacategory");
                                    nvcTmp["rs_schemacategory"] = sValue;
                                    sValue = this.GetValue("rs_schemaname");
                                    nvcTmp["rs_schemaname"] = sValue;
                                    sValue = this.GetValue("rs_schematype");
                                    nvcTmp["rs_schematype"] = sValue;
                                    sValue = this.GetValue("rs_schematypecategory");
                                    nvcTmp["rs_schematypecategory"] = sValue;
                                    sValue = this.GetValue("rs_sdi_flow_direction");
                                    nvcTmp["rs_sdi_flow_direction"] = sValue;
                                    sValue = this.GetValue("rs_section_btsynonym");
                                    nvcTmp["rs_section_btsynonym"] = sValue;
                                    sValue = this.GetValue("rs_segment_instance");
                                    nvcTmp["rs_segment_instance"] = sValue;
                                    sValue = this.GetValue("rs_segment_name");
                                    nvcTmp["rs_segment_name"] = sValue;
                                    sValue = this.GetValue("rs_segmentname");
                                    nvcTmp["rs_segmentname"] = sValue;
                                    sValue = this.GetValue("rs_viewname");
                                    nvcTmp["rs_viewname"] = sValue;
                                    htRSMLMLOUT[nRecCount] = nvcTmp;
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception during OUT Data Binding of PS - 3 BR - 1", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        }
                        // To handle continue error type / Non-Raise errors
                        if ((lSPErrorID == 0))
                        {
                            if (base.GetCommandOutParam(ref lSPErrorID, SP_ERR_PROTOCOL_OUTPARAM))
                            {
                                if ((lSPErrorID != 0))
                                {
                                    this.Process_MethodError_Info(String.Empty, APP_ERROR, lSPErrorID, nLoop, 127270, 3, 1);
                                }
                            }
                        }
                    }
                    if ((psIndex != -1))
                    {
                        base.PrepareIBRForExecution(psIndex, brSeqNo, 1, 0);
                    }
                }
                catch (CRVWException rvwe)
                {
                    throw rvwe;
                }
                catch (Exception e)
                {
                    base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception at PS - 3 BR - 1 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                }
                finally
                {
                    CloseCommand();
                    Close();
                }
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("PS - 3 {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private void FillPlaceHolderValue(ref System.Collections.Hashtable PlaceHolderData, long lInstance)
        {
            System.Exception ex = null;
            try
            {
                System.Collections.Hashtable tempdata = null;
                System.Collections.Specialized.NameValueCollection Localtable = null;
                int count = PlaceHolderData.Count;
                for (int i = 1; (i <= count); i = (i + 1))
                {
                    tempdata = (Hashtable)PlaceHolderData[i];
                    switch (tempdata["SegName"].ToString().ToLower())
                    {
                        case "_hseg":
                            Localtable = nvc_HSEG;
                            break;
                        case "rsmlml":
                            Localtable = (NameValueCollection)htRSMLML[lInstance];
                            break;
                        case "rsmlmlout":
                            Localtable = (NameValueCollection)htRSMLMLOUT[lInstance];
                            break;
                        case "fw_context":
                            Localtable = this.nvcFW_CONTEXT;
                            break;
                        default:
                            base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, "RVWException in FillPlaceHolderValue No NameValueCollection is present for the gi" +
                                    "ven segment name", string.Empty, string.Empty, 0, string.Empty, string.Empty);
                            break;
                    }
                    tempdata["DIValue"] = Localtable[tempdata["DIName"].ToString()];
                    PlaceHolderData[i] = tempdata;
                }
                return;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (System.Exception e)
            {
                base.WriteProfiler(string.Format("{0} - {1}", "General exception in FillPlaceHolderValue", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General exception in FillPlaceHolderValue_{0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
            }
        }
        private bool Process_MethodError_Info(string szErrDesc, string szErrSource, long SPErrorID, long lInstance, long lMethodId, long lPSSeqNo, long lBRSeqNo)
        {
            CErrorHandler ehs = new CErrorHandler(int.Parse(nvcFW_CONTEXT["language"]));
            long lBRErrorId = 0;
            long lServerity = 0;
            string szErrorMsg = string.Empty;
            string szCorrectiveMsg = string.Empty;
            string szFocusSegName = string.Empty;
            string szFocusDI = string.Empty;
            int iStrPos = 0;
            int iEndPos = 0;
            string ErrDesc = string.Empty;
            string ErrNo = string.Empty;
            base.WriteProfiler("Inside Process_MethodError_Info");
            System.Collections.Hashtable PlaceHolderData = new System.Collections.Hashtable();
            try
            {
                if ((szErrSource != CUtil.APP_ERROR))
                {
                    base.WriteProfiler(string.Format("Error Message:{0}", ErrDesc));
                    base.HandleUnknownError(szErrDesc, ref ErrNo, ref ErrDesc);
                    try
                    {
                        SPErrorID = long.Parse(ErrNo.Trim());
                    }
                    catch (System.Exception)
                    {
                        szErrorMsg = ehs.GetResourceInfo("non_num_err");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                    if ((SPErrorID > 0))
                    {
                        try
                        {
                            if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                            {
                                ehs.EHSachapisrrssave(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                                if ((PlaceHolderData.Count > 0))
                                {
                                    this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                    ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                                }
                                base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                            }
                        }
                        catch (CRVWException rvwe)
                        {
                            throw rvwe;
                        }
                        catch (Exception e)
                        {
                            if ((ErrDesc.Length > 0))
                            {
                                szErrorMsg = ErrDesc;
                                base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrorMsg, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return true;
                            }
                            else
                            {
                                szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                                base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        base.Set_Error_Info(SPErrorID, szErrSource, CUtil.STOP_PROCESSING, szErrDesc, string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        if ((base.Process_MethodError_Info(szErrDesc, szErrSource, SPErrorID, lInstance, lMethodId, lPSSeqNo, lBRSeqNo) == false))
                        {
                            ehs.EHSachapisrrssave(lMethodId, SPErrorID, lInstance, lPSSeqNo, lBRSeqNo, ref lBRErrorId, ref szErrorMsg, ref szCorrectiveMsg, ref lServerity, ref szFocusSegName, ref szFocusDI, ref PlaceHolderData);
                            if ((PlaceHolderData.Count > 0))
                            {
                                this.FillPlaceHolderValue(ref PlaceHolderData, lInstance);
                                ehs.ReplaceErrMsg(PlaceHolderData, ref szErrorMsg);
                            }
                            base.Set_Error_Info(lBRErrorId, CUtil.APP_ERROR, lServerity.ToString(), szErrorMsg, szFocusDI, szFocusSegName, lInstance, szCorrectiveMsg, "0");
                        }
                    }
                    catch (CRVWException rvwe)
                    {
                        throw rvwe;
                    }
                    catch (Exception e)
                    {
                        szErrorMsg = ehs.GetResourceInfo("err_desc_not_found");
                        base.Set_Error_Info(0, szErrSource, CUtil.STOP_PROCESSING, string.Format("{0} {1}", szErrorMsg, e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                        return false;
                    }
                }
                return true;
            }
            catch (CRVWException rvwe)
            {
                throw rvwe;
            }
            catch (Exception e)
            {
                base.WriteProfiler(string.Format("General Exception in Process_MethodError Info - {0}", e.Message));
                base.Set_Error_Info(0, CUtil.FRAMEWORK_ERROR, CUtil.STOP_PROCESSING, string.Format("General Exception in Process_MethodError Info - {0}", e.Message), string.Empty, string.Empty, 0, string.Empty, string.Empty);
                return false;
            }
        }
        public virtual void LogMessage(string sContext, string sMessage)
        {
            System.Diagnostics.DefaultTraceListener listener = new System.Diagnostics.DefaultTraceListener();
            string sFileName = "c:\\temp\\achapisrrssave.txt";
            listener.WriteLine(string.Format("{0} : {1}", sContext, sMessage));
            if ((System.IO.File.Exists(sFileName) == true))
            {
                try
                {
                    System.IO.StreamWriter sw = new System.IO.StreamWriter(sFileName, true);
                    sw.WriteLine(string.Format("{0} : {1} : {2}", System.DateTime.Now.ToString(), sContext, sMessage));
                    sw.Close();
                }
                catch (System.Exception e)
                {
                    listener.WriteLine(string.Format("LogMessage : {0}", e.Message));
                }
            }
        }
    }
}

