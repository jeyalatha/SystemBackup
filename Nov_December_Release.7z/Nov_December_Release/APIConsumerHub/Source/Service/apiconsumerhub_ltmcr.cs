/********************************************************************************************************
* Copyright @2004, RAMCO SYSTEMS,  All rights reserved.													
* Application/Module Name   :apiconsumerhub_ltmcr.cs
* Code Generated on         :12/06/2022 11:36:49
* Code Generated From       :ramco/PLF/ACH_ECR_00083/techwarcnv56\inst2/sa/Rvw20AppDB/TECHWARCNV56
* Revision/Version #        :
* Purpose                   :
* Modifications             :
* Modifier Name & Date      :
********************************************************************************************************/
using System;
using System.Reflection;
using System.Diagnostics;
[assembly: AssemblyDescription("ramco/PLF/ACH_ECR_00083/techwarcnv56-inst2/sa/Rvw20AppDB/TECHWARCNV56/06-12-2022")]
//transction scope - Dotnet ltm transaction scope - 0 - Required, 1 - Required New, 2 - Supported
// model scope - 0 Supported, 1 - Required
//outZBytes - true - zipped byte[]  , false - string
//tdFormat = 0 - String , 1- JSON , 2-Dataset
namespace com.ramco.vw.apiconsumerhub.service
{
	public class Capiconsumerhub_ltmcr
	{
		public const int ATMA_SUCCESS = 0;
		public const int ATMA_FAILURE = 999;
		public const int ATMA_INVALID_SERVICE = 998;


		public int ProcessDocument(string szInMtd, string szServiceName, string szSessionToken, bool outZBytes, int tdFormat, ref string szOutMtd, ref byte[] byteOutMtd)
		{
			DefaultTraceListener output = new DefaultTraceListener();
			try
			{
				szOutMtd = "";
				byteOutMtd = null;

				Capiconsumerhub_ltm capiconsumerhub_ltm = new Capiconsumerhub_ltm();
				switch (szServiceName.ToLower().Trim())
				{
					case("achapisrapitrg"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrapitrg service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrapitrg service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrapitrg service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrinit"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrinit service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrpmsave"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrpmsave service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrpmsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrpmsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrrqsave"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrqsave service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrqsave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrqsave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrrssave"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrssave service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrssave service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrrssave service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisrservi1"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrservi1 service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrservi1 service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisrservi1 service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achapisruidesh"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisruidesh service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisruidesh service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achapisruidesh service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achescrsrcustnm"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrcustnm service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrcustnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrcustnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achescrsrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achescrsrinit"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrinit service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achescrsrprojnm"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrprojnm service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrprojnm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achescrsrprojnm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsractdes"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsractdes service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsractdes service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsractdes service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrargqry"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargqry service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargqry service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargqry service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrargsav"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargsav service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrargsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrflddef"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrflddef service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrflddef service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrflddef service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrfldqry"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldqry service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldqry service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldqry service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrfldsav"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldsav service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfldsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrfolimp"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfolimp service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfolimp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrfolimp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrimpsch"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrimpsch service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrimpsch service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrimpsch service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrinctrl"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinctrl service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinctrl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinctrl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrinit"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinit service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrqrynam"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrynam service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrynam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrynam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrqrysav"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrysav service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrysav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrqrysav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrrepsav"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrrepsav service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrrepsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrrepsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrsdl"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrsdl service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrsdl service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrsdl service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsrtsknam"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrtsknam service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrtsknam service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsrtsknam service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlsruides"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsruides service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsruides service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlsruides service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achgqlstdsrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlstdsrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlstdsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achgqlstdsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achimpgqlsrimpfol"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpgqlsrimpfol service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpgqlsrimpfol service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpgqlsrimpfol service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achimpschsrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achimpschsrimpfol"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimpfol service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimpfol service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimpfol service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achimpschsrimport"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimport service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimport service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrimport service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achimpschsrmlimp"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrmlimp service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 2, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrmlimp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achimpschsrmlimp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achmscrsrrqmdtp"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrqmdtp service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrqmdtp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrqmdtp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achmscrsrrscode"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrscode service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrscode service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrscode service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achmscrsrrsmdtp"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrsmdtp service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrsmdtp service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achmscrsrrsmdtp service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissractivi"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissractivi service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissractivi service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissractivi service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissrfet"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrfet service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrfet service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrfet service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissrinit"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrinit service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrinit service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrinit service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissrsav"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrsav service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrsav service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrsav service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissrschm"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrschm service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrschm service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrschm service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissrtaskna"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrtaskna service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrtaskna service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissrtaskna service executed with a failure.");
							return ATMA_FAILURE;
						}
					case("achvissruiname"):
						output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissruiname service started.");
						if (capiconsumerhub_ltm.ProcessDocument(szInMtd, szServiceName, szSessionToken, 0, outZBytes, tdFormat, out szOutMtd, out byteOutMtd) == 0)
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissruiname service executed successfully.");
							return ATMA_SUCCESS;
						}
						else
						{
							output.WriteLine("APICONSUMERHUB.Capiconsumerhub_ltmcr.ProcessDocument - achvissruiname service executed with a failure.");
							return ATMA_FAILURE;
						}
					default:
						output.WriteLine("Capiconsumerhub_ltmcr.ProcessDocument - Service referred Is Not part of the runtime component-" + szServiceName);
						return ATMA_INVALID_SERVICE;
				}
			}
			catch (Exception e)
			{
				output.WriteLine("Capiconsumerhub_ltmcr.ProcessDocument - General Exception :");
				output.WriteLine(e.Message);
				szOutMtd = "";
				return ATMA_FAILURE;
			}
			finally
			{
			}
		}
	}
}
