IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='de_generate_service' AND TYPE = 'P')
    Begin
        Drop PROC de_generate_service
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_generate_service.sql
********************************************************************************/
/************************************************************************/
/* procedure			de_generate_service								*/
/* description			SP to generate Servie Data						*/
/************************************************************************/
/* project				Design Engineering								*/
/* version																*/
/************************************************************************/
/* referenced															*/
/* tables																*/
/************************************************************************/
/* development history													*/
/************************************************************************/
/* author				Giridharan.V									*/
/* date					09/ DEC/ 2003									*/
/************************************************************************/
/* modification history													*/
/************************************************************************/
/* modified by			: A.G.Senthil kumar								*/
/* date					: 23-04-2004									*/
/* description			: bugid :DEENG203SYS_000012						*/
/************************************************************************/
/* modification history													*/
/************************************************************************/
/* modified by			: S.Balaji										*/
/* date					: 10-06-2005									*/
/* BugId				: PNR2.0_2825									*/
/* description			: For Collation Conflict						*/
/************************************************************************/
/* modified by			: Ganesh										*/
/* date					: 13-06-2005									*/
/* BugId				: PNR2.0_2825									*/
/* description			: For Collation Conflict						*/
/************************************************************************/
/* modified by  : Sangeetha L     	                                    */
/* date         : 18/07/2005                                            */
/* description  : Invalid primary key violation in table fw_des_service.*/
/* BugID		: PNR2.0_3277											*/
/* modified by  : Shriram V     	                                    */
/* date         : 04/10/2005                                            */
/* description  : Method is Reused . So Servie cannot be Regenerated	*/
/* BugID	: PNR2.0_4090												*/
/************************************************************************/
/* modified by			: Sangeetha L									*/
/* date					: 06-01-2006									*/
/* BugId				: PNR2.0_5313									*/
/* description			: updating section name for parameter table		*/
/************************************************************************/
/* modified by			: Saravanan kumar P							    */
/* date					: 28-02-2006									*/
/* BugId				: PNR2.0_6386								    */
/************************************************************************/
/* modified by			: Saravanan kumar P							    */
/* date					: 02-03-2006									*/
/* BugId				: PNR2.0_6784							    	*/
/************************************************************************/
/* modified by			: Saravanan kumar P							    */
/* date					: 03-03-2006									*/
/* BugId				: PNR2.0_6727						    		*/
/************************************************************************/
/* modified by			: Saravanan kumar P							    */
/* date					: 06-03-2006									*/
/* BugId				: PNR2.0_6871&PNR2.0_6863					    */
/************************************************************************/
/* modified by			: kiruthika R							    	*/
/* date					: 14-11-2006									*/
/* BugId				: PNR2.0_10978					    			*/
/************************************************************************/
/* modified by			: Anuradha M				*/
/* date					: 29-11-2006			*/
/* BugId				: PNR2.0_11220 			*/
/************************************************************************/
/* modified by			: Anuradha M				*/
/* date					: 30-11-2006			*/
/* BugId				: PNR2.0_11244			*/
/************************************************************************/
/* modified by			: Anuradha M				*/
/* date					: 01-02-2007			*/
/* BugId				: PNR2.0_12066			*/
/************************************************************************/
/* modified by			: Anuradha M				*/
/* date					: 28-09-2007			*/
/* BugId				: PNR2.0_15533			*/
/************************************************************************/
/* modified by			: Chanheetha N A								*/
/* date					: 17-nov-2007									*/
/* BugId				: PNR2.0_16023 									*/
/************************************************************************/
/* modified by			: Feroz											*/
/* date					: 16-feb-2009									*/
/* BugId				: PNR2.0_21082 									*/
/************************************************************************/
/* modified by			: Gowrisankar M									*/
/* date					: 01-Apr-2009									*/
/* BugId				: PNR2.0_21616 									*/
/* Desc					: Hidden views are not to be added to the 		*/
/*						  ML-Method if Map_ml_flag is set as "No" 		*/
/************************************************************************/
/* Modified by  		: Gowrisankar M	                                */
/* Date         		: 12-May-2009                                   */
/* Bug ID       		: PNR2.0_22194                                  */
/* Description			: Report Dataitemname usage check to be done at */
/*						  service generation  							*/
/************************************************************************/
/* modified by  : Feroz				                                     */
/* date         : 04-Aug-2009                                            */
/* Bug Id 		: PNR2.0_2179											*/
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/************************************************************************/
/* modified by			: Gowrisankar M									*/
/* date					: 08-Oct-2009									*/
/* BugId				: PNR2.0_24216 									*/
/* Description			: Allowing hidden view to be included though 	*/
/*							the visible view is not mapped to the task	*/
/************************************************************************/
/* modified by   	: Saravanan              							*/
/* date       		: 23-Jul-2010               							*/
/* BugId      		: PNR2.0_27694                 						*/
/* Bug Desc		: Override Option to be made hidden in Specify UI State					*/
/****************************************************************************************/
/* modified by  :	Manikandan P K 										*/
/* date         :	01-Feb-2011                                         */
/* Bug ID		:	PNR2.0_29939         								*/
/* Description	:	SP_code change compatible for Oracle Migration      */
/****************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/****************************************************************************/
/* modified by   : Sangeetha G												*/
/* date			 : 11-Apr-2011												*/
/* BugId		 : PNR2.0_30869												*/
/* BugId		 : Feature Release - PageEvents								*/
/****************************************************************************/
/* modified by			: Jeya Latha K									 */
/* date					: 29-Sep-2011									 */
/* BugId				: PNR2.0_33317 									 */
/* Description			: New Feature - Offline Reports					 */
/*************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Created by  	: Kiruthika R                                               	*/
/* Date         : 13-June-2016                                                  */
/*Defect Id 	: PLF2.0_18487	(Performance Tuning)							*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 31-Jan-2018  Defect ID	:TECH-18349	*/
/********************************************************************************/
/* Modified by  : Jeya Latha K	Date: 30-Apr-2018  Defect ID : TECH-20897 */
/*************************************************************************************/
/* Modified By : Jeya Latha K/Venkatesan K  Date: 04-Dec-2018  Defect ID: TECH-28806 */
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019  Defect ID: TECH-34971 */
/* Modified by : Jeya Latha K               Date: 27-May-2020  Defect ID: TECH-46646 */
/*************************************************************************************/
/* Modified by			: Ponmalar A 										    */
/* Date					: 29-Sep-2022											*/
/* Defect ID			: TECH-73216											*/
/********************************************************************************/
/* Modified by			: Ponmalar A 										    */
/* Date					: 27-Oct-2022											*/
/* Defect ID			: TECH-73996											*/
/********************************************************************************/
/* Modified by  : Ponmalar A		Date: 01-Dec-2022  Defect ID	:TECH-75230	*/
/********************************************************************************/
create PROCEDURE de_generate_service
	@CTxt_Language engg_ctxt_language,
	@CTxt_Service engg_ctxt_service,
	@CTxt_OUInstance engg_ctxt_ouinstance,
	@CTxt_User engg_ctxt_user,
	@customer_name engg_name,
	@project_name engg_name,
	@ico_number engg_name,
	@process_name engg_name,
	@component_name engg_name,
	@activity_name engg_name,
	@ui_name engg_name,
	@page_name engg_name,
	@task_name engg_name,
	@component_prfx engg_name,
	@service_idfr engg_name,
	@mt_prfx engg_name,
	@cb_load_idfr engg_name,
	@cb_def_idfr engg_name,
	@hdr_valid_idfr engg_name,
	@hdr_sgmt_idfr engg_name,
	@cb_sgmt_idfr engg_name,
	@ml_sgmt_idfr engg_name,
	@mlcb_sgmt_idfr engg_name,
	@ml_out_sgmt_idfr engg_name,
	@sp_prfx engg_name,
	@rs_prfx engg_name,
	@ps_prfx engg_name,
	@cbhdr_sgmt_idfr engg_name,
	@hdr_ref_idfr engg_name,
	@hdr_fet_idfr engg_name,
	@hdr_chk_idfr engg_name,
	@err_chk_idfr engg_name,
	@hdr_save_idfr engg_name,
	@ps_ref_idfr engg_name,
	@mt_out_idfr engg_name,
	@sp_out_idfr engg_name,
	@bo_idfr engg_name,
	@hdr_segmt_idfr engg_name,
	@cbo_segmt_idfr engg_name,
	@mlcb_segmt_idfr engg_name,
	@ml_segmt_idfr engg_name,
	@ml_out_segmt_idfr engg_name,
	@service_name engg_name OUTPUT,
	--code added for the caseid : PNR2.0_27694 starts
	@m_errorid engg_seqno OUTPUT
	--code added for the caseid : PNR2.0_27694 ends
AS
BEGIN
	--code added for the caseid : PNR2.0_27694 starts
	SELECT @m_errorid = 0

	--code added for the caseid : PNR2.0_27694 ends
	--VARIABLE DECLARATION STARTS
	DECLARE @msg engg_description,
		@component_descr engg_description,
		@tsk_service_name engg_name, --TO HOLD SERVICE NAME FOR THE SELECTED TASK
		--			@control_prfx		engg_name,
		@ui_prfx engg_name,
		@task_type engg_name,
		@task_prfx engg_name,
		--			@page_prfx			engg_name,
		--			@m_errorid			engg_id,
		@task_descr engg_Description,
		@service_type engg_seqno,
		@trn_scope_req engg_flag,
		@hdr_segment engg_description,
		@method_count engg_sequence_no, --CODE ADD BY DNR ON 19/03/2004 TO HOLD METHODS_COUNT FOR THE SERVICE
		@getdate engg_date,
		@hostname engg_name,
		@mname_tmp engg_name,
		@dataitem_name engg_name, --code added by Gowrisankar M on 12-May-2009 for PNR2.0_22194 
		@isbubblemessage	engg_seqno --TECH-69327

	SELECT @getdate = getdate(),
		@hostname = host_name()

	--VARIABLE DECLARATION ENDS
	------------------------------------------------------------------
	--NOTE: TASK PREFIX WILL BE CONTROL PREFIX FOR TRANS TASK TYPE.	--
	------	FOR FETCH AND INIT TASK TYPES, TASK PREFIX WILL BE		--
	------	CAPTURED FROM THE USER SEPERATELY.						--
	------------------------------------------------------------------
	--GETTING COMPONENT DESCRIPTION FOR NAME
	SELECT @component_descr = IsNull(component_descr, '')
	FROM de_ui_ico(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND ico_no = @ico_number
		AND process_name = @process_name
		AND component_name = @component_name

	IF DATALENGTH(LTRIM(RTRIM(@component_descr))) < 1
	BEGIN
		SELECT @msg = 'Unable to Identify Component Description.'

		EXEC engg_error_sp 'de_generate_service',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	--------------------
	--GETTING PREFIXES--
	--------------------
	--GETTING TASK TYPE
	SELECT @task_descr = a.task_descr
	FROM de_action A(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name
		AND a.component_name = @component_name
		AND a.activity_name = @activity_name
		AND a.ui_name = @ui_name
		AND a.page_bt_synonym = @page_name
		AND a.task_name = @task_name

	SELECT @task_type = a.task_type
	FROM de_action A(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name
		AND a.component_name = @component_name
		AND a.activity_name = @activity_name
		AND a.ui_name = @ui_name
		AND a.page_bt_synonym = @page_name
		AND a.task_name = @task_name

	--TECH-69327
		SELECT @isbubblemessage = 0
			--Select	@isbubblemessage	=	ISNULL(isbubblemessage, 0)
			IF EXISTS ( SELECT 'X'
				from	de_action			a (nolock),
					es_comp_task_type_mst	b (nolock)
				where	a.customer_name		= @customer_name
				and	a.project_name			= @project_name
				and	a.process_name			= @process_name
				and	a.component_name		= @component_name
				and	a.activity_name			= @activity_name
				and	a.ui_name				= @ui_name
				and	a.page_bt_synonym		= @page_name
				and	a.task_name				= @task_name
				and	a.customer_name		= b.customer_name
				and	a.project_name		= b.project_name
				and	a.process_name		= b.process_name
				and	a.component_name	= b.component_name
				and	a.task_pattern		= b.task_type_name
				and	b.BubbleMessage		= 'Y'
				)
				SELECT @isbubblemessage = 1
	--TECH-69327

	--TECH-73996
	IF EXISTS
	(SELECT 'X'
	FROM	es_quick_code_met (NOLOCK)
	WHERE	CustomerName	=	@customer_name
	AND		ProjectName		=	@project_name
	AND		ParameterCode	=	'DefaultinghiddenView'
	AND		ParameterText	=	'AUTO_MAP_HDNVIEW_COMBO'
	AND		ParameterValue	=	'Y')	
	AND		NOT EXISTS
	(SELECT 'X'
	 FROM	de_task_service_method_vw (NOLOCK)
	 WHERE	customer_name		=	@customer_name 
	 AND	project_name		=	@project_name
	 AND	process_name		=	@process_name
	 AND	component_name		=	@component_name
	 AND	activity_name		=	@activity_name
	 AND	ui_name				=   @ui_name	
	 AND	task_name 			= 	@task_name)
	BEGIN
		INSERT INTO de_hidden_view_usage
			(customer_name,			project_name,				process_name,	component_name,
			 activity_name,			ui_name,					page_name,		action_name,
			 control_bt_sysnonym,	hidden_view_bt_sysnonym,	timestamp,		createdby,
			 createddate,			modifiedby,					modifieddate,	control_page_name,
			 map_ml_flag,			ecrno)
		SELECT
			@customer_name,			@project_name,				@process_name,	@component_name,
			@activity_name,			@ui_name,					@page_name,		@task_name,
			a.control_bt_synonym,	hidden_view_bt_synonym,		1,				@ctxt_user,
			@getdate,				@ctxt_user,					@getdate,		page_name,
			'Y',					@ico_number
		FROM	de_hidden_view a WITH (NOLOCK)
		JOIN	de_ui_control   b (NOLOCK)
		ON		a.customer_name				= b.customer_name
		AND		a.project_name				= b.project_name
		AND		a.process_name				= b.process_name
		AND		a.component_name			= b.component_name
		AND		a.activity_name				= b.activity_name
		AND		a.ui_name					= b.ui_name
		AND		a.page_name					= b.page_bt_synonym
		AND		a.section_name				= b.section_bt_synonym
		AND		a.control_bt_synonym		= b.control_bt_synonym
		JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
		ON		b.customer_name				= c.customer_name
		AND		b.project_name				= c.project_name
		AND		b.process_name				= c.process_name
		AND		b.component_name			= c.component_name
		AND		b.control_type				= c.ctrl_type_name
		WHERE	a.customer_name		= @customer_name
		AND		a.project_name		= @project_name
		AND		a.process_name		= @process_name
		AND		a.component_name	= @component_name
		AND		a.activity_name		= @activity_name
		AND		a.ui_name			= @ui_name
		AND		a.page_name			= @page_name
		AND		a.hidden_view_bt_synonym NOT IN (SELECT	d.hidden_view_bt_sysnonym
		FROM	de_hidden_view_usage d (NOLOCK)
		WHERE	a.customer_name				= d.customer_name
		AND		a.project_name				= d.project_name
		AND		a.process_name				= d.process_name
		AND		a.component_name			= d.component_name
		AND		a.activity_name				= d.activity_name
		AND		a.ui_name					= d.ui_name
		AND		a.page_name					= d.page_name
		AND		d.action_name				= @task_name
		)
		AND     c.base_ctrl_type	= 'Combo'
		UNION
		SELECT
			@customer_name,			@project_name,				@process_name,	@component_name,
			@activity_name,			@ui_name,					@page_name,		@task_name,
			column_bt_synonym,		hidden_view_bt_synonym,		1,				@ctxt_user,
			@getdate,				@ctxt_user,					@getdate,		page_name,
			'Y',					@ico_number
		FROM	de_hidden_view a WITH (NOLOCK)
		JOIN	de_ui_grid   b (NOLOCK)
		ON		a.customer_name				= b.customer_name
		AND		a.project_name				= b.project_name
		AND		a.process_name				= b.process_name
		AND		a.component_name			= b.component_name
		AND		a.activity_name				= b.activity_name
		AND		a.ui_name					= b.ui_name
		AND		a.page_name					= b.page_bt_synonym
		AND		a.section_name				= b.section_bt_synonym
		AND		a.control_bt_synonym		= b.column_bt_synonym
		JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
		ON		b.customer_name				= c.customer_name
		AND		b.project_name				= c.project_name
		AND		b.process_name				= c.process_name
		AND		b.component_name			= c.component_name
		AND		b.column_type				= c.ctrl_type_name
		WHERE	a.customer_name		= @customer_name
		AND		a.project_name		= @project_name
		AND		a.process_name		= @process_name
		AND		a.component_name	= @component_name
		AND		a.activity_name		= @activity_name
		AND		a.ui_name			= @ui_name
		AND		a.page_name			= @page_name
		AND		a.hidden_view_bt_synonym NOT IN (SELECT	d.hidden_view_bt_sysnonym
		FROM	de_hidden_view_usage d (NOLOCK)
		WHERE	a.customer_name				= d.customer_name
		AND		a.project_name				= d.project_name
		AND		a.process_name				= d.process_name
		AND		a.component_name			= d.component_name
		AND		a.activity_name				= d.activity_name
		AND		a.ui_name					= d.ui_name
		AND		a.page_name					= d.page_name
		AND		d.action_name				= @task_name
		)
		AND     c.base_ctrl_type	= 'Combo'
	END
	--TECH-73996

	--code added by Gowrisankar M on 12-May-2009 for PNR2.0_22194 - Begins
	IF @task_type = 'Report'
	BEGIN
		SELECT @dataitem_name = dataitem_name
		FROM de_Report_action_dataset_dataitem a(NOLOCK)
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND page_bt_synonym = @page_name
			AND action_name = @task_name
			AND EXISTS (
				SELECT 'x'
				FROM de_task_control_map b(NOLOCK)
				WHERE b.customer_name = a.customer_name
					AND b.project_name = a.project_name
					AND b.process_name = a.process_name
					AND b.component_name = a.component_name
					AND b.activity_name = a.activity_name
					AND b.ui_name = a.ui_name
					AND b.action_name = a.action_name
					AND isnull(b.new_control_bt_synonym, b.control_bt_synonym) = a.dataitem_name
					AND b.map_flag = 'Y'
				)

		IF isnull(@dataitem_name, '') <> ''
		BEGIN
			EXEC engg_error_sp 'de_generate_service',
				1,
				'Report Dataitemname "<%1>" is already in use. Change the dataitemname and proceed',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@dataitem_name,
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END
	END

	--code added by Gowrisankar M on 12-May-2009 for PNR2.0_22194 - Ends
	--	Set	@task_type	= ''
	IF EXISTS (
			SELECT 'A'
			FROM de_action(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND page_bt_synonym = @page_name
				AND task_name = @task_name
				AND IsNull(primary_control_bts, '[None]') <> '[None]'
			)
	BEGIN
		-- code modified by shafina on 10-Aug-2004 for selecting tasktype - DEENG203SYS_000342
		SELECT @task_type = a.task_type
		FROM de_action A(NOLOCK),
			de_ui_control B(NOLOCK),
			es_comp_ctrl_type_mst_vw C(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND a.activity_name = @activity_name
			AND a.ui_name = @ui_name
			AND a.page_bt_synonym = @page_name
			AND a.task_name = @task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ui_name = b.ui_name
			AND a.page_bt_synonym = b.page_bt_synonym
			AND a.primary_control_bts = b.control_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.ctrl_type_name = b.control_type

		IF IsNull(@task_type, '') = ''
		BEGIN
			SELECT @task_type = a.task_type
			FROM de_action A(NOLOCK),
				de_ui_grid B(NOLOCK),
				es_comp_ctrl_type_mst_vw C(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_bt_synonym = @page_name
				AND a.task_name = @task_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.primary_control_bts = b.column_bt_synonym
				AND c.customer_name = b.customer_name
				AND c.project_name = b.project_name
				AND c.process_name = b.process_name
				AND c.component_name = b.component_name
				AND c.ctrl_type_name = b.column_type
		END
	END
	ELSE
	BEGIN
		IF upper(right(@task_type, 4)) = 'INIT'
			SELECT @task_type = 'Init'
				-- Code modification for  PNR2.0_30127 starts
		ELSE IF upper(right(@task_type, 8)) = 'DISPOSAL'
			SELECT @task_type = 'Disposal'
				-- Code modification for  PNR2.0_30127 ends
		ELSE
			SELECT @task_type = 'Fetch'
	END

	-- modified by Ganesh for the bugid ::: DEENG203SYS_000344 on 11/08/04
	IF @task_type = 'Link'
	BEGIN
		-- Code modified by Ganesh on 1/11/04 to consider the link task as trans
		SELECT @task_type = 'Trans'
	END

	IF @task_type IN (
			'Init',
			'Fetch',
			'Disposal'
			) -- Code modified for  PNR2.0_30127 
	BEGIN
		IF @task_type = 'Init'
		BEGIN
			SELECT @task_prfx = 'init'
		END
				-- Code modification for  PNR2.0_30127 starts
		ELSE IF @task_type = 'Disposal'
		BEGIN
			SELECT @task_prfx = 'dis'
		END
				-- Code modification for  PNR2.0_30127 ends
		ELSE
		BEGIN
			SELECT @task_prfx = 'fet'
		END
				--TO BE TAKEN FROM PARAM MST
	END
	ELSE
	BEGIN
		SELECT @task_prfx = control_prefix
		FROM de_action A(NOLOCK),
			de_ui_control B(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND a.activity_name = @activity_name
			AND a.ui_name = @ui_name
			AND a.page_bt_synonym = @page_name
			AND a.task_name = @task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ui_name = b.ui_name
			AND a.page_bt_synonym = b.page_bt_synonym
			AND a.Primary_control_bts = b.control_bt_synonym

		IF IsNull(@task_prfx, '') = ''
		BEGIN
			SELECT @task_prfx = column_prefix
			FROM de_action A(NOLOCK),
				de_ui_grid B(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_bt_synonym = @page_name
				AND a.task_name = @task_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_bt_synonym
				AND a.Primary_control_bts = b.column_bt_synonym
		END

		--Code Modification for PNR2.0_30869 starts 
		IF IsNull(@task_prfx, '') = ''
		BEGIN
			SELECT @task_prfx = ltrim(rtrim(page_prefix))
			FROM de_action A(NOLOCK),
				de_ui_page B(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_bt_synonym = @page_name
				AND a.task_name = @task_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.Primary_control_bts = b.page_bt_synonym
		END

		--Code Modification for PNR2.0_30869 ends 
		-- Code added for TECH-28806 Starts
		IF IsNull(@task_prfx, '') = ''
		BEGIN
			SELECT @task_prfx = ActionPrefix
			FROM de_action A(NOLOCK),
				ngplf_wr_template_action B(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_bt_synonym = @page_name
				AND a.task_name = @task_name
				AND a.customer_name = b.CustomerID
				AND a.project_name = b.ProjectID
				AND a.process_name = b.ProcessName
				AND a.component_name = b.ComponentName
				AND a.activity_name = b.ActivityName
				AND a.ui_name = b.UIName
				AND a.page_bt_synonym = b.PageName
				AND (
					(a.Primary_control_bts = isnull(b.controlname, '') + '_' + isnull(b.actionname, ''))
					OR (a.Primary_control_bts = isnull(b.controlname, '') + isnull(b.actionname, ''))
					)
		END
				-- Code added for TECH-28806 Ends
	END

	-- code added by Ganesh for the bugid :: DEENG203SYS_000431 on 28/10/04
	/*
	Code segment added by giri on 29/jun/2004
	Bug			:	Service name and Method Name is getting changed while regenerating the design
	Bug	ID		:	DEENG203ACC_000084
	Reason		:	While framing Service name and method name, Instead of taking UI prefix as [Mainscreen] page prefix,
					@page_prefix (Which is coming as input parameter) value had been used as UI prefix.
	Fix			:	While getting UI prefix, page_bt_synonym in the where condition nees to be changed to '[mainscreen]'
					instead of @page_prefix. To retain existing Service and Method names, following steps had been
					incorporated
				Step 1:	Frame the service name with old methodology and store it in the variable @old_service
				Step 2:	Get the existing service name for the task and store it in the variable @existing_service
				Step 3:	Compare the variables @old_service and @existing_service
				Step 4:	If both equals, then UI prefix will be taken as per old methodology. Else UI prefix will be
						taken as per new methodology
*/
	--MODIFICATION BY GIRI ON 29/JUN/2004 STARTS HERE
	DECLARE @old_service engg_name,
		@existing_Service engg_name,
		@tmp_ui_prfx engg_name

	--GETTING THE UI PREFIX AS PER PER OLD METHODOLOGY 
	SELECT @tmp_ui_prfx = IsNull(page_prefix, '')
	FROM de_ui_page(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND activity_name = @activity_name
		AND ui_name = @ui_name
		AND page_bt_synonym = @page_name

	--CODE SEGMENT FOR STEP 1 STARTS HERE
	SELECT @old_service = IsNull(@component_prfx + @tmp_ui_prfx + @service_idfr + @task_prfx, '')

	--CODE SEGMENT FOR STEP 1 ENDS HERE
	--CODE SEGMENT FOR STEP 2 STARTS HERE
	SELECT @existing_Service = service_name
	FROM de_task_service_map A(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name
		AND a.component_name = @component_name
		AND a.ui_name = @ui_name
		AND a.task_name = @task_name

	--CODE SEGMENT FOR STEP 2 ENDS HERE
	--CODE SEGMENT FOR STEP 3 and STEP 4 STARTS HERE
	SELECT @old_service = upper(LTrim(RTrim(@old_service))),
		@existing_Service = upper(LTrim(RTrim(@existing_Service)))

	IF @old_service = @existing_Service
	BEGIN
		SELECT @ui_prfx = @tmp_ui_prfx
	END
	ELSE
	BEGIN
		--GETTING UI PREFIX [ [MAINSCREEN] PAGE PREFIX ]
		SELECT @ui_prfx = IsNull(page_prefix, '')
		FROM de_ui_page(NOLOCK)
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND page_bt_synonym = '[mainscreen]'
	END

	--CODE SEGMENT FOR STEP 3 and STEP 4 ENDS HERE
	--MODIFICATION BY GIRI ON 29/JUN/2004 ENDS HERE
	----------------------------
	--DELETING EXISTING VALUES--
	----------------------------
	--GETTING THE SERVICE NAME FOR THE TASK NAME
	SELECT @tsk_Service_name = service_name
	FROM de_task_service_map A(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name
		AND a.component_name = @component_name
		AND a.ui_name = @ui_name
		AND a.task_name = @task_name

	--DELETING TASK SERVICE MAPPING FOR THE TASK
	DELETE de_task_service_map
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND activity_name = @activity_name
		AND ui_name = @ui_name
		AND task_name = @task_name

	--INSERTING ALL THE METHOD IDs INTO THE TEMPORARY TABLE FOR DELETING METHODS AND METHOD ID REFERENCED 
	--TABLES FOR THE METHODS WHICH BELONGS TO THE PARTICULAR SERVICE
	SELECT DISTINCT methodid
	INTO #service_methodid_tmp
	FROM de_fw_des_processsection_br_is(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	-- Added by Shriram V on 04/10/2005 for Bug ID : PNR2.0_4090
	IF EXISTS (
			SELECT customer_name,
				project_name,
				process_name,
				component_name,
				methodid
			FROM de_fw_des_processsection_br_is(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
				AND isbr = 1 -- PNR2.0_15533
				AND methodid IN (
					SELECT methodid
					FROM #service_methodid_tmp(NOLOCK)
					)
			GROUP BY customer_name,
				project_name,
				process_name,
				component_name,
				methodid
			HAVING count(servicename) > 1
			)
	BEGIN
		SELECT @mname_tmp = method_name
		FROM de_fw_des_processsection_br_is(NOLOCK)
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND isbr = 1 -- PNR2.0_15533
			AND methodid IN (
				SELECT methodid
				FROM #service_methodid_tmp(NOLOCK)
				)
		GROUP BY customer_name,
			project_name,
			process_name,
			component_name,
			method_name
		HAVING count(servicename) > 1

		EXEC engg_error_sp 'de_generate_service',
			1,
			'Method Name : <%1> is Reused. Pl Remove other Services before Regenerating this Service.',
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@mname_tmp,
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END

	-- Added by Shriram V on 04/10/2005 for Bug ID : PNR2.0_4090
	--METHOD PARAMETER AND SEGMENT DATAITEM MAPPING
	DELETE de_fw_des_di_parameter
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	/* Code Modified by Balaji s 0n 26/05/2005
	   for deleting place holder before processsection delete */
	SELECT *
	INTO #de_fw_des_di_placeholder
	FROM de_fw_des_di_placeholder(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	DELETE de_fw_des_di_placeholder
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	-- code added by Ganesh For the bugid :: PNR2.0_2051 on 19/4/05
	-- while deleting the process section, the intergration details is to be deleted.
	DELETE
	FROM de_fw_des_integ_serv_map
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND callingservicename = @tsk_service_name

	--METHOD
	--METHOD AND PROCESS SECTION MAPPING
	DELETE de_fw_des_processsection_br_is
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--PROCESS SECTION
	DELETE de_fw_des_processsection
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	SELECT customer_name, /*Modification made by Manikandan P K for Bug id : PNR2.0_29939 Starts*/
		methodid,
		placeholdername,
		parametername,
		errorid,
		upduser,
		updtime,
		project_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		process_name,
		component_name,
		ecrno /*Modification made by Manikandan P K for Bug id : PNR2.0_29939 Ends*/
	INTO #de_fw_des_be_placeholder
	FROM de_fw_des_be_placeholder(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD placeholder
	DELETE de_fw_des_be_placeholder
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD PARAMETERS
	DELETE de_fw_des_br_logical_parameter
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD DOCUMENTATION
	DELETE de_fw_des_br_documentation
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD AND SP MAPPING
	DELETE de_fw_des_sp
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD AND SP MAPPING
	--CODE UNCOMMENTED BY DNR ON 08-JUNE-2004 FOR THE BUGID DEENG203SYS_000188 
	-- WHILE GENERATING SERVICE,SYSTEM THROWS AN ERROR ,DELETE STATEMENT CONFLICTED WITH COLUMN REFERENCE CONSTRAINT 'DE_FW_DES_REQBR_DESBR_FKEY_DE_FW_DES_BUSINESSRULE'. THE CONFLICT OCCURRED IN DATABASE 'RVW20APPDB', 
	-- TABLE 'DE_FW_DES_REQBR_DESBR', COLUMN 'METHODID'.
	DELETE de_fw_des_reqbr_desbr
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	-- Added by Ganesh to avoid the deletion of the record in de_fw_des_brerror
	-- where the records are made in DR
	-- for the bugid :: DEENG203SYS_000236 on 24/06/04
	SELECT customer_name, /*Modification made by Manikandan P K for Bug id : PNR2.0_29939 Starts*/
		methodid,
		errorid,
		upduser,
		updtime,
		project_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		sperrorcode,
		process_name,
		component_name,
		error_context,
		ecrno /*Modification made by Manikandan P K for Bug id : PNR2.0_29939 Ends*/
	INTO #de_fw_des_brerror
	FROM de_fw_des_brerror(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	DELETE de_fw_des_brerror
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--METHOD
	DELETE de_fw_des_businessrule
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND methodid IN (
			SELECT methodid
			FROM #service_methodid_tmp(NOLOCK)
			)

	--ILBO MAPPING
	DELETE de_fw_des_ilbo_service_view_Datamap
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--attributemap changes kiruthika 
	DELETE de_fw_des_ilbo_service_view_attributemap
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--ILBO SERVICE MAPPING
	DELETE de_fw_des_ilbo_services
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--SERVICE SEGMENT DATAITEM
	DELETE de_fw_des_service_dataitem
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--SERVICE BO SEGMENT DATAITEM
	DELETE de_fw_des_dataitem
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND dataitemname NOT IN (
			SELECT dataitemname
			FROM de_fw_Des_Service_dataitem(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
			)

	--SERVICE SEGMENTS
	DELETE de_fw_des_service_segment
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--SERVICE SEGMENT DOCUMENTATION
	DELETE de_fw_des_service_documentation
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND servicename = @tsk_service_name

	--SERVICE
	DELETE de_fw_des_service
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND componentname = @component_name
		AND servicename = @tsk_service_name

	--DELETING FLOW BR AND METHOD MAPPING
	DELETE
	FROM de_flowbr_method_map
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND activity_name = @activity_name
		AND service_name = @tsk_service_name

	--DELETING FROM HIDDEN VIEW DEFINITION FOR THE CONTROLS WHICH 
	--ARE NOT HAVING CONTROL NAME IN COLTROL MASTER
	DELETE
	FROM de_hidden_view
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND activity_name = @activity_name
		AND ui_name = @ui_name
		AND page_name = @page_name
		AND control_bt_synonym NOT IN (
			SELECT control_bt_synonym
			FROM de_ui_control(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND page_bt_synonym = @page_name
			
			UNION
			
			SELECT column_bt_synonym
			FROM de_ui_grid(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
				AND activity_name = @activity_name
				AND ui_name = @ui_name
				AND page_bt_synonym = @page_name
			)

	-------------------------
	--CREATING SERVICE DATA--
	-------------------------
	IF IsNull(@task_type, '') NOT IN ('Zoom')
	BEGIN
		IF IsNull(@task_prfx, '') = ''
		BEGIN
			SELECT @msg = 'Unable to Identify Task Prefix.'

			EXEC engg_error_sp 'de_generate_service',
				2,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--FRAMING SERVIC NAME
		-- code added by Ganesh on 21/11/04 to get a new service, method name for help task
		IF @task_type = 'Help'
		BEGIN
			SELECT @service_idfr = @service_idfr + '_Hp_'

			SELECT @service_name = IsNull(@component_prfx + @ui_prfx + @service_idfr + @task_prfx, '')
		END
		ELSE IF @task_type = 'UI'
			AND @task_descr LIKE 'Set Focus Event For%'
		BEGIN
			SELECT @service_idfr = @service_idfr + '_Sf_'

			SELECT @service_name = IsNull(@component_prfx + @ui_prfx + @service_idfr + @task_prfx, '')
		END
		ELSE IF @task_type = 'UI'
			AND @task_descr LIKE 'Leave Focus Event For%'
		BEGIN
			SELECT @service_idfr = @service_idfr + '_Lf_'

			SELECT @service_name = IsNull(@component_prfx + @ui_prfx + @service_idfr + @task_prfx, '')
		END
		ELSE
		BEGIN
			-- Added By Feroz For listedit
			IF @task_descr = 'List Edit Onfocus Task'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'OnFc'

				SELECT @mt_prfx = @mt_prfx + 'OnFc'

				SELECT @sp_prfx = @sp_prfx + 'OnFc'

				SELECT @rs_prfx = @rs_prfx + 'OnFc'

				SELECT @ps_prfx = @ps_prfx + 'OnFc'
			END
			ELSE IF @task_descr = 'List Edit Refill Task'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'ReFl'

				SELECT @mt_prfx = @mt_prfx + 'ReFl'

				SELECT @sp_prfx = @sp_prfx + 'ReFl'

				SELECT @rs_prfx = @rs_prfx + 'ReFl'

				SELECT @ps_prfx = @ps_prfx + 'ReFl'
			END
			ELSE IF @task_descr = 'Expand Event'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Exp'

				SELECT @mt_prfx = @mt_prfx + 'Exp'

				SELECT @sp_prfx = @sp_prfx + 'Exp'

				SELECT @rs_prfx = @rs_prfx + 'Exp'

				SELECT @ps_prfx = @ps_prfx + 'Exp'
			END
			-- Added for TECH-46646 Starts
			ELSE IF @task_descr = 'Pagination Event for Mobility'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Pag'
				SELECT @mt_prfx = @mt_prfx + 'Pag'
				SELECT @sp_prfx = @sp_prfx + 'Pag'
				SELECT @rs_prfx = @rs_prfx + 'Pag'
				SELECT @ps_prfx = @ps_prfx + 'Pag'
			END
			ELSE IF @task_descr = 'AssociatedUpdateTask'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Upd'
				SELECT @mt_prfx = @mt_prfx + 'Upd'
				SELECT @sp_prfx = @sp_prfx + 'Upd'
				SELECT @rs_prfx = @rs_prfx + 'Upd'
				SELECT @ps_prfx = @ps_prfx + 'Upd'
			END
			ELSE IF @task_descr = 'AssociatedDeleteTask'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Del'
				SELECT @mt_prfx = @mt_prfx + 'Del'
				SELECT @sp_prfx = @sp_prfx + 'Del'
				SELECT @rs_prfx = @rs_prfx + 'Del'
				SELECT @ps_prfx = @ps_prfx + 'Del'
			END
			--TECH-75230 (Service generation for pre/post task )
			ELSE IF @task_descr LIKE 'Pre Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Pr'
				SELECT @mt_prfx = @mt_prfx + 'Pr'
				SELECT @sp_prfx = @sp_prfx + 'Pr'
				SELECT @rs_prfx = @rs_prfx + 'Pr'
				SELECT @ps_prfx = @ps_prfx + 'Pr'
			END
			ELSE IF @task_descr LIKE 'Post Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Ps'
				SELECT @mt_prfx = @mt_prfx + 'Ps'
				SELECT @sp_prfx = @sp_prfx + 'Ps'
				SELECT @rs_prfx = @rs_prfx + 'Ps'
				SELECT @ps_prfx = @ps_prfx + 'Ps'
			END
			ELSE IF @task_descr LIKE 'Browse Pre Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Bpr'
				SELECT @mt_prfx = @mt_prfx + 'Bpr'
				SELECT @sp_prfx = @sp_prfx + 'Bpr'
				SELECT @rs_prfx = @rs_prfx + 'Bpr'
				SELECT @ps_prfx = @ps_prfx + 'Bpr'
			END
			ELSE IF @task_descr LIKE 'Browse Post Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Bps'
				SELECT @mt_prfx = @mt_prfx + 'Bps'
				SELECT @sp_prfx = @sp_prfx + 'Bps'
				SELECT @rs_prfx = @rs_prfx + 'Bps'
				SELECT @ps_prfx = @ps_prfx + 'Bps'
			END
			ELSE IF @task_descr LIKE 'Delete Pre Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Dpr'
				SELECT @mt_prfx = @mt_prfx + 'Dpr'
				SELECT @sp_prfx = @sp_prfx + 'Dpr'
				SELECT @rs_prfx = @rs_prfx + 'Dpr'
				SELECT @ps_prfx = @ps_prfx + 'Dpr'
			END
			ELSE IF @task_descr LIKE 'Delete Post Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Dps'
				SELECT @mt_prfx = @mt_prfx + 'Dps'
				SELECT @sp_prfx = @sp_prfx + 'Dps'
				SELECT @rs_prfx = @rs_prfx + 'Dps'
				SELECT @ps_prfx = @ps_prfx + 'Dps'
			END
			ELSE IF @task_descr LIKE 'Clear Task for attachment of%'
			BEGIN
				SELECT @service_idfr = @service_idfr + 'Cr'
				SELECT @mt_prfx = @mt_prfx + 'Cr'
				SELECT @sp_prfx = @sp_prfx + 'Cr'
				SELECT @rs_prfx = @rs_prfx + 'Cr'
				SELECT @ps_prfx = @ps_prfx + 'Cr'
			END
			--TECH-75230

			-- Added for TECH-46646 Ends
			-- Commented for TECH-18349
			--	if @task_descr = 'Click Event'
			--	begin 
			--		select @service_idfr = @service_idfr + 'Clk'
			--		Select @mt_prfx = @mt_prfx + 'Clk'  
			--		Select @sp_prfx = @sp_prfx + 'Clk'  
			--		Select @rs_prfx = @rs_prfx + 'Clk'  
			--		Select @ps_prfx = @ps_prfx + 'Clk'  
			--	end
			--else if @task_descr = 'Collapse Event'
			--begin
			--	select @service_idfr = @service_idfr + 'Clp'				
			--			Select @mt_prfx = @mt_prfx + 'Clp'  
			--	Select @sp_prfx = @sp_prfx + 'Clp'  
			--	Select @rs_prfx = @rs_prfx + 'Clp'  
			--	Select @ps_prfx = @ps_prfx + 'Clp'
			--end
			--else if @task_descr = 'Collapse All Event'
			--begin
			--	select @service_idfr = @service_idfr + 'Cla'				
			--			Select @mt_prfx = @mt_prfx + 'Cla'  
			--	Select @sp_prfx = @sp_prfx + 'Cla'  
			--	Select @rs_prfx = @rs_prfx + 'Cla'  
			--	Select @ps_prfx = @ps_prfx + 'Cla'  
			--end
			--else if @task_descr = 'Expand All Event'
			--begin
			--	select @service_idfr = @service_idfr + 'Exa'				
			--			Select @mt_prfx = @mt_prfx + 'Exa'  
			--	Select @sp_prfx = @sp_prfx + 'Exa'  
			--	Select @rs_prfx = @rs_prfx + 'Exa'  
			--	Select @ps_prfx = @ps_prfx + 'Exa'  
			--end
			-- Commented for TECH-18349
			-- Added By Feroz For listedit			
			SELECT @service_name = IsNull(@component_prfx + @ui_prfx + @service_idfr + @task_prfx, '')
		END
		
		-- Commented for TECH-18349
		--if (@task_descr in ('Allow Deletion','Allow Insertion')) or (@task_descr like '%Event')
		--Begin
		--	select @task_prfx = substring(@task_name, len(@task_name) -2,3)
		--	Select	@service_name	= IsNull(@component_prfx+@ui_prfx+@service_idfr+@task_prfx, '')
		--End
		-- Commented for TECH-18349
		--UPDATING THE SERVICE TYPE
		SELECT @trn_scope_req = b.trn_scope_req
		FROM de_action A(NOLOCK),
			es_comp_task_type_mst_vw B(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND a.activity_name = @activity_name
			AND a.ui_name = @ui_name
			AND a.page_bt_synonym = @page_name
			AND a.task_name = @task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.task_pattern = b.task_type_name

		IF IsNull(@trn_scope_req, '') = ''
			SELECT @trn_scope_req = 'Y'

		IF @trn_scope_req = 'Y'
			SELECT @service_type = 2
		ELSE
			SELECT @service_type = 0

		--Code added By Sangeetha L for the Bug ID:PNR2.0_3277 
		--Bug Descr:Invalid primary key violation in table fw_des_service
		IF EXISTS (
				SELECT 's'
				FROM de_fw_Des_service(NOLOCK)
				WHERE customer_name = @customer_name
					AND project_name = @project_name
					AND process_name = @process_name
					AND componentname = @component_name
					AND servicename = @service_name
				)
		BEGIN
			SELECT @msg = 'The service Name : ' + @service_name + ' already exists. Associate the task to service or Change the prefix and proceed.'

			EXEC engg_error_sp 'de_generate_service',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--Code added By Sangeetha L for the Bug ID:PNR2.0_3277 
		--Bug Descr:Invalid primary key violation in table fw_des_service
		--Creating Service for the task
		INSERT INTO de_fw_Des_service (
			customer_name,
			project_name,
			process_name,
			ServiceName,
			ComponentName,
			ServiceType,
			IsIntegSer,
			StatusFlag,
			UpdUser,
			UpdTime,
			ProcessingType,
			TIMESTAMP,
			Createdby,
			createddate,
			modifiedby,
			modifieddate,
			ecrno,
			isbubblemessage --TECH-69327
			) -- chan
		VALUES (
			@customer_name,
			@project_name,
			@process_name,
			@service_name,
			@component_name,
			@service_type,
			0,
			0,
			@ctxt_user,		--TECH-73216
			@getdate,
			1,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ico_number, -- chan
			@isbubblemessage --TECH-69327
			)

		--Generating Service Documentation
		INSERT INTO de_fw_des_service_documentation (
			customer_name,
			project_name,
			process_name,
			component_name,
			ServiceName,
			SerialNo,
			DocText,
			UpdUser,
			UpdTime,
			TIMESTAMP,
			Createdby,
			createddate,
			modifiedby,
			modifieddate,
			ecrno
			) -- chan)
		VALUES (
			@customer_name,
			@project_name,
			@process_name,
			@component_name,
			@service_name,
			1,
			'Service for ' + @task_descr,
			@ctxt_user,		--TECH-73216
			@getdate,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ico_number
			) -- chan
			--Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - START 

		--- Validate if for a ML Control if Hidden View Usage is present and No task control mapping s present raise error
		-- code commented by Gowrisankar M for PNR2.0_24216 on 08-Oct-2009 - starts
		-- 			If exists (Select 'x' from de_hidden_view_usage a (nolock),
		-- 					   de_ui_grid b (nolock)
		-- 				where a.customer_name  = b.customer_name
		-- 				and   a.project_name   = b.project_name 
		-- 				and   a.process_name   = b.process_name
		-- 				and   a.component_name = b.component_name
		-- 				and   a.activity_name  = b.activity_name
		-- 				and   a.ui_name	       = b.ui_name
		-- 				and   a.control_page_name = b.page_bt_synonym
		-- 				and   a.control_bt_sysnonym = b.column_bt_synonym
		-- 				and   a.action_name  = @task_name
		-- 				and   a.customer_name  = @customer_name
		-- 				and   a.project_name   = @project_name
		-- 				and   a.process_name   = @process_name
		-- 				and   a.component_name = @component_name
		-- 				and   a.activity_name  = @activity_name
		-- 				and   a.ui_name	       = @ui_name
		-- 				and   a.control_page_name = @page_name
		-- 				and   not exists (Select 'x' from de_task_control_map c(nolock)
		-- 						where a.customer_name  = c.customer_name
		-- 						and   a.project_name   = c.project_name
		-- 						and   a.process_name   = c.process_name
		-- 						and   a.component_name = c.component_name
		-- 						and   a.activity_name  = c.activity_name
		-- 						and   a.ui_name	       = c.ui_name
		-- 						and   a.control_page_name = c.page_name
		-- 						and   a.control_bt_sysnonym  = c.control_bt_synonym
		-- 						and   c.map_flag = 'Y'
		-- 						and   c.action_name = @task_name))
		-- 		begin
		-- 			Select @msg =  a.control_bt_sysnonym from de_hidden_view_usage a (nolock),
		-- 					   de_ui_grid b (nolock)
		-- 				where a.customer_name  = b.customer_name
		-- 				and   a.project_name   = b.project_name 
		-- 				and   a.process_name   = b.process_name
		-- 				and   a.component_name = b.component_name
		-- 				and   a.activity_name  = b.activity_name
		-- 				and   a.ui_name	       = b.ui_name
		-- 				and   a.control_page_name = b.page_bt_synonym
		-- 				and   a.control_bt_sysnonym = b.column_bt_synonym
		-- 				and   a.action_name  = @task_name
		-- 				and   a.customer_name  = @customer_name
		-- 				and   a.project_name   = @project_name
		-- 				and   a.process_name   = @process_name
		-- 				and   a.component_name = @component_name
		-- 				and   a.activity_name  = @activity_name
		-- 				and   a.ui_name	       = @ui_name
		-- 				and   a.control_page_name = @page_name
		-- 				and   not exists (Select 'x' from de_task_control_map c(nolock)
		-- 						where a.customer_name  = c.customer_name
		-- 						and   a.project_name   = c.project_name
		-- 						and   a.process_name   = c.process_name
		-- 						and   a.component_name = c.component_name
		-- 						and   a.activity_name  = c.activity_name
		-- 						and   a.ui_name	       = c.ui_name
		-- 						and   a.control_page_name = c.page_name
		-- 						and   a.control_bt_sysnonym  = c.control_bt_synonym
		-- 						and   c.map_flag = 'Y'
		-- 						and   c.action_name = @task_name)
		-- 
		-- 			Select	@msg = 'For the control ' + isnull(@msg, '') + ' only Hidden View Usage mapping exist and Task Control Mapping does not exist.'
		-- 			exec	engg_error_sp	'de_generate_service',
		-- 						1,
		-- 						@msg,
		-- 						@ctxt_language,
		-- 						@ctxt_ouinstance,
		-- 						@ctxt_service,
		-- 						@ctxt_user,
		-- 						'',
		-- 						'',
		-- 						'',
		-- 						'',
		-- 						@m_errorid output
		-- 			Return
		-- 		end
		-- code commented by Gowrisankar M for PNR2.0_24216 on 08-Oct-2009 - Ends
		--code added by saravanan for bugid:PNR2.0_6863
		--- Validate if for a ML Control if Hidden View Usage is present and No task control mapping s present raise error
		IF @task_type = 'Init'
			AND EXISTS (
				SELECT 'x'
				FROM de_hidden_view_usage a(NOLOCK),
					de_ui_control b(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND b.customer_name = c.customer_name
					AND b.project_name = c.project_name
					AND b.process_name = c.process_name
					AND b.component_name = c.component_name
					AND b.control_type = c.ctrl_type_name
					AND c.base_ctrl_type = 'COMBO'
					AND a.control_page_name = b.page_bt_synonym
					AND a.control_bt_sysnonym = b.control_bt_synonym
					AND a.action_name = @task_name
					AND a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @process_name
					AND a.component_name = @component_name
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name
					AND a.control_page_name = @page_name
					AND NOT EXISTS (
						SELECT 'x'
						FROM de_task_control_map d(NOLOCK)
						WHERE a.customer_name = d.customer_name
							AND a.project_name = d.project_name
							AND a.process_name = d.process_name
							AND a.component_name = d.component_name
							AND a.activity_name = d.activity_name
							AND a.ui_name = d.ui_name
							AND a.control_page_name = d.page_name
							AND a.control_bt_sysnonym = d.control_bt_synonym
							AND d.map_flag = 'Y'
							AND d.action_name = @task_name
						)
				)
		BEGIN
			SELECT @msg = a.control_bt_sysnonym
			FROM de_hidden_view_usage a(NOLOCK),
				de_ui_control b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.control_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'COMBO'
				AND a.control_page_name = b.page_bt_synonym
				AND a.control_bt_sysnonym = b.control_bt_synonym
				AND a.action_name = @task_name
				AND a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.control_page_name = @page_name
				AND NOT EXISTS (
					SELECT 'x'
					FROM de_task_control_map d(NOLOCK)
					WHERE a.customer_name = d.customer_name
						AND a.project_name = d.project_name
						AND a.process_name = d.process_name
						AND a.component_name = d.component_name
						AND a.activity_name = d.activity_name
						AND a.ui_name = d.ui_name
						AND a.control_page_name = d.page_name
						AND a.control_bt_sysnonym = d.control_bt_synonym
						AND d.map_flag = 'Y'
						AND d.action_name = @task_name
					)

			SELECT @msg = 'For Init Task, the Combo control ' + isnull(@msg, '') + ' only Hidden View Usage mapping exist and Task Control Mapping does not exist.'

			EXEC engg_error_sp 'de_generate_service',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--code added by saravanan for bugid:PNR2.0_6863	
		--Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - END
		-- code added by Anuradha on 29-Nov-2006 for the Bug ID :: PNR2.0_11220 - START
		IF @task_type = 'Init'
			AND EXISTS (
				SELECT 'x'
				FROM de_task_control_map a(NOLOCK),
					de_ui_control b(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					de_hidden_view e(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND b.customer_name = c.customer_name
					AND b.project_name = c.project_name
					AND b.process_name = c.process_name
					AND b.component_name = c.component_name
					AND b.control_type = c.ctrl_type_name
					AND c.base_ctrl_type = 'COMBO'
					AND a.page_name = b.page_bt_synonym
					AND a.control_bt_synonym = b.control_bt_synonym
					AND a.action_name = @task_name
					AND a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @process_name
					AND a.component_name = @component_name
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name
					AND a.page_name = @page_name
					AND a.map_flag = 'Y'
					-- code modified for the Bug PNR2.0_11244
					AND a.customer_name = e.customer_name
					AND a.project_name = e.project_name
					AND a.process_name = e.process_name
					AND a.component_name = e.component_name
					AND a.activity_name = e.activity_name
					AND a.ui_name = e.ui_name
					AND a.page_name = e.page_name
					AND a.control_bt_synonym = e.control_bt_synonym
					AND NOT EXISTS (
						SELECT 'x'
						FROM de_hidden_view_usage d(NOLOCK)
						WHERE e.customer_name = d.customer_name
							AND e.project_name = d.project_name
							AND e.process_name = d.process_name
							AND e.component_name = d.component_name
							AND e.activity_name = d.activity_name
							AND e.ui_name = d.ui_name
							AND e.page_name = d.control_page_name
							AND e.control_bt_synonym = d.control_bt_sysnonym
							AND e.hidden_view_bt_synonym = d.hidden_view_bt_sysnonym
							AND d.action_name = @task_name
						)
				)
		BEGIN
			SELECT @msg = a.control_bt_synonym
			FROM de_task_control_map a(NOLOCK),
				de_ui_control b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK),
				de_hidden_view e(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.control_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'COMBO'
				AND a.page_name = b.page_bt_synonym
				AND a.control_bt_synonym = b.control_bt_synonym
				AND a.action_name = @task_name
				AND a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_name = @page_name
				AND a.map_flag = 'Y'
				-- code modified for the Bug PNR2.0_11244
				AND a.customer_name = e.customer_name
				AND a.project_name = e.project_name
				AND a.process_name = e.process_name
				AND a.component_name = e.component_name
				AND a.activity_name = e.activity_name
				AND a.ui_name = e.ui_name
				AND a.page_name = e.page_name
				AND a.control_bt_synonym = e.control_bt_synonym
				AND NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view_usage d(NOLOCK)
					WHERE e.customer_name = d.customer_name
						AND e.project_name = d.project_name
						AND e.process_name = d.process_name
						AND e.component_name = d.component_name
						AND e.activity_name = d.activity_name
						AND e.ui_name = d.ui_name
						AND e.page_name = d.control_page_name
						AND e.control_bt_synonym = d.control_bt_sysnonym
						AND e.hidden_view_bt_synonym = d.hidden_view_bt_sysnonym
						AND d.action_name = @task_name
					)

				--TECH-73996
					IF ISNULL(@msg,'') <> '' 
					AND EXISTS(
					SELECT 'X' FROM de_fw_des_br_logical_parameter a (NOLOCK)
					JOIN de_task_service_method_vw b (NOLOCK)
					ON	a.customer_name		=	b.customer_name
					AND	a.project_name		=	b.project_name
					AND	a.process_name		=	b.process_name
					AND	a.component_name	=	b.component_name
					AND	a.method_name		=	b.method_name
					WHERE a.customer_name		= @customer_name
					AND a.project_name			= @project_name
					AND a.process_name			= @process_name
					AND a.component_name		= @component_name
					AND	b.activity_name			= @activity_name
					AND b.ui_name				= @ui_name
					AND	a.logicalparametername	= @msg
					AND	b.task_name				= @task_name)
				--TECH-73996
			BEGIN  --TECH-73996
			SELECT @msg = 'In Init Task, for the Combo control ' + isnull(@msg, '') + ' only Task Control Mapping exist and Hidden View Usage mapping does not exist.'

			EXEC engg_error_sp 'de_generate_service',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
			END ----TECH-73996
		END

		IF @task_type = 'Init'
			AND EXISTS (
				SELECT 'x'
				FROM de_task_control_map a(NOLOCK),
					de_ui_grid b(NOLOCK),
					es_comp_ctrl_type_mst c(NOLOCK),
					de_hidden_view e(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND b.customer_name = c.customer_name
					AND b.project_name = c.project_name
					AND b.process_name = c.process_name
					AND b.component_name = c.component_name
					AND b.column_type = c.ctrl_type_name
					AND c.base_ctrl_type = 'COMBO'
					AND a.page_name = b.page_bt_synonym
					AND a.control_bt_synonym = b.column_bt_synonym
					AND a.action_name = @task_name
					AND a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @process_name
					AND a.component_name = @component_name
					AND a.activity_name = @activity_name
					AND a.ui_name = @ui_name
					AND a.page_name = @page_name
					AND a.map_flag = 'Y'
					-- code modified for the Bug PNR2.0_11244
					AND a.customer_name = e.customer_name
					AND a.project_name = e.project_name
					AND a.process_name = e.process_name
					AND a.component_name = e.component_name
					AND a.activity_name = e.activity_name
					AND a.ui_name = e.ui_name
					AND a.page_name = e.page_name
					AND a.control_bt_synonym = e.control_bt_synonym
					-- code modified for the Bug PNR2.0_11244
					AND NOT EXISTS (
						SELECT 'x'
						FROM de_hidden_view_usage d(NOLOCK)
						WHERE e.customer_name = d.customer_name
							AND e.project_name = d.project_name
							AND e.process_name = d.process_name
							AND e.component_name = d.component_name
							AND e.activity_name = d.activity_name
							AND e.ui_name = d.ui_name
							AND e.page_name = d.control_page_name
							AND e.control_bt_synonym = d.control_bt_sysnonym
							AND e.hidden_view_bt_synonym = d.hidden_view_bt_sysnonym
							AND d.action_name = @task_name
						)
				)
		BEGIN
			SELECT @msg = a.control_bt_synonym
			FROM de_task_control_map a(NOLOCK),
				de_ui_grid b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK),
				de_hidden_view e(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.column_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'COMBO'
				AND a.page_name = b.page_bt_synonym
				AND a.control_bt_synonym = b.column_bt_synonym
				AND a.action_name = @task_name
				AND a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name
				AND a.component_name = @component_name
				AND a.activity_name = @activity_name
				AND a.ui_name = @ui_name
				AND a.page_name = @page_name
				AND a.map_flag = 'Y'
				-- code modified for the Bug PNR2.0_11244
				AND a.customer_name = e.customer_name
				AND a.project_name = e.project_name
				AND a.process_name = e.process_name
				AND a.component_name = e.component_name
				AND a.activity_name = e.activity_name
				AND a.ui_name = e.ui_name
				AND a.page_name = e.page_name
				AND a.control_bt_synonym = e.control_bt_synonym
				-- code modified for the Bug PNR2.0_11244
				AND NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view_usage d(NOLOCK)
					WHERE e.customer_name = d.customer_name
						AND e.project_name = d.project_name
						AND e.process_name = d.process_name
						AND e.component_name = d.component_name
						AND e.activity_name = d.activity_name
						AND e.ui_name = d.ui_name
						AND e.page_name = d.control_page_name
						AND e.control_bt_synonym = d.control_bt_sysnonym
						AND e.hidden_view_bt_synonym = d.hidden_view_bt_sysnonym
						AND d.action_name = @task_name
					)

					----TECH-73996
					IF ISNULL(@msg,'') <> '' 
					AND EXISTS(
					SELECT 'X' FROM de_fw_des_br_logical_parameter a (NOLOCK)
					JOIN de_task_service_method_vw b (NOLOCK)
					ON	a.customer_name		=	b.customer_name
					AND	a.project_name		=	b.project_name
					AND	a.process_name		=	b.process_name
					AND	a.component_name	=	b.component_name
					AND	a.method_name		=	b.method_name
					WHERE a.customer_name		= @customer_name
					AND a.project_name			= @project_name
					AND a.process_name			= @process_name
					AND a.component_name		= @component_name
					AND	b.activity_name			= @activity_name
					AND b.ui_name				= @ui_name
					AND	a.logicalparametername	= @msg
					AND	b.task_name				= @task_name)
				----TECH-73996
			
			BEGIN ----TECH-73996
			SELECT @msg = 'In Init Task, for the Combo control ' + isnull(@msg, '') + ' ,only Task Control Mapping exist and Hidden View Usage mapping  does not exist.'

			EXEC engg_error_sp 'de_generate_service',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
			END	----TECH-73996
		END

		-- code added by Anuradha on 29-Nov-2006 for the Bug ID :: PNR2.0_11220 - END
		-----------------------------------
		--GENERATING SERVICE SEGMENT DATA--
		-----------------------------------
		-- code added on 01-02-2007 for the BUG ID :: PNR2.0_12066 - start
		IF @task_type = 'report'
		BEGIN
			SET @task_type = 'Trans'
		END

		-- code added on 01-02-2007 for the BUG ID :: PNR2.0_12066 - End
		--SP TO CREATE SERVICE SEGMENT AND SERVICE SEGMENT DATAITEM
		EXEC de_generate_service_segment @Ctxt_Language,
			@Ctxt_Service,
			@Ctxt_OUInstance,
			@Ctxt_User,
			@customer_name,
			@project_name,
			@ico_number,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			@page_name,
			@task_name,
			@task_type,
			@service_name,
			@component_prfx,
			@bo_idfr,
			@hdr_segmt_idfr,
			@cbo_segmt_idfr,
			@mlcb_segmt_idfr,
			@ml_segmt_idfr,
			@ml_out_segmt_idfr

		--CREATING TEMPORARY TABLE #METHOD_SEGMENT_MAP TO HOLD THE METHODID AND SEGMENT NAME MAPPING
		--  code added  for handling #table by Muthu Kumar. K on 19-01-06
		CREATE TABLE #method_segment_map (
			methodid INT,
			segment_name VARCHAR(70) collate database_default
			)

		----------------------
		--GENERATING METHODS--
		----------------------
		--code added by saravanan for bugid:PNR2.0_10978
		IF @task_type = 'report'
		BEGIN
			SET @task_type = 'Trans'
		END

		--SP TO GENERATE METHODS AND METHOD PARAMETERS
		EXEC de_generate_methods @Ctxt_Language,
			@Ctxt_Service,
			@Ctxt_OUInstance,
			@Ctxt_User,
			@customer_name,
			@project_name,
			@ico_number,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			@page_name,
			@task_name,
			@task_type,
			@service_name,
			@component_prfx,
			@mt_prfx,
			@cb_load_idfr,
			@cb_def_idfr,
			@hdr_valid_idfr,
			@hdr_sgmt_idfr,
			@cb_sgmt_idfr,
			@ml_sgmt_idfr,
			@mlcb_sgmt_idfr,
			@ml_out_sgmt_idfr,
			@sp_prfx,
			@rs_prfx,
			@ps_prfx,
			@cbhdr_sgmt_idfr,
			@hdr_ref_idfr,
			@hdr_fet_idfr,
			@hdr_chk_idfr,
			@err_chk_idfr,
			@hdr_save_idfr,
			@ps_ref_idfr,
			@mt_out_idfr,
			@sp_out_idfr,
			@bo_idfr

		-- code modified by Ganesh to avoid deleting the control which are present in both the header & multi under a ui 
		-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - START
		-- While generating services, a header control mapped to ml is missing in ML methods.
		-- Code Added for BugId :  PNR2.0_2825
		DELETE a
		FROM de_fw_des_br_logical_parameter A(NOLOCK),
			de_fw_des_processsection_br_is B(NOLOCK),
			de_task_control_map C(NOLOCK),
			de_ui_control D(NOLOCK)
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.methodid = b.methodid
			AND a.method_name = b.method_name
			AND a.customer_name = c.customer_name
			AND a.project_name = c.project_name
			AND a.process_name = c.process_name
			AND a.component_name = c.component_name
			AND a.logicalparametername = c.new_control_bt_synonym
			AND c.customer_name = d.customer_name
			AND c.project_name = d.project_name
			AND c.process_name = d.process_name
			AND c.component_name = d.component_name
			AND c.activity_name = d.activity_name
			AND c.ui_name = d.ui_name
			AND c.page_name = d.page_bt_synonym
			AND c.control_bt_synonym = d.control_bt_synonym
			--Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - START 
			AND c.map_flag = 'Y'
			--Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - END
			AND c.map_ml_flag = 'N'
			AND c.customer_name = @customer_name
			AND c.project_name = @project_name
			AND c.process_name = @process_name
			AND c.component_name = @component_name
			AND c.activity_name = @activity_name
			AND c.ui_name = @ui_name
			AND c.action_name = @task_name
			AND b.servicename = @service_name
			AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
				SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
				FROM de_fw_des_processsection_br_is A(NOLOCK),
					#method_segment_map B(NOLOCK),
					de_fw_des_service_dataitem C(NOLOCK),
					de_ui_grid E(NOLOCK),
					de_task_control_map F(NOLOCK)
				WHERE a.methodid = b.methodid
					-- code modified by Ganesh for the bugid :: PNR2.0_2825 on 13/6/05
					AND c.segmentname collate database_default = b.segment_name
					AND e.customer_name = f.customer_name
					AND e.project_name = f.project_name
					AND e.process_name = f.process_name
					AND e.component_name = f.component_name
					AND e.activity_name = f.activity_name
					AND e.ui_name = f.ui_name
					AND e.page_bt_synonym = f.page_name
					AND e.section_bt_synonym = f.section_name
					AND e.column_bt_synonym = f.control_bt_synonym
					AND c.customer_name = f.customer_name
					AND c.project_name = f.project_name
					AND c.process_name = f.process_name
					AND c.component_name = f.component_name
					AND c.dataitemname = f.new_control_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.servicename = a.servicename
					AND f.customer_name = @customer_name
					AND f.project_name = @project_name
					AND f.process_name = @process_name
					AND f.component_name = @component_name
					AND f.activity_name = @activity_name
					AND f.ui_name = @ui_name
					AND f.action_name = @task_name
					AND a.servicename = @service_name
					-- start Added BY Feroz For bug id : PNR2.0_21082
					AND NOT EXISTS (
						SELECT 'x'
						FROM #populate_mapped_controls_extjs x(NOLOCK)
						WHERE x.page_bt_synonym = e.page_bt_synonym
							AND x.control_bt_synonym = e.control_bt_synonym
						
						UNION
						
						SELECT 'x'
						FROM #populate_header_control_extjs z(NOLOCK)
						WHERE z.control_name = e.column_bt_synonym
						)
				)

		-- end Added BY Feroz For bug id : PNR2.0_21082
		-- Code Commented by feroz since Mapping to Ml methods handled in Hidden View usage 
		--- Code added by Saravanan on 01/06/2005 for PNR2.0_2678 - START
		--- Remove Hidden Views for Hdr Controls while or not mapped to ML Methods
		-- 	delete	a
		-- 	from	de_fw_des_br_logical_parameter		A (nolock),
		-- 			de_fw_des_processsection_br_is		B (nolock),
		-- 			de_task_control_map					C (nolock),
		-- 			de_ui_control						D (nolock),
		-- 			de_hidden_view						E (nolock)
		-- 	where	a.customer_name				= b.customer_name
		-- 	and		a.project_name				= b.project_name
		-- 	and 	a.process_name				= b.process_name
		-- 	and 	a.component_name			= b.component_name	
		-- 	and		a.methodid					= b.methodid
		-- 	and		a.method_name				= b.method_name
		-- 
		-- 	and		a.customer_name				= e.customer_name
		-- 	and		a.project_name				= e.project_name
		-- 	and 	a.process_name				= e.process_name
		-- 	and 	a.component_name			= e.component_name
		-- 	and		a.logicalparametername		= e.new_control_bt_synonym
		-- 
		-- 	and		c.customer_name				= d.customer_name
		-- 	and		c.project_name				= d.project_name
		-- 	and		c.process_name				= d.process_name
		-- 	and		c.component_name			= d.component_name
		-- 	and		c.activity_name				= d.activity_name
		-- 	and		c.ui_name					= d.ui_name
		-- 	and		c.page_name					= d.page_bt_synonym
		-- 	and		c.control_bt_synonym		= d.control_bt_synonym
		-- --Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - START 
		-- 	and		c.map_flag 					= 'Y'
		-- --Code modified by Saravanan on 02/03/2006 for PNR2.0_6784 - END
		-- 	and		c.map_ml_flag				= 'N'
		-- 	and		c.customer_name				= d.customer_name
		-- 	and		c.project_name				= d.project_name
		-- 	and		c.process_name				= d.process_name
		-- 	and		c.component_name			= d.component_name
		-- 	and		c.activity_name				= d.activity_name
		-- 	and		c.ui_name					= d.ui_name
		-- 	and		c.page_name					= d.page_bt_synonym
		-- 	and		c.control_bt_synonym		= d.control_bt_synonym
		-- 
		-- 	and		d.customer_name				= e.customer_name
		-- 	and		d.project_name				= e.project_name
		-- 	and		d.process_name				= e.process_name
		-- 	and		d.component_name			= e.component_name
		-- 	and		d.activity_name				= e.activity_name
		-- 	and		d.ui_name					= e.ui_name
		-- 	and		d.page_bt_synonym			= e.page_name
		-- 	and		d.control_bt_synonym		= e.control_bt_synonym
		-- 
		-- 	and		c.customer_name				= @customer_name
		-- 	and		c.project_name				= @project_name
		-- 	and		c.process_name				= @process_name
		-- 	and		c.component_name			= @component_name
		-- 	and		c.activity_name				= @activity_name
		-- 	and		c.ui_name					= @ui_name
		-- 	and		c.action_name				= @task_name
		-- 	and		b.servicename				= @service_name
		-- 	and		a.customer_name+a.project_name+cast(a.methodid as varchar(10))+a.method_name+a.process_name+a.component_name 
		-- 	collate database_default
		-- 	in
		-- 			(select	distinct a.customer_name+a.project_name+cast(a.methodid as varchar(10))+a.method_name+a.process_name+a.component_name 
		-- 			from	de_fw_des_processsection_br_is 	A (nolock),
		-- 					#method_segment_map				B (nolock),
		-- 					de_fw_des_service_dataitem		C (nolock),
		-- 					de_ui_grid						E (nolock),
		-- 					de_task_control_map				F (nolock)
		-- 			where	a.methodid			= b.methodid
		-- 			-- code modified by Ganesh for the bugid :: PNR2.0_2825 on 13/6/05
		-- 			and		c.segmentname		collate database_default = b.segment_name
		-- 			and		e.customer_name		= f.customer_name
		-- 			and		e.project_name		= f.project_name
		-- 			and		e.process_name		= f.process_name
		-- 			and		e.component_name	= f.component_name
		-- 			and		e.activity_name		= f.activity_name
		-- 			and		e.ui_name			= f.ui_name
		-- 			and		e.page_bt_synonym	= f.page_name
		-- 			and		e.section_bt_synonym= f.section_name
		-- 			and		e.column_bt_synonym	= f.control_bt_synonym
		-- 			
		-- 			and		c.customer_name		= f.customer_name
		-- 			and		c.project_name		= f.project_name
		-- 			and		c.process_name		= f.process_name
		-- 			and		c.component_name	= f.component_name
		-- 			and		c.dataitemname		= f.new_control_bt_synonym
		-- 			
		-- 			and		c.customer_name		= a.customer_name
		-- 			and		c.project_name		= a.project_name
		-- 			and		c.process_name		= a.process_name
		-- 			and		c.component_name	= a.component_name
		-- 			and		c.servicename		= a.servicename
		-- 			
		-- 			and		f.customer_name		= @customer_name
		-- 			and		f.project_name		= @project_name
		-- 			and		f.process_name		= @process_name
		-- 			and		f.component_name	= @component_name
		-- 			and		f.activity_name		= @activity_name
		-- 			and		f.ui_name			= @ui_name
		-- 			and		f.action_name		= @task_name
		-- 			and		a.servicename		= @service_name
		-- 			)
		--- Code added by Saravanan on 01/06/2005 for PNR2.0_2678 - END
		--- Remove Hidden Views for Hdr Controls while or not mapped to ML Methods
		--- Code added by Saravanan on 27/02/2005 for PNR2.0_6386- START
		--- If Map_ML_Flag = 'Y' and Transfer only Hidden View = 'Y' - Delete parameter from de_fw_des_br_logical_parameter
		--- for ML Methods where Hdr Control came as 'OUT'
		DELETE a
		FROM de_fw_des_br_logical_parameter a(NOLOCK),
			de_fw_des_processsection_br_is b(NOLOCK),
			de_task_control_map c(NOLOCK),
			de_ui_control d(NOLOCK),
			de_hidden_view e(NOLOCK)
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.methodid = b.methodid
			AND a.method_name = b.method_name
			AND a.customer_name = e.customer_name
			AND a.project_name = e.project_name
			AND a.process_name = e.process_name
			AND a.component_name = e.component_name
			AND a.customer_name = c.customer_name
			AND a.project_name = c.project_name
			AND a.process_name = c.process_name
			AND a.component_name = c.component_name
			AND a.logicalparametername = c.new_control_bt_synonym
			AND a.flowdirection = 1
			AND c.customer_name = d.customer_name
			AND c.project_name = d.project_name
			AND c.process_name = d.process_name
			AND c.component_name = d.component_name
			AND c.activity_name = d.activity_name
			AND c.ui_name = d.ui_name
			AND c.page_name = d.page_bt_synonym
			AND c.control_bt_synonym = d.control_bt_synonym
			AND c.map_ml_flag = 'Y'
			AND e.transfer_flag = 'Y'
			AND c.customer_name = d.customer_name
			AND c.project_name = d.project_name
			AND c.process_name = d.process_name
			AND c.component_name = d.component_name
			AND c.activity_name = d.activity_name
			AND c.ui_name = d.ui_name
			AND c.page_name = d.page_bt_synonym
			AND c.control_bt_synonym = d.control_bt_synonym
			AND d.customer_name = e.customer_name
			AND d.project_name = e.project_name
			AND d.process_name = e.process_name
			AND d.component_name = e.component_name
			AND d.activity_name = e.activity_name
			AND d.ui_name = e.ui_name
			AND d.page_bt_synonym = e.page_name
			AND d.control_bt_synonym = e.control_bt_synonym
			AND c.customer_name = @customer_name
			AND c.project_name = @project_name
			AND c.process_name = @process_name
			AND c.component_name = @component_name
			AND c.activity_name = @activity_name
			AND c.ui_name = @ui_name
			AND c.action_name = @task_name
			AND b.servicename = @service_name
			AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
				SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
				FROM de_fw_des_processsection_br_is a(NOLOCK),
					#method_segment_map b(NOLOCK),
					de_fw_des_service_dataitem c(NOLOCK),
					de_ui_grid e(NOLOCK),
					de_task_control_map f(NOLOCK)
				WHERE a.methodid = b.methodid
					-- code modified by Ganesh for the bugid :: PNR2.0_2825 on 13/6/05
					AND c.segmentname collate database_default = b.segment_name
					AND e.customer_name = f.customer_name
					AND e.project_name = f.project_name
					AND e.process_name = f.process_name
					AND e.component_name = f.component_name
					AND e.activity_name = f.activity_name
					AND e.ui_name = f.ui_name
					AND e.page_bt_synonym = f.page_name
					AND e.section_bt_synonym = f.section_name
					AND e.column_bt_synonym = f.control_bt_synonym
					AND c.customer_name = f.customer_name
					AND c.project_name = f.project_name
					AND c.process_name = f.process_name
					AND c.component_name = f.component_name
					AND c.dataitemname = f.new_control_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.servicename = a.servicename
					AND f.customer_name = @customer_name
					AND f.project_name = @project_name
					AND f.process_name = @process_name
					AND f.component_name = @component_name
					AND f.activity_name = @activity_name
					AND f.ui_name = @ui_name
					AND f.action_name = @task_name
					AND a.servicename = @service_name
				)

		--- Code added by Saravanan on 27/02/2005 for PNR2.0_6386- END
		--- Code added by Saravanan on 03/02/2005 for PNR2.0_6784 - END
		DELETE a
		FROM de_fw_des_br_logical_parameter a(NOLOCK),
			de_fw_des_processsection_br_is b(NOLOCK),
			de_ui_control d(NOLOCK),
			de_hidden_view e(NOLOCK),
			de_hidden_view_usage f(NOLOCK)
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.methodid = b.methodid
			AND a.method_name = b.method_name
			AND a.customer_name = e.customer_name
			AND a.project_name = e.project_name
			AND a.process_name = e.process_name
			AND a.component_name = e.component_name
			AND a.logicalparametername = e.new_control_bt_synonym
			AND a.flowdirection = 0
			AND d.customer_name = e.customer_name
			AND d.project_name = e.project_name
			AND d.process_name = e.process_name
			AND d.component_name = e.component_name
			AND d.activity_name = e.activity_name
			AND d.ui_name = e.ui_name
			AND d.page_bt_synonym = e.page_name
			AND d.control_bt_synonym = e.control_bt_synonym
			AND d.customer_name = @customer_name
			AND d.project_name = @project_name
			AND d.process_name = @process_name
			AND d.component_name = @component_name
			AND d.activity_name = @activity_name
			AND d.ui_name = @ui_name
			AND f.action_name = @task_name
			AND b.servicename = @service_name
			AND e.customer_name = f.customer_name
			AND e.project_name = f.project_name
			AND e.process_name = f.process_name
			AND e.component_name = f.component_name
			AND e.activity_name = f.activity_name
			AND e.ui_name = f.ui_name
			AND e.page_name = f.control_page_name
			AND e.control_bt_synonym = f.control_bt_sysnonym
			AND e.hidden_view_bt_synonym = f.hidden_view_bt_sysnonym
			AND f.action_name = @task_name
			AND f.map_ml_flag <> 'Y' -- Added by Feroz
			AND EXISTS (
				SELECT 'x'
				FROM de_task_control_map c(NOLOCK)
				WHERE f.customer_name = c.customer_name
					AND f.project_name = c.project_name
					AND f.process_name = c.process_name
					AND f.component_name = c.component_name
					AND f.activity_name = c.activity_name
					AND f.ui_name = c.ui_name
					AND f.control_page_name = c.page_name
					AND f.control_bt_sysnonym = c.control_bt_synonym
					AND c.action_name = @task_name
					AND c.map_flag = 'N'
					AND c.map_ml_flag = 'N'
				)
			AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
				SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
				FROM de_fw_des_processsection_br_is a(NOLOCK),
					#method_segment_map b(NOLOCK),
					de_fw_des_service_dataitem c(NOLOCK),
					de_ui_grid e(NOLOCK),
					de_task_control_map f(NOLOCK)
				WHERE a.methodid = b.methodid
					-- code modified by Ganesh for the bugid :: PNR2.0_2825 on 13/6/05
					AND c.segmentname collate database_default = b.segment_name
					AND e.customer_name = f.customer_name
					AND e.project_name = f.project_name
					AND e.process_name = f.process_name
					AND e.component_name = f.component_name
					AND e.activity_name = f.activity_name
					AND e.ui_name = f.ui_name
					AND e.page_bt_synonym = f.page_name
					AND e.section_bt_synonym = f.section_name
					AND e.column_bt_synonym = f.control_bt_synonym
					AND c.customer_name = f.customer_name
					AND c.project_name = f.project_name
					AND c.process_name = f.process_name
					AND c.component_name = f.component_name
					AND c.dataitemname = f.new_control_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.servicename = a.servicename
					AND f.customer_name = @customer_name
					AND f.project_name = @project_name
					AND f.process_name = @process_name
					AND f.component_name = @component_name
					AND f.activity_name = @activity_name
					AND f.ui_name = @ui_name
					AND f.action_name = @task_name
					AND a.servicename = @service_name
				)

		-- Code added by Gowrisankar M for PNR2.0_21616 on 01-Apr-2009 - Begins
		IF @task_type = 'Fetch'
		BEGIN
			DELETE a
			FROM de_fw_des_br_logical_parameter a(NOLOCK),
				de_fw_des_processsection_br_is b(NOLOCK),
				de_ui_control d(NOLOCK),
				de_hidden_view e(NOLOCK),
				de_hidden_view_usage f(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.methodid = b.methodid
				AND a.method_name = b.method_name
				AND a.customer_name = e.customer_name
				AND a.project_name = e.project_name
				AND a.process_name = e.process_name
				AND a.component_name = e.component_name
				AND a.logicalparametername = e.new_control_bt_synonym
				AND a.flowdirection = 0
				AND d.customer_name = e.customer_name
				AND d.project_name = e.project_name
				AND d.process_name = e.process_name
				AND d.component_name = e.component_name
				AND d.activity_name = e.activity_name
				AND d.ui_name = e.ui_name
				AND d.page_bt_synonym = e.page_name
				AND d.control_bt_synonym = e.control_bt_synonym
				AND d.customer_name = @customer_name
				AND d.project_name = @project_name
				AND d.process_name = @process_name
				AND d.component_name = @component_name
				AND d.activity_name = @activity_name
				AND d.ui_name = @ui_name
				AND f.action_name = @task_name
				AND b.servicename = @service_name
				AND e.customer_name = f.customer_name
				AND e.project_name = f.project_name
				AND e.process_name = f.process_name
				AND e.component_name = f.component_name
				AND e.activity_name = f.activity_name
				AND e.ui_name = f.ui_name
				AND e.page_name = f.control_page_name
				AND e.control_bt_synonym = f.control_bt_sysnonym
				AND e.hidden_view_bt_synonym = f.hidden_view_bt_sysnonym
				AND f.action_name = @task_name
				AND f.map_ml_flag = 'N'
				AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
					SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
					FROM de_fw_des_processsection_br_is a(NOLOCK),
						#method_segment_map b(NOLOCK),
						de_fw_des_service_dataitem c(NOLOCK),
						de_ui_grid e(NOLOCK),
						de_task_control_map f(NOLOCK)
					WHERE a.methodid = b.methodid
						AND c.segmentname collate database_default = b.segment_name
						AND e.customer_name = f.customer_name
						AND e.project_name = f.project_name
						AND e.process_name = f.process_name
						AND e.component_name = f.component_name
						AND e.activity_name = f.activity_name
						AND e.ui_name = f.ui_name
						AND e.page_bt_synonym = f.page_name
						AND e.section_bt_synonym = f.section_name
						AND e.column_bt_synonym = f.control_bt_synonym
						AND c.customer_name = f.customer_name
						AND c.project_name = f.project_name
						AND c.process_name = f.process_name
						AND c.component_name = f.component_name
						AND c.dataitemname = f.new_control_bt_synonym
						AND c.customer_name = a.customer_name
						AND c.project_name = a.project_name
						AND c.process_name = a.process_name
						AND c.component_name = a.component_name
						AND c.servicename = a.servicename
						AND f.customer_name = @customer_name
						AND f.project_name = @project_name
						AND f.process_name = @process_name
						AND f.component_name = @component_name
						AND f.activity_name = @activity_name
						AND f.ui_name = @ui_name
						AND f.action_name = @task_name
						AND a.servicename = @service_name
					)
		END

		-- Code added by Gowrisankar M for PNR2.0_21616 on 01-Apr-2009 - Ends
		-- Code modification for  PNR2.0_30127 starts
		IF @task_type = 'Disposal'
		BEGIN
			DELETE a
			FROM de_fw_des_br_logical_parameter a(NOLOCK),
				de_fw_des_processsection_br_is b(NOLOCK),
				de_ui_control d(NOLOCK),
				de_hidden_view e(NOLOCK),
				de_hidden_view_usage f(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.methodid = b.methodid
				AND a.method_name = b.method_name
				AND a.customer_name = e.customer_name
				AND a.project_name = e.project_name
				AND a.process_name = e.process_name
				AND a.component_name = e.component_name
				AND a.logicalparametername = e.new_control_bt_synonym
				AND a.flowdirection = 1
				AND d.customer_name = e.customer_name
				AND d.project_name = e.project_name
				AND d.process_name = e.process_name
				AND d.component_name = e.component_name
				AND d.activity_name = e.activity_name
				AND d.ui_name = e.ui_name
				AND d.page_bt_synonym = e.page_name
				AND d.control_bt_synonym = e.control_bt_synonym
				AND d.customer_name = @customer_name
				AND d.project_name = @project_name
				AND d.process_name = @process_name
				AND d.component_name = @component_name
				AND d.activity_name = @activity_name
				AND d.ui_name = @ui_name
				AND f.action_name = @task_name
				AND b.servicename = @service_name
				AND e.customer_name = f.customer_name
				AND e.project_name = f.project_name
				AND e.process_name = f.process_name
				AND e.component_name = f.component_name
				AND e.activity_name = f.activity_name
				AND e.ui_name = f.ui_name
				AND e.page_name = f.control_page_name
				AND e.control_bt_synonym = f.control_bt_sysnonym
				AND e.hidden_view_bt_synonym = f.hidden_view_bt_sysnonym
				AND f.action_name = @task_name
				AND f.map_ml_flag = 'N'
				AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
					SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
					FROM de_fw_des_processsection_br_is a(NOLOCK),
						#method_segment_map b(NOLOCK),
						de_fw_des_service_dataitem c(NOLOCK),
						de_ui_grid e(NOLOCK),
						de_task_control_map f(NOLOCK)
					WHERE a.methodid = b.methodid
						AND c.segmentname collate database_default = b.segment_name
						AND e.customer_name = f.customer_name
						AND e.project_name = f.project_name
						AND e.process_name = f.process_name
						AND e.component_name = f.component_name
						AND e.activity_name = f.activity_name
						AND e.ui_name = f.ui_name
						AND e.page_bt_synonym = f.page_name
						AND e.section_bt_synonym = f.section_name
						AND e.column_bt_synonym = f.control_bt_synonym
						AND c.customer_name = f.customer_name
						AND c.project_name = f.project_name
						AND c.process_name = f.process_name
						AND c.component_name = f.component_name
						AND c.dataitemname = f.new_control_bt_synonym
						AND c.customer_name = a.customer_name
						AND c.project_name = a.project_name
						AND c.process_name = a.process_name
						AND c.component_name = a.component_name
						AND c.servicename = a.servicename
						AND f.customer_name = @customer_name
						AND f.project_name = @project_name
						AND f.process_name = @process_name
						AND f.component_name = @component_name
						AND f.activity_name = @activity_name
						AND f.ui_name = @ui_name
						AND f.action_name = @task_name
						AND a.servicename = @service_name
					)
		END

		-- Code modification for  PNR2.0_30127 ends
		DELETE a
		FROM de_fw_des_br_logical_parameter a(NOLOCK),
			de_fw_des_processsection_br_is b(NOLOCK),
			de_ui_control d(NOLOCK),
			de_hidden_view e(NOLOCK),
			de_hidden_view_usage f(NOLOCK)
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.methodid = b.methodid
			AND a.method_name = b.method_name
			AND a.customer_name = e.customer_name
			AND a.project_name = e.project_name
			AND a.process_name = e.process_name
			AND a.component_name = e.component_name
			AND a.logicalparametername = e.new_control_bt_synonym
			AND a.flowdirection = 0
			AND d.customer_name = e.customer_name
			AND d.project_name = e.project_name
			AND d.process_name = e.process_name
			AND d.component_name = e.component_name
			AND d.activity_name = e.activity_name
			AND d.ui_name = e.ui_name
			AND d.page_bt_synonym = e.page_name
			AND d.control_bt_synonym = e.control_bt_synonym
			AND d.customer_name = @customer_name
			AND d.project_name = @project_name
			AND d.process_name = @process_name
			AND d.component_name = @component_name
			AND d.activity_name = @activity_name
			AND d.ui_name = @ui_name
			AND f.action_name = @task_name
			AND b.servicename = @service_name
			AND e.customer_name = f.customer_name
			AND e.project_name = f.project_name
			AND e.process_name = f.process_name
			AND e.component_name = f.component_name
			AND e.activity_name = f.activity_name
			AND e.ui_name = f.ui_name
			AND e.page_name = f.control_page_name
			AND e.control_bt_synonym = f.control_bt_sysnonym
			AND e.hidden_view_bt_synonym = f.hidden_view_bt_sysnonym
			AND f.action_name = @task_name
			AND NOT EXISTS (
				SELECT 'x'
				FROM de_task_control_map c(NOLOCK)
				WHERE f.customer_name = c.customer_name
					AND f.project_name = c.project_name
					AND f.process_name = c.process_name
					AND f.component_name = c.component_name
					AND f.activity_name = c.activity_name
					AND f.ui_name = c.ui_name
					AND f.control_page_name = c.page_name
					AND c.action_name = @task_name
					AND f.control_bt_sysnonym = c.control_bt_synonym
				)
			AND a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name collate database_default IN (
				SELECT DISTINCT a.customer_name + a.project_name + cast(a.methodid AS VARCHAR(10)) + a.method_name + a.process_name + a.component_name
				FROM de_fw_des_processsection_br_is a(NOLOCK),
					#method_segment_map b(NOLOCK),
					de_fw_des_service_dataitem c(NOLOCK),
					de_ui_grid e(NOLOCK),
					de_task_control_map f(NOLOCK)
				WHERE a.methodid = b.methodid
					-- code modified by Ganesh for the bugid :: PNR2.0_2825 on 13/6/05
					AND c.segmentname collate database_default = b.segment_name
					AND e.customer_name = f.customer_name
					AND e.project_name = f.project_name
					AND e.process_name = f.process_name
					AND e.component_name = f.component_name
					AND e.activity_name = f.activity_name
					AND e.ui_name = f.ui_name
					AND e.page_bt_synonym = f.page_name
					AND e.section_bt_synonym = f.section_name
					AND e.column_bt_synonym = f.control_bt_synonym
					AND c.customer_name = f.customer_name
					AND c.project_name = f.project_name
					AND c.process_name = f.process_name
					AND c.component_name = f.component_name
					AND c.dataitemname = f.new_control_bt_synonym
					AND c.customer_name = a.customer_name
					AND c.project_name = a.project_name
					AND c.process_name = a.process_name
					AND c.component_name = a.component_name
					AND c.servicename = a.servicename
					AND f.customer_name = @customer_name
					AND f.project_name = @project_name
					AND f.process_name = @process_name
					AND f.component_name = @component_name
					AND f.activity_name = @activity_name
					AND f.ui_name = @ui_name
					AND f.action_name = @task_name
					AND a.servicename = @service_name
				)

		--code commented by saravanan for bug id:PNR2.0_6727
		-- 		If	@task_type	<> 'Init'
		-- 		begin
		-- 			delete	de_fw_des_br_logical_parameter
		-- 			from	de_fw_des_br_logical_parameter		A (nolock),
		-- 					de_fw_des_processsection_br_is		B (nolock),
		-- 					de_hidden_view						D (nolock),
		-- 					de_task_control_map					E (nolock)
		-- 			where	d.customer_name				= e.customer_name
		-- 			and		d.project_name				= e.project_name
		-- 			and		d.process_name				= e.process_name
		-- 			and		d.component_name			= e.component_name
		-- 			and		d.activity_name				= e.activity_name
		-- 			and		d.ui_name					= e.ui_name
		-- 			and		d.page_name					= e.page_name
		-- 			and		d.control_bt_synonym		= e.control_bt_synonym	
		-- 			
		-- 			and		a.customer_name				= b.customer_name
		-- 			and		a.project_name				= b.project_name
		-- 			and		a.process_name				= b.process_name
		-- 			and 	a.component_name			= b.component_name	
		-- 			and		a.methodid					= b.methodid
		-- 			
		-- 			and		a.customer_name				= e.customer_name
		-- 			and		a.project_name				= e.project_name
		-- 			and		a.process_name				= e.process_name
		-- 			and 	a.component_name			= e.component_name
		-- 			and		a.logicalparametername		= e.new_control_bt_synonym
		-- 			and		a.flowdirection				= 0
		-- 			and		d.transfer_flag				= 'Y'
		-- 			
		-- 			and		e.customer_name				= @customer_name
		-- 			and		e.project_name				= @project_name
		-- 			and		e.process_name				= @process_name
		-- 			and		e.component_name			= @component_name
		-- 			and		e.activity_name				= @activity_name
		-- 			and		e.ui_name					= @ui_name
		-- 			and		e.action_name				= @task_name
		-- 			and		b.servicename				= @service_name
		-- 		end
		--code commented by saravanan for bug id:PNR2.0_6727
		-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - START
		-- While generating services, a header control mapped to ml is missing in ML methods.
		-- RECORDING THE LOG DETAILS 
		-- ADDED BY DNR ON 19/03/2004.
		SELECT @method_count = count(methodid)
		FROM de_fw_des_processsection_br_is(NOLOCK)
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND servicename = @service_name

		DELETE
		FROM de_service_gen_log
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND activity_name = @activity_name
			AND ui_name = @ui_name
			AND task_name = @task_name

		INSERT INTO de_service_gen_log (
			customer_name,
			project_name,
			process_name,
			component_name,
			activity_name,
			ui_name,
			task_name,
			service_name,
			generation_date,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate,
			no_of_methods,
			ecrno
			) -- chan
		VALUES (
			@customer_name,
			@project_name,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			@task_name,
			@service_name,
			@getdate,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			@method_count,
			@ico_number
			) -- chan

		-- code added by feroz to populate scartch variable on 06-dec-2004
		SELECT @hdr_segment = current_value
		FROM es_comp_param_mst(NOLOCK)
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND param_category = 'HDRSEGNAME'

		-- code added by shafina on 07-dec-2004 for DEPF204ACC_000022(User defined scratch variable must be included in method as parameter.)
		INSERT INTO de_fw_des_service_dataitem (
			servicename,
			segmentname,
			dataitemname,
			ispartofkey,
			mandatoryflag,
			flowattribute,
			upduser,
			updtime,
			customer_name,
			project_name,
			process_name,
			component_name,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate,
			defaultvalue,
			ecrno
			) -- chan)
		SELECT @service_name,
			@hdr_segment,
			scratch_name,
			0,
			0,
			3,
			@ctxt_user,		--TECH-73216
			@getdate,
			@customer_name,
			@project_name,
			@process_name,
			@component_name,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			CASE upper(b.data_type)
				WHEN 'CHAR'
					THEN '~#~'
				WHEN 'DATE'
					THEN '01/01/1900'
				WHEN 'DATE-TIME'
					THEN '01/01/1900'
				WHEN 'TIME'
					THEN '01/01/1900'
				WHEN 'DATETIME'
					THEN '01/01/1900'
				WHEN 'DOUBLE'
					THEN '-915'
				WHEN 'INTEGER'
					THEN '-915'
				WHEN 'NUMERIC'
					THEN '-915'
				WHEN 'ENUMERATED'
					THEN ''
				ELSE ''
				END 'Def_Value',
			@ico_number -- chan
		FROM de_scratch_variable A(NOLOCK),
			de_glossary B(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND a.activity_name = @activity_name
			AND a.ui_name = @ui_name
			AND a.page_name = @page_name
			AND a.task_name = @task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.scratch_name = b.bt_synonym_name

		--Modified By Feroz For BugID--DEENG203ACC_000020
		--CREATING METHOD PARAMETER AND DATAITEM MAPPING
		-- code modified by Ganesh for the bugid :: PNR2.0_1600 on 25/3/04
		SELECT DISTINCT @customer_name 'customer_name',
			@project_name 'project_name',
			@process_name 'process_name',
			@component_name 'component_name',
			a.servicename,
			a.sectionname,
			a.sequenceno,
			a.methodid,
			e.method_name,
			e.logicalparametername 'parametername',
			d.segmentname,
			d.dataitemname,
			@ctxt_user 'hostname',		--TECH-73216
			@getdate 'getdate'
		INTO #de_fw_des_di_parameter
		FROM de_fw_des_processsection_br_is A(NOLOCK),
			de_fw_des_service B(NOLOCK),
			de_fw_des_service_segment C(NOLOCK),
			de_fw_des_service_dataitem D(NOLOCK),
			de_fw_des_br_logical_parameter E(NOLOCK),
			#method_segment_map G(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND a.servicename = @service_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.componentname
			AND a.servicename = b.servicename
			AND b.customer_name = c.customer_name
			AND b.project_name = c.project_name
			AND b.process_name = c.process_name
			AND b.componentname = c.component_name
			AND b.servicename = c.servicename
			AND d.customer_name = c.customer_name
			AND d.project_name = c.project_name
			AND d.process_name = c.process_name
			AND d.component_name = c.component_name
			AND d.servicename = c.servicename
			AND d.segmentname = c.segmentname
			AND a.customer_name = e.customer_name
			AND a.project_name = e.project_name
			AND a.process_name = e.process_name
			AND a.component_name = e.component_name
			AND a.method_name = e.method_name
			AND a.methodid = e.methodid
			AND d.customer_name = e.customer_name
			AND d.project_name = e.project_name
			AND d.process_name = e.process_name
			AND d.component_name = e.component_name
			AND d.dataitemname = e.logicalparametername
			AND c.segmentname collate database_default = g.segment_name
			AND e.methodid = g.methodid
			AND e.logicalparametername NOT IN (
				'Ctxt_User',
				'Ctxt_Language',
				'Ctxt_OUInstance',
				'Ctxt_Service',
				'Ctxt_Role',
				'Ctxt_Validation', --TECH-69327
				'Ctxt_Componentname'
				) -- Code added For Bug Id : PNR2.0_33317
		ORDER BY 1,
			2,
			3,
			4,
			5,
			6,
			7

		-- Code Added for BugId :  PNR2.0_2825
		DELETE #de_fw_des_di_parameter
		WHERE customer_name = @customer_name
			AND project_name = @project_name
			AND process_name = @process_name
			AND component_name = @component_name
			AND servicename = @service_name
			AND servicename + convert(VARCHAR, methodid) + convert(VARCHAR, sequenceno) + parametername collate database_default IN (
				SELECT servicename + convert(VARCHAR, methodid) + convert(VARCHAR, sequenceno) + parametername
				FROM #de_fw_des_di_parameter A(NOLOCK)
				WHERE customer_name = @customer_name
					AND project_name = @project_name
					AND process_name = @process_name
					AND component_name = @component_name
					AND servicename = @service_name
					AND segmentname = @hdr_sgmt_idfr
				)
			AND servicename + convert(VARCHAR, methodid) + convert(VARCHAR, sequenceno) + parametername collate database_default IN (
				SELECT servicename + convert(VARCHAR, methodid) + convert(VARCHAR, sequenceno) + parametername
				FROM #de_fw_des_di_parameter A(NOLOCK)
				WHERE customer_name = @customer_name
					AND project_name = @project_name
					AND process_name = @process_name
					AND component_name = @component_name
					AND servicename = @service_name
					AND segmentname <> @hdr_sgmt_idfr
				)
			AND segmentname = @hdr_sgmt_idfr

		INSERT INTO de_fw_des_di_parameter (
			Customer_name,
			project_name,
			process_name,
			component_name,
			ServiceName,
			SectionName,
			SequenceNo,
			Methodid,
			method_name,
			ParameterName,
			SegmentName,
			DataitemName,
			UpdUser,
			UpdTime,
			TIMESTAMP,
			Createdby,
			createddate,
			modifiedby,
			modifieddate,
			ecrno
			) -- chan
		SELECT DISTINCT customer_name,
			project_name,
			process_name,
			component_name,
			servicename,
			sectionname,
			sequenceno,
			methodid,
			method_name,
			parametername,
			segmentname,
			dataitemname,
			@ctxt_user,		--TECH-73216
			@getdate,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ico_number -- chan
		FROM #de_fw_des_di_parameter(NOLOCK)

		--CREATING CTXT PARAMETER MAPPINGS
		INSERT INTO de_fw_des_di_parameter (
			Customer_name,
			project_name,
			process_name,
			component_name,
			ServiceName,
			SectionName,
			SequenceNo,
			Methodid,
			Method_name,
			ParameterName,
			SegmentName,
			DataitemName,
			UpdUser,
			UpdTime,
			TIMESTAMP,
			Createdby,
			createddate,
			modifiedby,
			modifieddate,
			ecrno
			) -- chan
		SELECT DISTINCT @customer_name,
			@project_name,
			@process_name,
			@component_name,
			a.servicename,
			a.sectionname,
			a.sequenceno,
			a.methodid,
			e.method_name,
			e.logicalparametername,
			'fw_context',
			CASE e.logicalparametername
				WHEN 'ctxt_user'
					THEN 'User'
				WHEN 'ctxt_Language'
					THEN 'Language'
				WHEN 'ctxt_OUInstance'
					THEN 'OUInstance'
				WHEN 'ctxt_Service'
					THEN 'Service'
				WHEN 'ctxt_Role'
					THEN 'Role'
				WHEN 'ctxt_Validation'
					THEN 'Validation' -- Added for TECH-20897
				WHEN 'ctxt_Componentname'
					THEN 'Componentname'
				END, -- Code added For Bug Id : PNR2.0_33317
			@ctxt_user,		--TECH-73216
			@getdate,
			1,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ctxt_user,		--TECH-73216
			@getdate,
			@ico_number -- chan
		FROM de_fw_des_processsection_br_is A(NOLOCK),
			de_fw_des_service B(NOLOCK),
			de_fw_des_br_logical_parameter E(NOLOCK)
		WHERE a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name
			AND a.component_name = @component_name
			AND b.servicename = @service_name
			AND a.servicename = b.servicename
			AND b.customer_name = a.customer_name
			AND b.project_name = a.project_name
			AND b.process_name = a.process_name
			AND b.componentname = a.component_name
			AND e.customer_name = a.customer_name
			AND e.project_name = a.project_name
			AND e.process_name = a.process_name
			AND e.component_name = a.component_name
			AND e.methodid = a.methodid
			AND e.logicalparametername IN (
				'Ctxt_User',
				'Ctxt_Language',
				'Ctxt_OUInstance',
				'Ctxt_Service',
				'Ctxt_Role',
				'ctxt_Validation', -- Added for Validation
				'Ctxt_Componentname'
				) -- Code added For Bug Id : PNR2.0_33317
		ORDER BY 1,
			2,
			3,
			4,
			5,
			6,
			7

		--SP TO GENERATE METHOD DOCUMENTATION
		EXEC de_generate_method_documentation @Ctxt_Language,
			@Ctxt_Service,
			@Ctxt_OUInstance,
			@Ctxt_User,
			@customer_name,
			@project_name,
			@ico_number,
			@process_name,
			@component_name,
			@activity_name,
			@ui_name,
			@page_name,
			@task_name,
			@task_type,
			@service_name,
			@component_prfx
			-----------------------------
			--END OF SERVICE GENERATION--
			-----------------------------
	END --END OF TASK_TYPE <> 'ZOOM'

	-- Code Added By Ganesh on 01/30/04 for the Bugid :: DEENG203SYS_000367
	UPDATE a
	SET flowattribute = 0
	FROM de_fw_des_service_dataitem A(NOLOCK),
		de_task_service_map B(NOLOCK),
		de_action C(NOLOCK),
		es_comp_param_mst_vw D(NOLOCK)
	WHERE a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.servicename = b.service_name
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND b.task_name = c.task_name
		AND c.primary_control_bts = a.dataitemname
		AND c.task_type = 'UI'
		AND c.customer_name = d.customer_name
		AND c.project_name = d.project_name
		AND c.process_name = d.process_name
		AND c.component_name = d.component_name
		AND d.param_type = 'NAMECON'
		AND d.param_category = 'HDRSEGNAME'
		AND a.segmentname = d.current_value
		AND a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name
		AND a.component_name = @component_name
		AND a.servicename = @service_name
		AND c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.process_name = @process_name
		AND c.component_name = @component_name
		AND c.ui_name = @ui_name
		AND c.page_bt_synonym = @page_name

	UPDATE de_gen_service_method_history
	SET new_service_name = @service_name,
		new_method_id = b.methodid,
		new_method_name = b.methodname
	FROM de_gen_service_method_history A(NOLOCK),
		de_fw_des_businessrule B(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.process_name = @process_name
		AND b.component_name = @component_name
		AND a.task_name = @task_name
		AND a.old_method_name = b.methodname
		AND isnull(a.control_id, '') = ''

	-- code added by Ganesh on 08/10/04 to delete the errors for the method which are removed.
	DELETE a
	FROM #de_fw_des_di_placeholder A(NOLOCK),
		-- code modified by Ganesh on 06/10/2004 for the bugid :::DEENG203SYS_000382
		de_gen_service_method_history b(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') = ''

	DELETE a
	FROM #de_fw_des_be_placeholder A(NOLOCK),
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') = ''

	DELETE #de_fw_des_brerror
	FROM #de_fw_des_brerror A(NOLOCK),
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND a.methodid = b.old_method_id
		AND b.task_name collate database_default = @task_name
		AND isnull(b.new_method_id, '') = ''

	UPDATE #de_fw_des_brerror
	SET methodid = b.new_method_id,
		method_name = b.new_method_name,
		upduser = @ctxt_User,
		updtime = @getdate
	FROM #de_fw_des_brerror A(NOLOCK),
		-- code modified by Ganesh on 06/10/2004 for the bugid :::DEENG203SYS_000382
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND b.task_name collate database_default = @task_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') <> ''

	-- code added by Ganesh on 06/12/04 for the bugid :: DRENG203ACC_000027 
	UPDATE de_fw_des_brerror_unmap
	SET methodid = b.new_method_id,
		method_name = b.new_method_name,
		upduser = @ctxt_User,
		updtime = @getdate
	FROM de_fw_des_brerror_unmap A(NOLOCK),
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND b.task_name collate database_default = @task_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') <> ''

	INSERT de_fw_des_brerror (
		methodid,
		errorid,
		upduser,
		updtime,
		customer_name,
		project_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		sperrorcode,
		process_name,
		component_name,
		error_context,
		ecrno
		) -- chan
	SELECT methodid,
		errorid,
		upduser,
		updtime,
		customer_name,
		project_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		sperrorcode,
		process_name,
		component_name,
		error_context,
		@ico_number -- chan
	FROM #de_fw_des_brerror A(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND NOT EXISTS (
			SELECT 'S'
			FROM de_fw_des_brerror B(NOLOCK)
			WHERE a.customer_name collate database_default = b.customer_name
				AND a.customer_name collate database_default = b.customer_name
				AND a.methodid = b.methodid
				AND a.errorid = b.errorid
				AND a.method_name collate database_default = b.method_name
			)

	-- end here
	-- Added by Ganesh to avoid the deletion of the record in de_fw_des_be_placeholder where the records are made in DR
	-- for the bugid :: DEENG203SYS_000236 on 2/8/04
	-- starts here
	UPDATE #de_fw_des_be_placeholder
	SET methodid = b.new_method_id,
		method_name = b.new_method_name,
		upduser = @ctxt_user,
		updtime = @getdate
	FROM #de_fw_des_be_placeholder A(NOLOCK),
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') <> ''

	INSERT de_fw_des_be_placeholder (
		methodid,
		placeholdername,
		parametername,
		errorid,
		upduser,
		updtime,
		customer_name,
		project_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		process_name,
		component_name,
		ecrno
		) -- chan
	SELECT a.methodid,
		a.placeholdername,
		a.parametername,
		a.errorid,
		a.upduser,
		a.updtime,
		a.customer_name,
		a.project_name,
		a.method_name,
		a.TIMESTAMP,
		a.createdby,
		a.createddate,
		a.modifiedby,
		a.modifieddate,
		a.process_name,
		a.component_name,
		@ico_number -- chan
	FROM #de_fw_des_be_placeholder A(NOLOCK),
		de_fw_des_br_logical_parameter C(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.customer_name collate database_default = c.customer_name
		AND a.project_name collate database_default = c.project_name
		AND a.process_name collate database_default = c.process_name
		AND a.component_name collate database_default = c.component_name
		AND a.methodid = c.methodid
		AND a.parametername collate database_default = c.logicalparametername
		AND a.method_name collate database_default = c.method_name
		AND NOT EXISTS (
			SELECT 'S'
			FROM de_fw_des_be_placeholder B(NOLOCK)
			WHERE a.customer_name collate database_default = b.customer_name
				AND a.customer_name collate database_default = b.customer_name
				AND a.process_name collate database_default = b.process_name
				AND a.component_name collate database_default = b.component_name
				AND a.methodid = b.methodid
				AND a.errorid = b.errorid
				AND a.placeholdername collate database_default = b.placeholdername
				AND a.method_name collate database_default = b.method_name
			)

	-- end here
	-- Added by Ganesh to avoid the deletion of the record in de_fw_des_be_placeholder where the records are made in DR
	-- for the bugid :: DEENG203SYS_000236 on 3/8/04
	-- starts here
	UPDATE #de_fw_des_di_placeholder
	SET methodid = b.new_method_id,
		method_name = b.new_method_name,
		servicename = b.new_service_name,
		upduser = @ctxt_user,
		updtime = @getdate
	FROM #de_fw_des_di_placeholder A(NOLOCK),
		-- code modified by Ganesh on 06/10/2004 for the bugid :::DEENG203SYS_000382
		de_gen_service_method_history B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.method_name collate database_default = b.old_method_name
		AND a.methodid = b.old_method_id
		AND isnull(b.new_method_id, '') <> ''

	--code Added For BugId : PNR2.0_5313
	UPDATE #de_fw_des_di_placeholder
	SET sectionname = b.sectionname,
		upduser = @ctxt_user,
		updtime = @getdate
	FROM #de_fw_des_di_placeholder A(NOLOCK),
		de_fw_des_processsection_br_is B(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.customer_name collate database_default = b.customer_name
		AND a.project_name collate database_default = b.project_name
		AND a.process_name collate database_default = b.process_name
		AND a.component_name collate database_default = b.component_name
		AND a.servicename collate database_default = b.servicename
		AND a.methodid = b.methodid

	INSERT de_fw_des_di_placeholder (
		servicename,
		sectionname,
		sequenceno,
		methodid,
		placeholdername,
		errorid,
		segmentname,
		dataitemname,
		customer_name,
		project_name,
		process_name,
		component_name,
		method_name,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		upduser,
		updtime,
		ecrno
		) -- chan 
	SELECT a.servicename,
		a.sectionname,
		a.sequenceno,
		a.methodid,
		a.placeholdername,
		a.errorid,
		a.segmentname,
		a.dataitemname,
		a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.method_name,
		a.TIMESTAMP,
		a.createdby,
		a.createddate,
		a.modifiedby,
		a.modifieddate,
		a.upduser,
		a.updtime,
		@ico_number -- chan
	FROM #de_fw_des_di_placeholder A(NOLOCK),
		de_fw_des_service_dataitem C(NOLOCK)
	WHERE a.customer_name collate database_default = @customer_name
		AND a.project_name collate database_default = @project_name
		AND a.process_name collate database_default = @process_name
		AND a.component_name collate database_default = @component_name
		AND a.customer_name collate database_default = c.customer_name
		AND a.project_name collate database_default = c.project_name
		AND a.process_name collate database_default = c.process_name
		AND a.component_name collate database_default = c.component_name
		AND a.servicename collate database_default = c.servicename
		AND a.segmentname collate database_default = c.segmentname
		AND a.dataitemname collate database_default = c.dataitemname
		AND NOT EXISTS (
			SELECT 'S'
			FROM de_fw_des_di_placeholder B(NOLOCK)
			WHERE a.servicename collate database_default = b.servicename
				AND a.sectionname collate database_default = b.sectionname
				AND a.sequenceno = b.sequenceno
				AND a.methodid = b.methodid
				AND a.placeholdername collate database_default = b.placeholdername
				AND a.errorid = b.errorid
				AND a.segmentname collate database_default = b.segmentname
				AND a.dataitemname collate database_default = b.dataitemname
				AND a.method_name collate database_default = b.method_name
			)

	-- to delete the errors which are unmapped in DR
	DELETE
	FROM de_fw_des_brerror
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND cast(methodid AS VARCHAR(10)) + cast(errorid AS VARCHAR(10)) + method_name IN (
			SELECT cast(methodid AS VARCHAR(10)) + cast(errorid AS VARCHAR(10)) + method_name
			FROM de_fw_des_brerror_unmap(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
			)

	-- to delete the unmapped errors which are removed in requirement level 
	DELETE
	FROM de_fw_des_brerror_unmap
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND process_name = @process_name
		AND component_name = @component_name
		AND cast(methodid AS VARCHAR(10)) + cast(errorid AS VARCHAR(10)) + method_name NOT IN (
			SELECT cast(methodid AS VARCHAR(10)) + cast(errorid AS VARCHAR(10)) + method_name
			FROM de_fw_des_brerror(NOLOCK)
			WHERE customer_name = @customer_name
				AND project_name = @project_name
				AND process_name = @process_name
				AND component_name = @component_name
			)

	-- to maintain the sp errorcode which is changed in DR
	-- Code Added for BugId :  PNR2.0_2825
	UPDATE a
	SET a.sperrorcode = b.sperrorcode,
		a.error_context = b.error_context
	FROM de_fw_des_brerror A(NOLOCK),
		#de_fw_des_brerror B(NOLOCK),
		de_Fw_des_processsection_br_is C(NOLOCK)
	WHERE a.customer_name collate Database_default = b.customer_name
		AND a.project_name collate Database_default = b.project_name
		AND a.process_name collate Database_default = b.process_name
		AND a.component_name collate Database_default = b.component_name
		AND a.methodid = b.methodid
		AND a.errorid = b.errorid
		AND a.method_name collate Database_default = b.method_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.methodid = c.methodid
		AND a.method_name = c.method_name
		AND c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.process_name = @process_name
		AND c.component_name = @component_name
		AND c.servicename = @service_name

	-- end here
	---code added by vinoth on 23/07/2004  for the bug-id DEENG203ACC_000091    to update Remarks Column 
	UPDATE de
	SET remarks = d.task_descr + ' Generated sucessfully'
	FROM de_action d,
		de_fw_des_service de,
		de_task_service_map d1
	WHERE d.customer_name = d1.customer_name
		AND d.project_name = d1.project_name
		AND d.process_name = d1.process_name
		AND d.component_name = d1.component_name
		AND d.activity_name = d1.activity_name
		AND d.ui_name = d1.ui_name
		AND d.task_name = d1.task_name
		AND de.customer_name = d1.customer_name
		AND de.project_name = d1.project_name
		AND de.process_name = d1.process_name
		AND de.componentname = d1.component_name
		AND de.servicename = d1.service_name
		AND d.customer_name = @customer_name
		AND d.project_name = @project_name
		AND d.process_name = @process_name
		AND d.component_name = @component_name
		AND d.activity_name = @activity_name
		AND d.ui_name = @ui_name
		AND d.task_name = @task_name
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'de_generate_service' AND TYPE='P')
BEGIN
	GRANT EXEC ON  de_generate_service TO PUBLIC
END
GO 
