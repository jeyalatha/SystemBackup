IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_gengen_o' AND TYPE = 'P')
BEGIN
  DROP PROC de_design_sp_gengen_o
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_design_sp_gengen_o.sql
********************************************************************************/
/*      V E R S I O N      :  2 . 0 . 4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 12 - Jan -05 (Patch Release 1)    */
/********************************************************************************/
/* procedure    : de_design_sp_gengen_o                                         */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vasu k                                                        */
/* date         : 11/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* Modified by  :          Balaji D                                             */
/* Date         :          Feb 06 2011                                          */
/* Bug Id  :          PLF2.0_00214           */
/* Description  :          Zipped service release                               */
/********************************************************************************/
/* Modified by  :   Ponmalar A		Date: 01-Dec-2022	Defect ID : TECH-75230				*/
/* Description  :	Provision to retain the existing refinements during service generation. */
/********************************************************************************************/
CREATE PROCEDURE de_design_sp_gengen_o
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_act_descr engg_description,
	@engg_act_pending engg_seqno,
	@engg_act_total engg_seqno,
	@engg_all_pages engg_flag,
	@engg_all_tasks engg_flag,
	@engg_component engg_description,
	@engg_customer_name engg_name,
	@engg_ico_no engg_name,
	@engg_met_service engg_name,
	@engg_met_task engg_description,
	@engg_met_taskdescr engg_description,
	@engg_page_descr engg_description,
	@engg_page_pending engg_seqno,
	@engg_page_total engg_seqno,
	@engg_par_service engg_name,
	@engg_par_task engg_description,
	@engg_par_taskdescr engg_description,
	@engg_proj_proc_descr engg_description,
	@engg_project_name engg_name,
	@engg_ps_service engg_name,
	@engg_ps_task engg_description,
	@engg_ps_taskdescr engg_description,
	@engg_sdi_service engg_name,
	@engg_sdi_task engg_description,
	@engg_sdi_taskdescr engg_description,
	@engg_seg_service engg_name,
	@engg_seg_task engg_description,
	@engg_seg_taskdescr engg_description,
	@engg_ui_descr engg_description,
	@engg_ui_pending engg_seqno,
	@engg_ui_total engg_seqno,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language

	SELECT @ctxt_ouinstance = @ctxt_ouinstance

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr))

	SELECT @engg_act_pending = @engg_act_pending

	SELECT @engg_act_total = @engg_act_total

	SELECT @engg_all_pages = ltrim(rtrim(@engg_all_pages))

	SELECT @engg_all_tasks = ltrim(rtrim(@engg_all_tasks))

	SELECT @engg_component = ltrim(rtrim(@engg_component))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name))

	SELECT @engg_ico_no = ltrim(rtrim(@engg_ico_no))

	SELECT @engg_met_service = ltrim(rtrim(@engg_met_service))

	SELECT @engg_met_task = ltrim(rtrim(@engg_met_task))

	SELECT @engg_met_taskdescr = ltrim(rtrim(@engg_met_taskdescr))

	SELECT @engg_page_descr = ltrim(rtrim(@engg_page_descr))

	SELECT @engg_page_pending = @engg_page_pending

	SELECT @engg_page_total = @engg_page_total

	SELECT @engg_par_service = ltrim(rtrim(@engg_par_service))

	SELECT @engg_par_task = ltrim(rtrim(@engg_par_task))

	SELECT @engg_par_taskdescr = ltrim(rtrim(@engg_par_taskdescr))

	SELECT @engg_proj_proc_descr = ltrim(rtrim(@engg_proj_proc_descr))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name))

	SELECT @engg_ps_service = ltrim(rtrim(@engg_ps_service))

	SELECT @engg_ps_task = ltrim(rtrim(@engg_ps_task))

	SELECT @engg_ps_taskdescr = ltrim(rtrim(@engg_ps_taskdescr))

	SELECT @engg_sdi_service = ltrim(rtrim(@engg_sdi_service))

	SELECT @engg_sdi_task = ltrim(rtrim(@engg_sdi_task))

	SELECT @engg_sdi_taskdescr = ltrim(rtrim(@engg_sdi_taskdescr))

	SELECT @engg_seg_service = ltrim(rtrim(@engg_seg_service))

	SELECT @engg_seg_task = ltrim(rtrim(@engg_seg_task))

	SELECT @engg_seg_taskdescr = ltrim(rtrim(@engg_seg_taskdescr))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	SELECT @engg_ui_pending = @engg_ui_pending

	SELECT @engg_ui_total = @engg_ui_total

	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_act_pending = - 915
		SELECT @engg_act_pending = NULL

	IF @engg_act_total = - 915
		SELECT @engg_act_total = NULL

	IF @engg_all_pages = '~#~'
		SELECT @engg_all_pages = NULL

	IF @engg_all_tasks = '~#~'
		SELECT @engg_all_tasks = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SELECT @engg_ico_no = NULL

	IF @engg_met_service = '~#~'
		SELECT @engg_met_service = NULL

	IF @engg_met_task = '~#~'
		SELECT @engg_met_task = NULL

	IF @engg_met_taskdescr = '~#~'
		SELECT @engg_met_taskdescr = NULL

	IF @engg_page_descr = '~#~'
		SELECT @engg_page_descr = NULL

	IF @engg_page_pending = - 915
		SELECT @engg_page_pending = NULL

	IF @engg_page_total = - 915
		SELECT @engg_page_total = NULL

	IF @engg_par_service = '~#~'
		SELECT @engg_par_service = NULL

	IF @engg_par_task = '~#~'
		SELECT @engg_par_task = NULL

	IF @engg_par_taskdescr = '~#~'
		SELECT @engg_par_taskdescr = NULL

	IF @engg_proj_proc_descr = '~#~'
		SELECT @engg_proj_proc_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_ps_service = '~#~'
		SELECT @engg_ps_service = NULL

	IF @engg_ps_task = '~#~'
		SELECT @engg_ps_task = NULL

	IF @engg_ps_taskdescr = '~#~'
		SELECT @engg_ps_taskdescr = NULL

	IF @engg_sdi_service = '~#~'
		SELECT @engg_sdi_service = NULL

	IF @engg_sdi_task = '~#~'
		SELECT @engg_sdi_task = NULL

	IF @engg_sdi_taskdescr = '~#~'
		SELECT @engg_sdi_taskdescr = NULL

	IF @engg_seg_service = '~#~'
		SELECT @engg_seg_service = NULL

	IF @engg_seg_task = '~#~'
		SELECT @engg_seg_task = NULL

	IF @engg_seg_taskdescr = '~#~'
		SELECT @engg_seg_taskdescr = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @engg_ui_pending = - 915
		SELECT @engg_ui_pending = NULL

	IF @engg_ui_total = - 915
		SELECT @engg_ui_total = NULL

	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	/*declare @page_bt_synonym_tmp  engg_name
select @page_bt_synonym_tmp = min(page_bt_synonym)
from ep_published_ui_page_dtl_vw nolock
where  customer_name = @engg_customer_name
and  project_name = @engg_project_name
--and  req_no   = @engg_ico_no
and  process_name = @process_name_tmp
and  component_name = @component_name_tmp
and  activity_name = @activity_name_tmp
and  ui_name   = @ui_name_tmp
*/
	/*select section_bt_synonym 'engg_par_ps'
from ep_published_ui_section_dtl_vw nolock
where  customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  req_no   = @engg_ico_no
and  process_name = @process_name_tmp
and  component_name = @component_name_tmp
and  activity_name = @activity_name_tmp
and  ui_name   = @ui_name_tmp
and  page_bt_synonym = @page_bt_synonym_tmp
*/
	/*select  b.generation_date   'engg_gen_last_gen',
b.no_of_methods     'engg_gen_met_count',
b.service_name      'engg_gen_ser_name',
a.task_descr      'engg_gen_task_descr',
a.task_name      'engg_gen_task_name',
a.task_pattern      'engg_gen_task_pattern'
from  ep_published_action_mst_vw a ,
de_service_gen_log b
where  a.customer_name  = @engg_customer_name
and  a.project_name  = @engg_project_name
and  a.process_name  = @process_name_tmp
and  a.component_name = @component_name_tmp
and  a.activity_name  = @activity_name_tmp
and  a.ui_name   = @ui_name_tmp
and  a.page_bt_synonym  = @engg_page_descr

and  a.customer_name  *= b.customer_name
and  a.project_name  *= b.project_name
and  a.process_name  *= b.process_name
and  a.component_name *= b.component_name
and  a.activity_name  *= b.activity_name
and  a.ui_name   *= b.ui_name
and  a.task_name   *= b.task_name
order by a.task_seq
*/
	--CODE MODIFIED BY DNR FOR BUG ID DEENG203SYS_000047
	--CODE MODIFIED BY DNR ON 19-JUNE-2004 FOR THE BUG ID DEENG203ACC_000073
	--SOME TASKS ARE NOT GETTTING DISPLAYED IN THE ML
	
	--Code commented for TECH-75230 starts
	--SELECT CONVERT(VARCHAR(20), ISNULL(b.createddate, GETDATE())) 'engg_gen_last_gen',
	--	(
	--		SELECT count(methodid)
	--		FROM de_fw_des_processsection_br_is c(NOLOCK)
	--		WHERE c.customer_name = @engg_customer_name
	--			AND c.project_name = @engg_project_name
	--			AND c.process_name = @process_name_tmp
	--			AND c.component_name = @component_name_tmp
	--			AND c.servicename = b.servicename
	--		) 'engg_gen_met_count',
	--	b.servicename 'engg_gen_ser_name',
	--	a.task_descr 'engg_gen_task_descr',
	--	a.task_name 'engg_gen_task_name',
	--	a.task_pattern 'engg_gen_task_pattern',
	--	b.remarks 'engg_gen_remarks',
	--	-- code modified by shafina on 11-Jan-2005 for DEENG203ACC_000135(New tab for ActionReuse is added.)
	--	b.isintegser 'engg_gen_is',
	--	--Code Added for the Bug ID: PLF2.0_00214 starts
	--	b.isCached 'engg_gen_iscached',
	--	b.isZipped 'engg_gen_iszipped',
	--	b.ClearKey_Pattern 'engg_gen_clearkey_pattern',
	--	b.SetKey_Pattern 'engg_gen_setkey_pattern',
	--	--Code Added for the Bug ID: PLF2.0_00214 ends
	--	task_seq
	--FROM de_action a(NOLOCK),
	--	de_fw_des_service b(NOLOCK),
	--	de_task_service_map c(NOLOCK)
	--WHERE a.customer_name = @engg_customer_name
	--	AND a.project_name = @engg_project_name
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp
	--	AND a.activity_name = @activity_name_tmp
	--	AND a.ui_name = @ui_name_tmp
	--	AND a.page_bt_synonym = @engg_page_descr
	--	AND c.service_name = b.servicename
	--	AND a.customer_name = b.customer_name
	--	AND a.project_name = b.project_name
	--	AND a.process_name = b.process_name
	--	AND a.component_name = b.componentname
	--	AND a.customer_name = c.customer_name
	--	AND a.project_name = c.project_name
	--	AND a.process_name = c.process_name
	--	AND a.component_name = c.component_name
	--	AND a.activity_name = c.activity_name
	--	AND a.ui_name = c.ui_name
	--	AND a.task_name = c.task_name
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_action_reuse_info(NOLOCK)
	--		WHERE a.customer_name = @engg_customer_name
	--			AND a.project_name = @engg_project_name
	--			AND a.process_name = @process_name_tmp
	--			AND a.component_name = @component_name_tmp
	--			AND a.activity_name = @activity_name_tmp
	--			AND a.ui_name = @ui_name_tmp
	--			AND a.page_bt_synonym = @engg_page_descr
	--		)
	
	--UNION
	
	--SELECT '' 'engg_gen_last_gen',
	--	'' 'engg_gen_met_count',
	--	'' 'engg_gen_ser_name',
	--	a.task_descr 'engg_gen_task_descr',
	--	a.task_name 'engg_gen_task_name',
	--	a.task_pattern 'engg_gen_task_pattern',
	--	'' 'engg_gen_remarks',
	--	0 'engg_gen_is',
	--	--Code Added for the Bug ID: PLF2.0_00214 starts
	--	0 'engg_gen_iscached',
	--	0 'engg_gen_iszipped',
	--	'' 'engg_gen_clearkey_pattern',
	--	'' 'engg_gen_setkey_pattern',
	--	--Code Added for the Bug ID: PLF2.0_00214 ends
	--	task_seq
	--FROM de_action a(NOLOCK)
	--WHERE a.customer_name = @engg_customer_name
	--	AND a.project_name = @engg_project_name
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp
	--	AND a.activity_name = @activity_name_tmp
	--	AND a.ui_name = @ui_name_tmp
	--	AND a.page_bt_synonym = @engg_page_descr
	--	AND a.task_name NOT IN (
	--		SELECT A.task_name
	--		FROM de_task_service_map A(NOLOCK),
	--			de_fw_des_service B(NOLOCK)
	--		WHERE A.customer_name = @engg_customer_name
	--			AND A.project_name = @engg_project_name
	--			AND A.process_name = @process_name_tmp
	--			AND A.component_name = @component_name_tmp
	--			AND A.activity_name = @activity_name_tmp
	--			AND A.ui_name = @ui_name_tmp
	--			AND A.customer_name = B.customer_name
	--			AND A.project_name = B.project_name
	--			AND A.process_name = B.process_name
	--			AND A.component_name = B.componentname
	--			AND A.service_name = B.servicename
	--		)
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_taskreuse_info(NOLOCK)
	--		WHERE customer_name = @engg_customer_name
	--			AND project_name = @engg_project_name
	--			AND process_name = @process_name_tmp
	--			AND component_name = @component_name_tmp
	--			AND activity_name = @activity_name_tmp
	--			AND ui_name = @ui_name_tmp
	--			AND page_bt_synonym = @engg_page_descr
	--		)
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_action_reuse_info(NOLOCK)
	--		WHERE a.customer_name = @engg_customer_name
	--			AND a.project_name = @engg_project_name
	--			AND a.process_name = @process_name_tmp
	--			AND a.component_name = @component_name_tmp
	--			AND a.activity_name = @activity_name_tmp
	--			AND a.ui_name = @ui_name_tmp
	--			AND a.page_bt_synonym = @engg_page_descr
	--		)
	--ORDER BY a.task_seq
	--Code commented for TECH-75230 ends

	--Code added for TECH-75230 starts
	IF OBJECT_ID('tempdb..#genserdet') IS NOT NULL DROP TABLE #genserdet
	SELECT b.customer_name,
		   b.project_name,
		   b.process_name,
		   b.componentname,
		convert(VARCHAR(20), isnull(b.createddate, getdate())) 'engg_gen_last_gen',
		b.servicename 'engg_gen_ser_name',
		a.task_descr 'engg_gen_task_descr',
		a.task_name 'engg_gen_task_name',
		a.task_pattern 'engg_gen_task_pattern',
		b.remarks 'engg_gen_remarks',
		-- code modified by shafina on 11-Jan-2005 for DEENG203ACC_000135(New tab for ActionReuse is added.)
		b.isintegser 'engg_gen_is',
		--Code Added for the Bug ID: PLF2.0_00214 starts
		b.isCached 'engg_gen_iscached',
		b.isZipped 'engg_gen_iszipped',
		b.ClearKey_Pattern 'engg_gen_clearkey_pattern',
		b.SetKey_Pattern 'engg_gen_setkey_pattern',
		--Code Added for the Bug ID: PLF2.0_00214 ends
		task_seq,
		b.ApplyRefinements 'engg_gen_applyrefine', 
		convert(varchar(60),'')	'mode'
	INTO #genserdet
	FROM de_action a(NOLOCK),
		de_fw_des_service b(NOLOCK),
		de_task_service_map c(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.activity_name = @activity_name_tmp
		AND a.ui_name = @ui_name_tmp
		AND a.page_bt_synonym = @engg_page_descr
		AND c.service_name = b.servicename
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.componentname
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.task_name = c.task_name
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_action_reuse_info(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_page_descr
			)
	
	UNION
	
	SELECT a.customer_name,
		   a.project_name,
		   a.process_name,
		   a.component_name,
		'' 'engg_gen_last_gen',
		'' 'engg_gen_ser_name',
		a.task_descr 'engg_gen_task_descr',
		a.task_name 'engg_gen_task_name',
		a.task_pattern 'engg_gen_task_pattern',
		'' 'engg_gen_remarks',
		0 'engg_gen_is',
		--Code Added for the Bug ID: PLF2.0_00214 starts
		0 'engg_gen_iscached',
		0 'engg_gen_iszipped',
		'' 'engg_gen_clearkey_pattern',
		'' 'engg_gen_setkey_pattern',
		--Code Added for the Bug ID: PLF2.0_00214 ends
		task_seq,
		0 'engg_gen_applyrefine',
		convert(varchar(60),'')	'mode'	
	FROM de_action a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.activity_name = @activity_name_tmp
		AND a.ui_name = @ui_name_tmp
		AND a.page_bt_synonym = @engg_page_descr
		AND a.task_name NOT IN (
			SELECT A.task_name
			FROM de_task_service_map A(NOLOCK),
				de_fw_des_service B(NOLOCK)
			WHERE A.customer_name = @engg_customer_name
				AND A.project_name = @engg_project_name
				AND A.process_name = @process_name_tmp
				AND A.component_name = @component_name_tmp
				AND A.activity_name = @activity_name_tmp
				AND A.ui_name = @ui_name_tmp
				AND A.customer_name = B.customer_name
				AND A.project_name = B.project_name
				AND A.process_name = B.process_name
				AND A.component_name = B.componentname
				AND A.service_name = B.servicename
			)
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_taskreuse_info(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_page_descr
			)
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_action_reuse_info(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_page_descr
			)
	ORDER BY a.task_seq
	
				--Manual services populated in temp table
	IF OBJECT_ID('tempdb..#manualservice') IS NOT NULL DROP TABLE #manualservice
	SELECT  a.customer_name,	a.project_name	,a.process_name	,a.componentname,	engg_gen_ser_name
	INTO	#manualservice
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_fw_des_service b  (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.componentname
	AND		a.engg_gen_ser_name	=	b.servicename		
	LEFT JOIN	de_service_gen_log c (NOLOCK)
	ON		b.customer_name		=	c.customer_name
	AND		b.project_name		=	c.project_name
	AND		b.process_name		=	c.process_name
	AND		b.componentname		=	c.component_name
	AND		b.servicename		=	c.service_name
	WHERE	ISNULL(c.service_name,'') = ''
	AND		ISNULL(engg_gen_task_pattern,'')	<> 'Disposal'
	
			--Manual service -mode updation
	UPDATE #genserdet
	SET		mode = 'Manual'
	FROM	#manualservice	a (NOLOCK)
	JOIN	#genserdet b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.componentname
	AND		a.engg_gen_ser_name	=	b.engg_gen_ser_name
	
			--Manually modified services -mode updation
	UPDATE #genserdet
	SET	mode = 'Manual'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_service_gen_log b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	WHERE	ISNULL(Manually_modified,'N')	=	'Y'
			--Updating refined for the service which is having seq '0' in de_refine_parameter and that 0 params are not available in de_fw_des_br_logical_parameter
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_parameter b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_br_logical_parameter c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.method_name		=	c.method_name
	AND b.parameter_name	=	c.logicalparametername
	WHERE	ISNULL(mode,'')	=	''
	AND		b.sequence_no	=	0
	AND		ISNULL(c.logicalparametername,'') = ''

			--Updating refined for the service which is having seq '0' in de_refine_methods and that 0 methods are not availble in de_fw_des_processsection_br_is
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_methods b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_processsection_br_is c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.method_name		=	c.method_name
	AND b.service_name		=	c.ServiceName
	WHERE	ISNULL(mode,'')	=	''
	AND		b.include_flag	=	0
	AND		ISNULL(c.method_name,'') = ''

			--Updating refined for the service which is having seq '0' in de_refine_process_section and that 0 ProcSec are not available in de_fw_des_processsection_br_is
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_process_section b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_processsection_br_is c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.service_name		=	c.ServiceName
	AND b.ps_name			=	c.SectionName
	WHERE	ISNULL(mode,'')	=	''
	AND		b.sequence_no	=	0
	AND		ISNULL(c.sectionname,'') = ''

			--Generate services -mode updation - for Manually_modified null and N
	UPDATE #genserdet
	SET	mode = 'Generated'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_service_gen_log b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	WHERE	ISNULL(Manually_modified,'N')	=	'N'
	AND		ISNULL(mode,'')	=	''

				--Out from Temp table
	SELECT engg_gen_last_gen 'engg_gen_last_gen',
			CASE WHEN mode <> 'Manual' THEN (
			SELECT count(distinct method_name)
			FROM de_refine_methods c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.service_name = b.engg_gen_ser_name
			)
			ELSE (
			SELECT count(methodid)
			FROM de_fw_des_processsection_br_is c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.servicename = b.engg_gen_ser_name
			) END 'engg_gen_met_count',
		engg_gen_ser_name 'engg_gen_ser_name',
		engg_gen_task_descr 'engg_gen_task_descr',
		engg_gen_task_name 'engg_gen_task_name',
		engg_gen_task_pattern 'engg_gen_task_pattern',
		engg_gen_remarks 'engg_gen_remarks',
		engg_gen_is 'engg_gen_is',
		engg_gen_iscached 'engg_gen_iscached',
		engg_gen_iszipped 'engg_gen_iszipped',
		engg_gen_clearkey_pattern 'engg_gen_clearkey_pattern',
		engg_gen_setkey_pattern 'engg_gen_setkey_pattern',
		task_seq,
		mode		'engg_gen_mode',	
		engg_gen_applyrefine 'engg_gen_applyrefine', 
		CASE WHEN mode= 'Refined' THEN (
			SELECT count(methodid)
			FROM de_fw_des_processsection_br_is c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.servicename = b.engg_gen_ser_name
			) ELSE '' END  'engg_gen_refine_met_count' 
		FROM #genserdet b
		WHERE	 b.customer_name	= @engg_customer_name
		AND      b.project_name		= @engg_project_name
		AND      b.process_name		= @process_name_tmp
		AND      b.componentname	= @component_name_tmp

	SET NOCOUNT OFF
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_gengen_o' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_design_sp_gengen_o TO PUBLIC
END
GO