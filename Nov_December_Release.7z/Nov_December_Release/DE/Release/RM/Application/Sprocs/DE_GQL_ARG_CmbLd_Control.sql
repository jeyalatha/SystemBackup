IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DE_GQL_ARG_CmbLd_Control' AND TYPE = 'P')
BEGIN
  DROP PROC DE_GQL_ARG_CmbLd_Control
END
GO
/********************************************************************************/
/* Procedure                               : DE_GQL_ARG_CmbLd_Control			*/
/* Description                             :									*/
/********************************************************************************/
/* Referenced                              :                                    */
/* Tables                                  :									*/
/********************************************************************************/
/* Development history                     :                                    */
/********************************************************************************/
/* Author                                  : Priyadharshini U/Jeya Latha K      */
/* Date                                    : 19-JAN-2021                        */
/* rTrack ID                               : TECH-63474                         */
/* Description							   : GQL						        */
/********************************************************************************/
/* Modification History                    :                                    */
/********************************************************************************/
/* Author                                  : Ponmalar A / Jeya Latha K		    */
/* Date                                    : 20-DEC-2021                        */
/* rTrack ID                               : TECH-64865                         */
/* Description							   : GQL Operations						*/
/********************************************************************************/
/* Author                                  : Ponmalar A/Jeya Latha K			*/
/* Date                                    : 11-JAN-2022						*/
/* rTrack ID                               : TECH-65386							*/
/* Description							   : GQL Operations						*/
/********************************************************************************/
/* Modified By	: Ponmalar A / Priyadharshini U									*/
/* Defect ID	: TECH-67697													*/
/* Modified on	: 31Mar2022														*/
/* Description	: GQL Changes.													*/
/********************************************************************************/
/* Modified By	: Ponmalar A													*/
/* Defect ID	: TECH-69326													*/
/* Modified on	: 27May2022														*/
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230	*/
/********************************************************************************/
CREATE  PROCEDURE DE_GQL_ARG_CmbLd_Control
	@ctxt_ouinstance              ctxt_ouinstance,
	@ctxt_user                    ctxt_user,
	@ctxt_language                ctxt_language,
	@ctxt_service                 ctxt_service,
    @CustomerName	              engg_name,
    @ProjectName                  engg_name,
	@Ecrno                        engg_name, 
	@ProcessDesc				  engg_desc,
	@ComponentDesc				  engg_desc,
	@ActivityName				  engg_name,
--	@UIName						  engg_name,	
	@UIDesc						  engg_desc,				
	@m_errorid                    INT OUTPUT

AS
BEGIN	
	SET NOCOUNT ON

	SET @m_errorid = 0


	DECLARE @tmp_Procname	engg_name,
			@tmp_Compname	engg_name,
			@tmp_Actname	engg_name,
	        @tmp_uiname		engg_name,
			@tmp_actdescr	engg_description,
			@tmp_uidescr	engg_description

	IF (@ctxt_service	=	'achgqlsrinit')
		BEGIN
			SELECT TOP 1
					   @tmp_Procname	=	process_name,
					   @tmp_Compname	=	component_name,
					   @tmp_Actname		=	activity_name,
					   @tmp_uiname		=	ui_name,
					   @tmp_actdescr	=	activity_descr,
					   @tmp_uidescr		=	ui_descr
			FROM       de_ui_ico WITH (NOLOCK)
			WHERE     customer_name 	=	RTRIM(@CustomerName)
			AND		  project_name		=	RTRIM(@ProjectName)
			AND       ico_no			=	RTRIM(@ecrno)
			AND		  process_descr		=	RTRIM(@ProcessDesc)
			AND		  component_descr	=	RTRIM(@ComponentDesc)
			ORDER BY activity_descr,ui_descr
		END

	ELSE IF (@ctxt_service	=	'achgqlsruides')
		BEGIN

			SELECT  @tmp_Procname	=	process_name,
					@tmp_Compname	=	component_name
			FROM	de_ui_ico WITH (NOLOCK)
			WHERE     customer_name 	=	RTRIM(@CustomerName)
			AND		  project_name		=	RTRIM(@ProjectName)
			AND       ico_no			=	RTRIM(@ecrno)
			AND		  process_descr		=	RTRIM(@ProcessDesc)
			AND		  component_descr	=	RTRIM(@ComponentDesc)
			ORDER BY activity_descr,ui_descr

			SELECT	@tmp_Actname	=	@ActivityName
					--@tmp_uiname		=	@UIName
			
			SELECT  @tmp_uiname		=	ui_name
			FROM	de_ui_ico WITH (NOLOCK)
			WHERE     customer_name 	=	RTRIM(@CustomerName)
			AND		  project_name		=	RTRIM(@ProjectName)
			AND       ico_no			=	RTRIM(@ecrno)
			AND		  process_name		=	RTRIM(@tmp_Procname)
			AND		  component_name	=	RTRIM(@tmp_Compname)
			AND		  activity_name		=	RTRIM(@ActivityName)
			AND		  ui_descr			=	RTRIM(@UIDesc)
			ORDER BY activity_descr,ui_descr

		END

	SELECT	 DISTINCT
		     RTRIM(control_id +' - '+ view_name + ' (' + control_bt_synonym + ')' )  'engg_gqargml_ctrlviewname',
			 1 'Displayorder'
	FROM	de_ui_control AS deu WITH (NOLOCK)
	INNER JOIN es_comp_ctrl_type_mst_vw AS vew WITH (NOLOCK)
	ON		deu.customer_name		=	vew.customer_name  
	AND		deu.project_name		=	vew.project_name  
	AND		deu.process_name		=	vew.process_name  
	AND		deu.component_name		=	vew.component_name  
	AND		deu.control_type		=	vew.ctrl_type_name  
	WHERE   deu.customer_name 		=	RTRIM(@CustomerName)
	AND		deu.project_name		=	RTRIM(@ProjectName)
	AND		deu.process_name		=	RTRIM(@tmp_Procname)
	AND		deu.component_name		=	RTRIM(@tmp_Compname)
	AND		deu.activity_name		=	RTRIM(@tmp_Actname)
	AND		deu.ui_name				=	RTRIM(@tmp_uiname)
	AND     vew.base_ctrl_type NOT IN (  
   'line',  
   'button',  
   --'link',  --Code commented for TECH-65386
   'grid',  
   'Label' 
   )  
	
	UNION

	SELECT	DISTINCT 
			RTRIM(control_id +' - '+ view_name + ' (' + hidden_view_bt_synonym + ')' ) 'engg_gqargml_ctrlviewname',
			2 'Displayorder'
	FROM	de_hidden_view AS hdn WITH (NOLOCK)
	WHERE   hdn.customer_name 					=	RTRIM(@CustomerName)
	AND		hdn.project_name					=	RTRIM(@ProjectName)
	AND		hdn.process_name					=	RTRIM(@tmp_Procname)
	AND		hdn.component_name					=	RTRIM(@tmp_Compname)
	AND     hdn.activity_name					=	RTRIM(@tmp_Actname)
	AND		hdn.ui_name							=	RTRIM(@tmp_uiname)
	AND		ISNULL(hdn.HIDDEN_VIEW_SOURCE, '')	=	''

	UNION

	SELECT	DISTINCT 
		    RTRIM(control_id +' - '+ view_name + ' (' + column_bt_synonym + ')' )  'engg_gqargml_ctrlviewname',
			3 'Displayorder'
	FROM	de_ui_grid AS grd WITH (NOLOCK)
	WHERE   grd.customer_name 		=	RTRIM(@CustomerName)
	AND		grd.project_name		=	RTRIM(@ProjectName)
	AND		grd.process_name		=	RTRIM(@tmp_Procname)
	AND		grd.component_name		=	RTRIM(@tmp_Compname)
	AND     grd.activity_name		=	RTRIM(@tmp_Actname)
	AND		grd.ui_name				=	RTRIM(@tmp_uiname)

	UNION

	SELECT	DISTINCT 
		    RTRIM(control_id +' - '+ 'modeflag' + ' (' + 'modeflag' + ')' )  'engg_gqargml_ctrlviewname',   ---15dec2021
			3 'Displayorder'
	FROM	de_ui_grid AS grd WITH (NOLOCK)
	WHERE   grd.customer_name 		=	RTRIM(@CustomerName)
	AND		grd.project_name		=	RTRIM(@ProjectName)
	AND		grd.process_name		=	RTRIM(@tmp_Procname)
	AND		grd.component_name		=	RTRIM(@tmp_Compname)
	AND     grd.activity_name		=	RTRIM(@tmp_Actname)
	AND		grd.ui_name				=	RTRIM(@tmp_uiname)

	UNION

	SELECT	DISTINCT 
		    RTRIM(control_id +' - '+ 'rowno' + ' (' + 'rowno' + ')' )  'engg_gqargml_ctrlviewname',			---15dec2021
			3 'Displayorder'
	FROM	de_ui_grid AS grd WITH (NOLOCK)
	WHERE   grd.customer_name 		=	RTRIM(@CustomerName)
	AND		grd.project_name		=	RTRIM(@ProjectName)
	AND		grd.process_name		=	RTRIM(@tmp_Procname)
	AND		grd.component_name		=	RTRIM(@tmp_Compname)
	AND     grd.activity_name		=	RTRIM(@tmp_Actname)
	AND		grd.ui_name				=	RTRIM(@tmp_uiname)

	UNION

	--TECH-69326	
	SELECT CASE WHEN quick_code_value = 'Language' THEN 'Language - Language (Ctxt_Language)'				--TECH-75230
				WHEN quick_code_value = 'OUInstance' THEN 'OUInstance - OUInstance (Ctxt_OUInstance)'
				WHEN quick_code_value = 'Role' THEN 'Role - Role (Ctxt_Role)'
				WHEN quick_code_value = 'Service' THEN 'Service - Service (Ctxt_Service)'
				WHEN quick_code_value = 'User' THEN 'User - User (Ctxt_User)'	END			'engg_gqargml_ctrlviewname',
		   4				'Displayorder'
	FROM de_quick_code_mst (NOLOCK) 
	WHERE quick_code_type = 'FW_CONTEXT'
	AND	  ISNULL(quick_code_value,'') <> 'Component'
	--TECH-69326
	
	UNION

	SELECT	
			''		'engg_gqargml_ctrlviewname'  ,
			''		'Displayorder'
	
	ORDER BY Displayorder 

	SET NOCOUNT OFF
END
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DE_GQL_ARG_CmbLd_Control' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON DE_GQL_ARG_CmbLd_Control TO PUBLIC
END
GO



