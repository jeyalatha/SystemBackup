IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DEactpatSpinitdefpat' AND TYPE = 'P')
    BEGIN
        DROP PROC DEactpatSpinitdefpat
    END
GO
/*********************************************************************************/
/* Procedure					: DEactpatSpinitdefpat							 */
/* Description					: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									 */
/* Date							: Nov 16 2022 11:52AM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Created By					: VimalKumar R									 */
/* Date							: 01/12/2022									 */
/* Description					: 												 */
/*********************************************************************************/

Create Procedure DEactpatSpinitdefpat
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@de_engg_component         	engg_description, --Input 
	@de_engg_customer_name     	engg_name, --Input 
	@de_engg_ecr_no            	engg_name, --Input 
	@de_engg_process_descr     	engg_description, --Input 
	@de_engg_project_name      	engg_name, --Input 
	@de_engg_tasktxt_desc      	engg_description, --Input 
	@de_engg_task_docum        	engg_description, --Input 
	@de_engg_tasttxt_docu      	engg_description, --Input 
	@de_engg_txttask_patt_desc 	engg_description, --Input 
	@de_engg_txttask_patt_name 	engg_name, --Input 
	@hdncustomer               	engg_name, --Input 
	@hdnproject                	engg_name, --Input 
	@prj_hdn_ctrl              	plf_hdn_ctrl_bt, --Input 
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = @ctxt_user
	Set @ctxt_service               = @ctxt_service
	Set @de_engg_component          = @de_engg_component
	Set @de_engg_customer_name      = @de_engg_customer_name
	Set @de_engg_ecr_no             = @de_engg_ecr_no
	Set @de_engg_process_descr      = @de_engg_process_descr
	Set @de_engg_project_name       = @de_engg_project_name
	Set @de_engg_tasktxt_desc       = @de_engg_tasktxt_desc
	Set @de_engg_task_docum         = @de_engg_task_docum
	Set @de_engg_tasttxt_docu       = @de_engg_tasttxt_docu
	Set @de_engg_txttask_patt_desc  = @de_engg_txttask_patt_desc
	Set @de_engg_txttask_patt_name  = @de_engg_txttask_patt_name
	Set @hdncustomer                = @hdncustomer
	Set @hdnproject                 = @hdnproject
	Set @prj_hdn_ctrl               = @prj_hdn_ctrl

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @de_engg_component = '~#~' 
		Select @de_engg_component = null  

	IF @de_engg_customer_name = '~#~' 
		Select @de_engg_customer_name = null  

	IF @de_engg_ecr_no = '~#~' 
		Select @de_engg_ecr_no = null  

	IF @de_engg_process_descr = '~#~' 
		Select @de_engg_process_descr = null  

	IF @de_engg_project_name = '~#~' 
		Select @de_engg_project_name = null  

	IF @de_engg_tasktxt_desc = '~#~' 
		Select @de_engg_tasktxt_desc = null  

	IF @de_engg_task_docum = '~#~' 
		Select @de_engg_task_docum = null  

	IF @de_engg_tasttxt_docu = '~#~' 
		Select @de_engg_tasttxt_docu = null  

	IF @de_engg_txttask_patt_desc = '~#~' 
		Select @de_engg_txttask_patt_desc = null  

	IF @de_engg_txttask_patt_name = '~#~' 
		Select @de_engg_txttask_patt_name = null  

	IF @hdncustomer = '~#~' 
		Select @hdncustomer = null  

	IF @hdnproject = '~#~' 
		Select @hdnproject = null  

	IF @prj_hdn_ctrl = '~#~' 
		Select @prj_hdn_ctrl = null  

	SELECT DISTINCT 
		task_type_name	'de_engg_cmbtaskt_met'  
	FROM	es_task_type_met(NOLOCK)  
   
	UNION  
   
	SELECT 
		'DoNotDefault'	'de_engg_cmbtaskt_met'  
	FROM	es_task_type_met(NOLOCK)  
	ORDER BY 1  

	/* 
	-- OutputList
	Select
		null 'de_engg_cmbtaskt_met', 
	*/

	Set nocount off
End


IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DEactpatSpinitdefpat' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON DEactpatSpinitdefpat TO PUBLIC
END
GO