IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_design_sp_defctltc' AND TYPE = 'P')
BEGIN
	DROP PROC de_design_sp_defctltc                                                                 
END
GO
/********************************************************************************/
/*      V E R S I O N      :  2 . 0 . 4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 12 - Jan -05 (Patch Release 1)    */
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 01-APR-2004    */
/********************************************************************************/
/* procedure    : de_design_sp_defctltc                                         */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vasu k                                                        */
/* date         : 9/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  :       DNR                                                    */
/* date         :       29-June-2004                                           */
/* description  :       DEENG203ACC_000085                                     */
/*system is not allowing to map the controls for Link and Help task.			*/
/* modified by  :       FEROZ                                                   */
/* date         :       26-July-2004                                            */
/* description  :       DEENG203SYS_000315	                                    */
/*																				*/
/********************************************************************************/
/* modified by  :       Anuradha M                                              */
/* date         :       19-Dec-2005                                   	        */
/* description  :       Bug Id : PNR2.0_5061                                    */
/*			Bug Descr : validation to restrict subscription and pubclication for the control type Label */
/********************************************************************************/
/* modified by  :       Anuradha M                                              */
/* date         :       22-Dec-2005                                   	        */
/* description  :       Bug Id : PNR2.0_5111                                  */
/********************************************************************************/
/* modified by  : Balaji S                                                    */
/* date         : 29-JUN-2006                                                    */
/* Bug Id 	: PNR2.0_9131							*/
/* Description  : New Base Control Type Label */
/********************************************************************************/
/* modified by  : Chanheetha N A                                                */
/* date         : 24-Aug-2006                                                   */
/* Bug Id 		: PNR2.0_10007						*/
/********************************************************************************/
/* modified by  : Anuradha M	                                                */
/* date         : 28-Aug-2006                                                   */
/* Bug Id 	: PNR2.0_10065							*/
/********************************************************************************/
/* modified by  : Chanheetha N A                                                */
/* date         : 06-Oct-2006                                                   */
/* Bug Id 	    : PNR2.0_10466						*/
/********************************************************************************/
/* modified by  : Balaji S		                                        */
/* date         : 12-Dec-2006                                                   */
/* Bug Id 	    : PNR2.0_11358						*/
/********************************************************************************/
/* Modified by : Feroz		 						*/
/* Modified on : 08/11/06	 						*/
/* Description : State Processing 						*/
/********************************************************************************/
/* modified by			: Chanheetha N A				*/
/* date					: 17-nov-2007				*/
/* BugId				: PNR2.0_16023 				*/
/********************************************************************************/
/* modified by			: Chanheetha N A				*/
/* date					: 13-Dec-2007				*/
/* BugId				: PNR2.0_16275 				*/
/*********************************************************************************/
/* modified by			: Chanheetha N A				 */
/* date					: 17-Dec-2007				 */
/* BugId				: PNR2.0_16306 				 */
/***********************************************************************************/
/* modified by   : Sangeetha G        						   */
/* date     	 : 02-Sep-2008         						   */
/* BugId    	 : PNR2.0_19109        						   */
/* Modified For  : Violation of PRIMARY KEY constraint 'de_task_control_map_pkey'. */
/*                 Cannot insert duplicate key in object 'dbo.de_task_control_map' */
/***********************************************************************************/
/* Modified by			: Feroz											*/
/* Date					: 09-Jan-2008									*/
/* BugId				: PNR2.0_20589 									*/
/************************************************************************/
/* modified by  : Feroz				                                            */
/* date         : 04-Aug-2009                                                   */
/* Bug Id 		: PNR2.0_2179													*/
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By					: Feroz										 */
/* Date							: 26-Aug-2009								 */
/* Description					: PNR2.0_23463 								 */
/******************************************************************************/
/* modified by	: Sangeetha G												  */  
/* date			: 11-Apr-2011												  */  
/* BugId		: PNR2.0_30869												  */  
/* modified for	: Feature Release											  */  
/******************************************************************************/  
/* modified by	: Balaji D													  */  
/* date			: June 21 2011												  */  
/* BugId		: PNR2.0_31958												  */  
/* modified for	: controls are not fetched for Page Events 					  */  
/******************************************************************************/  
/* modified by : Loganayaki P               */
/* date   : Oct 15 2016              */
/* BugId  : TECH-218             */
/* modified for : Hdnrt_stcontrl Should be fetched in Action control mapping,Since in RT state there is no task state mapping*/
/******************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118         */
/* Modified on : 30-May-2017                                                    */
/* Description : Platform Feature Release                                       */
/********************************************************************************/
/* Modified by : JeyaLatha/Ranjitha R      for callid  TECH-18349               */
/* Modified on : 31-Jan-2018                                                    */
/* Description : Platform Feature Release                                       */
/********************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-19347 */  
/********************************************************************************/
/* Modified by  : Ranjitha R	Date: 28-Feb-2018  Defect ID : TECH-20326 */  
/*****************************************************************************************/
/* Modified By : Jeya Latha K/Venkatesan K  Date: 04-Dec-2018  Defect ID: TECH-28806     */
/* Modified by : Jeya Latha K/Venkatesan K  Date: 17-Jun-2019  Defect ID: TECH-34971     */
/* Modified by : Jeya Latha K				Date: 28-Jun-2019  Defect ID: TECH-35368     */
/* Modified by : Jeya Latha K				Date: 09-Jul-2019  Defect ID: TECH-35248     */ 
/* Modified by : Jeya Latha K			    Date: 25-Jul-2019  Defect ID: TECH-36371	 */
/*****************************************************************************************/
/* Modified by : Jeya Latha K/Ponmalar A    Date: 17-Sep-2021  Defect ID: TECH-62151	 */
/* Description : Ignoring action column type in Action control Mapping Grid				 */
/*****************************************************************************************/
/* Modified by : Ponmalar A					Date: 27-Oct-2022  Defect ID: TECH-73996	 */
/*****************************************************************************************/
/* Modified by : Ponmalar A					Date: 01-Dec-2022  Defect ID: TECH-75320	 */
/*****************************************************************************************/
CREATE procedure de_design_sp_defctltc
	@ctxt_language             engg_ctxt_language,
	@ctxt_ouinstance           engg_ctxt_ouinstance,
	@ctxt_service              engg_ctxt_service,
	@ctxt_user                 engg_ctxt_user,
	@engg_act_descr            engg_description,
	@engg_component            engg_description,
	@engg_customer_name        engg_name,
	@engg_ico_no               engg_name,
	@engg_proj_proc_descr      engg_description,
	@engg_project_name         engg_name,
	@engg_task_name            engg_name,
-- code modified by shafina on 11-Jan-2005 for DEENG203ACC_000135(New tab for ActionReuse is added.)
	@engg_tc_hdrtask_descr        engg_description,
	@engg_tc_page              engg_name,
	@engg_tc_section           engg_name,
	@engg_ui_descr             engg_description,
	@m_errorid                    int output
as
begin

	set nocount on

	--temporary and formal parameters mapping
	select @ctxt_language                 = @ctxt_language
	select @ctxt_ouinstance               = @ctxt_ouinstance
	select @ctxt_service                  = ltrim(rtrim(@ctxt_service))
	select @ctxt_user                     = ltrim(rtrim(@ctxt_user))
	select @engg_act_descr                = ltrim(rtrim(@engg_act_descr))
	select @engg_component                = ltrim(rtrim(@engg_component))
	select @engg_customer_name            = ltrim(rtrim(@engg_customer_name))
	select @engg_ico_no                   = ltrim(rtrim(@engg_ico_no))
	select @engg_proj_proc_descr          = ltrim(rtrim(@engg_proj_proc_descr))
	select @engg_project_name             = ltrim(rtrim(@engg_project_name))
	select @engg_task_name                = ltrim(rtrim(@engg_task_name))
	select @engg_tc_page                  = ltrim(rtrim(@engg_tc_page))
	select @engg_tc_section               = ltrim(rtrim(@engg_tc_section))
	select @engg_tc_hdrtask_descr         = ltrim(rtrim(@engg_tc_hdrtask_descr))
	select @engg_ui_descr                 = ltrim(rtrim(@engg_ui_descr))

	--null checking
	if @ctxt_language = -915
	select @ctxt_language = null

	if @ctxt_ouinstance = -915
	select @ctxt_ouinstance = null

	if @ctxt_service = '~#~'
	select @ctxt_service = null

	if @ctxt_user = '~#~'
	select @ctxt_user = null

	if @engg_act_descr = '~#~'
	select @engg_act_descr = null

	if @engg_component = '~#~'
	select @engg_component = null

	if @engg_customer_name = '~#~'
	select @engg_customer_name = null

	if @engg_ico_no = '~#~'
	select @engg_ico_no = null

	if @engg_proj_proc_descr = '~#~'
	select @engg_proj_proc_descr = null

	if @engg_project_name = '~#~'
	select @engg_project_name = null

	if @engg_task_name = '~#~'
	select @engg_task_name = null

	if @engg_tc_page = '~#~'
	select @engg_tc_page = null

	if @engg_tc_section = '~#~'
	select @engg_tc_section = null

	if @engg_tc_hdrtask_descr = '~#~'
	select @engg_tc_hdrtask_descr = null

	if @engg_ui_descr = '~#~'
	select @engg_ui_descr = null

	-- code modified by Ganesh for the callid :: PNR2.0_3947 on 22/09/05
	if isnull(@engg_task_name, '') = ''
	begin
		EXEC    ENGG_ERROR_SP	'de_design_sp_defctltc',			
				'1',
				'THERE IS NO TASK DEFINED FOR THE SELECTED PAGE',
				@CTXT_LANGUAGE,
				@CTXT_OUINSTANCE,
				@CTXT_SERVICE,
				@CTXT_USER,	
				'',
				'',
				'',
				'',
				@m_errorid	
		return
	 end

	declare	@process_name_tmp	engg_name

	select	@process_name_tmp = process_name 
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_descr	= @engg_proj_proc_descr
		
	declare	@component_name_tmp  engg_name

	select	@component_name_tmp = component_name 
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_descr	= @engg_component

	declare @activity_name_tmp	engg_name

	select	@activity_name_tmp = activity_name 
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and		activity_descr	= @engg_act_descr
	
	declare @ui_name_tmp	engg_name

	select	@ui_name_tmp = ui_name 
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and 	activity_name	= @activity_name_tmp
	and		ui_descr		= @engg_ui_descr
	
	declare @guid		engg_guid
	
	select	@guid = newid()
	-- Code Added by feroz for state Processing feature 
	declare @ui_prefix	engg_name

	select 	@ui_prefix	= page_prefix
	from 	de_ui_page (nolock)			
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and 	activity_name	= @activity_name_tmp
	and 	ui_name 		= @ui_name_tmp
	and 	page_bt_synonym = '[Mainscreen]'

-- code uncommented by Anuradha M on 28-Aug-2006 for the Bug ID :: PNR2.0_10065  -- start
 	if @engg_tc_page = 'All'
		select @engg_tc_page = null
 	if @engg_tc_section = 'All'
		select @engg_tc_section = null
-- code uncommented by Anuradha M on 28-Aug-2006 for the Bug ID :: PNR2.0_10065  -- End

	declare @taskpattern_tmp engg_name

-- 	select @taskpattern_tmp		=	vw.default_for
-- 	from de_action 				act(nolock),
-- 		 es_comp_task_type_mst_vw vw(nolock)
-- 	where   act.customer_name	=	@engg_customer_name 
-- 	and   act.project_name		=	@engg_project_name
-- 	and   act.process_name		=	@process_name_tmp
-- 	and   act.component_name	=	@component_name_tmp
-- 	and   act.activity_name		=	@activity_name_tmp
-- 	and   act.ui_name			=   @ui_name_tmp
-- 	and   act.task_name			=   @engg_task_name	
-- 	and   vw.customer_name		=	@engg_customer_name 	
-- 	and   vw.project_name		=	@engg_project_name
-- 	and   vw.process_name		=	@process_name_tmp
-- 	and   vw.component_name		=	@component_name_tmp
-- 	and   vw.task_type_name 	=	act.task_pattern

--starts here

/** 
	Commented for the Defect id: TECH_20326 starts. */
-- Code added for Defect id TECH-18349 starts
	--if not exists (select 'x' 
	--from	de_hidden_view_usage (nolock)
	--where 	customer_name	= @engg_customer_name
	--and		project_name	= @engg_project_name
	--and		process_name	= @process_name_tmp
	--and		component_name	= @component_name_tmp
	--and 	activity_name	= @activity_name_tmp
	--and 	ui_name 		= @ui_name_tmp
	--and     action_name		= @engg_task_name
	--and     ((hidden_view_bt_sysnonym	like 'hdiFID%' 
	--and     hidden_view_bt_sysnonym	like 'hdiDFU%') 	
	--or		hidden_view_bt_sysnonym	like 'hdiMDL%')) -- added for Defect Id: TECH-19347
	--begin
	--	insert into de_hidden_view_usage (
	--			customer_name,		project_name,		process_name,		component_name,			activity_name,		ui_name,
	--			page_name,			action_name,		control_bt_sysnonym,hidden_view_bt_sysnonym,timestamp,			createdby,
	--			createddate,		modifiedby,			modifieddate,		control_page_name,		map_ml_flag,		ecrno)
	--	select  vw.customer_name,	vw.project_name,	vw.process_name,	vw.component_name,		vw.activity_name,	vw.ui_name,
	--			page_bt_synonym,	task_name,			control_bt_synonym,	hidden_view_bt_synonym,	1,					@ctxt_user,
	--			getdate(),			@ctxt_user,			getdate(),			page_name,				'Y' ,				@engg_ico_no
	--	from	de_hidden_view vw (nolock),
	--			de_action act (nolock)	
	--	where 	vw.customer_name			= @engg_customer_name
	--	and		vw.project_name				= @engg_project_name
	--	and		vw.process_name				= @process_name_tmp
	--	and		vw.component_name			= @component_name_tmp
	--	and 	vw.activity_name			= @activity_name_tmp
	--	and 	vw.ui_name 					= @ui_name_tmp
	--	and     task_name					= @engg_task_name
	--	and    ((vw.hidden_view_bt_synonym	like 'hdiFID%' 
	--	and      vw.hidden_view_bt_synonym	like 'hdiDFU%' )
	--	or		vw.hidden_view_bt_synonym   like 'hdiMDL%') -- added for Defect Id: TECH-19347
	--	and     vw.customer_name			= act.customer_name
	--	and     vw.project_name				= act.project_name
	--	and     vw.process_name				= act.process_name
	--	and		vw.component_name			= act.component_name
	--	and     vw.activity_name			= act.activity_name
	--	and		vw.ui_name 					= act.ui_name
	--	and     page_name					= page_bt_synonym
	--	and		not exists (select 'x'
	--	from	de_hidden_view_usage (nolock)
	--	where 	customer_name	= vw.customer_name
	--	and		project_name	= vw.project_name
	--	and		process_name	= vw.process_name
	--	and		component_name	= vw.component_name
	--	and 	activity_name	= vw.activity_name
	--	and 	ui_name 		= vw.ui_name
	--	and     page_name		= vw.page_name
	--	and     action_name		= act.task_name
	--	and		control_bt_sysnonym=vw.control_bt_synonym
	--	and		hidden_view_bt_sysnonym=vw.hidden_view_bt_synonym)
	--end
-- Code added for Defect id TECH-18349 ends
/* Commented for the Defect id: TECH_20326 ends. */

		
	select	@taskpattern_tmp	= ''

	If	Exists(	Select	'A'
	from	de_action	(nolock)
	where	customer_name		= @engg_customer_name
	and		project_name		= @engg_project_name
	and		process_name		= @process_name_tmp
	and		component_name		= @component_name_tmp
	and		activity_name		= @activity_name_tmp
	and		ui_name				= @ui_name_tmp
	and		task_name			= @engg_task_name
	and		isNull(primary_control_bts, '[NONE]')	<> '[NONE]')
	begin		
		Select	@taskpattern_tmp = case	upper(c.base_ctrl_type)
				when	'BUTTON'	then	'Trans'
				when	'LINK'		then	'Link'
				when	'GRID'		then	'Zoom'
				else	'UI'
				end
		from	de_action A (nolock),
				de_ui_control B (nolock),
				es_comp_ctrl_type_mst_vw C (nolock)
		where	a.customer_name			= @engg_customer_name
		and		a.project_name			= @engg_project_name
		and		a.process_name			= @process_name_tmp
		and		a.component_name		= @component_name_tmp
		and		a.activity_name			= @activity_name_tmp
		and		a.ui_name				= @ui_name_tmp
		and		a.task_name				= @engg_task_name
		and		a.customer_name			= b.customer_name
		and		a.project_name			= b.project_name
		and		a.process_name			= b.process_name
		and		a.component_name		= b.component_name
		and		a.activity_name			= b.activity_name
		and		a.ui_name				= b.ui_name
		and		a.page_bt_synonym		= b.page_bt_synonym
		and		a.primary_control_bts	= b.control_bt_synonym
		and		c.customer_name			= b.customer_name
		and		c.project_name			= b.project_name
		and		c.process_name			= b.process_name
		and		c.component_name		= b.component_name
		and		c.ctrl_type_name		= b.control_type
		
		Select	@taskpattern_tmp = case	upper(c.base_ctrl_type)
				when	'BUTTON'	then	'Trans'
				when	'LINK'		then	'Link'
				when	'GRID'		then	'Zoom'
				else	'UI'
				end
		from	de_action A (nolock),
				de_ui_control B (nolock),
				es_comp_stat_ctrl_type_mst	C (nolock)
		where	a.customer_name			= @engg_customer_name
		and		a.project_name			= @engg_project_name
		and		a.process_name			= @process_name_tmp
		and		a.component_name		= @component_name_tmp
		and		a.activity_name			= @activity_name_tmp
		and		a.ui_name				= @ui_name_tmp
		and		a.task_name				= @engg_task_name
		and		a.customer_name			= b.customer_name
		and		a.project_name			= b.project_name
		and		a.process_name			= b.process_name
		and		a.component_name		= b.component_name
		and		a.activity_name			= b.activity_name
		and		a.ui_name				= b.ui_name
		and		a.page_bt_synonym		= b.page_bt_synonym
		and		a.primary_control_bts	= b.control_bt_synonym
		and		c.customer_name			= b.customer_name
		and		c.project_name			= b.project_name
		and		c.process_name			= b.process_name
		and		c.component_name		= b.component_name
		and		c.ctrl_type_name		= b.control_type
		
		-- Code added for TECH-28806 Starts
		Select	@taskpattern_tmp		= CASE 
					WHEN C.ActionType = 'taskinfo' AND C.ControlName like 'grd%'  THEN 'UI'
					WHEN C.ActionType = 'taskinfo' AND C.ControlName not like 'grd%'  THEN 'Trans'
					WHEN C.ActionType = 'linkinfo'   THEN  'LINK'
				END
		from	de_action A (nolock),				
				ngplf_wr_template_action C (nolock)
		where	a.customer_name			= @engg_customer_name
		and		a.project_name			= @engg_project_name
		and		a.process_name			= @process_name_tmp
		and		a.component_name		= @component_name_tmp
		and		a.activity_name			= @activity_name_tmp
		and		a.ui_name				= @ui_name_tmp
		and		a.task_name				= @engg_task_name
		and		a.customer_name			= c.CustomerID
		and		a.project_name			= c.ProjectID
		and		a.process_name			= c.ProcessName
		and		a.component_name		= c.componentname
		and		a.activity_name			= c.ActivityName
		and		a.ui_name				= c.UIName
		and		a.page_bt_synonym		= c.PageName		
		and		(	(a.primary_control_bts	= c.controlname  +'_'+ c.actionname) or (a.primary_control_bts	= c.controlname  + c.actionname)	)
		-- Code added for TECH-28806 Ends

		If	IsNull(@taskpattern_tmp, '') = ''
		begin
			Select	@taskpattern_tmp	=	case	upper(c.base_ctrl_type)
					when	'BUTTON'	then	'Trans'
					when	'LINK'		then	'Link'
					when	'GRID'		then	'Zoom'
					else	'UI'
					end
			from	de_action A (nolock),
					de_ui_grid B (nolock),
					es_comp_ctrl_type_mst_vw C (nolock)
			where	a.customer_name			= @engg_customer_name
			and		a.project_name			= @engg_project_name
			and		a.process_name			= @process_name_tmp
			and		a.component_name		= @component_name_tmp
			and		a.activity_name			= @activity_name_tmp
			and		a.ui_name				= @ui_name_tmp
			and		a.task_name				= @engg_task_name
			and		a.customer_name			= b.customer_name
			and		a.project_name			= b.project_name
			and		a.process_name			= b.process_name
			and		a.component_name		= b.component_name
			and		a.activity_name			= b.activity_name
			and		a.ui_name				= b.ui_name
			and		a.page_bt_synonym		= b.page_bt_synonym
			and		a.primary_control_bts	= b.column_bt_synonym
			and		c.customer_name			= b.customer_name
			and		c.project_name			= b.project_name
			and		c.process_name			= b.process_name
			and		c.component_name		= b.component_name
			and		c.ctrl_type_name		= b.column_type


			Select	@taskpattern_tmp	=	case	upper(c.base_ctrl_type)
					when	'BUTTON'	then	'Trans'
					when	'LINK'		then	'Link'
					when	'GRID'		then	'Zoom'
					else	'UI'
					end
			from	de_action					A (nolock),
					de_ui_grid					B (nolock),
					es_comp_stat_ctrl_type_mst	C (nolock)
			where	a.customer_name			= @engg_customer_name
			and		a.project_name			= @engg_project_name
			and		a.process_name			= @process_name_tmp
			and		a.component_name		= @component_name_tmp
			and		a.activity_name			= @activity_name_tmp
			and		a.ui_name				= @ui_name_tmp
			and		a.task_name				= @engg_task_name
			and		a.customer_name			= b.customer_name
			and		a.project_name			= b.project_name
			and		a.process_name			= b.process_name
			and		a.component_name		= b.component_name
			and		a.activity_name			= b.activity_name
			and		a.ui_name				= b.ui_name
			and		a.page_bt_synonym		= b.page_bt_synonym
			and		a.primary_control_bts	= b.column_bt_synonym
			and		c.customer_name			= b.customer_name
			and		c.project_name			= b.project_name
			and		c.process_name			= b.process_name
			and		c.component_name		= b.component_name
			and		c.ctrl_type_name		= b.column_type
		end
		
		if @taskpattern_tmp = 'Zoom'
		Begin	
			Select	@taskpattern_tmp = case	upper(c.section_type)
					when	'MobCalendar'	then	'Trans'					
					else	'UI'
					end			
			from	de_action	A (nolock),
					de_ui_control B (nolock),
					de_ui_Section	C (nolock)
			where	a.customer_name			= @engg_customer_name
			and		a.project_name			= @engg_project_name
			and		a.process_name			= @process_name_tmp
			and		a.component_name		= @component_name_tmp
			and		a.activity_name			= @activity_name_tmp
			and		a.ui_name				= @ui_name_tmp
			and		a.task_name				= @engg_task_name
			and		a.customer_name			= b.customer_name
			and		a.project_name			= b.project_name
			and		a.process_name			= b.process_name
			and		a.component_name		= b.component_name
			and		a.activity_name			= b.activity_name
			and		a.ui_name				= b.ui_name
			and		a.page_bt_synonym		= b.page_bt_synonym
			and		a.primary_control_bts	= b.control_bt_synonym
			and		c.customer_name			= b.customer_name
			and		c.project_name			= b.project_name
			and		c.process_name			= b.process_name
			and		c.component_name		= b.component_name
			and		c.activity_name			= b.activity_name
			and		c.ui_name				= b.ui_name
			and		c.page_bt_synonym		= b.page_bt_synonym
			and		c.section_bt_synonym	= b.section_bt_synonym
		End
		--Else 
		--select @taskpattern_tmp = 'Zoom'
	end
	else
	begin
		If	upper(right(@engg_task_name, 4))= 'INIT'
			select	@taskpattern_tmp	= 'Init'
		else
			select	@taskpattern_tmp	= 'Fetch'
	end
	
-- ends here


-- Code modification  for PNR2.0_30869  starts 
  
	If IsNull(@taskpattern_tmp, '') = ''  
	begin  
		Select	@taskpattern_tmp	= (a.task_type) --  PNR2.0_31958 
		from	de_action   A (nolock),  
				de_ui_page   B (nolock)
		where	a.customer_name		= @engg_customer_name  
		and		a.project_name		= @engg_project_name  
		and		a.process_name		= @process_name_tmp  
		and		a.component_name	= @component_name_tmp  
		and		a.activity_name		= @activity_name_tmp  
		and		a.ui_name			= @ui_name_tmp  
		and		a.task_name			= @engg_task_name  
		and		a.customer_name		= b.customer_name  
		and		a.project_name		= b.project_name  
		and		a.process_name		= b.process_name  
		and		a.component_name	= b.component_name  
		and		a.activity_name		= b.activity_name  
		and		a.ui_name			= b.ui_name  
		and		a.primary_control_bts= b.page_bt_synonym  

	end  
  
-- Code modification  for PNR2.0_30869  ends 



	if @taskpattern_tmp ='Init'
	begin

		insert into de_task_control_map(
			customer_name,			project_name,			process_name,			component_name,			activity_name,			ui_name,		
			action_name,			page_name,				section_name,			control_bt_synonym,		map_flag, 				map_ml_flag,	
			tc_sysid,				timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
			ecrno,					control_type)--chan --TECH-75230
		select distinct 
			@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,	@activity_name_tmp,		@ui_name_tmp, 
			@engg_task_name,		a.page_bt_synonym 'PG',	a.section_bt_synonym 'SC',control_bt_synonym 'CBTS','Y',				'Y', 
			@guid,					0,						@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
			@engg_ico_no,			base_ctrl_type--chan --TECH-75230
		from	de_ui_control			A (nolock),
				es_comp_ctrl_type_mst_vw	CTM (nolock)	
		where 	a.customer_name		=	@engg_customer_name 
		and   	a.project_name		=	@engg_project_name
		and   	a.process_name		=	@process_name_tmp
		and   	a.component_name	=	@component_name_tmp
		and   	a.activity_name		=	@activity_name_tmp
		and   	a.ui_name			=   @ui_name_tmp
		and   	a.customer_name 	= 	ctm.customer_name
		and   	a.project_name 		=   ctm.project_name
		and   	a.process_name 		= 	ctm.process_name
		and		a.component_name	= 	ctm.component_name
		and		a.control_type		=   ctm.ctrl_type_name	
		and		ctm.base_ctrl_type	= 	'Combo'
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
		and    a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
		and    a.section_bt_synonym =  isnull(@engg_tc_section,a.section_bt_synonym)
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
--		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
		and   a.control_bt_synonym not in ( select control_bt_synonym 
		from de_task_control_map M(nolock)																	
		where m.customer_name		=	@engg_customer_name 
		and   m.project_name		=	@engg_project_name
		and   m.process_name		=	@process_name_tmp
		and   m.component_name		=	@component_name_tmp
		and   m.activity_name		=	@activity_name_tmp
		and   m.ui_name			    =   @ui_name_tmp	
		and   m.page_name		    = 	isnull(a.page_bt_synonym,m.page_name)
		and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
		and   m.action_name 		= 	@engg_task_name)
-- 		group by a.page_bt_synonym,	a.section_bt_synonym,	a.control_bt_synonym

		insert into de_task_control_map(
			customer_name,			project_name,				process_name,				component_name,					activity_name,	
			ui_name,				action_name,				page_name,					section_name,					control_bt_synonym,	
			map_flag, 				map_ml_flag,				tc_sysid,					timestamp,						createdby,		
			createddate,			modifiedby,					modifieddate,				ecrno,							control_type)--chan --TECH-75230
		select	distinct
			@engg_customer_name,	@engg_project_name,			@process_name_tmp,			@component_name_tmp,			@activity_name_tmp,				
			@ui_name_tmp,			@engg_task_name,			a.page_bt_synonym 'PG',		a.section_bt_synonym 'SC',		column_bt_synonym 'CBTS',
			'Y',					'Y',						@guid,						0,								@ctxt_user,
			getdate(),				@ctxt_user,					getdate(),					@engg_ico_no,					base_ctrl_type --chan --TECH-75230
		from	de_ui_grid A (nolock),
				es_comp_ctrl_type_mst_vw CTM (nolock)
		where	a.customer_name		=	@engg_customer_name 
		and		a.project_name		=	@engg_project_name
		and		a.process_name		=	@process_name_tmp
		and		a.component_name	=	@component_name_tmp
		and		a.activity_name		=	@activity_name_tmp
		and		a.ui_name			=   @ui_name_tmp
		and		a.customer_name 	= 	ctm.customer_name
		and		a.project_name 		=  	ctm.project_name
		and		a.process_name 		= 	ctm.process_name
		and		a.component_name	=	ctm.component_name
		and		a.column_type		=   ctm.ctrl_type_name	
		and		ctm.base_ctrl_type	= 	'Combo'
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
		and		a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
		and		a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
--		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
		and		a.column_bt_synonym not in  ( select control_bt_synonym 
		from	de_task_control_map M(nolock)																	
		where	m.customer_name		=	@engg_customer_name 
		and		m.project_name		=	@engg_project_name
		and		m.process_name		=	@process_name_tmp
		and		m.component_name	=	@component_name_tmp
		and		m.activity_name		=	@activity_name_tmp
		and		m.ui_name			=   @ui_name_tmp	
-- Code Modified by Ganesh To Populate the Same Control Difined under 2 Different Pages
-- for the Bugid :::DEENG203ACC_000087 on 14/7/04																							 			
		and   m.page_name			= 	isnull(a.page_bt_synonym,m.page_name)
		and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
		and   m.action_name 		= 	@engg_task_name)
--group by a.page_bt_synonym,	a.section_bt_synonym,	a.column_bt_synonym
	
	----TECH-73996
	--IF EXISTS
	--(SELECT 'X'
	--FROM	es_quick_code_met (NOLOCK)
	--WHERE	CustomerName	=	@engg_customer_name
	--AND		ProjectName		=	@engg_project_name
	--AND		ParameterCode	=	'DefaultinghiddenView'
	--AND		ParameterText	=	'AUTO_MAP_HDNVIEW_COMBO'
	--AND		ParameterValue	=	'Y')
	--BEGIN
	
	--IF NOT EXISTS
	--(SELECT 'X'
	-- FROM	de_task_service_method_vw (NOLOCK)
	-- WHERE	customer_name		=	@engg_customer_name 
	-- AND	project_name		=	@engg_project_name
	-- AND	process_name		=	@process_name_tmp
	-- AND	component_name		=	@component_name_tmp
	-- AND	activity_name		=	@activity_name_tmp
	-- AND	ui_name				=   @ui_name_tmp	
	-- AND	task_name 			= 	@engg_task_name)
	-- BEGIN
	--INSERT INTO de_task_control_map(
	--		customer_name,			project_name,			process_name,			component_name,			activity_name,			ui_name,		
	--		action_name,			page_name,				section_name,			control_bt_synonym,		map_flag, 				map_ml_flag,	
	--		tc_sysid,				timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
	--		ecrno,					control_type)--chan --14469
	--	SELECT distinct 
	--		@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,	@activity_name_tmp,		@ui_name_tmp, 
	--		@engg_task_name,		a.page_name 'PG',		a.section_name 'SC',	hidden_view_bt_synonym 'CBTS','Y',				'Y', 
	--		@guid,					0,						@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
	--		@engg_ico_no,			base_ctrl_type  --14469--chan
	--	FROM	de_hidden_view			A (NOLOCK)	
	--	JOIN	de_ui_control   b (NOLOCK)
	--	ON		a.customer_name				= b.customer_name
	--	AND		a.project_name				= b.project_name
	--	AND		a.process_name				= b.process_name
	--	AND		a.component_name			= b.component_name
	--	AND		a.activity_name				= b.activity_name
	--	AND		a.ui_name					= b.ui_name
	--	AND		a.page_name					= b.page_bt_synonym
	--	AND		a.section_name				= b.section_bt_synonym
	--	AND		a.control_bt_synonym		= b.control_bt_synonym
	--	JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
	--	ON		b.customer_name				= c.customer_name
	--	AND		b.project_name				= c.project_name
	--	AND		b.process_name				= c.process_name
	--	AND		b.component_name			= c.component_name
	--	AND		b.control_type				= c.ctrl_type_name
	--	WHERE 	a.customer_name		=	@engg_customer_name 
	--	AND   	a.project_name		=	@engg_project_name
	--	AND   	a.process_name		=	@process_name_tmp
	--	AND   	a.component_name	=	@component_name_tmp
	--	AND   	a.activity_name		=	@activity_name_tmp
	--	AND   	a.ui_name			=   @ui_name_tmp
	--	AND    a.page_name 			=  ISNULL(@engg_tc_page,a.page_name)
	--	AND    a.section_name		=  ISNULL(@engg_tc_section,a.section_name)
	--	AND   a.hidden_view_bt_synonym NOT IN ( select control_bt_synonym 
	--	FROM de_task_control_map M(NOLOCK)																	
	--	WHERE m.customer_name		=	@engg_customer_name 
	--	AND   m.project_name		=	@engg_project_name
	--	AND   m.process_name		=	@process_name_tmp
	--	AND   m.component_name		=	@component_name_tmp
	--	AND   m.activity_name		=	@activity_name_tmp
	--	AND   m.ui_name			    =   @ui_name_tmp	
	--	AND   m.page_name		    = 	ISNULL(a.page_name,m.page_name)
	--	AND   m.section_name		= 	ISNULL(@engg_tc_section,m.section_name)
	--	AND   m.action_name 		= 	@engg_task_name)
	--	AND     c.base_ctrl_type	= 'Combo'
	--	UNION
	--	SELECT distinct 
	--		@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,	@activity_name_tmp,		@ui_name_tmp, 
	--		@engg_task_name,		a.page_name 'PG',		a.section_name 'SC',	hidden_view_bt_synonym 'CBTS','Y',				'Y', 
	--		@guid,					0,						@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
	--		@engg_ico_no,			'HiddenView' --chan  --14469
	--	FROM	de_hidden_view			A (NOLOCK)	
	--	JOIN	de_ui_grid   b (NOLOCK)
	--	ON		a.customer_name				= b.customer_name
	--	AND		a.project_name				= b.project_name
	--	AND		a.process_name				= b.process_name
	--	AND		a.component_name			= b.component_name
	--	AND		a.activity_name				= b.activity_name
	--	AND		a.ui_name					= b.ui_name
	--	AND		a.page_name					= b.page_bt_synonym
	--	AND		a.section_name				= b.section_bt_synonym
	--	AND		a.control_bt_synonym		= b.column_bt_synonym
	--	JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
	--	ON		b.customer_name				= c.customer_name
	--	AND		b.project_name				= c.project_name
	--	AND		b.process_name				= c.process_name
	--	AND		b.component_name			= c.component_name
	--	AND		b.column_type				= c.ctrl_type_name
	--	WHERE 	a.customer_name		=	@engg_customer_name 
	--	AND   	a.project_name		=	@engg_project_name
	--	AND   	a.process_name		=	@process_name_tmp
	--	AND   	a.component_name	=	@component_name_tmp
	--	AND   	a.activity_name		=	@activity_name_tmp
	--	AND   	a.ui_name			=   @ui_name_tmp
	--	AND    a.page_name 			=  ISNULL(@engg_tc_page,a.page_name)
	--	AND    a.section_name		=  ISNULL(@engg_tc_section,a.section_name)
	--	AND   a.hidden_view_bt_synonym NOT IN ( select control_bt_synonym 
	--	FROM de_task_control_map M(NOLOCK)																	
	--	WHERE m.customer_name		=	@engg_customer_name 
	--	AND   m.project_name		=	@engg_project_name
	--	AND   m.process_name		=	@process_name_tmp
	--	AND   m.component_name		=	@component_name_tmp
	--	AND   m.activity_name		=	@activity_name_tmp
	--	AND   m.ui_name			    =   @ui_name_tmp	
	--	AND   m.page_name		    = 	ISNULL(a.page_name,m.page_name)
	--	AND   m.section_name		= 	ISNULL(@engg_tc_section,m.section_name)
	--	AND   m.action_name 		= 	@engg_task_name)
	--	AND     c.base_ctrl_type	= 'Combo'
		
	--END
	--END
	----TECH-73996


--  Modification for PNR2.0_19109  starts

	create table #de_task_control_map_tmp 
	(
	customer_name   	varchar(60)  collate database_default,
	project_name    	varchar(60)  collate database_default,
	process_name    	varchar(60)  collate database_default,
	component_name  	varchar(60)  collate database_default,
	activity_name   	varchar(60)  collate database_default,
	ui_name				varchar(60)  collate database_default,
	action_name    	 	varchar(60)  collate database_default,
	page_name 			varchar(60)  collate database_default,
	section_name 		varchar(60)  collate database_default, 
	control_bt_synonym 	varchar(60)  collate database_default,
	control_type		varchar(60)  collate database_default --TECH-75230
	)



	insert into #de_task_control_map_tmp 
		(customer_name,				project_name,			process_name,				component_name,				activity_name,
		ui_name,					action_name,			page_name,					section_name,				control_bt_synonym,
		control_type)	--TECH-75230
	select distinct 
		@engg_customer_name,		@engg_project_name,		@process_name_tmp,			@component_name_tmp,		@activity_name_tmp,
		@ui_name_tmp,				@engg_task_name,		a.page_bt_synonym,			c.section_bt_synonym ,		a.published_bt_synonym,
		base_ctrl_type	--TECH-75230
	from	de_publication_dataitem  A (nolock),
			de_ui_control   C(nolock),
			es_comp_ctrl_type_mst_vw CTM (nolock)
	where	a.customer_name			= @engg_customer_name
	and		a.project_name			= @engg_project_name
	and		a.process_name			= @process_name_tmp
	and		a.component_name		= @component_name_tmp
	and		a.activity_name			= @activity_name_tmp
	and		a.ui_name				= @ui_name_tmp
	and		a.page_bt_synonym		= isnull(@engg_tc_page,a.page_bt_synonym)
	and		c.section_bt_synonym	= isnull(@engg_tc_section,c.section_bt_synonym)
	and		a.customer_name			= ctm.customer_name
	and		a.project_name			= ctm.project_name
	and		a.process_name			= ctm.process_name
	and		a.component_name		= ctm.component_name
	and		c.control_type			= ctm.ctrl_type_name
	--       and   ctm.base_ctrl_type <> 'Grid'
	--Code Modified For BugId : PNR2.0_9131
	and		ctm.base_ctrl_type not in ('Grid','Button','Link','Line','Label', 'ListEdit','RSSlider', 'Slider','Assorted', 'Pivot','TreeGrid', 'ListView') --ttt -- -- Modified By feroz for bug id :PNR2.0_23463 
	-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061
	and		c.control_type  not in ('Filler','Filler2','Label')
	-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061
	and		a.customer_name			= c.customer_name
	and		a.project_name			= c.project_name
	and		a.process_name			= c.process_name
	and		a.component_name		= c.component_name
	and		a.activity_name			= c.activity_name
	and		a.ui_name				= c.ui_name
	-- code modified by shafina on 28-May-2004 for DEENG203ACC_000058
	--(In action control mapping tab , when default is done for init task , published dataitems must also be fetched in the ML along with the combo controls , .)
	and		a.page_bt_synonym		=   c.page_bt_synonym
	and		a.published_bt_synonym	=   c.control_bt_synonym
	--        and   a.published_control_name = c.control_bt_synonym
	and		a.published_control_name= c.control_id
	and		a.published_view_name	= c.view_name
	--  code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
	and   c.section_bt_synonym not in  ( select section_bt_synonym
	from  de_ui_section M(nolock)
	where m.customer_name			= @engg_customer_name
	and   m.project_name			= @engg_project_name
	and   m.process_name			= @process_name_tmp
	and   m.component_name			= @component_name_tmp
	and   m.activity_name			= @activity_name_tmp
	and   m.ui_name					= @ui_name_tmp
	and	  m.section_type			= 'ListItem')
	and   a.published_bt_synonym not in  ( select control_bt_synonym
	from  de_task_control_map M(nolock)
	where m.customer_name			= @engg_customer_name
	and   m.project_name			= @engg_project_name
	and   m.process_name			= @process_name_tmp
	and   m.component_name			= @component_name_tmp
	and   m.activity_name			= @activity_name_tmp
	and   m.ui_name					= @ui_name_tmp
	and   m.page_name				= isnull(a.page_bt_synonym,m.page_name)
	and   m.section_name			= isnull(@engg_tc_section,m.section_name)
	and   m.action_name				= @engg_task_name)

	insert into de_task_control_map
		(customer_name,				project_name,			process_name,			component_name,				activity_name,
		ui_name,					action_name,			page_name,				section_name,				control_bt_synonym,
		map_flag,					map_ml_flag,			tc_sysid,				timestamp,					createdby,
		createddate,				modifiedby,				modifieddate,			ecrno,						control_type)--chan --TECH-75230
	select  
		customer_name,				project_name,			process_name,			component_name,				activity_name,
		ui_name,					action_name,			page_name 'PG',			section_name 'SC',			control_bt_synonym 'CBTS',
		'Y',						'Y',					newid() ,				0,							@ctxt_user,
		getdate(),					@ctxt_user,				getdate(),				@engg_ico_no,				control_type --TECH-75230
	from  #de_task_control_map_tmp  (nolock)





/*
		insert into de_task_control_map(customer_name,	project_name,	process_name,	component_name,	activity_name,	
										ui_name,		action_name,	page_name,		section_name,	control_bt_synonym,	
										map_flag, 		map_ml_flag,	tc_sysid,		timestamp,		createdby,		
										createddate,	modifiedby,	modifieddate,ecrno)--chan
							select		distinct @engg_customer_name,	@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,				
										@ui_name_tmp,			@engg_task_name,	a.page_bt_synonym 'PG',	c.section_bt_synonym 'SC',	a.published_bt_synonym 'CBTS',
										'Y',						'Y',					@guid,			0,					@ctxt_user,
										getdate(),		@ctxt_user,	getdate(),@engg_ico_no --chan				
							from	de_publication_dataitem		A (nolock),
								de_ui_control			C(nolock),
								es_comp_ctrl_type_mst_vw	CTM (nolock)
							where a.customer_name		=	@engg_customer_name 
							and   a.project_name		=	@engg_project_name
							and   a.process_name		=	@process_name_tmp
							and   a.component_name		=	@component_name_tmp
							and   a.activity_name		=	@activity_name_tmp
							and   a.ui_name				=   @ui_name_tmp
							and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
							and   c.section_bt_synonym 	=  isnull(@engg_tc_section,c.section_bt_synonym)
							and	 a.customer_name		= ctm.customer_name
							and	a.project_name			= ctm.project_name
							and	a.process_name			= ctm.process_name
							and	a.component_name		= ctm.component_name
							and	  c.control_type		=   ctm.ctrl_type_name	
--							and	  ctm.base_ctrl_type	<> 'Grid'
--Code Modified For BugId : PNR2.0_9131
							and	  ctm.base_ctrl_type	not in ('Grid','Button','Link','Line','Label') --ttt
							-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061	
							and	c.control_type		not in ('Filler','Filler2','Label')
							-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061
							and   a.customer_name		=	c.customer_name
							and   a.project_name		=	c.project_name
							and   a.process_name		=	c.process_name
							and   a.component_name		=	c.component_name
							and   a.activity_name		=	c.activity_name
							and   a.ui_name				=	c.ui_name
-- code modified by shafina on 28-May-2004 for DEENG203ACC_000058 
--(In action control mapping tab , when default is done for init task , published dataitems must also be fetched in the ML along with the combo controls , .)
							and	  a.page_bt_synonym		=  	c.page_bt_synonym
							and	  a.published_bt_synonym=   c.control_bt_synonym
-- 							and   a.published_control_name	= c.control_bt_synonym
							and   a.published_control_name	= c.control_id
							and   a.published_view_name 	= c.view_name
--		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
							and   a.published_bt_synonym not in  ( select control_bt_synonym 
							   	from de_task_control_map M(nolock)																	
								where m.customer_name		=	@engg_customer_name 
								and   m.project_name		=	@engg_project_name
								and   m.process_name		=	@process_name_tmp
								and   m.component_name		=	@component_name_tmp
								and   m.activity_name		=	@activity_name_tmp
								and   m.ui_name				=   @ui_name_tmp	
								and   m.page_name			= 	isnull(a.page_bt_synonym,m.page_name)
								and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
								and   m.action_name 		= 	@engg_task_name)
							--group by a.page_bt_synonym,	c.section_bt_synonym,	a.published_bt_synonym

-- code commented by chanheetha N A for the call id : PNR2.0_10466
-- 		insert into de_task_control_map(customer_name,	project_name,	process_name,	component_name,	activity_name,	
-- 										ui_name,		action_name,	page_name,		section_name,	control_bt_synonym,	
-- 										map_flag, 		map_ml_flag,	tc_sysid,		timestamp,		createdby,		
-- 										createddate,	modifiedby,	modifieddate)
-- 						select		@engg_customer_name,	@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,
-- 									@ui_name_tmp,			@engg_task_name,	c.page_bt_synonym 'PG',	c.section_bt_synonym 'SC',	a.published_bt_synonym 'CBTS',
-- 									'Y',						'Y',					newid(),			0,					@ctxt_user,
-- 									getdate(),		@ctxt_user,	getdate()
-- 						from	de_publication_dataitem		A (nolock),
-- 							de_ui_grid			C(nolock),
-- 							es_comp_ctrl_type_mst_vw	CTM (nolock)
-- 						where a.customer_name		=	@engg_customer_name 
-- 						and   a.project_name		=	@engg_project_name
-- 						and   a.process_name		=	@process_name_tmp
-- 						and   a.component_name		=	@component_name_tmp
-- 						and   a.activity_name		=	@activity_name_tmp
-- 						and   a.ui_name				=   @ui_name_tmp
-- 						and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
-- 						and   c.section_bt_synonym 	=  isnull(@engg_tc_section,c.section_bt_synonym)
-- 							and	 a.customer_name		= ctm.customer_name
-- 							and	a.project_name			= ctm.project_name
-- 							and	a.process_name			= ctm.process_name
-- 							and	a.component_name		= ctm.component_name
-- 
-- 						and	  c.column_type			=   ctm.ctrl_type_name	
-- 						and	  ctm.base_ctrl_type	= 'Grid'
-- 						and   a.customer_name		=	c.customer_name
-- 						and   a.project_name		=	c.project_name
-- 						and   a.process_name		=	c.process_name
-- 						and   a.component_name		=	c.component_name
-- 						and   a.activity_name		=	c.activity_name
-- 						and   a.ui_name				=	c.ui_name
-- 						and	  a.page_bt_synonym		=  	c.page_bt_synonym
-- 						and	  a.published_bt_synonym=   c.column_bt_synonym
-- -- 						and   a.published_control_name	= c.control_bt_synonym
-- 						and   a.published_control_name	= c.control_id
-- 						and   a.published_view_name 	= c.view_name
-- --		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
-- 						and   a.published_bt_synonym not in ( select control_bt_synonym 
-- 								   from de_task_control_map M(nolock)																	
-- 									where m.customer_name		=	@engg_customer_name 
-- 									and   m.project_name		=	@engg_project_name
-- 									and   m.process_name		=	@process_name_tmp
-- 									and   m.component_name		=	@component_name_tmp
-- 									and   m.activity_name		=	@activity_name_tmp
-- 									and   m.ui_name				=   @ui_name_tmp	
-- 									and   m.page_name			= 	isnull(c.page_bt_synonym,m.page_name)
-- 									and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
-- 									and   m.action_name 		= 	@engg_task_name)
-- 						group by c.page_bt_synonym,	c.section_bt_synonym,	a.published_bt_synonym


*/
-- code commented by chanheetha N A for the call id : PNR2.0_10466
-- code modified by shafina on 10-Dec-2004 for DEENG203_000121 (In task control mapping tab , hidden views must also be defaulted in the multiline.)
	

	delete  from  #de_task_control_map_tmp

	insert  into #de_task_control_map_tmp
		(customer_name,				project_name,				process_name,				component_name,				activity_name,
		ui_name,					action_name,				page_name,					section_name,				control_bt_synonym)
	select  distinct 
		@engg_customer_name,		@engg_project_name,			@process_name_tmp,			@component_name_tmp,		@activity_name_tmp,
		@ui_name_tmp,				@engg_task_name,			a.page_bt_synonym ,			b.section_name ,			a.published_bt_synonym 
	from	de_publication_dataitem  a (nolock),
			de_hidden_view_usage  c (nolock),
			de_hidden_view    b (nolock)
	where	a.customer_name			= @engg_customer_name
	and		a.project_name			= @engg_project_name
	and		a.process_name			= @process_name_tmp
	and		a.component_name		= @component_name_tmp
	and		a.activity_name			= @activity_name_tmp
	and		a.ui_name				= @ui_name_tmp
	and		a.page_bt_synonym		= isnull(@engg_tc_page,a.page_bt_synonym)
	and		b.section_name			= isnull(@engg_tc_section,b.section_name)
	and		c.customer_name			= b.customer_name
	and		c.project_name			= b.project_name
	and		c.process_name			= b.process_name
	and		c.component_name		= b.component_name
	and		c.activity_name			= b.activity_name
	and		c.ui_name				= b.ui_name
	and		c.page_name				= b.page_name
	and		c.control_bt_sysnonym	= b.control_bt_synonym
	and		c.hidden_view_bt_sysnonym = b.hidden_view_bt_synonym
	and		a.customer_name			= c.customer_name
	and		a.project_name			= c.project_name
	and		a.process_name			= c.process_name
	and		a.component_name		= c.component_name
	and		a.activity_name			= c.activity_name
	and		a.ui_name				= c.ui_name
	and		a.page_bt_synonym		= c.page_name
	and		a.published_bt_synonym	= c.hidden_view_bt_sysnonym
	and		a.published_control_name = b.control_id
	and		a.published_view_name	= b.view_name
	and   b.section_name not in  ( select section_bt_synonym
	from  de_ui_section M(nolock)
	where m.customer_name			= @engg_customer_name
	and   m.project_name			= @engg_project_name
	and   m.process_name			= @process_name_tmp
	and   m.component_name			= @component_name_tmp
	and   m.activity_name			= @activity_name_tmp
	and   m.ui_name					= @ui_name_tmp
	and	  m.section_type			= 'ListItem')

	and		a.published_bt_synonym not in( select control_bt_synonym
	from	de_task_control_map m(nolock)
	where	m.customer_name			= @engg_customer_name
	and		m.project_name			= @engg_project_name
	and		m.process_name			= @process_name_tmp
	and		m.component_name		= @component_name_tmp
	and		m.activity_name			= @activity_name_tmp
	and		m.ui_name				= @ui_name_tmp
	and		m.page_name				= isnull(a.page_bt_synonym,m.page_name)
	and		m.section_name			= isnull(@engg_tc_section,m.section_name)
	and		m.action_name			= @engg_task_name)

	insert into de_task_control_map
		(customer_name,			project_name,				process_name,			component_name,			activity_name,
		ui_name,				action_name,				page_name,				section_name,			control_bt_synonym,
		map_flag,				map_ml_flag,				tc_sysid,				timestamp,				createdby,
		createddate,			modifiedby,					modifieddate,			ecrno,					control_type)--chan	--TECH-75230
	select  customer_name,		project_name,				process_name,			component_name,			activity_name,
		ui_name,				action_name,				page_name 'PG',			section_name 'SC',		control_bt_synonym 'CBTS',
		'Y',					'Y',						newid(),				0,						@ctxt_user,
		getdate(),				@ctxt_user,					getdate(),				@engg_ico_no,			control_type --chan --TECH-75230
	from  #de_task_control_map_tmp  (nolock)


	drop  table  #de_task_control_map_tmp

end

--  Modification for PNR2.0_19109  ends

/*

	insert into de_task_control_map(customer_name,	project_name,	process_name,	component_name,	activity_name,	
										ui_name,		action_name,	page_name,		section_name,	control_bt_synonym,	
										map_flag, 		map_ml_flag,	tc_sysid,		timestamp,		createdby,		
										createddate,	modifiedby,	modifieddate,       ecrno)--chan
		select		distinct @engg_customer_name,@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,				
					@ui_name_tmp,		@engg_task_name,	a.page_bt_synonym 'PG',	b.section_name 'SC',	a.published_bt_synonym 'CBTS',
					'Y',				'Y',				@guid,			0,					@ctxt_user,
					getdate(),			@ctxt_user,			getdate(),    @engg_ico_no --chan				
		from	de_publication_dataitem		a (nolock),
				de_hidden_view_usage		c (nolock),
				de_hidden_view				b (nolock)
		where a.customer_name		=	@engg_customer_name 
		and a.project_name		=	@engg_project_name
		and   a.process_name		=	@process_name_tmp
		and   a.component_name		=	@component_name_tmp
		and   a.activity_name		=	@activity_name_tmp
		and   a.ui_name				=   @ui_name_tmp
		and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
		and   b.section_name	 	=  isnull(@engg_tc_section,b.section_name)
		and   c.customer_name 		= 	b.customer_name
		and   c.project_name 		=   b.project_name
		and   c.process_name 		= 	b.process_name
		and	  c.component_name		=	b.component_name
		and	  c.activity_name		= 	b.activity_name
		and	  c.ui_name				=	b.ui_name
		and	  c.page_name			=	b.page_name
		and	  c.control_bt_sysnonym	=	b.control_bt_synonym
		and   c.hidden_view_bt_sysnonym	=	b.hidden_view_bt_synonym
		and   a.customer_name		=	c.customer_name
		and   a.project_name		=	c.project_name
		and   a.process_name		=	c.process_name
		and   a.component_name		=	c.component_name
		and   a.activity_name		=	c.activity_name
		and   a.ui_name				=	c.ui_name
		and	  a.page_bt_synonym		=  	c.page_name
		and	  a.published_bt_synonym=   c.hidden_view_bt_sysnonym
		and   a.published_control_name	= b.control_id
		and   a.published_view_name 	= b.view_name
		and   a.published_bt_synonym not in( select control_bt_synonym 
										   from de_task_control_map m(nolock)																	
											where m.customer_name		=	@engg_customer_name 
											and   m.project_name		=	@engg_project_name
											and   m.process_name		=	@process_name_tmp
											and   m.component_name		=	@component_name_tmp
											and   m.activity_name		=	@activity_name_tmp
											and   m.ui_name				=   @ui_name_tmp	
											and   m.page_name			= 	isnull(a.page_bt_synonym,m.page_name)
											and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
											and   m.action_name 		= 	@engg_task_name)
--		group by a.page_bt_synonym,	b.section_name,a.published_bt_synonym

		end

*/

	if @taskpattern_tmp 	in( 'Fetch','Trans','UI','Link')
	begin
	
		insert into de_task_control_map(
			customer_name,				project_name,			process_name,				component_name,			activity_name,	
			ui_name,					action_name,			page_name,					section_name,			control_bt_synonym,	
			map_flag, 					map_ml_flag,			tc_sysid,					timestamp,				createdby,		
			createddate,				modifiedby,				modifieddate,				ecrno,					control_type)--chan --TECH-75230
		select		distinct 
			@engg_customer_name,		@engg_project_name,		@process_name_tmp,			@component_name_tmp,	@activity_name_tmp,				
			@ui_name_tmp,				@engg_task_name,		a.page_bt_synonym,			a.section_bt_synonym,	control_bt_synonym,
			'Y',						'Y',					@guid,						0,						@ctxt_user,
			getdate(),					@ctxt_user,				getdate(),					@engg_ico_no,			base_ctrl_type --chan --TECH-75230
		from	de_ui_control				A (nolock),
				es_comp_ctrl_type_mst_vw	B (nolock)
		where	a.customer_name			=	@engg_customer_name 
		and		a.project_name			=	@engg_project_name
		and		a.process_name			=	@process_name_tmp
		and		a.component_name		=	@component_name_tmp
		and		a.activity_name			=	@activity_name_tmp
		and		a.ui_name				=   @ui_name_tmp
		and		a.customer_name			=	b.customer_name
		and		a.project_name			=	b.project_name
		and		a.process_name			=	b.process_name
		and		a.component_name		=	b.component_name
		and		a.control_type			=	b.ctrl_type_name
--Code Modified For BugId : PNR2.0_9131
		and		upper(b.base_ctrl_type) not in('BUTTON', 'LINK', 'GRID', 'LINE','Label', 'ListEdit','RSSlider', 'Slider','Assorted', 'Pivot', 'TreeGrid', 'ListView') --tt -- -- Modified By feroz for bug id :PNR2.0_23463 
-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061
		and		a.control_type  not in ('Filler','Filler2','Label')
-- code modified by Anuradha M ON 19/12/2005 for the Bug Id :: PNR2.0_5061
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
		and		a.page_bt_synonym 		=  isnull(@engg_tc_page,a.page_bt_synonym)
		and		a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
-- code uncommented by chanheetha N A for the call id : PNR2.0_10466
--		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
		and   a.section_bt_synonym not in  ( select section_bt_synonym
		from  de_ui_section M(nolock)
		where m.customer_name			= @engg_customer_name
		and   m.project_name			= @engg_project_name
		and   m.process_name			= @process_name_tmp
		and   m.component_name			= @component_name_tmp
		and   m.activity_name			= @activity_name_tmp
		and   m.ui_name					= @ui_name_tmp
		and	  m.section_type			= 'ListItem')

		and		a.control_bt_synonym not in ( 	select control_bt_synonym 
		from	de_task_control_map M(nolock)																	
		where	m.customer_name			=	@engg_customer_name 
		and		m.project_name			=	@engg_project_name
		and		m.process_name			=	@process_name_tmp
		and		m.component_name		=	@component_name_tmp
		and		m.activity_name			=	@activity_name_tmp
		and		m.ui_name				=   @ui_name_tmp	
		and		m.page_name				= 	isnull(a.page_bt_synonym,m.page_name)
		and		m.section_name			= 	isnull(@engg_tc_section,m.section_name)
		and		m.action_name 			= 	@engg_task_name)	
			/* Code Added by feroz for spin control feature */	
		and  a.control_bt_synonym not in(   select	y.spin_control_bt_synonym
		from 	de_action 			x (nolock),
				de_spin_control		y (nolock)
		where	x.customer_name			= @engg_customer_name
		and		x.project_name			= @engg_project_name
		and 	x.process_name			= @process_name_tmp
		and 	x.component_name		= @component_name_tmp
		and 	x.activity_name			= @activity_name_tmp	 
		and 	x.ui_name 				= @ui_name_tmp
		and 	x.page_bt_synonym		= isnull(a.page_bt_synonym,x.page_bt_synonym)	
		and 	x.task_name				= @engg_task_name
		and 	x.customer_name			= y.customer_name
		and 	x.project_name			= y.project_name
		and 	x.process_name			= y.process_name
		and 	x.component_name		= y.component_name
		and 	x.activity_name			= y.activity_name
		and 	x.ui_name 				= y.ui_name)
-- 		and 	x.page_bt_synonym		= y.page_bt_synonym)	 -- Commented by Feroz for Bug id :PNR2.0_20589
		-- Code Added by feroz for state Processing feature 
		and		a.control_bt_synonym 	<> 	'hdnrt_stcontrol'
union
		--Seperate select  for hdnrt_stcontrol as the map and map_ml flag shoud be 'N' for the first time. Code added against TECH-218 Starts
		select  distinct @engg_customer_name,	@engg_project_name,		@process_name_tmp,	@component_name_tmp, @activity_name_tmp,
						 @ui_name_tmp,			@engg_task_name,		a.page_bt_synonym,  a.section_bt_synonym,control_bt_synonym,
						'N',					'N',					@guid,				0,					 @ctxt_user,
						getdate(),				@ctxt_user,				getdate(),          @engg_ico_no,		'' --chan --TECH-75230
		from	de_ui_control    A (nolock)
		where	a.customer_name		= @engg_customer_name
		and		a.project_name		= @engg_project_name
		and		a.process_name		= @process_name_tmp
		and		a.component_name	= @component_name_tmp
		and		a.activity_name		= @activity_name_tmp
		and		a.ui_name			=   @ui_name_tmp
		and		a.page_bt_synonym	=  isnull(@engg_tc_page,a.page_bt_synonym)
		and		a.section_bt_synonym=  isnull(@engg_tc_section,a.section_bt_synonym)
		and		a.control_bt_synonym= 'hdnrt_stcontrol'  
		and		not exists (  select 'X'
		from	de_task_control_map M(nolock)
		where	m.customer_name		= @engg_customer_name
		and		m.project_name		= @engg_project_name
		and		m.process_name		= @process_name_tmp
		and		m.component_name	= @component_name_tmp
		and		m.activity_name		= @activity_name_tmp
		and		m.ui_name			=   @ui_name_tmp
		and		m.page_name			=  isnull(a.page_bt_synonym,m.page_name)
		and		m.section_name		=  isnull(@engg_tc_section,m.section_name)
		and		m.action_name		=  @engg_task_name
		and		m.control_bt_synonym= a.control_bt_synonym)
		and		not  exists  (select 'X'
		from	de_ui_state_task_mst b(nolock)
		where	b.customer_name		= @engg_customer_name
		and		b.project_name		= @engg_project_name
		and		b.process_name		= @process_name_tmp
		and		b.component_name	= @component_name_tmp
		and		b.activity_name		= @activity_name_tmp
		and		b.ui_name			=   @ui_name_tmp
		--and		b.page_bt_synonym   =  isnull(a.page_bt_synonym,b.page_bt_synonym) Code commented by Ganesh prabhu S for TECH-18495
		and		b.task_name			=  @engg_task_name)
		
		-- Code added against TECH-218 Ends

		union
		select		@engg_customer_name,	@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,				
					@ui_name_tmp,			@engg_task_name,	a.page_bt_synonym,	a.section_bt_synonym,	column_bt_synonym,
					'Y',						'Y',						@guid,			0,					@ctxt_user,
					getdate(),		@ctxt_user,	getdate(), @engg_ico_no,	base_ctrl_type --chan --TECH-75230
		from 	de_ui_grid A(nolock),
		es_comp_ctrl_type_mst_vw	B (nolock) --TECH-75230
		where	a.customer_name			=	b.customer_name
		and		a.project_name			=	b.project_name
		and		a.process_name			=	b.process_name
		and		a.component_name		=	b.component_name
		and		a.column_type			=	b.ctrl_type_name  --TECH-75230
		and		a.customer_name		=	@engg_customer_name 
		and		a.project_name		=	@engg_project_name
		and		a.process_name		=	@process_name_tmp
		and		a.component_name	=	@component_name_tmp
		and		a.activity_name		=	@activity_name_tmp
		and		a.ui_name			=   @ui_name_tmp
		and		a.page_bt_synonym 	=   isnull(@engg_tc_page,a.page_bt_synonym)
		and		a.section_bt_synonym =  isnull(@engg_tc_section,a.section_bt_synonym)	
--		code modified by Anuradha M  on 22/12/2005 for the Bug Id :: PNR2.0_5111
		and		a.column_bt_synonym not in  ( select control_bt_synonym 
		from	de_task_control_map M(nolock)																	
		where	m.customer_name		=	@engg_customer_name 
		and		m.project_name		=	@engg_project_name
		and		m.process_name		=	@process_name_tmp
		and		m.component_name	=	@component_name_tmp
		and		m.activity_name		=	@activity_name_tmp
		and		m.ui_name			=   @ui_name_tmp	
		and		m.page_name			= 	isnull(a.page_bt_synonym,m.page_name)
		and		m.section_name		= 	isnull(@engg_tc_section,m.section_name)
		and		m.action_name 		= 	@engg_task_name)			
		and		a.column_type		not in ('action','menubutton')                   --Code added by Ponmalar A for Defect ID: TECH-62151

		union--PNR2.0_10007																

		select	@engg_customer_name,@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,				
				@ui_name_tmp,		@engg_task_name,	a.page_name 'PG',	b.section_name 'SC', hidden_view_bt_sysnonym 'CBTS',
				'Y',				'Y',				@guid,			0,					@ctxt_user,
				getdate(),			@ctxt_user,			getdate(), @engg_ico_no,			'HiddenView' --chan
		from	de_hidden_view_usage	a (nolock),
				de_hidden_view			b (nolock)
		where 	a.customer_name				=	@engg_customer_name 
		and   	a.project_name				=	@engg_project_name
		and   	a.process_name				=	@process_name_tmp
		and   	a.component_name			=	@component_name_tmp
		and   	a.activity_name				=	@activity_name_tmp
		and   	a.ui_name					=   @ui_name_tmp
		and		a.action_name				=	@engg_task_name
		and   	a.customer_name 			= 	b.customer_name
		and   	a.project_name 				=   b.project_name
		and   	a.process_name 				= 	b.process_name
		and		a.component_name			=	b.component_name
		and		a.activity_name				= 	b.activity_name
		and		a.ui_name					=	b.ui_name
		and		a.page_name					=	b.page_name
		and		a.control_bt_sysnonym		=	b.control_bt_synonym
		and		a.hidden_view_bt_sysnonym	=	b.hidden_view_bt_synonym
		--Code Modified for bugId :PNR2.0_11358
		and     b.page_name 				=  isnull(@engg_tc_page,b.page_name)
		and   	b.section_name 				=  isnull(@engg_tc_section,b.section_name)	
		and   b.section_name not in  ( select section_bt_synonym
		from  de_ui_section M(nolock)
		where m.customer_name			= @engg_customer_name
		and   m.project_name			= @engg_project_name
		and   m.process_name			= @process_name_tmp
		and   m.component_name			= @component_name_tmp
		and   m.activity_name			= @activity_name_tmp
		and   m.ui_name					= @ui_name_tmp
		and	  m.section_type			= 'ListItem')

		and   	a.hidden_view_bt_sysnonym 	not in(
		select control_bt_synonym 
		from 	de_task_control_map m(nolock)																	
		where 	m.customer_name				= @engg_customer_name 
		and   	m.project_name				= @engg_project_name
		and   	m.process_name				= @process_name_tmp
		and   	m.component_name			= @component_name_tmp
		and   	m.activity_name				= @activity_name_tmp
		and   	m.ui_name					= @ui_name_tmp	
		--Code Modified for bugId :PNR2.0_11358
		and   	m.page_name					= isnull(@engg_tc_page,m.page_name)
		and   	m.section_name				= isnull(@engg_tc_section,m.section_name)
		and   	m.action_name 				= @engg_task_name)
		group 	by a.page_name,	b.section_name ,	a.hidden_view_bt_sysnonym

		-- Added by feroz to show static Controls
		insert into de_task_control_map(
			customer_name,				project_name,				process_name,			component_name,				activity_name,	
			ui_name,					action_name,				page_name,				section_name,				control_bt_synonym,	
			map_flag, 					map_ml_flag,				tc_sysid,				timestamp,					createdby,		
			createddate,				modifiedby,					modifieddate,			ecrno,						control_type)--chan --TECH-75230
		select	distinct 
			@engg_customer_name,		@engg_project_name,			@process_name_tmp,		@component_name_tmp,		@activity_name_tmp,				
			@ui_name_tmp,				@engg_task_name,			a.page_bt_synonym,		a.section_bt_synonym,		control_bt_synonym,
			'Y',						'Y',						@guid,					0,							@ctxt_user,
			getdate(),					@ctxt_user,					getdate(),				@engg_ico_no,				base_ctrl_type --chan --TECH-75230
		from	de_ui_control				A (nolock),
				es_comp_stat_ctrl_type_mst	B (nolock)
		where 	a.customer_name		=	@engg_customer_name 
		and   	a.project_name		=	@engg_project_name
		and   	a.process_name		=	@process_name_tmp
		and   	a.component_name	=	@component_name_tmp
		and   	a.activity_name		=	@activity_name_tmp
		and   	a.ui_name			=   @ui_name_tmp
		and	  	a.customer_name		= 	b.customer_name
		and		a.project_name		= 	b.project_name
		and		a.process_name		= 	b.process_name
		and		a.component_name	=	b.component_name
		and		a.control_type		=	b.ctrl_type_name

	--TECH-73996
	IF EXISTS
	(SELECT 'X'
	FROM	es_quick_code_met (NOLOCK)
	WHERE	CustomerName	=	@engg_customer_name
	AND		ProjectName		=	@engg_project_name
	AND		ParameterCode	=	'DefaultinghiddenView'
	AND		ParameterText	=	'AUTO_MAP_HDNVIEW_COMBO'
	AND		ParameterValue	=	'Y')
	BEGIN
	IF NOT EXISTS
	(SELECT 'X'
	 FROM	de_task_service_method_vw (NOLOCK)
	 WHERE	customer_name		=	@engg_customer_name 
	 AND	project_name		=	@engg_project_name
	 AND	process_name		=	@process_name_tmp
	 AND	component_name		=	@component_name_tmp
	 AND	activity_name		=	@activity_name_tmp
	 AND	ui_name				=   @ui_name_tmp	
	 AND	task_name 			= 	@engg_task_name)
	 BEGIN
	INSERT INTO de_task_control_map(
			customer_name,			project_name,			process_name,			component_name,			activity_name,			ui_name,		
			action_name,			page_name,				section_name,			control_bt_synonym,		map_flag, 				map_ml_flag,	
			tc_sysid,				timestamp,				createdby,				createddate,			modifiedby,				modifieddate,
			ecrno,					control_type)--chan --TECH-75230
		SELECT distinct 
			@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,	@activity_name_tmp,		@ui_name_tmp, 
			@engg_task_name,		a.page_name 'PG',		a.section_name 'SC',	hidden_view_bt_synonym 'CBTS','Y',				'Y', 
			@guid,					0,						@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
			@engg_ico_no,			'HiddenView' --chan
		FROM	de_hidden_view			A (NOLOCK)	
		JOIN	de_ui_control   b (NOLOCK)
		ON		a.customer_name				= b.customer_name
		AND		a.project_name				= b.project_name
		AND		a.process_name				= b.process_name
		AND		a.component_name			= b.component_name
		AND		a.activity_name				= b.activity_name
		AND		a.ui_name					= b.ui_name
		AND		a.page_name					= b.page_bt_synonym
		AND		a.section_name				= b.section_bt_synonym
		AND		a.control_bt_synonym		= b.control_bt_synonym
		JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
		ON		b.customer_name				= c.customer_name
		AND		b.project_name				= c.project_name
		AND		b.process_name				= c.process_name
		AND		b.component_name			= c.component_name
		AND		b.control_type				= c.ctrl_type_name
		WHERE 	a.customer_name		=	@engg_customer_name 
		AND   	a.project_name		=	@engg_project_name
		AND   	a.process_name		=	@process_name_tmp
		AND   	a.component_name	=	@component_name_tmp
		AND   	a.activity_name		=	@activity_name_tmp
		AND   	a.ui_name			=   @ui_name_tmp
		AND    a.page_name 			=  ISNULL(@engg_tc_page,a.page_name)
		AND    a.section_name		=  ISNULL(@engg_tc_section,a.section_name)
		AND   a.hidden_view_bt_synonym NOT IN ( select control_bt_synonym 
		FROM de_task_control_map M(NOLOCK)																	
		WHERE m.customer_name		=	@engg_customer_name 
		AND   m.project_name		=	@engg_project_name
		AND   m.process_name		=	@process_name_tmp
		AND   m.component_name		=	@component_name_tmp
		AND   m.activity_name		=	@activity_name_tmp
		AND   m.ui_name			    =   @ui_name_tmp	
		AND   m.page_name		    = 	ISNULL(a.page_name,m.page_name)
		AND   m.section_name		= 	ISNULL(@engg_tc_section,m.section_name)
		AND   m.action_name 		= 	@engg_task_name)
		AND     c.base_ctrl_type	= 'Combo'
		UNION
		SELECT distinct 
			@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,	@activity_name_tmp,		@ui_name_tmp, 
			@engg_task_name,		a.page_name 'PG',		a.section_name 'SC',	hidden_view_bt_synonym 'CBTS','Y',				'Y', 
			@guid,					0,						@ctxt_user,				getdate(),				@ctxt_user,				getdate(),
			@engg_ico_no,			'HiddenView' --chan	--TECH-75230
		FROM	de_hidden_view			A (NOLOCK)	
		JOIN	de_ui_grid   b (NOLOCK)
		ON		a.customer_name				= b.customer_name
		AND		a.project_name				= b.project_name
		AND		a.process_name				= b.process_name
		AND		a.component_name			= b.component_name
		AND		a.activity_name				= b.activity_name
		AND		a.ui_name					= b.ui_name
		AND		a.page_name					= b.page_bt_synonym
		AND		a.section_name				= b.section_bt_synonym
		AND		a.control_bt_synonym		= b.column_bt_synonym
		JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
		ON		b.customer_name				= c.customer_name
		AND		b.project_name				= c.project_name
		AND		b.process_name				= c.process_name
		AND		b.component_name			= c.component_name
		AND		b.column_type				= c.ctrl_type_name
		WHERE 	a.customer_name		=	@engg_customer_name 
		AND   	a.project_name		=	@engg_project_name
		AND   	a.process_name		=	@process_name_tmp
		AND   	a.component_name	=	@component_name_tmp
		AND   	a.activity_name		=	@activity_name_tmp
		AND   	a.ui_name			=   @ui_name_tmp
		AND    a.page_name 			=  ISNULL(@engg_tc_page,a.page_name)
		AND    a.section_name		=  ISNULL(@engg_tc_section,a.section_name)
		AND   a.hidden_view_bt_synonym NOT IN ( select control_bt_synonym 
		FROM de_task_control_map M(NOLOCK)																	
		WHERE m.customer_name		=	@engg_customer_name 
		AND   m.project_name		=	@engg_project_name
		AND   m.process_name		=	@process_name_tmp
		AND   m.component_name		=	@component_name_tmp
		AND   m.activity_name		=	@activity_name_tmp
		AND   m.ui_name			    =   @ui_name_tmp	
		AND   m.page_name		    = 	ISNULL(a.page_name,m.page_name)
		AND   m.section_name		= 	ISNULL(@engg_tc_section,m.section_name)
		AND   m.action_name 		= 	@engg_task_name)
		AND     c.base_ctrl_type	= 'Combo'

	END
	END
	--TECH-73996

 	end

	
-- Added for Rule Builder Starts Defect ID: TECH-35368

	Declare @RBTaskName			engg_name,
			@RBPageName			engg_description,
			@RBFlowBR			engg_name,
			@PrimaryControl		engg_name

	IF EXISTS ( SELECT 'X'
	FROM	de_Action (nolock)
	WHERE	Customer_name		= @engg_customer_name
	AND		Project_name		= @engg_project_name
	AND		Process_name		= @process_name_tmp
	AND		Component_name		= @component_name_tmp
	AND		Activity_name		= @activity_name_tmp
	AND		ui_name				= @ui_name_tmp
	AND		task_descr			= 'UI Task to Load MultiSelect Combo for Rule Builder'
	)
	BEGIN
		SELECT	@RBTaskName			= ISNULL(task_name,''),
				@RBPageName			= page_bt_synonym,
				@PrimaryControl		= primary_control_bts
		FROM	de_Action (nolock)
		WHERE	Customer_name		= @engg_customer_name
		AND		Project_name		= @engg_project_name
		AND		Process_name		= @process_name_tmp
		AND		Component_name		= @component_name_tmp
		AND		Activity_name		= @activity_name_tmp
		AND		ui_name				= @ui_name_tmp
		AND		task_descr			= 'UI Task to Load MultiSelect Combo for Rule Builder'

		IF @engg_task_name			= @RBTaskName
		BEGIN
				EXEC re_default_flowbr		
								@CTxt_Language		= @CTxt_Language,
								@CTxt_Service		= @CTxt_Service,
								@CTxt_OUInstance	= @CTxt_OUInstance,
								@CTxt_User			= @CTxt_User,
								@customer_name		= @engg_customer_name,
								@project_name		= @engg_project_name,
								@process_name		= @process_name_tmp,
								@component_name		= @component_name_tmp,
								@activity_name		= @activity_name_tmp,
								@ui_name			= @ui_name_tmp,
								@page_name			= @RBPageName,
								@task_name			= @RBTaskName,
								@task_pattern		= 'UI',
								@task_sysid			= '' ,
								@work_request       = 'BASE'

			SELECT	Top 1 @RBFlowBR		= flowbr_name
			FROM	re_flowbr (nolock)
			WHERE	Customer_name		= @engg_customer_name
			AND		Project_name		= @engg_project_name
			AND		Process_name		= @process_name_tmp
			AND		Component_name		= @component_name_tmp
			AND		Activity_name		= @activity_name_tmp
			AND		ui_name				= @ui_name_tmp
			AND		page_bt_synonym		= @RBPageName		
			AND		task_name			= @RBTaskName

			IF NOT EXISTS (SELECT 'X'
			FROM re_flowbr_combo (nolock)
			WHERE	Customer_name		= @engg_customer_name
			AND		Project_name		= @engg_project_name
			AND		Process_name		= @process_name_tmp
			AND		Component_name		= @component_name_tmp
			AND		Activity_name		= @activity_name_tmp
			AND		ui_name				= @ui_name_tmp
			AND		page_bt_synonym		= @RBPageName		
			AND		task_name			= @RBTaskName
			AND		flowbr_name			= @RBFlowBR)
			BEGIN
				INSERT INTO re_flowbr_combo
						(customer_name,			project_name,			process_name,			component_name,
						activity_name,			ui_name,				page_bt_synonym,		task_name,
						flowbr_name,			combo_bt_synonym,		combo_sysid,			flowbr_sysid,
						timestamp,				createdby,				createddate,			modifiedby,
						modifieddate,			combo_page_name,		clear_tree_before_population,
						rcnno)
				SELECT		
						@engg_customer_name,	@engg_project_name,		@process_name_tmp,		@component_name_tmp,
						@activity_name_tmp,		@ui_name_tmp,			@RBPageName,			@RBTaskName,
						@RBFlowBR,				@PrimaryControl,		newid(),				newid(),
						1,						@ctxt_user,				Getdate(),				@ctxt_user,
						Getdate(),				@RBPageName,			0,					
						@engg_ico_no
			END

			Delete from de_task_control_map 
			WHERE	Customer_name		= @engg_customer_name
			AND		Project_name		= @engg_project_name
			AND		Process_name		= @process_name_tmp
			AND		Component_name		= @component_name_tmp
			AND		Activity_name		= @activity_name_tmp
			AND		ui_name				= @ui_name_tmp
			AND		action_name			= @engg_task_name

			insert into de_task_control_map(
				customer_name,				project_name,			process_name,				component_name,			activity_name,	
				ui_name,					action_name,			page_name,					section_name,			control_bt_synonym,	
				map_flag, 					map_ml_flag,			tc_sysid,					timestamp,				createdby,		
				createddate,				modifiedby,				modifieddate,				ecrno,					control_type) --chan --TECH-75230
			select		distinct 
				@engg_customer_name,		@engg_project_name,		@process_name_tmp,			@component_name_tmp,	@activity_name_tmp,				
				@ui_name_tmp,				@engg_task_name,		a.page_bt_synonym,			a.section_bt_synonym,	control_bt_synonym,
				'Y',						'Y',					@guid,						0,						@ctxt_user,
				getdate(),					@ctxt_user,				getdate(),					@engg_ico_no,			base_ctrl_type --chan --TECH-75230
			from	de_ui_control				A (nolock),
					es_comp_ctrl_type_mst_vw	B (nolock)
			where	a.customer_name			=	@engg_customer_name 
			and		a.project_name			=	@engg_project_name
			and		a.process_name			=	@process_name_tmp
			and		a.component_name		=	@component_name_tmp
			and		a.activity_name			=	@activity_name_tmp
			and		a.ui_name				=   @ui_name_tmp
			and		a.customer_name			=	b.customer_name
			and		a.project_name			=	b.project_name
			and		a.process_name			=	b.process_name
			and		a.component_name		=	b.component_name
			and		a.control_type			=	b.ctrl_type_name
			and		upper(b.base_ctrl_type) not in('BUTTON', 'LINK', 'GRID', 'LINE','Label', 'ListEdit','RSSlider', 'Slider','Assorted', 'Pivot', 'TreeGrid', 'ListView') --tt -- -- Modified By feroz for bug id :PNR2.0_23463 
			and		a.control_type  not in ('Filler','Filler2','Label')
			and		a.page_bt_synonym 		=  isnull(@engg_tc_page,a.page_bt_synonym)
			and		a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
			and		a.control_bt_synonym not in ( 	select control_bt_synonym 
			from	de_task_control_map M(nolock)																	
			where	m.customer_name			=	@engg_customer_name 
			and		m.project_name			=	@engg_project_name
			and		m.process_name			=	@process_name_tmp
			and		m.component_name		=	@component_name_tmp
			and		m.activity_name			=	@activity_name_tmp
			and		m.ui_name				=   @ui_name_tmp	
			and		m.page_name				= 	isnull(a.page_bt_synonym,m.page_name)
			and		m.section_name			= 	isnull(@engg_tc_section,m.section_name)
			and		m.action_name 			= 	@engg_task_name)	
			and		a.control_bt_synonym 	<> 	'hdnrt_stcontrol'
			-- Commented for the defect id TECH-35248 Starts
			--UNION
			--select		@engg_customer_name,	@engg_project_name,	@process_name_tmp,	@component_name_tmp,	@activity_name_tmp,				
			--			@ui_name_tmp,			@engg_task_name,	grd.page_bt_synonym,	grd.section_bt_synonym,	column_bt_synonym,
			--			'Y',						'Y',						@guid,			0,					@ctxt_user,
			--			getdate(),		@ctxt_user,	getdate(), @engg_ico_no --chan
			--from 	de_ui_grid grd (nolock),
			--		de_ui_control ctl (nolock),
			--		es_comp_ctrl_type_mst typ (nolock)
			--where	grd.customer_name		=	@engg_customer_name 
			--and		grd.project_name		=	@engg_project_name
			--and		grd.process_name		=	@process_name_tmp
			--and		grd.component_name		=	@component_name_tmp
			--and		grd.activity_name		=	@activity_name_tmp
			--and		grd.ui_name				=   @ui_name_tmp
			--and		grd.page_bt_synonym 	=   isnull(@engg_tc_page,grd.page_bt_synonym)
			--and		grd.section_bt_synonym	=  isnull(@engg_tc_section,grd.section_bt_synonym)	

			--and		grd.customer_name		= ctl.customer_name
			--and		grd.project_name		= ctl.project_name
			--and		grd.process_name		= ctl.process_name
			--and		grd.component_name		= ctl.component_name
			--and		grd.activity_name		= ctl.activity_name
			--and		grd.ui_name				= ctl.ui_name
			--and		grd.page_bt_synonym		= ctl.page_bt_synonym
			--and		grd.section_bt_synonym	= ctl.section_bt_synonym
			--and		grd.control_bt_synonym	= ctl.control_bt_synonym

			--and		ctl.customer_name		= typ.customer_name
			--and		ctl.project_name		= typ.project_name
			--and		ctl.process_name		= typ.process_name
			--and		ctl.component_name		= typ.component_name
			--and		ctl.control_type		= typ.ctrl_type_name
			--and		typ.base_ctrl_type		= 'ListView'

			--and		grd.column_bt_synonym not in  ( select control_bt_synonym 
			--from	de_task_control_map M(nolock)																	
			--where	m.customer_name		=	@engg_customer_name 
			--and		m.project_name		=	@engg_project_name
			--and		m.process_name		=	@process_name_tmp
			--and		m.component_name	=	@component_name_tmp
			--and		m.activity_name		=	@activity_name_tmp
			--and		m.ui_name			=   @ui_name_tmp	
			--and		m.page_name			= 	isnull(grd.page_bt_synonym,m.page_name)
			--and		m.section_name		= 	isnull(@engg_tc_section,m.section_name)
			--and		m.action_name 		= 	@engg_task_name)
			-- Commented for the defect id TECH-35248 Ends	
		END
		ELSE
		BEGIN
			Delete from de_task_control_map 
			WHERE	Customer_name		= @engg_customer_name
			AND		Project_name		= @engg_project_name
			AND		Process_name		= @process_name_tmp
			AND		Component_name		= @component_name_tmp
			AND		Activity_name		= @activity_name_tmp
			AND		ui_name				= @ui_name_tmp
			AND		action_name			= @engg_task_name
			AND		(control_bt_synonym  LIKE '%_MS' OR
						control_bt_synonym  LIKE '%_MS_Col%' OR
						control_bt_synonym  LIKE '%_ENTITY' )
				
			
		END	
	END

-- Added for Rule Builder Ends Defect ID: TECH-35368		

	--TECH-75230
		UPDATE a
		SET	control_type = mst.base_ctrl_type
		FROM de_task_control_map a(NOLOCK)
		JOIN de_ui_control ctrl (NOLOCK)	
		ON a.customer_name			=  ctrl.customer_name
		AND a.project_name			=  ctrl.project_name
		AND a.process_name			=  ctrl.process_name
		AND a.component_name		=  ctrl.component_name
		AND a.activity_name			=  ctrl.activity_name
		AND a.ui_name				=  ctrl.ui_name
		AND a.page_name				=  ctrl.page_bt_synonym
		AND a.section_name			=  ctrl.section_bt_synonym
		AND a.control_bt_synonym	=  ctrl.control_bt_synonym
		JOIN es_comp_ctrl_type_mst mst (NOLOCK)
		ON	ctrl.customer_name	= mst.customer_name
		AND ctrl.project_name	= mst.project_name
		AND ctrl.process_name	= mst.process_name
		AND ctrl.component_name = mst.component_name
		AND ctrl.control_type	= mst.ctrl_type_name 
		WHERE a.customer_name	= @engg_customer_name
		AND a.project_name		= @engg_project_name
		AND a.process_name		= @process_name_tmp
		AND a.component_name	= @component_name_tmp
		AND a.activity_name		= @activity_name_tmp
		AND a.ui_name			= @ui_name_tmp
	
		UPDATE a
		SET	control_type = mst.base_ctrl_type
		FROM de_task_control_map a(NOLOCK)
		JOIN de_ui_grid grd (NOLOCK)	
		ON a.customer_name			=  grd.customer_name
		AND a.project_name			=  grd.project_name
		AND a.process_name			=  grd.process_name
		AND a.component_name		=  grd.component_name
		AND a.activity_name			=  grd.activity_name
		AND a.ui_name				=  grd.ui_name
		AND a.page_name				=  grd.page_bt_synonym
		AND a.section_name			=  grd.section_bt_synonym
		AND a.control_bt_synonym	=  grd.column_bt_synonym
		JOIN es_comp_ctrl_type_mst mst (NOLOCK)
		ON	grd.customer_name	= mst.customer_name
		AND grd.project_name	= mst.project_name
		AND grd.process_name	= mst.process_name
		AND grd.component_name	= mst.component_name
		AND grd.column_type		= mst.ctrl_type_name 
		WHERE a.customer_name	= @engg_customer_name
		AND a.project_name		= @engg_project_name
		AND a.process_name		= @process_name_tmp
		AND a.component_name	= @component_name_tmp
		AND a.activity_name		= @activity_name_tmp
		AND a.ui_name			= @ui_name_tmp

		UPDATE	a
		SET		control_type = 'HiddenView'
		FROM de_task_control_map a(NOLOCK)
		JOIN de_hidden_view hdn (NOLOCK) 
		ON a.customer_name			=	hdn.customer_name
		AND a.project_name			=	hdn.project_name
		AND a.process_name			=	hdn.process_name
		AND a.component_name		=   hdn.component_name
		AND a.activity_name			=   hdn.activity_name
		AND a.ui_name				=	hdn.ui_name
		AND a.page_name				=	hdn.page_name
		AND a.section_name			=	hdn.section_name
		AND a.control_bt_synonym	=	hdn.hidden_view_bt_synonym 
		WHERE a.customer_name	= @engg_customer_name
		AND a.project_name		= @engg_project_name
		AND a.process_name		= @process_name_tmp
		AND a.component_name	= @component_name_tmp
		AND a.activity_name		= @activity_name_tmp
		AND a.ui_name			= @ui_name_tmp
	
	IF EXISTS(
	SELECT 'x'
	FROM	de_listedit_column (NOLOCK)
	WHERE customer_name		=	@engg_customer_name
	AND	  project_name 		=	@engg_project_name
	AND	  process_name 		=	@process_name_tmp
	AND	  component_name 	=	@component_name_tmp
	AND	  activity_name		=	@activity_name_tmp
	AND	  ui_name			=	@ui_name_tmp
	)
	BEGIN
		UPDATE	de_task_control_map
		SET		control_type	=	'ListEdit'
		FROM	de_task_control_map a
		JOIN	de_listedit_column	b
		ON		a.customer_name	=	b.customer_name
		AND		a.project_name	=	b.project_name
		AND		a.process_name	=	b.process_name
		AND		a.component_name=	b.component_name
		AND		a.activity_name	=	b.activity_name
		AND		a.ui_name		=	b.ui_name
		AND		a.control_bt_synonym	=	b.listedit_column_synonym
		WHERE	a.customer_name		=	@engg_customer_name
		AND	    a.project_name 		=	@engg_project_name
		AND	    a.process_name 		=	@process_name_tmp
		AND	    a.component_name 	=	@component_name_tmp
		AND	    a.activity_name		=	@activity_name_tmp
		AND	    a.ui_name			=	@ui_name_tmp
	END

		UPDATE de_task_control_map
		SET control_type = 'MultiselectCombo'
		FROM	de_task_control_map a
		JOIN	de_ui_grid b
		ON		a.customer_name			=	b.customer_name
		AND		a.project_name			=	b.project_name
		AND		a.process_name			=	b.process_name
		AND		a.component_name		=	b.component_name
		AND		a.activity_name			=	b.activity_name
		AND		a.ui_name				=	b.ui_name
		AND		a.control_bt_synonym	=	b.column_bt_synonym
		JOIN	de_ui_control c
		ON		b.customer_name			=	c.customer_name
		AND		b.project_name			=	c.project_name
		AND		b.process_name			=	c.process_name
		AND		b.component_name		=	c.component_name
		AND		b.activity_name			=	c.activity_name
		AND		b.ui_name				=	c.ui_name
		AND		b.page_bt_synonym		=	c.page_bt_synonym
		AND		b.section_bt_synonym	=	c.section_bt_synonym
		AND		b.control_bt_synonym	=	c.control_bt_synonym
		JOIN	es_comp_ctrl_type_mst d
		ON		c.customer_name			=	d.customer_name
		AND		c.project_name			=	d.project_name
		AND		c.process_name			=	d.process_name
		AND		c.component_name		=	d.component_name
		AND		c.control_type			=	d.ctrl_type_name
		WHERE	a.customer_name		=	@engg_customer_name
		AND	    a.project_name 		=	@engg_project_name
		AND	    a.process_name 		=	@process_name_tmp
		AND	    a.component_name 	=	@component_name_tmp
		AND	    a.activity_name		=	@activity_name_tmp
		AND	    a.ui_name			=	@ui_name_tmp
		AND     d.base_ctrl_type	= 'ListView'

	--TECH-75230

	select 	case map_flag
			when 'Y' then 1
			else 0 end					'engg_map_flag',
			case map_ml_flag
			when 'Y' then 1
			else 0 end					'engg_map_all' ,
			control_bt_synonym			'engg_tc_ctrl_bts' ,
			m.page_name					'engg_tc_page_name' ,
			m.section_name				'engg_tc_sec_name' ,
			m.action_name				'engg_tc_task_name',
			CASE [Load] WHEN 'Y' THEN 1 ELSE 0 END 'engg_tc_load', --TECH-75230
			m.control_type				'engg_tc_ctrl_type'	--TECH-75230
	from	de_task_control_map M(nolock)																	
	where	m.customer_name		=	@engg_customer_name 
	and		m.project_name		=	@engg_project_name
	and		m.process_name		=	@process_name_tmp
	and		m.component_name	=	@component_name_tmp
	and		m.activity_name		=	@activity_name_tmp
	and		m.ui_name			=   @ui_name_tmp	
-- code uncommented by Anuradha M on 28-Aug-2006 for the Bug ID :: PNR2.0_10065  -- start
 	and		m.page_name			= 	isnull(@engg_tc_page,m.page_name)
 	and		m.section_name		= 	isnull(@engg_tc_section,m.section_name)
-- code uncommented by Anuradha M on 28-Aug-2006 for the Bug ID :: PNR2.0_10065  -- End
	and		m.action_name 		= 	@engg_task_name
	and		m.control_bt_synonym   not in (select hidden_view_bt_synonym--PNR2.0_10007
	from	de_hidden_view a(nolock)
	where m.customer_name		=	a.customer_name 
	and   m.project_name		=	a.project_name
	and   m.process_name		=	a.process_name
	and   m.component_name		=	a.component_name
	and   m.activity_name		=	a.activity_name
	and   m.ui_name				=   a.ui_name
	and   m.page_name			=   a.page_name
	and   m.section_name		=   a.section_name
	and   isnull(a.HIDDEN_VIEW_SOURCE,'')<>'')

	set nocount off
end
GO
IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_design_sp_defctltc' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON de_design_sp_defctltc	TO PUBLIC
END
GO
