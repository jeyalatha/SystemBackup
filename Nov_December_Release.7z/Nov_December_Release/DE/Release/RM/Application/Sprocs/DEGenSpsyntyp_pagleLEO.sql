
/******************************************************************************/
/* Procedure					: DEGenSpsyntyp_pagleLEO								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* modified by  : Veena U                                      					*/  
/* date         : Nov 2 2015                                      				*/  
/* BugId        : PLF2.0_15434                                          		*/  
/********************************************************************************/ 
/* modified by  : Pavithra V                                      					*/  
/* date         : NOV-20-2019                                      				*/  
/* BugId        : TECH-39352                                          		*/  
/********************************************************************************/  
/* Modified by : Hareesh K/Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809 */ 
/*************************************************************************************************/
/* Modified by : Ganesh Prabhu S               Date: 14-Nov-2022  Defect ID : TECH-74248 		  */ 
/*************************************************************************************************/
Create Procedure DEGenSpsyntyp_pagleLEO
	@ctxt_ouinstance          	ctxt_ouinstance, --Input 
	@ctxt_user                	ctxt_user, --Input 
	@ctxt_language            	ctxt_language, --Input 
	@ctxt_service             	ctxt_service, --Input 
	@de_design_actname        	engg_description, --Input 
	@de_design_syntype        	engg_name, --Input 
	@engg_act_descr           	engg_description, --Input 
	@engg_component           	engg_description, --Input 
	@engg_customer_name       	engg_name, --Input 
	@engg_ico_no              	engg_name, --Input 
	@engg_page_descr			engg_name,
	@engg_project_name        	engg_name, --Input 
	@engg_proj_proc_descr     	engg_description, --Input 
	@engg_ui_descr            	engg_description, --Input 
	@m_errorid                	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	--declaration of temporary variables


	--temporary and formal parameters mapping

	Set @ctxt_user                 = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service              = ltrim(rtrim(@ctxt_service))
	Set @de_design_actname         = ltrim(rtrim(@de_design_actname))
	Set @de_design_syntype         = ltrim(rtrim(@de_design_syntype))
	Set @engg_act_descr            = ltrim(rtrim(@engg_act_descr))
	Set @engg_component            = ltrim(rtrim(@engg_component))
	Set @engg_customer_name        = ltrim(rtrim(@engg_customer_name))
	Set @engg_ico_no               = ltrim(rtrim(@engg_ico_no))
	Set @engg_project_name         = ltrim(rtrim(@engg_project_name))
	Set @engg_proj_proc_descr      = ltrim(rtrim(@engg_proj_proc_descr))
	Set @engg_ui_descr             = ltrim(rtrim(@engg_ui_descr))

	--null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @de_design_actname = '~#~' 
		Select @de_design_actname = null  

	IF @de_design_syntype = '~#~' 
		Select @de_design_syntype = null  

	IF @engg_act_descr = '~#~' 
		Select @engg_act_descr = null  

	IF @engg_component = '~#~' 
		Select @engg_component = null  

	IF @engg_customer_name = '~#~' 
		Select @engg_customer_name = null  

	IF @engg_ico_no = '~#~' 
		Select @engg_ico_no = null  

	IF @engg_project_name = '~#~' 
		Select @engg_project_name = null  

	IF @engg_proj_proc_descr = '~#~' 
		Select @engg_proj_proc_descr = null  

	IF @engg_ui_descr = '~#~' 
		Select @engg_ui_descr = null  
		
	declare @tmp_proc		engg_name,
			@tmp_comp		engg_name,
			@tmp_act		engg_name,
			@tmp_ui			engg_name,
			@tmp_page		engg_name,
			@tmp_tsk		engg_name
						
	select 	@tmp_proc		= process_name 
	from 	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_descr	= @engg_proj_proc_descr
		
	select 	@tmp_comp		= component_name 
	from 	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @tmp_proc
	and		component_descr	= @engg_component


	select 	top 1 @tmp_act	= activity_name
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @tmp_proc
	and		component_name	= @tmp_comp
	and		activity_descr	= @engg_act_descr
	
	select 	top 1 @tmp_ui	= ui_name
	from	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @tmp_proc
	and		component_name	= @tmp_comp
	and 	activity_name	= @tmp_act
	and		ui_descr		= @engg_ui_descr
	

	if	@de_design_syntype	= 'Control'
	Begin
			IF exists (	Select	'x'
					from	de_ui_control	ctrl(nolock),
							es_comp_ctrl_type_mst	ctype(nolock)
					where 	ctrl.customer_name		= ctype.customer_name
					and		ctrl.project_name		= ctype.project_name
					and		ctrl.process_name		= ctype.process_name
					and		ctrl.component_name		= ctype.component_name
					and		ctrl.control_type		= ctype.ctrl_type_name
					and		ctrl.customer_name		= @engg_customer_name
					and		ctrl.project_name		= @engg_project_name
					and		ctrl.process_name		= @tmp_proc
					and		ctrl.component_name		= @tmp_comp
					and 	activity_name			= @tmp_act
					and		ui_name					= @tmp_ui
					--and		base_ctrl_type			<>'Grid'
					--CODE ADDED AGAINST THE DEFECT ID : TECH-39352 
					and		base_ctrl_type			not in ('Grid','Label')
					and     control_type            <> 'Label'
					--CODE ADDED AGAINST THE DEFECT ID : TECH-39352 
					and		visisble_flag			= 'Y'
					and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection'))
		Begin
			Select	distinct
					page_bt_synonym		'de_design_page_name_list',
					control_bt_synonym	'de_design_syn_name_list'
			from	de_ui_control	ctrl(nolock),
					es_comp_ctrl_type_mst	ctype(nolock)
			where 	ctrl.customer_name		= ctype.customer_name
			and		ctrl.project_name		= ctype.project_name
			and		ctrl.process_name		= ctype.process_name
			and		ctrl.component_name		= ctype.component_name
			and		ctrl.control_type		= ctype.ctrl_type_name
			and		ctrl.customer_name		= @engg_customer_name
			and		ctrl.project_name		= @engg_project_name
			and		ctrl.process_name		= @tmp_proc
			and		ctrl.component_name		= @tmp_comp
			and 	activity_name			= @tmp_act
			and		ui_name					= @tmp_ui
			--and		base_ctrl_type			<>'Grid'
			--CODE ADDED AGAINST THE DEFECT ID : TECH-39352 
			and		base_ctrl_type			not in ('Grid','Label')
			and     control_type            <> 'Label'
			--CODE ADDED AGAINST THE DEFECT ID : TECH-39352 
			and		visisble_flag			= 'Y'
			and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection')
		End
		Else
		Begin
			Select	''		'de_design_page_name_list',
					''		'de_design_syn_name_list'
		End
	End
	if	@de_design_syntype	= 'Page'
	Begin
		Select	distinct
				page_bt_synonym		'de_design_page_name_list',
				page_bt_synonym		'de_design_syn_name_list'
		from	de_ui_page	(nolock)
		where 	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and 	activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
	End
		if	@de_design_syntype	= 'Section'
	Begin
		Select	distinct
				page_bt_synonym		'de_design_page_name_list',
				section_bt_synonym	'de_design_syn_name_list'
		from	de_ui_section	(nolock)
		where 	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and 	activity_name		= @tmp_act
		and		ui_name				= @tmp_ui
		and		visisble_flag		= 'Y'
		and		section_bt_synonym	not in ('PrjhdnSection','hdnrt_stsection','[tabcontrol]')-- TECH-74248 11537
	End
		if	@de_design_syntype	in ('Column','Cell')
	Begin
		
	
		If exists (	Select	distinct 'x'
					from	de_ui_grid	ctrl(nolock),
							es_comp_ctrl_type_mst	ctype(nolock)
					where 	ctrl.customer_name		= ctype.customer_name
					and		ctrl.project_name		= ctype.project_name
					and		ctrl.process_name		= ctype.process_name
					and		ctrl.component_name		= ctype.component_name
					and		ctrl.column_type		= ctype.ctrl_type_name
					and		ctrl.customer_name		= @engg_customer_name
					and		ctrl.project_name		= @engg_project_name
					and		ctrl.process_name		= @tmp_proc
					and		ctrl.component_name		= @tmp_comp
					and 	activity_name			= @tmp_act
					and		ui_name					= @tmp_ui
					and		visisble_flag			= 'Y'
					and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection'))
		Begin
			Select	distinct
					page_bt_synonym		'de_design_page_name_list',
					column_bt_synonym	'de_design_syn_name_list'
			from	de_ui_grid	ctrl(nolock),
					es_comp_ctrl_type_mst	ctype(nolock)
			where 	ctrl.customer_name		= ctype.customer_name
			and		ctrl.project_name		= ctype.project_name
			and		ctrl.process_name		= ctype.process_name
			and		ctrl.component_name		= ctype.component_name
			and		ctrl.column_type		= ctype.ctrl_type_name
			and		ctrl.customer_name		= @engg_customer_name
			and		ctrl.project_name		= @engg_project_name
			and		ctrl.process_name		= @tmp_proc
			and		ctrl.component_name		= @tmp_comp
			and 	activity_name			= @tmp_act
			and		ui_name					= @tmp_ui
			and		visisble_flag			= 'Y'
			and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection')
		End
		Else
		Begin
			Select	''		'de_design_page_name_list',
					''		'de_design_syn_name_list'
		End
	End
	
	/* 
	--OutputList
		Select
		null 'de_design_page_name_list', 
		null 'de_design_syn_name_list', 
	*/
	
Set nocount off

End




