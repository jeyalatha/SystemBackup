IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_publ_sp_publico' AND TYPE = 'P')
BEGIN
	DROP PROC de_publ_sp_publico
END
GO
/*      V E R S I O N      :  PNR2.0_1403    */
/*      Released By        :  Development Team*/
/*      Release Comments   :  For DotNet Migration, Naming convention has been changed  for some of the out parameters by using Stub Generator.Comments will not be there for this Request ID.    */
/* procedure    :                                             */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vasu k                                                        */
/* date         : 4/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : Balaji S                                                      */
/* date         : 03/03/2005                                                    */
/* description  : Validation For One Control More than one Susbcription   */
/* BugID  : PNR2.0_2717              */
/********************************************************************************/
/* modified by  : Ganesh                                                       */
/* date         : 15/06/2005                                                    */
/* description  : Error description has to be updated based on the language.  */
/* BugID  : PNR2.0_2911              */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Saravanan for PNR2.0_2889          */
/* Modified on : 16/06/2005              */
/* Description : While download, publish & unpublish of ECR allow only one instance at a time. */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_2986         */
/* Modified on : 16/06/2005              */
/* Description : ECR publish tuning            */
/* Modified by : Shriram V for callid PNR2.0_3616        */
/* Modified on : 22/08/05               */
/* Description : Length of BT Synonym Caption should not Exceed 60 Characters-  */
/*Validation to be put in RCN download/Publish and ECR download/Publish   */
/* Modified by : Saravanan for callid Platform_2.0.3.X_281      */
/* Modified on : 22/08/05               */
/* Description : I am noy able to Publish ECR ,It is throwing an error "Formal  */
/* parameter '@ctxt_user' was defined as OUTPUT but the actual parameter not declared OUTPUT." */
/********************************************************************************/
/* Modified by : Saravanan for callid Platform_2.0.3.X_466      */
/* Modified on : 02/09/05               */
/* Description : While publishing the ECR, it is throwing an error "Formal   */
/* parameter '@ctxt_user' was defined as OUTPUT but the actual parameter not declared OUTPUT." */
/********************************************************************************/  /* Modified by : Saravanan for Platform_2.0.3.X_468        */
/* Modified on : 03/09/2005              */
/* Description : While unpublishing the ECR, it throws some blank error. Simulation */
/* available... Customer: hema ECR: PO_ECR_00004        */
/********************************************************************************/
/* Modified by : Sageetha L              */
/* Modified on : 23/09/2005              */
/* Description :                 */
/********************************************************************************/
/* modification history               */
/* Modified by : Gowrisankar M for callid PNR2.0_5010       */
/* Modified on : 15-Dec-2005              */
/* Description : Validation has to be added for Data type / Length mismatch  */
/* between Segment dataitem & method Parameter         */
/********************************************************************************/
/* modification history               */
/* Modified by : Balaji S for callid PNR2.0_5029        */
/* Modified on : 16-Dec-2005              */
/* Description : Validation has to be added for Data type / Length mismatch  */
/* between Segment dataitem & method Parameter except for fw_context segment */
/********************************************************************************/
/********************************************************************************/
/* modification history               */
/* Modified by : Arunn for callid PNR2.0_5080-5073        */
/* Modified on : 20-Dec-2005              */
/* Description : While validating Segment Data Item & Method Parameter BT data  */
/*   type & length should be equal, check for IN and IN/OUT      */
/* cases for Method Parameters and length of method parameter is     */
/* not less than Segment Dataitem length.          */
/********************************************************************************/
/*modified by   :Chanheetha N A                                           */
/*date          :14-Mar-2007                                             */
/*BugId   :PNR2.0_12630             */
/********************************************************************************/
/*modified by   :Chanheetha N A                                           */
/*date          :05-Apr-2007                                             */
/*BugId   :PNR2.0_12993             */
/********************************************************************************/
/*modified by   :Balaji S                                              */
/*date          :04-Jun-2007                                             */
/*BugId   :PNR2.0_13940             */
/********************************************************************************/
/*modified by   :Balaji S                                              */
/*date          :04-Jun-2007                                             */
/*BugId   :PNR2.0_13947             */
/********************************************************************************/
/*modified by   :Chanheetha N A                                           */
/*date          :07-Jun-2007                                             */
/*BugId   :PNR2.0_14006              */
/********************************************************************************/
/*modified by   :Kiruthika R                                           */
/*date          :23-Jul-2007                                             */
/*BugId   :PNR2.0_14623              */
/********************************************************************************/
/*modified by   :Chanheetha N A                                           */
/*date          :06-Aug-2007                                             */
/*BugId   :PNR2.0_14839              */
/********************************************************************************/
/*modified by   :Gowrisankar M                                           */
/*date          :05-Sep-2007             */
/*BugId :PNR2.0_15193              */
/********************************************************************************/
/*modified by   :Balaji S                                          */
/*date          :19-Sep-2007    */
/*BugId  :PNR2.0_15372  */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/********************************************************************************/
/* modified by   : Gowrisankar M            */
/* date     : 10-Jan-2008              */
/* BugId    : PNR2.0_16442              */
/********************************************************************************/
/* modified by   : S.Sivakumar             */
/* date   : 25-APR-2008             */
/* BugId  : PNR2.0_17729             */
/********************************************************************************/
/* modified by     : Sangeetha G             */
/* date           : 7-May-2008             */
/* BugId          : PNR2.0_17846             */
/* Modified For    : To populate the table de_comp_doc_status      */
/************************************************************************/
/* modified by  : Sangeetha G                 */
/* date        : 21-May-2008                 */
/* BugId       : PNR2.0_17991                 */
/* Modified For : Altered validation during publish ECR   */
/************************************************************************/
/* modified by  : Sangeetha G                 */
/* date        : 16-Oct-2008                 */
/* BugId       : PNR2.0_19644                 */
/* Modified For : To validate  datatype mismatch  between publication  */
/*     and subscription Dataitem during  ECR  publish  */
/*     instead  in  Resolve links ui .    */
/************************************************************************/
/* modified by  : S Gopinath                 */
/* date        : 17-Oct-2008                 */
/* BugId       : PNR2.0_19728                */
/* Modified For : To validate  datatype mismatch  between publication  */
/*     and subscription Dataitem during  Resolve links ui */
/********************************************************************************/
/* modified by     Gowrisankar M for PNR2.0_20359                               */
/* date            15/01/2009                                                 */
/* description     Error context to be changed from ControlID-ViewName to  */
/*     Segment-Dataitem                                            */
/********************************************************************************/
/* modified by  :  Gowrisankar M                                    */
/* date         :  16/02/2009                                                 */
/* BugId        :  PNR2.0_20956                                                 */
/* description  :  Mismatch error to be excluded unused services    */
/********************************************************************************/
/* modified by  :  Gowrisankar M                                    */
/* date         :  18-Mar-2009                                                 */
/* BugId        :  PNR2.0_21544                                                 */
/* description  :  Process Only-selected-rows to be updated from task pattern */
/********************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description  : PNR2.0_23463          */
/******************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 31-Aug-2009         */
/* Description     : PNR2.0_23545          */
/******************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 31-Aug-2009         */
/* Description     : PNR2.0_23560         */
/******************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 04-Sep-2009         */
/* Description     : PNR2.0_23650         */
/********************************************************************************/
/* Modified By : Gowrisankar M               */
/* Date   : 21-Dec-2009              */
/* Bug ID  : PNR2.0_25310              */
/* Description : Dataset Name to be used in group by instead of segment name */
/********************************************************************************/
/* Modified By       : Sangeetha G												 */
/* Date				 : Sep 17 2010											     */
/* Bug Id			 : PNR2.0_28333	                                             */
/* Description       : Ezee view page for Platform                               */
/*********************************************************************************/
/* Modified By       : Chanheetha N A						 */
/* Date		     : 10-Nov-2010				                 */
/* Bug Id	     : PNR2.0_27462	                                         */
/* Description       : For the new feature Process Updated rows                  */
/*********************************************************************************/
/* Modified By       : Sangeetha G						 */
/* Date		         : 10-FEB-2011				                 */
/* Bug Id	         : PNR2.0_30128	                                         */
/* Description       : For 're-used service'                  */
/*********************************************************************************/
/* modified by			: Jeya Latha K											*/
/* date					: 29-Sep-2011											*/
/* BugId				: PNR2.0_33317 											*/
/* Description			: New Feature - Offline Reports							*/
/********************************************************************************/
/* modified by			: Jeya Latha K											*/
/* date					: 21-Oct-2011											*/
/* BugId				: PNR2.0_33945 											*/
/* Description			: New Feature - Offline Reports							*/
/********************************************************************************/
/* modified by  :	Muthupandi S												*/
/* date         :	01-December-2011											*/
/* Bug ID		:	PNR2.0_34596 [ Changed Objects Bug Id : PNR2.0_35183  ]		*/
/* Description	:	Validation added to avoid adding a new section with the existing */
/*					section name across UI										*/
/********************************************************************************/
/* modified by			: Balaji D      										*/
/* date					: 24-Apr-2012											*/
/* BugId				: PLF2.0_00194 											*/
/* Description			: Focusdataitem to be updated form Segment-dataitem		*/
/********************************************************************************/
/* modified by			: Muthupandi S											*/
/* date					: 10-May-2012											*/
/* BugId				: PLF2.0_00360 											*/
/* Description			: Validation added to avoid defining Combo load methods under fetch services*/
/********************************************************************************/
/* modified by  :	Shakthi P														 */
/* date         :	26-FEB-2014												     	 */
/* Bug ID		:	PLF2.0_07676 													 */
/* Description	:	Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool */
/*Bar Hiding, Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator	*/
/*************************************************************************************/
/* modified by			: Loganayaki P`												*/
/* date					: 29-Apr-2014											*/
/* BugId				: PLF2.0_08219											*/
/* Description			: Validation commended inorder to allow Combo load methods under fetch services  */
/********************************************************************************/ 
/* Modified by  : Veena U                                                  */
/* Date         : 25-Feb-2015                                                  */
/* Call ID		: PLF2.0_11499                                                 */
/********************************************************************************/ 
/* Modified by  : Loganayaki P                                                  */
/* Date         : 14-OCT-2016                                                  */
/* Call ID		: TECH-218                                                */
/********************************************************************************/ 
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010 */  
/**************************************************************************************/
/* Modified by : Venkatesan K			    Date: 08-Nov-2019  Defect ID: TECH-39810 */
/*************************************************************************************/
/* Modified by : Hareesh K/Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809 */ 
/*************************************************************************************************/
/* Modified by : Venkatesan K				  Date: 06-May-2020  Defect ID : TECH-45828 */ 
/*************************************************************************************************/
/*************************************************************************************************/
/* Modified by : Ganesh Prabhu S				  Date: 05-Sept-2020  Defect ID : TECH-49490 */ 
/*************************************************************************************************/
/* Modified by : Kiruthika R				   Date: 23-Feb-2021  Defect ID : TECH-55700 */ 
/*************************************************************************************************/
/* Modified By	: Priyadharshini U																*/
/* Defect ID	: TECH-72114																	*/
/* Modified on	: 22-Aug-2022																	*/
/* Description	: 	Platform Release for the month of August'22									*/
/************************************************************************************************/
/*************************************************************************************************/
/* Modified By	: SRIKANTH S																*/
/* Defect ID	: TECH-72237																	*/
/* Modified on	: 05-SEPT-2022																*/
/* Description	: 	Update for iszipped service								*/
/************************************************************************************************/
/* Modified By	: Deepika S																		*/
/* Defect ID	: TECH-73522																	*/
/* Modified on	: 27-OCT-2022																	*/
/* Description	: Validation for restricting dataitem in both ilbo mapping and attribute mapping */
/************************************************************************************************/
/* Modified By	: Ganesh Prabhu S																*/
/* Defect ID	: TECH-73989																	*/
/* Modified on	: 27-OCT-2022																	*/
/************************************************************************************************/
/* Modified By	: Ponmalar A																	*/
/* Defect ID	: TECH-75230																	*/
/* Modified on	: 06-Dec-2022																	*/
/************************************************************************************************/
create   Procedure de_publ_sp_publico
@ctxt_language			engg_ctxt_language,
@ctxt_ouinstance        engg_ctxt_ouinstance,
@ctxt_service           engg_ctxt_service,
@ctxt_user              engg_ctxt_user,
@customer_name          engg_name,
@ico_descr              engg_description,
@ico_no                 engg_name,
@project_name           engg_name,
@modeflag               engg_modeflag,
@fprowno                engg_rowno,
@m_errorid				engg_seqno output
as
begin

set nocount on

--temporary and formal parameters mapping
select @ctxt_language   = @ctxt_language
select @ctxt_ouinstance         = @ctxt_ouinstance
select @ctxt_service            = ltrim(rtrim(@ctxt_service))
select @ctxt_user               = ltrim(rtrim(@ctxt_user))
select @customer_name           = ltrim(rtrim(@customer_name))
select @ico_descr               = ltrim(rtrim(@ico_descr))
select @ico_no                  = ltrim(rtrim(@ico_no))
select @project_name            = ltrim(rtrim(@project_name))
select @modeflag                = ltrim(rtrim(@modeflag))
select @fprowno                 = @fprowno

if @modeflag <>'Z'
begin
select  @fprowno    'fprowno'
set nocount off
return
end

--null checking
if @ctxt_language = -915
select @ctxt_language = null

if @ctxt_ouinstance = -915
select @ctxt_ouinstance = null

if @ctxt_service = '~#~'
select @ctxt_service = null

if @ctxt_user = '~#~'
select @ctxt_user = null

if @customer_name = '~#~'
select @customer_name = null

if @ico_descr = '~#~'
select @ico_descr = null

if @ico_no = '~#~'
select @ico_no = null

if @project_name = '~#~'
select @project_name = null

if @modeflag = '~#~'
select @modeflag = null

if @fprowno = -915
select @fprowno = null


select @fprowno = @fprowno + 1

Declare @proc_name  engg_name,
@comp_name  engg_name,
@date   engg_date,
@prev_ecr  engg_name,
@method_name engg_name,
@control_name engg_name,
@msg   engg_documentation, -- Code modified by Gowrisankar for PNR2.0_15193 on 05-Sep-2007
@getdate  engg_date,
@btName_tmp  engg_name,
@Act_name_rpt engg_name,
@UI_NAME_rpt engg_name,
@Task_Name_rpt engg_name,
@ui_name_db engg_name,	-- Code added For Bug Id : PNR2.0_33317
@tmp_activity_name engg_name,
@tmp_ui_name engg_name,
@tmp_templateid engg_name,
@uisubtype	engg_name	--TECH-75230

-- Changed Objects Inclusion for Bug Id : PNR2.0_35183		Starts
declare @depstatereq engg_name /*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
declare @act_depstate engg_name
declare @ui_depstate engg_name
declare @sec_depstate engg_name/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/
-- Changed Objects Inclusion for Bug Id : PNR2.0_35183		End

If @modeflag ='Z'
begin

select @getdate = getdate()

-- code modified by shafina on 26-Oct-2004 for ECENG203ACC_000084 (ECR for a component must be published in downloaded order)
select @date   = createddate,
@proc_name  = process_name,
@comp_name  = component_name,
@tmp_activity_name = activity_name, --TECH-75230
@tmp_ui_name = ui_name				--TECH-75230
from de_ui_ico (nolock)
where customer_name  = @customer_name
and  project_name  = @project_name
and   ico_no      = @ico_no

-- Code added by Saravanan on 09/06/2005 for PNR2.0_2889 - To avoid multiple ECR publish - START
If exists (Select 'x' from de_ecr_publish_chk (nolock)
where work_flag in ('P', 'U')
and   customer_name = @customer_name
and   project_name  = @project_name)
begin
--- Code modified for Platform_2.0.3.X_468
-- Code Modified For Bug_id PNR2.0_17729 Starts Here
Select @msg = ecr_no +  ' is being published / unpublished by ' + publ_username +  ' from ' + cast(datepart (hh,start_time) as varchar(2)) + ':'+ cast(datepart (mi,start_time)as varchar(2))
+ ':'+ cast(datepart (ss,start_time)as varchar(2)) + ' onwards. Please try after some time...'
from de_ecr_publish_chk (nolock)
where work_flag in ('P', 'U')
exec   engg_error_sp 'de_publ_sp_publico', 1, @msg ,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
'', '', '', '', @m_errorid
return
end

Insert into de_ecr_publish_chk
(customer_name,     project_name,   ecr_no,   publ_username,   start_time,  host_mcname,  work_flag)
values
(@customer_name,     @project_name, @ico_no,    @ctxt_user,    getdate(),  host_name(),  'P') 

-- code added against TECH-73989 by 11537
if not exists	(select top 1 'x' 
				from	de_fw_des_service (nolock)
				where	customer_name	= @customer_name
				and		project_name	= @project_name
				and		process_name	= @proc_name
				and		componentname	= @comp_name
				)
BEGIN 
	--TECH-75230	--11536
	IF NOT EXISTS	(SELECT TOP 1 'x' 
				from	de_task_gql_mapping (nolock)
				where	customername	= @customer_name
				and		projectname	= @project_name
				and		processname	= @proc_name
				and		componentname	= @comp_name
				)
				BEGIN
				RAISERROR ('No services available under this component, Minimum one service is required for Code Gen.',16,1)
				RETURN
				END
	--TECH-75230	--11536
END

-- code added against TECH-73989 by 11537


-- Code Modified For Bug_id PNR2.0_17729 Ends Here

--code added by chanheetha N A for the call id: PNR2.0_12993
/*Code commented by Sangeetha G for the bug id:PNR2.0_30128 **starts**  */
--select  @msg = ''
--
--Select @msg = 'In the re-used service '''+ a.servicename + ''' the dataitem '''+ a.dataitemname + ''' has been mapped to two different Controls under the segment '''+ a.segmentname+ '''.pls change the same and proceed'
--from  de_fw_des_ilbo_service_view_datamap a (nolock),
--de_fw_des_ilbo_service_view_datamap b (nolock)
--where a.customer_name = @customer_name
--and   a.project_name  = @project_name
--and   a.process_name  = @proc_name
--and   a.component_name = @comp_name
--and   a.customer_name   =  b.customer_name
--and   a.project_name    =  b.project_name
--and   a.process_name    =  b.process_name
--and   a.component_name  =  b.component_name
--and   a.activity_name   =  b.activity_name
--and   a.ilbocode        =  b.ilbocode
--and   a.servicename     =  b.servicename
--and   a.segmentname     =  b.segmentname
--and   a.dataitemname    =  b.dataitemname
--and (a.controlid      <> b.controlid
--or    a.viewname        <> b.viewname)
--and   a.taskname        <> b.taskname
--
--if isnull(@msg , '') <> ''
--
--begin
--exec   engg_error_sp 'de_publ_sp_publico', 1, @msg ,
--@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--'', '', '', '', @m_errorid
--return
--end
/*Code commented by Sangeetha G for the bug id:PNR2.0_30128 **ends**  */

--code added by chanheetha N A for the call id: PNR2.0_12993

--code added by Gowrisankar for PNR2.0_5010 on 15-Dec-2005
--select  @msg = ''

--select @msg = 'For the service : ' + x.servicename + ' in the method :'+ a.method_name +
--' the parameter : ' + a.logicalparametername + ' btname / data type / length : ' + d.bt_name + ' / '+ d.data_type + ' / '
--+ convert(varchar(20), d.length ) + ' differs from the Segment :' + x.segmentname + ' the Dataitem name: '+x.dataitemname+
--+ ' btname / data type / length : '+ c.bt_name + ' / '+  c.data_type + ' / ' + convert(varchar(20), c.length )
--from    de_fw_des_br_logical_parameter a (nolock),
--de_fw_des_di_parameter   x (nolock),
--de_glossary      b (nolock),
--de_business_term    c (nolock),
--de_business_term    d (nolock)
--where a.customer_name   = @customer_name
--and  a.project_name    = @project_name
--and   a.process_name    = @proc_name
--and   a.component_name   = @comp_name

--and  a.customer_name   = x.customer_name
--and  a.project_name   = x.project_name
--and  a.process_name   = x.process_name
--and  a.component_name  = x.component_name
--and  a.methodid    = x.methodid
--and  a.logicalparametername = x.parametername

--and  x.customer_name   = b.customer_name
--and  x.project_name   = b.project_name
--and  x.process_name   = b.process_name
--and  x.component_name  = b.component_name
--and  x.dataitemname   = b.bt_synonym_name

--and  c.customer_name   = b.customer_name
--and  c.project_name   = b.project_name
--and  c.process_name   = b.process_name
--and  c.component_name  = b.component_name
--and  c.bt_name    =  b.bt_name

--and  a.customer_name   = d.customer_name
--and  a.project_name   = d.project_name
--and  a.process_name   = d.process_name
--and  a.component_name  = d.component_name
--and  a.btname    = d.bt_name

--and  isnull(a.btname,'')  <> ''
--and  (c.data_type   <> d.data_type
--or    (c.length    <>  d.length and d.length     < c.length)  )
----Code Modified For BugId : PNR2.0_5029
--and  x.segmentname   <> 'fw_context'

----code Modified For BugId : PNR2.0_5080-5073 on 20-Dec-2005
--and     a.flowdirection   in (0, 2)

---- and  d.length     < c.length
----code added by Gowrisankar for PNR2.0_20956 on 16-Feb-2009 - Begins
--and  exists ( select 'x'
--from de_task_service_map tkser (nolock)
--where tkser.customer_name  = x.customer_name
--and  tkser.project_name  = x.project_name
--and  tkser.process_name  = x.process_name
--and  tkser.component_name = x.component_name
--and  tkser.service_name  = x.servicename
--union
--select 'x'
--from de_fw_Des_processsection_br_is psbr (nolock)
--where psbr.customer_name  = x.customer_name
--and  psbr.project_name  = x.project_name
--and  psbr.integservicename = x.servicename
--and  psbr.isbr    = 0 )
----code added by Gowrisankar for PNR2.0_20956 on 16-Feb-2009 - Ends

--if isnull(@msg , '') <> ''
--begin
--exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
--@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--@ico_no, '', '', '', @m_errorid
--return
--end --code added by Gowrisankar for PNR2.0_5010 on 15-Dec-2005

/*Modification made by Muthupandi S for Bug id : PLF2.0_00360 Ends*/					
/*Modification made by Loganayaki P for Bug id : PLF2.0_08219 starts*/					
--if @modeflag = 'Z'
--begin   
--if exists (select 'X' from de_action a (nolock),
--			de_task_service_map b (nolock),
--			de_fw_req_activity c (nolock),
--			de_fw_des_base_task_segment_attribs d (nolock)
--			where a.customer_name	= @customer_name
--			and	  a.project_name	= @project_name
--			and	  a.process_name	= @proc_name	
--			and	  a.component_name	= @comp_name
--			and	  a.task_type		= 'Fetch'
--			and	  a.customer_name	= b.customer_name
--			and	  a.project_name	= b.project_name
--			and	  a.process_name	= b.process_name 
--			and	  a.component_name	= b.component_name
--			and	  a.activity_name	= b.activity_name
--			and	  a.ui_name			= b.ui_name
--			and	  a.task_name		= b.task_name
--			and	  b.customer_name	= c.customer_name
--			and	  b.project_name	= c.project_name
--			and	  b.process_name	= c.process_name 
--			and	  b.component_name	= c.component_name
--			and	  b.activity_name	= c.activityname
--			and	  c.customer_name	= d.customer_name
--			and	  c.project_name	= d.project_name
--			and	  c.process_name	= d.process_name 
--			and	  c.component_name	= d.component_name
--			and	  c.activityid		= d.activityid
--			and   b.ui_name			= d.ilbocode
--			and	  b.task_name		= d.taskname
--			and   b.service_name	= d.servicename
--			and   d.combofill		= 1)
--		begin
--			declare @Serv_name engg_name,@ui_name engg_name
			 
--			select top 1 @Serv_name = b.service_name,
--						 @ui_name	= a.ui_name
--			from de_action a (nolock),
--			de_task_service_map b (nolock),
--			de_fw_req_activity c (nolock),
--			de_fw_des_base_task_segment_attribs d (nolock)
--			where a.customer_name	= @customer_name
--			and	  a.project_name	= @project_name
--			and	  a.process_name	= @proc_name	
--			and	  a.component_name	= @comp_name
--			and	  a.task_type		= 'Fetch'
--			and	  a.customer_name	= b.customer_name
--			and	  a.project_name	= b.project_name
--			and	  a.process_name	= b.process_name 
--			and	  a.component_name	= b.component_name
--			and	  a.activity_name	= b.activity_name
--			and	  a.ui_name			= b.ui_name
--			and	  a.task_name		= b.task_name
--			and	  b.customer_name	= c.customer_name
--			and	  b.project_name	= c.project_name
--			and	  b.process_name	= c.process_name 
--			and	  b.component_name	= c.component_name
--			and	  b.activity_name	= c.activityname
--			and	  c.customer_name	= d.customer_name
--			and	  c.project_name	= d.project_name
--			and	  c.process_name	= d.process_name 
--			and	  c.component_name	= d.component_name
--			and	  c.activityid		= d.activityid
--			and   b.ui_name			= d.ilbocode
--			and	  b.task_name		= d.taskname
--			and   b.service_name	= d.servicename
--			and   d.combofill		= 1
			
--			select @msg = 'In an UI' + @ui_name + 'Combo load method is defined under the Fetch service ' + @serv_name + '. Please remove and proceed' 
--			exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
--			@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--			@ico_no, '', '', '', @m_errorid
--			return
--		End
--End	
/*Modification made by Loganayaki P for Bug id : PLF2.0_08219 Ends*/						
/*Modification made by Muthupandi S for Bug id : PLF2.0_00360 Ends*/					
-- Changed Objects Inclusion for Bug Id : PNR2.0_35183		Starts
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Starts*/
select @depstatereq = current_value from es_project_param_mst (nolock)
						where customer_name = @customer_name
						and project_name = @project_name
						and param_category = 'DEPSTATEREQ' 
if @modeflag = 'Z'
begin
	if @depstatereq = 'Y'
	begin 
	select  @act_depstate = a.activity_name,
	@ui_depstate =  a.ui_name,
	@sec_depstate = a.section_bt_synonym
	from  de_ui_section  a(nolock),
	de_ui_ico b (nolock)
	where  a.customer_name =  b.customer_name
	and a.project_name =  b.project_name
	and a.process_name =  b.process_name
	and a.component_name= b.component_name
	and a.activity_name =  b.activity_name
	and a.ui_name		=  b.ui_name
	and b.customer_name =  @customer_name
	and b.project_name	=  @project_name
	and b.ico_no = @ico_no
	group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name,a.section_bt_synonym
	having count(*) > 1


	if isnull(@ui_depstate,'') <> ''
	begin
	select @msg = 'In an UI :'+'"'+@ui_depstate+'"'+' under the activity '+'"'+@act_depstate+'"'+', section'+ '"'+@sec_depstate+ '"'+' is defined more than once' 
	exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
	@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
	@ico_no, '', '', '', @m_errorid
	return
end
end
end
/*Modification made by Muthupandi S for Bug id : PNR2.0_34596 Ends*/
-- Changed Objects Inclusion for Bug Id : PNR2.0_35183		Ends

--code added by chanheetha N A for the call id  : PNR2.0_12630

--Code commented for PNR2.PNR2.0_19728  starts
----Code addition for PNR2.0_19644 starts
--
--select  @msg = ''
--
--select @msg = 'The datatype ('+ ltrim(rtrim(c.data_type)) + ') of the publication dataitem  ' + a.published_bt_synonym + ' of publication  ' + a.publication_name +
--' under the component ' + f.publication_comp_name +
--' differs from the datatype ('+ ltrim(rtrim(d.data_type))+ ') of its mapped subscription dataitem '+ a.subscribed_bt_synonym + ' of subscription ' + a.subscription_name + ' under the component ' + a.component_name +'.'
--
--from
--de_resolved_link_dataitem a (nolock),
--de_resolved_link_dataitem f (nolock),
--de_glossary       b (nolock),
--de_glossary       e (nolock),
--de_business_term  c (nolock),
--de_business_term  d (nolock)
--
--where a.customer_name    = @customer_name
--and   a.project_name     = @project_name
--and   a.process_name     = @proc_name
--and   a.component_name   = @comp_name
--and   a.customer_name     = f.customer_name
--and   a.project_name      = f.project_name
--and   a.process_name      = f.process_name
--and   a.component_name    = f.component_name
--and   a.activity_name  = f.activity_name
--and   a.ui_name   = f.ui_name
--and   a.page_bt_synonym  = f.page_bt_synonym
--and   a.publication_name  = f.publication_name
--and   a.dataitemname      = f.dataitemname
--and   a.subscription_name   = f.subscription_name
--and   a.subscribed_bt_synonym  = f.subscribed_bt_synonym
--and   a.published_bt_synonym = f.published_bt_synonym
--
--and  f.customer_name           = b.customer_name
--and  f.project_name            = b.project_name
--and  f.publication_comp_name   = b.component_name
--and  f.published_bt_synonym    = b.bt_synonym_name
--
--and  a.customer_name           = e.customer_name
--and  a.project_name            = e.project_name
--and  a.process_name            = e.process_name
--and  a.component_name          = e.component_name
--and  a.subscribed_bt_synonym   = e.bt_synonym_name
--
--
--and  c.customer_name   = b.customer_name
--and  c.project_name    = b.project_name
--and  c.process_name    = b.process_name
--and  c.component_name  = b.component_name
--and  c.bt_name         = b.bt_name
--
--and  d.customer_name   = e.customer_name
--and  d.project_name    = e.project_name
--and  d.process_name    = e.process_name
--and  d.component_name  = e.component_name
--and  d.bt_name         = e.bt_name
--
--and  isnull(d.bt_name,'')  <> ''
--and  c.data_type   <> d.data_type
--
--if isnull(@msg , '') <> ''
--begin
--exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
--@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--@ico_no, '', '', '', @m_errorid
--return
--end
--
----Code addition for PNR2.0_19644 ends
--Code commented for PNR2.PNR2.0_19728 ends
-- 11537 Forced activity starts
Declare @forcedact engg_name

select	Top 1 @forcedact = isnull(activityname,'')
from	de_fw_req_activity a (nolock),
		de_fw_des_ilbo_Service_view_Datamap b (nolock)
where	a.customer_name		= @customer_name
and     a.project_name      = @project_name
and     a.process_name      = @proc_name
and     a.component_name    = @comp_name
and     a.IsForcedActivity  = 1 
and		a.customer_name     = b.customer_name       
and		a.project_name		= b.project_name       
and		a.process_name      = b.process_name       
and		a.component_name    = b.component_name       
and		a.activityname		= b.activity_name
and     (b.servicename = 'DepforcedMainPgISAddTrSr' or
		b.servicename  =  'DepforcedMainPgISUpdTrSr')

if isnull(@forcedact,'') <> ''
Begin

	select @msg = 'Integration services ''DepforcedMainPgISAddTrSr'' & ''DepforcedMainPgISUpdTrSr'' should be mapped to the Activity: '+ @forcedact
	Raiserror (@msg ,16,1)
	Return
End


-- 11537 Forced activity Ends

if exists (select  'x'
from de_fw_des_processsection_br_is a(nolock)
where a.customer_name   = @customer_name
and  a.project_name    = @project_name
and   a.process_name    = @proc_name
and   a.component_name   = @comp_name
and     not exists (Select 'x' from  de_fw_des_service_dataitem     b(nolock)
where a.customer_name    = b.customer_name
and  a.project_name     = b.project_name
and   a.process_name     = b.process_name
and   a.component_name   = b.component_name
and   a.servicename      = b.servicename)
and   exists   (Select 'x' from  de_fw_des_ilbo_service_view_datamap c (nolock)
where a.customer_name    = c.customer_name
and   a.project_name     = c.project_name
and   a.process_name     = c.process_name
and   a.component_name   = c.component_name
and   a.servicename      = c.servicename))
begin

declare @service_name engg_name

select  @service_name = a.servicename
from    de_fw_des_processsection_br_is a(nolock)
where a.customer_name   = @customer_name
and  a.project_name    = @project_name
and   a.process_name    = @proc_name
and   a.component_name   = @comp_name
and     not exists (Select 'x' from  de_fw_des_service_dataitem     b(nolock)
where a.customer_name    = b.customer_name
and   a.project_name     = b.project_name
and   a.process_name     = b.process_name
and   a.component_name   = b.component_name
and   a.servicename      = b.servicename)
and     exists   (Select 'x' from  de_fw_des_ilbo_service_view_datamap c (nolock)
where a.customer_name    = c.customer_name
and   a.project_name     = c.project_name
and   a.process_name     = c.process_name
and   a.component_name   = c.component_name
and   a.servicename      = c.servicename)


select @msg = 'Dataitem does not exists For the Service ' + @service_name +'.Pls Define the dataitem and proceed.'
exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@ico_no, '', '', '', @m_errorid
return

end

--code added by kiruthika for bugid:PNR2.0_14623

declare @servicename     engg_service_name,
@segmentname  engg_segment_name,
@dataitemname  engg_data_item_name

select @servicename = ''

select @servicename = a.servicename,
@segmentname  = a.segmentname,
@dataitemname = a.dataitemname
from   de_fw_des_service_dataitem a(nolock)
where   a.customer_name   = @customer_name
and  a.project_name    = @project_name
and   a.process_name    = @proc_name
and   a.component_name   = @comp_name
and     charindex(' ',a.dataitemname) <> 0

if isnull (@servicename,'') <> ''
begin
select @msg = 'For the service:"'+ @servicename + '"under the segment:"' + @segmentname + '"the dataitemname:"'+ @dataitemname+ '" contain spaces'
raiserror (@msg,16,1)
return
end
--code added by chanheetha N A for the call id  : PNR2.0_12630

--Insert into de_ecr_publish_chk
--(customer_name,     project_name,   ecr_no,   publ_username,   start_time,  host_mcname,  work_flag)
--values
--(@customer_name,     @project_name, @ico_no,    @ctxt_user,    getdate(),  host_name(),  'P')

-- Code added by Saravanan on 09/06/2005 for PNR2.0_2889 - To avoid multiple ECR publish - END
if exists (
select 'x'
from de_ui_ico (nolock)
where customer_name  = @customer_name
and  project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
and   ico_no      <> @ico_no
and  ico_status  = 'C'
and  createddate  < @date
)
begin
select @prev_ecr  = ico_no
from de_ui_ico (nolock)
where customer_name  = @customer_name
and  project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
and   ico_no      <> @ico_no
and  ico_status  = 'C'
and  createddate  < @date
exec   engg_error_sp 'de_publ_sp_publico', 1, 'Publish the previous ECR Number <%1> first..',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@prev_ecr, '', '', '', @m_errorid
end

-- code modified by Ganesh  for the callid :: PNR2.0_2986 on 21/6/05
--  declare mainui_cur cursor
--  for
--  select process_name,component_name,activity_name,ui_name
--  from de_ui_ico(nolock)
--  where customer_name = @customer_name
--  and  project_name = @project_name
--  and  ico_no    = @ico_no
--
--  open mainui_cur
--
--  while 1=1
--  begin--1
--  fetch next from mainui_cur
--  into @proc_name,@comp_name,@act_name,@ui_name
--
--  if @@fetch_status <> 0
--  break
--
--  if exists ( select 'x' from de_ui_ico(nolock)
--   where customer_name  = @customer_name
--   and  project_name   = @project_name
--   and  process_name   = @proc_name
--   and  component_name  = @comp_name
--   and  activity_name  = @act_name
--   and  ui_name     = @ui_name
--   and  ico_no      = @ico_no
--   and  ico_status     = 'P')
--  begin
--  exec  engg_error_sp 'de_publ_sp_publico', 1, 'ECR Number <%1> already published',
--   @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--    @ico_no, '', '', '', @m_errorid
--  close  mainui_cur
--  deallocate mainui_cur
--
--  return
--  end
--  --select * from de_ui update de_ui set current_req_no=''
--
--
--  if not exists ( select 'x' from de_ui(nolock)
--         where customer_name  = @customer_name
--         and  project_name   = @project_name
--         and  process_name   = @proc_name
--         and  component_name  = @comp_name
--         and  activity_name  = @act_name
--         and  ui_name     = @ui_name
--         and  current_req_no   =  @ico_no)
--  begin
--  exec  engg_error_sp 'de_publ_sp_publico', 1, 'ECR Number <%1> already published',
--   @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--    @ico_no, '', '', '', @m_errorid
--
--  close  mainui_cur
--  deallocate mainui_cur
--
--  return
--  end
--
--
--  update  de_ui_ico
--  set  ico_status   = 'P'
--  where  customer_name  = @customer_name
--  and   project_name  = @project_name
--  and   process_name  = @proc_name
--  and   component_name  = @comp_name
--  and   activity_name  = @act_name
--  and   ui_name     = @ui_name
--  and   ico_no      = @ico_no
--
--  --CODE MODIFIED BY DNR ON 19-MAY-2004
--  update  de_ui
--  set  current_req_no  = ''
--  where customer_name  = @customer_name
--  and   project_name  = @project_name
--  and  process_name  = @proc_name
--  and  component_name  = @comp_name
--  and   activity_name  = @act_name
--  and   ui_name     = @ui_name
--  and   current_req_no  = @ico_no
--
--  end
--  close  mainui_cur
--  deallocate mainui_cur

if exists ( select  'x'
from  de_ui_ico(nolock)
where  customer_name  = @customer_name
and   project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
and   ico_no      = @ico_no
and   ico_status    = 'P')
begin
exec   engg_error_sp 'de_publ_sp_publico', 1, 'ECR Number <%1> already published',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@ico_no, '', '', '', @m_errorid
return
end

if not exists ( select  'x'
from  de_ui(nolock)
where  customer_name  = @customer_name
and   project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
and   current_req_no  =  @ico_no)
begin
exec   engg_error_sp 'de_publ_sp_publico', 1, 'ECR Number <%1> already published',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@ico_no, '', '', '', @m_errorid
return
end

----------------------------------------Code Added against Defect ID : TECH-73522 starts---------------------

declare @serv_name engg_name,
		@attrib_Dataitem engg_name
if exists (
select 'x' from de_fw_des_ilbo_service_view_attributemap a (nolock),de_fw_des_ilbo_service_view_datamap b(nolock)
					where a.customer_name = @customer_name
					and a.project_name = @project_name
					and a.process_name = @proc_name
					and a.component_name = @comp_name
			--		and servicename = @service_name
					and a.customer_name = b.customer_name
					and a.project_name = b.project_name
					and a.process_name = b.process_name
					and a.component_name = b.component_name
					and a.servicename = b.servicename
					and a.segmentname = b.segmentname
					and a.dataitemname = b.dataitemname
					)

begin 
SELECT   
		@serv_name = a.servicename,
		@attrib_Dataitem = a.dataitemname
		from de_fw_des_ilbo_service_view_attributemap a (nolock),de_fw_des_ilbo_service_view_datamap b(nolock)
					where a.customer_name = @customer_name
					and a.project_name = @project_name
					and a.process_name = @proc_name
					and a.component_name = @comp_name
			--		and servicename = @service_name
					and a.customer_name = b.customer_name
					and a.project_name = b.project_name
					and a.process_name = b.process_name
					and a.component_name = b.component_name
					and a.servicename = b.servicename
					and a.segmentname = b.segmentname
					and a.dataitemname = b.dataitemname
raiserror('The dataitem "%s" having mapped in both Ilbo Mapping and Control Attribute Mapping against the service "%s".',
16,1,@attrib_Dataitem,@serv_name)
end

-------------------------------------------ends----------------------------
--Code added for defectid TECH-75230 starts
SELECT 	  @dataitemname = ''

SELECT @uisubtype =	ui_subtype 
FROM de_ui (NOLOCK)
WHERE customer_name		= @customer_name	
AND	  project_name		= @project_name
AND	  process_name		= @proc_name
AND   component_name	= @comp_name
AND   activity_name		= @tmp_activity_name
AND   ui_name			= @tmp_ui_name

SELECT	@dataitemname = column_bt_synonym
FROM de_ui_control_dtl_vw WITH (NOLOCK)
WHERE customer_name		= @customer_name	
AND	  project_name		= @project_name
AND	  process_name		= @proc_name
AND   component_name	= @comp_name
AND   activity_name		= @tmp_activity_name
AND   ui_name			= @tmp_ui_name
AND   column_bt_synonym		NOT IN 
(SELECT DISTINCT BTSynonym 
 FROM de_task_gql_argument_mapping  (NOLOCK)
 WHERE customername		= @customer_name	
 AND   projectname		= @project_name
 AND   processname		= @proc_name
 AND   componentname	= @comp_name
 AND   activityname		= @tmp_activity_name
 AND   uiname			= @tmp_ui_name
 AND   ISNULL(BTSynonym,'') <>''
UNION
SELECT DISTINCT BTSynonym 
FROM de_task_gql_field_mapping (NOLOCK) 
WHERE customername		= @customer_name	
AND   projectname		= @project_name
AND   processname		= @proc_name
AND   componentname		= @comp_name
AND   activityname		= @tmp_activity_name
AND   uiname			= @tmp_ui_name
AND	  ISNULL(BTSynonym,'') <>''
UNION
SELECT DISTINCT control_bt_synonym 
FROM de_task_control_attributemap (NOLOCK) 
WHERE customer_name		= @customer_name	
AND   project_name		= @project_name
AND   process_name		= @proc_name
AND   component_name	= @comp_name
AND   activity_name		= @tmp_activity_name
AND   ui_name			= @tmp_ui_name
AND   ISNULL(control_bt_synonym,'') <>''
UNION
SELECT DISTINCT dataitemname 
FROM de_fw_des_ilbo_service_view_datamap (NOLOCK)
WHERE customer_name		= @customer_name	
AND   project_name		= @project_name
AND   process_name		= @proc_name
AND   component_name	= @comp_name
AND   activity_name		= @tmp_activity_name
AND	  ilbocode			= @tmp_ui_name 
AND isnull(dataitemname,'') <>''
)
AND base_ctrl_type NOT IN ('Grid','Button','link','Assorted','ListEdit','ListView','TreeGrid','Pivot','RSGrid','RSSlider','Slider')
AND section_bt_synonym <> 'PrjhdnSection'

IF ISNULL(@dataitemname,'') <> ''	AND ISNULL(@uisubtype,'') <> 'Offline'
BEGIN
SELECT @msg = 'BTSynonym '''+@dataitemname+''' is not associated to any one of the services in the UI '''+@tmp_ui_name+'''.Please map and proceed.'
RAISERROR(@msg,16,1)
RETURN
END

--Code added for defectid TECH-75230 ends

-- Code Added For Bug_id PNR2.0_17729 Starts Here

--Modified  by  Sangeetha for PNR2.0_17991

Begin

If Exists
(
Select 'x'
From de_report_action_dataset_segment b (Nolock)
Where Customer_Name = @customer_name
and  Project_Name = @project_name
and  Process_Name = @proc_name
and  Component_Name = @comp_name
and  segment_instance = 'Multiple'
and  sub_report  = 'No'
Group by ui_name, action_name
Having count(distinct dataset_name) > 1   -- code modified by Gowrisankar M on 21-Dec-2009 for PNR2.0_25310
)
-- Group by ui_name, action_name
-- Having count(distinct segment_name) > 1

Begin
Select  @Act_name_rpt = activity_name,
@Ui_Name_rpt = ui_name,
@Task_Name_Rpt = action_name
From de_report_action_dataset_segment a (Nolock)
Where Customer_Name = @customer_name
and  Project_Name = @project_name
and  Process_Name = @proc_name
and  Component_Name = @comp_name
and  exists   (
Select 'x'
From de_report_action_dataset_segment b (Nolock)
Where Customer_Name = @customer_name
and  Project_Name = @project_name
and  Process_Name = @proc_name
and  Component_Name = @comp_name
and  segment_instance = 'Multiple'
and  sub_report  = 'No'
and  a.activity_name = b.activity_name
and  b.ui_name  = a.ui_name
and  b.action_name = a.action_name
Group by ui_name, action_name
Having count(distinct dataset_name) > 1  -- code modified by Gowrisankar M on 21-Dec-2009 for PNR2.0_25310
)
-- Group by activity_name,ui_name, action_name
-- Having count(distinct segment_name) > 1

Select @msg = 'For The Activity ' + @Act_name_rpt +'in the UI '+ @Ui_Name_rpt +' The Following task ' +@Task_Name_Rpt +' Has More Than One Main Report'
Raiserror (@msg,16,1)
return
End
End
-- Code Added For Bug_id PNR2.0_17729 Ends Here

-- Code added For Bug Id : PNR2.0_33317		Starts
select	@ui_name_db = ''
select	@ui_name_db = a.ui_name
from	de_action a(nolock),
		es_comp_task_type_mst_vw b(nolock)
where	a.Customer_Name		= @customer_name
and		a.Project_Name		= @project_name
and		a.Process_Name		= @proc_name
and		a.Component_Name	= @comp_name

and		a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.task_pattern		= b.task_type_name
and		isnull(b.alternate_db,'N')= 'Y'

and		not exists (select 'x'
			from	de_action c(nolock),		-- modification for bugid : PNR2.0_33945 starts
					de_task_service_map d (nolock)
			where	c.Customer_Name		= @customer_name
			and		c.Project_Name		= @project_name
			and		c.Process_Name		= @proc_name
			and		c.Component_Name	= @comp_name

			and		c.customer_name	= a.customer_name
			and		c.project_name	= a.project_name
			and		c.process_name	= a.process_name
			and		c.component_name= a.component_name
			and		c.activity_name	= a.activity_name
			and		c.ui_name		= a.ui_name
			and		c.task_type		= 'Report'
			
			and		c.customer_name	= d.customer_name
			and		c.project_name	= d.project_name
			and		c.process_name	= d.process_name
			and		c.component_name= d.component_name
			and		c.activity_name	= d.activity_name
			and		c.ui_name		= d.ui_name
			and		c.task_name		= d.task_name	-- modification for bugid : PNR2.0_33945 ends
			)

If isnull(@ui_name_db,'') <> ''
Begin
	Select @msg = 'Atleast one Report Task should be present for the ILBO: ' + isnull(@ui_name_db,'') + ' Since ''Configure Alternate Database'' option is used in Action Pattern'
	Raiserror (@msg,16,1)
	return
End

-- Code added For Bug Id : PNR2.0_33317		Ends

update  de_ui_ico
set  ico_status   = 'P',modifieddate=getdate(),modifiedby=@ctxt_user
where  customer_name  = @customer_name
and   project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
and   ico_no      = @ico_no

update  de_ui
set  current_req_no  = ''
where  customer_name  = @customer_name
and   project_name  = @project_name
and  process_name  = @proc_name
and  component_name  = @comp_name
and   current_req_no  = @ico_no

--11536 for UPE STARTS TECH-45828

EXEC UPE_combo_list_load_MainSP		@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
									@customer_name,		@project_name,			@ico_no,			@proc_name,		
									@comp_name

EXEC UPE_Service_Copy_MoreAction	@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
									@customer_name,		@project_name ,			@ico_no,			@proc_name,		
									@comp_name

EXEC UPE_combo_list_load_MainSP_ServiceCopy	@ctxt_language,		@ctxt_ouinstance,		@ctxt_service,		@ctxt_user,
									@customer_name,		@project_name,			@ico_no,			@proc_name,		
									@comp_name



--11536 for UPE ENDS

Exec DRLogExt_cleanup_ecrpublish @customer_name , @project_name  ,@proc_name , @comp_name

Exec DRLogExt_ecrpublish @customer_name , @project_name , @ico_no

Exec DRExRep_cleanup_ecrpublish @customer_name , @project_name  ,@proc_name , @comp_name

Exec DRExRep_ecrpublish @customer_name , @project_name , @ico_no

--- Code modified by Saravanan for Platform_2.0.3.X_281 - START
exec Rmt_ECR_Publish @customer_name , @project_name , @ico_no , @ctxt_user, @ctxt_language,     @m_errorid  out
--- Code modified by Saravanan for Platform_2.0.3.X_281 - END

--code added for focus control by kiruthika R
if exists ( select 'x'
from es_CodeGen_Used (nolock)
where   Customer_Name = rtrim(@customer_name)
and     Project_Name    = rtrim(@project_name) )
begin
declare @count engg_name
set @count = ''
if exists ( select 'x'
from de_ui_ico a(nolock),
de_flowbr_br_error b(nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.ico_no   = @ico_no
and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.activity_name  = a.activity_name
and  b.ui_name   = a.ui_name
and     isnull(b.error_context, '') <> '')
begin
select @count =
case
when  a.MS_Dev_Required  ='Yes'and b.MS_Dev_Available     = 'No' then 'Ms Dev console'
when  a.MS_LP_Required   ='Yes'and b.MS_LP_Available      = 'No' then 'Ms Launch Pad'
when  a.Java_Dev_Required ='Yes'and b.Java_Dev_Available   = 'No' then 'Java Dev console'
when  a.Java_LP_Required  ='Yes'and b.Java_LP_Available    = 'No' then 'Java Launch Pad'
when  a.DotNet_Dev_Required ='Yes'and b.DotNet_Dev_Available = 'No' then 'DotNet Dev console'
when  a.DotNet_LP_Required ='Yes'and b.DotNet_LP_Available  = 'No' then 'DotNet Launch Pad'
else  'No error'
end
from    es_CodeGen_Used    a (nolock),
es_Feature_Available  b (nolock)
where   a.Customer_Name  = rtrim(@customer_name)
and     a.Project_Name    = rtrim(@project_name)
and  a.Feature_List  = 'Focus Control'
and  a.Feature_List  = b.Feature_List

if @count <> 'No error'
begin
select @msg = 'Focus Control does not support in the '+@count
exec engg_error_sp
'ep_validation_sp',  8,     @msg,
@ctxt_language,   @ctxt_ouinstance, @ctxt_service,
@ctxt_user,    '',     '',
'',      '',     @m_errorid output

if @m_errorid <> 0
return
end
end
end

select @method_name = ''

select @method_name = method_name
from de_fw_des_brerror (nolock)
where  customer_name  = @customer_name
and  project_name = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
group by component_name, methodid, method_name, sperrorcode
having count (*) > 1

if isnull(@method_name, '') <> ''
begin
exec   engg_error_sp 'de_publ_sp_publico', 1, 'SP ERROR CODE IS DUPLICATED FOR THE METHOD : <%1>. CHANGE AND PROCEED',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@method_name, '', '', '', @m_errorid
return
end

/*  Code Added By Balaji S on 03/06/2005
Validation For A Control With more than one Subscription */
Select @control_name = ''

Select @control_name  = control_bt_synonym
from de_subscription (nolock)
where  customer_name  = @customer_name
and   project_name  = @project_name
and   process_name  = @proc_name
and   component_name  = @comp_name
GROUP BY  customer_name, project_name,
process_name, component_name,
activity_name, ui_name,
page_bt_synonym,control_bt_synonym
HAVING COUNT(*) > 1

if isnull(@control_name, '') <> ''
begin
exec   engg_error_sp 'de_publ_sp_publico',
1, 'One or more Subscription exists For Control <%1>',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@control_name, '', '', '', @m_errorid
return
end


/* Code Modified For BugId :PNR2.0_3879 */

--Commented by Shriram V for callid PNR2.0_3996
/* select top 1
@servicename_tmp = a.servicename,
@segmentname_tmp = a.segmentname
from de_fw_des_ilbo_service_view_datamap a (nolock),
de_fw_des_service_segment   b (nolock)
where a.customer_name = @customer_name
and a.project_name = @project_name
and a.process_name = @proc_name
and a.component_name= @comp_name
and b.customer_name = a.customer_name
and b.project_name = a.project_name
and b.process_name = a.process_name
and b.component_name= a.component_name
and b.servicename = a.servicename
and b.segmentname = a.segmentname
and b.instanceflag = 0
and exists
(  select 's'
from de_ui_grid   c(nolock)
where a.customer_name = c.customer_name
and a.project_name = c.project_name
and a.process_name = c.process_name
and a.component_name= c.component_name
and a.ilbocode = c.ui_name
and a.controlid = c.control_id
and a.viewname = c.view_name
union
select 's'
from de_hidden_view  f(nolock)
where a.customer_name = f.customer_name
and a.project_name = f.project_name
and a.process_name = f.process_name
and a.component_name= f.component_name
and a.ilbocode = f.ui_name
and a.controlid = f.control_id
and a.viewname = f.view_name
and isnumeric(f.view_name) = 1)
and  exists (
select 's'
from de_fw_des_ilbo_service_view_datamap d (nolock)
where a.customer_name = d.customer_name
and a.project_name = d.project_name
and a.process_name = d.process_name
and a.component_name= d.component_name
and a.ilbocode = d.ilbocode
and a.servicename = d.servicename
and a.activityid = d.activityid
and a.taskname = d.taskname
and a.segmentname = d.segmentname
and exists
(  select 's'
from de_ui_control  e(nolock)
where d.customer_name = e.customer_name
and d.project_name = e.project_name
and d.process_name = e.process_name
and d.component_name= e.component_name
and d.ilbocode = e.ui_name
and d.controlid = e.control_id
and d.viewname = e.view_name
union
select 's'
from de_hidden_view  f(nolock)
where d.customer_name = f.customer_name
and d.project_name = f.project_name
and d.process_name = f.process_name
and d.component_name= f.component_name
and d.ilbocode = f.ui_name
and d.controlid = f.control_id
and d.viewname = f.view_name
and isnumeric(f.view_name) = 0 ))

if isnull(@servicename_tmp, '') <> ''
begin
exec   engg_error_sp 'de_publ_sp_publico',
1, 'For The Service <%1> ,Mutiline Control is Mapped To Single Instance Segment <%2>.Plz Remove & Proceed ',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@servicename_tmp, @segmentname_tmp, '', '', @m_errorid
return
end


select @m_errorid = 0 */
--Commented by Shriram V for callid PNR2.0_3996


--Added by Shriram V on 22/08/05 for  Bug Id : PNR2.0_3616
--code Modified for bugId : PNR2.0_13940
--Code Modified for bugId : PNR2.0_13947
--  if exists (  select 'x'
--       from de_ui_control  a(nolock),
--         es_comp_ctrl_type_mst b(nolock),
--         de_ui_ico    c(nolock),
--         de_glossary_lng_extn d(nolock)
--       where a.customer_name   = b.customer_name
--       and  a.project_name   = b.project_name
--       and  a.process_name   = b.process_name
--       and  a.component_name  = b.component_name
--       and  a.control_type   = b.ctrl_type_name
--       and  b.base_ctrl_type  <> 'label'
--       and  a.customer_name   = c.customer_name
--       and  a.project_name   = c.project_name
--       and  a.process_name   = c.process_name
--       and  a.component_name  = c.component_name
--       and  a.customer_name   = d.customer_name
-- and  a.project_name   = d.project_name
--       and  a.process_name   = d.process_name
--       and  a.component_name  = d.component_name
--       and  a.control_bt_synonym = d.bt_synonym_name
--       and  c.customer_name   = @customer_name
--       and  c.project_name   = @project_name
--       and  c.ico_no    = @ico_no
--       and  len(a.bt_synonym_caption) > 60)
--  if exists( select 'x'
--     from  de_glossary_lng_extn  (nolock)
--     where  customer_name  = @customer_name
--     and   project_name  = @project_name
--     and   process_name  = @proc_name
--     and   component_name  = @comp_name
--     and  isnull(bt_name,'') <> ''
--     and  len(bt_synonym_caption) > 60)
--
--   begin
--   exec   engg_error_sp 'de_publ_sp_publico',
--      1, 'Length of BT Synonym Caption(S) cannot Exceed 60  Characters',
--     @ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
--     @control_name, '', '', '', @m_errorid
--   return
--  end

declare @btsyntmp engg_name

create table #ep_component_glossary_mst
( bt_synonym_name varchar(60), bt_synonym_caption varchar(255) )


insert  into #ep_component_glossary_mst
(bt_synonym_name, bt_synonym_caption)
select distinct a.component_name, b.bt_synonym_caption
from  ep_ui_mst     a(nolock),
ep_component_glossary_mst b(nolock)
where  a.customer_name    =  @customer_name
and   a.project_name    =  @project_name
and   a.process_name    =  @proc_name
and   a.component_name    =  @comp_name
and  a.customer_name    =  b.customer_name
and   a.project_name    =  b.project_name
and   a.process_name    =  b.process_name
and   a.component_name    =  b.component_name
and  a.component_name = b.bt_synonym_name
and  len(bt_synonym_caption) > 60
union
select distinct a.activity_name, b.bt_synonym_caption
from  ep_ui_mst     a(nolock),
ep_component_glossary_mst b(nolock)
where  a.customer_name    =  @customer_name
and   a.project_name    =  @project_name
and   a.process_name    =  @proc_name
and   a.component_name    =  @comp_name
and  a.customer_name    =  b.customer_name
and   a.project_name    =  b.project_name
and   a.process_name    =  b.process_name
and   a.component_name    =  b.component_name
and  a.activity_name  = b.bt_synonym_name
and  len(bt_synonym_caption) > 60
union
select distinct a.ui_name, b.bt_synonym_caption
from  ep_ui_mst     a(nolock),
ep_component_glossary_mst b(nolock)
where  a.customer_name    =  @customer_name
and   a.project_name    =  @project_name
and   a.process_name    =  @proc_name
and   a.component_name    =  @comp_name
and  a.customer_name    =  b.customer_name
and   a.project_name    =  b.project_name
and   a.process_name    =  b.process_name
and   a.component_name    =  b.component_name
and  a.ui_name   = b.bt_synonym_name
and  len(bt_synonym_caption) > 60
union
select distinct a.control_bt_synonym, c.bt_synonym_caption
from  ep_ui_control_dtl     a(nolock),
es_comp_ctrl_type_mst   b(nolock),
ep_component_glossary_mst  c(nolock)
where  a.customer_name     =  @customer_name
and   a.project_name     = @project_name
and   a.process_name  =  @proc_name
and   a.component_name    =  @comp_name
and   a.customer_name     =  b.customer_name
and   a.project_name     =  b.project_name
and   a.process_name     =  b.process_name
and   a.component_name    =  b.component_name
and   a.control_type     =  b.ctrl_type_name
and   a.customer_name     =  c.customer_name
and   a.project_name     =  c.project_name
and   a.process_name     =  c.process_name
and   a.component_name    =  c.component_name
and   a.control_bt_synonym    =  c.bt_synonym_name
and   b.base_ctrl_type    <> 'label'
--and  len(bt_synonym_caption) > 60
and  len(bt_synonym_caption) > 120 --code modified by 11536
union
select distinct a.column_bt_synonym, b.bt_synonym_caption
from  ep_ui_grid_dtl    a(nolock),
ep_component_glossary_mst b(nolock)
where  a.customer_name    =  @customer_name
and   a.project_name   =  @project_name
and   a.process_name    =  @proc_name
and   a.component_name    =  @comp_name
and  a.customer_name    =  b.customer_name
and   a.project_name    =  b.project_name
and   a.process_name    =  b.process_name
and   a.component_name    =  b.component_name
and  a.column_bt_synonym = b.bt_synonym_name
and  len(bt_synonym_caption) > 60

select  @btsyntmp = bt_synonym_name
from  #ep_component_glossary_mst


if isnull(@btsyntmp,'') <> ''
begin
exec  engg_error_sp 'de_publ_sp_publico',4, 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym "<%1>"', @ctxt_language,   @ctxt_ouinstance,@ctxt_service, @ctxt_user, @btsyntmp,   '', '', '',    @m_errorid  output
return
end

drop table #ep_component_glossary_mst

--Code Added for bugId : PNR2.0_15372
if exists ( select 'x'
from de_glossary  a(nolock),
de_business_term b(nolock)
where a.customer_name = b.customer_name
and a.project_name = b.project_name
and a.process_name = b.process_name
and a.component_name= b.component_name
and a.bt_name = b.bt_name
and b.data_type = 'numeric'
and a.customer_name = @customer_name
and   a.project_name  = @project_name
and   a.process_name  = @proc_name
and   a.component_name= @comp_name
and isnull(b.precision_type,'') = '')
begin


select @btName_tmp = a.bt_name
from de_glossary  a(nolock),
de_business_term b(nolock)
where a.customer_name = b.customer_name
and a.project_name = b.project_name
and a.process_name = b.process_name
and a.component_name= b.component_name
and a.bt_name = b.bt_name
and b.data_type = 'numeric'
and a.customer_name = @customer_name
and   a.project_name  = @project_name
and   a.process_name  = @proc_name
and   a.component_name= @comp_name
and isnull(b.precision_type,'') = ''

exec   engg_error_sp 'de_publ_sp_publico',
1, 'For the Numeric BT <%1> , precision cannot be Null',
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
@btName_tmp, '', '', '', @m_errorid
return
end


--Added by Shriram V on 22/08/05 for  Bug Id : PNR2.0_3616

-- Added By Feroz For moving static values into enumerated

delete  de_enum_value
from  de_enum_value
where customer_name+ '#' +project_name+ '#' +process_name+ '#' +component_name+ '#' +activity_name+ '#' +ui_name+ '#' +page_bt_synonym+ '#' +section_bt_synonym+ '#' +control_bt_synonym+ '#' +
enum_code+ '#' +enum_caption in (
select distinct a.customer_name+ '#' +a.project_name+ '#' + a.process_name+ '#' + a.component_name+ '#' + a.activity_name+ '#' + a.ui_name+ '#' + a.page_bt_synonym+ '#' +
a.section_bt_synonym+ '#' + a.control_bt_synonym+ '#' + b.quick_code+ '#' + b.quick_code_value
from  de_ui_control   a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.control_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.control_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
union
select distinct a.customer_name+ '#' + a.project_name+ '#' + a.process_name+ '#' + a.component_name+ '#' + a.activity_name+ '#' + a.ui_name+ '#' + a.page_bt_synonym+ '#' +
a.section_bt_synonym+ '#' + a.column_bt_synonym+ '#' + b.quick_code+ '#' + b.quick_code_value
from  de_ui_grid      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.column_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.column_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name)


delete  de_enum_value_lng_extn
from  de_enum_value_lng_extn
where customer_name+ '#' +project_name+ '#' +process_name+ '#' +component_name+ '#' +activity_name+ '#' +ui_name+ '#' +page_bt_synonym+ '#' +section_bt_synonym+ '#' +control_bt_synonym+ '#' +
enum_code+ '#' +enum_caption + '#' + convert(varchar(4),languageid) in (
select distinct a.customer_name+ '#' +a.project_name+ '#' + a.process_name+ '#' + a.component_name+ '#' + a.activity_name+ '#' + a.ui_name+ '#' + a.page_bt_synonym+ '#' +
a.section_bt_synonym+ '#' + a.control_bt_synonym+ '#' + b.quick_code+ '#' + b.quick_code_value + '#' + convert(varchar(4),b.languageid)
from  de_ui_control      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.control_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name  = c.process_name
and  a.component_name   = c.component_name
and  a.control_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
union
select distinct a.customer_name+ '#' + a.project_name+ '#' + a.process_name+ '#' + a.component_name+ '#' + a.activity_name+ '#' + a.ui_name+ '#' + a.page_bt_synonym+ '#' +
a.section_bt_synonym+ '#' + a.column_bt_synonym+ '#' + b.quick_code+ '#' + b.quick_code_value + '#' + convert(varchar(4),b.languageid)
from  de_ui_grid      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.column_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.column_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name)

insert into de_enum_value
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
enum_code,enum_caption,default_flag,seq_no,enum_value_sysid,ui_page_sysid,timestamp,createdby,createddate,modifiedby,modifieddate )
select distinct a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym,
a.section_bt_synonym, a.control_bt_synonym, b.quick_code, b.quick_code_value, case b.default_flag when 'YES' then 'Y' Else 'N' End, b.sequence, newid(),newid(), 1, @ctxt_user, @getdate, @ctxt_user, @getdate
from  de_ui_control      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.control_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.control_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
and  not exists (select  'x'
from  de_enum_value en (nolock)
where  en.customer_name = a.customer_name
and  en.project_name  = a.project_name
and  en.process_name  = a.process_name
and  en.component_name  = a.component_name
and  en.activity_name  = a.activity_name
and  en.ui_name    = a.ui_name
and  en.page_bt_synonym  = a.page_bt_synonym
and  en.section_bt_synonym = a.section_bt_synonym
and  en.control_bt_synonym = a.control_bt_synonym
and  en.enum_code  = b.quick_code)
union
select distinct a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym,
a.section_bt_synonym, a.column_bt_synonym, b.quick_code, b.quick_code_value, case b.default_flag when 'YES' then 'Y' Else 'N' End, b.sequence, newid(),newid(), 1, @ctxt_user, @getdate, @ctxt_user, @getdate
from  de_ui_grid      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.column_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.column_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
and  not exists (select  'x'
from  de_enum_value en (nolock)
where  en.customer_name = a.customer_name
and  en.project_name  = a.project_name
and  en.process_name  = a.process_name
and  en.component_name  = a.component_name
and  en.activity_name  = a.activity_name
and  en.ui_name    = a.ui_name
and  en.page_bt_synonym  = a.page_bt_synonym
and  en.section_bt_synonym = a.section_bt_synonym
and  en.control_bt_synonym = a.column_bt_synonym
and  en.enum_code  = b.quick_code)


insert into de_enum_value_lng_extn
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
enum_code,enum_caption,default_flag,seq_no,enum_value_sysid,ui_page_sysid,timestamp,createdby,createddate,modifiedby,modifieddate, languageid )
select distinct a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym,
a.section_bt_synonym, a.control_bt_synonym, b.quick_code, b.quick_code_value, case b.default_flag when 'YES' then 'Y' Else 'N' End, b.sequence, newid(),newid(), 1, @ctxt_user, @getdate, @ctxt_user, @getdate, b.languageid
from  de_ui_control      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.control_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.control_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
and  not exists (select  'x'
from  de_enum_value_lng_extn en (nolock)
where  en.customer_name = a.customer_name
and  en.project_name  = a.project_name
and  en.process_name  = a.process_name
and  en.component_name  = a.component_name
and  en.activity_name  = a.activity_name
and  en.ui_name    = a.ui_name
and  en.page_bt_synonym  = a.page_bt_synonym
and  en.section_bt_synonym = a.section_bt_synonym
and  en.control_bt_synonym = a.control_bt_synonym
and  en.enum_code  = b.quick_code
and  en.languageid  = b.languageid)
union
select distinct a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym,
a.section_bt_synonym, a.column_bt_synonym, b.quick_code, b.quick_code_value, case b.default_flag when 'YES' then 'Y' Else 'N' End, b.sequence, newid(),newid(), 1, @ctxt_user, @getdate, @ctxt_user, @getdate, b.languageid
from  de_ui_grid      a (nolock),
ep_stat_ctrl_val_mst   b (nolock),
es_comp_stat_ctrl_type_mst  c (nolock)
where  a.column_type    = c.ctrl_type_name
and  a.customer_name   = @customer_name
and  a.project_name    = @project_name
and  a.process_name   = @proc_name
and  a.component_name   = @comp_name
and  a.customer_name   = c.customer_name
and  a.project_name    = c.project_name
and  a.process_name   = c.process_name
and  a.component_name   = c.component_name
and  a.column_type    = b.ctrl_type_name
and  b.customer_name   = c.customer_name
and  b.project_name    = c.project_name
and  b.ctrl_type_name  = c.ctrl_type_name
and  not exists (select  'x'
from  de_enum_value_lng_extn en (nolock)
where  en.customer_name = a.customer_name
and  en.project_name  = a.project_name
and  en.process_name  = a.process_name
and  en.component_name  = a.component_name
and  en.activity_name  = a.activity_name
and  en.ui_name    = a.ui_name
and  en.page_bt_synonym  = a.page_bt_synonym
and  en.section_bt_synonym = a.section_bt_synonym
and  en.control_bt_synonym = a.column_bt_synonym
and  en.enum_code  = b.quick_code
and  en.languageid  = b.languageid)

--CODE ADDED BY DNR for BUGID DEENG203ACC_000021
--CODE MODIFIED BY DNR for BUGID DEENG203ACC_000057
--( @ctxt_language,@ctxt_ouinstance,@ctxt_service ,@ctxt_user params added.)

-- Modified By feroz for bug id :PNR2.0_23463
-- Added By Feroz For listEdit
-- Modified By feroz for bug id :PNR2.0_23545
select a.*
into #de_ui_control
from de_ui_control   a (nolock),
es_comp_ctrl_type_mst b (nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.control_type  = b.ctrl_type_name
and  b.base_ctrl_type = 'ListEdit'
-- Modified By feroz for bug id :PNR2.0_23545

update a
set  a.control_type = 'Grid12'
from de_ui_control   a (nolock),
es_comp_ctrl_type_mst b (nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.control_type  = b.ctrl_type_name
and  b.base_ctrl_type = 'ListEdit'
-- Added By Feroz For listEdit
-- Modified By feroz for bug id :PNR2.0_23463


exec de_fw_req_migrate_model
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service ,
@ctxt_user,
@customer_name,
@project_name,
@ico_no,
@comp_name,
@comp_name,
@m_errorid output

if @m_errorid <> 0
return
/*code added by sangeetha G for the bug id:PNR2.0_30128 **starts**  */
select  @msg = ''      
      
Select @msg = 'In the re-used service '''+ a.servicename + ''' the dataitem '''+ a.dataitemname + ''' has been mapped to two different Controls under the segment '''+ a.segmentname+ '''.pls change the same and proceed'      
from  de_fw_des_ilbo_service_view_datamap a (nolock),      
de_fw_des_ilbo_service_view_datamap b (nolock)      
where a.customer_name = @customer_name      
and   a.project_name  = @project_name      
and   a.process_name  = @proc_name      
and   a.component_name = @comp_name      
and   a.customer_name   =  b.customer_name      
and   a.project_name    =  b.project_name      
and   a.process_name    =  b.process_name      
and   a.component_name  =  b.component_name      
and   a.activity_name   =  b.activity_name      
and   a.ilbocode        =  b.ilbocode      
and   a.servicename     =  b.servicename      
and   a.segmentname     =  b.segmentname      
and   a.dataitemname    =  b.dataitemname      
and (a.controlid      <> b.controlid      
or    a.viewname        <> b.viewname)      
and   a.taskname        <> b.taskname      
      
if isnull(@msg , '') <> ''      
      
begin      
exec   engg_error_sp 'de_publ_sp_publico', 1, @msg ,      
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,      
'', '', '', '', @m_errorid      
return      
end

/*code added by sangeetha G for the bug id:PNR2.0_30128 **ends**  */


--  select  @proc_name = process_name,
--    @comp_name  = component_name
--  from  de_ui_ico(nolock)
--  where  customer_name  = @customer_name
--  and   project_name  = @project_name
--  and   ico_no      = @ico_no

-- code added by Ganesh on 7/7/04 for the bugid :: ECENG203SYS_000081
--  insert into de_FW_DES_REQBR_DESBR
--    (reqbrname,    methodid,   upduser,   updtime,
--    customer_name,   project_name,  process_name,  component_name,
--    method_name,   timestamp,   createdby,   createddate,
--    modifiedby,    modifieddate)
--  select
--    methodname,    methodid,   upduser,   updtime,
--    customer_name,   project_name,  process_name,  component_name,
--    methodname,    timestamp,   createdby,   createddate,
--    modifiedby,    modifieddate
--  FROM de_FW_DES_BUSINESSRULE (nolock)
--  where customer_name = @customer_name
--  and  project_name = @project_name
--  and  process_name = @proc_name
--  and  component_name  = @comp_name
--  and  methodid not in ( select distinct methodid
--         from de_FW_DES_REQBR_DESBR (nolock)
--         where customer_name = @customer_name
--         and  project_name = @project_name
--         and  process_name = @proc_name
--         and  component_name  = @comp_name)
--
--
--  declare @std_br_text engg_description
--  select @std_br_text = 'Default BR generated by the system since the flow br associated to this design BR had been removed'
--
--  Insert into de_fw_req_businessrule(
--    brname,    brtype,     brdesc,
--    upduser,   updtime,    customer_name,
--    project_name,  timestamp,    createdby,
--    createddate,  modifiedby,    modifieddate,
--    process_name,  component_name)
--  select distinct
--    reqbrname,   'Rule',     @std_br_text,
--    @ctxt_user,   getdate(),    customer_name,
--    project_name,  1,      @ctxt_user,
--    getdate(),   @ctxt_user,    getdate(),
--    process_name,  component_name
--  from de_fw_des_reqbr_desbr (nolock)
--  where customer_name = @customer_name
--  and  project_name = @project_name
--  and  process_name = @proc_name
--  and  component_name  = @comp_name
--  and  ReqBRName not in ( select BRName
--         from de_fw_req_BusinessRule (nolock)
--         where customer_name = @customer_name
--         and  project_name = @project_name
--         and  process_name = @proc_name
--         and  component_name  = @comp_name
--          )
-- end

select @m_errorid = 0
-- CALLING the validation sp
exec de_publish_all_objects_ecr @ctxt_language,
@ctxt_ouinstance,
@ctxt_service ,
@ctxt_user,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,--chan
@m_errorid output

if @m_errorid <> 0
return


-- modifed by Ganesh For the Bugid ::: DEENG203SYS_000316 on 26/07/04
update a
set  a.activityid = b.activityid
from de_fw_des_ilbo_service_view_datamap a (nolock),
de_fw_req_activity b (nolock)
where a.customer_name = @customer_name
and  a.project_name = @project_name
and  a.process_name = @proc_name
and  a.component_name= @comp_name
and  a.customer_name = b.customer_name
and  a.project_name = b.project_name
and  a.process_name = b.process_name
and  a.component_name= b.componentname
and  a.activity_name = b.activityname

-- code modified by Ganesh for the callid :: PNR2.0_3642 on 31/08/05
update a
set  sperrorprotocol  = '0'
from de_Fw_des_sp   a (nolock),
de_fw_des_brerror b (nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name

and  b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and b.methodid   = a.methodid
and  a.sperrorprotocol = '1'

-- code added by Ganesh on 24/8/04
-- update the controlid for the label controls for those the length is exceeding 32 characters
exec de_update_label_controls @ctxt_language,
@ctxt_service,
@ctxt_ouinstance,
@ctxt_user,
@customer_name,
@project_name,
@proc_name,
@comp_name
--
--  -- Code Modified by feroz for bug id :  DEENG203SYS_000366 on 30-Sept-2004
--  delete a
--  from de_fw_req_br_error_placeholder a (nolock),
--    de_action   b (nolock)
--  where b.customer_name  = @customer_name
--  and  b.project_name  = @project_name
--  and  b.process_name  = @proc_name
--  and  b.component_name = @comp_name
--  and  b.customer_name  = a.customer_name
--  and  b.project_name  = a.project_name
--  and  b.process_name  = a.process_name
--  and  b.component_name = a.component_name
--  and  b.task_name   = a.taskname
--  and  a.brname not in ( select  distinct reqbrname
--         from  de_fw_des_reqbr_desbr  c (nolock)
--         where b.customer_name  = @customer_name
--         and  b.project_name  = @project_name
--         and  b.process_name  = @proc_name
--         and  b.component_name = @comp_name)



--  delete a
--  from de_fw_req_task_br_error_context a (nolock),
--    de_action   b (nolock)
--  where b.customer_name  = @customer_name
--  and  b.project_name  = @project_name
--  and  b.process_name  = @proc_name
--  and  b.component_name = @comp_name
--  and  b.customer_name  = a.customer_name
--  and  b.project_name  = a.project_name
--  and  b.process_name  = a.process_name
--  and  b.component_name = a.component_name
--  and  b.task_name   = a.taskname
--  and  a.brname not in ( select  distinct reqbrname
--         from  de_fw_des_reqbr_desbr  c (nolock)
--         where b.customer_name  = @customer_name
--         and  b.project_name  = @project_name
--         and  b.process_name  = @proc_name
--         and  b.component_name = @comp_name)


--  -- code added by Ganesh on 22/9/04 for the bugid :: ECENG203ACC_000077
--  -- To avoid the reqbr not mapped to the design br problem
--  delete a
--  from de_fw_req_task_rule a (nolock),
--    de_action   b (nolock)
--  where b.customer_name  = @customer_name
--  and  b.project_name  = @project_name
--  and  b.process_name  = @proc_name
--  and  b.component_name = @comp_name
--  and  b.customer_name  = a.customer_name
--  and  b.project_name  = a.project_name
--  and  b.process_name  = a.process_name
--  and  b.component_name = a.component_name
--  and  b.task_name   = a.taskname
--  and  a.brname not in ( select  distinct reqbrname
--         from  de_fw_des_reqbr_desbr  c (nolock)
--         where b.customer_name  = @customer_name
--         and  b.project_name  = @project_name
--         and  b.process_name  = @proc_name
--         and  b.component_name = @comp_name)


-- code added by Ganesh to update the error severity & the Detail Descr
update de_fw_des_error
set  detaileddesc = errormessage
where customer_name = @customer_name
and  project_name = @project_name
and  process_name = @proc_name
and  componentname =  @comp_name


-- code modified by Ganesh on 15/06/05 for the bugid ::: PNR2.0_2911

update de_fw_des_err_det_local_info
set  errormessage =  b.errormessage,
detaileddesc = b.errormessage
from de_fw_des_err_det_local_info  a (nolock),
de_fw_des_error     b (nolock),
es_language_met     c (nolock)  where a.customer_name = @customer_name
and  a.project_name = @project_name
and  a.process_name = @proc_name
and  a.component_name=  @comp_name
and  a.customer_name = b.customer_name
and  a.project_name = b.project_name
and  a.process_name = b.process_name
and  a.component_name=  b.componentname
and  a.errorid  =  b.errorid
and  quick_code_type =  'language_code'
and  quick_code_value=  'English'
and  quick_code  =  langid

delete from de_fw_des_focus_control
where customer_name = @customer_name
and  project_name = @project_name
and  process_name = @proc_name
and  component_name =  @comp_name

delete from de_fw_req_ilbo_task_rpt
where customer_name = @customer_name
and  project_name = @project_name
and  process_name = @proc_name
and  component_name =  @comp_name

-- added by feroz for report task
insert into de_fw_req_ilbo_task_rpt
(customer_name, project_name, process_name, component_name, activity_name, ilbocode, taskname, Pagename, reporttype, processingtype,
ContextName, createdby, createddate, modifiedby, modifieddate)
select  customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, report_page, report_type, processing_type,
report_context, @ctxt_user, getdate(), @ctxt_user, getdate()
from  de_report_attributes (nolock)
where customer_name = @customer_name
and  project_name = @project_name
and  process_name = @proc_name
and  component_name =  @comp_name
--code added for bugid: PLF2.0_07676 starts
union
select  distinct customer_name, project_name, process_name, component_name, activity_name, ui_name, task_name, report_page, 'crystal', '0',
report_context, @ctxt_user, getdate(), @ctxt_user, getdate()
from  de_sp_report_action_segment (nolock)
where customer_name = @customer_name
and  project_name = @project_name
and  process_name = @proc_name
and  component_name =  @comp_name
--code added for bugid: PLF2.0_07676 ends

-- Code commented and modified for PNR2.0_20359 on 15-Jan-2009

-- added by feroz for populating focus control table
--insert into de_fw_des_focus_control
--(customer_name, project_name, process_name, component_name, errorcontext, errorid, controlid, segmentname, focusdataitem,
--createdby, createddate, modifiedby, modifieddate)
--select  distinct a.customer_name, a.project_name, a.process_name, a.component_name, b.servicename, a.errorid, c.controlid, c.segmentname, c.control_bt_synonym,
--@ctxt_user, @getdate, @ctxt_user, @getdate
--from  de_fw_des_brerror     a (nolock),
--de_fw_des_processsection_br_is   b (nolock),
--de_fw_des_ilbo_service_view_datamap c (nolock),
--de_fw_des_service_dataitem   d (nolock)
--where a.customer_name  = @customer_name
--and  a.project_name  = @project_name
--and  a.process_name  = @proc_name
--and  a.component_name = @comp_name
--and  a.customer_name  = b.customer_name
--and  a.project_name  = b.project_name
--and  a.process_name   = b.process_name
--and  a.component_name  = b.component_name
--and  a.customer_name  = c.customer_name
--and  a.project_name  = c.project_name
--and  a.process_name   = c.process_name
--and  a.component_name  = c.component_name
--and  a.customer_name  = d.customer_name
--and  a.project_name  = d.project_name
--and  a.process_name   = d.process_name
--and  a.component_name  = d.component_name
--and  a.methodid     = b.methodid
--and  a.error_context   = c.controlid + ' - ' + c.viewname
--and  b.servicename     = c.servicename
--and  c.segmentname   = d.segmentname
--and  c.servicename     = d.servicename
--and  c.dataitemname  = d.dataitemname
--and  d.flowattribute  in( 0, 2)
--and  not exists (select 'x'
--from  de_fw_des_focus_control e (nolock)
--where  e.customer_name  = b.customer_name
--and  e.project_name  = b.project_name
--and  e.process_name   = b.process_name
--and  e.component_name  = b.component_name
--and  e.errorcontext     = b.servicename
--and  e.segmentname  = c.segmentname
--and  e.errorid    = a.errorid
--and  e.controlid   = c.controlid
--and  e.focusdataitem  = c.control_bt_synonym)

insert into de_fw_des_focus_control
(customer_name, project_name, process_name, component_name, errorcontext, errorid, controlid, segmentname, focusdataitem,
createdby, createddate, modifiedby, modifieddate)
select  distinct a.customer_name, a.project_name, a.process_name, a.component_name, b.servicename, a.errorid, c.controlid, c.segmentname, c.dataitemname, --code modified for Bug ID:PLF2.0_00194
@ctxt_user, @getdate, @ctxt_user, @getdate
from  de_fw_des_brerror     a (nolock),
de_fw_des_processsection_br_is   b (nolock),
de_fw_des_service_dataitem   d (nolock),
de_fw_des_ilbo_service_view_datamap c (nolock)

where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name

and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name   = b.process_name
and  a.component_name  = b.component_name
and  a.methodid     = b.methodid

and  b.customer_name  = d.customer_name
and  b.project_name  = d.project_name
and  b.process_name   = d.process_name
and  b.component_name  = d.component_name
and  b.servicename     = d.servicename

and  d.customer_name  = c.customer_name
and  d.project_name  = c.project_name
and  d.process_name   = c.process_name
and  d.component_name  = c.component_name
and  d.servicename     = c.servicename
and  d.segmentname   = c.segmentname
and  d.dataitemname  = c.dataitemname

and  a.error_context   = d.segmentname + ' - ' + d.dataitemname

and  d.flowattribute  in( 0, 2)

and  not exists ( select 'x'
from  de_fw_des_focus_control e (nolock)
where  e.customer_name  = b.customer_name
and  e.project_name  = b.project_name
and  e.process_name   = b.process_name
and  e.component_name  = b.component_name
and  e.errorcontext     = b.servicename
and  e.segmentname  = c.segmentname
and  e.errorid    = a.errorid
and  e.controlid   = c.controlid
and  e.focusdataitem  = c.control_bt_synonym )

--code added for PNR2.0_21544 on 18-Mar-2009 - Begins

Update d
Set  	--process_selrows = isnull(a.proc_sel_rows,'N'),
/*process_selrows = case when (a.proc_sel_rows = 'Y' and a.sys_proc_sel_rows='Y') then a.sys_proc_sel_rows
								 when  a.sys_proc_sel_rows='Y' then a.sys_proc_sel_rows
								 else isnull(a.proc_sel_rows,'N')
						  end ,
process_updrows =	case when (a.process_updrows = 'Y' and a.sys_process_updrows='Y') then a.sys_process_updrows
						    when         a.sys_process_updrows='Y' then a.sys_process_updrows
								 else isnull(a.process_updrows,'N')
						  end */
process_selrows = case when (a.proc_sel_rows = 'Y' and a.sys_proc_sel_rows='Y') then 'SY'
								 when  a.sys_proc_sel_rows='Y' then 'SY'
								 else isnull(a.proc_sel_rows,'N')
						  end ,
process_updrows =	case when (a.process_updrows = 'Y' and a.sys_process_updrows='Y') then 'SY'
						    when         a.sys_process_updrows='Y' then 'SY'
								 else isnull(a.process_updrows,'N')
						  end ,
process_selupdrows =	case when (a.sys_proc_selupd_rows='Y') then 'sy'
						        else isnull(a.sys_proc_selupd_rows,'N')
						  end 
from   es_comp_task_type_mst    a(nolock),
de_action     b(nolock),
de_task_service_map   c(nolock),
de_fw_des_service_segment d(nolock),
de_fw_des_service_dataitem e (nolock)
where  a.customer_name   =  @customer_name
and  a.project_name   =  @project_name
and  a.req_no   = 'Base'
and  a.process_name   =  @proc_name
and  a.component_name  =  @comp_name
and  a.customer_name   =  b.customer_name
and  a.project_name   =  b.project_name
and  a.process_name   =  b.process_name
and  a.component_name =  b.component_name
and     a.task_type_name    =  b.task_pattern
and  b.customer_name   =  c.customer_name
and  b.project_name   =  c.project_name
and  b.process_name   =  c.process_name
and  b.component_name =  c.component_name
and     b.activity_name    =  c.activity_name
and     b.ui_name     =  c.ui_name
and  b.task_name   = c.task_name
and  c.customer_name   =  d.customer_name
and  c.project_name   =  d.project_name
and  c.process_name   =  d.process_name
and  c.component_name =  d.component_name
and     c.service_name    =  d.servicename
and		d.instanceflag	= '1'
and	 d.customer_name   =	e.customer_name
and  d.project_name   =		e.project_name
and  d.process_name   =		e.process_name
and  d.component_name =		e.component_name
and  d.servicename    =	e.servicename
and	 d.segmentname		=	e.segmentname
and	 e.dataitemname	=	'modeflag'

--code added for PNR2.0_21544 on 18-Mar-2009 - Ends

-- Start Code added by Feroz for List edit

update de_fw_req_ilbo_view
set  listedit  = NULL
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  isnull(listedit, '') <> ''

update de_fw_req_ilbo_control
set  listedit  = NULL
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  isnull(listedit, '') <> ''

-- For List edit
update a
set  listedit  = 'Y'
from de_fw_req_ilbo_view  a (nolock),
de_listedit_control_map b (nolock),
de_ui_grid    c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.control_bt_synonym = b.mapped_bt_synonym

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.page_bt_synonym =  b.page_bt_synonym
and  c.section_bt_synonym = b.section_bt_synonym
and  c.column_bt_synonym = b.mapped_bt_synonym


update a
set  listedit  = 'Y'
from de_fw_req_ilbo_control a (nolock),
de_listedit_control_map b (nolock),
de_ui_control   c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.control_bt_synonym = b.mapped_bt_synonym

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.page_bt_synonym =  b.page_bt_synonym
and  c.section_bt_synonym = b.section_bt_synonym
and  c.control_bt_synonym = b.mapped_bt_synonym


update a
set  a.listedit  = 'Y',
a.type  = 'RSListEdit' -- Modified By Feroz For Bug id : PNR2.0_23650
from de_fw_req_ilbo_control a (nolock),
de_listedit_column  b (nolock),
de_ui_grid    c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.control_bt_synonym = b.listedit_synonym
and  a.controlid    = b.listedit_controlid

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.control_bt_synonym = b.listedit_synonym
and  c.column_bt_synonym =  b.listedit_column_synonym


-- For Date Highlight
update a
set  listedit  = 'Y'
from de_fw_req_ilbo_view    a (nolock),
de_date_highlight_control_map b (nolock),
de_ui_grid      c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.control_bt_synonym = b.control_bt_synonym

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.page_bt_synonym =  b.page_bt_synonym
and  c.section_bt_synonym = b.section_bt_synonym
and  c.column_bt_synonym = b.control_bt_synonym

update a
set  listedit  = 'Y'
from de_fw_req_ilbo_control   a (nolock),
de_date_highlight_control_map b (nolock),
de_ui_control     c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.control_bt_synonym = b.control_bt_synonym

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.page_bt_synonym =  b.page_bt_synonym
and  c.section_bt_synonym = b.section_bt_synonym
and  c.control_bt_synonym = b.control_bt_synonym


update a
set  a.listedit  = 'Y',
a.type  = 'RSListEdit' -- Modified By Feroz For Bug id : PNR2.0_23650
from de_fw_req_ilbo_control   a (nolock),
de_date_highlight_control_map b (nolock),
de_ui_grid      c (nolock)
where a.customer_name  =  @customer_name
and  a.project_name  =  @project_name
and  a.process_name  =  @proc_name
and  a.component_name =  @comp_name

and  a.customer_name  =  b.customer_name
and  a.project_name  =  b.project_name
and  a.process_name  =  b.process_name
and  a.component_name =  b.component_name
and     a.ilbocode   =  b.ui_name
and  a.control_bt_synonym = b.listedit_synonym
and  a.controlid    = b.listedit_controlid

and  c.customer_name  =  b.customer_name
and  c.project_name  =  b.project_name
and  c.process_name  =  b.process_name
and  c.component_name =  b.component_name
and  c.activity_name  =  b.activity_name
and     c.ui_name   =  b.ui_name
and  c.control_bt_synonym = b.listedit_synonym
--  and  c.column_bt_synonym =  b.listedit_column_synonym

Declare @IsGlance			ngplf_name ,
		@tmp_process_name	ngplf_name,
		@tmp_component_name ngplf_name--,
		--@tmp_activity_name	ngplf_name,
		--@tmp_ui_name		ngplf_name

	select	@tmp_process_name   =	process_name,
			@tmp_component_name	=	component_name,
			@tmp_activity_name	=	activity_name,
			@tmp_ui_name		=	ui_name
	from	de_ui_ico (nolock)
	where	customer_name		=	@customer_name
	and		project_name		=	@project_name
	and		ico_no				=	@ico_no

	select	@IsGlance = isnull(IsGlance,'N')
	from ep_ui_mst a(nolock)
	where	a.customer_name			= @customer_name
	and		a.project_name			= @project_name
	and		a.process_name			= @tmp_process_name
	and		a.component_name		= @tmp_component_name
	and		a.activity_name			= @tmp_activity_name
	and		a.ui_name				= @tmp_ui_name
	
--If @IsGlance <> 'Y'
--Begin

		update b
	set  b.viewname = a.controlid + b.viewname
	from de_fw_req_ilbo_control a (nolock),
	de_fw_req_ilbo_view  b (nolock),
	ep_ui_mst c(nolock)
	where a.customer_name  =  @customer_name
	and  a.project_name  =  @project_name
	and  a.process_name  =  @proc_name
	and  a.component_name =  @comp_name
	and  a.customer_name  =  b.customer_name
	and  a.project_name  =  b.project_name
	and  a.process_name  =  b.process_name
	and  a.component_name =  b.component_name
	and  a.ilbocode   =  b.ilbocode
	and  a.controlid   =  b.controlid
		and  a.listedit   = 'Y'
	and  a.type    = 'RSListEdit'	 -- Modified By Feroz For Bug id : PNR2.0_23650
	and  a.customer_name  =  c.customer_name --code added by kiruthika for listedit issue
	and  a.project_name   =  c.project_name
	and  a.process_name   =  c.process_name
	and  a.component_name =  c.component_name
	and  a.ilbocode       =  c.ui_name
	and  isnull(c.IsGlance,'N') <> 'Y'
	
	
	update a
	set  a.viewname = b.viewname
	from de_fw_des_ilbo_service_view_datamap a (nolock),
	de_fw_req_ilbo_view  b (nolock),
	de_fw_req_ilbo_control  c (nolock),
	ep_ui_mst d(nolock)
	where a.customer_name  =  @customer_name
	and  a.project_name  =  @project_name
	and  a.process_name  =  @proc_name
	and  a.component_name =  @comp_name
	
	and  a.customer_name  =  b.customer_name
	and  a.project_name  =  b.project_name
	and  a.process_name  =  b.process_name
	and  a.component_name =  b.component_name
	and     a.ilbocode   =  b.ilbocode
	and  a.page_bt_synonym  = b.page_bt_synonym
	and  a.control_bt_synonym = b.control_bt_synonym
	and  a.controlid   =  b.controlid
	
	and  c.customer_name  =  b.customer_name
	and  c.project_name  =  b.project_name
	and  c.process_name  =  b.process_name
	and  c.component_name =  b.component_name
	and     c.ilbocode   =  b.ilbocode
	and  c.controlid   =  b.controlid
	and  c.listedit   = 'Y'
	and  c.type    = 'RSListEdit' -- Modified By Feroz For Bug id : PNR2.0_23650
	and  a.customer_name  =  d.customer_name --code added by kiruthika for listedit issue
	and  a.project_name   =  d.project_name
	and  a.process_name   =  d.process_name
	and  a.component_name =  d.component_name
	and  a.ilbocode       =  d.ui_name
	and  isnull(d.IsGlance,'N') <> 'Y' 

--END

-- For non mapped Listedit
delete from de_fw_req_ilbo_view
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  ilbocode + '#' + controlid  in (
select  ui_name + '#' + listedit_controlid
from de_listedit_column  (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  activity_name + '#' +  ui_name + '#' + listedit_synonym   not in (select activity_name + '#' +  ui_name + '#' + listedit_synonym
from de_listedit_control_map (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name ))

delete from  de_fw_req_ilbo_control
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  ilbocode + '#' + controlid  in (
select  ui_name + '#' + listedit_controlid
from de_listedit_column  (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  activity_name + '#' +  ui_name + '#' + listedit_synonym   not in (select activity_name + '#' +  ui_name + '#' + listedit_synonym
from de_listedit_control_map (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name ))
-- Iszipped should be 1 for the report service- TECH-218
update	c
set		c.iszipped	=	1
from de_task_service_map a (nolock),de_action b(nolock),de_fw_des_service c (nolock)
where	c.Customer_Name		= @customer_name
and		c.Project_Name		= @project_name
and		c.Process_Name		= @proc_name
and		c.ComponentName		= @comp_name
and		a.customer_name		= b.customer_name
and		a.project_name		= b.project_name
and		a.process_name		= b.process_name
and		a.component_name	= b.component_name
and		a.activity_name		= b.activity_name
and		a.ui_name				= b.ui_name
and		a.task_name			= b.task_name
and		a.customer_name		= c.customer_name
and		a.project_name		= c.project_name
and		a.process_name		= c.process_name
and		a.component_name	= c.componentname
and		a.service_name		= c.servicename
and		b.task_type			= 'Report'
and  isnull(c.iszipped,0) ='' --13705  for TECH-72237
and     not exists (select 'X' from de_fw_des_service_segment d(nolock)
					where	d.customer_name		= c.customer_name
					and		d.project_name		= c.project_name
					and		d.process_name		= c.process_name
					and		d.component_name	= c.componentname 
					and     d.servicename		= c.servicename
					and     d.segmentname		in ('Rpttemplatecontext','RptFlatFileOut'))


-- End Code added by Feroz for Listedit

-- code commented by Ganesh for the bugid :: ECENG203SYS_000178 on 7/3/05
-- bugdecr ::Unable to Publish ECR. ECR downloaded. System hangs after clicking Publish Ecr Button. not able to proceed.

-- code is added in Unpublish ECR

-- code added by Ganesh on 26/7/04
-- CALLING the de Publish table deletion
--  exec engg_publish_ecr_req_des_remove_sp @ctxt_language,
--            @ctxt_ouinstance,
--            @ctxt_service ,
--            @ctxt_user,
--            @customer_name,
--            @project_name,
--            @proc_name,
--            @comp_name,
--            @ico_no,
--            @m_errorid output

-- code added by Ganesh on 26/7/04
-- CALLING the de Publish req table insertion
exec engg_publish_ecr_req_move_sp   @ctxt_language,
@ctxt_ouinstance,
@ctxt_service ,
@ctxt_user,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,
@m_errorid output

-- code added by Ganesh on 26/7/04
-- CALLING the de Publish des table insertion
exec engg_publish_ecr_des_move_sp @ctxt_language,
@ctxt_ouinstance,
@ctxt_service ,
@ctxt_user,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,
@m_errorid output

-- code commented by Ganesh for the bugid :: ECENG203SYS_000178 on 7/3/05
-- bugdecr ::Unable to Publish ECR. ECR downloaded. System hangs after clicking Publish Ecr Button. not able to proceed.

-- code is added in Unpublish ECR
--  exec de_published_delete_sp_ecr @ctxt_ouinstance,
--          @ctxt_user,
--          @ctxt_language,
--          @ctxt_service,
--          @customer_name,
--          @project_name,
--          @proc_name,
--          @ico_no,
--          @m_errorid output


exec de_published_ins_sp_ecr  @ctxt_ouinstance,
@ctxt_user,
@ctxt_language,
@ctxt_service,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,
@m_errorid output

--code added for bug id TECH-55700
Declare @de_fw_req_publish_ilbo_control_property Table 
	(customername varchar(60),projectname varchar(60),processname varchar(60),componentname varchar(60),ecrno varchar(60),controlid varchar(64),
	ilbocode varchar(200),propertyname varchar(64),viewname varchar(64),type varchar(20),value varchar(510),control_bt_synonym varchar(60),page_bt_synonym varchar(60)

	PRIMARY KEY (customername, projectname, ecrno, processname, componentname, controlid, ilbocode, propertyname, viewname))
	
INSERT INTO @de_fw_req_publish_ilbo_control_property
	(customername,projectname,processname,componentname,ecrno,controlid,ilbocode,propertyname,viewname,type,value,control_bt_synonym,page_bt_synonym)				 
SELECT 
	customername,projectname,processname,componentname,ecrno,controlid,ilbocode,propertyname,viewname,type,value,control_bt_synonym,page_bt_synonym
FROM	de_fw_req_publish_ilbo_control_property  b WITH(NOLOCK)		
WHERE	  b.customername  = @customer_name
and		  b.projectname   = @project_name
and		  b.ecrno         = @ico_no
and       b.processname   = @proc_name
and       b.componentname = @comp_name


insert into de_fw_des_publish_task_segment_attribs
(  customername,  projectname,  ecrno,   processname,
componentname,  activityid,   ilbocode,  taskname,
servicename,  segmentname,  combofill,  displayflag,
timestamp,   createdby,   createddate, modifiedby,
modifieddate)
select a.customer_name, a.project_name,  b.ecrno,  a.process_name,
a.component_name, a.activityid,   a.ilbocode,  a.taskname,
a.servicename,  a.segmentname,  1,    d.displayflag,
1,     @ctxt_user,   @getdate,  @ctxt_user,
@getdate
from de_fw_des_ilbo_service_view_datamap  a (nolock),
@de_fw_req_publish_ilbo_control_property b ,
de_fw_req_ilbo_control     c (nolock),
de_fw_req_ilbo_view      d (nolock)
where a.customer_name  = b.customername
and  a.project_name  = b.projectname
and  a.process_name  = b.processname
and  a.component_name = b.componentname
and  a.ilbocode   = b.ilbocode
and  a.controlid   = b.controlid
and  a.viewname   = b.viewname

and  b.propertyname   = 'ColumnType'
and  b.value    = 'ComboBox'

and  c.customer_name  = a.customer_name
and  c.project_name  = a.project_name
and  c.process_name  = a.process_name
and  c.component_name = a.component_name
and  c.ilbocode   = a.ilbocode
and  c.controlid   = a.controlid
and  c.type    in ('RSGrid','RSTreeGrid') -- Code added for defect id TECH-49490

and  d.customer_name  = a.customer_name
and  d.project_name  = a.project_name
and  d.process_name  = a.process_name
and  d.component_name = a.component_name
and  d.ilbocode   = a.ilbocode
and  d.controlid   = a.controlid
and  d.viewname   = a.viewname
and  d.displayflag  = 'T'

and  b.customername  = @customer_name
and  b.projectname  = @project_name
and  b.ecrno    = @ico_no
and  b.processname  = @proc_name
and  b.componentname  = @comp_name

and    exists( select  'x'
from  de_fw_des_ilbo_service_view_datamap dm (nolock),
de_fw_req_ilbo_view     ctl (nolock)
where dm.customer_name  = a.customer_name
and  dm.project_name   = a.project_name
and  dm.process_name   = a.process_name
and  dm.component_name  = a.component_name
and  dm.ilbocode    = a.ilbocode
and  dm.servicename   = a.servicename
and  dm.taskname    = a.taskname
and  dm.segmentname   = a.segmentname

and  dm.customer_name  = ctl.customer_name
and  dm.project_name   = ctl.project_name
and  dm.process_name   = ctl.process_name
and  dm.component_name  = ctl.component_name
and  dm.ilbocode    = ctl.ilbocode
and  dm.controlid   = ctl.controlid
and  dm.viewname    = ctl.viewname
group by dm.customer_name,  dm.project_name,  dm.process_name ,
dm.component_name, dm.ilbocode,  dm.segmentname,dm.viewname
--ctl.customer_name, ctl.project_name, ctl.process_name,
--ctl.component_name,ctl.ilbocode,  ctl.viewname
having count(*) = 1)
and  not exists (
select 'x'
from de_fw_des_ilbo_service_view_datamap vd (nolock),
@de_fw_req_publish_ilbo_control_property  cp 
where vd.customer_name = a.customer_name
and  vd.project_name  = a.project_name
and  vd.process_name  = a.process_name
and  vd.component_name = a.component_name
and  vd.ilbocode   = a.ilbocode
and  vd.servicename  = a.servicename --code added by kiruthika for combo filling issue
and  vd.taskname    = a.taskname
and  vd.segmentname   = a.segmentname

and  cp.customername  = vd.customer_name
and  cp.projectname  = vd.project_name
and  cp.ecrno   = @ico_no
and  cp.processname  = vd.process_name
and  cp.componentname = vd.component_name
and  cp.ilbocode   = vd.ilbocode
and  cp.controlid  = vd.controlid
and  cp.viewname   = vd.viewname

and  cp.propertyname  = 'ColumnType'
and  cp.value    <> 'ComboBox')

group by a.customer_name,  a.project_name, b.ecrno,  a.process_name,
a.component_name, a.activityid,  a.ilbocode,  a.taskname,
a.servicename,  a.segmentname, a.controlid, d.displayflag
having count(*) = 1
union
select b.customer_name, b.project_name,  @ico_no,  b.process_name,
b.component_name,  b.activityid,   b.ilbocode,  b.taskname,

b.servicename,  b.segmentname,  1,    'T',
1,     @ctxt_user,   @getdate,  @ctxt_user,
@getdate
from de_fw_des_service_segment   a (nolock),
de_fw_des_ilbo_service_view_datamap b (nolock),
de_ui_control      c (nolock),
es_comp_ctrl_type_mst    d (nolock)
where b.customer_name  = a.customer_name
and  b.project_name  = a.project_name
and  b.process_name  = a.process_name
and  b.component_name = a.component_name
and  b.servicename  = a.servicename
and  b.segmentname  = a.segmentname

and  c.customer_name  = b.customer_name
and  c.project_name  = b.project_name
and  c.process_name  = b.process_name
and  c.component_name = b.component_name
and  c.ui_name   = b.ilbocode
and  c.control_id  = b.controlid
and  c.view_name   = b.viewname

and  d.customer_name  = c.customer_name
and  d.project_name  = c.project_name
and  d.process_name  = c.process_name
and  d.component_name = c.component_name
and  d.ctrl_type_name = c.control_type
and  d.base_ctrl_type = 'Combo'

and  a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name
and  a.instanceflag  = 1

group by  b.customer_name, b.project_name, b.process_name, b.component_name,
b.activityid,   b.ilbocode,  b.taskname,  b.servicename,
b.segmentname
having count(*) = 1

end

-- added By feroz for list edit

insert into de_fw_des_publish_task_segment_attribs
(  customername,  projectname,  ecrno,   processname,
componentname,  activityid,   ilbocode,  taskname,
servicename,  segmentname,  combofill,  displayflag,
timestamp,   createdby,   createddate, modifiedby,
modifieddate)
select distinct a.customer_name, a.project_name,  b.ecrno,  a.process_name,
a.component_name, a.activityid,   a.ilbocode,  a.taskname,
a.servicename,  a.segmentname,  1,    d.displayflag,
1,     @ctxt_user,   @getdate,  @ctxt_user,
@getdate
from de_fw_des_ilbo_service_view_datamap  a (nolock),
@de_fw_req_publish_ilbo_control_property b ,
de_fw_req_ilbo_control     c (nolock),
de_fw_req_ilbo_view      d (nolock),
de_fw_des_service_segment e(nolock) --code added by kiruthika for combo filling issue
,de_ui f(nolock)
where e.customer_name  = a.customer_name
and  e.project_name  = a.project_name
and  e.process_name  = a.process_name
and  e.component_name = a.component_name
and  e.servicename    = a.servicename
and  e.segmentname    = a.segmentname
and  e.instanceflag = 1 
and  c.customer_name  = a.customer_name
and  c.project_name  = a.project_name
and  c.process_name  = a.process_name
and  c.component_name = a.component_name
and  c.ilbocode   = a.ilbocode
and  c.controlid   = a.controlid
and  c.type    = 'RSListEdit'       -- Modified By Feroz For Bug id : PNR2.0_23650
and  d.customer_name  = a.customer_name
and  d.project_name  = a.project_name
and  d.process_name  = a.process_name
and  d.component_name = a.component_name
and  d.ilbocode   = a.ilbocode
and  d.controlid   = a.controlid
and  d.viewname   = a.viewname

and  b.customername  = a.customer_name
and  b.projectname  = a.project_name
and  b.processname  = a.process_name
and  b.componentname  = a.component_name
and  b.ilbocode   = a.ilbocode
and  b.controlid   = a.controlid
and  b.controlid + b.viewname = a.viewname -- commented by JL on 03 jan 20 -- 11537
--and  b.viewname = a.viewname -- Added by JL on 03 jan 20
and  b.propertyname  = 'ColumnType'
and  d.displayflag  = 'T'

and  f.customer_name  = a.customer_name
and  f.project_name  = a.project_name
and  f.process_name  = a.process_name
and  f.component_name = a.component_name
and	 f.activity_name  = a.activity_name
and  f.ui_name		= a.ilbocode
and	 isnull(f.IsGlance,'N') = 'N'

and  b.customername  = @customer_name
and  b.projectname  = @project_name
and  b.ecrno    = @ico_no
and  b.processname  = @proc_name
and  b.componentname  = @comp_name
and    exists( select  'x'
from de_fw_des_ilbo_service_view_datamap dm (nolock),
de_fw_req_ilbo_view     ctl (nolock)
where dm.customer_name = a.customer_name
and  dm.project_name  = a.project_name
and  dm.process_name  = a.process_name
and  dm.component_name = a.component_name
and  dm.ilbocode   = a.ilbocode
and  dm.servicename  = a.servicename
and  dm.taskname   = a.taskname
and  dm.segmentname  = a.segmentname

and  dm.customer_name = ctl.customer_name
and  dm.project_name  = ctl.project_name
and  dm.process_name  = ctl.process_name
and  dm.component_name = ctl.component_name
and  dm.ilbocode   = ctl.ilbocode
and  dm.controlid  = ctl.controlid
and  dm.viewname   = ctl.viewname
group by dm.customer_name,  dm.project_name,  dm.process_name ,
dm.component_name, dm.ilbocode,  dm.segmentname,dm.viewname
--ctl.customer_name, ctl.project_name, ctl.process_name,
--ctl.component_name,ctl.ilbocode,  ctl.viewname
having count(*) = 1)

--11537 glance combo filling

insert into de_fw_des_publish_task_segment_attribs
(  customername,  projectname,  ecrno,   processname,
componentname,  activityid,   ilbocode,  taskname,
servicename,  segmentname,  combofill,  displayflag,
timestamp,   createdby,   createddate, modifiedby,
modifieddate)

select distinct a.customer_name, a.project_name,  b.ecrno,  a.process_name,
a.component_name, a.activityid,   a.ilbocode,  a.taskname,
a.servicename,  a.segmentname,  1,    d.displayflag,
1,     @ctxt_user,   @getdate,  @ctxt_user,
@getdate
from de_fw_des_ilbo_service_view_datamap  a (nolock),
@de_fw_req_publish_ilbo_control_property b ,
de_fw_req_ilbo_control     c (nolock),
de_fw_req_ilbo_view      d (nolock),
de_fw_des_service_segment e(nolock),--code added by kiruthika for combo filling issue
de_ui f (nolock)
where e.customer_name  = a.customer_name
and  e.project_name  = a.project_name
and  e.process_name  = a.process_name
and  e.component_name = a.component_name
and  e.servicename    = a.servicename
and  e.segmentname    = a.segmentname
and  e.instanceflag = 1 
and  c.customer_name  = a.customer_name
and  c.project_name  = a.project_name
and  c.process_name  = a.process_name
and  c.component_name = a.component_name
and  c.ilbocode   = a.ilbocode
and  c.controlid   = a.controlid
and  c.type    = 'RSListEdit'       -- Modified By Feroz For Bug id : PNR2.0_23650
and  d.customer_name  = a.customer_name
and  d.project_name  = a.project_name
and  d.process_name  = a.process_name
and  d.component_name = a.component_name
and  d.ilbocode   = a.ilbocode
and  d.controlid   = a.controlid
and  d.viewname   = a.viewname

and  b.customername  = a.customer_name
and  b.projectname  = a.project_name
and  b.processname  = a.process_name
and  b.componentname  = a.component_name
and  b.ilbocode   = a.ilbocode
and  b.controlid   = a.controlid
--and  b.controlid + b.viewname = a.viewname -- commented by JL on 03 jan 20 -- 11537
and  b.viewname = a.viewname -- Added by JL on 03 jan 20
and  b.propertyname  = 'ColumnType'
and  d.displayflag  = 'T'

and  f.customer_name  = a.customer_name
and  f.project_name  = a.project_name
and  f.process_name  = a.process_name
and  f.component_name = a.component_name
and	 f.activity_name  = a.activity_name
and  f.ui_name		= a.ilbocode

and	 isnull(f.IsGlance,'N') = 'Y'

and  b.customername  = @customer_name
and  b.projectname  = @project_name
and  b.ecrno    = @ico_no
and  b.processname  = @proc_name
and  b.componentname  = @comp_name
and    exists( select  'x'
from de_fw_des_ilbo_service_view_datamap dm (nolock),
de_fw_req_ilbo_view     ctl (nolock)
where dm.customer_name = a.customer_name
and  dm.project_name  = a.project_name
and  dm.process_name  = a.process_name
and  dm.component_name = a.component_name
and  dm.ilbocode   = a.ilbocode
and  dm.servicename  = a.servicename
and  dm.taskname   = a.taskname
and  dm.segmentname  = a.segmentname

and  dm.customer_name = ctl.customer_name
and  dm.project_name  = ctl.project_name
and  dm.process_name  = ctl.process_name
and  dm.component_name = ctl.component_name
and  dm.ilbocode   = ctl.ilbocode
and  dm.controlid  = ctl.controlid
and  dm.viewname   = ctl.viewname
group by dm.customer_name,  dm.project_name,  dm.process_name ,
dm.component_name, dm.ilbocode,  dm.segmentname,dm.viewname
--ctl.customer_name, ctl.project_name, ctl.process_name,
--ctl.component_name,ctl.ilbocode,  ctl.viewname
having count(*) = 1)

delete from  de_fw_req_publish_ilbo_control_property
where customername  =  @customer_name
and  projectname   =  @project_name
and  ecrno    =  @ico_no
and  processname   =  @proc_name
and  componentname  =  @comp_name
and  ilbocode + '#' + controlid  in (
select  ui_name + '#' + listedit_controlid
from de_listedit_column  (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name
and  activity_name + '#' +  ui_name + '#' + listedit_synonym   not in (select activity_name + '#' +  ui_name + '#' + listedit_synonym
from de_listedit_control_map (nolock)
where customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name  =  @proc_name
and  component_name  =  @comp_name ))
-- Modified By feroz for bug id :PNR2.0_23545
update a
set  a.control_type = b.control_type
from de_ui_control a (nolock),
#de_ui_control b (nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.section_bt_synonym = b.section_bt_synonym
and  a.control_bt_synonym = b.control_bt_synonym
-- Modified By feroz for bug id :PNR2.0_23545
-- Modified By feroz for bug id :PNR2.0_23560
update a
set  a.control_type = b.control_type
from de_published_ui_control a (nolock),
#de_ui_control b (nolock)
where a.customer_name  = @customer_name
and  a.project_name  = @project_name
and  a.process_name  = @proc_name
and  a.component_name = @comp_name
and  a.ecrno    = @ico_no
and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name
and  a.page_bt_synonym = b.page_bt_synonym
and  a.section_bt_synonym = b.section_bt_synonym
and  a.control_bt_synonym = b.control_bt_synonym
-- Modified By feroz for bug id :PNR2.0_23560
-- added By feroz for list edit

-- Added by feroz for AVS
exec  avs_publish_ecr_message_validation
@ctxt_ouinstance,
@ctxt_user,
@ctxt_language,
@ctxt_service,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,
@m_errorid output


-- Added by Hemalatha.K for CVS
exec  cvs_publish_ecr_message_validation
@ctxt_ouinstance,
@ctxt_user,
@ctxt_language,
@ctxt_service,
@customer_name,
@project_name,
@proc_name,
@comp_name,
@ico_no,
@m_errorid output

-- Code added by Saravanan on 09/06/2005 for PNR2.0_2889 - To avoid multiple ECR publish - START
--Code added By Sangeetha L on 23-09-2005 for Entrie in Workflow Tables
Exec  ecr_publ_wrkflow_insert
@customer_name,
@project_name,
@ico_no

Delete from de_ecr_publish_chk
where ecr_no = @ico_no
and   work_flag  = 'P'
and   customer_name = @customer_name
and   project_name  = @project_name


-- Added  by Sangeetha G  for  PNR2.0_17846

exec  de_comp_doc_status_ins_sp  @customer_name , @project_name ,@proc_name ,@comp_name,@ico_no ,@ctxt_user,'P'


-- Code added by Saravanan on 09/06/2005 for PNR2.0_2889 - To avoid multiple ECR publish - END
--output parameters

						if exists ( select  'x'  -- code added by 11536 for the case id TECH-20631
					from	de_ui_ico(nolock)  
					where	customer_name		=	@customer_name  
					and		project_name		=	@project_name  
					and		ico_no				=	rtrim(@ico_no)  
					and		ico_status			=	'P'
					)  
					begin 

						Update	FW_NIA_GenDoc_Rcn_Ecr_ICO_temp 
						set		doc_status			=	'ECRPUB'
						where	Customerid			=	@customer_name
						and		Projectid			=	@project_name
						and		ECRNumber			=	rtrim(@ico_no) 

					End


-- NGPLF Changes Starts

Declare @tmp_prc	engg_name,
		@tmp_cmp	engg_name,
		@tmp_act	engg_name,
		@tmp_ui		engg_name,
		@ctxt_role	engg_name 

select	 @tmp_prc	=	a.process_name,
		 @tmp_cmp	=	a.component_name
from	de_ui_ico a(nolock)
where	a.customer_name		= @customer_name
and		a.project_name		= @project_name
and		a.ico_no			= @ico_no

--DECLARE	getui CURSOR FOR
--select	a.component_name, a.process_name,  a.activity_name,  a.ui_name	
--from	de_ui_ico a(nolock),
--		de_ui b(nolock)
--where	a.customer_name		= @customer_name
--and		a.project_name		= @project_name
--and		a.ico_no			= @ico_no

--and		b.customer_name		= a.customer_name
--and		b.project_name		= a.project_name
--and		b.process_name		= a.process_name
--and		b.component_name	= a.component_name
--and		b.activity_name		= a.activity_name
--and		b.ui_name			= a.ui_name
----and  b.current_req_no =  a.ico_no

--OPEN getui
--FETCH NEXT FROM getui into @tmp_cmp, @tmp_prc,	 @tmp_act, @tmp_ui
							
			
--WHILE @@FETCH_STATUS = 0
--BEGIN

			Exec ngplf_dcn_publish
								@ctxt_language,			@ctxt_ouinstance,			@ctxt_user,				@ctxt_role,			
								@customer_name,			@project_name,				@tmp_prc,				@tmp_cmp,				
								@EcrNumber	=	@ico_no


	--if @modeflag = 'Z'
	--begin
	
	--	select  @tmp_activity_name	=	a.activity_name,
	--			@tmp_ui_name		=	a.ui_name,
	--			@tmp_templateid		=	a.templateid
	--	from  de_mdcf_template_taskcontrol_map  a(nolock),
	--			de_task_control_map b (nolock)
	--	where  a.customer_name =  b.customer_name
	--	and a.project_name =  b.project_name
	--	--and a.process_name =  b.process_name
	--	and a.mapped_component= b.component_name
	--	and a.activity_name =  b.activity_name
	--	and a.ui_name		=  b.ui_name
	--	and	a.task_name		= b.action_name

	--	and b.customer_name =  @customer_name
	--	and b.project_name	=  @project_name
	--	and b.process_name = @tmp_prc
	--	and	b.component_name = @tmp_cmp
	--	and a.BT_synonym_name <> b.control_bt_synonym
	--	group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name,a.templateid
	--	having count(*) > 1


	--if isnull(@tmp_templateid,'') <> ''
	--begin
	--	select @msg = 'In an Template :'+'"'+@tmp_templateid+'"'+' under the activity '+'"'+@tmp_activity_name+'"'+', UI'+ '"'+@tmp_ui_name+ '"'+' some of the controls are deleted/Added. Please check the Manage MDCF Template UI.' 
	--	exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
	--	@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
	--	@ico_no, '', '', '', @m_errorid
	--	return
	--end

	--	select  @tmp_activity_name	=	a.activity_name,
	--			@tmp_ui_name		=	a.ui_name,
	--			@tmp_templateid		=	a.templateid
	--	from  de_mdcf_template_task  a(nolock),
	--			de_action b (nolock)
	--	where  a.customer_name =  b.customer_name
	--	and a.project_name =  b.project_name
	--	--and a.process_name =  b.process_name
	--	and a.mapped_component= b.component_name
	--	and a.activity_name =  b.activity_name
	--	and a.ui_name		=  b.ui_name
	--	and	a.task_name		<> b.task_name
	--	and b.task_type not in ('INIT', 'Fetch', 'Disposal')

	--	and b.customer_name =  @customer_name
	--	and b.project_name	=  @project_name
	--	and b.process_name = @tmp_prc
	--	and	b.component_name = @tmp_cmp
		
	--	group by a.customer_name, a.project_name, a.process_name, a.component_name, a.activity_name, a.ui_name,a.templateid
	--	having count(*) > 1


	--if isnull(@tmp_templateid,'') <> ''
	--begin
	--	select @msg = 'In an Template :'+'"'+@tmp_templateid+'"'+' under the activity '+'"'+@tmp_activity_name+'"'+', UI'+ '"'+@tmp_ui_name+ '"'+' some of the Tasks are deleted/Added. Please check the Manage MDCF Template UI.' 
	--	exec   engg_error_sp 'de_publ_sp_publico', 1, @msg,
	--	@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,
	--	@ico_no, '', '', '', @m_errorid
	--	return
	--end

--end
		
			--FETCH NEXT FROM getui into @tmp_cmp, @tmp_prc,	 @tmp_act, @tmp_ui
--END
--CLOSE getui
--DEALLOCATE getui

-- NGPLF Changes Ends

if @ico_descr not in  ('pubezeeview')  --code modified for PNR2.0_28333	
select  @fprowno    'fprowno'

set nocount off
End

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_publ_sp_publico' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_publ_sp_publico TO PUBLIC
END
GO
