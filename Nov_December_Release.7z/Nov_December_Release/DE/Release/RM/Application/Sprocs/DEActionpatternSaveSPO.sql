IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DEActionpatternSaveSPO' AND TYPE = 'P')
    Begin
        Drop PROC DEActionpatternSaveSPO
    End
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		DEActionpatternSaveSPO.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : DEActionpatternSaveSPO                                    */
/* Description  :                                                               */
/********************************************************************************/

CREATE PROCEDURE DEActionpatternSaveSPO
	@ctxt_ouinstance engg_ctxt_OUInstance, --Input 
	@ctxt_user engg_ctxt_User, --Input 
	@ctxt_language engg_ctxt_Language, --Input 
	@ctxt_service engg_ctxt_Service, --Input 
	@engg_cmbtaskt_met engg_name, --Input 
	@engg_cmbtask_patt engg_name, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_process_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_req_no engg_name, --Input 
	@engg_tasktxt_desc engg_description, --Input 
	@engg_tasttxt_docu engg_description, --Input 
	@guid engg_guid, --Input 
	@hidden_control1 engg_description, --Input 
	@engg_a_fprowno engg_RowNo, --Input/Output 
	@engg_k_fprowno engg_RowNo, --Input/Output 
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @engg_cmbtaskt_met = '~#~'
		SET @engg_cmbtaskt_met = NULL

	IF @engg_cmbtask_patt = '~#~'
		SET @engg_cmbtask_patt = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_process_descr = '~#~'
		SET @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_req_no = '~#~'
		SET @engg_req_no = NULL

	IF @engg_tasktxt_desc = '~#~'
		SET @engg_tasktxt_desc = NULL

	IF @engg_tasttxt_docu = '~#~'
		SET @engg_tasttxt_docu = NULL

	IF @guid = '~#~'
		SET @guid = NULL

	IF @hidden_control1 = '~#~'
		SET @hidden_control1 = NULL

	IF @engg_a_fprowno = - 915
		SET @engg_a_fprowno = NULL

	IF @engg_k_fprowno = - 915
		SET @engg_k_fprowno = NULL

	DECLARE @engg_process_name engg_name,
		@engg_comp_name engg_name

	SELECT TOP 1 @engg_process_name = process_name,
		@engg_comp_name = component_name
	FROM de_ui_ico(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND	ico_no		=	@engg_req_no
		AND process_descr = @engg_process_descr
		AND component_descr = @engg_component
	ORDER BY 1,
		2

	DELETE
	FROM es_ctrl_dtl_tmp
	WHERE guid = @hidden_control1

	IF NOT EXISTS (
			SELECT 'x'
			FROM es_ctrl_dtl_tmp(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND def_task_type = CASE 
					WHEN @engg_cmbtaskt_met = 'DoNotDefault'
						THEN 'dnd'
					ELSE @engg_cmbtaskt_met
					END
				AND task_type = @engg_cmbtask_patt
				AND user_id = @ctxt_user
				AND guid = @hidden_control1
			)
	BEGIN
		INSERT INTO es_ctrl_dtl_tmp (
			customer_name,
			project_name,
			process_name,
			component_name,
			task_type,
			def_task_type,
			user_id,
			guid,
			ctrl_req,
			task_properties,
			enumerated_task_value,
			task_enum_value
			)
		SELECT DISTINCT @engg_customer_name,
			@engg_project_name,
			@engg_process_name,
			@engg_comp_name,
			@engg_cmbtask_patt,
			quick_code,
			@ctxt_user,
			@hidden_control1,
			0,
			quick_code_value,
			CASE 
				WHEN quick_code_value IN ('No of Place Holders')
					THEN '0'
				ELSE NULL
				END,
			CASE 
				WHEN quick_code_value IN ('No of Place Holders')
					THEN b.no_placeholder
				ELSE NULL
				END
		FROM es_ctrl_task_met a(NOLOCK),
			de_comp_task_type_mst b(NOLOCK)
		WHERE quick_code_type = 'task'
			AND task_type_name = @engg_cmbtask_patt
			AND customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @engg_process_name
			AND component_name = @engg_comp_name
	END

	UPDATE a
	SET a.task_req = CASE 
			WHEN a.task_properties = 'Clear On Page Save'
				AND b.clr_on_page_save = 'y'
				THEN 1
			WHEN a.task_properties = 'Combo Default Required'
				AND b.cbdef_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Conditional Multiline Fetch'
				AND b.cond_ml_fetch = 'y'
				THEN 1
			WHEN a.task_properties = 'Data Saving Task'
				AND b.data_save_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Header Fetch Required'
				AND b.hdr_fetch_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Header Save Required'
				AND b.hdr_save_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Include Message Place Holder'
				AND b.incl_place_holder = 'y'
				THEN 1
			WHEN a.task_properties = 'ML Save Required'
				AND b.ml_save_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Multiline Fetch Required'
				AND b.ml_fet_req = 'y'
				THEN 1
			WHEN a.task_properties = 'ML Singlesegment Required'
				AND b.MLSaveSinglesegment = 'y'
				THEN 1
			WHEN a.task_properties = 'Process only Selected Rows'
				AND b.proc_sel_rows = 'y'
				THEN 1
			WHEN a.task_properties = 'Process only Updated Rows'
				AND b.process_updrows = 'y'
				THEN 1 
			WHEN a.task_properties = 'Refresh On Save'
				AND b.refresh_on_save = 'y'
				THEN 1
			WHEN a.task_properties = 'Separate Header Refresh Method Required'
				AND b.hdr_ref_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Separate Method for Header Check Required'
				AND b.hdr_check_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Separate Method for Message Handling'
				AND b.err_handle_method = 'y'
				THEN 1
			WHEN a.task_properties = 'Should User Role to be Mapped to All Methods'
				AND b.usr_role_map = 'y'
				THEN 1
			WHEN a.task_properties = 'Task Conformation'
				AND b.task_confirmation = 'y'
				THEN 1
			WHEN a.task_properties = 'Logic Extensions'
				AND b.Logic_Extensions = 'y'
				THEN 1
			WHEN a.task_properties = 'Transaction Scope Required'
				AND b.trn_scope_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Validate On Initiate'
				AND b.valid_on_init = 'y'
				THEN 1
			WHEN a.task_properties = 'Fprowno Required'
				AND b.fprowno_req = 'y'
				THEN 1
			WHEN a.task_properties = 'Configure Alternate Database'
				AND b.alternate_db = 'y'
				THEN 1
			WHEN a.task_properties = 'System Process only Selected Rows'
				AND b.sys_proc_sel_rows = 'y'
				THEN 1
			WHEN a.task_properties = 'System Process only Updated Rows'
				AND b.sys_process_updrows = 'y'
				THEN 1
			WHEN a.task_properties = 'LinkAsUI Required'
				AND b.Linkasui = 'y'
				THEN 1
			WHEN a.task_properties = 'Uiastrans Required'
				AND b.Uiastrans = 'y'
				THEN 1
			WHEN a.task_properties = 'System Process only selected Updated Rows'
				AND b.sys_proc_selupd_rows = 'y'
				THEN 1
			WHEN a.task_properties = 'Current Context Parameters'
				AND b.CurrentContextInformation = 'y'
				THEN 1
			WHEN a.task_properties = 'Parent Context Parameters'
				AND b.ParentContextInformation = 'y'
				THEN 1
			WHEN a.task_properties = 'Modeflag Enabled'
				AND b.ModeflagEnabled = 'y'
				THEN 1
					
			WHEN a.task_properties = 'Bulk Validation'
				AND b.BulkValidation = 'y'
				THEN 1
					-- code ends	
			
			WHEN a.task_properties = 'Bubble Message'
				AND b.BubbleMessage = 'y'
				THEN 1
			
			ELSE 0
			END
	FROM es_ctrl_dtl_tmp a(NOLOCK),
		de_comp_task_type_mst b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @engg_process_name
		AND a.component_name = @engg_comp_name
		AND a.task_type = @engg_cmbtask_patt
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.task_type_name = a.task_type
		AND a.guid = @hidden_control1

	SELECT DISTINCT a.task_properties 'de_engg_task_descr',
		a.task_req 'de_engg_task_req'
	FROM es_ctrl_dtl_tmp a(NOLOCK),
		es_ctrl_task_met b(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @engg_process_name
		AND a.component_name = @engg_comp_name
		AND a.task_type = @engg_cmbtask_patt
		AND b.quick_code_type = 'task'
		AND isnull(a.enumerated_task_value, '#') = '#'
		AND a.guid = @hidden_control1
	
	UNION
	
	SELECT DISTINCT b.quick_code_value 'de_engg_task_descr',
		0 'de_engg_task_req'
	FROM es_ctrl_task_met b(NOLOCK)
	WHERE b.quick_code_type = 'task'
		AND b.quick_code_value <> 'No of Place Holders'
		AND quick_code = 'DND'
		AND b.quick_code_value NOT IN (
			SELECT DISTINCT a.task_properties
			FROM es_ctrl_dtl_tmp a(NOLOCK),
				es_ctrl_task_met b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.task_type = @engg_cmbtask_patt
				AND b.quick_code_type = 'task'
				AND quick_code = def_task_type
				AND isnull(a.enumerated_task_value, '#') = '#'
				AND a.guid = @hidden_control1
			)
	ORDER BY 'de_engg_task_req' DESC

	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DEActionpatternSaveSPO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON  DEActionpatternSaveSPO TO PUBLIC
END
GO