IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='engg_publish_ecr_des_move_sp' AND TYPE = 'P')
    Begin
        Drop PROC engg_publish_ecr_des_move_sp
    End
GO

/*******************************************************************************/    
/* procedure    : engg_publish_ecr_des_move_sp         */    
/* description  :                                                               */    
/********************************************************************************/    
/* project      :                                                               */    
/* version      : 4.0.00                                                        */    
/********************************************************************************/    
/* referenced   :                                                               */    
/* tables       :                                                               */    
/********************************************************************************/    
/* development history                                                          */    
/* author       :                                                               */    
/* date         :                   */    
/********************************************************************************/    
/* modification history                                                         */    
/********************************************************************************/    
/* Modified By  :    Date :       Description :  */    
/* Kiruthika R     13 Mar 2007     PNR2.0_12606  */    
/********************************************************************************/    
/* Modified By  :    Date :       Description :  */    
/* Sangeetha G    17-Aug-07    PNR2.0_14989  */    
/********************************************************************************/    
/* modified by   : Chanheetha N A        */    
/* date     : 17-nov-2007         */    
/* BugId    : PNR2.0_16023          */    
/************************************************************************/    
/* Modified By     : chanheetha n a          */    
/* Date      : 13-Nov-2008         */    
/* Bug ID     : PNR2.0_19951         */    
/* Description     : for handle changes         */    
/******************************************************************************/    
/* modified by  : Sangeetha G            */    
/* date    : 11-Feb-2011                                           */    
/* Bug Id   : PNR2.0_30127           */    
/* Modified for  : Feature  Release          */    
/****************************************************************************/    
/* modified by     : Balaji D               */    
/* modified on     : Dec 31 2011           */    
/* Bug ID      : PLF2.0_00214            */    
/* Case Desc     : Modelling for Zipped & Cached Services.    */    
/****************************************************************************/    
/* modified by     : Shakthi P               */    
/* modified on     : Jan 21 2013           */    
/* Bug ID      : PLF2.0_03173            */    
/* Case Desc     : update map flag while publishing      */    
/****************************************************************************/    
/* modified by     : Gankan G               */    
/* modified on     : July 22 2013           */    
/* Bug ID      : PLF2.0_05478            */    
/* Case Desc     : Code modified for new column addition     */    
/****************************************************************************/    
/* modified by  : Shakthi P               */    
/* date         : 26-FEB-2014                   */    
/* Bug ID  : PLF2.0_07676               */    
/* Description : Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool */    
/*Bar Hiding, Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator */    
/***************************************************************************************************/    
/* modified by  : Ganesh Prabhu S             */    
/* date         : Oct 10 2014                                                    */    
/* BugId        : PLF2.0_09035                                                   */    
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout in  layout level            */    
/***************************************************************************************************/    
/* modified by  : Loganayaki P                                                   */    
/* date         : Oct 18 2016                                                    */    
/* BugId        : TECH-218                                                  */    
/***************************************************************************************************/    
/* Modified by : Jeya Latha K/Ganesh Prabhu S for callid TECH-7349    */  
/* Modified on : 14-03-2017                */  
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */  
/* Modified By : Jeya Latha K Date: 01-Nov-2019 Defect ID:TECH-39534     */  
/***********************************************************************************/  
/***************************************************************************************************/    
/* modified by  : Ganesh Prabhu S                                                   */    
/* BugId        : TECH-36760                                                  */    
/***************************************************************************************************/   
/* modified by  : Venkatesan K	                                                   */    
/* BugId        : TECH-45828                                                */    
/***************************************************************************************************/    
/* Modified By : Jeya Latha K/ Venkatesan K Date: 17-AUG-2021 Defect ID:TECH-61144				   */
/* Description : New Feature--Task API Mapping													   */
/***************************************************************************************************/
/* Modified by	: Vimal Kumar R / Priyadharshini U												   */   
/* Modified on	: 13-04-2022																	   */   
/* DefectId     : TECH-68064																	   */    
/* Description	: Provision to specify PSR, PMR, PSMR in refine service in						   
			 	  design engineering and design service in design refinement.					   */  
/***************************************************************************************************/
/* Modified By	: Ponmalar A / Jeya Latha K														   */
/* Date			: 27-MAY-2022																	   */
/* Defect ID	: TECH-69327																	   */
/* Description	: Provision for modeling bubble message - 
				 display the multiple messages when we fire a task - Bubble message				   */
/***************************************************************************************************/
/* Modified by  : Priyadharshini U		Date: 01-Dec-2022  Defect ID	:TECH-75230				   */
/***************************************************************************************************/
create  PROCEDURE engg_publish_ecr_des_move_sp    
@ctxt_language				engg_ctxt_language,    
@ctxt_ouinstance			engg_ctxt_ouinstance,    
@ctxt_service				engg_ctxt_service,    
@ctxt_user					engg_ctxt_user,    
@customername				engg_name,    
@projectname				engg_name,    
@processname				engg_name,    
@componentname				engg_name,    
@publishedecrno				engg_name,    
@m_errorid					int output    
as    
    
declare @servicename_tmp  engg_name,    
@iscomponent_tmp engg_name    
begin    
    
set nocount on    
    
INSERT  INTO de_fw_des_publish_ilbo_ctrl_event    
(ecrno, customername, projectname, processname,    
componentname,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, taskname, methodname, createstubflag,    
upduser, updtime, viewname,control_bt_synonym,page_bt_synonym)  --chan    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, taskname, methodname, createstubflag,    
upduser, updtime, viewname,control_bt_synonym,page_bt_synonym    
FROM  de_fw_des_ilbo_ctrl_event (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_controlvalue    
(ecrno, customername, projectname, processname,    
componentname,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, variableno, iscontrol, controlname,    
viewname, variablename, upduser, updtime,    
ctrlevent_viewname, flowdirection,control_bt_synonym,page_bt_synonym) --chan    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, variableno, iscontrol, controlname,    
viewname, variablename, upduser, updtime, ctrlevent_viewname,    
flowdirection ,control_bt_synonym,page_bt_synonym    
FROM  de_fw_des_ilbo_controlvalue (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_action_group    
(ecrno, customername, projectname, processname,    
componentname,  ilbocode, groupcode, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  ilbocode, groupcode, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
upduser, updtime    
FROM  de_fw_des_ilbo_action_group (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_actions    
(ecrno, customername, projectname, processname,    
componentname,  ilbocode, groupcode, actionsequence,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, actionid, controlid, viewname,    
servicename, reqbrname, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  ilbocode, groupcode, actionsequence,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, actionid, controlid, viewname, servicename,    
reqbrname, upduser, updtime    
FROM  de_fw_des_ilbo_actions (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_actiongrp_task    
(ecrno, customername, projectname, processname,    
componentname,  activityid, taskname, ilbocode,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, groupcode, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  activityid, taskname, ilbocode,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, groupcode, upduser, updtime    
FROM  de_fw_des_ilbo_actiongrp_task (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_actiongrp_event    
(ecrno, customername, projectname, processname,    
componentname,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, activityid, groupcode, upduser,    
updtime, viewname)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, activityid, groupcode, upduser,    
updtime, viewname    
FROM  de_fw_des_ilbo_actiongrp_event (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
-- modified by Ganesh on 16/11/04 for the bugid ::: ECPF204ACC_000005    
INSERT  INTO de_fw_des_publish_error    
(ecrno, customername, projectname, processname,    
componentname,  errorid, displaytype, errorsource,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, reqerror, errormessage, detaileddesc,    
defaultseverity, defaultcorrectiveaction, upduser, updtime)    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name, a.process_name,    
a.componentname,  a.errorid, a.displaytype, a.errorsource,    
a.timestamp, a.createdby, a.createddate, a.modifiedby,    
a.modifieddate, a.reqerror, a.errormessage, a.detaileddesc,    
a.defaultseverity, a.defaultcorrectiveaction, a.upduser, a.updtime    
FROM  de_fw_des_error  a (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.componentname = @ComponentName    
    
-- MODIFIED BY FEROZ FOR GETTING ALL ERROR ID    
--  FROM  de_fw_des_error  a (nolock), 
--    de_fw_des_brerror b (nolock), 
--    de_fw_des_processsection_br_is c (nolock)    
--  WHERE  a.customer_name = @CustomerName    
--  AND   a.project_name  = @ProjectName    
--  AND   a.process_name  = @ProcessName    
--  AND   a.componentname = @ComponentName    
--  and  a.customer_name = b.customer_name    
--  and  a.project_name = b.project_name    
--  and  a.process_name = b.process_name    
--  and  a.componentname = b.component_name    
--  and  a.errorid  = b.errorid    
--  and  b.customer_name = c.customer_name    
--  and  b.project_name = c.project_name    
--  and  b.process_name = c.process_name    
--  and  b.component_name= c.component_name    
--  and  b.methodid  = c.methodid    
--  and  b.method_name = c.method_name    
    
-- condition added by Ganesh for the issue 'de_fw_des_publish_error_placeholder_fkey_de_fw_des_publish_error' on 17/11/04    
INSERT  INTO de_fw_des_publish_error_placeholder    
(ecrno, customername, projectname,  errorid,    
placeholdername, timestamp, createdby, createddate,    
modifiedby, modifieddate, upduser, updtime,    
processname, componentname)    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name,  a.errorid,    
a.placeholdername, a.timestamp, a.createdby, a.createddate,    
a.modifiedby, a.modifieddate, a.upduser, a.updtime,    
a.process_name,  a.component_name    
FROM  de_fw_des_error_placeholder a (nolock),    
de_fw_des_publish_error  b (nolock)    
WHERE  a.customer_name  = @CustomerName    
AND   a.project_name   = @ProjectName    
AND   a.process_name   = @ProcessName    
AND   a.component_name  = @ComponentName    
and  a.customer_name  = b.customername    
AND   a.project_name   = b.projectname    
AND   a.process_name   = b.processname    
AND   a.component_name  = b.componentname    
and  a.errorid   = b.errorid    
and  b.ecrno    = @PublishedEcrNo    
    
INSERT  INTO de_fw_des_publish_err_det_local_info    
(ecrno, customername, projectname,  errorid,    
langid, timestamp, createdby, createddate,    
modifiedby, modifieddate, errormessage, detaileddesc,    
upduser, updtime,  processname, componentname)    
SELECT  distinct    
@PublishedEcrNo,  a.customer_name, a.project_name,  a.errorid,    
a.langid, a.timestamp, a.createdby, a.createddate,    
a.modifiedby, a.modifieddate, a.errormessage, a.detaileddesc,    
a.upduser, a.updtime, a.process_name, a.component_name    
FROM  de_fw_des_err_det_local_info a (nolock),    
de_fw_des_brerror b (nolock),    
de_fw_des_processsection_br_is c (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.component_name = @ComponentName    
and  a.customer_name = b.customer_name    
and  a.project_name = b.project_name    
and  a.process_name = b.process_name    
and  a.component_name= b.component_name    
and  a.errorid  = b.errorid    
and  b.customer_name = c.customer_name    
and  b.project_name = c.project_name    
and  b.process_name = c.process_name    
and  b.component_name= c.component_name    
and  b.methodid  = c.methodid    
and  b.method_name = c.method_name    
    
INSERT  INTO de_fw_des_publish_svco    
(ecrno, customername, projectname, processname,    
componentname,  svconame, timestamp, createdby,    
createddate, modifiedby, modifieddate, svcodescription,    
svcoscope, svcotype, dllname, progid, upduser, updtime,Base_compname)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  svconame, timestamp, createdby,    
createddate, modifiedby, modifieddate, svcodescription,    
svcoscope, svcotype, dllname, progid, upduser, updtime ,componentname    
FROM  de_fw_des_svco (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_errbtn_local_info    
(ecrno, customername, projectname,  severityid,    
langid, timestamp, createdby, createddate,    
modifiedby, modifieddate, severitydesc, buttontext,    
upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name,  severityid,    
langid, timestamp, createdby, createddate,    
modifiedby, modifieddate, severitydesc, buttontext,    
upduser, updtime    
FROM  de_fw_des_errbtn_local_info (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
and  process_name = @processname    
and  component_name = @ComponentName    
   
-- code added by Ganesh on 28/10/04 to include the process name & component name    
INSERT  INTO de_fw_des_publish_context    
(ecrno, customername, projectname,   errorid,    
errorcontext, timestamp, createdby, createddate,    
modifiedby, modifieddate, severityid, correctiveaction,    
upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name,   errorid,    
errorcontext, timestamp, createdby, createddate,    
modifiedby, modifieddate, severityid, correctiveaction,    
upduser, updtime    
FROM  de_fw_des_context (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_corr_action_local_info    
(ecrno, customername, projectname,   errorid,    
errorcontext, langid, timestamp, createdby,    
createddate, modifiedby, modifieddate, correctiveaction,    
upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name,  errorid,    
errorcontext, langid, timestamp, createdby,    
createddate, modifiedby, modifieddate, correctiveaction,    
upduser, updtime    
FROM  de_fw_des_corr_action_local_info (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
    
/* Modified by Bakiaraj V on 18-jan-2005 for the bug id   : DEPF204ACC_000060    
bug desc : Addtion of Process Name in different tables.  */    
    
INSERT  INTO de_fw_des_publish_bro    
(ecrno, customername, projectname,    broname,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, brodescription, dllname, brotype,    
broscope, progid, clsid, clsname,    
upduser, updtime, systemgenerated, processname,componentname)    
SELECT   @PublishedEcrNo, customer_name, project_name,   broname,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, brodescription, dllname, brotype,    
broscope, progid, clsid, clsname,    
upduser, updtime, systemgenerated, @ProcessName ,@ComponentName    
FROM  de_fw_des_bro (nolock)    
WHERE  customer_name  = @CustomerName    
AND   project_name  = @ProjectName    
and  process_name  = @ProcessName    
AND   componentname  = @ComponentName    
    
INSERT  INTO de_fw_des_publish_segment    
(ecrno, customername, projectname, processname,    
componentname,  bocode, segmentname, instanceflag,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  bocode, segmentname, instanceflag,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, upduser, updtime    
FROM  de_fw_des_segment (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_service    
(ecrno, customername, projectname, processname,    
componentname,  servicename, servicetype, isintegser,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, statusflag, upduser, updtime,    
svconame, processingtype,remarks, iszipped, iscached, clearkey_pattern, setkey_pattern,	--Code Modified for the Bug ID:PLF2.0_00214  
isbubblemessage,  ApplyRefinements )     --TECH-69327	--TECH-75230
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
componentname,  servicename, servicetype, isintegser,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, statusflag, upduser, updtime,    
svconame, processingtype ,remarks, iszipped, iscached, clearkey_pattern, setkey_pattern, --Code Modified for the Bug ID:PLF2.0_00214    
isbubblemessage, ApplyRefinements	--TECH-69327	--TECH-75230
FROM  de_fw_des_service (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   componentname = @ComponentName    
    
-- Column process_selrows added  by Sangeetha G for  PNR2.0_14989    
    
INSERT  INTO de_fw_des_publish_service_segment    
(ecrno, customername, projectname, processname,    
componentname,  servicename, segmentname, instanceflag,    
mandatoryflag, timestamp, createdby, createddate,    
modifiedby, modifieddate, bocode, bosegmentname,    
parentsegmentname, upduser, updtime , process_selrows,process_updrows,
UPEComboFilling,process_selupdrows,ProcessingType )    --Code added for the DefectId Tech- 68064
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  servicename, segmentname, instanceflag,    
mandatoryflag, timestamp, createdby, createddate,    
modifiedby, modifieddate, bocode, bosegmentname,    
parentsegmentname, upduser, updtime ,process_selrows,process_updrows,--PLF2.0_05478   
UPEComboFilling,process_selupdrows, -- TECH-45828
ProcessingType	--Code added for the DefectId Tech- 68064
FROM  de_fw_des_service_segment (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_service_dataitem    
(ecrno, customername, projectname, processname,    
componentname,  servicename, segmentname, dataitemname,    
ispartofkey, mandatoryflag, flowattribute, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
defaultvalue, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  servicename, segmentname, dataitemname,    
ispartofkey, mandatoryflag, flowattribute, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
defaultvalue, upduser, updtime    
FROM  de_fw_des_service_dataitem (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_service_documentation    
(ecrno, customername, projectname, processname,    
componentname,  servicename, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
doctext, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  servicename, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
doctext, upduser, updtime    
FROM  de_fw_des_service_documentation (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_bo    
(ecrno, customername, projectname, processname,    
componentname,  bocode, timestamp, createdby,    
createddate, modifiedby, modifieddate, bodesc,    
statusflag, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
componentname,  bocode, timestamp, createdby,    
createddate, modifiedby, modifieddate, bodesc,    
statusflag, upduser, updtime    
FROM  de_fw_des_bo (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   componentname = @ComponentName    
    
-- code modified by feroz on 24/nov/2004 for bug id ECPF204SYS_000028    
    
INSERT  INTO de_fw_des_publish_dataitem    
(ecrno, customername, projectname, processname,    
componentname,  bocode, segmentname, dataitemname,    
ispartofkey, mandatoryflag, timestamp, createdby,    
createddate, modifiedby, modifieddate, parentbocode,    
ownersegmentname, originaldataitemname, defaultvalue, upduser,    
updtime)    
SELECT  @PublishedEcrNo, a.customer_name, a.project_name, a.process_name,    
a.component_name,  a.bocode, a.segmentname, a.dataitemname,    
a.ispartofkey, a.mandatoryflag, a.timestamp, a.createdby,    
a.createddate, a.modifiedby, a.modifieddate, a.parentbocode,    
a.ownersegmentname, a.originaldataitemname, a.defaultvalue, a.upduser,    
a.updtime    
FROM  de_fw_des_dataitem     a (nolock),    
de_fw_req_publish_bterm_synonym b (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name = @ProjectName    
AND   a.process_name = @ProcessName    
AND   a.component_name = @ComponentName    
and  a.customer_name = b.customername    
and  a.project_name = b.projectname    
and     a.process_name  = b.processname    
and  a.component_name = b.componentname    
and     a.dataitemname = b.btsynonym    
and  b.ecrno   = @publishedecrno    
and a.dataitemname <> 'ModeFlag'    
    
INSERT  INTO de_fw_des_publish_businessrule    
(ecrno, customername, projectname, processname,    
componentname,  methodid, accessesdatabase, operationtype,    
systemgenerated, timestamp, createdby, createddate,    
modifiedby, modifieddate, bocode, methodname,    
dispid, statusflag, broname, upduser,    
--code modified for the call id : PNR2.0_19951 starts    
updtime, isintegbr,btstring,btsynonymstring) --chan    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  methodid, accessesdatabase, operationtype,    
systemgenerated, timestamp, createdby, createddate,    
modifiedby, modifieddate, bocode, methodname,    
dispid, statusflag, broname, upduser,    
--code modified for the call id : PNR2.0_19951 starts    
updtime, isintegbr ,btstring,btsynonymstring --chan    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_businessrule (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_sp    
(ecrno, customername, projectname, processname,    
componentname,  methodid, timestamp, createdby,    
createddate, modifiedby, modifieddate, spname,    
upduser, updtime, sperrorprotocol,method_name)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  methodid, timestamp, createdby,    
createddate, modifiedby, modifieddate, spname,    
upduser, updtime, sperrorprotocol, method_name    
FROM  de_fw_des_sp (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_reqbr_desbr    
(ecrno, customername, projectname, processname,    
componentname,  reqbrname, methodid, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
upduser, updtime,method_name)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  reqbrname, methodid, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
upduser, updtime,method_name--chan    
FROM  de_fw_des_reqbr_desbr (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_brerror    
(ecrno, customername, projectname,   methodid,    
errorid, timestamp, createdby, createddate,    
modifiedby, modifieddate, upduser, updtime,    
--code modified for the call id : PNR2.0_19951 starts    
sperrorcode, processname, componentname, error_context,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name,  a.methodid,    
a.errorid, a.timestamp, a.createdby, a.createddate,    
a.modifiedby, a.modifieddate, a.upduser, a.updtime,    
--code modified for the call id : PNR2.0_19951 starts    
a.sperrorcode, a.process_name, a.component_name, a.error_context,a.method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_brerror     a (nolock),    
de_fw_des_processsection_br_is  c (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.component_name= @ComponentName    
and  a.customer_name = c.customer_name    
and  a.project_name = c.project_name    
and  a.process_name = c.process_name    
and  a.component_name= c.component_name    
and  a.methodid  = c.methodid    
and  a.method_name = c.method_name    
    
-- code modified by Ganesh on 3/11/04 for the bugid ::: ECPF204ACC_000004    
INSERT  INTO de_fw_des_publish_br_logical_parameter    
(ecrno, customername, projectname,   methodid,    
logicalparametername, timestamp, createdby, createddate,    
modifiedby, modifieddate, logicalparamseqno, recordsetname,    
rssequenceno, flowdirection, btname, spparametertype,    
--code modified for the call id : PNR2.0_19951 starts    
upduser, updtime, processname, componentname,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name,   a.methodid,    
a.logicalparametername, a.timestamp, a.createdby, a.createddate,    
a.modifiedby, a.modifieddate, a.logicalparamseqno, a.recordsetname,    
a.rssequenceno, a.flowdirection, a.btname, a.spparametertype,    
--code modified for the call id : PNR2.0_19951 starts    
a.upduser, a.updtime, a.process_name, a.component_name,a.method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_br_logical_parameter  a (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.component_name= @ComponentName    
    
    
INSERT  INTO de_fw_des_publish_br_documentation    
(ecrno, customername, projectname, processname,    
componentname,  methodid, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
--code modified for the call id : PNR2.0_19951 starts    
doctext, upduser, updtime,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  methodid, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
--code modified for the call id : PNR2.0_19951 starts    
doctext, upduser, updtime ,method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_br_documentation (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_bo_documentation    
(ecrno, customername, projectname, processname,    
componentname,  bocode, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
doctext, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  bocode, serialno, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
doctext, upduser, updtime    
FROM  de_fw_des_bo_documentation (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_be_placeholder   
(ecrno, customername, projectname,   methodid,    
placeholdername, errorid, timestamp, createdby,    
createddate, modifiedby, modifieddate, parametername,    
--code modified for the call id : PNR2.0_19951 starts    
upduser, updtime, processname, componentname,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name,   a.methodid,    
a.placeholdername, a.errorid, a.timestamp, a.createdby,    
a.createddate, a.modifiedby, a.modifieddate, a.parametername,    
--code modified for the call id : PNR2.0_19951 starts    
a.upduser, a.updtime, a.process_name, a.component_name,a.method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_be_placeholder a (nolock),    
de_fw_des_processsection_br_is  c (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.component_name= @ComponentName    
and  a.customer_name = c.customer_name    
and  a.project_name = c.project_name    
and  a.process_name = c.process_name    
and  a.component_name= c.component_name    
and  a.methodid  = c.methodid    
    
INSERT  INTO de_fw_des_publish_processsection    
(ecrno, customername, projectname, processname,    
componentname,  servicename, sectionname, sectiontype,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, sequenceno, controlexpression, processingtype,    
upduser, updtime)    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name, a.process_name,    
a.component_name,  a.servicename, a.sectionname, a.sectiontype,    
a.timestamp, a.createdby, a.createddate, a.modifiedby,    
a.modifieddate, a.sequenceno, a.controlexpression, a.processingtype,    
a.upduser, a.updtime    
FROM  de_fw_des_processsection   a (nolock)    
WHERE  a.customer_name  = @CustomerName    
AND   a.project_name   = @ProjectName    
AND   a.process_name   = @ProcessName   
AND   a.component_name  = @ComponentName    
    
INSERT  INTO de_fw_des_publish_processsection_br_is    
(ecrno, customername, projectname, processname,    
componentname,  servicename, sectionname, sequenceno,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, isbr, methodid, integservicename,    
controlexpression, connectivityflag, executionflag, upduser,    
updtime,method_name,SpecID,SpecName,SpecVersion,Path,OperationID,OperationVerb, QueryID,
UPEControlExpr)   --Code Added for Defect ID : TECH-39534   
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  servicename, sectionname, sequenceno,    
timestamp, createdby, createddate, modifiedby,    
modifieddate, isbr, methodid, integservicename,    
controlexpression, connectivityflag, executionflag,    
upduser, updtime ,method_name,SpecID,SpecName,Version,Path,OperationID,OperationVerb, QueryID,
UPEControlExpr --11536  --Code Added for Defect ID : TECH-39534  , TECH-45828 
FROM  de_fw_des_processsection_br_is (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_di_placeholder    
(ecrno, customername, projectname, processname,    
componentname,  servicename, sectionname, sequenceno,    
methodid, placeholdername, errorid, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
--code modified for the call id : PNR2.0_19951 starts    
segmentname, dataitemname, upduser, updtime,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  distinct @PublishedEcrNo, a.customer_name, a.project_name, a.process_name,    
a.component_name,  a.servicename, a.sectionname, a.sequenceno,    
a.methodid, a.placeholdername, a.errorid, a.timestamp,    
a.createdby, a.createddate, a.modifiedby, a.modifieddate,    
--code modified for the call id : PNR2.0_19951 starts    
a.segmentname, a.dataitemname, a.upduser, a.updtime ,a.method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_di_placeholder a (nolock),    
de_fw_des_processsection_br_is  c (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name  = @ProjectName    
AND   a.process_name  = @ProcessName    
AND   a.component_name= @ComponentName    
and  a.customer_name = c.customer_name    
and  a.project_name = c.project_name    
and  a.process_name = c.process_name    
and  a.component_name= c.component_name    
and  a.methodid  = c.methodid    
    
INSERT  INTO de_fw_des_publish_di_parameter    
(ecrno, customername, projectname, processname,    
componentname,  servicename, sectionname, sequenceno,    
parametername, timestamp, createdby, createddate,    
modifiedby, modifieddate, methodid, segmentname,    
--code modified for the call id : PNR2.0_19951 starts    
dataitemname, upduser, updtime,method_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  servicename, sectionname, sequenceno,    
parametername, timestamp, createdby, createddate,    
modifiedby, modifieddate, methodid, segmentname,    
--code modified for the call id : PNR2.0_19951 starts    
dataitemname, upduser, updtime ,method_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_di_parameter (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
-- Code modification for  PNR2.0_30127 starts    
    
-- TECH-36760    
INSERT  INTO de_fw_des_publish_error_lookup    
(ecrno,customer_name,project_name,process_name,component_name,activity_name,ui_name,taskname,service_name,    
errorid,pub_name,linkid,published_comp_name,published_act_name,published_ui_name,createddate,createdby,modifiedby,modifieddate,height,width,suppress_msg)    
SELECT  distinct @PublishedEcrNo,customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,service_name,    
errorid,pub_name,linkid,published_comp_name,published_act_name,published_ui_name,createddate,createdby,modifiedby,modifieddate,height,width,suppress_msg  
FROM  de_fw_des_error_lookup  (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_error_lookup_dataitem    
(ecrno,customer_name,project_name,process_name,component_name,activity_name,ui_name,taskname,service_name,errorid,pub_name,    
linkid,published_comp_name,published_act_name,published_ui_name,pub_page,pub_dataitemname,pub_control_bt_synonym,pub_controlid,    
pub_viewname,pub_flowtype,sub_page,sub_control_bt_synonym,sub_controlid,sub_viewname,sub_flowtype,createddate,createdby,modifieddate,modifiedby)    
SELECT  distinct @PublishedEcrNo,customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,service_name,    
errorid,pub_name,linkid,published_comp_name,published_act_name,published_ui_name,pub_page,pub_dataitemname,pub_control_bt_synonym,    
pub_controlid,pub_viewname,pub_flowtype,sub_page,sub_control_bt_synonym,sub_controlid,sub_viewname,sub_flowtype,createddate,createdby,modifieddate,modifiedby    
FROM  de_fw_des_error_lookup_dataitem  (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name  = @ProjectName    
AND   process_name  = @ProcessName    
AND   component_name= @ComponentName    
    
  -- TECH-36760    
insert into  de_fw_des_publish_followup_tasks    
(customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,success_errorid,    
followup_taskname,service_name,ecrno,createddate,createdby,modifiedby,ModifiedDate,height,width,suppress_msg)    
select    
customer_name,project_name,process_name,component_name,activity_name,ui_name,task_name,success_errorid,    
followup_taskname,service_name,@PublishedEcrNo,createddate,createdby,modifiedby,ModifiedDate,height,width,suppress_msg  
from de_fw_des_followup_tasks (nolock)    
where customer_name = @customername    
and  project_name = @projectname    
and  process_name = @processname    
and  component_name = @componentname    
    
    
-- Code modification for  PNR2.0_30127 ends    
    
    
INSERT  INTO de_fw_des_publish_integ_serv_map    
(ecrno, customername, projectname, processname,    
componentname,  callingservicename, sectionname, sequenceno,    
integservicename, integsegment, integdataitem, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
callingsegment, callingdataitem, upduser, updtime)    
SELECT  @PublishedEcrNo, a.customer_name, a.project_name, a.process_name,    
a.component_name,  a.callingservicename, a.sectionname, a.sequenceno,    
a.integservicename, a.integsegment, a.integdataitem, a.timestamp,    
a.createdby, a.createddate, a.modifiedby, a.modifieddate,    
a.callingsegment, a.callingdataitem, a.upduser, a.updtime    
FROM  de_fw_des_integ_serv_map a (nolock)    
--    ,    
--    de_fw_des_service b (nolock)    
WHERE  a.customer_name = @CustomerName    
AND   a.project_name = @ProjectName    
AND   a.process_name = @ProcessName    
AND   a.component_name = @ComponentName    
--  and  a.customer_name = b.customer_name    
--  AND   a.project_name = b.project_name    
--  AND   a.process_name = b.process_name    
--  AND   a.component_name = b.componentname    
--  and  a.callingservicename = b.servicename    
    
    
INSERT  INTO de_fw_des_publish_ilerror    
(ecrno, customername, projectname, processname,    
componentname,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, localerrorno, errorid, upduser,    
updtime, viewname,page_bt_synonym,control_bt_synonym)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, localerrorno, errorid, upduser,    
updtime, viewname ,page_bt_synonym,control_bt_synonym --chan    
FROM  de_fw_des_ilerror (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
INSERT  INTO de_fw_des_publish_ilbo_services    
(ecrno, customername, projectname, processname,    
componentname,  ilbocode, servicename, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
isprepopulate, upduser, updtime)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  ilbocode, servicename, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
isprepopulate, upduser, updtime    
FROM  de_fw_des_ilbo_services (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
    
-- code modified by kiruthika for bugid:PNR2.0_12606    
INSERT  INTO de_fw_des_publish_ilbo_service_view_datamap    
(ecrno, customername, projectname, processname,    
componentname,  ilbocode, servicename, activityid,    
taskname, segmentname, dataitemname, timestamp,    
createdby, createddate, modifiedby, modifieddate,    
iscontrol, controlid, viewname, variablename,    
--code modified for the call id : PNR2.0_19951 starts    
upduser, updtime,control_bt_synonym,page_bt_synonym,activity_name)    
--code modified for the call id : PNR2.0_19951 ends    
SELECT  distinct @PublishedEcrNo, map.customer_name, map.project_name, map.process_name,    
map.component_name,  map.ilbocode, map.servicename, map.activityid,    
map.taskname, map.segmentname, map.dataitemname, map.timestamp,    
map.createdby, map.createddate, map.modifiedby, map.modifieddate,    
map.iscontrol, map.controlid,map.viewname, map.variablename,    
--code modified for the call id : PNR2.0_19951 starts   
map.upduser, map.updtime ,map.control_bt_synonym, map.page_bt_synonym,map.activity_name    
--code modified for the call id : PNR2.0_19951 ends    
FROM  de_fw_des_ilbo_service_view_datamap map (nolock),    
de_fw_req_publish_task  r(nolock),    
de_action     a(nolock)    
WHERE  map.customer_name = @CustomerName    
AND   map.project_name = @ProjectName    
AND   map.process_name = @ProcessName    
and  map.customer_name = a.customer_name    
and  map.project_name =  a.project_name    
and  map.process_name  = a.process_name    
and  map.component_name  = a.component_name    
and  map.activity_name =  a.activity_name    
and  map.ilbocode   = a.ui_name    
and  map.taskname  = a.task_name    
AND   map.component_name = @ComponentName    
and  map.taskname     = r.taskname    
and   map.customer_name = r.customername    
AND   map.project_name =  r.projectname    
AND   map.process_name =  r.processname    
AND   map.component_name = r.componentname    
and  r.ecrno    =@PublishedEcrNo    
    
--code added for bugid: PLF2.0_07676 starts    
INSERT  INTO de_fw_des_publish_ilbo_service_view_attributemap    
(customername,projectname,processname,componentname,ecrno,    
ilbocode,servicename,activityid,taskname,segmentname,dataitemname,    
createdby,createddate,modifiedby,modifieddate,controlid,viewname,activity_name,control_bt_synonym,    
page_bt_synonym,propertytype,propertyname,type)    
SELECT  distinct map.customer_name,map.project_name,map.process_name,map.component_name,@PublishedEcrNo,    
map.ilbocode,map.servicename,map.activityid,map.taskname,map.segmentname,map.dataitemname,    
map.createdby,map.createddate,map.modifiedby,map.modifieddate,map.controlid,map.viewname,map.activity_name,map.control_bt_synonym,    
map.page_bt_synonym,map.propertytype,map.propertyname,type       -- Type column added against Tech-218  
FROM  de_fw_des_ilbo_service_view_attributemap map (nolock),    
de_fw_req_publish_task  r(nolock),    
de_action     a(nolock)    
WHERE  map.customer_name = @CustomerName    
AND   map.project_name = @ProjectName    
AND   map.process_name = @ProcessName    
and  map.customer_name = a.customer_name    
and  map.project_name =  a.project_name    
and  map.process_name  = a.process_name    
and  map.component_name  = a.component_name    
and  map.activity_name =  a.activity_name    
and  map.ilbocode   = a.ui_name    
and  map.taskname  = a.task_name    
AND   map.component_name = @ComponentName    
and  map.taskname     = r.taskname    
and   map.customer_name = r.customername    
AND   map.project_name =  r.projectname    
AND   map.process_name =  r.processname    
AND   map.component_name = r.componentname    
and  r.ecrno    =@PublishedEcrNo    
--code added for bugid: PLF2.0_07676 ends    
    
INSERT  INTO de_fw_des_publish_ilbo_placeholder    
(ecrno, customername, projectname, processname,    
componentname,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, placeholdername, iscontrol, controlname,    
viewname, variablename, errorid, upduser,    
updtime, ctrlevent_viewname,control_bt_synonym,page_bt_synonym)    
SELECT  @PublishedEcrNo, customer_name, project_name, process_name,    
component_name,  timestamp, createdby, createddate,    
modifiedby, modifieddate, ilbocode, controlid,    
eventname, placeholdername, iscontrol, controlname,    
viewname, variablename, errorid, upduser,    
updtime, ctrlevent_viewname ,control_bt_synonym,page_bt_synonym    
FROM  de_fw_des_ilbo_placeholder (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
-- Added By feroz for Error Context on Dec 14    
insert into de_fw_des_publish_focus_control    
(ecrno, customer_name, project_name, process_name,    
component_name, errorcontext, errorid, controlid,    
segmentname, focusdataitem, createdby, createddate,    
modifiedby, modifieddate )    
select @PublishedEcrNo, customer_name, project_name, process_name,    
component_name, errorcontext, errorid, controlid,    
segmentname, focusdataitem, createdby, createddate,    
modifiedby, modifieddate    
from  de_fw_des_focus_control (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
    
insert into de_fw_des_publish_chart_service_segment    
(ecrno, customer_name, project_name, process_name, component_name,    
chart_id, chart_section, servicename, segmentname, instanceflag, timestamp,    
createdby, createddate, modifiedby, modifieddate ,map)--code modified for the call id : PLF2.0_03173    
select  @PublishedEcrNo, customer_name, project_name, process_name, component_name,    
chart_id, chart_section, servicename, segmentname, instanceflag, timestamp,    
createdby, createddate, modifiedby, modifieddate ,map    
from  de_fw_des_chart_service_segment (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
and  map = '1'    
    
insert into de_fw_des_publish_chart_service_dataitem    
(ecrno, customer_name, project_name, process_name, component_name, chart_id, chart_section,    
chart_attribute, servicename, segmentname, dataitemname, ispartofkey, mandatoryflag, flowattribute,    
--code modified for the call id : PNR2.0_19951 starts    
defaultvalue, timestamp, createdby, createddate, modifiedby, modifieddate,map)    
--code modified for the call id : PNR2.0_19951 ends    
select  @PublishedEcrNo, customer_name, project_name, process_name, component_name, chart_id, chart_section,    
chart_attribute, servicename, segmentname, dataitemname, ispartofkey, mandatoryflag, flowattribute,    
--code modified for the call id : PNR2.0_19951 starts    
defaultvalue, timestamp, createdby, createddate, modifiedby, modifieddate,map    
--code modified for the call id : PNR2.0_19951 ends    
from  de_fw_des_chart_service_dataitem (nolock)    
WHERE  customer_name = @CustomerName    
AND   project_name = @ProjectName    
AND   process_name = @ProcessName    
AND   component_name = @ComponentName    
and  map = '1'    
    
--  -- integration serice datat move    
--  declare control_cur cursor for    
--  select  distinct servicename    
--  from  de_fw_des_processsection_br_is  (nolock)    
--  where  customer_name = @customername    
--  and   project_name = @projectname    
--  and   process_name = @processname    
--  and   component_name = @componentname    
--  and   isbr  =0    
--    
--  open control_cur    
--    
--  while (1 = 1)    
--  begin    
--   fetch next from control_cur    
--   into @servicename_tmp    
--    
--   if @@fetch_status <> 0    
--    break    
--    
--   select  @iscomponent_tmp = componentname    
--   from  de_fw_des_service    
--   where  customer_name = @customername    
--   and   project_name = @projectname    
--   and   process_name = @processname    
--   and   servicename  = @servicename_tmp    
--   and   isintegser  =0    
--    
--   insert into de_fw_des_publish_processsection(    
--   customername,projectname,processname,componentname,ecrno,    
--   servicename,sectionname,sectiontype,timestamp,createdby,    
--   createddate,modifiedby,modifieddate,sequenceno,controlexpression,    
--   processingtype,upduser,updtime)    
--   select  customer_name,project_name,process_name,component_name,@publishedecrno,    
--   servicename,sectionname,sectiontype,timestamp,@ctxt_user,    
--   getdate(),@ctxt_user,getdate(),sequenceno,controlexpression,    
--   processingtype,@ctxt_user,getdate()    
--   from  de_fw_des_processsection a (nolock)    
--   where  a.customer_name = @customername    
--   and   a.project_name = @projectname    
--   and   a.process_name = @processname    
--   and   a.component_name = @iscomponent_tmp    
--   and   a.servicename  = @servicename_tmp    
--   and  not exists ( select 's'    
--         from de_fw_des_publish_processsection c (nolock)    
--         where c.customername  = a.customer_name    
--         and  c.projectname  = a.project_name    
--         and  c.processname  = a.process_name    
--         AND  c.componentname  = a.component_name    
--         and  c.ecrno    = @publishedecrno    
--         and  c.servicename  = a.servicename    
--         and  c.sectionname  = a.sectionname )    
--    
--   insert into de_fw_des_publish_service_segment(    
--   customername,projectname,processname,componentname,ecrno,servicename,    
--   segmentname,instanceflag,mandatoryflag,timestamp,createdby,createddate,    
--   modifiedby,modifieddate,bocode,bosegmentname,parentsegmentname,upduser,    
--   updtime)    
--   select    
--   customer_name,project_name,process_name,component_name,@publishedecrno,servicename,    
--   segmentname,instanceflag,mandatoryflag,timestamp,@ctxt_user,getdate(),    
--   @ctxt_user,getdate(),bocode,bosegmentname,parentsegmentname,@ctxt_user,getdate()    
--   from de_fw_des_service_segment a (nolock)    
--   where customer_name = @customername    
--   and  project_name = @projectname    
--   and  process_name = @processname    
--   and  component_name = @iscomponent_tmp    
--   and  servicename  = @servicename_tmp    
--   and  not exists  ( select 's'    
--         from de_fw_des_publish_service_segment c (nolock)    
--         where c.customername  = a.customer_name    
--         and  c.projectname  = a.project_name    
--         and  c.processname  = a.process_name    
--         AND  c.componentname  = a.component_name    
--         and  c.ecrno    = @publishedecrno    
--         and  c.servicename  = a.servicename    
--         and  c.segmentname  = a.segmentname )    
--    
--   insert into de_fw_des_publish_service_dataitem(    
--   customername,projectname,processname,componentname,ecrno,    
--   servicename,segmentname,dataitemname,ispartofkey,mandatoryflag,    
--   flowattribute,timestamp,createdby,createddate,modifiedby,modifieddate,    
--   defaultvalue,upduser,updtime)    
--   select    
--   customer_name,project_name,process_name,component_name,@publishedecrno,    
--   servicename,segmentname,dataitemname,ispartofkey,mandatoryflag,    
--   flowattribute,timestamp,createdby,createddate,modifiedby,modifieddate,    
--   defaultvalue,upduser,updtime    
--   from de_fw_des_service_dataitem a (nolock)    
--   where customer_name = @customername    
--   and  project_name = @projectname    
--   and  process_name = @processname    
--   and  component_name = @iscomponent_tmp    
--   and  servicename  = @servicename_tmp    
--   and  not exists  ( select 's'    
--         from de_fw_des_publish_service_dataitem c (nolock)    
--         where c.customername  = a.customer_name    
--         and  c.projectname  = a.project_name    
--         and  c.processname  = a.process_name    
--         AND  c.componentname  = a.component_name    
--         and  c.ecrno    = @publishedecrno    
--         and  c.servicename  = a.servicename    
--         and  c.segmentname  = a.segmentname    
--         and  c.dataitemname  = a.dataitemname )    
--  end    
--  close control_cur    
--  deallocate control_cur    
--    
 --Code Added for Defect ID : TECH-39534  Starts  
 -- code added by 11536 for API  
  
 INSERT INTO fw_des_publish_api_request_serv_map  
      ( CustomerName,   ProjectName,   DocNo,    ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     OperationVerb,   MediaType,   ParentSchemaName,  SchemaName,   
       SchemaCategory,   SegmentName,   DataItemName,  NodeID,     ParentNodeID,  
       Identifier,    Type,     DisplayName,  
       CreatedUser,   CreatedDate,   ModifiedUser,  ModifiedDate)  
    SELECT DISTINCT  
       CustomerName,   ProjectName,   @PublishedEcrNo, ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     OperationVerb,   MediaType,   ParentSchemaName,  SchemaName,   
       SchemaCategory,   SegmentName,   DataItemName,  NodeID,     ParentNodeID,  
       Identifier,    Type,     DisplayName,  
       @ctxt_user,    GETDATE(),    @ctxt_user,  GETDATE()  
     FROM fw_des_api_request_serv_map (NOLOCK)  
     WHERE customername = @CustomerName    
     AND  projectname  = @ProjectName     
     AND  componentname = @ComponentName   
  
  INSERT INTO fw_des_publish_api_response_serv_map  
      ( CustomerName,   ProjectName,   DocNo,    ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     OperationVerb,   MediaType,   ResponseCode,   ParentSchemaName,  
       SchemaName,    SchemaCategory,   SegmentName,  DataItemName,   NodeID,  
       ParentNodeID,   Identifier,    Type,    DisplayName,  
       CreatedUser,   CreatedDate,  ModifiedUser,   ModifiedDate )  
    SELECT DISTINCT  
       CustomerName,   ProjectName,   @PublishedEcrNo, ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     OperationVerb,   MediaType,   ResponseCode,   ParentSchemaName,  
       SchemaName,    SchemaCategory,   SegmentName,  DataItemName,   NodeID,  
       ParentNodeID,   Identifier,    Type,    DisplayName,  
       @ctxt_user,    GETDATE(),    @ctxt_user,   GETDATE()  
     FROM fw_des_api_response_serv_map (NOLOCK)  
     WHERE customername = @CustomerName    
     AND  projectname  = @ProjectName     
     AND  componentname = @ComponentName    
  
  INSERT INTO fw_des_publish_api_pathparameter_serv_map  
      ( CustomerName,   ProjectName,   DocNo,    ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     ParameterName,   SegmentName,  DataItemName,   CreatedUser,  
       CreatedDate,   ModifiedUser,   ModifiedDate )  
    SELECT DISTINCT  
       CustomerName,   ProjectName,   @PublishedEcrNo, ComponentName,   ServiceName,  
       SectionName,   SequenceNo,    SpecID,    SpecName,    Version,  
       Path,     ParameterName,   SegmentName,  DataItemName,   @ctxt_user,  
       GETDATE(),    @ctxt_user,    GETDATE()  
     FROM fw_des_api_pathparameter_serv_map (NOLOCK)  
     WHERE customername = @CustomerName    
     AND  projectname  = @ProjectName     
     AND  componentname = @ComponentName   
  
  INSERT INTO fw_des_publish_api_pathoperationparameter_serv_map  
        ( CustomerName,  ProjectName,  DocNo,   ComponentName,   ServiceName,  
         SectionName,  SequenceNo,   SpecID,   SpecName,    Version,  
         Path,    OperationVerb,  ParameterName, SegmentName,   DataItemName,  
         CreatedUser,  CreatedDate,  ModifiedUser, ModifiedDate )  
      SELECT DISTINCT  
         CustomerName,  ProjectName,  DocNo,   ComponentName,   ServiceName,  
         SectionName,  SequenceNo,   SpecID,   SpecName,    Version,  
         Path,    OperationVerb,  ParameterName, SegmentName,   DataItemName,  
         @ctxt_user,   GETDATE(),   @ctxt_user,  GETDATE()  
       FROM fw_des_api_pathoperationparameter_serv_map (NOLOCK)  
       WHERE customername = @CustomerName    
       AND  projectname  = @ProjectName     
       AND  componentname = @ComponentName   
  
 -- For task  
  
  INSERT INTO fw_des_publish_api_request_task_map   
      ( CustomerName,  ProjectName,   DocNo,    ComponentName,  ActivityName,  
       UIName,    TaskName,    SequenceNo,   SpecID,    SpecName,  
       Version,   Path,     OperationVerb, MediaType,   ParentSchemaName,  
       SchemaName,   SchemaCategory,   ControlBTSynonym, ControlID,   ViewName,  
       NodeID,    ParentNodeID,   Identifier,   Type,    DisplayName,  
       CreatedUser,  CreatedDate,   ModifiedUser,  ModifiedDate )  
   SELECT DISTINCT   
       CustomerName,  ProjectName,   @PublishedEcrNo, ComponentName,  ActivityName,  
       UIName,    TaskName,    SequenceNo,   SpecID,    SpecName,  
       Version,   Path,     OperationVerb,  MediaType,   ParentSchemaName,  
       SchemaName,   SchemaCategory,   ControlBTSynonym, ControlID,   ViewName,  
       NodeID,    ParentNodeID,   Identifier,   Type,    DisplayName,  
       @ctxt_user,   GETDATE(),    @ctxt_user,   GETDATE()  
     FROM fw_des_api_request_task_map (NOLOCK)  
     WHERE customername = @CustomerName    
     AND  projectname  = @ProjectName     
     AND  componentname = @ComponentName   
    
  INSERT INTO fw_des_publish_api_response_task_map  
       ( CustomerName,  ProjectName,  DocNo,    ComponentName,   ActivityName,  
        UIName,    TaskName,   SequenceNo,   SpecID,     SpecName,  
        Version,   Path,    OperationVerb,  MediaType,    ResponseCode,  
        ParentSchemaName, SchemaName,   SchemaCategory,  ControlBTSynonym,  ControlID,  
        ViewName,   NodeID,    ParentNodeID,  Identifier,    Type,  
        DisplayName,  CreatedUser,  CreatedDate,  ModifiedUser,   ModifiedDate )  
    SELECT DISTINCT   
        CustomerName,  ProjectName,  @PublishedEcrNo, ComponentName,   ActivityName,  
        UIName,    TaskName,   SequenceNo,   SpecID,     SpecName,  
        Version,   Path,    OperationVerb,  MediaType,    ResponseCode,  
        ParentSchemaName, SchemaName,   SchemaCategory,  ControlBTSynonym,  ControlID,  
        ViewName,   NodeID,    ParentNodeID,  Identifier,    Type,  
        DisplayName,  @ctxt_user,   GETDATE(),   @ctxt_user,    GETDATE()  
      FROM fw_des_api_response_task_map (NOLOCK)  
      WHERE customername = @CustomerName    
      AND  projectname  = @ProjectName     
      AND  componentname = @ComponentName   
    
  INSERT INTO fw_des_publish_api_pathoperationparameter_task_map   
       ( CustomerName,  ProjectName,  DocNo,    ComponentName,   ActivityName,  
        UIName,    TaskName,   SequenceNo,   SpecID,     SpecName,  
        Version,   Path,    OperationVerb,  ParameterName,   ControlBTSynonym,  
        ControlID,   ViewName,   CreatedUser,  CreatedDate,   ModifiedUser,  
        ModifiedDate )  
    SELECT DISTINCT   
        CustomerName,  ProjectName,  @PublishedEcrNo, componentName,   ActivityName,  
        UIName,    TaskName,   SequenceNo,   SpecID,     SpecName,  
        Version,   Path,    OperationVerb,  ParameterName,   ControlBTSynonym,  
        ControlID,   ViewName,   @ctxt_user,   GETDATE(),    @ctxt_user,  
        GETDATE()  
      FROM fw_des_api_pathoperationparameter_task_map (NOLOCK)  
      WHERE customername = @CustomerName    
      AND  projectname  = @ProjectName     
      AND  componentname = @ComponentName   
    
  INSERT INTO fw_des_publish_api_pathparameter_task_map  
       ( CustomerName,  ProjectName,   DocNo,   ComponentName,   ActivityName,  
        UIName,    TaskName,    SequenceNo,  SpecID,     SpecName,  
        Version,   Path,     ParameterName, ControlBTSynonym,  ControlID,  
        ViewName,   CreatedUser,   CreatedDate, ModifiedUser,   ModifiedDate )  
    SELECT DISTINCT   
        CustomerName,  ProjectName,   @PublishedEcrNo,ComponentName,   ActivityName,  
        UIName,    TaskName,    SequenceNo,  SpecID,     SpecName,  
        Version,   Path,     ParameterName, ControlBTSynonym,  ControlID,  
        ViewName,   @ctxt_user,    GETDATE(),  @ctxt_user,    GETDATE()  
      FROM fw_des_api_pathparameter_task_map (NOLOCK)  
      WHERE customername = @CustomerName    
      AND  projectname  = @ProjectName     
      AND  componentname = @ComponentName   
  
  INSERT INTO de_fw_des_publish_api_task_map  
       ( CustomerName,   ProjectName,   DocNo,    ComponentName,  
        ActivityName,   UIName,     TaskName,   SequenceNo,  
        SpecID,     SpecName,    Version,   Path,  
        OperationVerb,   OperationID,   CreatedUser,  CreatedDate,  
        ModifiedUser,   ModifiedDate )  
    SELECT DISTINCT   
        CustomerName,   ProjectName,   @PublishedEcrNo, ComponentName,  
        ActivityName,   UIName,     TaskName,   SequenceNo,  
        SpecID,     SpecName,    Version,   Path,  
        OperationVerb,   OperationID,   @ctxt_user,   GETDATE(),  
        @ctxt_user,    GETDATE()  
      FROM de_fw_des_api_task_map (NOLOCK)  
      WHERE customername = @CustomerName    
      AND  projectname  = @ProjectName     
      AND  componentname = @ComponentName   

	  --Added against the case id TECH-45828

	INSERT INTO de_published_upe_control_task_detail
					(	CustomerName,			ProjectName,			ProcessName,			ComponentName,
						ActivityName,			UIName,					PageName,				SectionName,
						BTSynonymName,			ControlID,				ViewName,				ControlType,
						TaskName,				TaskDescr,				TaskType,				ServiceName,
						ServiceSectionName,		SectionSequence,		MethodID,				MethodName,
						MethodSequence,			ParameterName,			ParameterFlowDirection,	RecordSetName,
						SegmentName,			DataitemName,			DataItemFlowDirection,	ISMoreAction,
						CreatedBY,				CreatedDate,			ModifiedBY,				Modifieddate,
						ECRNumber	)
			SELECT DISTINCT
						CustomerName,			ProjectName,			ProcessName,			ComponentName,
						ActivityName,			UIName,					PageName,				SectionName,
						BTSynonymName,			ControlID,				ViewName,				ControlType,
						TaskName,				TaskDescr,				TaskType,				ServiceName,
						ServiceSectionName,		SectionSequence,		MethodID,				MethodName,
						MethodSequence,			ParameterName,			ParameterFlowDirection,	RecordSetName,
						SegmentName,			DataitemName,			DataItemFlowDirection,	ISMoreAction,
						@ctxt_user,				GETDATE(),				@ctxt_user,				GETDATE(),
						@PublishedEcrNo
				FROM	de_upe_control_task_detail (NOLOCK)  
				WHERE	customername	=	@CustomerName    
				AND		projectname		=	@ProjectName     
				AND		componentname	=	@ComponentName   	


  
  
 -- code ends for API  
--Code Added for Defect ID : TECH-39534 Ends  

	--Task ApI mappping code starts

		INSERT INTO de_published_task_api_mapping	
					(	CustomerName,		ProjectName,			ProcessName,			ComponentName,
						ActivityName,		UIName,					DocNo,					TaskName,
						ApiSpecID,			ApiSpecName,			ApiVersion,				ApiPath,
						ApiOperationVerb,	ApiOperationID,			ApiExecSequence,		TimeStamp,
						CreatedBy,			CreatedDate,			ModifiedBy,				ModifiedDate )
			SELECT DISTINCT
						CustomerName,		ProjectName,			ProcessName,			ComponentName,
						ActivityName,		UIName,					@PublishedEcrNo,		TaskName,
						ApiSpecID,			ApiSpecName,			ApiVersion,				ApiPath,
						ApiOperationVerb,	ApiOperationID,			ApiExecSequence,		TimeStamp,
						@ctxt_user,			GETDATE(),				@ctxt_user,				GETDATE()
				FROM	de_task_api_mapping (NOLOCK)
				WHERE	customername	=	@CustomerName    
				AND		projectname		=	@ProjectName     
				AND		componentname	=	@ComponentName  

		INSERT INTO de_published_task_api_subtask 
				(	CustomerName,		ProjectName,		ProcessName,			ComponentName,
					ActivityName,		UIName,				DocNo,					TaskName,			
					TaskType,			SubTaskName,		SubTaskSequence,		SubTaskType,
					TimeStamp,
					CreatedBy,			CreatedDate,		ModifiedBy,				ModifiedDate	)	
			SELECT DISTINCT
					CustomerName,		ProjectName,		ProcessName,			ComponentName,
					ActivityName,		UIName,				@PublishedEcrNo,		TaskName,			
					TaskType,			SubTaskName,		SubTaskSequence,		SubTaskType,
					TimeStamp,
					@ctxt_user,			GETDATE(),			@ctxt_user,				GETDATE()
			FROM	de_task_api_subtask (NOLOCK)
			WHERE	customername	=	@CustomerName    
			AND		projectname		=	@ProjectName     
			AND		componentname	=	@ComponentName  

		INSERT INTO de_published_task_api_parameter_map 
					(	CustomerName,		ProjectName,		ProcessName,		ComponentName,
						ActivityName,		UIName,				DocNo,				TaskName,		
						ApiSpecID,			ApiSpecName,		ApiVersion,			ApiPath,
						ApiOperationVerb,	ApiOperationID,		ParameterName,		ParameterLocation,	
						Identifier,			DataType,			ParameterType,		IsPrimitiveType,	
						SchemaMemberLevel,	IsMandatory,		NodeID,				ParentNodeID,		
						ApiExecSequence,	TimeStamp,			ConstantValue,		ControlID,
						ViewName,			BTSynonymName,		ControlDataType,	ModeFlag,		
						CreatedBy,			CreatedDate,		ModifiedBy,			ModifiedDate )
			SELECT DISTINCT
						CustomerName,		ProjectName,		ProcessName,		ComponentName,
						ActivityName,		UIName,				@PublishedEcrNo,	TaskName,		
						ApiSpecID,			ApiSpecName,		ApiVersion,			ApiPath,
						ApiOperationVerb,	ApiOperationID,		ParameterName,		ParameterLocation,	
						Identifier,			DataType,			ParameterType,		IsPrimitiveType,	
						SchemaMemberLevel,	IsMandatory,		NodeID,				ParentNodeID,		
						ApiExecSequence,	TimeStamp,			ConstantValue,		ControlID,
						ViewName,			BTSynonymName,		ControlDataType,	ModeFlag,
						@ctxt_user,			GETDATE(),			@ctxt_user,			GETDATE()
				FROM	de_task_api_parameter_map (NOLOCK)
				WHERE	customername	=	@CustomerName    
				AND		projectname		=	@ProjectName     
				AND		componentname	=	@ComponentName 

		INSERT INTO de_published_task_api_request_map
					 (	CustomerName,		ProjectName,		ProcessName,			ComponentName,
						ActivityName,		UIName,				DocNo,					TaskName,
						ApiExecSequence,
						ApiSpecID,			ApiSpecName,		ApiVersion,				ApiPath,				
						ApiOperationVerb,	ApiOperationID,		MediaType,				ParentSchemaName,		
						SchemaName,			SchemaCategory,		FlattenedSchemaName,	Identifier,				
						DataType,			SchemaType,			IsPrimitiveType,		SchemaMemberLevel,		
						IsMandatory,		NodeID,				ParentNodeID,			ConstantValue,
						ControlID,			ViewName,			BTSynonymName,			ControlDataType,
						--RequestType,		
						ModeFlag,			TimeStamp,							
						CreatedBy,			CreatedDate,		ModifiedBy,				ModifiedDate	)
			SELECT DISTINCT
						CustomerName,		ProjectName,		ProcessName,			ComponentName,
						ActivityName,		UIName,				@PublishedEcrNo,		TaskName,
						ApiExecSequence,
						ApiSpecID,			ApiSpecName,		ApiVersion,				ApiPath,				
						ApiOperationVerb,	ApiOperationID,		MediaType,				ParentSchemaName,		
						SchemaName,			SchemaCategory,		FlattenedSchemaName,	Identifier,				
						DataType,			SchemaType,			IsPrimitiveType,		SchemaMemberLevel,		
						IsMandatory,		NodeID,				ParentNodeID,			ConstantValue,
						ControlID,			ViewName,			BTSynonymName,			ControlDataType,
						--RequestType,		
						ModeFlag,			TimeStamp,						
						@ctxt_user,			GETDATE(),			@ctxt_user,				GETDATE()
				FROM	de_task_api_request_map (NOLOCK)
				WHERE	customername	=	@CustomerName    
				AND		projectname		=	@ProjectName     
				AND		componentname	=	@ComponentName 

		INSERT INTO de_published_task_api_response_map
					(	CustomerName,			ProjectName,		ProcessName,		ComponentName,
						ActivityName,			UIName,				DocNo,				TaskName,				
						ApiExecSequence,		ControlID,			ViewName,			BTSynonymName,
						ControlDataType,		NodeID,				ParentNodeID,	
						ApiSpecID,				ApiSpecName,		ApiVersion,			ApiPath,
						ApiOperationVerb,		ApiOperationID,		MediaType,			ParentSchemaName,
						SchemaName,				FlattenedSchemaName,Identifier,			DataType,
						SchemaType,				SchemaCategory,		SchemaMemberLevel,	IsPrimitiveType,
						IsMandatory,			ConstantValue,		
						ModeFlag,				TimeStamp,		
						CreatedBy,				CreatedDate,		ModifiedBy,			ModifiedDate	)
			SELECT DISTINCT
						CustomerName,			ProjectName,		ProcessName,		ComponentName,
						ActivityName,			UIName,				@PublishedEcrNo,	TaskName,				
						ApiExecSequence,		ControlID,			ViewName,			BTSynonymName,
						ControlDataType,		NodeID,				ParentNodeID,	
						ApiSpecID,				ApiSpecName,		ApiVersion,			ApiPath,
						ApiOperationVerb,		ApiOperationID,		MediaType,			ParentSchemaName,
						SchemaName,				FlattenedSchemaName,Identifier,			DataType,
						SchemaType,				SchemaCategory,		SchemaMemberLevel,	IsPrimitiveType,
						IsMandatory,			ConstantValue,		
						ModeFlag,				TimeStamp,
						@ctxt_user,				GETDATE(),			@ctxt_user,			GETDATE()
				FROM	de_task_api_response_map (NOLOCK)
				WHERE	customername	=	@CustomerName    
				AND		projectname		=	@ProjectName     
				AND		componentname	=	@ComponentName



	--Task ApI mappping code starts

set nocount off    
end 

GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'engg_publish_ecr_des_move_sp' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON engg_publish_ecr_des_move_sp TO PUBLIC
END
GO

