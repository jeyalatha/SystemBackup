IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='de_fw_req_migrate_config' AND TYPE = 'P')
    Begin
        Drop PROC de_fw_req_migrate_config
    End
GO  
/********************************************************************************/      
/* procedure    : de_fw_req_migrate_config                                      */      
/* description  :                                                               */      
/********************************************************************************/      
/* project      :                                                               */      
/* version      :                                                               */      
/********************************************************************************/      
/* referenced   :                                                               */      
/* tables       :                                                               */      
/********************************************************************************/      
/* development history                                                          */      
/********************************************************************************/      
/* author       :                                                     */      
/* date         : 4/ 12/ 2003                                                   */      
/********************************************************************************/      
/* modification history                                                         */      
/* Modified by : Ganesh for callid PNR2.0_2986         */      
/* Modified on : 16/06/2005              */      
/* Description : ECR publish tuning            */      
/********************************************************************************/      
/* modification history                                                         */      
/* Modified by : Ganesh for callid PNR2.0_3386         */      
/* Modified on : 01/08/05               */      
/* Description : Add Component Description Activity Description and Task Description in Glossary.*/      
/* modification history                                                         */      
/* Modified by : Shriram V              */      
/* Modified on : 17/08/05               */      
/* Description : Blank Error Thrown while ECR Publish       */      
/********************************************************************************/      
/* Modified by : Balaji S For BugID : PNR2.0_3839        */      
/* Modified on : 13/09/05               */      
/* Description : while Publishing Ecr,Activity Local Info Table Not Get Updated.*/      
/********************************************************************************/      
/* Modified by : Ganesh S For BugID : PNR2.0_3927        */      
/* Modified on : 13/09/05               */      
/* Description : Need to populate activity sequence        */      
/********************************************************************************/      
/* Modified by : Saravanan              */      
/* Modified on : 26/09/05               */      
/* Description : Error message thrown if dataitem is not mapped to BT, is corrected*/      
/********************************************************************************/      
/* Modified by : Sangeetha L For BugID :  PNR2.0_4282       */      
/* Modified on : 18/10/05               */      
/* Description : While generating deployment scripts with respect to an ECR, the*/      
/* activity description for the activities not in the current ECR were generated incorrectly.*/      
/********************************************************************************/      
/* Modified by : Ganesh For BugID : PNR2.0_4912         */      
/* Modified on : 08/12/05               */      
/* Description : Handling Data Saving task in the application.     */      
/********************************************************************************/      
/* Modified by : Balaji S For BugID :  PNR2.0_5014        */      
/* Modified on : 15/12/05               */      
/* Description : INSERT statement conflicted with TABLE FOREIGN KEY constraint      
'de_fw_req_component_local_info_fkey_de_fw_req_language'. The conflict      
occurred in database 'MOSModel', table 'de_fw_req_language'. .  */      
/********************************************************************************/      
/* Modified by : Sangeetha L For BugID : PNR2.0_5489       */      
/* Modified on : 18/01/06               */      
/* Description : Handling Data Saving task in the application.     */      
/********************************************************************************/      
/* Modified by : Sangeetha L For BugID : PNR2.0_7453       */      
/* Modified on : 24/03/06               */      
/********************************************************************************/      
/* Modified by : kiruthika R For BugID : PNR2.0_8068       */      
/* Modified on : 20/04/06               */      
/********************************************************************************/      
/* Modified by : Sangeetha L For BugID : PNR2.0_8139       */      
/* Modified on : 25/04/06               */      
/********************************************************************************/      
/* Modified by : Sangeetha L For BugID : PNR2.0_8241       */      
/* Modified on : 02/05/06               */      
/********************************************************************************/      
/* Modified by : kiruthika R For BugID : PNR2.0_8491       */      
/* Modified on : 16/05/06               */      
/********************************************************************************/      
/* Modified by : kiruthika R For BugID : PNR2.0_9192       */      
/* Modified on : 29/06/06               */      
/********************************************************************************/      
/* Modified By  : Date :   Description :    */      
/* S K Mohamed Mohideen 15 Jun 2006 Task Confirmation Message changes */      
/********************************************************************************/      
/* Modified by : kiruthika R For BugID : PNR2.0_10280       */      
/* Modified on : 19/09/06               */      
/********************************************************************************/      
/* Modified by : chanheetha N A For BugID : PNR2.0_10813      */      
/* Modified on : 03-Nov-2006              */      
/********************************************************************************/      
/* Modified By  : Date :   Description :         */      
/* S K Mohamed Mohideen 10 Nov 2006 Task Status Message changes     */      
/********************************************************************************/      
/********************************************************************************/      
/* Modified by : Senthil Kumar S  For BugID : PNR2.0_11087       */      
/* Modified on : 21-Nov-2006              */      
/********************************************************************************/      
/* Modified by : Senthil Kumar S  For BugID : PNR2.0_11119       */      
/* Modified on : 22-Nov-2006              */      
/********************************************************************************/      
/* Modified by : kiruthika R  For BugID : PNR2.0_11121       */      
/* Modified on : 22-Nov-2006              */      
/********************************************************************************/      
/* Modified by : chanheetha N A For BugID : PNR2.0_11068      */      
/* Modified on : 29-Nov-2006              */      
/********************************************************************************/      
/* Modified by : Gowrisankar M For BugID : PNR2.0_11308       */      
/* Modified on : 06-Dec-2006              */      
/********************************************************************************/      
/* Modified by : chanheetha N A For BugID : PNR2.0_11331      */      
/* Modified on : 08-Dec-2006              */      
/********************************************************************************/      
/* Modified by : Kiruthika R For BugID : PNR2.0_11346       */      
/* Modified on : 11-Dec-2006              */      
/********************************************************************************/      
/* Modified by : Senthil Kumar S For BugID : PNR2.0_11659      */  /* Modified on : 03-Jan-2007 */      
/********************************************************************************/      
/* Modified by : Chanheetha N A For BugID : PNR2.0_11770      */      
/* Modified on : 09-Jan-2007              */      
/********************************************************************************/      
/* Modified by : Kiruthika R For BugID : PNR2.0_11831          */      
/* Modified on : 17-Jan-2007              */      
/********************************************************************************/      
/* Modified by : Gowrisankar M For BugID : PNR2.0_12117, PNR2.0_12119      */      
/* Modified on : 05-Feb-2007              */      
/********************************************************************************/      
/* Modified by : Chanheetha N A For BugID : PNR2.0_12211         */      
/* Modified on : 10-Feb-2007              */      
/********************************************************************************/      
/* Modified by : Senthil Kumar S For BugID : PNR2.0_12408      */      
/* Modified on : 28-Feb-2007              */      
/********************************************************************************/      
/* Modified by : Chanheetha N A For BugID : PNR2.0_13217         */      
/* Modified on : 12-Apr-2007              */      
/********************************************************************************/      
/* Modified by : Gowrisankar For BugID : PNR2.0_13486          */      
/* Modified on : 02-May-2007              */      
/********************************************************************************/      
/* Modified by : Kiruthika  For BugID : PNR2.0_14041          */      
/* Modified on : 11-june-2007              */      
/********************************************************************************/      
/* Modified by : Gowrisankar  For BugID : PNR2.0_14756,PNR2.0_14897,PNR2.0_15171*/      
/* Modified on : 31-Jul-2007, 09-Aug-2007, 31-Aug-2007       */      
/********************************************************************************/      
/* modified by   : Chanheetha N A        */      
/* date     : 17-nov-2007         */      
/* BugId    : PNR2.0_16023          */      
/************************************************************************/      
/* modified by    : Sangeetha G        */      
/* date     : 28-nov-2007         */      
/* BugId    : PNR2.0_16100         */      
/********************************************************************************/      
/* modified by   : Gowrisankar M           */      
/* date     : 10-Jan-2008           */      
/* BugId    : PNR2.0_16448            */      
/********************************************************************************/      
/* modified by : praveen kumar.A  */      
/* date   : 18-06-2008   */      
/* Bug id  : PNR2.0_18241  */      
/********************************************************************************/      
/*Modifications   by   : Chanheetha N A    */      
/*Date          : 30-10-2008     */      
/*Bug Id     : PNR2.0_19835      */      
/*Bug Description            : For handle change comp   */       
/********************************************************************************/      
/* Modified By     : chanheetha n a          */      
/* Date      : 13-Nov-2008         */      
/* Bug ID     : PNR2.0_19951         */      
/* Description     : pkey violation - insertion for de_fw_req_task        */      
/******************************************************************************/      
/*Modifications   by   :Sangeetha G         */      
/*Date          :04-Mar-2009        */      
/*Bug Id     :PNR2.0_21328          */      
/*Bug Description            :In handlechanges during validate     */       
/*     The INSERT statement conflicted with the FOREIGN  */      
/* KEY constraint of table de_fw_req_publish_language*/      
/********************************************************************************/      
/*Modified by  : Gowrisankar M                */      
/*Date      : 25-Jun-2009                */      
/*Bug Id    : PNR2.0_22708                 */      
/*Description   : Textareas with 1 visible row to be updated as "RSLIST"  */       
/********************************************************************************/      
/*Modified by  : Gowrisankar M                */      
/*Date      : 21-Dec-2009                */      
/*Bug Id    : PNR2.0_25310                */      
/*Description   : Report dataset to be thrown in error message for segment */       
/****************************************************************************************************************/      
/*Modified by      : Sangeetha G                */      
/*Date      : 04-Feb-2010                */      
/*Bug Id       : PNR2.0_25798                */      
/*Description       : Conflict with the fkey const"de_fw_req_bterm_fkey_de_fw_req_precision" on ECR publish */       
/*****************************************************************************************************************/      
/*Modified by      : Sangeetha G                       */      
/*Date    : 07-June-2010                      */      
/*Bug Id     : PNR2.0_27090                      */      
/*Description       : Language id and name hardcoded. To modifiy the same.         */       
/*****************************************************************************************************************/      
/*Modified by      : Saravana Kumar P                       */        
/*Date      : 09-Apr-2011                      */        
/*Bug Id           : PNR2.0_30909                      */        
/*Description      : Insertion of 'Disposal' task into de_fw_req_task only if task-service mapping exists         */        
/*****************************************************************************************************************/       
/* modified by  : Sangeetha G                    */        
/* date    : 11-Apr-2011                    */        
/* BugId   : PNR2.0_30869                    */        
/* modified for  : Feature Release                   */        
/****************************************************************************************************************/       
/* modified by    : Gankan G                         */      
/* date     : 30-Aug-2012                        */      
/* BugId    : PLF2.0_01396                          */      
/* description   : Code modified to handle control property             */      
/* Primary BugID  : PLF2.0_01414                    */      
/****************************************************************************************************************/       
/* modified by    : Gankan G                         */      
/* date     : 03-Dec-2013                        */      
/* BugId    : PLF2.0_06940                          */      
/* description   : Code modified to handle data save property            */      
/****************************************************************************************************************/       
/* Modified by  : Veena U                                                  */      
/* Date         : 25-Feb-2015                                                  */      
/* Call ID  : PLF2.0_11499                                                 */      
/********************************************************************************/       
/* Created by   : Veena U                                                */      
/* Date         : 16-March-2016                                                  */      
/*Defect Id  : PLF2.0_17326            */      
/********************************************************************************/       
/* modified by   Date    Defect ID       */      
/* Veena U    08-Jun-2016   PLF2.0_18487      */      
/********************************************************************************/      
/* Modified by : Jeya Latha K/Ganesh Prabhu S Defect ID:TECH-7349 On:14-03-2017 */      
/* Description : New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid  */      
/* Modified by : JeyaLatha   Defect ID: TECH-16126      On: 30-Nov-2017 */      
/* Modified by : Pavithra V   Defect ID: TECH-17752      On: 18-JAN-2018 */      
/* Description : Ilbo type changes not getting reflected in depmetadata script */      
/* Modified by : Ganesh Prabhu S Defect ID: TECH-21980      On: 28-May-2018 */      
/* Modified By : Jeya Latha K Date : 15-Nov-2018   Defect ID : TECH-28189 */      
/*************************************************************************************************/      
/* Modified by : Venkatesan K Defect ID:AHBG-27244 On:13-12-2018          */      
/* Description : To get the component description from glossary table instead of de_ui_ico Table  */      
/* Modified By : Jeya Latha K  Date: 08-Jan-2019   Defect ID: TECH-28436     */      
/* Modified by : Jeya Latha K   Date: 25-Jul-2019  Defect ID: TECH-36371        */    
/*************************************************************************************************/      
/* Modified by : Jeya Latha K/Ponmalar A   Date: 03-Mar-2022  Defect ID: TECH-66740      */  
/* Description : Document Store path & System Generated File ID options need to be printed in    
     Activity dll source code naming as STORE_PATH   
				 & CRTL_UPLOAD_AUTO_FILE_REQ _<control view>									  */
/**************************************************************************************************/  
/* Modified by : Jeya Latha K/Ponmalar A   Date: 31-Mar-2022  Defect ID: TECH-66740      */  
/* Description : Document Store path & System Generated File ID options need to be printed in    
     Activity dll source code naming as STORE_PATH   
				 & CRTL_UPLOAD_AUTO_FILE_REQ _<control view>									  */
/**************************************************************************************************/
/* Modified by : Ganesh Prabhu S   	Date: 25-May-2022  Defect ID: TECH-69346				  	  */
/**************************************************************************************************/
/* Modified by : Manoj S   			Date: 03-Nov-2022  Defect ID: TECH-74216				  	  */
/**************************************************************************************************/               
CREATE procedure de_fw_req_migrate_config      
@ctxt_language     engg_ctxt_language,      
@ctxt_ouinstance   engg_ctxt_ouinstance,      
@ctxt_service      engg_ctxt_service,      
@ctxt_user         engg_ctxt_user,      
@customername    engg_name,      
@projectname    engg_name,      
@req_no      engg_name,      
@componentname     engg_name,      
@processname   engg_name,      
@fp_id       engg_name,      
@m_errorid   engg_id output      
as      
begin      
set nocount on      
      
declare  @sequenceno_tmp     engg_seqno,      
@process_name_tmp  engg_name,      
@process_descr_tmp  engg_description,      
@component_descr_tmp engg_description,      
@uidescr_tmp   engg_description,      
@msg      engg_documentation,      
--    @m_errorid    engg_id,      
--@prev_act_name   engg_name,      
--@prev_ui_name   engg_name,      
--@uiname_tmp    engg_name,      
--@pagename_tmp   engg_name,      
--@tabseq_tmp    engg_rowno,      
--@errorcode    engg_sequence_no,      
--@brserialno    engg_tiny_no,      
-- code modified by ganesh for the  callid :: 4525 on 8/11/05      
@activityid_tmp   engg_sequence_no, -- numeric(10,4),      
@act_id     engg_sequence_no, /* PNR2.0_12211 */      
@ws_act_id     engg_sequence_no, /* PNR2.0_12211 */      
@activityname_tmp   engg_name,      
@activity_descr   engg_description,      
-- @task_type    engg_name,      
--@tsk_activity_name  engg_name,      
--@tsk_ui_name   engg_name,      
--@tsk_task_name   engg_name,      
@activity_seq   engg_seqno,      
@activity_type   engg_tiny_no,      
@getdate     engg_date,      
@ui_tmp     engg_name,      
@page_tmp    engg_name,      
@cnt_tmp    engg_seqno,      
@ui_tmp_chk    engg_name,      
@act_name_tmp   engg_name,      
@horder     engg_seqno,      
@vorder     engg_seqno,      
@bt_name_tmp   engg_name,      
@count     engg_seqno,      
@service_tmp   engg_name,      
@dataitem_tmp   engg_name,      
@precisiontype   engg_type,      
@btsyntmp    engg_name,      
@accesskey short,     
@forcedActivity engg_type,      
@DeviceType engg_type      
      
select  @getdate  = getdate()      
      
-- code modified by 11536 for the case id AHBG-27244      
      
--select  @process_name_tmp   =  process_name,      
--@process_descr_tmp  =  process_descr,      
--@component_descr_tmp  =   component_descr      
--from de_ui_ico(nolock)      
--where  customer_name  =  @customername      
--and  project_name = @projectname      
--and  process_name  =   @processname      
--and  component_name = @componentname      
      
select @process_name_tmp  = a.process_name,      
  @process_descr_tmp  = process_descr,      
  @component_descr_tmp =   b.bt_synonym_caption      
from de_ui_ico a (nolock),      
  de_glossary b (nolock)      
where a.customer_name   = @customername      
and  a.project_name   = @projectname      
and  a.process_name   =   @processname      
and  a.component_name  = @componentname      
      
and  a.customer_name   = b.customer_name      
and  a.project_name   = b.project_name       
and  a.process_name   =   b.process_name      
and  a.component_name  = b.component_name      
and  a.component_name  = b.bt_synonym_name      
  
Declare @de_glossary_lng_extn Table   
   (customer_name VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),  
    component_name VARCHAR(60),bt_synonym_name VARCHAR(64),bt_synonym_caption Nvarchar(255),data_type VARCHAR(60),length int,ecrno VARCHAR(60),  
    singleinst_sample_data Nvarchar(255),multiinst_sample_data Nvarchar(255), bt_name VARCHAR(60),languageid int   
    PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name,ecrno,languageid))  
  
 Declare @de_glossary Table   
 (customer_name VARCHAR(60),project_name VARCHAR(60),process_name VARCHAR(60),  
 component_name VARCHAR(60),bt_synonym_name VARCHAR(64),bt_synonym_caption Nvarchar(255),data_type VARCHAR(60),length int,ecrno VARCHAR(60),  
 singleinst_sample_data Nvarchar(255),multiinst_sample_data Nvarchar(255), bt_name VARCHAR(60)  
 PRIMARY KEY (customer_name,project_name,process_name,component_name,bt_synonym_name,ecrno))  
  
  
  
insert into @de_glossary (customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,data_type,length,ecrno,singleinst_sample_data,multiinst_sample_data,bt_name)  
select distinct a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,a.bt_synonym_caption,a.data_type,a.length,@req_no,singleinst_sample_data,multiinst_sample_data,bt_name  
from de_glossary a (nolock)  
where a.customer_name  = @customername  
and  a.project_name  = @projectname  
and  a.process_name  = @processname  
and  a.component_name = @componentname  
   
--insert into @de_glossary_lng_extn (customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)  
--select a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,  
--(case when isnull(b.Targetcaption,'')='' then a.bt_synonym_caption  when isnull(b.Targetcaption,'')<>'' then b.Targetcaption  end ) ,  
--a.data_type,a.length,@req_no as ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,1  as languageid  
--from @de_glossary a  left outer join   
--  PLF_XLTranslated_Meta_Master b (nolock)  
--on  a.customer_name  = @customername  
--and  a.project_name  = @projectname  
--and  a.ecrno    = @req_no  
--and  a.process_name  = @processname  
--and  a.component_name = @componentname  
--and  a.customer_name  = b.customer_name  
--and  a.project_name  = b.project_name  
--and  a.bt_synonym_caption= b.Sourcecaption  
--and  b.Targetlanguageid  = 1  
--group by a.customer_name,a.project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,Targetcaption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name  
  
--insert into @de_glossary_lng_extn (customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)  
--select a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,  
--a.bt_synonym_caption,a.data_type,a.length,@req_no as ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,1  
--from de_glossary a  (nolock)  
--where a.customer_name  = @customername  
--and  a.project_name  = @projectname  
----and  a.ecrno    = @req_no  
--and  a.process_name  = @processname  
--and  a.component_name = @componentname  
  
declare @language_code engg_name  
  
declare langcurs cursor FAST_FORWARD  for  
  
select quick_code  
from ep_language_met (nolock)  
--where quick_code <>1  
  
  
open langcurs  
  
while (1=1)  
begin  
fetch next from langcurs into @language_code  
  
if @@fetch_status <> 0  
break  
  
insert into @de_glossary_lng_extn(customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,  
data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)  
select distinct a.customer_name,a.project_name,a.process_name,a.component_name,a.bt_synonym_name,  
(case when b.Targetcaption IS NULL then a.bt_synonym_caption  else b.Targetcaption  end ) ,--TECH-69346
a.data_type,a.length,@req_no,singleinst_sample_data,multiinst_sample_data,bt_name,@language_code   
from @de_glossary a  left join   
  PLF_XLTranslated_Meta_Master b (nolock)  
    
on  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.bt_synonym_caption= b.Sourcecaption  
and     a.customer_name  = @customername  
and  a.project_name  = @projectname  
and  a.process_name  = @processname  
and  a.component_name = @componentname  
and  b.Targetlanguageid  = @language_code  
  
--and     a.ecrno       =   @req_no  
--join ep_language_met c(nolock)  
--on      b.Targetlanguageid  =   c.quick_code  
--and  b.Targetlanguageid  = @language_code  
--group by a.customer_name,a.project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,Targetcaption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name  
  
end  
  
close langcurs  
deallocate langcurs  
  
--insert into @de_glossary_lng_extn(customer_name,project_name,process_name,component_name,bt_synonym_name,  
--bt_synonym_caption,data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,languageid)  
--select customer_name,project_name,process_name,component_name,bt_synonym_name,bt_synonym_caption,  
--data_type,[length],ecrno,singleinst_sample_data,multiinst_sample_data,bt_name,'1'  
--from   @de_glossary  
  
      
-- AHBG-27244 end      
      
--Code added for bugID: PLF2.0_01396 starts      
if exists( select 'x' from sysobjects (nolock) where name = 'de_customer_space' and type ='u')      
begin      
delete from de_fw_req_ilbo_view      
where customer_name = @customername      
and   project_name = @projectname      
and  process_name = @processname      
and   component_name = @componentname      
and   ecrno  = @req_no      
      
delete from de_fw_req_activity_ilbo_task--PLF2.0_06940      
where customer_name = @customername      
and   project_name = @projectname      
and   process_name = @processname      
and   component_name = @componentname      
and   ecrno  = @req_no      
end      
--Code added for bugID: PLF2.0_01396 ends      
-- for 2 different customer same process name & component name was given      
if not exists ( select  'x'      
from   de_fw_req_process(nolock)      
where  customer_name  =  @customername      
and    project_name   = @projectname      
and   processname   = @process_name_tmp      
)      
begin      
      
insert into de_fw_req_process      
(processname,processdesc,processlevelno,upduser,updtime,customer_name,      
project_name,timestamp,createdby,createddate,parentprocess,ecrno)--chan      
values      
(      
@process_name_tmp,@process_descr_tmp,1,@ctxt_user,@getdate,@customername,      
@projectname,1,@ctxt_user,@getdate,@process_name_tmp,@req_no      
)      
end      
      
-- To insert the value in de_fw_req_language      
--code modification by sangeetha  for  PNR2.0_21328  starts      
      
If not exists (select '*' from  sysobjects (nolock)      
  where name  =   'de_customer_space'      
  and  type   = 'U')      
begin       
      
insert into de_fw_req_language      
(langid,langdesc,upduser,updtime,customer_name,project_name,timestamp,createdby,createddate,ecrno)      
select      
quick_code,quick_code_value,@ctxt_user,@getdate,@customername,@projectname,1, @ctxt_user,@getdate,@req_no --chan      
from ep_language_met a (nolock)      
where quick_code_type = 'language_code'      
and  not exists (  select  'S'      
from  de_fw_req_language b (nolock)      
where  a.quick_code   = b.langid      
and   b.customer_name = @customername      
and   b.project_name = @projectname)      
      
end       
      
else       
  
begin      
      
insert into de_fw_req_language      
(langid,langdesc,upduser,updtime,customer_name,project_name,timestamp,createdby,createddate,ecrno)      
select      
quick_code,quick_code_value,@ctxt_user,@getdate,@customername,@projectname,1, @ctxt_user,@getdate,@req_no --chan      
from ep_language_met a (nolock)      
where quick_code_type = 'language_code'      
and  not exists (  select  'S'      
from  de_fw_req_language b (nolock)      
where  a.quick_code   = b.langid      
and   b.customer_name = @customername      
and   b.project_name  = @projectname      
and   b.ecrno       = @req_no)      
      
      
end        
      
--code modification by sangeetha  for  PNR2.0_21328 ends      
      
-- get the component sequence number.      
-- generating new component sequence number      
select  @sequenceno_tmp = isnull(max(isnull(sequenceno,0)), 0)      
from  de_fw_req_process_component(nolock)      
where  customer_name = @customername      
and  project_name = @projectname      
      
select @sequenceno_tmp = @sequenceno_tmp + 1      
      
      
if not exists (select 'x'      
from de_fw_req_process_component (nolock)      
where  customer_name = @customername      
and  project_name = @projectname      
and  parentprocess = @process_name_tmp      
and  componentname   = @fp_id      
)      
begin      
-- inserting a record for the new component.      
insert into de_fw_req_process_component      
(componentname,componentdesc,parentprocess,      
upduser,updtime,sequenceno, customer_name,      
project_name,timestamp,createdby,createddate,ecrno)      
values (  @fp_id,@component_descr_tmp, @process_name_tmp,      
@ctxt_user,@getdate,@sequenceno_tmp,@customername,      
@projectname,0,@ctxt_user,@getdate,@req_no)  --chan      
end      
      
--inserting a record into de_fw_req_component_local_info      
insert into de_fw_req_component_local_info      
(componentname,langid,componentdesc,helpfilename,      
tooltiptext,upduser,updtime,summarytext,customer_name,      
project_name,process_name,timestamp,createdby,createddate,ecrno)      
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05      
--Code modified For BugId : PNR2.0_5014      
select distinct @componentname ,languageid,bt_synonym_caption,null,      --distinct added against TECH-74216
'',@ctxt_user,@getdate,null,@customername,      
@projectname , @process_name_tmp,1,@ctxt_user,@getdate,@req_no --chan      
from @de_glossary_lng_extn a,      
de_fw_req_language  b(nolock)      
where a.customer_name  = @customername      
and  a.project_name  = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @componentname      
and  a.bt_synonym_name = @componentname      
and  a.customer_name  = b.customer_name      
and  a.project_name  = b.project_name      
and  a.languageid  = b.langid      
and      not exists ( select 'x'      
from de_fw_req_component_local_info c (nolock)      
where  a.customer_name  = c.customer_name      
and  a.project_name  = c.project_name      
and     a.process_name  = c.process_name      
and  a.component_name = c.componentname      
and  a.languageid  = c.langid)      
      
--Code added for BugID:PNR2.0_8241 Starts      
if exists(select 'x'      
from de_business_term a(nolock)      
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name = @processname      
and  a.component_name = @componentname      
and   isnull(a.precision_type, '') <> ''      
and  a.precision_type not in (select distinct b.pt_name      
from de_precision_type b (nolock)      
where b.customer_name = @customername      
and  b.project_name = @projectname      
and  b.process_name = @processname      
and  b.component_name = @componentname      
and  b.customer_name = a.customer_name      
and  b.project_name  = a.project_name      
and  b.process_name = a.process_name      
and  b.component_name =a.component_name  )      
      
)      
begin      
      
select  @bt_name_tmp = a.bt_name,@precisiontype = a.precision_type      
from de_business_term a(nolock)      
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name = @processname      
and  a.component_name = @componentname      
and   isnull(a.precision_type, '') <> ''      
and  a.precision_type not in (select distinct b.pt_name      
from de_precision_type b (nolock)      
where b.customer_name = @customername      
and  b.project_name = @projectname      
and  b.process_name = @processname      
and  b.component_name = @componentname      
and  b.customer_name = a.customer_name      
and  b.project_name  = a.project_name      
and  b.process_name = a.process_name      
and  b.component_name =a.component_name )      
      
      
      
set @msg = 'For The btsynonym  ' + @bt_name_tmp + ' the mapped Precision type '+  @precisiontype +' is not Defined for the Component.'      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@uidescr_tmp,      
'',      
'',      
'',      
@m_errorid output      
Return      
      
end      
      
--code modified for the call id :PNR2.0_13217      
IF exists (select  'x'      
from  de_action a (nolock),      
de_action b (nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name    = @processname      
and   a.component_name  = @componentname      
and a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.task_name       = b.task_name      
AND   a.task_descr      <> b.task_descr )      
begin      
      
select  @msg = 'Task Description getting duplicated For the task '''+a.task_name+'''.Pls change the task description and proceed.'      
from  de_action a (nolock),      
de_action b (nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name    = @processname      
and   a.component_name  = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.task_name       = b.task_name      
AND   a.task_descr      <> b.task_descr      
      
      
      
exec engg_error_sp 'de_fw_req_migrate_config',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@uidescr_tmp,     
'',    '',      
'',      
@m_errorid output      
Return      
      
end      
      
IF exists (select  'x'      
from  de_action_lng_extn a (nolock),      
de_action_lng_extn b (nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name    = @processname      
and   a.component_name  = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.task_name       = b.task_name      
and   a.languageid      = b.languageid      
AND   a.task_descr      <> b.task_descr )      
begin      
      
declare @lang engg_name ,@tsk_name engg_name,@lng_id engg_seqno      
select  @tsk_name = a.task_name,      
@lng_id   = a.languageid      
from  de_action_lng_extn a (nolock),      
de_action_lng_extn b (nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name    = @processname      
and   a.component_name  = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.task_name       = b.task_name      
and   a.languageid      = b.languageid      
AND   a.task_descr      <> b.task_descr      
      
      
-- Modification for PNR2.0_27090 starts       
/*      
if (@lng_id = 1)      
begin      
select @lang = 'English'      
end      
else      
if (@lng_id = 2)      
begin      
select @lang = 'german'      
end      
*/      
      
select @lang  = quick_code_value       
from ep_language_met (nolock)      
where  quick_code  = @lng_id      
and    quick_code_type  = 'language_code'      
      
-- Modification for PNR2.0_27090 ends       
      
select  @msg = 'For the Language '''+@lang+''' Task Description getting duplicated For the task '''+@tsk_name+'''.Pls change the task description and proceed.'      
      
exec engg_error_sp 'de_fw_req_migrate_config',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@uidescr_tmp,      
'',      
'',      
'',      
@m_errorid output      
Return      
      
end      
      
--code modified for the call id : PNR2.0_13217      
      
--code added by chanheetha N A for the call id :PNR2.0_11331 on 08-Dec-2006      
      
-- code modified by praveen kumar A for call id : PNR2.0_18241 on 18-june-2008 starts        
if exists (select 'x'      
from   de_report_action_dataset_segment a(nolock)      
where a.customer_name  = @customername      
and   a.project_name   = @projectname      
and   a.process_name   = @processname      
and   a.component_name = @componentname      
and   not exists  ( select 'x'      
from  de_report_action_dataset_dataitem b (nolock)      
where b.customer_name   = a.customer_name      
and  b.project_name    =  a.project_name      
and  b.process_name    =  a.process_name      
and  b.component_name  =  a.component_name      
and  b.activity_name = a.activity_name      
and  b.ui_name   = a.ui_name      
and  b.page_bt_synonym = a.page_bt_synonym      
and  b.action_name  = a.action_name      
and b.report_name = a.report_name      
and  b.dataset_name  = a.dataset_name ))      
begin      
      
declare @seg_name engg_name ,@act_name engg_name,@activity_name engg_name,@ui_name engg_name      
      
-- select @seg_name = a.segment_name,      
-- @act_name = a.action_name,      
-- @activity_name = a.activity_name, /* PNR2.0_11770 */      
-- @ui_name  = a.ui_name      
-- from   de_report_action_segment a(nolock)      
-- where a.customer_name  = @customername      
-- and   a.project_name   = @projectname      
-- and   a.process_name   = @processname      
-- and   a.component_name = @componentname      
-- and   not exists  ( select 'x'      
-- from  de_report_action_segment_dataitem b (nolock)      
-- where b.customer_name   = a.customer_name      
-- and  b.project_name    =  a.project_name      
-- and  b.process_name    =  a.process_name      
-- and  b.component_name  =  a.component_name      
-- and  b.activity_name = a.activity_name      
-- and  b.ui_name   = a.ui_name      
-- and  b.page_btsynonym = a.page_btsynonym      
-- and  b.action_name  = a.action_name      
-- and  b.segment_name  = a.segment_name )      
      
      
      
select @seg_name = a.dataset_name, -- code modified by Gowrisankar M on 21-Dec-2009 for PNR2.0_25310      
@act_name = a.action_name,      
@activity_name = a.activity_name,      
@ui_name  = a.ui_name      
from   de_report_action_dataset_segment a(nolock)      
where a.customer_name  = @customername     
and   a.project_name   = @projectname      
and   a.process_name   = @processname      
and   a.component_name = @componentname      
and   not exists  ( select 'x'      
from  de_report_action_dataset_dataitem b (nolock)      
where b.customer_name   = a.customer_name      
and  b.project_name    =  a.project_name      
and  b.process_name    =  a.process_name      
and  b.component_name  =  a.component_name      
and  b.activity_name = a.activity_name      
and  b.ui_name   = a.ui_name      
and  b.page_bt_synonym = a.page_bt_synonym      
and  b.action_name  = a.action_name      
and b.report_name = a.report_name      
and  b.dataset_name  = a.dataset_name ) -- code modified by praveen kumar A for call id : PNR2.0_18241 on 18-june-2008 ends      
      
-- code modified by Gowrisankar M on 21-Dec-2009 for PNR2.0_25310 -Begins      
set @msg = 'Dataitem does not exists for the Report Dataset "'+@seg_name+'" under the Task : "'+ @act_name +'"'+ ' for the Activity/UI : '+@activity_name+'/'+ @ui_name      
-- code modified by Gowrisankar M on 21-Dec-2009 for PNR2.0_25310 -Ends      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@uidescr_tmp,      
'',      
'',      
'',      
@m_errorid output      
Return      
      
end      
--code added by chanheetha N A for the call id :PNR2.0_11331 on 08-Dec-2006      
      
      
--code added by Sangeetha G for PNR2.0_16100 starts      
      
      
declare @dataitem_name  engg_name      
declare @action_name  engg_name      
declare @dataset_name  engg_name      
      
      
if exists (select 'x'      
from   de_report_action_dataset_dataitem a(nolock) ,      
de_glossary b (nolock)      
where a.customer_name    =  @customername      
and   a.project_name     =  @projectname      
and   a.process_name     =  @processname      
and   a.component_name   =  @componentname      
and   a.customer_name    =  b.customer_name      
AND   a.project_name     =  b.project_name      
AND   a.process_name   = b.process_name      
and   a.component_name   =  b.component_name      
and   a.dataitem_name  = b.BT_Synonym_name      
and   isnull(b.bt_name, '') = ''      
)      
      
begin      
select  @action_name  =  a.action_name ,      
@dataset_name = a.dataset_name,      
@dataitem_name  = a.dataitem_name      
      
from   de_report_action_dataset_dataitem a(nolock) ,      
de_glossary b (nolock)      
where a.customer_name    =  @customername      
and   a.project_name     =  @projectname      
and   a.process_name     =  @processname      
and   a.component_name   =  @componentname      
and   a.customer_name    =  b.customer_name      
AND   a.project_name     =  b.project_name      
AND   a.process_name   = b.process_name      
and   a.component_name   =  b.component_name      
and   a.dataitem_name  = b.BT_Synonym_name      
and   isnull(b.bt_name, '') = ''      
      
      
select  @msg = 'BT has not been mapped to the dataitem '+''''+  @dataitem_name +''''+ ' under the dataset ' + ''''+ @dataset_name+'''' + ' for the report task '+ '''' + @action_name + ''''      
      
exec engg_error_sp      
'de_fw_req_migrate_config',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
      
      
Return      
end      
      
--code added by Sangeetha G for PNR2.0_16100 Ends      
      
      
select @bt_name_tmp = ''      
--Code added for BugID:PNR2.0_8241 Ends      
-- for inserting the new precision types      
insert into de_fw_req_precision      
(precisiontype,  totallength,  decimallength,   upduser,      
updtime,   customer_name,  project_name,   timestamp,      
createdby,   createddate,  process_name,   component_name,ecrno)      
select      
pt_name,   total_length,  decimal_length,   @ctxt_user,      
@getdate,   customer_name,  project_name,   1,      
createdby,   createddate,  process_name,   component_name,@req_no      
from de_precision_type (nolock)      
where customer_name = @customername      
and  project_name = @projectname      
and  process_name = @processname      
and  component_name = @fp_id      
--chan      
and  pt_name not in (select precisiontype from de_fw_req_precision      
where upper(customer_name) = @customername      
and  upper(project_name)  = @projectname      
and  process_name = @processname   --Added for bugid - PNR2.0_25798       
and  component_name   = @fp_id      
)      
      
--  --TO INCLUDE MODEFLAG      
--  insert into de_fw_req_bterm(      
--     btname,    btdesc,    isbterm,    datatype,      
--     upduser,   updtime,   customer_name,   project_name,      
--     timestamp,   createdby,   createddate,   modifiedby,      
--     modifieddate,  length,    precisiontype,   minvalue,      
--     maxvalue,   process_name,  component_name)      
--  values(   
--     'ModeFlag',   'ModeFlag',   1,      'char',      
--     @ctxt_user,   @getdate,   @customername,   @projectname,      
--     1,     @ctxt_user,   @getdate,    @ctxt_user,      
--     @getdate,   2,     NULL,     NULL,      
--     NULL,    @processname,  @componentname)      
      
-- for inserting the new bts in fw_req_bterm      
insert into de_fw_req_bterm      
(btname,  btdesc,    isbterm,  datatype,      
length,   precisiontype,  minvalue,  maxvalue,      
upduser,  updtime,   customer_name, project_name,      
timestamp,  createdby,   createddate, process_name,      
component_name,ecrno)      
select      
bt_name,   bt_descr,   1,    data_type,      
length,    precision_type, null,   null,      
@ctxt_user,   @getdate,  customer_name, project_name,      
1,     createdby,  createddate, process_name,      
component_name,  @req_no      
from de_business_term a(nolock)      
where a.customer_name  = @customername      
and    a.project_name  = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @fp_id      
and  len(a.bt_name)  <= 30      
--chan      
and     a.bt_name    not in (  select b.btname      
from   de_fw_req_bterm b(nolock)      
where   b.customer_name  = a.customer_name      
and     b.project_name   = a.project_name      
and   b.process_name   = a.process_name      
and   b.component_name = a.component_name )      
      
      
      
--code added by senthil for Bugid : PNR2.0_1433 -- Start      
--TO INCLUDE MODEFLAG      
if not exists ( select  1      
from  de_fw_req_bterm (nolock)      
where  customer_name = @customername      
and  project_name = @projectname      
and  process_name = @processname      
and  component_name = @componentname      
and  btname   = 'ModeFlag' )      
begin      
insert into de_fw_req_bterm(      
btname,    btdesc,    isbterm,    datatype,      
upduser,   updtime,   customer_name,   project_name,      
timestamp,   createdby,   createddate,   modifiedby,      
modifieddate,  length,    precisiontype,   minvalue,      
maxvalue,   process_name,  component_name,   ecrno)      
values(      
'ModeFlag',   'ModeFlag',   1,      'char',      
@ctxt_user,   @getdate,   @customername,   @projectname,      
1,     @ctxt_user,   @getdate,    @ctxt_user,      
@getdate,   2,     NULL,     NULL,      
NULL,    @processname,  @componentname,   @req_no)      
end      
--code added by senthil for Bugid : PNR2.0_1433 -- End      
      
      
insert into de_fw_req_bterm_group      
(componentname,  btname,  upduser,  updtime,customer_name, project_name,process_name,ecrno)      
select component_name, bt_name, @ctxt_user,  @getdate, customer_name , project_name,process_name,@req_no --chan      
from de_business_term a(nolock)      
where customer_name = @customername      
and  project_name  = @projectname      
and  process_name  = @processname      
and  component_name = @componentname      
and  len(bt_name) <= 30      
and     bt_name not in ( select btname      
from de_fw_req_bterm_group a (nolock)      
where customer_name = @customername      
and    project_name = @projectname      
and  process_name = @processname      
and  componentname = @fp_id)      
      
      
-- code modified by Ganesh on 20/1/05 for the bugid :: ECENG203SYS_000160      
-- INSERT statement conflicted with TABLE FOREIGN KEY constraint 'de_fw_des_publish_br_logical_parameter_fkey_de_fw_req_publish_bterm'. The conflict occurred in database 'RVW20APPDB', table 'de_fw_req_publish_bterm'      
      
declare @logicalparametername engg_name,      
@btname     engg_name,      
@method_name engg_name      
      
select  @count = 0      
select @count=count(a.process_name)      
from de_fw_des_br_logical_parameter a (nolock)      
where a.customer_name    = @customername      
and    a.project_name     = @projectname      
and  a.process_name    = @processname      
and  a.component_name  = @componentname      
and  not exists (      
select 's'      
from de_fw_req_bterm b (nolock)      
where a.customer_name    = b.customer_name      
and    a.project_name     = b.project_name      
and  a.process_name    = b.process_name      
and  a.component_name  = b.component_name      
and  a.btname    = b.btname)      
      
if @count > 0      
begin      
--code modified by kiruthika for bugid:PNR2.0_8068      
select  top 1 @method_name=a.method_name,@logicalparametername=a.logicalparametername,      
@btname=a.btname      
from de_fw_des_br_logical_parameter a (nolock)      
where a.customer_name    = @customername      
and    a.project_name     = @projectname      
and  a.process_name    = @processname      
and  a.component_name  = @componentname      
and  not exists (      
select 's'      
from de_fw_req_bterm b (nolock)      
where a.customer_name    = b.customer_name      
and    a.project_name     = b.project_name      
and  a.process_name    = b.process_name      
and  a.component_name  = b.component_name      
and  a.btname    = b.btname)      
set @msg = 'In the Method:'+@method_name+'for the parameter:'+@logicalparametername+'the btname:'+@btname+'used is not defined for the component.'      
--set @msg = 'One or more business terms mapped with the method parameter doesnot exists for the component.'      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
      
      
-- From de_fw_req_migrate_btsynonym      
      
-- To add the filler2 in the chk      
--  Check for UI Header Control Detail      
-- Code modified by Gowrisankar for PNR2.0_14756 on 31-Jul-2007      
--  select @count = 0      
--  select  @uidescr_tmp  = d.ui_descr      
--  from de_ui_control    a (nolock),      
--    es_comp_ctrl_type_mst  b (nolock),      
--    de_glossary    c (nolock),      
--    de_ui_ico    d(nolock)      
--  where a.customer_name    = @customername      
--  and    a.project_name     = @projectname      
--  and  a.process_name    = @processname      
--  and  a.component_name  = @componentname      
--      
--  and    a.customer_name    = b.customer_name      
--  and    a.project_name     = b.project_name      
--      
--      
--  and  a.process_name   = b.process_name      
--  and  a.component_name  = b.component_name      
--  and    a.control_type   = b.ctrl_type_name      
--      
--  and    a.customer_name    = c.customer_name      
--  and    a.project_name     = c.project_name      
--  and  a.process_name   = c.process_name      
--  and    a.component_name   = c.component_name      
--  and    a.control_bt_synonym  = c.bt_synonym_name      
--      
--  and    a.customer_name    = d.customer_name      
--  and    a.project_name     = d.project_name      
--  and  a.process_name   = d.process_name      
--  and    a.component_name   = d.component_name      
--  and  a.activity_name   = d.activity_name      
--  and  a.ui_name    = d.ui_name      
--      
--  --and    b.base_ctrl_type    not in ('link','radiobutton','button','line', 'Grid')--added by Ganesh      
--  and    b.base_ctrl_type    not in ('link','button','line', 'Grid','label')--modified for bugid:PNR2.0_9192--PNR2.0_14041      
--  and    a.control_type    not in ('filler', 'filler2')--added by Ganesh      
--  and  isnull(c.bt_name,'')  = ''      
      
      
declare @activityname_temp engg_name, @uiname_temp engg_name, @activitydesc_temp engg_name, @uidesc_temp engg_name      
select @btsyntmp = ''      
      
select  @activityname_temp = a.activity_name, @uiname_temp  = a.ui_name, @btsyntmp = c.bt_synonym_name      
--  select  @count = count(a.component_name)      
from de_ui_control    a (nolock),      
es_comp_ctrl_type_mst  b (nolock),      
de_glossary    c (nolock)      
where a.customer_name    = @customername      
and    a.project_name     = @projectname      
and  a.process_name    = @processname      
and  a.component_name  = @componentname      
and    a.customer_name    = b.customer_name      
and    a.project_name     = b.project_name      
--code added on 16-May-2006 for the bug id :PNR2.0_8491      
and a.process_name   = b.process_name      
and    a.control_type   = b.ctrl_type_name      
and  a.component_name  = b.component_name      
and  a.process_name   = b.process_name      
and    a.customer_name    = c.customer_name      
and    a.project_name     = c.project_name      
--code added on 16-May-2006 for the bug id :PNR2.0_8491      
and a.process_name   = c.process_name      
and    a.component_name   = c.component_name      
and    a.control_bt_synonym  = c.bt_synonym_name      
-- and    b.base_ctrl_type    not in ('link','radiobutton','button','line', 'Grid')--added by Ganesh      
and    b.base_ctrl_type    not in ('link','button','line', 'Grid','label')--Modified for bugid:PNR2.0_9192--PNR2.0_14041      
and    a.control_type    not in ('filler', 'filler2')--added by Ganesh      
and  isnull(c.bt_name,'')  = ''      
      
-- --  if @count > 0      
if isnull(@btsyntmp,'') <> ''      
begin      
-- --    set @msg = 'One or more header btsynonym(s) are not mapped with the businessterm For the UI <%1>'      
      
select @activitydesc_temp = activityname      
from fw_bpt_activity    a(nolock),      
fw_bpt_function_component b(nolock)      
where a.customerid = b.customerid      
and  a.projectid  = b.projectid      
and  a.bpid   = b.bpid      
and  a.functionid = b.functionid      
and  b.customerid = @customername      
and  b.projectid  = @projectname      
and  b.bpid   = @processname      
and  b.componentname = @componentname      
and  a.activityid = @activityname_temp      
      
select @uidesc_temp = uiname      
from fw_bpt_ui     a(nolock),      
fw_bpt_function_component b(nolock)      
where a.customerid = b.customerid      
and  a.projectid  = b.projectid      
and  a.bpid   = b.bpid      
and  a.functionid = b.functionid      
and  b.customerid = @customername      
and  b.projectid  = @projectname      
and  b.bpid   = @processname      
and  b.componentname = @componentname      
and  a.uiid   = @uiname_temp      
      
-- Code modified by Gowrisankar for PNR2.0_14756 on 31-Jul-2007      
set @msg = 'The header btsynonym "'+@btsyntmp+'", in Activity "<%1>"; UI "<%2>", is not mapped with any businessterms.'      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@activitydesc_temp,  -- code modified for PNR2.0_14897 on 09-Aug-2007      
@uidesc_temp,   -- code modified for PNR2.0_15171 on 31-Aug-2007      
'',      
'',      
@m_errorid output      
Return      
end      
      
      
--  Check for UI Grid Detail      
-- Code modified by Gowrisankar for PNR2.0_14756 on 31-Jul-2007      
--  select @count =0      
--      
--  select  @uidescr_tmp = ui_descr      
--  from de_ui_grid      a (nolock),      
--    es_comp_ctrl_type_mst  b (nolock),      
--    de_glossary    c (nolock),      
--    de_ui_ico    d (nolock)      
--  where a.customer_name   = @customername      
--  and    a.project_name    = @projectname      
--  and  a.process_name  = @processname      
--  and  a.component_name  = @componentname      
--      
--  and    a.customer_name   = b.customer_name      
--  and    a.project_name    = b.project_name      
--  and  a.process_name   = b.process_name      
--  and  a.component_name = b.component_name      
--  and    a.column_type   = b.ctrl_type_name      
--      
--  and    a.customer_name   = c.customer_name      
--  and    a.project_name    = c.project_name      
--  and  a.process_name   = c.process_name      
--  and    a.component_name  = c.component_name      
--  and a.column_bt_synonym = c.bt_synonym_name      
--      
--  and    a.customer_name   = d.customer_name      
--  and    a.project_name    = d.project_name      
--  and  a.process_name  = d.process_name      
--  and    a.component_name  = d.component_name      
--  and  a.activity_name  = d.activity_name      
--  and  a.ui_name   = d.ui_name      
--      
--  and    b.base_ctrl_type   not in ('link','radiobutton','button','filler','line')--added by Ganesh      
--  and  isnull(c.bt_name,'')= ''      
      
select @btsyntmp = ''      
      
select  @activityname_temp = a.activity_name, @uiname_temp  = a.ui_name, @btsyntmp = c.bt_synonym_name      
--  select  @count = count(a.component_name)      
from de_ui_grid      a (nolock),      
es_comp_ctrl_type_mst  b (nolock),      
de_glossary    c (nolock)      
where a.customer_name   = @customername      
and    a.project_name    = @projectname      
and  a.process_name  = @processname      
and  a.component_name  = @componentname      
      
and    a.customer_name   = b.customer_name      
and    a.project_name    = b.project_name      
and  a.process_name   = b.process_name      
      
and    a.column_type   = b.ctrl_type_name      
and  a.component_name  = b.component_name      
and    a.customer_name   = c.customer_name      
and    a.project_name    = c.project_name      
and  a.process_name   = c.process_name --PNR2.0_11087      
and    a.component_name  = c.component_name      
and    a.column_bt_synonym = c.bt_synonym_name      
      
--  and    b.base_ctrl_type   not in ('link','radiobutton','button','filler','line')--added by Ganesh      
and    b.base_ctrl_type   not in ('radiobutton','button','filler','line')--PNR2.0_11087      
and  isnull(c.bt_name,'')= ''      
      
--  if @count > 0      
if isnull(@btsyntmp,'') <> ''      
begin      
--    set @msg = 'One or more grid column btsynonym(s) are not mapped with the businessterm For UI <%1>'      
      
select @activitydesc_temp = activityname      
from fw_bpt_activity    a(nolock),      
fw_bpt_function_component b(nolock)      
where a.customerid = b.customerid      
and  a.projectid  = b.projectid      
and  a.bpid   = b.bpid      
and  a.functionid = b.functionid      
and  b.customerid = @customername      
and  b.projectid  = @projectname      
and  b.bpid   = @processname      
and  b.componentname = @componentname      
and  a.activityid = @activityname_temp      
      
select @uidesc_temp = uiname      
from fw_bpt_ui     a(nolock),      
fw_bpt_function_component b(nolock)      
where a.customerid = b.customerid      
and  a.projectid  = b.projectid      
and  a.bpid   = b.bpid      
and  a.functionid = b.functionid      
and  b.customerid = @customername      
and  b.projectid  = @projectname      
and  b.bpid   = @processname      
and  b.componentname = @componentname      
and  a.uiid   = @uiname_temp      
      
-- Code modified by Gowrisankar for PNR2.0_14756 on 31-Jul-2007      
set @msg = 'The grid column btsynonym "'+@btsyntmp+'", in Activity "<%1>"; UI "<%2>", is not mapped with any businessterms.'      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@activitydesc_temp,  -- code modified for PNR2.0_14897 on 09-Aug-2007      
@uidesc_temp,   -- code modified for PNR2.0_15171 on 31-Aug-2007      
'',      
'',      
@m_errorid output      
Return      
end      
      
--Validation added by Senthil for Call ID : PNR2.0_11119      
select  @service_tmp  = '',      
@dataitem_tmp  = ''      
      
select  @service_tmp  = a.servicename,     
@dataitem_tmp  = a.dataitemname      
from   de_fw_des_service_dataitem a(nolock),      
de_glossary b(nolock)      
where  a.customer_name  = @customername      
and    a.project_name      = @projectname      
and    a.process_name      = @processname      
and    a.component_name = @componentname      
and    a.customer_name    = b.customer_name      
and    a.project_name     = b.project_name      
and    a.process_name      = b.process_name      
and    a.component_name    = b.component_name      
and    a.dataitemname      = b.bt_synonym_name      
-- and    a.servicename       = @servicename      
AND    isnull(b.bt_name,'')=''      
     
if isnull(@service_tmp,'') <> ''      
begin      
      
Select  @msg =   'For the Service Dataitem : <%1> of the service : <%2> Bt name is not mapped'      
      
exec engg_error_sp 'de_fw_req_migrate_config',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
@dataitem_tmp,      
@service_tmp,      
'',      
'',      
@m_errorid output      
Return      
end      
      
      
      
      
--  Check for de_hidden_view      
--  select  @count = 0      
--      
--  select  @count=count(a.component_name)      
select @btsyntmp = ''      
      
select  @btsyntmp = c.bt_synonym_name      
from de_hidden_view  a (nolock),      
de_glossary  c (nolock)      
where a.customer_name     = @customername      
and    a.project_name      = @projectname      
and  a.process_name    = @processname      
and  a.component_name    = @componentname      
      
and    a.customer_name     = c.customer_name      
and    a.project_name      = c.project_name      
and  a.process_name     = c.process_name      
and    a.component_name    = c.component_name      
and    a.hidden_view_bt_synonym  = c.bt_synonym_name      
      
and  isnull(c.bt_name,'')   = ''      
and  isnull(a.HIDDEN_VIEW_SOURCE,'')   = '' -- Code modified by Gowrisankar M for PNR2.0_12117, PNR2.0_12119 on 05-Feb-2007      
      
--  if @count > 0      
if isnull(@btsyntmp,'') <> ''      
begin      
--    set @msg = 'one or more hidden view btsynonym(s) are not mapped with the businessterm'      
set @msg = 'The hidden view btsynonym "'+@btsyntmp+'" is not mapped with the businessterm'      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
      
      
--  Check for de_hidden_view      
--  select  @count = 0      
--      
--  select  @count=count(a.component_name)      
select @btsyntmp = ''      
      
select  @btsyntmp = c.bt_synonym_name      
from de_hidden_view   a (nolock),      
de_glossary   c (nolock)      
where a.component_name   = @fp_id      
and    a.customer_name    = @customername      
and    a.project_name     = @projectname      
and  a.process_name    = @processname      
and  a.component_name   = @componentname      
      
and    a.customer_name     = c.customer_name      
and    a.project_name      = c.project_name      
and  a.process_name    = c.process_name      
and    a.component_name    = c.component_name      
and    a.new_control_bt_synonym  = c.bt_synonym_name      
      
and  isnull(c.bt_name,'')   = ''      
and  isnull(a.HIDDEN_VIEW_SOURCE,'')   = '' -- Code modified by Gowrisankar M for PNR2.0_12117, PNR2.0_12119 on 05-Feb-2007      
--      
--  if @count > 0      
if isnull(@btsyntmp,'') <> ''      
begin      
--  Set @msg = 'ONE OR MORE HIDDEN VIEW BTSYNONYM(S) ARE NOT MAPPED WITH THE BUSINESSTERM'      
Set @msg = 'The hidden view btsynonym "'+@btsyntmp+'" is not mapped with the businessterm'      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
--code modified by kiruthika for bugid:PNR2.0_11121      
--de_re_wsinp_cat_parameters      
select @btsyntmp = ''      
      
select  @btsyntmp = a.bt_synonym_name      
from de_re_wsinp_cat_parameters   c (nolock),      
de_glossary   a (nolock),      
de_re_wsinp_area_dtl b (nolock)      
where a.customer_name    = @customername      
and    a.project_name     = @projectname      
and  a.process_name    = @processname      
and  a.component_name   = @componentname      
and    a.customer_name     = c.customer_code      
and    a.project_name      = c.project_code      
and c.customer_code    = b.customer_code      
and    c.project_code    = b.project_code      
and     c.area_code     = b.area_code      
and    a.customer_name     = b.customer_code      
and    a.project_name      = b.project_code      
and     a.component_name   = b.component_name      
and    a.bt_synonym_name    = c.bt_name      
and  isnull(a.bt_name,'')   = ''      
      
if isnull(@btsyntmp,'') <> ''      
begin      
Set @msg = 'The BTSynonym "'+@btsyntmp+'" is not mapped with the Business Term'      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
      
--Added by Shriram V on 18/03/2005 for Bug ID : PNR2.0_1496      
-- code modified by Ganesh  for the callid :: PNR2.0_2986 on 21/6/05      
select @count = 0      
select  @bt_name_tmp = bt_name      
from de_glossary    (nolock)      
where   customer_name    = @customername      
and project_name     = @projectname      
and  process_name   = @processname      
and  component_name   = @componentname      
and  component_name+bt_name not in      
( select  component_name+bt_name      
from  de_business_term (nolock)      
where   customer_name  = @customername      
and    project_name   = @projectname      
and  process_name = @processname      
and  component_name = @componentname)      
and  isnull(bt_name,'') <> ''      
and  bt_name <> 'MODEFLAG'      
      
      
if isnull(@bt_name_tmp,'') <> ''      
begin      
      
Set @msg = 'Business Terms : '+ @bt_name_tmp +' Mapped With the BTSYNONYM(S) not Defined for the Component.'      
      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
      
-- Added by Shriram V on 18/02/2005 for Bug ID : PNR2.0_1496      
if not exists (select 'x'      
from de_fw_req_bterm_synonym (nolock)      
where customer_name = @customername      
and   project_name  = @projectname      
and   process_name  = @processname      
and   component_name= @componentname      
and   btsynonym     = 'ModeFlag'      )      
begin      
Insert into de_fw_req_bterm_synonym(      
btsynonym,    btname,     upduser,    updtime,      
customer_name,   project_name,   timestamp,    createdby,      
createddate,   modifiedby,    modifieddate,   process_name,      
component_name,   ecrno)      
values(  'ModeFlag',    'ModeFlag',    @ctxt_user,    @getdate,      
@customername,   @projectname,   1,      @ctxt_user,      
@getdate,    @ctxt_user,    @getdate,    @processname,      
@componentname,   @req_no)      
      
      
Insert into de_fw_req_lang_bterm_synonym      
(btsynonym,   langid,    foreignname,  longpltext,      
shortpltext,  shortdesc,   longdesc,   upduser,      
updtime,   customer_name,  project_name,  timestamp,      
createdby,   createddate,  process_name,  component_name,ecrno)      
select distinct      
'ModeFlag',   quick_code,   'ModeFlag',   'ModeFlag',      
'ModeFlag',   'ModeFlag',   'ModeFlag',   @ctxt_user,      
@getdate,   @customername,  @projectname,  1,      
@ctxt_user,   @getdate,   @processname,  @componentname,@req_no      
from ep_language_met (nolock)      
-- code modified by Sulochana on 04/11/2005 for Case ID : Platform_2.0.3.1_78      
where quick_code in ( Select langid      
from de_fw_req_language (nolock)      
where customer_name = @customername      
and project_name = @projectname      
)      
end      
      
insert into de_fw_req_bterm_synonym      
(btsynonym,  btname,   upduser, updtime,      
customer_name, project_name, timestamp, createdby,      
createddate, process_name, component_name,ecrno)      
select  bt_synonym_name,bt_name,  @ctxt_user, @getdate,      
customer_name, project_name, 1,   @ctxt_user,      
@getdate,  process_name, component_name, @req_no      
from de_glossary  (nolock)      
where customer_name  = @customername      
and     project_name  = @projectname      
and  process_name  =  @processname      
and  component_name  = @fp_id      
and  isnull(bt_name,'') <> ''      
-- code modified For BugId : PNR2.0_7453      
and  bt_synonym_name not in ('modeflag')      
and  len(bt_synonym_name) < 31      
and     bt_synonym_name not in (   select btsynonym      
from  de_fw_req_bterm_synonym (nolock)      
where customer_name = @customername      
and   project_name  = @projectname      
and   process_name  = @processname      
and   component_name= @componentname)      
    
      
-- code modified by Ganesh for the callid :: PNR2.0_3157 on 6/7/05      
insert into de_fw_req_lang_bterm_synonym      
(btsynonym,   langid,    foreignname,  longpltext,      
shortpltext,  shortdesc,   longdesc,   upduser,      
updtime,   customer_name,  project_name,  timestamp,      
createdby,   createddate,  process_name,  component_name,ecrno)      
select  distinct      
bt_synonym_name, languageid,   bt_synonym_name, bt_synonym_caption,      
bt_synonym_caption, bt_synonym_caption, bt_synonym_caption, @ctxt_user,      
@getdate,   customer_name,  project_name,  1,      
@ctxt_user,   @getdate,   process_name,  component_name, @req_no      
from @de_glossary_lng_extn  a  
where customer_name  = @customername      
and     project_name  = @projectname      
and  process_name  =  @processname      
and  component_name  = @fp_id      
and  isnull(bt_name,'') <> ''      
-- code modified For BugId : PNR2.0_7453      
and  bt_synonym_name not in ('modeflag')      
and  len(bt_synonym_name) < 31      
and  len(bt_synonym_caption) < 61 -- Code modified by Gowrisankar M for PNR2.0_16448 on 10-Jan-2008      
--Code Added by Sangeetha L fro BugID:pnr2.0_5489      
and   customer_name+project_name+process_name+component_name+bt_synonym_name      
in (select customer_name+project_name+process_name+component_name+btsynonym      
from  de_fw_req_bterm_synonym(nolock)      
where customer_name  = @customername      
and     project_name  = @projectname      
and  process_name  =  @processname      
and  component_name  = @fp_id)      
--Code Added by Sangeetha L fro BugID:pnr2.0_5489      
--chan      
and    not exists  (select 'x'  
from  de_fw_req_lang_bterm_synonym c(nolock)      
where a.customer_name  = c.customer_name      
and     a.project_name  = c.project_name      
and  a.process_name  = c.process_name      
and  a.component_name = c.component_name  
and  a.bt_synonym_name =c.btsynonym  
and  a.languageid  =c.langid)      
      
      
/*  Code Added By Balaji S on 18/05/2005      
To Check Whether Dataitem is Mapped to Business Term */      
select  @service_tmp  = '',      
@dataitem_tmp  = ''      
select  @service_tmp  = a.servicename,      
@dataitem_tmp  = a.dataitemname      
from de_fw_des_di_parameter   a (nolock)      
where a.customer_name   = @customername      
and    a.project_name    = @projectname      
and  a.process_name  = @processname      
and  a.component_name  = @componentname --code modified by Gowrisankar for PNR2.0_13486 on 02-May-2007      
and  not exists ( select 'x'      
from de_fw_req_bterm_synonym b(nolock)      
where b.customer_name   = a.customer_name      
and    b.project_name    = a.project_name      
and  b.process_name  = a.process_name      
and  b.component_name  = a.component_name      
and  b.btsynonym   = a.dataitemname )      
and  a.segmentname   <> 'Fw_context'      
      
if isnull(@service_tmp,'') <> ''      
begin      
set @msg = 'For the Existing Service <%1> , Dataitem <%2> is not mapped to Business Term'      
      
      
--- Code modified by Saravanan on 26/09/2005 to display service name & dataitem name in the error message -- START      
exec engg_error_sp 'de_fw_req_migrate_config',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
--      @uidescr_tmp,      
@service_tmp,      
@dataitem_tmp,      
'',      
'',      
@m_errorid output      
--- Code modified by Saravanan on 26/09/2005 to display service name & dataitem name in the error message -- END      
Return      
end      
      
      
-- from de_fw_req_migrate_uis      
insert into de_fw_req_ilbo      
(ilbocode,  description, ilbotype,  statusflag,      
upduser,  updtime,  customer_name, project_name,      
process_name, component_name, aspofilepath, ecrno)      
select distinct ui_name,  ui_descr,  case ui_type      
when  'EntryPoint'  then 1      
when  'Main'   then 2      
when  'Modify' then 3      
when 'MainModify' then 4      
when 'MainView'  then 5      
when 'Others'  then 6      
when 'Security'  then 7      
when 'View'   then 8      
when 'Snapshot'  then 9      
when 'Help'   then  6      
when 'Search' then 1      
else 6      
end,      
0,    @ctxt_user, @getdate, customer_name, project_name,      
process_name, component_name, ui_name+'_'+ui_name+'.asp',@req_no      
from de_ui (nolock)      
where customer_name = @customername      
and  project_name = @projectname      
and  process_name  = @processname      
and  component_name = @fp_id      
--chan      
and     ui_name   not in ( select ilbocode      
from de_fw_req_ilbo (nolock)      
where customer_name = @customername      
and  project_name = @projectname      
and  process_name  = @processname      
and  component_name = @fp_id )      
      
--update a      
--set  aspofilepath = activity_name+'_'+ui_name+'.asp'      
--from de_fw_req_ilbo  a (nolock),      
--de_ui   b (nolock)      
--where a.customer_name  = b.customer_name      
--and  a.project_name  = b.project_name      
--and  a.process_name  = b.process_name      
--and  a.component_name = b.component_name      
--and  a.ilbocode   = b.ui_name      
--and  b.customer_name  = @customername      
--and  b.project_name  = @projectname      
--and  b.process_name   = @processname      
--and b.component_name = @fp_id      
-----------------------------------------TECH-17752      
update a      
 set ilbotype = case  when b.ui_type = 'EntryPoint'  then 1      
                         when b.ui_type = 'Main'        then 2      
       when b.ui_type = 'Modify'      then 3      
       when b.ui_type = 'MainModify'  then 4      
       when b.ui_type = 'MainView'    then 5      
       when b.ui_type = 'Others'      then 6      
       when b.ui_type = 'Security'    then 7      
       when b.ui_type = 'View'        then 8      
       when b.ui_type = 'Snapshot'    then 9      
       when b.ui_type = 'Help'        then 6      
       when b.ui_type = 'Search'      then 1      
       else 6      
end,      
   aspofilepath = activity_name+'_'+ui_name+'.asp'      
from de_fw_req_ilbo  a (nolock),      
de_ui   b (nolock)      
where a.customer_name  = b.customer_name      
and  a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and  a.ilbocode   = b.ui_name      
and  b.customer_name  = @customername      
and  b.project_name  = @projectname      
and  b.process_name   = @processname      
and  b.component_name = @fp_id      
-----------------------------------------------TECH-17752      
    
      
-- to update the ui descrption from de glossary      
update de_fw_req_ilbo      
set  description   = bt_synonym_caption      
from de_fw_req_ilbo   a (nolock),      
de_glossary    b (nolock)      
where a.customer_name = b.customer_name      
and  a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and  a.ilbocode   = b.bt_synonym_name      
and  b.customer_name  = @customername      
and  b.project_name  = @projectname      
and  b.process_name   = @processname      
and  b.component_name = @fp_id      
      
-- for inserting the new uis in fp_req_ilbo_local_info      
insert into de_fw_req_ilbo_local_info      
(ilbocode,  langid,    description,   helpindex,      
upduser,  updtime,   customer_name,   project_name,      
process_name, component_name,  timestamp,    createdby,      
createddate, ecrno)      
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05      
select distinct      
a.ui_name,  languageid,   bt_synonym_caption,  1,      
@ctxt_user,  @getdate,    a.customer_name,  a.project_name,      
a.process_name, a.component_name, 1,      @ctxt_user,      
@getdate,@req_no      
from de_ui     a (nolock),      
@de_glossary_lng_extn b   
where a.component_name = @fp_id      
and  a.customer_name  = @customername      
and  a.project_name  = @projectname      
and  a.process_name   = @processname    
      
and  b.customer_name  = a.customer_name      
and  b.project_name  = a.project_name      
and  b.process_name  = a.process_name      
and  b.component_name = a.component_name      
and  b.bt_synonym_name = a.ui_name      
--chan      
and     ui_name   not in ( select ilbocode      
from    de_fw_req_ilbo_local_info c(nolock)      
where c.customer_name = b.customer_name      
and  c.project_name = b.project_name      
and  c.process_name  = b.process_name      
and  c.component_name= b.component_name      
and     c.langid  = b.languageid)      
      
-- from de_fw_req_migrate_ui_tabs      
-- for inserting into fw_req_ilbo_tabs      
insert into de_fw_req_ilbo_tabs      
(ilbocode,tabname,btsynonym,upduser,updtime,      
customer_name,project_name,process_name,component_name,      
timestamp,createdby,createddate,ecrno)      
select   ui_name,page_bt_synonym,page_bt_synonym,@ctxt_user,@getdate,      
customer_name, project_name,process_name,component_name,      
1,createdby,createddate,@req_no      
from de_ui_page a(nolock)      
where customer_name = @customername      
and     project_name = @projectname      
and  process_name  = @processname      
and  component_name = @fp_id      
and  page_bt_synonym <> '[mainscreen]'      
and     not exists   ( select 'x'      
from  de_fw_req_ilbo_tabs b (nolock)    
where b.customer_name  = a.customer_name      
and     b.project_name  = a.project_name      
and  b.process_name   = a.process_name      
and  b.component_name = a.component_name      
and     b.ilbocode   = a.ui_name      
and     b.tabname   = a.page_bt_synonym      
and     b.btsynonym   = a.page_bt_synonym)      
      
      
insert into de_fw_req_ilbo_tab_properties      
(ilbocode,  tabname,   propertyname,  value,      
upduser,  updtime,   customer_name,  project_name,      
process_name, component_name,  ecrno)      
select ui_name,  page_bt_synonym,  'Width',  '10',      
@ctxt_user,  @getdate,    customer_name,      
project_name, process_name,   component_name,@req_no      
from de_ui_page  p(nolock)      
where p.customer_name  = @customername      
and  p.project_name  = @projectname      
and  p.process_name   = @processname      
and  p.component_name = @fp_id      
and  p.page_bt_synonym not in('[mainscreen]')      
and     not exists   ( select 'x'      
from  de_fw_req_ilbo_tab_properties b (nolock)      
where b.customer_name  = p.customer_name      
and     b.project_name  = p.project_name      
and  b.process_name   = p.process_name      
and  b.component_name = p.component_name      
and     b.ilbocode   = p.ui_name      
and     b.tabname   = p.page_bt_synonym      
and     b.propertyname  = 'Width')      
      
-- to get the tab Sequence No      
-- starts here      
      
select @cnt_tmp = 0,      
@ui_tmp_chk = ''      
      
DECLARE seq_cur CURSOR FOR      
select distinct activity_name, ui_name, page_bt_synonym, horder,vorder      
from de_ui_page p (nolock)      
where p.customer_name  = @customername      
and  p.project_name  = @projectname      
and  p.process_name   = @processname      
and  p.component_name = @fp_id      
and  p.page_bt_synonym  not  in      
( select  pr.tabname      
from  de_fw_req_ilbo_tab_properties pr(nolock)      
where pr.customer_name = @customername      
and  pr.project_name  = @projectname      
and  pr.component_name = @fp_id      
and  pr.customer_name = p.customer_name      
and   pr.project_name  = p.project_name      
and   pr.component_name  = p.component_name      
and   pr.tabname   = p.page_bt_synonym      
and   pr.propertyname  = 'SequenceNo')      
and  p.page_bt_synonym <> '[mainscreen]'      
order by activity_name, ui_name, horder,vorder      
      
OPEN seq_cur      
      
WHILE (1=1)      
BEGIN      
FETCH NEXT FROM seq_cur      
INTO  @act_name_tmp,      
@ui_tmp,      
@page_tmp,      
@horder,      
@vorder      
      
if @@FETCH_STATUS <> 0      
break      
      
if (@ui_tmp_chk != @ui_tmp )      
set @cnt_tmp =  0      
      
set @cnt_tmp = @cnt_tmp + 1      
      
insert into de_fw_req_ilbo_tab_properties      
(ilbocode,   tabname,   propertyname,  value,      
upduser,   updtime,   customer_name,  project_name,      
process_name,  component_name,  ecrno)      
values (@ui_tmp,   @page_tmp,   'SequenceNo',  @cnt_tmp,  @ctxt_user,   @getdate,   @customername,  @projectname,      
@processname,  @fp_id,    @req_no)      
      
set @ui_tmp_chk = @ui_tmp      
      
END      
      
CLOSE seq_cur      
DEALLOCATE seq_cur      
      
-- FROM de_fw_req_migrate_activityuitask      
      
select @activityname_tmp = null,      
@activity_seq  = 0      
      
-- for generating the activity id.      
declare activity_cur cursor      
for      
select distinct activity_name      
from de_ui(nolock)      
where customer_name = @customername      
and     project_name = @projectname      
and  process_name =  @processname      
and component_name = @fp_id      
      
open activity_cur      
      
fetch next from activity_cur      
into  @activityname_tmp      
      
while (@@fetch_status = 0)      
begin      
      
-- to Get the Activity type from the blueprint tables      
-- code modified by Ganesh for the callid PNR2.0_3927 on 21/9/05      
-- To get the activity seq from BPT table      
select @activity_type = case a.activitytype      
when 'sys' then 2      
else 1      
end,      
@activity_seq =  Act_sequence_no,      
@accesskey = accesskey,      
@forcedActivity = isnull(IsForcedActivity,0)      
from fw_bpt_activity  a (nolock),      
fw_bpt_function_component b (nolock)      
where a.customerid = b.customerid      
and  a.projectid  = b.projectid      
and  a.bpid   = b.bpid      
and  a.functionid = b.functionid      
and  a.customerid = @customername      
and  a.projectid  = @projectname      
and  a.bpid   = @processname      
and  b.ComponentName = @fp_id      
and  a.activityid = @activityname_tmp      
      
select @devicetype = isnull(DeviceType,'')      
from de_fw_req_activity_devicetype_vw  a (nolock)      
where   a.customer_name = @customername      
and  a.process_name  = @projectname      
and  a.process_name   = @processname      
and  a.component_name = @fp_id      
and  a.activity_name = @activityname_tmp      
      
if isnull(@activity_seq, '') = ''      
begin      
set @msg = 'The Sequence Number for the Activity : '+ @activityname_tmp + ' Cannot be Blank.'      
exec engg_error_sp 'de_fw_req_migrate_btsynonym',      
2,      
@msg,      
@ctxt_language,      
@ctxt_ouinstance,      
@ctxt_service,      
@ctxt_user,      
'',      
'',      
'',      
'',      
@m_errorid output      
Return      
end      
--code modified by Sangeetha L On 18-10-2005 BugId:PNR2.0_4282      
--BugDescr:While generating deployment scripts with respect to an ECR, the activity description for the activities      
--not in the current ECR were generated incorrectly.      
      
select  @activity_descr =  bt_synonym_caption      
from de_glossary(nolock)      
where  customer_name  =  @customername      
and project_name = @projectname      
and  process_name  =   @processname      
and component_name = @componentname      
and bt_synonym_name =  @activityname_tmp      
--code modified by Sangeetha L On 18-10-2005 BugId:PNR2.0_4282      
      
--BugDescr:While generating deployment scripts with respect to an ECR, the activity description for the activities      
--not in the current ECR were generated incorrectly.      
select  @count = 0      
      
select  @count     = count(component_name)      
from de_fw_req_activity (nolock)      
where customer_name  = @customername      
and     project_name  = @projectname      
and  process_name   = @processname      
and  component_name  = @fp_id      
and    activityname  = @activityname_tmp      
      
if @count > 0      
begin      
select  @activityid_tmp     = activityid      
from de_fw_req_activity (nolock)      
where customer_name = @customername      
and     project_name = @projectname      
and  process_name  =  @processname      
and  component_name = @fp_id      
and    activityname =  @activityname_tmp      
      
update de_fw_req_activity      
set  activitytype =  @activity_type,     
activitydesc = @activity_descr,      
modifiedby  = @ctxt_user,      
modifieddate =  @getdate,      
activitysequence=  @activity_seq,      
accesskey = @accesskey ,      
IsForcedActivity = @ForcedActivity,      
devicetype  = @devicetype      
where customer_name = @customername      
and     project_name = @projectname      
and  process_name  =   @processname      
and  component_name = @fp_id      
and    activityname =  @activityname_tmp      
      
--Code Added For BugId : PNR2.0_3839      
      
update a      
set  activitydesc = bt_synonym_caption,      
modifiedby  = @ctxt_user,      
modifieddate =  @getdate      
from de_fw_req_activity_local_info  a (nolock),      
@de_glossary_lng_extn   b   
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name  = @processname      
and  a.component_name= @fp_id      
and    a.activity_name = @activityname_tmp      
and  a.customer_name = b.customer_name      
and  a.project_name = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name= b.component_name      
and  a.langid  = b.languageid      
and    a.activity_name = b.bt_synonym_name      
      
--code added by Sangeetha L for bug id:PNR2.0_8139 starts      
      
insert into de_fw_req_activity_local_info      
(activityid,langid,activitydesc,helpindex,tooltiptext,      
upduser,updtime,customer_name,project_name,process_name,      
component_name,activity_name,timestamp,createdby,createddate,ecrno)      
      
select distinct      
@activityid_tmp,languageid,b.bt_synonym_caption,null,null,      
@ctxt_user,@getdate,a.customer_name,a.project_name,a.process_name,      
a.component_name,a.activityname,1,@ctxt_user,@getdate,@req_no      
from de_fw_req_activity   a (nolock),      
@de_glossary_lng_extn b   
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name  = @processname      
and  a.component_name= @fp_id      
and    a.activityname = @activityname_tmp      
      
and  a.customer_name = b.customer_name      
and  a.project_name = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name= b.component_name      
and    a.activityname = b.bt_synonym_name      
and    not exists (select 'x' from de_fw_req_activity_local_info c(nolock)      
where  c.customer_name   = @customername      
and     c.project_name   = @projectname      
and     c.process_name   = @processname      
and     c.component_name  = @fp_id      
and     c.activityid   = @activityid_tmp      
and     c.activity_name   = @activityname_tmp      
and     c.customer_name   = b.customer_name      
and     c.project_name   = b.project_name      
and     c.process_name   = b.process_name      
and     c.component_name  = b.component_name      
and     c.activity_name   = b.bt_synonym_name      
and     c.langid    = b.languageid      
)      
--code added by Sangeetha L for bug id:PNR2.0_8139 ends      
end      
else      
begin      
/*PNR2.0_12211 */      
select @activityid_tmp = 0      
      
If exists ( select 'x'      
from  de_re_published_wsinp_nonrvw_actcode (nolock)      
where  customer_code  = @customername      
and    project_code  = @projectname      
and    component_name  = @fp_id      
and    activity_name   = @activityname_tmp      
and    isnull(activityid,0) <> 0)      
begin      
select @activityid_tmp   = isnull(activityid,0)      
from de_re_published_wsinp_nonrvw_actcode (nolock)      
where  customer_code  = @customername      
and    project_code  = @projectname      
and    component_name  = @fp_id      
and    activity_name   = @activityname_tmp      
and    isnull(activityid,0) <> 0      
end      
      
if isnull(@activityid_tmp,0) = 0      
begin      
select  @act_id   = max(isnull(activityid,0))/* PNR2.0_12211 */      
from de_fw_req_activity(nolock)      
      
--    select  @activityid_tmp   = isnull(@activityid_tmp,0)  + 1      
      
select @ws_act_id  = max(isnull(activityid,0))      
from  de_re_published_wsinp_nonrvw_actcode (nolock)      
      
    
if ( isnull(@act_id,0) >= isnull(@ws_act_id,0))      
begin      
select  @activityid_tmp   = isnull(@act_id,0)  + 1 --PNR2.0_12408      
end      
else      
begin      
select  @activityid_tmp   = isnull(@ws_act_id,0)  + 1 --PNR2.0_12408      
end      
end      
/* PNR2.0_12211*/      
--     select @activity_seq  = max(isnull(activitysequence,0)) + 1      
--     from de_fw_req_activity (nolock)      
--     where   customer_name  = @customername      
--     and     project_name  = @projectname      
--     and  process_name   =  @processname      
--     and  component_name  = @fp_id      
      
select @activity_seq  =  isnull(@activity_seq,0) + 1      
      
-- for inserting into fp_req_activity      
insert into de_fw_req_activity(      
activityid,    activityname,    activitydesc,    componentname,      
activitytype,   activityposition,   activitysequence,   iswfenabled,      
upduser,    updtime,     customer_name,    project_name,      
process_name,   component_name,    timestamp,     createdby,      
createddate,   ecrno,accesskey, IsForcedActivity, DeviceType)      
select @activityid_tmp,  @activityname_tmp,   @activity_descr,   @fp_id,      
@activity_type,   1,     @activity_seq,    1,      
@ctxt_user,    @getdate,     @customername,    @projectname,      
@processname,   @fp_id,      1,       @ctxt_user,      
@getdate,    @req_no,@accesskey, @ForcedActivity, @devicetype      
      
insert into de_fw_req_activity_local_info      
(activityid,langid,activitydesc,helpindex,tooltiptext,      
upduser,updtime,customer_name,project_name,process_name,      
component_name,activity_name,timestamp,createdby,createddate,ecrno)      
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05      
select distinct      
@activityid_tmp,languageid,b.bt_synonym_caption,null,null,      
@ctxt_user,@getdate,a.customer_name,a.project_name,a.process_name,      
a.component_name,a.activityname,1,@ctxt_user,@getdate,@req_no      
from de_fw_req_activity   a (nolock),      
@de_glossary_lng_extn b   
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name  = @processname      
and  a.component_name= @fp_id      
and    a.activityname = @activityname_tmp      
      
and  a.customer_name = b.customer_name      
and  a.project_name = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name= b.component_name      
and    a.activityname = b.bt_synonym_name      
and    not exists (select 'x' from de_fw_req_activity_local_info c(nolock)      
where  c.customer_name   = @customername      
and     c.project_name   = @projectname      
and     c.process_name   = @processname      
and     c.component_name  = @fp_id      
and     c.activityid   = @activityid_tmp      
and     c.activity_name   = @activityname_tmp      
and     c.customer_name   = b.customer_name      
and     c.project_name   = b.project_name      
and     c.process_name   = b.process_name      
and     c.component_name  = b.component_name      
and     c.activity_name   = b.bt_synonym_name      
and     c.langid    = b.languageid)      
end      
      
fetch next from activity_cur      
into  @activityname_tmp      
      
end -- while loop end.      
      
close activity_cur      
      
deallocate activity_cur      
      
      
-- for inserting the new tasks in fw_req_task      
/* PNR2.0_11346 */      
/* PNR2.0_11831 */      
insert into de_fw_req_task      
(taskname,tasktype,taskdesc,upduser,updtime,      
customer_name,project_name,timestamp,createdby,createddate,      
process_name,component_name, task_confirm_msg,task_status_msg,task_process_msg,ecrno) --Code Modified for PNR2.0_30869       
select distinct a.task_name, case ltrim(rtrim(a.task_type))      
when 'Init' then 'initialize'      
else a.task_type      
end,      
a.task_descr,  @ctxt_user, @getdate, a.customer_name,      
a.project_name, 1,   @ctxt_user, @getdate,      
a.process_name, a.component_name,  (  select top 1 task_confirm_msg      
from  de_action c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name     = @processname      
and   c.component_name   = @fp_id      
and   c.task_type  <> 'DISPOSAL'    -- code added for bug id : PNR2.0_30909      
and   isnull(c.task_confirm_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name     = b.project_name      
and   c.process_name  = b.process_name      
and   c.component_name   = b.component_name      
and   c.task_name        = b.task_name ) ,      
(select top 1 task_status_msg      
from  de_action c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name     = @processname      
and   c.component_name   = @fp_id      
and   isnull(c.task_status_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name     = b.project_name      
and   c.process_name     = b.process_name      
and   c.component_name   = b.component_name      
and   c.task_name        = b.task_name ) ,      
--Code Modification for PNR2.0_30869 starts       
(select top 1 task_process_msg       
from  de_action c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name    = @processname      
and   c.component_name   = @fp_id      
and   isnull(c.task_process_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name     = b.project_name      
and   c.process_name     = b.process_name      
and   c.component_name   = b.component_name      
and   c.task_name        = b.task_name ) ,@req_no      
from  de_action a (nolock),      
de_action b (nolock)      
where a.customer_name    = @customername      
and   a.project_name     = @projectname      
and   a.process_name     = @processname      
and   a.component_name   = @fp_id      
and   a.customer_name    = b.customer_name      
and   a.project_name     = b.project_name      
and   a.process_name     = b.process_name      
and   a.component_name   = b.component_name      
and   a.task_name        = b.task_name      
and   (isnull(a.task_confirm_msg,'a') <> isnull(b.task_confirm_msg,'a')      
or    isnull(a.task_status_msg,'a') <> isnull(b.task_status_msg,'a')  /* PNR2.0_11831 */      
or    isnull(a.task_process_msg,'a') <> isnull(b.task_process_msg,'a'))         
 --Code Modification for PNR2.0_30869 ends      
--code added for the call id : PNR2.0_19951 starts      
and   not exists ( select 'x'         
from de_fw_req_task b(nolock)      
where b.customer_name  = a.customer_name      
and  b.project_name    = a.project_name      
and  b.process_name    = a.process_name      
and  b.component_name  = a.component_name      
and  b.taskname        = a.task_name)      
--code added for the call id : PNR2.0_19951 ends      
      
insert into de_fw_req_task      
(taskname,tasktype,taskdesc,upduser,updtime,      
customer_name,project_name,timestamp,createdby,createddate,      
process_name,component_name, task_confirm_msg, task_status_msg ,task_process_msg, ecrno )-- Column added by Mohideen on Jun 15, 2006   --Code Modified for PNR2.0_30869      
select distinct task_name, case ltrim(rtrim(task_type))      
when 'Init' then 'initialize'      
else task_type      
end,      
task_descr,  @ctxt_user, @getdate, customer_name,      
project_name, 1,   @ctxt_user, @getdate,      
process_name, component_name,  task_confirm_msg, task_status_msg ,task_process_msg, @req_no-- Column added by Mohideen on Jun 15, 2006  --Code Modified for PNR2.0_30869      
from de_action a(nolock)      
where a.customer_name = @customername      
and a.project_name = @projectname      
and  a.process_name  = @processname      
and a.component_name= @fp_id      
and   a.task_type  <> 'DISPOSAL' -- code added for bug id : PNR2.0_30909      
and   not exists ( select 'x'   /* PNR2.0_11346 , PNR2.0_11659 */      
from de_fw_req_task b(nolock)      
where b.customer_name  = a.customer_name      
and  b.project_name    = a.project_name      
and  b.process_name    = a.process_name      
and  b.component_name  = a.component_name      
and  b.taskname        = a.task_name)      
      
-- code added for Bug ID : PNR2.0_30909    Starts           
insert into de_fw_req_task        
(taskname,tasktype,taskdesc,upduser,updtime,        
customer_name,project_name,timestamp,createdby,createddate,        
process_name,component_name, task_confirm_msg, task_status_msg ,task_process_msg, ecrno )-- Column added by Mohideen on Jun 15, 2006   --Code Modified for PNR2.0_30869      
select distinct a.task_name, a.task_type,        
a.task_descr,  @ctxt_user, @getdate, a.customer_name,        
a.project_name, 1,   @ctxt_user, @getdate,        
a.process_name,a.component_name, a.task_confirm_msg, a.task_status_msg ,a.task_process_msg, a.ecrno -- Column added by Mohideen on Jun 15, 2006   --Code Modified for PNR2.0_30869      
from de_action a(nolock),        
de_task_service_map c (nolock)        
where a.customer_name = @customername        
and a.project_name = @projectname        
and  a.process_name  = @processname        
and a.component_name= @fp_id        
and   a.task_type  = 'DISPOSAL'        
and  a.customer_name  = c.customer_name        
and  a.project_name    = c.project_name        
and  a.process_name    = c.process_name        
and  a.component_name  = c.component_name        
and  a.activity_name  = c.activity_name         
and  a.ui_name = c.ui_name        
and  a.task_name = c.task_name        
-- code added for Bug ID : PNR2.0_30909    Ends       
and   not exists ( select 'x'   /* PNR2.0_11346 , PNR2.0_11659 */        
from de_fw_req_task b(nolock)        
where b.customer_name  = a.customer_name        
and  b.project_name    = a.project_name        
and  b.process_name    = a.process_name        
and  b.component_name  = a.component_name        
and  b.taskname        = a.task_name)        
      
-- added by feroz to update task_type report      
update  d      
set  d.tasktype  = 'Report'      
from de_ui_control     a (nolock),      
es_comp_ctrl_type_mst  b (nolock),      
de_action     c (nolock),      
de_fw_req_task    d (nolock)      
where a.customer_name  = @customername      
and  a.project_name  = @projectname      
and  a.process_name   = @processname      
and  a.component_name = @fp_id      
      
and  a.customer_name   = b.customer_name      
and    a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name  = b.component_name      
and     a.control_type   = b.ctrl_type_name      
      
and  a.customer_name   = c.customer_name      
and    a.project_name   = c.project_name      
and  a.process_name   = c.process_name      
and  a.component_name  = c.component_name      
and  a.activity_name   = c.activity_name      
and  a.ui_name    = c.ui_name      
and  a.page_bt_synonym  = c.page_bt_synonym      
and  a.control_bt_synonym = c.primary_control_bts      
      
and  c.customer_name   = d.customer_name      
and    c.project_name   = d.project_name      
and  c.process_name   = d.process_name      
and  c.component_name  = d.component_name      
and  c.task_name    = d.taskname      
and    b.base_ctrl_type  = 'Button'      
and     b.report_req    = 'Y'      
      
/*PNR2.0_11068*/      
Update a      
SET   a.task_confirm_msg = c.quick_code_value      
From  de_action_lng_extn   a (nolock),      
es_comp_task_type_mst   b (nolock),      
ep_quick_code_mst  c (nolock)      
where a.customer_name  = @customername      
and  a.project_name  = @projectname      
and  a.process_name   = @processname      
and  a.component_name = @fp_id      
      
and  a.customer_name   = b.customer_name      
and    a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name  = b.component_name      
and     a.task_pattern  = b.task_type_name      
      
and     b.task_confirmation    = 'Y'      
and     isnull(a.task_confirm_msg,'')   = ''    
and     c.quick_code_type     = 'task_confirm_msg'      
/*PNR2.0_11068*/      
      
      
/* PNR2.0_10813 */      
/* PNR2.0_11831 */      
insert into de_fw_req_task_local_info  --chan      
(taskname,langid,description,helpindex,upduser,updtime,customer_name,project_name,      
timestamp,createdby,createddate,process_name,component_name, task_confirm_msg, task_status_msg,task_process_msg, ecrno) --Code Modified for PNR2.0_30869      
select distinct a.task_name,a.languageid,a.task_descr,0, @ctxt_user,@getdate,a.customer_name,a.project_name,      
1,@ctxt_user,@getdate,a.process_name,a.component_name,       
(select top 1 task_confirm_msg      
from  de_action_lng_extn c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name     = @processname      
and   c.component_name   =  @fp_id      
and   isnull(c.task_confirm_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name   = b.project_name      
and   c.process_name     = b.process_name      
and   c.component_name   = b.component_name      
and   c.languageid       = b.languageid      
and   c.task_name        = b.task_name ),      
(select top 1 task_status_msg      
from  de_action_lng_extn c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name = @processname      
and   c.component_name   =  @fp_id      
and   isnull(c.task_status_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name     = b.project_name      
and   c.process_name     = b.process_name      
and   c.component_name   = b.component_name      
and   c.languageid       = b.languageid      
and   c.task_name        = b.task_name ),      
--Code Modification for PNR2.0_30869 starts       
(select top 1 task_process_msg      
from  de_action_lng_extn c (nolock)      
where c.customer_name    = @customername      
and   c.project_name     = @projectname      
and   c.process_name = @processname      
and   c.component_name   =  @fp_id      
and isnull(c.task_process_msg,'')<> ''      
and   c.customer_name    = b.customer_name      
and   c.project_name     = b.project_name      
and   c.process_name     = b.process_name      
and   c.component_name   = b.component_name      
and   c.languageid       = b.languageid      
and   c.task_name        = b.task_name ),@req_no      
from  de_action_lng_extn a (nolock),      
de_action_lng_extn b (nolock),      
de_fw_req_task d (nolock)   -- code added for Bug ID : PNR2.0_30909      
where a.customer_name    = @customername      
and   a.project_name     = @projectname      
and   a.process_name     = @processname      
and  a.component_name   =  @fp_id      
and   a.customer_name    = b.customer_name      
and   a.project_name     = b.project_name      
and   a.process_name     = b.process_name      
and   a.component_name   = b.component_name      
and   a.task_name        = b.task_name      
and   a.languageid       = b.languageid      
and  (isnull(a.task_confirm_msg,'a') <> isnull(b.task_confirm_msg,'a') /* PNR2.0_11346 */      
or   isnull(a.task_status_msg,'a') <> isnull(b.task_status_msg,'a')  /* PNR2.0_11831 */      
or   isnull(a.task_process_msg,'a') <> isnull(b.task_process_msg,'a') )       
--Code Modification for PNR2.0_30869 ends       
-- code added for Bug ID : PNR2.0_30909      
and   a.customer_name    = d.customer_name        
and   a.project_name     = d.project_name        
and   a.process_name     = d.process_name        
and   a.component_name   = d.component_name        
and   a.task_name        = d.taskname         
      
/* PNR2.0_10813 */      
--code added for the call id : PNR2.0_19951 starts      
and     not exists ( select 'x'      
from de_fw_req_task_local_info b(nolock)       
where a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.languageid      = b.langid      
and   a.task_name    = b.taskname )      
--code added for the call id : PNR2.0_19951 ends      
  
-- for inserting the new tasks in fw_req_task_local_info      
insert into de_fw_req_task_local_info      
(taskname,langid,description,helpindex,      
upduser,updtime,customer_name,project_name,      
timestamp,createdby,createddate,process_name,component_name, task_confirm_msg, task_status_msg,task_process_msg,ecrno) -- Column added by Mohideen on Jun 15, 2006  --Code Modified for PNR2.0_30869      
-- code modified by Ganesh for the callid :: PNR2.0_3386 on 01/08/05      
select distinct task_name,languageid,task_descr,0,      
@ctxt_user,@getdate,a.customer_name,a.project_name,      
1,@ctxt_user,@getdate,a.process_name,a.component_name, a.task_confirm_msg, a.task_status_msg ,a.task_process_msg, @req_no-- Column added by Mohideen on Jun 15, 2006 --Code Modified for PNR2.0_30869      
from de_action_lng_extn a (nolock),      
de_fw_req_task c(nolock)   -- added for Bug Id : PNR2.0_30909      
where a.customer_name = @customername      
and  a.project_name = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @fp_id      
and   a.customer_name   = c.customer_name        
and   a.project_name    = c.project_name        
and   a.process_name    = c.process_name        
and   a.component_name  = c.component_name        
and   a.task_name    = c.taskname      
and     not exists ( select 'x'      
from de_fw_req_task_local_info b(nolock) /* PNR2.0_10813 */      
where a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name    = b.process_name      
and   a.component_name  = b.component_name      
and   a.languageid      = b.langid      
and   a.task_name    = b.taskname )      
      
-- for inserting into fw_req_activity_task      
insert into de_fw_req_activity_task      
( activityid,  taskname,  invocationtype,      
tasksequence, upduser,  updtime,      
customer_name, project_name, process_name,      
component_name, activity_name, timestamp,      
createdby,  createddate,ecrno)      
select      
distinct  b.activityid, a.task_name, 1,      
1,    @ctxt_user,  @getdate,      
a.customer_name,a.project_name, a.process_name,      
a.component_name,a.activity_name,1,      
@ctxt_user,  @getdate,@req_no      
from de_action  a(nolock) ,      
de_fw_req_activity b (nolock),      
de_fw_req_task d(nolock)  -- added for Bug Id : PNR2.0_30909      
where a.customer_name  =   @customername      
and  a.project_name  =   @projectname      
and  a.process_name   =  @processname      
and  a.component_name =   @fp_id      
and  a.customer_name  = b.customer_name      
and  a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
--Modification for the call id : PNR2.0_19835 starts      
--and  a.component_name = b.componentname      
and  a.component_name = b.component_name       
--Modification for the call id : PNR2.0_19835 ends      
and  a.activity_name  = b.activityname      
--chan      
-- code added for bug id : PNR2.0_30909      
and  a.customer_name   = d.customer_name        
and   a.project_name    = d.project_name        
and   a.process_name    = d.process_name      
and   a.component_name  = d.component_name        
and   a.task_name    = d.taskname       
and     a.task_name  not in (select c.taskname      
from de_fw_req_activity_task c (nolock)      
where c.customer_name  = b.customer_name      
and  c.project_name  = b.project_name      
and  c.process_name  = b.process_name      
--Modification for the call id : PNR2.0_19835 starts      
--and  c.component_name = b.componentname      
and  c.component_name = b.component_name       
--Modification for the call id : PNR2.0_19835 ends      
and     c.activity_name  = b.activityname      
and     c.activityid  = b.activityid )      
      
update de_fw_req_activity_task      
set  tasksequence   = b.task_seq      
from de_fw_req_activity_task a(nolock),      
de_action    b(nolock)      
where a.customer_name  =   @customername      
and  a.project_name  =   @projectname      
and  a.process_name   =  @processname      
and  a.component_name =   @fp_id      
and  a.customer_name  = b.customer_name      
and  a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and  a.activity_name  = b.activity_name      
and  a.taskname   = b.task_name      
      
-- for inserting into fw_req_activity_ilbo      
insert into de_fw_req_activity_ilbo      
(activityid,ilbocode,upduser,updtime,      
customer_name,project_name,process_name,component_name ,      
activity_name,timestamp,createdby,createddate,ecrno)      
select b.activityid,a.ui_name,@ctxt_user,@getdate,      
a.customer_name,a.project_name, a.process_name,a.component_name ,      
a.activity_name,1,@ctxt_user,@getdate,@req_no      
from de_ui    a(nolock),      
de_fw_req_activity b(nolock)      
where a.customer_name  =  @customername      
and  a.project_name  =  @projectname      
and  a.process_name   =  @processname      
and  a.component_name =  @fp_id      
and  a.customer_name  =  b.customer_name      
and  a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and     a.activity_name  = b.activityname      
--chan      
and     a.ui_name  not in (select c.ilbocode      
from    de_fw_req_activity_ilbo c (nolock)      
where c.customer_name  = b.customer_name      
and  c.project_name  = b.project_name      
and  c.process_name  = b.process_name      
--Modification for the call id : PNR2.0_19835 starts      
--and  c.component_name = b.componentname      
and  c.component_name = b.component_name       
--Modification for the call id : PNR2.0_19835 ends      
and     c.activity_name  = b.activityname      
and     c.activityid  = b.activityid )      
      
/* code modified by Ganesh on 27-01-05 for the bug id : DEENG203SYS_000499      
bug desc  : to add new column Taskconfirmation in de_fw_req_activity_ilbo_task and in de_fw_req_publish_activity_ilbo_task tables  */      
      
-- for inserting into fw_req_activity_ilbo_task      
insert into de_fw_req_activity_ilbo_task      
(activityid,  ilbocode,   taskname,   upduser,      
updtime,   datasavingtask,  linktype,   customer_name,      
project_name,  process_name,  component_name,  activity_name,      
timestamp,   createdby,  createddate,  Taskconfirmation,ecrno, Autoupload)-- Offline Task for TECH-16126       
select  distinct      
b.activityid,  a.ui_name,   a.task_name,  @ctxt_user,      
-- code modified by Ganesh for the callid PNR2.0_4912 on 08-12-05      
@getdate,   case  data_save_req      
when  'Y' then 1      
else  0      
end,    0,     a.customer_name,      
a.project_name,  a.process_name,  a.component_name, a.activity_name,      
1,     @ctxt_user,  @getdate,      
case c.task_confirmation      
when 'Y' then 1      
else  0      
end,@req_no, Autoupload       
from de_action     a (nolock),      
de_fw_req_activity_ilbo b (nolock),      
es_comp_task_type_mst c (nolock),      
de_fw_req_task d (nolock)  -- added for Bug Id : PNR2.0_30909      
where a.customer_name  =  @customername      
and  a.project_name  = @projectname      
and  a.process_name   = @processname      
and  a.component_name =  @fp_id      
and  a.customer_name  =  b.customer_name      
and  a.project_name  =  b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and  a.activity_name  = b.activity_name      
and  a.ui_name   = b.ilbocode      
and  a.customer_name  =  c.customer_name      
and  a.project_name  =  c.project_name      
and  a.process_name  = c.process_name      
and  a.component_name = c.component_name      
and  a.task_pattern  =  c.task_type_name      
--chan      
-- added for Bug Id : PNR2.0_30909      
and   a.customer_name   = d.customer_name        
and   a.project_name    = d.project_name        
and   a.process_name    = d.process_name        
and   a.component_name  = d.component_name        
and   a.task_name    = d.taskname      
and     a.task_name  not in (select c.taskname      
from  de_fw_req_activity_ilbo_task c (nolock)      
where c.customer_name  = b.customer_name      
and  c.project_name  = b.project_name      
and  c.process_name  = b.process_name      
and  c.component_name = b.component_name      
and     c.activity_name  = b.activity_name      
and     c.activityid  = b.activityid      
and     c.ilbocode      =   b.ilbocode)      
      
-- commented by Ganesh      
--from de_fw_req_migrate_businessrules      
      
--  insert into de_fw_req_businessrule      
--   ( brname, brtype, brdesc, upduser, updtime,      
--     customer_name,project_name,timestamp,createdby,createddate,      
--    process_name, component_name)      
--  select  a.br_name, 'rule', br_descr, @ctxt_user,  @getdate,      
--    a.customer_name, a.project_name,1,@ctxt_user, @getdate,      
--    a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_business_rule b (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.br_component_name = b.component_name      
--  and  a.br_name   = b.br_name      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   <> 'G'      
--  union      
--  select  c.br_name, 'rule', brgroup_descr, @ctxt_user, @getdate,      
--    a.customer_name, a.project_name,1,@ctxt_user, @getdate,      
--    a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_rulegroup  b (nolock),      
--    de_rulegroup_step c (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.br_component_name = b.component_name      
--  and  a.br_name   = b.brgroup_name      
--  and  b.customer_name  = c.customer_name      
--  and  b.project_name  = c.project_name      
--  and  b.component_name = c.component_name      
--  and  b.brgroup_name  = c.brgroup_name      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   = 'G'      
--      
--  insert into de_fw_req_br_documentation      
--   ( brname, serialno, doctext, upduser, updtime,      
--    customer_name,project_name,timestamp,createdby,createddate,      
--    process_name,component_name )      
--  select  a.br_name, 1, isnull(b.br_doc,''), @ctxt_user, @getdate,      
--    a.customer_name,a.project_name,1,@ctxt_user, @getdate,      
--    a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_business_rule b (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.br_component_name = b.component_name      
--  and  a.br_name   = b.br_name      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   <> 'G'      
--  union      
--  select c.br_name, 1, isnull(b.brgroup_doc,''), @ctxt_user, @getdate,      
--    a.customer_name,a.project_name,1,@ctxt_user, @getdate,      
--    a.process_name , a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_rulegroup  b (nolock),      
--    de_rulegroup_step c (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.br_component_name = b.component_name      
--  and  a.br_name   = b.brgroup_name      
--  and  b.customer_name  = c.customer_name      
--  and  b.project_name  = c.project_name      
--  and  b.component_name = c.component_name      
--  and  b.brgroup_name  = c.brgroup_name      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   = 'G'      
--      
--  insert into de_fw_req_error(      
--    errorcode,   severity,   upduser,   updtime,      
--    customer_name,  project_name,  timestamp,   createdby,      
--    createddate, process_name,  component_name)      
--  select  distinct      
--    b.message_id, case error_serverity      
--          when  'fatal' then 1      
--          when  'critical' then 2      
--          when  'warning' then 3      
--          when  'informational' then 4      
--          when  'information' then 4      
--          else 4      
--          end, @ctxt_user, @getdate,      
--    a.customer_name, a.project_name, 1,   @ctxt_user,      
--    @getdate,   a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_flowbr_br_error b (nolock),      
--    de_message   c (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.process_name  = b.process_name      
--  and  a.component_name = b.component_name      
--  and  a.activity_name  = b.activity_name      
--  and  a.ui_name   = b.ui_name      
--  and  a.page_bt_synonym = b.page_bt_synonym      
--  and  a.task_name   = b.task_name      
--  and  a.flowbr_name  = b.flowbr_name      
--  and  a.br_id    = b.br_id      
--  and  a.customer_name  = c.customer_name      
--  and  a.project_name  = c.project_name      
--  and  a.br_component_name = c.component_name      
--  and  b.customer_name  = c.customer_name      
--  and  b.project_name  = c.project_name      
--  and  b.message_id  = c.error_id      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--      
--  insert into de_fw_req_error_local_info      
--    (errorcode, langid, errordesc, upduser, updtime,      
--    customer_name,project_name,timestamp,createdby,createddate,      
--    process_name, component_name )      
--  select  distinct      
--    b.message_id, 1 ,c.error_descr, @ctxt_user, @getdate,      
--    c.customer_name, c.project_name, 1, @ctxt_user, @getdate,      
--    c.process_name, c.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_flowbr_br_error b (nolock),      
--    de_message   c (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.process_name  = b.process_name      
--  and  a.component_name = b.component_name      
--  and  a.activity_name  = b.activity_name      
--  and  a.ui_name   = b.ui_name      
--  and  a.page_bt_synonym = b.page_bt_synonym      
--  and  a.task_name   = b.task_name      
--  and  a.flowbr_name  = b.flowbr_name      
--  and  a.br_id    = b.br_id      
--  and  a.customer_name  = c.customer_name      
--  and  a.project_name  = c.project_name      
--  and  a.br_component_name = c.component_name      
--  and  b.customer_name  = c.customer_name      
--  and  b.project_name  = c.project_name      
--  and  b.message_id  = c.error_id      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--      
--  insert into de_fw_req_br_error      
--    (brname,  errorcode,  upduser,  updtime,      
--    customer_name, project_name, timestamp,  createdby,      
--    createddate, process_name, component_name )      
--  select  a.br_name,  b.message_id, @ctxt_user, @getdate,      
--    a.customer_name,a.project_name, 1,    @ctxt_user,      
--    @getdate,  a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_flowbr_br_error b (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.process_name  = b.process_name      
--  and  a.component_name = b.component_name      
--  and  a.activity_name  = b.activity_name      
--  and  a.ui_name   = b.ui_name      
--  and  a.page_bt_synonym = b.page_bt_synonym      
--  and  a.task_name   = b.task_name      
--  and  a.flowbr_name  = b.flowbr_name      
--  and  a.br_id    = b.br_id      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   <> 'G'      
--  union      
--  select  b.br_name, a.message_id, @ctxt_user, @getdate,      
--    a.customer_name,a.project_name,1,@ctxt_user, @getdate,      
--    d.process_name, d.component_name      
--  from de_rulegroup_step_msg  a (nolock),      
--    de_rulegroup_step   b (nolock),      
--    de_fw_req_error      c (nolock),      
--    de_flowbr_rule_map  d (nolock)      
--  where a.customer_name  = b.customer_name      
--  and     a.project_name  = b.project_name      
--  and  a.component_name = b.component_name      
--  and  a.brgroup_name  = b.brgroup_name      
--  and  a.step_id   = b.step_id      
--  and  a.customer_name  = c.customer_name      
--  and     a.project_name  = c.project_name      
--  and  a.message_id  = c.errorcode      
--  and  d.customer_name  = b.customer_name      
--  and  d.project_name  = b.project_name      
--  and  d.br_component_name = b.component_name      
--  and  d.br_name   = b.brgroup_name      
--  and  d.customer_name  = @customername      
--  and  d.project_name  = @projectname      
--  and  d.process_name   = @processname      
--  and  d.component_name = @componentname      
--  and  d.br_type   = 'G'      
--      
--  --inserting the values in the table de_fw_req_task_rule      
--  insert into de_fw_req_task_rule      
--    (taskname,   brsequence,  brname,   invocationtype,      
--    upduser,   updtime,  customer_name, project_name,      
--    timestamp,   createdby,  createddate, modifiedby,      
--    modifieddate,  process_name, component_name)      
--  select a.task_name,  a.seq_no,  a.br_name,  '1',      
--    @ctxt_user,   @getdate,  a.customer_name,a.project_name,      
--    a.timestamp,  @ctxt_user,  @getdate,  @ctxt_user,      
--    @getdate,   a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock)      
--  where a.customer_name = @customername      
--  and  a.project_name = @projectname      
--  and  a.component_name= @componentname      
--  and  a.br_type   <> 'G'      
--  union      
--  select a.task_name,  a.seq_no,  c.br_name,   '1',      
--    @ctxt_user,   @getdate,  a.customer_name, a.project_name,      
--    a.timestamp,  @ctxt_user,  @getdate,   @ctxt_user,      
--    @getdate,    a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_rulegroup  b (nolock),      
--    de_rulegroup_step c (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.br_component_name = b.component_name      
--  and  a.br_name   = b.brgroup_name      
--  and  b.customer_name  = c.customer_name      
--  and  b.project_name  = c.project_name     
--  and  b.component_name = c.component_name      
--  and  b.brgroup_name  = c.brgroup_name      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name   = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   = 'G'      
--      
--      
--  insert into de_fw_req_task_br_error_context      
--   (taskname, brsequence, brname,  errorcode,      
--   severity, upduser, updtime, customer_name,project_name,      
--   timestamp, createdby, createddate,process_name, component_name)      
--  select  a.task_name, a.seq_no,   a.br_name,  b.message_id,      
--    Case msg_severity      
--    When  'Fatal'   then 1      
--    When  'Critical'   then 2      
--    When  'Warning'   then 3      
--    When  'Informational' then 4      
-- When  'Information'  then 4      
--    else 4      
--    End, @ctxt_user, @getdate,a.customer_name,a.project_name,      
--    1,a.createdby,a.createddate, a.process_name, a.component_name      
--  from de_flowbr_rule_map  a (nolock),      
--    de_flowbr_br_error b (nolock)      
--  where a.customer_name  = b.customer_name      
--  and  a.project_name  = b.project_name      
--  and  a.process_name  = b.process_name      
--  and  a.component_name = b.component_name      
--  and  a.activity_name  = b.activity_name      
--  and  a.ui_name   = b.ui_name      
--  and  a.page_bt_synonym = b.page_bt_synonym      
--  and  a.task_name   = b.task_name      
--  and  a.flowbr_name  = b.flowbr_name      
--  and  a.br_id    = b.br_id      
--  and  a.customer_name  = @customername      
--  and  a.project_name  = @projectname      
--  and  a.process_name  = @processname      
--  and  a.component_name = @componentname      
--  and  a.br_type   <> 'G'      
--  union      
--  select  d.task_name, d.seq_no,   b.br_name,  a.message_id,      
--    Case msg_severity      
--    When  'Fatal'   then 1      
--    When  'Critical'   then 2      
--    When  'Warning'   then 3      
--    When  'Informational' then 4      
--    When  'Information'  then 4      
--    else 4      
--    End, @ctxt_user, @getdate,a.customer_name,a.project_name,      
--    1,a.createdby,a.createddate, d.process_name, d.component_name      
--  from de_rulegroup_step_msg  a (nolock),      
--    de_rulegroup_step   b (nolock),      
--    de_fw_req_error      c (nolock),      
--    de_flowbr_rule_map  d (nolock)      
--  where a.customer_name  = b.customer_name      
--  and     a.project_name  = b.project_name      
--  and  a.component_name = b.component_name      
--  and  a.brgroup_name  = b.brgroup_name      
--  and  a.step_id   = b.step_id      
--  and  a.customer_name  = c.customer_name      
--  and     a.project_name  = c.project_name      
--  and  a.message_id  = c.errorcode      
--  and  d.customer_name  = b.customer_name      
--  and  d.project_name  = b.project_name      
--  and  d.br_component_name = b.component_name      
--  and  d.br_name   = b.brgroup_name      
--  and  d.customer_name  = @customername      
--  and  d.project_name  = @projectname      
--  and  d.process_name  = @processname      
--  and  d.component_name = @componentname      
--  and  d.br_type   = 'G'      
    
    
        
insert into de_fw_req_ilbo_control      
(ilbocode,controlid,type,upduser,updtime,tabname,      
customer_name,project_name,process_name,component_name,page_bt_synonym,control_bt_synonym,      
timestamp,createdby,createddate,ecrno)      
select  distinct      
A.ui_name,A.control_id, CASE B.base_ctrl_type      
WHEN   'CheckBox'   THEN  'RSCheck'      
WHEN 'Combo'   THEN 'RSComboCtrl'      
WHEN 'Edit'   THEN 'RSEditCtrl'     
--WHEN 'Label'   THEN 'RSEditCtrl'      
WHEN 'Grid'   THEN 'RSGrid'      
WHEN 'ListView'   THEN 'RSListView' -- ListView added for TECH-28436      
WHEN 'Line'   THEN 'RSLine' -- Line  added for TECH-36371      
WHEN 'StackedLinks'   THEN 'RSStackedLinks' --added for stackedlinks grid      
WHEN 'Slider'   THEN 'RSSlider' --added for stackedlinks grid      
WHEN 'Pivot'   THEN 'RSPivotGrid'       
WHEN 'Assorted'   THEN 'RSAssorted'       
WHEN 'TreeGrid'   THEN 'RSTreeGrid'       
when 'radiobutton' then 'RSGroup'      
When 'DataHyperlink' Then 'RSEditCtrl'      
ELSE B.base_ctrl_type      
END ,@CTXT_USER,@getdate,case A.page_bt_synonym      
when '[mainscreen]' then NULL      
else A.page_bt_synonym      
end,      
A.customer_name,A.project_name,A.process_name,A.component_name,A.page_bt_synonym,A.control_bt_synonym,      
1,@CTXT_USER,@getdate,@req_no      
from de_ui_control  A(nolock), es_comp_ctrl_type_mst B(nolock)      
where  A.customer_name  = @customername      
and    A.project_name   = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @componentname      
and    a.customer_name  = b.customer_name      
and    a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name     
and     A.control_type  = B.ctrl_type_name      
and    b.base_ctrl_type not in ('link','button','line', 'Label')      
and     A.control_type  not in ('Label')      
and    a.control_type  not in ('filler' , 'filler2')      
--and  isnull(B.IsPivot,'') <> 'Y'--for pivot control PLF2.0_17326        
--and  isnull(B.IsAssorted,'N') <> 'Y'---for assorted control PLF2.0_18487      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and  not exists (select 'x' from de_ui_combolink cml(nolock)      
where  cml.customer_name   = a.customer_name      
and  cml.project_name   = a.project_name      
and  cml.process_name  = a.process_name      
and  cml.component_name  = a.component_name      
and  cml.activity_name   = a.activity_name      
and  cml.ui_name    = a.ui_name      
and  cml.combo_control_bt_synonym =a.control_bt_synonym        
)      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and     not exists ( select 'x'      
from de_fw_req_ilbo_control c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = A.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id )      
union      
-- Added By feroz for static controls      
select  distinct      
A.ui_name,A.control_id, CASE B.base_ctrl_type      
WHEN 'Combo'   THEN 'RSComboCtrl'      
ELSE B.base_ctrl_type      
END ,@CTXT_USER,@getdate,case A.page_bt_synonym      
when '[mainscreen]' then NULL      
else A.page_bt_synonym      
end,      
A.customer_name,A.project_name,A.process_name,A.component_name,A.page_bt_synonym,A.control_bt_synonym,      
1,@CTXT_USER,@getdate,@req_no      
from de_ui_control  A(nolock), es_comp_stat_ctrl_type_mst B(nolock)      
where  A.customer_name  = @customername      
and    A.project_name   = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @componentname      
and    a.customer_name  = b.customer_name      
and    a.project_name  = b.project_name      
and  a.process_name  = b.process_name      
and  a.component_name = b.component_name      
and     A.control_type  = B.ctrl_type_name      
      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and  not exists (select 'x' from de_ui_combolink cml(nolock)      
where  cml.customer_name   = a.customer_name      
and  cml.project_name   = a.project_name      
and  cml.process_name  = a.process_name      
and  cml.component_name  = a.component_name      
and  cml.activity_name   = a.activity_name      
and  cml.ui_name    = a.ui_name      
and  cml.combo_control_bt_synonym =a.control_bt_synonym        
)      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and     not exists ( select 'x'      
from de_fw_req_ilbo_control c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = A.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id )      
---For Pivot Control PLF2.0_17326        
--Union      
--select  distinct      
--A.ui_name,A.control_id, CASE B.base_ctrl_type      
----WHEN 'Grid'   THEN 'RSPivotGrid'      
--WHEN 'Pivot'   THEN 'RSPivotGrid'      
--ELSE B.base_ctrl_type      
--END ,@CTXT_USER,@getdate,case A.page_bt_synonym      
--when '[mainscreen]' then NULL      
--else A.page_bt_synonym      
--end,      
--A.customer_name,A.project_name,A.process_name,A.component_name,A.page_bt_synonym,A.control_bt_synonym,      
--1,@CTXT_USER,@getdate,@req_no      
--from de_ui_control  A(nolock), es_comp_ctrl_type_mst B(nolock)      
--where A.customer_name  = @customername      
--and  A.project_name  = @projectname      
--and  a.process_name  = @processname      
--and  a.component_name = @componentname      
--and  a.customer_name  = b.customer_name      
--and  a.project_name  = b.project_name      
--and  a.process_name  = b.process_name      
--and  a.component_name = b.component_name      
--and     A.control_type  = B.ctrl_type_name      
----and  isnull(B.IsPivot,'')= 'Y'      
--and  b.base_ctrl_type = 'Pivot'      
--and     not exists ( select 'x'      
--from de_fw_req_ilbo_control c (nolock)      
--where c.customer_name  = a.customer_name      
--and  c.project_name  = A.project_name      
--and  c.process_name  = a.process_name      
--and  c.component_name = a.component_name      
--and  c.ilbocode   = a.ui_name      
--and  c.controlid   = a.control_id )      
      
---For assorted control PLF2.0_18487       
--Union      
--select  distinct      
--A.ui_name,A.control_id, CASE B.base_ctrl_type      
--WHEN 'Assorted'   THEN 'RSAssorted'      
--ELSE B.base_ctrl_type      
--END ,@CTXT_USER,@getdate,case A.page_bt_synonym      
--when '[mainscreen]' then NULL      
--else A.page_bt_synonym      
--end,      
--A.customer_name,A.project_name,A.process_name,A.component_name,A.page_bt_synonym,A.control_bt_synonym,      
--1,@CTXT_USER,@getdate,@req_no      
--from de_ui_control  A(nolock), es_comp_ctrl_type_mst B(nolock)      
--where A.customer_name  = @customername      
--and  A.project_name  = @projectname      
--and  a.process_name  = @processname      
--and  a.component_name = @componentname      
--and  a.customer_name  = b.customer_name      
--and  a.project_name  = b.project_name      
--and  a.process_name  = b.process_name      
--and  a.component_name = b.component_name      
--and     A.control_type  = B.ctrl_type_name      
----and  isnull(B.IsAssorted,'N')= 'Y'      
--and  b.base_ctrl_type = 'Assorted'      
--and     not exists ( select 'x'      
--from de_fw_req_ilbo_control c (nolock)      
--where c.customer_name  = a.customer_name      
--and  c.project_name  = A.project_name      
--and  c.process_name  = a.process_name      
--and  c.component_name = a.component_name      
--and  c.ilbocode   = a.ui_name      
--and  c.controlid   = a.control_id )      
      
-- to insert the record for the control for which the caption is req      
-- in ilbo_control having type as 'Label' (12/8/04)      
insert into de_fw_req_ilbo_control      
(ilbocode,    controlid,    type,    upduser,      
updtime,    tabname,    customer_name,  project_name,      
process_name,   component_name,   page_bt_synonym, control_bt_synonym,      
timestamp,    createdby,    createddate,ecrno)      
select  distinct      
dtl.ui_name,   'lbl'+dtl.control_id,  'Label',   @CTXT_USER,      
@getdate,    case  dtl.page_bt_synonym      
when  '[mainscreen]' then NULL      
else  dtl.page_bt_synonym      
end,      
dtl.customer_name,  dtl.project_name,      
dtl.process_name,  dtl.component_name,  dtl.page_bt_synonym, dtl.control_bt_synonym,      
1,      @CTXT_USER,    @getdate,@req_no      
from de_ui_control   dtl(nolock),      
es_comp_ctrl_type_mst mst(nolock)      
where dtl.customer_name  = @customername      
and  dtl.project_name  = @projectname      
and  dtl.process_name  = @processname      
and  dtl.component_name  = @componentname      
and  dtl.customer_name  = mst.customer_name      
and  dtl.project_name  = mst.project_name      
and  dtl.process_name  = mst.process_name      
and  dtl.component_name  = mst.component_name      
and  dtl.control_type  = mst.ctrl_type_name      
and  mst.caption_req   = 'y'      
-- code added by Ganesh for the bugid :: PNR2.0_2324 on 17/05/05      
and     dtl.control_type  not in ('Label')   
-- ListView added for TECH-28436      
and  mst.base_ctrl_type  not in ('link','radiobutton','button', 'grid','line', 'Label','RSSlider', 'Pivot', 'Assorted','TreeGrid', 'ListView')      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and  not exists (select 'x' from de_ui_combolink cml(nolock)      
where  cml.customer_name  = dtl.customer_name      
and cml.project_name   = dtl.project_name      
and  cml.process_name  = dtl.process_name      
and  cml.component_name  = dtl.component_name      
and  cml.activity_name   = dtl.activity_name      
and  cml.ui_name    = dtl.ui_name      
and  cml.combo_control_bt_synonym =dtl.control_bt_synonym        
)      
-- code added for restricting the combo link control printing in activity dll TECH-21980      
and     not exists ( select 'x'      
from de_fw_req_ilbo_control c (nolock)      
where c.customer_name = dtl.customer_name      
and   c.project_name = dtl.project_name      
and   c.process_name = dtl.process_name      
and   c.component_name = dtl.component_name      
and   c.ilbocode  = dtl.ui_name      
and   c.controlid  = dtl.control_id )      
      
      
if @ctxt_user = 'platform'      
begin    
select  distinct a.ui_name,  a.control_id, a.view_name /*view_name*/,'T',   a.visible_length,      
a.column_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.column_bt_synonym,      
-- code modified by Ganesh for the bugid :: PNR2.0_2372 on 11/05/05      
1,@ctxt_user,@getdate,@req_no      
from de_ui_grid a(nolock),      
es_comp_ctrl_type_mst b(nolock),      
de_fw_req_ilbo_control c(nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name = @processname      
and   a.component_name = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name = b.process_name      
and   a.component_name = b.component_name      
and   a.column_type  = b.ctrl_type_name      
and   a.customer_name   = c.customer_name      
and   a.project_name    = c.project_name      
and   a.component_name  = c.component_name      
and   a.ui_name   = c.ilbocode      
and   a.control_bt_synonym = c.control_bt_synonym      
and   b.base_ctrl_type  not in ('button')      
and   B.ctrl_type_name  not in ('filler' , 'filler2')      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
union      
-- Added By feroz For static controls      
select  distinct  a.ui_name,  a.control_id, a.view_name /*view_name*/,'T',   a.visible_length,      
a.column_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.column_bt_synonym,      
1,@ctxt_user,@getdate,@req_no      
from de_ui_grid a(nolock),      
es_comp_stat_ctrl_type_mst b(nolock),      
de_fw_req_ilbo_control c(nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name = @processname      
and   a.component_name = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name = b.process_name      
and   a.component_name = b.component_name      
and   a.column_type  = b.ctrl_type_name      
and   a.customer_name   = c.customer_name      
and   a.project_name    = c.project_name      
and   a.component_name  = c.component_name      
and   a.ui_name  = c.ilbocode      
and   a.control_bt_synonym = c.control_bt_synonym      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
return    
end    
      
      
---- for inserting into fw_req_ilbo_view      
insert into de_fw_req_ilbo_view      
(ilbocode,  controlid,  viewname, displayflag, displaylength,      
btsynonym,  upduser,  updtime, customer_name, project_name,      
process_name, component_name, page_bt_synonym,control_bt_synonym,      
timestamp,  createdby,  createddate,ecrno,  
ctrl_type_name, store_path, systemgeneratedfileid)    --TECH-66740  
select  distinct a.ui_name,  a.control_id, a.view_name /*view_name*/,'T',   a.visible_length,      
a.column_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.column_bt_synonym,      
-- code modified by Ganesh for the bugid :: PNR2.0_2372 on 11/05/05      
1,@ctxt_user,@getdate,@req_no,  
--TECH-66740    
a.column_type,     
CASE WHEN (isnull(b.relative_document_path,'')) <> ''   
 THEN  LOWER(LTRIM(RTRIM(b.relative_document_path)))   
 ELSE LOWER(LTRIM(RTRIM(isnull(b.relative_image_path,''))))   
END,   
--isnull(b.SystemGeneratedFileId,'n')  
CASE WHEN ISNULL(b.relative_document_path,'') <> '' AND isnull(b.systemgeneratedfileid,'') = '' THEN 'n'  
          WHEN ISNULL(b.relative_image_path,'')    <> '' AND isnull(b.systemgeneratedfileid,'') = '' THEN 'n'  
         ELSE isnull(b.systemgeneratedfileid,'') END       --TECH-66740        
from de_ui_grid a(nolock),      
es_comp_ctrl_type_mst b(nolock),      
de_fw_req_ilbo_control c(nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name = @processname      
and   a.component_name = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name = b.process_name      
and   a.component_name = b.component_name      
and   a.column_type  = b.ctrl_type_name      
and   a.customer_name   = c.customer_name      
and   a.project_name    = c.project_name      
and   a.component_name  = c.component_name      
and   a.ui_name   = c.ilbocode      
and   a.control_bt_synonym = c.control_bt_synonym      
and   b.base_ctrl_type  not in ('button')      
and   B.ctrl_type_name  not in ('filler' , 'filler2')      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
union      
-- Added By feroz For static controls      
select  distinct  a.ui_name,  a.control_id, a.view_name /*view_name*/,'T',   a.visible_length,      
a.column_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.column_bt_synonym,      
1,@ctxt_user,@getdate,@req_no,   
a.column_type, '', '' --TECH-66740      
from de_ui_grid a(nolock),      
es_comp_stat_ctrl_type_mst b(nolock),      
de_fw_req_ilbo_control c(nolock)      
where a.customer_name   = @customername      
and   a.project_name    = @projectname      
and   a.process_name = @processname      
and   a.component_name = @componentname      
and   a.customer_name   = b.customer_name      
and   a.project_name    = b.project_name      
and   a.process_name = b.process_name      
and   a.component_name = b.component_name      
and   a.column_type  = b.ctrl_type_name      
and   a.customer_name   = c.customer_name      
and   a.project_name    = c.project_name      
and   a.component_name  = c.component_name      
and   a.ui_name  = c.ilbocode      
and   a.control_bt_synonym = c.control_bt_synonym      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
      
-- for inserting into fw_req_ilbo_view      
    
insert into de_fw_req_ilbo_view      
(ilbocode,  controlid,  viewname, displayflag, displaylength,      
btsynonym,  upduser,  updtime, customer_name, project_name,      
process_name, component_name, page_bt_synonym,control_bt_synonym,      
timestamp,  createdby, createddate,ecrno,   
ctrl_type_name, store_path , systemgeneratedfileid)     --TECH-66740      
select  distinct      
a.ui_name,  a.control_id, a.view_name, 'T',  a.visisble_length,      
a.control_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.control_bt_synonym,      
1,@CTXT_USER,@getdate,@req_no,   
--TECH-66740  
a.control_type,  
CASE WHEN (isnull(b.relative_document_path,'')) <> ''   
 THEN  LOWER(LTRIM(RTRIM(b.relative_document_path)))   
 ELSE LOWER(LTRIM(RTRIM(isnull(b.relative_image_path,''))))   
END,   
--ISNULL(b.systemgeneratedfileid,'n')  
CASE WHEN ISNULL(b.relative_document_path,'') <> '' AND isnull(b.systemgeneratedfileid,'') = '' THEN 'n'  
          WHEN ISNULL(b.relative_image_path,'')    <> '' AND isnull(b.systemgeneratedfileid,'') = '' THEN 'n'  
         ELSE isnull(b.systemgeneratedfileid,'') END   
--TECH-66740      
from de_ui_control     a (nolock),      
es_comp_ctrl_type_mst  b (nolock),      
de_fw_req_ilbo_control  c (nolock)      
where a.customer_name  = @customername      
and    a.project_name   = @projectname      
and  a.process_name = @processname      
and  a.component_name = @componentname      
and    a.customer_name  = b.customer_name      
and    a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name = b.component_name      
and  a.control_type  = b.ctrl_type_name      
and    a.customer_name  = c.customer_name      
and    a.project_name   = c.project_name      
and    a.component_name = c.component_name      
and    a.ui_name   = c.ilbocode      
and  a.page_bt_synonym= c.page_bt_synonym      
and    a.control_bt_synonym = c.control_bt_synonym      
and  a.control_id  = c.controlid      
-- ListView added for TECH-28436      
and  b.base_ctrl_type not in  ('Grid','StackedLinks','RSSlider','Assorted', 'Pivot', 'TreeGrid', 'ListView')   --kanagavel      
and     b.base_ctrl_type  not in ('link','button','line')      
and     a.control_type  not in ('filler' , 'filler2')      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
      
union      
-- Added By feroz For static controls      
select  distinct      
a.ui_name,  a.control_id, a.view_name, 'T',  a.visisble_length,      
a.control_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_bt_synonym,a.control_bt_synonym,      
1,@CTXT_USER,@getdate,@req_no,   
a.control_type, '', ''  --TECH-66740       
from de_ui_control     a (nolock),      
es_comp_stat_ctrl_type_mst  b (nolock),      
de_fw_req_ilbo_control  c (nolock)      
where a.customer_name  = @customername      
and    a.project_name   = @projectname      
and  a.process_name   = @processname      
and  a.component_name = @componentname      
and    a.customer_name  = b.customer_name      
and    a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name = b.component_name      
and    a.control_type  = b.ctrl_type_name      
and    a.customer_name  = c.customer_name      
and    a.project_name   = c.project_name      
and    a.component_name = c.component_name      
and    a.ui_name   = c.ilbocode      
and  a.page_bt_synonym= c.page_bt_synonym      
and    a.control_bt_synonym = c.control_bt_synonym      
and  a.control_id  = c.controlid      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
     
      
-- TO ADD HIDDEN VIEWS IN TO FW_REQ_ILBO_VIEW TABLE      
      
insert into de_fw_req_ilbo_view      
(ilbocode,  controlid,  viewname, displayflag, displaylength,      
btsynonym,  upduser,  updtime, customer_name, project_name,      
process_name, component_name, page_bt_synonym,control_bt_synonym,      
timestamp,  createdby,  createddate,ecrno,   
ctrl_type_name, store_path, systemgeneratedfileid)     --TECH-66740  
select  distinct  a.ui_name,  b.control_id, a.view_name ,'F', b.visisble_length,      
a.hidden_view_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_name,a.control_bt_synonym,      
1,@ctxt_user,@getdate,@req_no,   
---TECH-66740  
--b.control_type,  
'hidden view','','' --23Mar2022   
--CASE WHEN (isnull(c.relative_document_path,'')) <> ''   
-- THEN LOWER(LTRIM(RTRIM(c.relative_document_path)))   
-- ELSE LOWER(LTRIM(RTRIM(isnull(c.relative_image_path,''))))   
--END,  
--isnull(systemgeneratedfileid,'')  
---TECH-66740      
from de_hidden_view   a (nolock),      
de_ui_control   b (nolock),      
es_comp_ctrl_type_mst c (nolock)      
where a.customer_name   = @customername      
and  a.project_name   = @projectname      
and  a.process_name    = @processname      
and  a.component_name  = @componentname      
and  a.customer_name = b.customer_name      
and  a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name  = b.component_name     
and  a.activity_name   = b.activity_name      
and  a.ui_name    = b.ui_name      
and  a.page_name   = b.page_bt_synonym      
and  a.control_bt_synonym = b.control_bt_synonym      
and  a.customer_name   = c.customer_name      
and  a.project_name   = c.project_name      
and  a.process_name   = c.process_name      
and  a.component_name  = c.component_name      
and  b.control_type   = c.ctrl_type_name      
and  c.base_ctrl_type  <> 'label'      
-- code modified by saravanan for bugid:PNR2.0_10280      
and     not exists (select 'x'      
from    de_hidden_view d (nolock)      
where   a.customer_name   = d.customer_name      
and  a.project_name   = d.project_name      
and  a.process_name    = d.process_name      
and  a.component_name  = d.component_name      
and     a.activity_name   = d.activity_name      
and  a.ui_name    = d.ui_name      
and  a.page_name    = d.page_name      
and     a.control_id   = d.control_id      
and     isnull(d.HIDDEN_VIEW_SOURCE, '') <> ''      
and     a.hidden_view_bt_synonym = d.HIDDEN_VIEW_SOURCE   )      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
union      
select  distinct  a.ui_name,  a.control_id, a.view_name ,'F', b.visible_length,      
a.hidden_view_bt_synonym, @CTXT_USER,@getdate,a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_name,a.control_bt_synonym,      
1,@ctxt_user,@getdate,@req_no,   
column_type, '', ''  --TECH-66740      
from de_hidden_view   a (nolock),      
de_ui_grid    b (nolock)      
where a.customer_name   = @customername      
and  a.project_name   = @projectname      
and  a.process_name   = @processname      
and  a.component_name  = @componentname      
and  a.customer_name   = b.customer_name      
and  a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name  = b.component_name      
and  a.activity_name   = b.activity_name      
and  a.ui_name    = b.ui_name      
and  a.page_name    = b.page_bt_synonym      
and  a.control_bt_synonym = b.column_bt_synonym      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and   c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and   c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
union      
-- Added by feroz for static control      
select  distinct  a.ui_name,  b.control_id, a.view_name, 'F',   b.visisble_length,      
a.hidden_view_bt_synonym, @CTXT_USER,  @getdate,  a.customer_name,a.project_name,      
a.process_name,a.component_name,a.page_name,a.control_bt_synonym,      
1,@ctxt_user,@getdate,@req_no,   
b.control_type, '', '' --TECH-66740      
from de_hidden_view    a (nolock),      
de_ui_control    b (nolock),      
es_comp_stat_ctrl_type_mst c (nolock)      
where a.customer_name   = @customername      
and  a.project_name   = @projectname      
and  a.process_name    = @processname      
and  a.component_name  = @componentname      
and  a.customer_name   = b.customer_name      
and  a.project_name   = b.project_name      
and  a.process_name   = b.process_name      
and  a.component_name  = b.component_name      
and  a.activity_name   = b.activity_name      
and  a.ui_name    = b.ui_name      
and  a.page_name    = b.page_bt_synonym      
and  a.control_bt_synonym = b.control_bt_synonym      
and  a.customer_name   = c.customer_name      
and  a.project_name   = c.project_name      
and  a.process_name   = c.process_name      
and  a.component_name  = c.component_name      
and  b.control_type   = c.ctrl_type_name      
and     not exists ( select 'x'      
from de_fw_req_ilbo_view c (nolock)      
where c.customer_name = a.customer_name      
and   c.project_name = a.project_name      
and   c.process_name = a.process_name      
and  c.component_name = a.component_name      
and   c.ilbocode  = a.ui_name      
and  c.controlid  = a.control_id      
and   c.viewname  = a.view_name)      
  
-- code added for TECH-66740 starts  
-- For updating glance ui controls storepath for non-aviation for both header / grid columns  


update de_fw_req_ilbo_view  
SET  store_path = b.StaticStorePath,  
  systemgeneratedfileid = CASE WHEN b.systemgeneratedfileid= 'yes' THEN 'n'  
           WHEN b.systemgeneratedfileid = 'no' THEN 'y'  
         ELSE b.systemgeneratedfileid END  
FROM de_fw_req_ilbo_view a (nolock),  
  ngplf_published_common_properties_vw_fn(@customername, @projectname, 'DCN', @req_no) b  
WHERE a.customer_name   = b.customerid  
AND  a.project_name		= b.projectid  
AND  a.process_name		= b.processname  
AND  a.component_name	= b.componentname  
AND  a.ilbocode			= b.uiname  
AND  a.controlid		= b.ControlName  
AND  a.viewname			= b.viewname  
AND  isnull(b.IsAviation, 'n') IN ('n','no')  
--and  isnull(b.StaticStorePath, '') <> ''   --  14469
AND  a.customer_name  = @customername      
AND  a.project_name   = @projectname      
AND  a.process_name   = @processname      
AND  a.component_name = @componentname   
AND EXISTS (SELECT 'X'
FROM ngplf_published_common_properties_vw_fn (@customername, @projectname, 'DCN', @req_no) b
WHERE b.CustomerID	=	@customername 
AND   b.ProjectID	=	@projectname  
AND   b.ProcessName =	@processname  
AND   b.componentname = @componentname
AND   b.UIName		 =  a.ilbocode)


-- For resetting store path for aviation attachments  
update de_fw_req_ilbo_view  
set  store_path = ''  
from de_fw_req_ilbo_view a (nolock),  
  es_comp_ctrl_type_mst b (nolock)      
where a.customer_name  = @customername      
and  a.project_name  = @projectname      
and  a.process_name  = @processname      
and  a.component_name = @componentname      
and  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.ctrl_type_name = b.ctrl_type_name  
and  (isnull(b.relative_document_path,'') <> ''   
or  isnull(b.relative_image_path,'')  <> '')  
and  isnull(b.avn_download, 'n')    = 'Y'  
--code added for TECH-66740 ends  
      
-- Added for TECH-28189      
UPDATE  req SET faTransaction = isnull(ui.faTransaction,0)      
FROM de_fw_req_ilbo req(nolock),      
  fw_bpt_ui ui (nolock)      
WHERe req.customer_name = ui.CustomerID      
AND  req.project_name = ui.ProjectID      
AND  req.process_name = ui.BPID      
--req.component_name = ui.FunctionID      
AND  req.ilbocode  = ui.UIID      
-- code added by Ganesh for the  bugid :: PNR2.0_2301 on 04/05/05      
-- The Text Area filed has to converted as RSLIST.      
update de_fw_req_ilbo_control      
set  type     = 'RSLIST'      
from de_ui_control   dtl(nolock),      
es_comp_ctrl_type_mst mst(nolock),      
de_fw_req_ilbo_control ctl (nolock)      
where ctl.customer_name  = @customername      
and  ctl.project_name  = @projectname      
and  ctl.component_name  = @componentname      
and  ctl.process_name   = @processname      
      
and  dtl.customer_name  = mst.customer_name      
and  dtl.project_name  = mst.project_name      
and  dtl.process_name  = mst.process_name      
and  dtl.component_name  = mst.component_name      
and  dtl.control_type  = mst.ctrl_type_name      
      
and  dtl.customer_name  = ctl.customer_name      
and  dtl.project_name  = ctl.project_name      
and  dtl.process_name  = ctl.process_name      
and  dtl.component_name  = ctl.component_name      
and  dtl.ui_name    = ctl.ilbocode      
and  dtl.control_bt_synonym = ctl.control_bt_synonym      
and  dtl.control_id   = ctl.controlid      
      
and  mst.base_ctrl_type  = 'Edit'      
and  mst.visisble_rows   >= 1 -- Code modified for 25-Jun-2009 by Gowrisankar M for PNR2.0_22708       
      
      
set nocount off      
End   
GO

IF EXISTS ( SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_fw_req_migrate_config' AND TYPE = 'P' )
BEGIN
	GRANT EXEC ON  de_fw_req_migrate_config TO PUBLIC
END
GO
 