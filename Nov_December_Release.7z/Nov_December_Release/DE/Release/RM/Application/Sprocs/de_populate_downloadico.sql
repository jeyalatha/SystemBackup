IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_populate_downloadico' AND TYPE = 'P')
BEGIN
  DROP PROC de_populate_downloadico
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	27 Aug 2019
Purpose 		de_populate_downloadico.sql
********************************************************************************/
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/********************************************************************************/
/* procedure    : de_populate_downloadico                                       */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       :                                                           */
/* date         : 4/ 12/ 2003                                                   */
/********************************************************************************/
/* modification history                                                         */
/* Modified by :                 */
/* Modified on :                 */
/* Description :                 */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3237         */
/* Modified on : 13/07/2005              */
/* Description : INSERT statement conflicted with TABLE FOREIGN KEY constraint
'de_fw_req_publish_ilbo_view_fkey_de_fw_req_publish_ilbo_control'.
The conflict occurred in database 'MOSModel', table 'de_fw_req_publish_ilbo_control'..*/
/********************************************************************************/
/* modified by  : Sangeetha L                                                  */
/* date         : 18/07/2005                                                    */
/* description  : Invalid primary key violation in table fw_des_service.  */
/* BugID  : PNR2.0_3277             */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3386         */
/* Modified on : 01/08/05               */
/* Description : Add Component Description, Activity Description and Task Description in Glossary.*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Gowrisankar for callid PNR2.0_4079        */
/* Modified on : 03/09/05               */
/* Description : Modification of the Enumerated Caption based on the language extension*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_4254         */
/* Modified on : 17/10/05               */
/* Description : Error while publishing ECR : INSERT statement conflicted with TABLE
FOREIGN KEY constraint 'de_fw_req_ilbo_view_fkey_de_fw_req_ilbo_control'.
The conflict occurred in database 'rvw20appdb', table 'de_fw_req_ilbo_control'.*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_4277         */
/* Modified on : 18/10/05   */
/* Description : unable to map the hidden view to a control      */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Anuradha M              */
/* Modified on : 18/10/05               */
/* Description : Bug Id : PNR2.0_4287            */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh               */
/* Modified on : 20/10/05               */
/* Description : Bug Id : PNR2.0_4345
The Filler controls defined in the preview level is to be handeld in ECR based Html generation.*/
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Gowrisankar              */
/* Modified on : 05 Nov 2005              */
/* Description : Bug Id : PNR2.0_4505           */
/********************************************************************************/
/* Modified by : Sangeetha L                      */
/* Modified on : 21 Jan 2006                        */
/* Description : Bug Id : PNR2.0_5645                   */
/********************************************************************************/
/* Modified by : Sangeetha L                      */
/* Modified on : 28 Feb 2006                        */
/* Description : Bug Id : PNR2.0_6673                   */
/********************************************************************************/
/* Modified by : Anuradha                      */
/* Modified on : 16 Mar 2006                   */
/* Description : Bug Id : PNR2.0_7254               */
/********************************************************************************/
/* Modified by : Balaji S                          */
/* Modified on : 10 Jul 2006                        */
/* Description : Bug Id : PNR2.0_9377                   */
/********************************************************************************/
/* Modified by : Balaji S                          */
/* Modified on : 21 Jul 2006                        */
/* Description : Bug Id : PNR2.0_9604                   */
/********************************************************************************/
/* Modified by : Balaji S                          */
/* Modified on : 09 Aug 2006                        */
/* Description : Bug Id : PNR2.0_9857                   */
/********************************************************************************/
/* Modified by : Savitha              */
/* Modified on : 18 Aug 2006                        */
/* Description : Bug Id : PNR2.0_9917                   */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 19 Aug 2006                        */
/* Description : Bug Id : PNR2.0_9944                   */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 27 oct 2006                        */
/* Description : Bug Id : PNR2.0_10703                   */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 08 Nov 2006                        */
/* Description : Bug Id : PNR2.0_10880                   */
/********************************************************************************/
/* Modified By  : Date :   Description :    */
/* S K Mohamed Mohideen 09 Nov 2006 Task Status Message changes  */
/********************************************************************************/
/* Modified by : Feroz                */
/* Modified on : 08/11/06               */
/* Description : State Processing       */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 14 Dec 2006                        */
/* Description : Bug Id :PNR2.0_11392                     */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 15 Dec 2006                        */
/* Description : Bug Id : PNR2.0_11420                   */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 27-Mar-2007                        */
/* Bug Id      : PNR2.0_12828                      */
/********************************************************************************/
/* Modified by : Anuradha M              */
/* Modified on : 28 mar 2007                        */
/* Description : Bug Id : PNR2.0_12845                   */
/********************************************************************************/
/* Modified by : Balaji S              */
/* Modified on : 15 May 2007                        */
/* Description : Bug Id : PNR2.0_13656                   */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 16-May-2007              */
/* BUG ID      : PNR2.0_13677             */
/********************************************************************************/
/* modified by  : Kiruthika R                                                   */
/* date         : 25-May-2007                                                   */
/* description  : PNR2.0_13817                                                  */
/********************************************************************************/
/* modified by  : Gowrisankar M                                                 */
/* date         : 01-Aug-2007                                                   */
/* description  : PNR2.0_14775                                                  */
/********************************************************************************/
/********************************************************************************/
/* modified by  : Sangeetha G                                                 */
/* date         : 01-Aug-2007                                                   */
/* description  : PNR2.0_14780                                                 */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by    : Sangeetha G        */
/* date     : 30-nov-2007         */
/* BugId    : PNR2.0_16143           */
/************************************************************************/
/* modified by    : Sangeetha G        */
/* date        : 3-dec-2007         */
/* BugId          : PNR2.0_16152           */
/************************************************************************/
/* modified by    : Sangeetha G        */
/* date           : 04-Dec-2007         */
/* BugId          : PNR2.0_16185            */
/************************************************************************/
/* modified by    : Sangeetha G           */
/* date           : 19-Feb-2008           */
/* BugId          : PNR2.0_16899          */
/************************************************************************/
/* modified by  : Feroz                                            */
/* date         : 25-Apr-2008                                           */
/* Bug Id   : PNR2.0_1476                    */
/************************************************************************/
/* modified by  : Jeya Latha K   */
/* date         : 13-May-2008       */
/* Bug Id : PNR2.0_1522                    */
/************************************************************************/
/* modified by  : Feroz                                              */
/* date         : 07-July-2008                                          */
/* Bug Id    : PNR2.0_18426                 */
/************************************************************************/
/* Modified by  : Gopinath S           */
/* Date         : 06-OCT-2008           */
/* Bug ID       : PNR2.0_19480           */
/************************************************************************/
/* modified by   : Feroz           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/************************************************************************/
/* Modified by   : Feroz           */
/* Date     : 09-Jan-2008         */
/* BugId    : PNR2.0_20589          */
/************************************************************************/
/* Modified by   : Gowrisankar M for PNR2.0_20871     */
/* Date     : 30-Jan-2009         */
/* Description   : Accesskey Update from Preview is to be commented*/
/************************************************************************/
/* Modified by   : Feroz           */
/* Date     : 12-Feb-2008         */
/* BugId    : PNR2.0_21027          */
/************************************************************************/
/* Modified by   : Jeya Latha K         */
/* Date     : 13-Feb-2008         */
/* BugId    : PNR2.0_21050          */
/************************************************************************/
/* Modified by   : Gowrisankar M         */
/* Date     : 25-May-2009         */
/* BugId    : PNR2.0_22370          */
/* Description   : Column state properties update duplicated  */
/************************************************************************/
/* modified by  : Sangeetha G                                           */
/* date         : 26-May-2009                                           */
/* Bug Id  : PNR2.0_22275       */
/* modified for : To include page focus in state processing  */
/************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By     : Feroz           */
/* Date       : 26-Aug-2009         */
/* Description     : PNR2.0_23463          */
/******************************************************************************/
/* Modified By     : Chanheetha N A        */
/* Date      : 23-Oct-2009         */
/* Bug Id      : PNR2.0_24424         */
/* Description     : Pagename added for mapped controls to launch EzeeView Link from model  */
/*************************************************************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 19-Jan-2010                                                   */
/* Bug Id   : PNR2.0_25308             */
/* Description  : Phase 4 Features            */
/********************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 29-Jan-2010                                                   */
/* Bug Id   : PNR2.0_25741             */
/********************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 08-Feb-2010         */
/* Description     : PNR2.0_25863 --Added for imagepath column  */
/******************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 09-Feb-2010         */
/* Description     : PNR2.0_25884          */
/******************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 11-Feb-2010         */
/* Description     : PNR2.0_25912 , PNR2.0_25915     */
/******************************************************************************/
/* Modified By     : Jeya Latha K         */
/* Date       : 15-Feb-2010         */
/* Description     : PNR2.0_25928         */
/******************************************************************************/
/* Modified by : Gowrisankar M           */
/* Date   : 25-Feb-2010           */
/* BugId  : PNR2.0_26070            */
/* Description : State tables to be deleted before page master deletion*/
/************************************************************************/
/* Modified By     :  Jeya Latha K        */
/* Date       :  26-Feb-2010        */
/* Description     :  Bug ID PNR2.0_26087      */
/********************************************************************************/
/* modified by  : Gowrisankar M                                              */
/* date         : 30-Mar-2010                                                   */
/* Bug Id   : PNR2.0_26390             */
/* Description : Removal of report related tables data based on re_published */
/********************************************************************************/
/* Modified By     :  Sangeetha G  */
/* Date      :  05-Apr-10  */
/* Bugid     :  PNR2.0_26335  */
/* Modified For     :  Traversal table schema change */
/**********************************************************************************************/
/* Modified By     : Sangeetha G                  */
/* Date      : 28-Apr-2010          */
/* Bug Id      : PNR2.0_26701           */
/* Description     : Column addition for ListEdit Resolve tables */
/***********************************************************************************************/
/* Modified By      : Chanheetha N A               */
/* Date            : 14-May-2010             */
/* BugID       : PNR2.0_26860              */
/* Modified For      : Extra column to specify freezecount                   */
/********************************************************************************/
/* modified by  : Sangeetha G            */
/* date    : 11-Feb-2011                                           */
/* Bug Id   : PNR2.0_30127           */
/* Modified for  : Feature  Release          */
/****************************************************************************/
/* modified by   : Sangeetha G           */
/* date    : 11-Apr-2011           */
/* BugId   : PNR2.0_30869           */
/* modified for  : Feature Release          */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : May 18 2011           */
/* Bug ID  : PNR2.0_31403            */
/* Case Desc : Tree Grid Feature Enhancement.      */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : June 08 2011           */
/* Bug ID  : PNR2.0_31780               */
/* Case Desc : Tree Grid Feature Enhancement.      */
/************************************************************************/
/* modified by : Chanheetha N A          */
/* modified on : June 09 2011           */
/* Bug ID  : PNR2.0_31788               */
/* Case Desc : Performance Tuning for ecr dwnld      */
/************************************************************************/
/* modified by : Balaji D            */
/* modified on : July 08 2011           */
/* Bug ID  : PNR2.0_32271              */
/* Case Desc : Freezecount Value is not updating for grid controls   */
/************************************************************************/
/* modified by : Gankan.G               */
/* modified on : 05-AUG-2011           */
/* Bug ID  : PNR2.0_32794            */
/* Case Desc : Code addded to avoid duplication of task description */
/*      within a component         */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : 08-AUG-2011           */
/* Bug ID  : PNR2.0_32811            */
/* Case Desc : Radio button caption not updating       */
/************************************************************************/
/* Modified by  : Balaji D            */
/* Date         : 05-Aug-2011                                           */
/* Bug ID  : PNR2.0_32748                                          */
/* Case Desc : Radio button caption not updating       */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : 15-Oct-2011           */
/* Bug ID  : PNR2.0_34035            */
/* Case Desc : Chart table schema change        */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : 03-Nov-2011           */
/* Bug ID  : PNR2.0_33960           */
/* Case Desc : Sample data,Set_User_Pref & AccessKey not updating */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : 04-Nov-2011           */
/* Bug ID  : PNR2.0_34150           */
/* Case Desc : SQL error on ecr download        */
/************************************************************************/
/* modified by : Balaji D               */
/* modified on : Dec 31 2011           */
/* Bug ID  : PNR2.0_35984            */
/* Case Desc : Modelling for Splitter Section.      */
/************************************************************************/
/* modified by  : Balaji D                                     */
/* date         : july 02 2012                                   */
/* BugId        : PLF2.0_00961                                    */
/* Case Desc    : PopUpSection,Button Right Align,Page/Button/Link Images*/
/************************************************************************/
/* modified by   : Kiruthika R                       */
/* date          : 06-Mar-2013                     */
/* Bug ID		 : PLF2.0_03710              */
/* Description   : Customlist implementation for header edit controls.       */
/************************************************************************/
/* modified by  : Gankan G           */
/* date         : 28-May-2013           */
/* Bug ID		: PLF2.0_04721           */
/* Description	: Code modified to handle equal tabwidth   */
/************************************************************************/
/* modified by  :  Shakthi P                            */
/* date         : 12-Mar-2014                              */
/* Bug ID		: PLF2.0_07805                             */
/* Description  : Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan*/
/*********************************************************************************/
/* modified by  :  Loganayaki P													 */
/* date         :  29-05-2014													 */
/* Bug ID		:  PLF2.0_09536														 */
/* Description  :  Code added to restrict workflow control deletion 			 */
/*********************************************************************************/
/* modified by  : Shakthi P                                                     	 */
/* date         : 30 May 2014                                                 	     */
/* Bug Id       : PLF2.0_08470                                      	        	 */
/* Description  : Tooltip Not Required.ForceFit,Grid Column Caption Not Required 	 */
/* There is log of changes so,no modification History                            	 */
/*************************************************************************************/
/* modified by   : Ganesh Prabhu S      										*/
/* date			 : 10-Sep-2014     										*/
/* description	 : Code Added to involve tree grid in fetch		*/
/* Primary BugID : PLF2.0_09523											*/
/************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* modified by  : Veena U														*/
/* date         : 25-Feb-2015													 */
/* Bug ID		:  PLF2.0_11499															 */
/* Description  :  code added for Width,height,toolbarreq,groupname columns	 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 28-Mar-2016                                                  */
/*Defect Id 	: PLF2.0_17570										*/
/********************************************************************************/
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 21-Nov-2017  Defect ID	:TECH-16126	*/
/********************************************************************************/
/* Modified by  : Ranjitha			Date: 29-Mar-2018  Defect ID	:TECH-20326	*/
/************************************************************************************************/
/* Modified by  : Jeya Latha K				Date: 30-Apr-2018  Defect ID : TECH-20897			*/
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010			*/
/* Modified by : Jeya Latha K				Date: 08-Jan-2019  Defect ID : TECH-29822			*/
/* Modified by : Jeya Latha K			    Date: 25-Jul-2019  Defect ID: TECH-36371			*/
/************************************************************************************************/
/* Modified by : Hareesh K/Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809 */ 
/* Modified by : Rajeswari M/Jeya Latha K			  Date: 27-Feb-2020  Defect ID : TECH-43307	*/
/* Modified by : Rajeswari M/Priyadharshini U		  Date: 28-Jul-2021  Defect ID : TECH-60451	*/
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer     */
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo				*/ 
/*************************************************************************************************/
/* Modified By	: Venkatesan K																	 */
/* Defect ID	: TECH-66583																     */
/* Modified on	: 24Feb2022																         */
/* Description	: RVW 2.0 Model publish table implementation for control and task property.      */
/*************************************************************************************************/
/* Modified By	: Ponmalar A/Priyadharshini U													 */
/* Defect ID	: TECH-68066																     */
/* Modified on	: 13-Apr-2022																     */
/* Description	: Post and Pre Tasks for Attachment controls.									 */
/*************************************************************************************************/
/* modified by  : Venkatesan K																	 */
/* Date         : 13-APR-2022																	 */
/* Defect ID	: TECH-68067																	 */
/* Description  : Provision to download all the attachments as bulk in Grid Control.			 */
/*************************************************************************************************/
/* modified by  : Manoj S																	     */
/* Date         : 05-Jul-2022																	 */
/* Defect ID	: TECH-70535																	 */
/* Description  : Control id is not getting modified in the Nativeapp template modelling.		 */
/*************************************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	VimalKumar R												*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by : Vimal Kumar R												    */
/* Modified on : 27-July-2022                                                   */
/* Defect ID   : TECH-71262														*/
/* Description : Platform Features for the Month of July'22                     */
/********************************************************************************/
/* Modified By  : Ganesh Prabhu S												*/
/* Defect ID 	: TECH-71539													*/
/* Modified on 	: 02Aug2022														*/
/********************************************************************************/
/* Modified By  : Ponmalar A													*/
/* Defect ID 	: Tech-72114													*/
/* Modified on 	: 09Aug2022														*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 30-Sep-2022		Defect ID  : TECH-73216 */
/****************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R												*/
/* Modified on : 27-Oct-2022															*/
/* Defect ID   : TECH-73996																*/
/* Description : Addition of attributes for control types in setup ui preferences screen*/
/****************************************************************************************/
/* Modified by : Ponmalar A / Vimal Kumar R												*/
/* Modified on : 02-Nov-2022															*/
/* Defect ID   : TECH-74150																*/
/****************************************************************************************/
CREATE  PROCEDURE de_populate_downloadico
	@Ctxt_Language engg_Ctxt_Language,
	@ctxt_OUInstance engg_ctxt_OUInstance,
	@Ctxt_Service engg_Ctxt_Service,
	@ctxt_User engg_ctxt_User,
	@customer_name engg_name,
	@project_name engg_name,
	@ecr_no engg_name,
	@ico_no engg_name,
	@process_name_tmp engg_name,
	@component_name_tmp engg_name,
	@activity_name_tmp engg_name,
	@ui_name_tmp engg_name
AS
BEGIN
	SET NOCOUNT ON

	DECLARE --    @l1_tmp      engg_name,
		@ctrl_hdb_ctrl_id engg_name,
		@ctrl_hdn_name engg_name,
		--   @ctrl_hdn_ctrl_name   engg_name,
		@hdn_view_tmp engg_name,
		--   @data_column_scalemode  engg_prefix,
		--   @label_column_scalemode  engg_prefix,
		@grid_ctrl_name engg_name,
		@grid_clmn_name engg_name,
		@grid_ctrl_id engg_name,
		@page_name engg_name,
		@date engg_date

	SELECT @date = getdate()

	--deleting state tables
	DELETE a
	FROM de_ui_state a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.state_id = a.state_id
			)

	DELETE a
	FROM de_ui_state_section a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.state_id = a.state_id
			)

	DELETE a
	FROM de_ui_state_control a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.state_id = a.state_id
			)

	DELETE a
	FROM de_ui_state_task a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state_task b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.task_name = a.task_name
			)

	DELETE a
	FROM de_ui_state_task_mst a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state_task_mst b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.task_name = a.task_name
				AND b.state_id = a.state_id
			)

	-- Code added for the BugId PNR2.0_1790 Starts
	DELETE a
	FROM de_ui_state_column a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_state_column b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcn_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
				AND b.state_id = a.state_id
			)

	DELETE a
	FROM de_ui_state_page a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_published_ui_state_page b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.state_id = a.state_id
			)

	-- Code added for the BugId PNR2.0_1790 Ends
	--deleting state tables end
	-- starting-- --code moved here to avoid foreign key violation for page tables
	--1.DE_UI_PAGE
	DELETE a
	FROM de_ui_page a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_page c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
			)

	UPDATE a
	SET a.horder = b.horder,
		a.vorder = b.vorder,
		a.page_doc = b.page_doc,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.page_Type = b.page_Type, -- Column added for the BugId PNR2.0_1790
		a.pageimage = b.pageimage -- Code added for the BugId PLF2.0_00961
		,
		a.width = b.width --code added for bugID:PLF2.0_04721
		,
		a.PageClass = b.PageClass,
		a.HeaderPosition = b.HeaderPosition, ---PLF2.0_17570
		a.TabTitleStyle = b.TabTitleStyle,
		a.TabIconPosition = b.TabIconPosition,
		a.PageLayout = b.PageLayout,
		a.XYCoordinates = b.XYCoordinates,
		a.ColumnLayWidth = b.ColumnLayWidth,
		--Code added for TECH-70687 starts
		a.LeftToolbar		=	b.LeftToolbar	,
		a.RightToolbar		=	b.RightToolbar	,
		a.TopToolbar		=	b.TopToolbar	,
		a.BottomToolbar		=	b.BottomToolbar	
		--Code added for TECH-70687 ends
	--a.page_prefix = b.page_prefix -- check JL
	FROM de_ui_page a(NOLOCK),
		re_published_ui_page b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym

	INSERT INTO de_ui_page (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		horder,
		vorder,
		ui_page_sysid,
		ui_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		page_doc,
		page_prefix,
		page_Type,
		ecrno,
		pageimage --) -- Column added for the BugId PNR2.0_1790,PLF2.0_00961 --code modified for : PLF2.0_04721
		,
		width,
		PageClass --code added for bugID:PLF2.0_04721
		,
		HeaderPosition,
		TabRotation,
		TabTitleStyle,
		TabIconPosition, ---PLF2.0_17570
		PageLayout,
		XYCoordinates,
		ColumnLayWidth,
		--Code added for TECH-70687 starts
		LeftToolbar,
		RightToolbar,
		TopToolbar,
		BottomToolbar
		--Code added for TECH-70687 ends
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		horder,
		vorder,
		ui_page_sysid,
		ui_sysid,
		1,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		page_doc,
		page_prefix,
		page_Type,
		@ico_no,
		pageimage -- Column added for the BugId PNR2.0_1790,PLF2.0_00961
		,
		width,
		PageClass --code added for bugID:PLF2.0_04721
		,
		HeaderPosition,
		TabRotation,
		TabTitleStyle,
		TabIconPosition, ---PLF2.0_17570
		PageLayout,
		XYCoordinates,
		ColumnLayWidth,
		--Code added for TECH-70687 starts
		LeftToolbar,
		RightToolbar,
		TopToolbar,
		BottomToolbar
		--Code added for TECH-70687 ends
	FROM re_published_ui_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_page c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
			)

	-- ended-- --code moved here to avoid foreign key violation for page tables
	--Code Modification for PNR2.0_30869 starts
	DELETE a
	FROM de_ui_pageevents a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_pageevents c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
			)

	UPDATE a
	SET a.horder = b.horder,
		a.vorder = b.vorder,
		a.Task_Onclick = b.Task_Onclick,
		a.SystemGenerated = b.SystemGenerated,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_ui_pageevents a(NOLOCK),
		re_published_ui_pageevents b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym

	--and  (isnull(a.horder,0)  <> isnull(b.horder,0)  or --shakthi
	--isnull(a.vorder,0)  <> isnull(b.vorder,0) or
	--isnull(a.Task_Onclick,'')  <> isnull(b.Task_Onclick,'') or
	--isnull(a.SystemGenerated,'') <> isnull(b.SystemGenerated,''))
	INSERT INTO de_ui_pageevents (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		horder,
		vorder,
		EventRequired,
		Task_Onclick,
		SystemGenerated,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.horder,
		a.vorder,
		a.EventRequired,
		a.Task_Onclick,
		a.SystemGenerated,
		1,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_pageevents a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_pageevents c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
			)

	--Code Modification for PNR2.0_30869 ends
	--2. DE_UI_SECTION
	DELETE a
	FROM de_ui_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.section_bt_synonym <> 'WF_HDN_SECTION' --- code added for bugid PLF2.0_09523 to restrict deletion of WF_HDN_SECTION
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
			)

	--- code added for bug id PLF2.0_09523 begins
	DELETE a
	FROM de_ui_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.section_bt_synonym = 'WF_HDN_SECTION'
		AND NOT EXISTS (
			SELECT 's'
			FROM re_wsinp_task_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_name
				AND b.project_code = a.project_name
				AND b.container_page_ilbo_code = a.ui_name
			
			UNION
			
			SELECT 's'
			FROM re_wsinp_task_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_name
				AND b.project_code = a.project_name
				AND b.detail_page_ilbo_code = a.ui_name
			)
		AND NOT EXISTS (
			SELECT 's'
			FROM re_ui_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.section_bt_synonym = a.section_bt_synonym
			) --- code added for bug id PLF2.0_09523 ends

	--Code Modified for BugId : PNR2.0_9377
	UPDATE a
	SET visisble_flag = b.visisble_flag,
		title_required = b.title_required,
		border_required = b.border_required,
		parent_section = b.parent_section,
		horder = b.horder,
		vorder = b.vorder,
		section_doc = b.section_doc,
		title_alignment = b.title_alignment,
		width = b.width,
		height = b.height,
		SectionPrefixClass = b.SectionPrefixClass,
		caption_Format = b.caption_Format,
		ctrl_caption_align = b.ctrl_caption_align,
		section_type = b.section_type,
		--section_prefix   = b.section_prefix,
		Setion_width_Scalemode = b.Setion_width_Scalemode,
		Setion_height_Scalemode = b.Setion_height_Scalemode,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.Associated_control = b.Associated_control, -- Code modified for  PNR2.0_31403
		a.splitter_pos = b.splitter_pos, --PNR2.0_34863
		a.section_collapsemode = b.section_collapsemode,
		a.NColSpan = b.NColSpan,
		a.NRowSpan = b.NRowSpan,
		--a.IsStatic = b.IsStatic,
		a.section_collapse = b.section_collapse,
		a.CarouselNavigation = b.CarouselNavigation,
		cell_spacing = b.cell_spacing,
		cell_padding = b.cell_padding,
		Region = b.Region, ---PLF2.0_17570
		TitlePosition = b.TitlePosition,
		CollapseDir = b.CollapseDir,
		SectionLayout = b.SectionLayout,
		XYCoordinates = b.XYCoordinates,
		ColumnLayWidth = b.ColumnLayWidth,
		IsPlatform = b.IsPlatform,
		IsResponsive = b.IsResponsive,
		mob_pop_fullview = b.mob_pop_fullview,
		BorderLeftWidth			=	b.BorderLeftWidth,
		BorderRightWidth		=	b.BorderRightWidth,
		BorderTopWidth			=	b.BorderTopWidth,
		BorderBottomWidth		=	b.BorderBottomWidth,
		BorderLeftColor			=	b.BorderLeftColor,
		BorderRightColor		=	b.BorderRightColor,
		BorderTopColor			=	b.BorderTopColor,
		BorderBottomColor		=	b.BorderBottomColor,
		BorderTopLeftRadius		=	b.BorderTopLeftRadius,
		BorderTopRightRadius	=	b.BorderTopRightRadius,
		BorderBottomLeftRadius	=	b.BorderBottomLeftRadius,
		BorderBottomRightRadius	=	b.BorderBottomRightRadius,
		BorderStyle				=	b.BorderStyle,		
		ForResponsive			=	b.ForResponsive,		--Code added for TECH-69624
		--Code added for TECH-70687 starts
		LeftToolbar				=	b.LeftToolbar,
		RightToolbar			=	b.RightToolbar,
		TopToolbar				=	b.TopToolbar,
		BottomToolbar			=	b.BottomToolbar,
		MinimizedRows			=	b.MinimizedRows,
		ViewMode				=	b.ViewMode,
		HasTitleAction			=	b.HasTitleAction,
		--Code added for TECH-70687 ends
		TitleIcon				=	b.TitleIcon,		--Tech-72114
		Orientation				=	b.Orientation		--TECH-74150
	FROM de_ui_section a(NOLOCK),
		re_published_ui_section b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.ecr_no = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym

	--Code Modified for BugId : PNR2.0_9377
	INSERT INTO de_ui_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		visisble_flag,
		title_required,
		border_required,
		parent_section,
		horder,
		vorder,
		ui_section_sysid,
		page_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		section_doc,
		width,
		height,
		SectionPrefixClass,
		caption_Format,
		ctrl_caption_align,
		section_type,
		Setion_width_Scalemode,
		Setion_height_Scalemode,
		section_prefix,
		ecrno, --chan
		title_alignment,
		Associated_control,
		splitter_pos,
		section_collapsemode,
		NRowSpan,
		NColSpan /*, Isstatic*/,
		section_collapse,
		CarouselNavigation -- Code modified for  PNR2.0_30127 ,PNR2.0_31403 ,PNR2.0_34863
		,
		cell_spacing,
		cell_padding,
		Region,
		TitlePosition,
		CollapseDir,
		SectionLayout,
		XYCoordinates,
		ColumnLayWidth,
		IsPlatform,
		IsResponsive,
		mob_pop_fullview,
		--Code added for TECH-69624 starts
		BorderLeftWidth,
		BorderRightWidth,
		BorderTopWidth,
		BorderBottomWidth,
		BorderLeftColor,
		BorderRightColor,
		BorderTopColor,
		BorderBottomColor,
		BorderTopLeftRadius,
		BorderTopRightRadius,
		BorderBottomLeftRadius,
		BorderBottomRightRadius,
		BorderStyle,
		ForResponsive,
		--Code added for TECH-69624 ends
		--Code added for TECH-70687 starts
		LeftToolbar,
		RightToolbar,
		TopToolbar,
		BottomToolbar,
		MinimizedRows,
		ViewMode,
		HasTitleAction,
		--Code added for TECH-70687 ends
		TitleIcon,	--Tech-72114
		Orientation	--TECH-74150
		) ---PLF2.0_17570
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.visisble_flag,
		a.title_required,
		a.border_required,
		a.parent_section,
		a.horder,
		a.vorder,
		a.ui_section_sysid,
		a.page_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.section_doc,
		a.width,
		a.height,
		a.SectionPrefixClass,
		a.caption_Format,
		a.ctrl_caption_align,
		a.section_type,
		a.Setion_width_Scalemode,
		a.Setion_height_Scalemode,
		a.section_prefix,
		@ico_no,
		title_alignment,
		Associated_control,
		splitter_pos,
		a.section_collapsemode,
		a.NRowSpan,
		a.NColSpan,
		/*a.isstatic,*/ a.section_collapse,
		CarouselNavigation -- Code modified for  PNR2.0_30127,PNR2.0_31403 ,PNR2.0_34863
		,
		cell_spacing,
		cell_padding,
		Region,
		TitlePosition,
		CollapseDir,
		SectionLayout,
		XYCoordinates,
		ColumnLayWidth,
		IsPlatform, ---PLF2.0_17570		
		IsResponsive,
		mob_pop_fullview,
		--Code added for TECH-69624 Starts
		BorderLeftWidth,
		BorderRightWidth,
		BorderTopWidth,
		BorderBottomWidth,
		BorderLeftColor,
		BorderRightColor,
		BorderTopColor,
		BorderBottomColor,
		BorderTopLeftRadius,
		BorderTopRightRadius,
		BorderBottomLeftRadius,
		BorderBottomRightRadius,
		BorderStyle,
		ForResponsive,
		--Code added for TECH-69624 ends
		--Code added for TECH-70687 starts
		LeftToolbar,
		RightToolbar,
		TopToolbar,
		BottomToolbar,
		MinimizedRows,
		ViewMode,
		HasTitleAction,
		--Code added for TECH-70687 ends
		TitleIcon, --Tech-72114
		Orientation	--TECH-74150
	FROM re_published_ui_section a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.ecr_no = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
			)

	----------------------------------------------------------------------------------------------
	--2. DE_UI_CONTROL
	DELETE a
	FROM de_ui_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.control_bt_synonym NOT IN (
			'HdnWFOrgUnit',
			'HdnWFDocKey'
			) -- code added for the bug id plf2.0
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	/* code added for bug id : */
	DELETE a
	FROM de_ui_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.control_bt_synonym IN (
			'HdnWFOrgUnit',
			'HdnWFDocKey'
			)
		AND NOT EXISTS (
			SELECT 's'
			FROM re_wsinp_task_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_name
				AND b.project_code = a.project_name
				AND b.container_page_ilbo_code = a.ui_name
			
			UNION
			
			SELECT 's'
			FROM re_wsinp_task_dtl b(NOLOCK)
			WHERE b.customer_code = a.customer_name
				AND b.project_code = a.project_name
				AND b.detail_page_ilbo_code = a.ui_name
			)
		AND NOT EXISTS (
			SELECT 's'
			FROM re_ui_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	/* code added for bug id : ends*/
	UPDATE a
	SET control_type = b.control_type,
		horder = b.horder,
		vorder = b.vorder,
		visisble_length = b.visisble_length,
		control_doc = b.control_doc,
		order_seq = b.order_seq,
		data_column_width = b.data_column_width,
		label_column_width = b.label_column_width,
		data_column_scalemode = b.data_column_scalemode,
		label_column_scalemode = b.label_column_scalemode,
		control_id = b.control_id,
		view_name = b.view_name,
		tab_seq = b.tab_seq,
		help_tabstop = b.help_tabstop,
		LabelClass = b.LabelClass,
		ControlClass = b.ControlClass,
		LabelImageClass = b.LabelImageClass,
		ControlImageClass = b.ControlImageClass,
		proto_tooltip = b.proto_tooltip, --code added by Kiruthika for bugid:PNR2.0_11392
		Freezecount = b.freezecount, --code added for bugid:PNR2.0_32271
		--code added for bugid:PNR2.0_33960 starts
		sample_data = b.sample_data,
		Set_User_Pref = b.Set_User_Pref,
		--code added for bugid:PNR2.0_33960 ends
		-- Code added for the BugId PLF2.0_00961 Starts
		controlimage = b.controlimage,
		colspan = b.colspan,
		rowspan = b.rowspan,
		TemplateID = b.TemplateID,
		-- Code added for the BugId PLF2.0_00961 Ends
		modifiedby = @ctxt_user,
		modifieddate = @date,
		TemplateCategory = b.TemplateCategory,
		TemplateSpecific = b.TemplateSpecific,
		Control_class_ext6 = b.Control_class_ext6,
		icon_position = b.icon_position,
		icon_class = b.icon_class,
		accesskey = b.accesskey,
		sensitivedata = b.sensitivedata, -- Added for TECH-20897
		IsPlatform = b.IsPlatform,
		DynamicStyle = b.DynamicStyle,
		ImageAsData = b.ImageAsData,
		MoreEventEnabled=b.MoreEventEnabled,  --Added for the Defect ID TECH-45828
       	UpeSetFocusEnabled=b.UpeSetFocusEnabled, --Added for the Defect ID TECH-45828
		ExtensionReqd	= b.ExtensionReqd,				--Code added for TECH-60451
		ExtensionLaunchMode	=	b.ExtensionLaunchMode,  --Code added for TECH-60451
		AssociateControl	=	b.AssociateControl,	--code added for the defect id : TECH-63527
		BorderLeftWidth			=	b.BorderLeftWidth,
		BorderRightWidth		=	b.BorderRightWidth,
		BorderTopWidth			=	b.BorderTopWidth,
		BorderBottomWidth		=	b.BorderBottomWidth,
		BorderLeftColor			=	b.BorderLeftColor,
		BorderRightColor		=	b.BorderRightColor,
		BorderTopColor			=	b.BorderTopColor,
		BorderBottomColor		=	b.BorderBottomColor,
		BorderTopLeftRadius		=	b.BorderTopLeftRadius,
		BorderTopRightRadius	=	b.BorderTopRightRadius,
		BorderBottomLeftRadius	=	b.BorderBottomLeftRadius,
		BorderBottomRightRadius	=	b.BorderBottomRightRadius,
		BorderStyle				=	b.BorderStyle,					
		HasCustomAction			=	b.HasCustomAction,
		ForResponsive			=	b.ForResponsive,					--Code added for TECH-69624 
		ControlFormat			=	b.ControlFormat,		
		ButtonNature			=	b.ButtonNature,
		InlineStyle				=	b.InlineStyle		--TECH-74150
	FROM de_ui_control a(NOLOCK),
		re_published_ui_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym

	----Code Modified For BugId : PNR2.0_9604
	--and  ( isnull(a.control_type,'')   <> isnull(b.control_type,'')    or --shakthi
	--isnull(a.horder,0)     <> isnull(b.horder,0)     or
	--isnull(a.vorder,0)     <> isnull(b.vorder,0)     or
	--isnull(a.visisble_length,0)   <> isnull(b.visisble_length,0)   or
	--isnull(a.control_doc,'')   <> isnull(b.control_doc,'')    or
	--isnull(a.order_seq,0)    <> isnull(b.order_seq,0)    or
	--isnull(a.data_column_width,0)  <> isnull(b.data_column_width,0)  or
	--isnull(a.label_column_width,0)  <> isnull(b.label_column_width,0)  or
	--isnull(a.data_column_scalemode,'') <> isnull(b.data_column_scalemode,'')  or
	--isnull(a.label_column_scalemode,'') <> isnull(b.label_column_scalemode,'')  or
	--isnull(a.control_id,'')    <> isnull(b.control_id,'')    or
	--isnull(a.view_name,'')    <> isnull(b.view_name,'')     or
	--isnull(a.tab_seq,0)     <> isnull(b.tab_seq,0)      or
	--isnull(a.help_tabstop,'')   <> isnull(b.help_tabstop,'')    or
	--isnull(a.LabelClass,'')    <> isnull(b.LabelClass,'')     or
	--isnull(a.ControlClass,'')   <> isnull(b.ControlClass,'')    or
	--isnull(a.LabelImageClass,'')  <> isnull(b.LabelImageClass,'')   or
	--isnull(a.ControlImageClass,'')  <> isnull(b.ControlImageClass,'')  or
	--isnull(a.proto_tooltip,'')   <> isnull(b.proto_tooltip,'') --code added by Kiruthika for bugid:PNR2.0_11420
	--or isnull(a.freezecount,0)   <> isnull(b.freezecount,0)--code added for bugid:PNR2.0_32271
	----code added for bugid:PNR2.0_33960 starts
	--or isnull(a.sample_data,'')   <> isnull(b.sample_data,'')
	--or isnull(a.Set_User_Pref,'')   <> isnull(b.Set_User_Pref,'')
	----code added for bugid:PNR2.0_33960 ends
	---- Code added for the BugId PLF2.0_00961 Starts
	--or isnull(a.controlimage,'')    <> isnull( b.controlimage,'')
	--or isnull(a.colspan,0)         <> isnull(b.colspan,0)
	--or isnull(a.rowspan,0)         <> isnull(b.rowspan,0))
	-- Code added for the BugId PLF2.0_00961 Ends
	-- Code commented for PNR2.0_20871 on 30-Jan-2009 -- Begins
	-- Code Added for the Bug Id :PNR2.0_1522 - AccessKey Feature
	-- update a set a.Accesskey = b.accesskey
	-- from  de_ui_control a (nolock),
	--  ep_ui_control_dtl b(nolock)
	-- where  a.customer_name  = b.customer_name
	-- and a.project_name  = b.project_name
	-- and a.process_name  = b.process_name
	-- and a.component_name = b.component_name
	-- and a.activity_name  = b.activity_name
	-- and a.ui_name  = b.ui_name
	-- and a.page_bt_synonym = b.page_bt_synonym
	-- and a.section_bt_synonym = b.section_bt_synonym
	-- and a.control_bt_synonym = b.control_bt_synonym
	-- and a.control_type  = b.control_type
	-- Code commented for PNR2.0_20871 on 30-Jan-2009 -- Ends
	INSERT INTO de_ui_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		ui_control_sysid,
		ui_section_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		order_seq,
		data_column_width,
		control_id,
		view_name,
		label_column_width,
		visisble_length,
		proto_tooltip,
		sample_data,
		control_doc,
		control_prefix,
		data_column_scalemode,
		label_column_scalemode,
		tab_seq,
		help_tabstop,
		LabelClass,
		ControlClass,
		LabelImageClass,
		ControlImageClass,
		ecrno,
		Set_User_Pref,
		freezecount, -- code Added by Gopinath S for the Call ID PNR2.0_19480 --added for PNR2.0_26860
		controlimage,
		colspan,
		rowspan,
		TemplateID,
		TemplateCategory,
		TemplateSpecific,
		Control_class_ext6,
		icon_position,
		icon_class,
		AccessKey, -- code modified for the caseid: PLF2.0_00961
		sensitivedata,
		Isplatform,
		DynamicStyle,
		ImageAsData,
	  	MoreEventEnabled,  --Added for the Defect ID TECH-45828
     	UpeSetFocusEnabled,  --Added for the Defect ID TECH-45828
		ExtensionReqd,     --Code added for TECH-60451
		ExtensionLaunchMode,
		AssociateControl, --code added for the defect id : TECH-63527
		--Code added for TECH-69624 starts
		BorderLeftWidth,
		BorderRightWidth,
		BorderTopWidth,
		BorderBottomWidth,
		BorderLeftColor,
		BorderRightColor,
		BorderTopColor,
		BorderBottomColor,
		BorderTopLeftRadius,
		BorderTopRightRadius,
		BorderBottomLeftRadius,
		BorderBottomRightRadius,
		BorderStyle,
		HasCustomAction,
		ForResponsive,--Code added for TECH-69624 ends
						-- Added for TECH-20897
		ControlFormat,
		ButtonNature,
		InlineStyle		--TECH-74150
		) 
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		ui_control_sysid,
		ui_section_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		order_seq,
		data_column_width,
		control_id,
		view_name,
		label_column_width,
		visisble_length,
		proto_tooltip,
		sample_data,
		control_doc,
		control_prefix,
		data_column_scalemode,
		label_column_scalemode,
		tab_seq,
		help_tabstop,
		LabelClass,
		ControlClass,
		LabelImageClass,
		ControlImageClass,
		@ico_no,
		Set_User_Pref,
		freezecount, --added for PNR2.0_26860
		controlimage,
		colspan,
		rowspan,
		TemplateID,
		TemplateCategory,
		TemplateSpecific,
		Control_class_ext6,
		icon_position,
		icon_class,
		AccessKey, -- code modified for the caseid: PLF2.0_00961
		sensitivedata,
		Isplatform,
		DynamicStyle,
		ImageAsData,
	  	MoreEventEnabled, --Added for the Defect ID TECH-45828
     	UpeSetFocusEnabled,  --Added for the Defect ID TECH-45828
		ExtensionReqd,      
		ExtensionLaunchMode,
		AssociateControl, ---code added for the defect id : TECH-63527
		--Code added for TECH-69624 starts
		BorderLeftWidth,
		BorderRightWidth,
		BorderTopWidth,
		BorderBottomWidth,
		BorderLeftColor,
		BorderRightColor,
		BorderTopColor,
		BorderBottomColor,
		BorderTopLeftRadius,
		BorderTopRightRadius,
		BorderBottomLeftRadius,
		BorderBottomRightRadius,
		BorderStyle,
		HasCustomAction, 
		ForResponsive,
		ControlFormat,
		ButtonNature,
		InlineStyle		--TECH-74150
		--Code added for TECH-69624 ends
	FROM re_published_ui_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
			)


	----13852 added on 21feb2020 Starts
	DELETE a
	FROM de_ui_section_refinement a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_section_refinement c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.rcnno = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND	c.section_bt_synonym = a.section_bt_synonym
				AND	c.formfactor	= a.formfactor
			)

	UPDATE a
	SET a.visible_flag = b.visible_flag,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_ui_section_refinement a(NOLOCK),
		re_published_ui_section_refinement b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND	a.section_bt_synonym = b.section_bt_synonym
		AND	a.formfactor	= b.formfactor


	Insert Into de_ui_section_refinement(
	   customer_name,
       project_name,
       process_name,
       component_name,
       activity_name,
       ui_name,
       Formfactor,
       page_bt_synonym,
       section_bt_synonym,
       ecrno,
       visible_flag,
       timestamp,
       createdby,
       createddate,
       modifiedby,
       modifieddate)
	Select r.customer_name,
           r.project_name,
         r.process_name,
           r.component_name,
           r.activity_name,
           r.ui_name,
           r.Formfactor,
           r.page_bt_synonym,
           r.section_bt_synonym,
           @ico_no,
           r.visible_flag,
           r.timestamp,
           @ctxt_user,
           @date,
           @ctxt_user,
           @date
	From re_published_ui_section_refinement r(nolock),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND r.customer_name = b.customer_name
		AND r.project_name = b.project_name
		AND r.rcnno = b.ecr_no
		AND r.process_name = b.process_name
		AND r.component_name = b.component_name
		AND r.activity_name = b.activity_name
		AND r.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_section_refinement c(NOLOCK)
			WHERE r.customer_name = c.customer_name
				AND r.project_name = c.project_name
				AND r.process_name = c.process_name
				AND r.component_name = c.component_name
				AND r.activity_name = c.activity_name
				AND r.ui_name = c.ui_name
				AND r.page_bt_synonym = c.page_bt_synonym
				AND r.section_bt_synonym = c.section_bt_synonym								
				AND	r.formfactor	= c.formfactor
			)

	DELETE a
	FROM de_responsive_sec_weightage a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_responsive_sec_weightage c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.rcnno = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND	c.section_bt_synonym = a.section_bt_synonym
				AND	c.formfactor	= a.formfactor
			)

	UPDATE a
	SET a.Weightage = b.Weightage,
		a.SectionWidth	= b.SectionWidth,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_responsive_sec_weightage a(NOLOCK),
		re_published_responsive_sec_weightage b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym								
		AND	a.formfactor	= b.formfactor


   Insert Into de_responsive_sec_weightage(
              customer_name,
              project_name,
              process_name,
              component_name,
              activity_name,
              ui_name,
              Formfactor,
              page_bt_synonym,
              parent_section,
              section_bt_synonym,
              ecrno,
              Weightage,
              SectionWidth,
              timestamp,
              createdby,
              createddate,
              modifiedby,
              modifieddate)
  Select   w.customer_name,
		   w.project_name,
           w.process_name,
           w.component_name,
           w.activity_name,
           w.ui_name,
           w.Formfactor,
           w.page_bt_synonym,
           w.parent_section,
           w.section_bt_synonym,
           @ico_no,
           w.Weightage,
           w.SectionWidth,
           w.timestamp,
           @ctxt_user,
           @date,
           @ctxt_user,
           @date
	From re_published_responsive_sec_weightage w(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND w.customer_name = b.customer_name
		AND w.project_name = b.project_name
		AND w.rcnno = b.ecr_no
		AND w.process_name = b.process_name
		AND w.component_name = b.component_name
		AND w.activity_name = b.activity_name
		AND w.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_responsive_sec_weightage c(NOLOCK)
			WHERE w.customer_name = c.customer_name
				AND w.project_name = c.project_name
				AND w.process_name = c.process_name
				AND w.component_name = c.component_name
				AND w.activity_name = c.activity_name
				AND w.ui_name = c.ui_name
				AND w.page_bt_synonym = c.page_bt_synonym
				AND w.section_bt_synonym = c.section_bt_synonym	
				AND w.section_bt_synonym = c.section_bt_synonym								
				AND	w.formfactor	= c.formfactor		
			)



	---13852 added on 21feb2020 End

-----Code added for TECH-60451 Starts
	DELETE extn
	FROM de_ui_grid_Extension AS extn,
		#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
	AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
	AND   b.ecr_no				=	@ecr_no
	AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   extn.Customer_Name	=	b.customer_name
	AND   extn.Project_Name		=	b.project_name
	AND   extn.Process_Name		=	b.process_name
	AND   extn.Component_Name	=	b.component_name
	AND   extn.Activity_Name	=	b.activity_name
	AND   extn.ui_name			=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_grid_Extension AS pex(NOLOCK)
			WHERE pex.Customer_Name			=	extn.Customer_Name
			AND   pex.Project_Name			=	extn.Project_Name
			AND   pex.Rcnno					=	@ecr_no
			AND   pex.Process_Name			=	extn.Process_Name
			AND   pex.Component_Name		=	extn.Component_Name
			AND   pex.Activity_Name			=	extn.Activity_Name
			AND   pex.UI_Name				=	extn.UI_Name
			AND   pex.Page_BT_Synonym		=	extn.Page_BT_Synonym
		    AND	  pex.Section_BT_Synonym	=	extn.Section_BT_Synonym
		    AND	  pex.Control_ID			=	extn.Control_ID
			AND   pex.View_Name				=	extn.View_Name
			AND   pex.ParameterName			=	extn.ParameterName
			AND   pex.ParameterSequence		=	extn.ParameterSequence
			AND   pex.MappedBTSynonym		=	extn.MappedBTSynonym
		    AND   pex.MappedField			=	extn.MappedField )
			

		INSERT INTO de_ui_grid_Extension (
			   Customer_Name,
			   Project_Name,
			   EcrNo,
               Process_Name,
               Component_Name,
               Activity_Name,
               UI_Name,
               Page_BT_Synonym,
               Section_BT_Synonym,
               Control_ID,
               View_Name,
               ParameterName,
               ParameterSequence,
               MappedBTSynonym,
               MappedField,
               CreatedBy,
               CreatedDate,
               ModifiedBy,
               ModifiedDate)
	  SELECT 
			   pxtn.Customer_Name,
			   pxtn.Project_Name,
			   @ico_no,
               pxtn.Process_Name,
               pxtn.Component_Name,
               pxtn.Activity_Name,
               pxtn.UI_Name,
               pxtn.Page_BT_Synonym,
               pxtn.Section_BT_Synonym,
               pxtn.Control_ID,
               pxtn.View_Name,
               pxtn.ParameterName,
               pxtn.ParameterSequence,
               pxtn.MappedBTSynonym,
               pxtn.MappedField,
               @ctxt_user,
               @date,
               @ctxt_user,
               @date
	FROM	re_published_ui_grid_Extension AS pxtn WITH (NOLOCK),
	#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
    AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
    AND   b.ecr_no				=	@ecr_no
    AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   pxtn.Customer_Name	=	b.customer_name
	AND   pxtn.Project_Name		=	b.project_name
	AND   pxtn.Rcnno			=	b.ecr_no
	AND   pxtn.Process_Name		=	b.process_name
	AND   pxtn.Component_Name	=	b.component_name
	AND   pxtn.Activity_Name	=	b.activity_name
	AND   pxtn.UI_Name			=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM  de_ui_grid_Extension AS extn (NOLOCK)
			WHERE pxtn.Customer_Name		=	extn.Customer_Name
			AND	  pxtn.Project_Name			=	extn.Project_Name
			AND   pxtn.Process_Name			=	extn.Process_Name
			AND   pxtn.Component_Name		=	extn.Component_Name
			AND   pxtn.Activity_Name		=	extn.Activity_Name
			AND   pxtn.UI_Name				=	extn.UI_Name
			AND   pxtn.Page_BT_Synonym		=	extn.Page_BT_Synonym
			AND	  pxtn.Section_BT_Synonym	=	extn.Section_BT_Synonym
			AND	  pxtn.Control_ID			=	extn.Control_ID
			AND   pxtn.View_Name			=	extn.View_Name
			AND   pxtn.ParameterName		=	extn.ParameterName
			AND   pxtn.ParameterSequence	=	extn.ParameterSequence
			AND   pxtn.MappedBTSynonym		=	extn.MappedBTSynonym
			AND   pxtn.MappedField			=	extn.MappedField
		)


	-----Code added for TECH-60451 Ends
	
	--Code added for TECH-69624 
	DELETE cust
	FROM de_ui_control_customaction AS cust,
		#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
	AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
	AND   b.ecr_no				=	@ecr_no
	AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   cust.Customer_Name	=	b.customer_name
	AND   cust.Project_Name		=	b.project_name
	AND   cust.Process_Name		=	b.process_name
	AND   cust.Component_Name	=	b.component_name
	AND   cust.Activity_Name	=	b.activity_name
	AND   cust.ui_name			=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_control_customaction AS pcust(NOLOCK)
			WHERE pcust.Customer_Name			=	cust.Customer_Name
			AND   pcust.Project_Name			=	cust.Project_Name
			AND   pcust.Rcnno					=	@ecr_no
			AND   pcust.Process_Name			=	cust.Process_Name
			AND   pcust.Component_Name			=	cust.Component_Name
			AND   pcust.Activity_Name			=	cust.Activity_Name
			AND   pcust.UI_Name					=	cust.UI_Name
			AND   pcust.Page_BT_Synonym			=	cust.Page_BT_Synonym
		    AND	  pcust.Section_BT_Synonym		=	cust.Section_BT_Synonym
		    AND	  pcust.control_bt_synonym		=	cust.control_bt_synonym
			AND   pcust.ActionControlBTSynonym	=	cust.ActionControlBTSynonym )
			

		INSERT INTO de_ui_control_customaction (
				customer_name,
				project_name,
				req_no,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				control_bt_synonym,
				ActionControlBTSynonym,
				Control_ID,
				View_Name,
				ActionType,
				ActionSequence,
				IconClass,
				IconPosition,
				Width,
				ToolTip,
				ActionName,
				ActionDescription,
				ActionControlID,
				ActionViewName,
				Createdby,
				Createddate,
				Modifiedby,
				Modifieddate)
	  SELECT 
				pcust.Customer_Name,
				pcust.Project_Name,
				@ico_no,
				pcust.process_name,
				pcust.component_name,
				pcust.activity_name,
				pcust.ui_name,
				pcust.page_bt_synonym,
				pcust.section_bt_synonym,
				pcust.control_bt_synonym,
				pcust.ActionControlBTSynonym,
				pcust.Control_ID,
				pcust.View_Name,
				pcust.ActionType,
				pcust.ActionSequence,
				pcust.IconClass,
				pcust.IconPosition,
				pcust.Width,
				pcust.ToolTip,
				pcust.ActionName,
				pcust.ActionDescription,
				pcust.ActionControlID,
				pcust.ActionViewName,
				@ctxt_user,
				@date,
				@ctxt_user,
				@date
	FROM	re_published_ui_control_customaction AS pcust WITH (NOLOCK),
	#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
    AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
    AND   b.ecr_no				=	@ecr_no
    AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   pcust.Customer_Name	=	b.customer_name
	AND   pcust.Project_Name	=	b.project_name
	AND   pcust.Rcnno			=	b.ecr_no
	AND   pcust.Process_Name	=	b.process_name
	AND   pcust.Component_Name	=	b.component_name
	AND   pcust.Activity_Name	=	b.activity_name
	AND   pcust.UI_Name			=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM  de_ui_control_customaction AS cust (NOLOCK)
			WHERE pcust.Customer_Name			=	cust.Customer_Name
			AND   pcust.Project_Name			=	cust.Project_Name
			AND   pcust.Process_Name			=	cust.Process_Name
			AND   pcust.Component_Name			=	cust.Component_Name
			AND   pcust.Activity_Name			=	cust.Activity_Name
			AND   pcust.UI_Name					=	cust.UI_Name
			AND   pcust.Page_BT_Synonym			=	cust.Page_BT_Synonym
		    AND	  pcust.Section_BT_Synonym		=	cust.Section_BT_Synonym
		    AND	  pcust.control_bt_synonym		=	cust.control_bt_synonym
			AND   pcust.ActionControlBTSynonym	=	cust.ActionControlBTSynonym 
		)
	--Code added for TECH-69624 

	--Code added for TECH-70687 starts
	DELETE title
	FROM de_ui_section_titleaction AS title,
		#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
	AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
	AND   b.ecr_no				=	@ecr_no
	AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   title.Customer_Name	=	b.customer_name
	AND   title.Project_Name	=	b.project_name
	AND   title.Process_Name	=	b.process_name
	AND   title.Component_Name	=	b.component_name
	AND   title.Activity_Name	=	b.activity_name
	AND   title.ui_name			=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_section_titleaction AS ptitle(NOLOCK)
			WHERE ptitle.Customer_Name			=	title.Customer_Name
			AND   ptitle.Project_Name			=	title.Project_Name
			AND   ptitle.rcnno					=	@ecr_no
			AND   ptitle.Process_Name			=	title.Process_Name
			AND   ptitle.Component_Name			=	title.Component_Name
			AND   ptitle.Activity_Name			=	title.Activity_Name
			AND   ptitle.UI_Name				=	title.UI_Name
			AND   ptitle.Page_BT_Synonym		=	title.Page_BT_Synonym
		    AND	  ptitle.Section_BT_Synonym		=	title.Section_BT_Synonym
		    AND	  ptitle.TitleControlBTSynonym	=	title.TitleControlBTSynonym )
			

		INSERT INTO de_ui_section_titleaction (
				customer_name,
				project_name,
				ecrno,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_bt_synonym,
				section_bt_synonym,
				TitleControlBTSynonym,
				ActionType,
				ActionSequence,
				IconClass,
				IconPosition,
				Width,
				ToolTip,
				ActionName,
				ActionDescription,
				ActionControlID,
				ActionViewName,
				Createdby,
				Createddate,
				Modifiedby,
				Modifieddate,
				Titleaction)
	  SELECT 
				ptitle.Customer_Name,
				ptitle.Project_Name,
				@ico_no,
				ptitle.process_name,
				ptitle.component_name,
				ptitle.activity_name,
				ptitle.ui_name,
				ptitle.page_bt_synonym,
				ptitle.section_bt_synonym,
				ptitle.TitleControlBTSynonym,
				ptitle.ActionType,
				ptitle.ActionSequence,
				ptitle.IconClass,
				ptitle.IconPosition,
				ptitle.Width,
				ptitle.ToolTip,
				ptitle.ActionName,
				ptitle.ActionDescription,
				ptitle.ActionControlID,
				ptitle.ActionViewName,
				@ctxt_user,
				@date,
				@ctxt_user,
				@date,
				ptitle.Titleaction
	FROM	re_published_ui_section_titleaction AS ptitle WITH (NOLOCK),
	#de_rmt_ico_ui_tmp AS b
	WHERE b.customer_name		=	@customer_name
    AND   b.project_name		=	@project_name
	AND   b.ico_no				=	@ico_no
    AND   b.ecr_no				=	@ecr_no
    AND   b.process_name		=	@process_name_tmp
	AND   b.component_name		=	@component_name_tmp
	AND   ptitle.Customer_Name	=	b.customer_name
	AND   ptitle.Project_Name	=	b.project_name
	AND   ptitle.rcnno			=	b.ecr_no
	AND   ptitle.Process_Name	=	b.process_name
	AND   ptitle.Component_Name	=	b.component_name
	AND   ptitle.Activity_Name	=	b.activity_name
	AND   ptitle.UI_Name		=	b.ui_name
	AND NOT EXISTS (
			SELECT 's'
			FROM  de_ui_section_titleaction AS title (NOLOCK)
			WHERE ptitle.Customer_Name			=	title.Customer_Name
			AND   ptitle.Project_Name			=	title.Project_Name
			AND   ptitle.Process_Name			=	title.Process_Name
			AND   ptitle.Component_Name			=	title.Component_Name
			AND   ptitle.Activity_Name			=	title.Activity_Name
			AND   ptitle.UI_Name				=	title.UI_Name
			AND   ptitle.Page_BT_Synonym		=	title.Page_BT_Synonym
		    AND	  ptitle.Section_BT_Synonym		=	title.Section_BT_Synonym
			AND   ptitle.TitleControlBTSynonym	=	title.TitleControlBTSynonym )
	--Code added for TECH-70687 ends


	---13852 added on 13apr2020 Starts
	DELETE a
	FROM de_els_query_listedit_map a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customername = b.customer_name
		AND a.projectname = b.project_name
		AND a.processname = b.process_name
		AND a.componentname = b.component_name
		AND a.activityname = b.activity_name
		AND a.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_els_query_listedit_map c(NOLOCK)
			WHERE c.customername = a.customername
				AND c.projectname = a.projectname
				AND c.Rcnno = @ecr_no
				AND c.processname = a.processname
				AND c.componentname = a.componentname
				AND c.activityname = a.activityname
				AND c.uiname = a.uiname
				AND c.ListControlSynonym = a.ListControlSynonym
				AND	c.ListControlID = a.ListControlID
				AND	c.ListViewname	= a.ListViewname
				AND c.QueryID       = a.QueryID
				AND c.SearchIndex   = a.SearchIndex
				AND c.Pagesize      = a.Pagesize
			)

	


	Insert Into de_els_query_listedit_map(
	   customername,
       projectname,
	   Ecrno,
       processname,
       componentname,
       activityname,
       uiname,
       ListControlSynonym,
       ListControlID,
       ListViewname,
       QueryID,
       SearchIndex,
	   Pagesize,
       createdby,
       createddate,
       modifedby,
       modifieddate)
	Select m.customername,
           m.projectname,
		   @ico_no,
           m.processname,
           m.componentname,
           m.activityname,
           m.uiname,
           m.ListControlSynonym,
           m.ListControlID,
           m.ListViewname,
           m.QueryID,
           m.SearchIndex,
		   m.Pagesize,
           @ctxt_user,
           @date,
           @ctxt_user,
           @date
	From re_published_els_query_listedit_map m(nolock),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND m.customername = b.customer_name
		AND m.projectname = b.project_name
		AND m.Rcnno = b.ecr_no
		AND m.processname = b.process_name
		AND m.componentname = b.component_name
		AND m.activityname = b.activity_name
		AND m.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_els_query_listedit_map c(NOLOCK)
			WHERE m.customername = c.customername
				AND m.projectname = c.projectname
				AND m.processname = c.processname
				AND m.componentname = c.componentname
				AND m.activityname = c.activityname
				AND m.uiname = c.uiname
				AND m.ListControlSynonym = c.ListControlSynonym
				AND	m.ListControlID = c.ListControlID
				AND	m.ListViewname	= c.ListViewname
				AND m.QueryID       = c.QueryID
				AND m.SearchIndex   = c.SearchIndex
				AND m.Pagesize      = c.Pagesize
			)


	DELETE a
	FROM de_els_query_listedit_input a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customername = b.customer_name
		AND a.projectname = b.project_name
		AND a.processname = b.process_name
		AND a.componentname = b.component_name
		AND a.activityname = b.activity_name
		AND a.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_els_query_listedit_input c(NOLOCK)
			WHERE c.customername = a.customername
				AND c.projectname = a.projectname
				AND c.Rcnno = @ecr_no
				AND c.processname = a.processname
				AND c.componentname = a.componentname
				AND c.activityname = a.activityname
				AND c.uiname = a.uiname
				AND c.ListControlSynonym = a.ListControlSynonym
				AND	c.ListControlID = a.ListControlID
				AND	c.ListViewname	= a.ListViewname
				AND c.QueryID       = a.QueryID
				AND c.ParameterName   = a.ParameterName
				AND c.MappedSynonym      = a.MappedSynonym
				AND c.MappedControlID      = a.MappedControlID
				AND c.MappedViewName      = a.MappedViewName
			)

	


	Insert Into de_els_query_listedit_input(
	   customername,
       projectname,
	   Ecrno,
       processname,
       componentname,
       activityname,
       uiname,
       ListControlSynonym,
       ListControlID,
       ListViewname,
       QueryID,
       ParameterName,
	   MappedSynonym,
	   MappedControlID,
	   MappedViewName,
       createdby,
       createddate,
       modifedby,
       modifieddate)
	Select m.customername,
           m.projectname,
		   @ico_no,
           m.processname,
           m.componentname,
           m.activityname,
           m.uiname,
           m.ListControlSynonym,
           m.ListControlID,
           m.ListViewname,
           m.QueryID,
           m.ParameterName,
		   m.MappedSynonym,
		   m.MappedControlID,
		   m.MappedViewName,
           @ctxt_user,
           @date,
           @ctxt_user,
           @date
	From re_published_els_query_listedit_input m(nolock),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND m.customername = b.customer_name
		AND m.projectname = b.project_name
		AND m.Rcnno = b.ecr_no
		AND m.processname = b.process_name
		AND m.componentname = b.component_name
		AND m.activityname = b.activity_name
		AND m.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_els_query_listedit_input c(NOLOCK)
			WHERE m.customername = c.customername
				AND m.projectname = c.projectname
				AND m.processname = c.processname
				AND m.componentname = c.componentname
				AND m.activityname = c.activityname
				AND m.uiname = c.uiname
				AND m.ListControlSynonym = c.ListControlSynonym
				AND	m.ListControlID = c.ListControlID
				AND	m.ListViewname	= c.ListViewname
				AND m.QueryID       = c.QueryID
				AND m.ParameterName   = c.ParameterName
				AND m.MappedSynonym      = c.MappedSynonym
				AND m.MappedControlID      = c.MappedControlID
				AND m.MappedViewName      = c.MappedViewName
			)

	DELETE a
	FROM de_els_query_listedit_result a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customername = b.customer_name
		AND a.projectname = b.project_name
		AND a.processname = b.process_name
		AND a.componentname = b.component_name
		AND a.activityname = b.activity_name
		AND a.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_els_query_listedit_result c(NOLOCK)
			WHERE c.customername = a.customername
				AND c.projectname = a.projectname
				AND c.Rcnno = @ecr_no
				AND c.processname = a.processname
				AND c.componentname = a.componentname
				AND c.activityname = a.activityname
				AND c.uiname = a.uiname
				AND c.ListControlSynonym = a.ListControlSynonym
				AND	c.ListControlID = a.ListControlID
				AND	c.ListViewname	= a.ListViewname
				AND c.QueryID       = a.QueryID
				AND c.ResultColumnName  =	a.ResultColumnName
				AND c.MappedSynonym     =	a.MappedSynonym
				AND c.MappedControlID   =	a.MappedControlID
				AND c.MappedViewName    =	a.MappedViewName
				AND c.ParameterCaption  =	a.ParameterCaption
				AND c.Width				=	a.Width
				AND c.IsVisible			=	a.IsVisible
				AND c.seqno               =  a.seqno
			)

	


	Insert Into de_els_query_listedit_result(
	   customername,
       projectname,
	   Ecrno,
       processname,
       componentname,
       activityname,
       uiname,
       ListControlSynonym,
       ListControlID,
       ListViewname,
       QueryID,
       ResultColumnName,
	   MappedSynonym,
	   MappedControlID,
	   MappedViewName,
	   ParameterCaption,
	   Width,
	   IsVisible,
	   createdby,
       createddate,
       modifedby,
       modifieddate,
	   seqno)
	Select m.customername,
           m.projectname,
		   @ico_no,
           m.processname,
           m.componentname,
           m.activityname,
           m.uiname,
           m.ListControlSynonym,
           m.ListControlID,
           m.ListViewname,
           m.QueryID,
           m.ResultColumnName,
		   m.MappedSynonym,
		   m.MappedControlID,
		   m.MappedViewName,
		   m.ParameterCaption,
		   m.Width,
		   m.IsVisible,
           @ctxt_user,
           @date,
           @ctxt_user,
           @date,
		   m.seqno
	From re_published_els_query_listedit_result m(nolock),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND m.customername = b.customer_name
		AND m.projectname = b.project_name
		AND m.Rcnno = b.ecr_no
		AND m.processname = b.process_name
		AND m.componentname = b.component_name
		AND m.activityname = b.activity_name
		AND m.uiname = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_els_query_listedit_result c(NOLOCK)
			WHERE m.customername = c.customername
				AND m.projectname = c.projectname
				AND m.processname = c.processname
				AND m.componentname = c.componentname
				AND m.activityname = c.activityname
				AND m.uiname = c.uiname
				AND m.ListControlSynonym = c.ListControlSynonym
				AND	m.ListControlID = c.ListControlID
				AND	m.ListViewname	= c.ListViewname
				AND m.QueryID       = c.QueryID
				AND m.ResultColumnName   = c.ResultColumnName
				AND m.MappedSynonym      = c.MappedSynonym
				AND m.MappedControlID      = c.MappedControlID
				AND m.MappedViewName      = c.MappedViewName
				AND m.ParameterCaption      = c.ParameterCaption
				AND m.Width                 = c.Width
				AND m.IsVisible            = c.IsVisible
				AND m.seqno               =  c.seqno
			)


	---13852 added on 13apr2020 End

	---- Code Added for the Bug Id :PNR2.0_33960 - AccessKey Feature
	--update a set a.Accesskey = b.accesskey
	--from  de_ui_control a (nolock),
	--ep_ui_control_dtl b(nolock)
	--where  a.customer_name  = b.customer_name
	--and a.project_name  = b.project_name
	--and a.process_name  = b.process_name
	--and a.component_name = b.component_name
	--and a.activity_name  = b.activity_name
	--and a.ui_name  = b.ui_name
	--and a.page_bt_synonym = b.page_bt_synonym
	--and a.section_bt_synonym = b.section_bt_synonym
	--and a.control_bt_synonym = b.control_bt_synonym
	--and a.control_type  = b.control_type
	DELETE a
	FROM de_non_ui_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_non_ui_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	UPDATE a
	SET control_type = b.control_type,
		horder = b.horder,
		vorder = b.vorder,
		visisble_length = b.visisble_length,
		control_doc = b.control_doc,
		order_seq = b.order_seq,
		data_column_width = b.data_column_width,
		label_column_width = b.label_column_width,
		data_column_scalemode = b.data_column_scalemode,
		label_column_scalemode = b.label_column_scalemode,
		control_id = b.control_id,
		view_name = b.view_name,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_non_ui_control a(NOLOCK),
		re_published_non_ui_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym

	--and  (  isnull(a.control_type,'')   <> isnull(b.control_type,'')    or --shakthi
	--isnull(a.horder,0)     <> isnull(b.horder,0)     or
	--isnull(a.vorder,0)     <> isnull(b.vorder,0)     or
	--isnull(a.visisble_length,0)   <> isnull(b.visisble_length,0)   or
	--isnull(a.control_doc,'')   <> isnull(b.control_doc,'')    or
	--isnull(a.order_seq,0)    <> isnull(b.order_seq,0)    or
	--isnull(a.data_column_width,0)  <> isnull(b.data_column_width,0)  or
	--isnull(a.label_column_width,0)  <> isnull(b.label_column_width,0)  or
	--isnull(a.data_column_scalemode,'') <> isnull(b.data_column_scalemode,'')  or
	--isnull(a.label_column_scalemode,'') <> isnull(b.label_column_scalemode,'')  or
	--isnull(a.control_id,'')    <> isnull(b.control_id,'')    or
	--isnull(a.view_name,'')    <> isnull(b.view_name,''))
	INSERT INTO de_non_ui_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		ui_control_sysid,
		ui_section_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		order_seq,
		data_column_width,
		control_id,
		view_name,
		label_column_width,
		visisble_length,
		proto_tooltip,
		sample_data,
		control_doc,
		control_prefix,
		data_column_scalemode,
		label_column_scalemode
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		ui_control_sysid,
		ui_section_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		order_seq,
		data_column_width,
		control_id,
		view_name,
		label_column_width,
		visisble_length,
		proto_tooltip,
		sample_data,
		control_doc,
		control_prefix,
		data_column_scalemode,
		label_column_scalemode
	FROM re_published_non_ui_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_non_ui_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
			)

	---------------------------------------------------------------------------------------------
	-- 4.DE_UI_GRID
	DELETE a
	FROM de_ui_grid a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_grid b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE de_ui_grid
	SET column_type = c.column_type,
		column_no = c.column_no,
		visible_length = c.visible_length,
		col_doc = c.col_doc,
		control_id = c.control_id,
		view_name = c.view_name,
		proto_tooltip = c.proto_tooltip, --code added by kiruthika for bugid:PNR2.0_11392
		--code added for bugid:PNR2.0_33960 starts
		sample_data = c.sample_data,
		Set_User_Pref = c.Set_User_Pref,
		--code added for bugid:PNR2.0_33960 starts
		modifiedby = @ctxt_user,
		modifieddate = @date,
		default_required = c.default_required, --Code Modified for PNR2.0_30869,
		visible = c.visible,
		columnclass = c.columnclass,
		--ColumnHdrClass = c.ColumnHdrClass,
		Forcefit = c.Forcefit,
		TemplateID = c.TemplateID,
		iskey = c.iskey,
		Kyseq_no = c.Kyseq_no,
		TemplateCategory = c.TemplateCategory,
		TemplateSpecific = c.TemplateSpecific,
		Column_class_ext6 = c.Column_class_ext6,
		RowExpander = c.RowExpander,
		GridToForm = c.GridToForm,
		icon_position = c.icon_position,
		icon_class = c.icon_class,
		column_Transformas = c.column_Transformas -- added for GridToForm TECH-12776 
		,
		TreeColumn = c.TreeColumn, -- code added for defect id: TECH-20326
		sensitivedata = c.sensitivedata, -- Added for TECH-20897
		IsPlatform = c.IsPlatform,
		CompactView = c.CompactView,
	   	MoreEventEnabled=c.MoreEventEnabled,  --Added for the Defect ID TECH-45828
    	UpeSetFocusEnabled=c.UpeSetFocusEnabled,  --Added for the Defect ID TECH-45828
		IsExtension=c.IsExtension,    ---Code added for TECH-60451
		ExtensionOrder=c.ExtensionOrder, ---Code added for TECH-60451
		AssociateControl = c.AssociateControl --13639 on 22ndJuly2022
	FROM de_ui_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_ui_grid c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.page_bt_synonym = c.page_bt_synonym
		AND a.section_bt_synonym = c.section_bt_synonym
		AND a.control_bt_synonym = c.control_bt_synonym
		AND a.column_bt_synonym = c.column_bt_synonym

	--and  (isnull(a.column_type,'')      <>  isnull(c.column_type,'')  or shakthi
	--isnull(a.column_no,0)        <>  isnull(c.column_no,0)   or
	--isnull(a.visible_length,0)   <>  isnull(c.visible_length,0)  or
	--isnull(a.col_doc,'')          <>  isnull(c.col_doc,'')   or
	--isnull(a.control_id,'')   <>  isnull(c.control_id,'')   or
	--isnull(a.view_name,'')   <>  isnull(c.view_name,'')   or
	--isnull(a.default_required,'')   <>  isnull(c.default_required,'')   or   --Code Modified for PNR2.0_30869
	--isnull(a.proto_tooltip,'')  <>  isnull(c.proto_tooltip,'')--code added by kiruthika for bugid:PNR2.0_11420
	----code added for bugid:PNR2.0_33960 starts
	--or isnull(a.sample_data,'')   <> isnull(c.sample_data,'') --modified for PNR2.0_34150
	--or isnull(a.Set_User_Pref,'')   <> isnull(c.Set_User_Pref,'')) --modified for PNR2.0_34150
	----code added for bugid:PNR2.0_33960 ends
	INSERT INTO de_ui_grid (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		column_type,
		column_no,
		grid_sysid,
		ui_control_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		control_id,
		view_name,
		visible_length,
		proto_tooltip,
		sample_data,
		col_doc,
		column_prefix,
		ecrno,
		Set_User_Pref, -- code Added by Gopinath S for the Call ID PNR2.0_19480
		default_required,
		visible,
		ColumnClass --Code Modified for PNR2.0_30869
		,
		Forcefit,
		TemplateID,
		iskey,
		Kyseq_no,
		TemplateCategory,
		TemplateSpecific,
		RowExpander,
		GridToForm,
		icon_position,
		icon_class,
		TreeColumn,
		column_Transformas,
		sensitivedata,
		IsPlatform,
		CompactView,
		MoreEventEnabled,  --Added for the Defect ID TECH-45828
		UpeSetFocusEnabled,  --Added for the Defect ID TECH-45828
		IsExtension,    --Code added for TECH-60451
		ExtensionOrder, --Code added for TECH-60451
		AssociateControl	--13639 on 22ndjuly2022
		) -- Added for TECH-20897
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		column_type,
		column_no,
		grid_sysid,
		ui_control_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		control_id,
		view_name,
		visible_length,
		proto_tooltip,
		sample_data,
		col_doc,
		column_prefix,
		@ico_no,
		Set_User_Pref,
		default_required,
		visible,
		ColumnClass --Code Modified for PNR2.0_30869
		,
		Forcefit,
		TemplateID,
		iskey,
		Kyseq_no,
		TemplateCategory,
		TemplateSpecific,
		RowExpander,
		GridToForm,
		icon_position,
		icon_class,
		TreeColumn,
		column_Transformas,
		sensitivedata,
		IsPlatform,
		CompactView,
		MoreEventEnabled, --Added for the Defect ID TECH-45828
        UpeSetFocusEnabled, --Added for the Defect ID TECH-45828
		IsExtension,   --Code added for TECH-60451
		ExtensionOrder,  --Code added for TECH-60451
		AssociateControl	--13639 on 22ndJuly2022
	FROM re_published_ui_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_grid c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.column_bt_synonym = c.column_bt_synonym
			)

	---------------------------------------------------------------------------------------------
	--5.DE_TASK_CONTROL_MAP
	-- Code added by Gowrisankar for PNR2.0_14775 on 01-Aug-2007
	UPDATE a
	SET a.section_name = b.section_bt_synonym,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_task_control_map a(NOLOCK),
		re_published_ui_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_name = b.page_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.section_name <> b.section_bt_synonym

	UPDATE a
	SET a.section_name = b.section_bt_synonym,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_task_control_map a(NOLOCK),
		re_published_ui_grid b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_name = b.page_bt_synonym
		AND a.control_bt_synonym = b.column_bt_synonym
		AND a.section_name <> b.section_bt_synonym

	UPDATE a
	SET a.section_name = b.section_name, -- Modified by Sangeetha G for PNR2.0_14780
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_task_control_map a(NOLOCK),
		de_hidden_view b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_name = b.page_name
		AND a.control_bt_synonym = b.hidden_view_bt_synonym
		AND a.section_name <> b.section_name

	-- Code added by Gowrisankar for PNR2.0_14775 on 01-Aug-2007
	DELETE a
	FROM de_task_control_map a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_control c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_name
				AND c.section_bt_synonym = a.section_name
				AND c.control_bt_synonym = a.control_bt_synonym
			
			UNION
			
			SELECT 's'
			FROM de_ui_grid g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ui_name
				AND g.page_bt_synonym = a.page_name
				AND g.section_bt_synonym = a.section_name
				AND g.column_bt_synonym = a.control_bt_synonym
			)

	---------------------------------------------------------------------------------------------
	--7.DE_RADIO_BUTTON
	DELETE a
	FROM de_radio_button a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_radio_button c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.button_code = a.button_code
			)

	UPDATE a
	SET seq_no = b.seq_no,
		button_caption = b.button_caption,
		default_flag = b.default_flag,
		horder = b.horder,
		vorder = b.vorder,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_radio_button a(NOLOCK),
		re_published_radio_button b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.button_code = b.button_code

	--code commented for the Bug ID: PNR2.0_32748 starts
	--and  (  isnull(a.seq_no,0)   <> isnull(b.seq_no,0)   or
	--isnull(a.button_caption,'') <> isnull(b.button_caption,'') or
	--isnull(a.default_flag,'') <> isnull(b.default_flag,'') or
	--isnull(a.horder,0)   <> isnull(b.horder,0)   or
	--isnull(a.vorder,0)   <> isnull(b.vorder,0))
	--code commented for the Bug ID: PNR2.0_32748 ends
	INSERT INTO de_radio_button (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		button_code,
		seq_no,
		button_caption,
		default_flag,
		radio_button_sysid,
		ui_control_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		horder,
		vorder,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		button_code,
		seq_no,
		button_caption,
		default_flag,
		radio_button_sysid,
		ui_control_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		horder,
		vorder,
		@ico_no
	FROM re_published_radio_button a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_radio_button c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.button_code = a.button_code
			)

	DELETE a
	FROM de_radio_button_lng_extn a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_radio_button_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.button_code = a.button_code
			)

	UPDATE a
	SET seq_no = b.seq_no,
		button_caption = b.button_caption,
		default_flag = b.default_flag,
		horder = b.horder,
		vorder = b.vorder,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_radio_button_lng_extn a(NOLOCK),
		re_published_radio_button_lng_extn b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.button_code = b.button_code
		AND a.languageid = b.languageid

	--code commented for the Bug ID: PNR2.0_32811 starts
	--and  (  isnull(a.seq_no,0)   <> isnull(b.seq_no,0)   or
	--isnull(a.button_caption,'') <> isnull(b.button_caption,'') or
	--isnull(a.default_flag,'') <> isnull(b.default_flag,'') or
	--isnull(a.horder,0)   <> isnull(b.horder,0)   or
	--isnull(a.vorder,0)   <> isnull(b.vorder,0))
	--code commented for the Bug ID: PNR2.0_32811 ends
	INSERT INTO de_radio_button_lng_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		button_code,
		seq_no,
		button_caption,
		default_flag,
		radio_button_sysid,
		ui_control_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		horder,
		vorder,
		languageid,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		button_code,
		seq_no,
		button_caption,
		default_flag,
		radio_button_sysid,
		ui_control_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		horder,
		vorder,
		languageid,
		@ico_no
	FROM re_published_radio_button_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_radio_button_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.button_code = a.button_code
				AND c.languageid = a.languageid
			)

	---------------------------------------------------------------------------------------------
	--8. DE_ENUM_VALUE
	DELETE a
	FROM de_enum_value a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_enum_value c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.enum_code = a.enum_code
			)

	UPDATE a
	SET enum_caption = b.enum_caption,
		default_flag = b.default_flag,
		seq_no = b.seq_no,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_enum_value a(NOLOCK),
		re_published_enum_value b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.enum_code = b.enum_code

	--code commented for the Bug ID: PNR2.0_32748 starts
	--and  (  isnull(a.seq_no,0)    <> isnull(b.seq_no,0)   or
	--isnull(a.enum_caption,'')  <> isnull(b.enum_caption,'') or
	--isnull(a.default_flag,'')  <> isnull(b.default_flag,''))
	--code commented for the Bug ID: PNR2.0_32748 ends
	INSERT INTO de_enum_value (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		enum_code,
		enum_caption,
		default_flag,
		enum_value_sysid,
		ui_page_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		seq_no,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		enum_code,
		enum_caption,
		default_flag,
		enum_value_sysid,
		ui_page_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		seq_no,
		@ico_no
	FROM re_published_enum_value a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_enum_value c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.enum_code = a.enum_code
			)

	--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
	DELETE a
	FROM de_enum_value_lng_extn a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_enum_value_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.enum_code = a.enum_code
			)

	UPDATE a
	SET enum_caption = b.enum_caption,
		default_flag = b.default_flag,
		seq_no = b.seq_no,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_enum_value_lng_extn a(NOLOCK),
		re_published_enum_value_lng_extn b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.enum_code = b.enum_code
		AND a.languageid = b.languageid

	--code commented for the Bug ID: PNR2.0_32811 starts
	--and  ( isnull(a.seq_no,0)   <> isnull(b.seq_no,0)   or
	--isnull(a.enum_caption,'')  <> isnull(b.enum_caption,'') or
	--isnull(a.default_flag,'')  <> isnull(b.default_flag,''))
	--code commented for the Bug ID: PNR2.0_32811 ends
	INSERT INTO de_enum_value_lng_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		enum_code,
		enum_caption,
		default_flag,
		enum_value_sysid,
		ui_page_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		seq_no,
		languageid,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		enum_code,
		enum_caption,
		default_flag,
		enum_value_sysid,
		ui_page_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		seq_no,
		languageid,
		@ico_no
	FROM re_published_enum_value_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_enum_value_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.enum_code = a.enum_code
				AND c.languageid = a.languageid
			) --code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079

	---------------------------------------------------------------------------------------------
	--6.DE_HIDDEN_VIEW
	-- Code added by Gowrisankar for PNR2.0_14775 on 01-Aug-2007
	UPDATE a
	SET a.section_name = b.section_bt_synonym,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_hidden_view a(NOLOCK),
		re_published_ui_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_name = b.page_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.control_id = b.control_id
		AND a.section_name <> b.section_bt_synonym

	UPDATE a
	SET a.section_name = b.section_bt_synonym,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_hidden_view a(NOLOCK),
		re_published_ui_grid b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_name = b.page_bt_synonym
		AND a.control_bt_synonym = b.column_bt_synonym
		AND a.control_id = b.control_id
		AND a.section_name <> b.section_bt_synonym

	-- Code added by Gowrisankar for PNR2.0_14775 on 01-Aug-2007
	DELETE a
	FROM de_hidden_view a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		-- code modified for the bug id PNR2.0_4505 on 05 Nov 2005
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_control c(NOLOCK),
				es_comp_ctrl_type_mst B(NOLOCK)
			WHERE c.customer_name = b.customer_name
				AND c.project_name = b.project_name
				AND c.process_name = b.process_name
				AND c.component_name = b.component_name
				AND c.control_type = B.ctrl_type_name
				AND b.base_ctrl_type NOT IN (
					'link',
					'button',
					'line',
					'Label'
					)
				AND c.control_type NOT IN ('Label')
				AND c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.control_id = a.control_id
			-- code modified for the bug id PNR2.0_4505 on 05 Nov 2005
			
			UNION
			
			SELECT 's'
			FROM de_ui_grid g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ui_name
				AND g.page_bt_synonym = a.page_name
				AND g.column_bt_synonym = a.control_bt_synonym
				AND g.control_id = a.control_id
			)

	DELETE a
	FROM de_hidden_view a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND EXISTS (
			SELECT 's'
			FROM de_enum_value c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_name
				AND c.control_bt_synonym = a.control_bt_synonym
			
			UNION
			
			SELECT 's'
			FROM de_radio_button d(NOLOCK)
			WHERE d.customer_name = a.customer_name
				AND d.project_name = a.project_name
				AND d.process_name = a.process_name
				AND d.component_name = a.component_name
				AND d.activity_name = a.activity_name
				AND d.ui_name = a.ui_name
				AND d.page_bt_synonym = a.page_name
				AND d.control_bt_synonym = a.control_bt_synonym
			)

	-- code Added by Ganesh for the callid :: PNR2.0_3237 on 13/7/05
	DELETE a
	FROM de_hidden_view a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND EXISTS (
			SELECT 's'
			FROM de_ui_control c(NOLOCK),
				es_comp_ctrl_type_mst d(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND d.customer_name = c.customer_name
				AND d.project_name = c.project_name
				AND d.process_name = c.process_name
				AND d.component_name = c.component_name
				AND d.ctrl_type_name = c.control_type
				AND d.base_ctrl_type IN (
					'link',
					'button',
					'line',
					'Label'
					)
			)

	---------------------------------------------------------------------------------------------
	-- 9) DE_UI_TRAVERSAL
	DELETE a
	FROM de_ui_traversal a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_traversal c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.link_type = a.link_type
			)

	UPDATE a
	SET linked_component = b.linked_component,
		linked_activity = b.linked_activity,
		linked_ui = b.linked_ui,
		associated_ctrl_bt_synonym = b.associated_ctrl_bt_synonym,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		a.Width = b.WIdth,
		a.Height = b.Height,
		a.Toolbar_notreq = b.Toolbar_notreq,
		a.LinkLaunchType = b.LinkLaunchType
	FROM de_ui_traversal a(NOLOCK),
		re_published_ui_traversal b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.link_type = b.link_type

	--and  (  isnull(a.linked_component,'') <> isnull(b.linked_component,'') or --shakthi
	--isnull(a.linked_activity,'') <> isnull(b.linked_activity,'')  or
	--isnull(a.linked_ui,'')   <> isnull(b.linked_ui,''))
	--Code modification for PNR2.0_26335 starts
	INSERT INTO de_ui_traversal (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		link_type,
		treaversal_sysid,
		ui_page_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		linked_component,
		linked_activity,
		linked_ui,
		associated_ctrl_bt_synonym,
		ecrno,
		trvsl_seq,
		Width,
		Height,
		Toolbar_notreq,
		LinkLaunchType
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		link_type,
		treaversal_sysid,
		ui_page_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		linked_component,
		linked_activity,
		linked_ui,
		associated_ctrl_bt_synonym,
		@ico_no,
		trvsl_seq,
		Width,
		Height,
		Toolbar_notreq,
		LinkLaunchType
	--Code modification for PNR2.0_26335 ends
	FROM re_published_ui_traversal a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_traversal c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.link_type = a.link_type
			)

	---------------------------------------------------------------------------------------------
	-- 10) DE_ACTION
	DELETE a
	FROM de_action a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_action c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
			)

	UPDATE a
	SET task_descr = b.task_descr,
		task_seq = b.task_seq,
		task_pattern = b.task_pattern,
		primary_control_bts = b.primary_control_bts,
		task_type = b.task_type,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		a.task_confirm_msg = b.task_confirm_msg, -- Column added by Mohideen on Jun 15, 2006
		a.task_status_msg = b.task_status_msg, -- Column added by Mohideen on Nov 10, 2006
		-- Code added for the BugId PNR2.0_1790 Starts
		a.usageid = b.usageid,
		a.ddt_page_bt_synonym = b.ddt_page_bt_synonym,
		a.ddt_control_bt_synonym = b.ddt_control_bt_synonym,
		a.ddt_control_id = b.ddt_control_id,
		a.ddt_view_name = b.ddt_view_name,
		-- Code added for the BugId PNR2.0_1790 Ends
		-- Code added for the BugId PLF2.0_00961 starts
		a.PopUp_page_bt_synonym = b.PopUp_page_bt_synonym,
		a.PopUp_section = b.PopUp_section,
		a.PopUp_close = b.PopUp_close,
		-- Code added for the BugId PLF2.0_00961 Ends
		a.IsCallout = b.IsCallout,
		a.QR_sourceCtrl = b.QR_sourceCtrl,
		a.QR_targetCtrl = b.QR_targetCtrl,
		a.Barcode_sourceCtrl = b.Barcode_sourceCtrl,
		a.Barcode_targetCtrl = b.Barcode_targetCtrl,
		a.browse_control = b.browse_control,
		a.QR_sourceCtrl_Page = b.QR_sourceCtrl_Page,
		a.QR_targetCtrl_Page = b.QR_targetCtrl_Page,
		a.Barcode_sourceCtrl_Page = b.Barcode_sourceCtrl_Page,
		a.Barcode_targetCtrl_Page = b.Barcode_targetCtrl_Page,
		a.browse_control_Page = b.browse_control_Page,
		a.group_name = b.group_name,
		a.Buttonbar_primary_section = b.Buttonbar_primary_section,
		a.Popup_onclick_close = b.Popup_onclick_close,
		a.Autoupload = b.Autoupload,
		a.sectionlaunchtype = b.sectionlaunchtype,
		a.QuickTask = b.QuickTask -- Added for the Defect ID TECH-29822
		,
		a.SystemTaskType = b.SystemTaskType,
		a.Systemgenerated	=	b.Systemgenerated	--TECH-73216
	FROM de_action a(NOLOCK),
		re_published_action b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name

	--and  (
	--isnull(a.task_descr,'')   <> isnull(b.task_descr,'')   or --shakthi
	--isnull(a.task_seq,0)   <> isnull(b.task_seq,0)    or
	--isnull(a.task_pattern,'')  <> isnull(b.task_pattern,'')  or
	--isnull(a.primary_control_bts,'')<> isnull(b.primary_control_bts,'') or
	--isnull(a.task_type,'')   <> isnull( b.task_type,'') or
	--isnull(a.task_confirm_msg,'') <> isnull( b.task_confirm_msg,'') or
	--isnull(a.task_status_msg,'') <> isnull( b.task_status_msg,'') or
	---- Code added for the BugId PNR2.0_1790 Starts
	--isnull(a.usageid,'') <> isnull( b.usageid,'') or
	--isnull(a.ddt_page_bt_synonym,'') <> isnull( b.ddt_page_bt_synonym,'')   or
	--isnull(a.ddt_control_bt_synonym,'') <> isnull( b.ddt_control_bt_synonym,'') or
	--isnull(a.ddt_control_id,'') <> isnull( b.ddt_control_id,'')   or
	--isnull(a.ddt_view_name,'') <> isnull( b.ddt_view_name,'')
	---- Code added for the BugId PNR2.0_1790 Ends
	---- Code added for the BugId PLF2.0_00961 starts
	--or isnull(a.PopUp_page_bt_synonym,'') <> isnull(b.PopUp_page_bt_synonym,'')
	--or isnull(a.PopUp_section,'') <> isnull(b.PopUp_section,'')
	--or isnull(a.PopUp_close,'')   <> isnull(b.PopUp_close,''))
	---- Code added for the BugId PLF2.0_00961 Ends
	INSERT INTO de_action (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		primary_control_bts,
		task_sysid,
		ui_sysid,
		task_type,
		task_confirm_msg,
		task_status_msg,
		ecrno, -- Column added by Mohideen on Jun 15, 2006
		usageid,
		ddt_page_bt_synonym,
		ddt_control_bt_synonym,
		ddt_control_id,
		ddt_view_name, -- Columns added for the BugId PNR2.0_1790
		task_process_msg,
		PopUp_page_bt_synonym,
		PopUp_section,
		PopUp_close,
		iscallout --Column added  for PNR2.0_30869 ,PLF2.0_00234
		,
		QR_sourceCtrl,
		QR_targetCtrl,
		Barcode_sourceCtrl,
		Barcode_targetCtrl,
		browse_control,
		QR_sourceCtrl_Page,
		QR_targetCtrl_Page,
		Barcode_sourceCtrl_Page,
		Barcode_targetCtrl_Page,
		browse_control_Page,
		group_name,
		Buttonbar_primary_section,
		Popup_onclick_close,
		Autoupload,
		sectionlaunchtype,
		QuickTask,
		SystemTaskType,	-- Added for the Defect ID TECH-29822
		Systemgenerated	--TECH-73216
		) 
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		primary_control_bts,
		newid(),
		ui_sysid,
		task_type,
		a.task_confirm_msg,
		a.task_status_msg,
		@ico_no, -- Column added by Mohideen on Jun 15, 2006
		usageid,
		ddt_page_bt_synonym,
		ddt_control_bt_synonym,
		ddt_control_id,
		ddt_view_name, -- Columns added for the BugId PNR2.0_1790
		task_process_msg,
		PopUp_page_bt_synonym,
		PopUp_section,
		PopUp_close,
		iscallout --Column added  for PNR2.0_30869 ,PLF2.0_00234
		,
		QR_sourceCtrl,
		QR_targetCtrl,
		Barcode_sourceCtrl,
		Barcode_targetCtrl,
		browse_control,
		QR_sourceCtrl_Page,
		QR_targetCtrl_Page,
		Barcode_sourceCtrl_Page,
		Barcode_targetCtrl_Page,
		browse_control_Page,
		group_name,
		Buttonbar_primary_section,
		Popup_onclick_close,
		Autoupload,
		sectionlaunchtype,
		QuickTask,
		SystemTaskType, -- Added for the Defect ID TECH-29822
		Systemgenerated	--TECH-73216
	FROM re_published_action a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
			)

	---------------------------------------------------------------------------------------------
	-- code added by Ganesh for the callid :: PNR2.0_3386 on 01/08/05
	-- 10) DE_ACTION_LNG_EXTN
	DELETE a
	FROM de_action_lng_extn a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_action_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.languageid = a.languageid
			)

	UPDATE a
	SET task_descr = b.task_descr,
		task_seq = b.task_seq,
		task_pattern = b.task_pattern,
		primary_control_bts = b.primary_control_bts,
		task_type = b.task_type,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		a.task_confirm_msg = b.task_confirm_msg, -- Column added by Mohideen on Jun 15, 2006
		a.task_status_msg = b.task_status_msg, -- Column added by Mohideen on Nov 10, 2006
		a.task_process_msg = b.task_process_msg, --Code Modified for PNR2.0_30869
		-- Code added for the BugId PNR2.0_1790 Starts
		a.usageid = b.usageid,
		a.ddt_page_bt_synonym = b.ddt_page_bt_synonym,
		a.ddt_control_bt_synonym = b.ddt_control_bt_synonym,
		a.ddt_control_id = b.ddt_control_id,
		a.ddt_view_name = b.ddt_view_name,
		-- Code added for the BugId PNR2.0_1790 Ends
		-- Code added for the BugId PLF2.0_00961 starts
		a.PopUp_page_bt_synonym = b.PopUp_page_bt_synonym,
		a.PopUp_section = b.PopUp_section,
		a.PopUp_close = b.PopUp_close
		-- Code added for the BugId PLF2.0_00961 Ends
		,
		a.Iscallout = b.iscallout,
		a.QR_sourceCtrl = b.QR_sourceCtrl,
		a.QR_targetCtrl = b.QR_targetCtrl,
		a.Barcode_sourceCtrl = b.Barcode_sourceCtrl,
		a.Barcode_targetCtrl = b.Barcode_targetCtrl,
		a.browse_control = b.browse_control,
		a.QR_sourceCtrl_Page = b.QR_sourceCtrl_Page,
		a.QR_targetCtrl_Page = b.QR_targetCtrl_Page,
		a.Barcode_sourceCtrl_Page = b.Barcode_sourceCtrl_Page,
		a.Barcode_targetCtrl_Page = b.Barcode_targetCtrl_Page,
		a.browse_control_Page = b.browse_control_Page,
		a.group_name = b.group_name,
		a.Buttonbar_primary_section = b.Buttonbar_primary_section,
		a.Popup_onclick_close = b.Popup_onclick_close,
		a.Autoupload = b.Autoupload
	FROM de_action_lng_extn a(NOLOCK),
		re_published_action_lng_extn b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.languageid = b.languageid

	--and  ( isnull(a.task_descr,'')   <> isnull(b.task_descr,'')   or --shakthi
	--isnull(a.task_seq,0)    <> isnull(b.task_seq,0)    or
	--isnull(a.task_pattern,'')   <> isnull(b.task_pattern,'')  or
	--isnull(a.primary_control_bts,'') <> isnull(b.primary_control_bts,'') or
	--isnull(a.task_type,'')    <> isnull(b.task_type,'') or
	--isnull(a.task_confirm_msg,'')  <> isnull( b.task_confirm_msg,'') or
	--isnull(a.task_status_msg,'')  <> isnull( b.task_status_msg,'') or
	--isnull(a.task_process_msg,'')  <> isnull( b.task_process_msg,'') or    --Code Modified for PNR2.0_30869
	-- Code added for the BugId PNR2.0_1790 Starts
	--isnull(a.usageid,'') <> isnull( b.usageid,'') or
	--isnull(a.ddt_page_bt_synonym,'') <> isnull( b.ddt_page_bt_synonym,'')   or
	--isnull(a.ddt_control_bt_synonym,'') <> isnull( b.ddt_control_bt_synonym,'') or
	--isnull(a.ddt_control_id,'') <> isnull( b.ddt_control_id,'')   or
	--isnull(a.ddt_view_name,'') <> isnull( b.ddt_view_name,'')
	-- Code added for the BugId PNR2.0_1790 Ends
	-- Code added for the BugId PLF2.0_00961 starts
	--or isnull(a.PopUp_page_bt_synonym,'') <> isnull(b.PopUp_page_bt_synonym,'')
	--or isnull(a.PopUp_section,'') <> isnull(b.PopUp_section,'')
	--or isnull(a.PopUp_close,'')   <> isnull(b.PopUp_close,''))
	-- Code added for the BugId PLF2.0_00961 Ends
	INSERT INTO de_action_lng_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		languageid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		primary_control_bts,
		task_sysid,
		ui_sysid,
		task_type,
		task_confirm_msg,
		task_status_msg,
		ecrno, -- Column added by Mohideen on Jun 15, 2006
		usageid,
		ddt_page_bt_synonym,
		ddt_control_bt_synonym,
		ddt_control_id,
		ddt_view_name, -- Columns added for the BugId PNR2.0_1790
		task_process_msg,
		PopUp_page_bt_synonym,
		PopUp_section,
		PopUp_close,
		iscallout --Column added  for PNR2.0_30869 ,PLF2.0_00234
		,
		QR_sourceCtrl,
		QR_targetCtrl,
		Barcode_sourceCtrl,
		Barcode_targetCtrl,
		browse_control,
		QR_sourceCtrl_Page,
		QR_targetCtrl_Page,
		Barcode_sourceCtrl_Page,
		Barcode_targetCtrl_Page,
		browse_control_Page,
		group_name,
		Buttonbar_primary_section,
		Popup_onclick_close,
		Autoupload
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		languageid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		primary_control_bts,
		newid(),
		ui_sysid,
		task_type,
		a.task_confirm_msg,
		a.task_status_msg,
		@ico_no, -- Column added by Mohideen on Jun 15, 2006
		usageid,
		ddt_page_bt_synonym,
		ddt_control_bt_synonym,
		ddt_control_id,
		ddt_view_name, -- Columns added for the BugId PNR2.0_1790
		task_process_msg,
		PopUp_page_bt_synonym,
		PopUp_section,
		PopUp_close,
		Iscallout --Column added  for PNR2.0_30869 ,PLF2.0_00234
		,
		QR_sourceCtrl,
		QR_targetCtrl,
		Barcode_sourceCtrl,
		Barcode_targetCtrl,
		browse_control,
		QR_sourceCtrl_Page,
		QR_targetCtrl_Page,
		Barcode_sourceCtrl_Page,
		Barcode_targetCtrl_Page,
		browse_control_Page,
		group_name,
		Buttonbar_primary_section,
		Popup_onclick_close,
		Autoupload
	FROM re_published_action_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		-- code modified by Ganesh for the callid :: PNR2.0_3473 on 01/08/05
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action_lng_extn c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.languageid = a.languageid
			)

	--   code added for the Bug ID :: PNR2.0_12845
	UPDATE a
	SET a.task_descr = b.task_descr
	FROM de_action_lng_extn a(NOLOCK),
		re_published_action_lng_extn b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.task_name = b.task_name
		AND a.task_descr <> b.task_descr
		AND a.languageid = b.languageid

	--   code added for the Bug ID :: PNR2.0_12845
	--------------------------------------------------------------------------------------------
	-- 11.DE_ACTION_SECTION_MAP
	DELETE a
	FROM de_action_section_map a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_action_section_map c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.section_page_bt_synonym = a.section_page_bt_synonym
				AND c.task_name = a.task_name
				AND c.section_bt_synonym = a.section_bt_synonym
			)

	INSERT INTO de_action_section_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		section_page_bt_synonym,
		section_bt_synonym,
		task_section_sysid,
		task_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		section_page_bt_synonym,
		section_bt_synonym,
		task_section_sysid,
		task_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no
	FROM re_published_action_section_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action_section_map c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.section_page_bt_synonym = a.section_page_bt_synonym
				AND c.task_name = a.task_name
				AND c.section_bt_synonym = a.section_bt_synonym
			)

	---------------------------------------------------------------------------------------------
	--12.DE_FLOWBR
	DELETE a
	FROM de_flowbr a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_flowbr c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
			)

	UPDATE a
	SET flowbr_descr = b.flowbr_descr,
		flowbr_sequence = b.flowbr_sequence,
		map_flag = b.map_flag,
		control_id = b.control_id,
		view_name = b.view_name,
		event_name = b.event_name,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_flowbr a(NOLOCK),
		re_published_flowbr b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.flowbr_name = b.flowbr_name

	--and  (isnull(a.flowbr_descr,'') <> isnull(b.flowbr_descr,'')  or --shakthi
	--isnull(a.flowbr_sequence,0) <> isnull(b.flowbr_sequence,0)  or
	--isnull(a.map_flag,'')  <> isnull(b.map_flag,'')   or
	--isnull(a.control_id,'')  <> isnull(b.control_id,'')   or
	--isnull(a.view_name,'')  <> isnull(b.view_name,'')   or
	--isnull(a.event_name,'')  <> isnull(b.event_name,''))
	INSERT INTO de_flowbr (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		flowbr_descr,
		flowbr_sequence,
		flowbr_sysid,
		task_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		map_flag,
		control_id,
		view_name,
		event_name,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		flowbr_descr,
		flowbr_sequence,
		flowbr_sysid,
		task_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		map_flag,
		control_id,
		view_name,
		event_name,
		@ico_no
	FROM re_published_flowbr a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_flowbr c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
			)

	---------------------------------------------------------------------------------------------
	--13.DE_GLOSSARY
	UPDATE de_glossary
	SET bt_synonym_caption = a.bt_synonym_caption,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		ref_bt_synonym_name = a.ref_bt_synonym_name,
		bt_synonym_doc = a.bt_synonym_doc,
		synonym_status = a.synonym_status,
		singleinst_sample_data = a.singleinst_sample_data,
		multiinst_sample_data = a.multiinst_sample_data,
		IsGlance = a.IsGlance
	--PNR2.0_13677
	--    data_type    = a.data_type,--code modified for bugid:PNR2.0_10880
	--    length     = a.length,
	--    bt_name     = a.bt_name
	FROM re_published_glossary a,
		de_glossary b
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.bt_synonym_name = b.bt_synonym_name
		AND a.component_name = b.component_name
		AND a.process_name = b.process_name

	-- if it is not in de_glossary insert it
	INSERT INTO de_glossary (
		customer_name,
		project_name,
		bt_synonym_name,
		component_name,
		process_name,
		data_type,
		length,
		bt_synonym_caption,
		glossary_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ref_bt_synonym_name,
		bt_synonym_doc,
		bt_name,
		synonym_status,
		singleinst_sample_data,
		multiinst_sample_data,
		ecrno,
		IsGlance
		)
	SELECT a.customer_name,
		a.project_name,
		a.bt_synonym_name,
		a.component_name,
		a.process_name,
		a.data_type,
		a.length,
		a.bt_synonym_caption,
		a.glossary_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.ref_bt_synonym_name,
		a.bt_synonym_doc,
		a.bt_name,
		a.synonym_status,
		a.singleinst_sample_data,
		a.multiinst_sample_data,
		@ico_no,
		IsGlance
	FROM re_published_glossary a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND NOT EXISTS (
			SELECT 's'
			FROM de_glossary b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.bt_synonym_name = a.bt_synonym_name
			)

	---------------------------------------------------------------------------------------------
	-- Code commented due to EP/RE lng extn purge Starts by 11537
	/*
	--14.DE_GLOSSARY_LNG_EXTN
	UPDATE de_glossary_lng_extn
	SET bt_synonym_caption = a.bt_synonym_caption,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		ref_bt_synonym_name = a.ref_bt_synonym_name,
		bt_synonym_doc = a.bt_synonym_doc,
		synonym_status = a.synonym_status,
		singleinst_sample_data = a.singleinst_sample_data,
		multiinst_sample_data = a.multiinst_sample_data
	--PNR2.0_13677
	--    data_type    = a.data_type,--code modified for bugid:PNR2.0_10880
	--    length     = a.length,
	--    bt_name     = a.bt_name
	FROM	re_published_glossary_lng_extn a,
			de_glossary_lng_extn b
	WHERE a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.bt_synonym_name = b.bt_synonym_name
		AND a.component_name = b.component_name
		AND a.process_name = b.process_name
		AND a.languageid = b.languageid
		AND a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp

		*/
		-- Code commented due to EP/RE lng extn Ends Starts by 11537

	--INSERT INTO de_glossary_lng_extn (
	--	customer_name,
	--	project_name,
	--	bt_synonym_name,
	--	component_name,
	--	process_name,
	--	data_type,
	--	length,
	--	bt_synonym_caption,
	--	glossary_sysid,
	--	TIMESTAMP,
	--	createdby,
	--	createddate,
	--	modifiedby,
	--	modifieddate,
	--	ref_bt_synonym_name,
	--	bt_synonym_doc,
	--	bt_name,
	--	synonym_status,
	--	singleinst_sample_data,
	--	multiinst_sample_data,
	--	languageid,
	--	ecrno
	--	)
	--SELECT a.customer_name,
	--	a.project_name,
	--	a.bt_synonym_name,
	--	a.component_name,
	--	process_name,
	--	a.data_type,
	--	a.length,
	--	a.bt_synonym_caption,
	--	a.glossary_sysid,
	--	a.TIMESTAMP,
	--	@ctxt_user,
	--	@date,
	--	@ctxt_user,
	--	@date,
	--	a.ref_bt_synonym_name,
	--	a.bt_synonym_doc,
	--	a.bt_name,
	--	a.synonym_status,
	--	a.singleinst_sample_data,
	--	a.multiinst_sample_data,
	--	c.quick_code,
	--	@ico_no
	--FROM	de_glossary a(NOLOCK),
	--		ep_language_met c (nolock)
	--WHERE a.customer_name = @customer_name
	--	AND a.project_name = @project_name
	--	--AND a.ecr_no = @ecr_no
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp
	--	AND NOT EXISTS (
	--		SELECT 's'
	--		FROM de_glossary_lng_extn b(NOLOCK)
	--		WHERE b.customer_name = a.customer_name
	--			AND b.project_name = a.project_name
	--			AND b.process_name = a.process_name
	--			AND b.component_name = a.component_name
	--			AND b.bt_synonym_name = a.bt_synonym_name
	--			AND b.languageid = c.quick_code
	--		)


	--UPDATE de_glossary_lng_extn
	--SET bt_synonym_caption = a.bt_synonym_caption,
	--	modifiedby = @ctxt_user,
	--	modifieddate = @date,
	--	ref_bt_synonym_name = a.ref_bt_synonym_name,
	--	bt_synonym_doc = a.bt_synonym_doc,
	--	synonym_status = a.synonym_status,
	--	singleinst_sample_data = a.singleinst_sample_data,
	--	multiinst_sample_data = a.multiinst_sample_data
	--FROM	de_glossary a,
	--		de_glossary_lng_extn b
	--WHERE a.customer_name = b.customer_name
	--	AND a.project_name = b.project_name
	--	AND a.bt_synonym_name = b.bt_synonym_name
	--	AND a.component_name = b.component_name
	--	AND a.process_name = b.process_name
	--	AND b.languageid	= 1
	--	AND a.customer_name = @customer_name
	--	AND a.project_name = @project_name
	--	--AND a.ecr_no = @ecr_no
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp

	----------------------------------------------------------------------------------------------
	-- 15) DE_FLOWBR_RULE_MAP
	DELETE a
	FROM de_flowbr_rule_map a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_flowbr_rule_map c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.br_id = a.br_id
			)

	UPDATE a
	SET br_name = b.br_name,
		br_type = b.br_type,
		seq_no = b.seq_no,
		br_component_name = b.br_component_name,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_flowbr_rule_map a(NOLOCK),
		re_published_flowbr_rule_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.flowbr_name = b.flowbr_name
		AND a.br_id = b.br_id

	--and  (  isnull(a.br_name,'')   <> isnull(b.br_name,'') or --shakthi
	--isnull(a.br_type,'')   <> isnull(b.br_type,'') or
	--isnull(a.seq_no,0)    <> isnull(b.seq_no,0)  or
	--isnull(a.br_component_name,'') <> isnull(b.br_component_name,''))
	INSERT INTO de_flowbr_rule_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		br_id,
		br_name,
		br_type,
		seq_no,
		br_sysid,
		flowbr_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		br_component_name,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		br_id,
		br_name,
		br_type,
		seq_no,
		br_sysid,
		flowbr_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		br_component_name,
		@ico_no
	FROM re_published_flowbr_rule_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_flowbr_rule_map c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.br_id = a.br_id
			)

	---------------------------------------------------------------------------------------------
	-- 16) DE_FLOWBR_BR_ERROR
	DELETE a
	FROM de_flowbr_br_error a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_flowbr_br_error c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.br_id = a.br_id
				AND c.message_id = a.message_id
			)

	UPDATE a
	SET message_descr = b.message_descr,
		default_flag = b.default_flag,
		msg_severity = b.msg_severity,
		error_context = b.error_context,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_flowbr_br_error a(NOLOCK),
		re_published_flowbr_br_error b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.flowbr_name = b.flowbr_name
		AND a.br_id = b.br_id
		AND a.message_id = b.message_id
		AND (
			isnull(a.message_descr, '') <> isnull(b.message_descr, '')
			OR isnull(a.default_flag, '') <> isnull(b.default_flag, '')
			OR isnull(a.msg_severity, '') <> isnull(b.msg_severity, '')
			OR isnull(a.error_context, '') <> isnull(b.error_context, '')
			)

	INSERT INTO de_flowbr_br_error (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		br_id,
		message_id,
		message_descr,
		default_flag,
		msg_sysid,
		br_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		msg_severity,
		error_context,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		br_id,
		message_id,
		message_descr,
		default_flag,
		msg_sysid,
		br_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		msg_severity,
		error_context,
		@ico_no
	FROM re_published_flowbr_br_error a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_flowbr_br_error c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.br_id = a.br_id
				AND c.message_id = a.message_id
			)

	--------------------------------------------------------------------------------------------
	-- 17) DE_FLOWBR_COMBO
	DELETE a
	FROM de_flowbr_combo a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_flowbr_combo c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.combo_bt_synonym = a.combo_bt_synonym
				AND c.combo_page_name = a.combo_page_name
			)

	UPDATE a
	SET combo_page_name = b.combo_page_name,
		clear_tree_before_population = b.clear_tree_before_population,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_flowbr_combo a(NOLOCK),
		re_published_flowbr_combo b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.flowbr_name = b.flowbr_name
		AND a.combo_bt_synonym = b.combo_bt_synonym
		AND a.combo_page_name = b.combo_page_name
		AND (
			isnull(a.combo_page_name, '') <> isnull(b.combo_page_name, '')
			OR isnull(a.clear_tree_before_population, '') <> isnull(b.clear_tree_before_population, '')
			)

	INSERT INTO de_flowbr_combo (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		combo_bt_synonym,
		combo_sysid,
		flowbr_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		combo_page_name,
		clear_tree_before_population,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		task_name,
		flowbr_name,
		combo_bt_synonym,
		combo_sysid,
		flowbr_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		combo_page_name,
		clear_tree_before_population,
		@ico_no
	FROM re_published_flowbr_combo a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_flowbr_combo c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.task_name = a.task_name
				AND c.flowbr_name = a.flowbr_name
				AND c.combo_bt_synonym = a.combo_bt_synonym
				AND c.combo_page_name = a.combo_page_name
			)

	---------------------------------------------------------------------------------------------
	-- 23) DE_RESOLVED_LINK_DATAITEM
	DELETE a
	FROM de_resolved_link_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_resolved_link_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym --code modified by Sangeetha L for bugid:PNR2.0_6673
				AND c.publication_name = a.publication_name
				AND c.dataitemname = a.dataitemname
				AND c.subscription_name = a.subscription_name
				AND c.subscribed_bt_synonym = a.subscribed_bt_synonym
			
			UNION
			
			SELECT 's'
			FROM de_hidden_view d(NOLOCK)
			WHERE d.customer_name = a.customer_name
				AND d.project_name = a.project_name
				AND d.process_name = a.process_name
				AND d.component_name = a.component_name
				AND d.activity_name = a.activity_name
				AND d.ui_name = a.ui_name
				AND d.hidden_view_bt_synonym = a.subscribed_bt_synonym
			--code added by Sangeetha L for bugid:PNR2.0_5645
			
			UNION
			
			SELECT 's'
			FROM de_hidden_view d(NOLOCK)
			WHERE d.customer_name = a.customer_name
				AND d.project_name = a.project_name
				--and     d.process_name     =   a.process_name
				AND d.component_name = a.publication_comp_name
				AND d.activity_name = a.publication_act_name
				AND d.ui_name = a.publication_ui_name
				AND d.hidden_view_bt_synonym = a.published_bt_synonym
			)

	--code added by Sangeetha L for bugid:PNR2.0_5645
	-- code added by Ganesh for the callid :: PNR2.0_4277 on 18/10/05
	DELETE a
	FROM de_resolved_link_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_resolved_link c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
				AND c.publication_name = a.publication_name
			)

	UPDATE a
	SET publication_comp_name = b.publication_comp_name,
		publication_act_name = b.publication_act_name,
		publication_ui_name = b.publication_ui_name,
		published_bt_synonym = b.published_bt_synonym,
		subscribed_flow_direction = b.subscribed_flow_direction,
		published_flow_direction = b.published_flow_direction,
		subscribed_control_name = b.subscribed_control_name,
		subscribed_view_name = b.subscribed_view_name,
		published_control_name = b.published_control_name,
		published_view_name = b.published_view_name,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_resolved_link_dataitem a(NOLOCK),
		re_published_resolved_link_dataitem b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym --code modified by Sangeetha L for bugid:PNR2.0_6673
		AND a.publication_name = b.publication_name
		AND a.dataitemname = b.dataitemname
		AND a.subscription_name = b.subscription_name
		AND a.subscribed_bt_synonym = b.subscribed_bt_synonym

	--and  (isnull(a.publication_comp_name,'')  <> isnull(b.publication_comp_name,'') or --shakthi
	--isnull(a.publication_act_name,'')  <> isnull(b.publication_act_name,'')  or
	--isnull(a.publication_ui_name,'')  <> isnull(b.publication_ui_name,'')   or
	--isnull(a.published_bt_synonym,'')  <> isnull(b.published_bt_synonym,'')  or
	--isnull(a.subscribed_flow_direction,'') <> isnull(b.subscribed_flow_direction,'')  or
	--isnull(a.published_flow_direction,'') <> isnull(b.published_flow_direction,'') or
	--isnull(a.subscribed_control_name,'') <> isnull(b.subscribed_control_name,'')  or
	--isnull(a.subscribed_view_name,'')  <> isnull(b.subscribed_view_name,'')  or
	--isnull(a.published_control_name,'')  <> isnull(b.published_control_name,'')  or
	--isnull(a.published_view_name,'')  <> isnull(b.published_view_name,''))
	INSERT INTO de_resolved_link_dataitem (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		subscription_name,
		subscribed_bt_synonym,
		publication_comp_name,
		publication_act_name,
		publication_ui_name,
		publication_name,
		published_bt_synonym,
		subscribed_flow_direction,
		published_flow_direction,
		resolved_link_dataitem_sysid,
		resolved_link_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		subscribed_control_name,
		subscribed_view_name,
		published_control_name,
		published_view_name,
		dataitemname,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		subscription_name,
		subscribed_bt_synonym,
		publication_comp_name,
		publication_act_name,
		publication_ui_name,
		publication_name,
		published_bt_synonym,
		subscribed_flow_direction,
		published_flow_direction,
		resolved_link_dataitem_sysid,
		resolved_link_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		subscribed_control_name,
		subscribed_view_name,
		published_control_name,
		published_view_name,
		dataitemname,
		@ico_no
	FROM re_published_resolved_link_dataitem a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_resolved_link_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
				AND c.dataitemname = a.dataitemname
				AND c.subscription_name = a.subscription_name
				AND c.subscribed_bt_synonym = a.subscribed_bt_synonym
			)

	---------------------------------------------------------------------------------------------
	-- 22) DE_RESOLVED_LINK
	DELETE a
	FROM de_resolved_link a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_resolved_link c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
				AND c.publication_name = a.publication_name
			)

	UPDATE a
	SET publication_comp_name = b.publication_comp_name,
		publication_act_name = b.publication_act_name,
		publication_ui_name = b.publication_ui_name,
		post_task = b.post_task,
		post_linktask = b.post_linktask, --Code Modified for PNR2.0_30869
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_resolved_link a(NOLOCK),
		re_published_resolved_link b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.subscription_name = b.subscription_name
		AND a.publication_name = b.publication_name

	--and  ( isnull(a.publication_comp_name,'')  <> isnull(b.publication_comp_name,'') or --shakthi
	--isnull(a.publication_act_name,'')  <> isnull(b.publication_act_name,'') or
	--isnull(a.publication_ui_name,'')  <> isnull(b.publication_ui_name,'')  or
	----Code Modification for PNR2.0_30869 starts
	--isnull(a.post_task,'')     <> isnull(b.post_task,'')  or
	--isnull(a.post_linktask,'')     <> isnull(b.post_linktask,'')
	--)
	----Code Modification for PNR2.0_30869 ends
	INSERT INTO de_resolved_link (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		subscription_name,
		publication_comp_name,
		publication_act_name,
		publication_ui_name,
		publication_name,
		resolved_link_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		post_task,
		ecrno,
		post_linktask
		) --Code Modified for PNR2.0_30869
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		subscription_name,
		publication_comp_name,
		publication_act_name,
		publication_ui_name,
		publication_name,
		resolved_link_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		post_task,
		@ico_no,
		post_linktask --Code Modified for PNR2.0_30869
	FROM re_published_resolved_link a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_resolved_link c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
				AND c.publication_name = a.publication_name
			)

	----------------------------------------------------------------------------------------------
	-- 21) DE_PUBLICATION_DATAITEM
	DELETE a
	FROM de_publication_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_publication_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
				AND c.dataitemname = a.dataitemname
			--      union
			--code commented by Sangeetha L for bugid:PNR2.0_5645
			--       select 's'
			--       from de_hidden_view d (nolock)
			--       where d.customer_name      = a.customer_name
			--       and     d.project_name     =   a.project_name
			--       and     d.process_name     =   a.process_name
			--       and     d.component_name  =   a.component_name
			--       and     d.activity_name      =   a.activity_name
			--       and     d.ui_name            =   a.ui_name
			--       and  d.page_name    =  a.page_bt_synonym
			--       and  d.hidden_view_bt_synonym= a.dataitemname)
			--code commented by Sangeetha L for bugid:PNR2.0_5645
			--code added by Sangeetha L for bugid:PNR2.0_5645
			
			UNION
			
			SELECT 's'
			FROM de_resolved_link_dataitem d(NOLOCK)
			WHERE d.customer_name = a.customer_name
				AND d.project_name = a.project_name
				AND d.process_name = a.process_name
				AND d.publication_comp_name = a.component_name
				AND d.publication_act_name = a.activity_name
				AND d.publication_ui_name = a.ui_name
				AND d.publication_name = a.publication_name
				AND d.dataitemname = a.dataitemname
			)
		-- Code added by sangeetha G for PNR2.0_16185 starts
		AND NOT EXISTS (
			SELECT 's'
			FROM de_hidden_view e(NOLOCK)
			WHERE e.customer_name = a.customer_name
				AND e.project_name = a.project_name
				AND e.process_name = a.process_name
				AND e.component_name = a.component_name
				AND e.activity_name = a.activity_name
				AND e.ui_name = a.ui_name
				AND e.hidden_view_bt_synonym = a.published_bt_synonym
			)

	-- Code added by sangeetha G for PNR2.0_16185 ends
	--code added by Sangeetha L for bugid:PNR2.0_5645
	-- code added by Ganesh for the callid :: PNR2.0_4277 on 18/10/05
	DELETE a
	FROM de_publication_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_publication c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
			)

	UPDATE a
	SET published_flow_direction = b.published_flow_direction,
		published_control_name = b.published_control_name,
		published_view_name = b.published_view_name,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_publication_dataitem a(NOLOCK),
		re_published_publication_dataitem b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.publication_name = b.publication_name
		AND a.dataitemname = b.dataitemname

	--and  ( isnull(a.published_flow_direction,'')  <> isnull(b.published_flow_direction,'') or --shakthi
	--isnull(a.published_control_name,'')   <> isnull(b.published_control_name,'')  or
	--isnull(a.published_view_name,'')   <> isnull(b.published_view_name,''))
	INSERT INTO de_publication_dataitem (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		publication_name,
		published_bt_synonym,
		published_flow_direction,
		publication_dataitem_sysid,
		publication_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		published_control_name,
		published_view_name,
		dataitemname,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		publication_name,
		published_bt_synonym,
		published_flow_direction,
		publication_dataitem_sysid,
		publication_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		published_control_name,
		published_view_name,
		dataitemname,
		@ico_no
	FROM re_published_publication_dataitem a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_publication_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
				AND c.dataitemname = a.dataitemname
			)

	---------------------------------------------------------------------------------------------
	-- 20) DE_PUBLICATION
	DELETE a
	FROM de_publication a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_publication c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
			)

	UPDATE a
	SET publication_descr = b.publication_descr,
		publication_doc = b.publication_doc,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_publication a(NOLOCK),
		re_published_publication b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.publication_name = b.publication_name

	--and  (isnull(a.publication_descr,'')  <> isnull(b.publication_descr,'') or --shakthi
	--isnull(a.publication_doc,'')  <> isnull(b.publication_doc,''))
	INSERT INTO de_publication (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		publication_name,
		publication_descr,
		publication_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		publication_doc,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.publication_name,
		a.publication_descr,
		a.publication_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.publication_doc,
		@ico_no
	FROM re_published_publication a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_publication c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.publication_name = a.publication_name
			)

	-------------------------------------------------------------------------------------------------------------------------
	-- 19) DE_SUBSCRIPTION_DATAITEM
	DELETE a
	FROM de_subscription_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_subscription_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
				AND c.subscribed_bt_synonym = a.subscribed_bt_synonym
				AND c.page_bt_synonym = a.page_bt_synonym
			--code commented by Sangeetha L for bugid:PNR2.0_5645
			--       union
			--       select 's'
			--       from de_hidden_view d (nolock)
			--       where d.customer_name      = a.customer_name
			--       and     d.project_name     =   a.project_name
			--       and     d.process_name     =   a.process_name
			--       and     d.component_name  =   a.component_name
			--       and     d.activity_name =   a.activity_name
			--       and     d.ui_name            =   a.ui_name
			--       and  d.page_name    =  a.page_bt_synonym
			--       and  d.hidden_view_bt_synonym= a.subscribed_bt_synonym)
			--code commented by Sangeetha L for bugid:PNR2.0_5645
			--code added by Sangeetha L for bugid:PNR2.0_5645
			
			UNION
			
			SELECT 's'
			FROM de_resolved_link_dataitem d(NOLOCK)
			WHERE d.customer_name = a.customer_name
				AND d.project_name = a.project_name
				AND d.process_name = a.process_name
				AND d.component_name = a.component_name
				AND d.activity_name = a.activity_name
				AND d.ui_name = a.ui_name
				AND d.page_bt_synonym = a.page_bt_synonym
				AND d.subscription_name = a.subscription_name
				AND d.subscribed_bt_synonym = a.subscribed_bt_synonym
			)

	--code added by Sangeetha L for bugid:PNR2.0_5645
	-- code added by Ganesh for the callid :: PNR2.0_4277 on 18/10/05
	DELETE a
	FROM de_subscription_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_subscription c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
			)

	UPDATE a
	SET subscribed_flow_direction = b.subscribed_flow_direction,
		subscribed_control_name = b.subscribed_control_name,
		subscribed_view_name = b.subscribed_view_name,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		a.Qlik_dataitem = b.Qlik_dataitem
	FROM de_subscription_dataitem a(NOLOCK),
		re_published_subscription_dataitem b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.subscription_name = b.subscription_name
		AND a.subscribed_bt_synonym = b.subscribed_bt_synonym
		AND a.page_bt_synonym = b.page_bt_synonym

	--and  ( isnull(a.subscribed_flow_direction,'') <> isnull(b.subscribed_flow_direction,'') or --shakthi
	--isnull(a.subscribed_control_name,'') <> isnull(b.subscribed_control_name,'')  or
	--isnull(a.subscribed_view_name,'')  <> isnull(b.subscribed_view_name,''))
	INSERT INTO de_subscription_dataitem (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		subscription_name,
		subscribed_bt_synonym,
		subscribed_flow_direction,
		subscription_dataitem_sysid,
		subscription_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		subscribed_control_name,
		subscribed_view_name,
		Qlik_dataitem
		) --vwqlik_change
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		subscription_name,
		subscribed_bt_synonym,
		subscribed_flow_direction,
		subscription_dataitem_sysid,
		subscription_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		subscribed_control_name,
		subscribed_view_name,
		Qlik_dataitem --vwqlik change
	FROM re_published_subscription_dataitem a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_subscription_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
				AND c.subscribed_bt_synonym = a.subscribed_bt_synonym
				AND c.page_bt_synonym = a.page_bt_synonym
			)

	----------------------------------------------------------------------------------------------------------------------------
	-- 18) DE_SUBSCRIPTION
	DELETE a
	FROM de_subscription a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_subscription c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
			)

	UPDATE a
	SET page_bt_synonym = b.page_bt_synonym,
		subscription_descr = b.subscription_descr,
		control_bt_synonym = b.control_bt_synonym,
		link_type = b.link_type,
		sugg_publishing_comp_name = b.sugg_publishing_comp_name,
		sugg_publishing_act_name = b.sugg_publishing_act_name,
		sugg_publishing_ui_name = b.sugg_publishing_ui_name,
		subscription_doc = b.subscription_doc,
		post_task = b.post_task,
		post_linktask = b.post_linktask, --Code Modified for PNR2.0_30869
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_subscription a(NOLOCK),
		re_published_subscription b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.subscription_name = b.subscription_name

	--and  (isnull(a.page_bt_synonym,'')   <> isnull(b.page_bt_synonym,'')    or --shakthi
	--isnull(a.subscription_descr,'')   <> isnull(b.subscription_descr,'')   or
	--isnull(a.control_bt_synonym,'')   <> isnull(b.control_bt_synonym,'')   or
	--isnull(a.link_type,'')     <> isnull(b.link_type,'')     or
	--isnull(a.sugg_publishing_comp_name,'') <> isnull(b.sugg_publishing_comp_name,'') or
	--isnull(a.sugg_publishing_act_name,'') <> isnull(b.sugg_publishing_act_name,'') or
	--isnull(a.sugg_publishing_ui_name,'') <> isnull(b.sugg_publishing_ui_name,'')  or
	--isnull(a.subscription_doc,'')   <> isnull(b.subscription_doc,'')   or
	--Code Modification for PNR2.0_30869 starts
	--isnull(a.post_task,'')     <> isnull(b.post_task,'') or
	--isnull(a.post_linktask,'')     <> isnull(b.post_linktask,''))
	--Code Modification for PNR2.0_30869 ends
	INSERT INTO de_subscription (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		subscription_name,
		subscription_descr,
		control_bt_synonym,
		link_type,
		subscription_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		sugg_publishing_comp_name,
		sugg_publishing_act_name,
		sugg_publishing_ui_name,
		subscription_doc,
		post_task,
		post_linktask
		) --Code Modified for PNR2.0_30869
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		subscription_name,
		subscription_descr,
		control_bt_synonym,
		link_type,
		subscription_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		sugg_publishing_comp_name,
		sugg_publishing_act_name,
		sugg_publishing_ui_name,
		subscription_doc,
		post_task,
		post_linktask --Code Modified for PNR2.0_30869
	FROM re_published_subscription a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_subscription c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.subscription_name = a.subscription_name
			)

	-------------------------------------------------------------------------------------------------------------------------
	-- 24) DE_MESSAGE
	UPDATE de_message
	SET error_descr = a.error_descr,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		error_serverity = a.error_serverity
	FROM re_published_message a(NOLOCK),
		de_message b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.error_id = b.error_id

	INSERT INTO de_message (
		customer_name,
		project_name,
		process_name,
		component_name,
		error_id,
		error_descr,
		message_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		error_serverity
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.error_id,
		a.error_descr,
		a.message_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.error_serverity
	FROM re_published_message a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.ecr_no = @ecr_no
		AND NOT EXISTS (
			SELECT 's'
			FROM de_message b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.error_id = a.error_id
			)

	---------------------------------------------------------------------------------------------
	-- 25) DE_BUSINESS_RULE
	UPDATE de_business_rule
	SET br_descr = a.br_descr,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		br_doc = a.br_doc
	FROM re_published_business_rule a(NOLOCK),
		de_business_rule b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.component_name = b.component_name
		AND a.process_name = b.process_name
		AND a.br_name = b.br_name

	INSERT INTO de_business_rule (
		customer_name,
		project_name,
		process_name,
		component_name,
		br_name,
		br_descr,
		rule_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		br_doc
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.br_name,
		a.br_descr,
		newid(),
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.br_doc
	FROM re_published_business_rule a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.ecr_no = @ecr_no
		AND NOT EXISTS (
			SELECT 's'
			FROM de_business_rule b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.br_name = a.br_name
			)

	----------------------------------------------------------------------------------------------
	-- 26) DE_RULEGROUP
	UPDATE de_rulegroup
	SET brgroup_descr = a.brgroup_descr,
		exposed_flag = a.exposed_flag,
		ref_brgroup_name = a.ref_brgroup_name,
		brgroup_doc = a.brgroup_doc,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM re_published_rulegroup a(NOLOCK),
		de_rulegroup b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.component_name = b.component_name
		AND a.process_name = b.process_name
		AND a.brgroup_name = b.brgroup_name

	INSERT INTO de_rulegroup (
		customer_name,
		project_name,
		process_name,
		component_name,
		brgroup_name,
		brgroup_descr,
		exposed_flag,
		brgroup_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ref_brgroup_name,
		brgroup_doc
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.brgroup_name,
		a.brgroup_descr,
		a.exposed_flag,
		a.brgroup_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.ref_brgroup_name,
		a.brgroup_doc
	FROM re_published_rulegroup a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND NOT EXISTS (
			SELECT 's'
			FROM de_rulegroup b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.brgroup_name = a.brgroup_name
			)

	---------------------------------------------------------------------------------------------
	-- 27) DE_RULEGROUP_STEP
	DELETE a
	FROM de_rulegroup_step a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_rulegroup_step b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.brgroup_name = a.brgroup_name
				AND b.step_id = a.step_id
			)

	UPDATE de_rulegroup_step
	SET br_name = a.br_name,
		step_no = a.step_no,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM re_published_rulegroup_step a(NOLOCK),
		de_rulegroup_step b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.ecr_no = @ecr_no
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.component_name = b.component_name
		AND a.process_name = b.process_name
		AND a.brgroup_name = b.brgroup_name
		AND a.step_id = b.step_id

	INSERT INTO de_rulegroup_step (
		customer_name,
		project_name,
		process_name,
		component_name,
		brgroup_name,
		step_id,
		br_name,
		step_no,
		step_sysid,
		brgroup_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.brgroup_name,
		a.step_id,
		a.br_name,
		a.step_no,
		a.step_sysid,
		a.brgroup_sysid,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_rulegroup_step a(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.ecr_no = @ecr_no
		AND NOT EXISTS (
			SELECT 's'
			FROM de_rulegroup_step b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.brgroup_name = a.brgroup_name
				AND b.step_id = a.step_id
			)

	---------------------------------------------------------------------------------------------
	-- 28) DE_RULEGROUP_STEP_MSG
	DELETE a
	FROM de_rulegroup_step_msg a
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_rulegroup_step_msg b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.brgroup_name = a.brgroup_name
				AND b.step_id = a.step_id
				AND b.message_id = a.message_id
			)

	UPDATE a
	SET message_descr = b.message_descr,
		msg_severity = b.msg_severity,
		default_flag = b.default_flag,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_rulegroup_step_msg a(NOLOCK),
		re_published_rulegroup_step_msg b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.brgroup_name = a.brgroup_name
		AND b.step_id = a.step_id
		AND b.message_id = a.message_id

	--and ( isnull(a.message_descr,'')  <> isnull(b.message_descr,'') or --shakthi
	--isnull(a.msg_severity,'')  <> isnull(b.msg_severity,'') or
	--isnull(a.default_flag,'')  <> isnull(b.default_flag,''))
	INSERT INTO de_rulegroup_step_msg (
		customer_name,
		project_name,
		process_name,
		component_name,
		brgroup_name,
		step_id,
		message_id,
		message_descr,
		msg_severity,
		default_flag,
		msg_sysid,
		step_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT customer_name,
		project_name,
		process_name,
		component_name,
		brgroup_name,
		step_id,
		message_id,
		message_descr,
		msg_severity,
		default_flag,
		msg_sysid,
		step_sysid,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_rulegroup_step_msg a(NOLOCK)
	WHERE customer_name = @customer_name
		AND project_name = @project_name
		AND ecr_no = @ecr_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND NOT EXISTS (
			SELECT 's'
			FROM de_rulegroup_step_msg b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.brgroup_name = a.brgroup_name
				AND b.step_id = a.step_id
				AND b.message_id = a.message_id
			)

	---------------------------------------------------------------------------------------------
	-- de_tree_dtl added by Feroz
	DELETE a
	FROM de_tree_dtl a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tree_dtl b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_type = a.node_type
			)

	UPDATE a
	SET a.node_description = b.node_description,
		a.event_req = b.event_req,
		a.mapped_task = b.mapped_task,
		a.open_img_name = b.open_img_name,
		a.not_exp_img_name = b.not_exp_img_name,
		a.expendable_img_name = b.expendable_img_name,
		a.expended_img_name = b.expended_img_name,
		a.close_img_name = b.close_img_name,
		a.chkbox_chk_img = b.chkbox_chk_img,
		a.chkbox_unchk_img = b.chkbox_unchk_img,
		a.chkbox_parial_chkimg = b.chkbox_parial_chkimg,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.ExpandImageEvent = b.ExpandImageEvent
	FROM de_tree_dtl a(NOLOCK),
		re_published_tree_dtl b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.ecr_no = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.node_type = b.node_type

	--and  (isnull(a.node_description,'')  <>  isnull(b.node_description,'')  or --shakthi
	--isnull(a.event_req,'')    <> isnull(b.event_req,'')    or
	--isnull(a.mapped_task,'')   <> isnull(b.mapped_task,'')   or
	--isnull(a.open_img_name,'')   <> isnull(b.open_img_name,'')   or
	--isnull(a.not_exp_img_name,'')  <> isnull(b.not_exp_img_name,'')  or
	--isnull(a.expendable_img_name,'') <> isnull(b.expendable_img_name,'')or
	--isnull(a.expended_img_name,'')  <> isnull(b.expended_img_name,'')  or
	--isnull(a.close_img_name,'')   <> isnull(b.close_img_name,'')  or
	--isnull(a.chkbox_chk_img,'')   <> isnull(b.chkbox_chk_img,'')  or
	--isnull(a.chkbox_unchk_img,'')  <> isnull(b.chkbox_unchk_img,'')  or
	--isnull(a.chkbox_parial_chkimg,'') <> isnull(b.chkbox_parial_chkimg,'') )
	INSERT INTO de_tree_dtl (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		node_type,
		node_description,
		event_req,
		mapped_task,
		open_img_name,
		not_exp_img_name,
		expendable_img_name,
		expended_img_name,
		close_img_name,
		chkbox_chk_img,
		chkbox_unchk_img,
		chkbox_parial_chkimg,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ExpandImageEvent
		)
	SELECT DISTINCT /*PNR2.0_12828*/
		a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.node_type,
		a.node_description,
		a.event_req,
		a.mapped_task,
		a.open_img_name,
		a.not_exp_img_name,
		a.expendable_img_name,
		a.expended_img_name,
		a.close_img_name,
		a.chkbox_chk_img,
		a.chkbox_unchk_img,
		a.chkbox_parial_chkimg,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		ExpandImageEvent
	FROM re_published_tree_dtl a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.ecr_no = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tree_dtl b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_type = a.node_type
			)

	---------------------------------------------------------------------------------------------
	-- de_tree_sample_data added by Feroz
	DELETE a
	FROM de_tree_sample_data a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tree_sample_data b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_type = a.node_type
			)

	UPDATE a
	SET a.node_description = b.node_description,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_tree_sample_data a(NOLOCK),
		re_published_tree_sample_data b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.ecr_no = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.node_type = b.node_type
		AND isnull(a.node_description, '') <> isnull(b.node_description, '')

	INSERT INTO de_tree_sample_data (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		node_type,
		node_description,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		Node_id
		)
	SELECT DISTINCT /*PNR2.0_12828*/
		a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.node_type,
		a.node_description,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.Node_id
	FROM re_published_tree_sample_data a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.ecr_no = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tree_sample_data b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_type = a.node_type
			)

	---------------------------------------------------------------------------------------------
	-- de_tree_sample_data_map added by Feroz
	DELETE a
	FROM de_tree_sample_data_map a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tree_sample_data_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_id = a.node_id
				AND b.parent_node_id = a.parent_node_id
			)

	UPDATE a
	SET a.node_description = b.node_description,
		a.parent_node_descr = b.parent_node_descr,
		a.mapped_flag = b.mapped_flag,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_tree_sample_data_map a(NOLOCK),
		re_published_tree_sample_data_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.ecr_no = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.node_id = b.node_id
		AND a.parent_node_id = b.parent_node_id

	--and  (isnull(a.node_description,'') <>  isnull(b.node_description,'')  or --shakthi
	--isnull(a.parent_node_descr,'') <>  isnull(b.parent_node_descr,'')  or
	--isnull(a.mapped_flag,'')  <> isnull(b.mapped_flag,''))
	INSERT INTO de_tree_sample_data_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		node_id,
		parent_node_id,
		node_type,
		node_description,
		parent_node_type,
		parent_node_descr,
		mapped_flag,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.node_id,
		a.parent_node_id,
		a.node_type,
		a.node_description,
		a.parent_node_type,
		a.parent_node_descr,
		a.mapped_flag,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_tree_sample_data_map a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.ecr_no = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tree_sample_data_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.node_id = a.node_id
				AND b.parent_node_id = a.parent_node_id
			)

	---------------------------------------------------------------------------------------------
	--code added on 18-Aug-2006
	DELETE a
	-- code commented and modified by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010
	--from de_report_action_segment_dataitem a,
	FROM de_report_action_dataset_dataitem a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_report_action_dataset b(NOLOCK) --,
				--   de_report_action_segment    d (nolock),
				-- code commented and modified by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010
				-- de_report_action_dataset_segment   d (nolock), -- Modified by sangeetha for  PNR2.0_16143
				-- de_report_action_dataset    e (nolock)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				-- code commented and modified by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010
				AND b.dataset_name = a.dataset_name --a.segment_name
				-- and b.customer_name  = d.customer_name
				-- and b.project_name  = d.project_name
				-- and b.process_name  = d.process_name
				-- and b.component_name = d.component_name
				-- and b.activity_name  = d.activity_name
				-- and b.ui_name  = d.ui_name
				-- and b.action_name  = d.action_name
				-- and  b.dataset_name   = d.dataset_name  --code modified by kiruthika For bugid:PNR2.0_9944
				-- --column name modified by sangeetha for  PNR2.0_16152
				-- and b.customer_name  = e.customer_name
				-- and b.project_name  = e.project_name
				-- --and d.ecr_no  = @ecr_no
				-- and b.process_name  = e.process_name
				-- and b.component_name = e.component_name
				-- and b.activity_name  = e.activity_name
				-- and b.ui_name  = e.ui_name
				-- and b.action_name  = e.action_name
				-- and b.dataset_name  = e.dataset_name
				--
				-- and a.customer_name  = d.customer_name
				-- and a.project_name  = d.project_name
				-- and a.process_name  = d.process_name
				-- and a.component_name = d.component_name
				-- and a.activity_name  = d.activity_name
				-- and a.ui_name  = d.ui_name
				-- and a.action_name  = d.action_name
				-- and a.segment_name  = d.segment_name
				-- code commented and modified by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010
			)

	-- code added by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010 starts
	DELETE a
	FROM de_report_dataset_dataitem_map a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_report_action_dataset b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				AND b.dataset_name = a.dataset_name
			)

	-- code added by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010 ends
	DELETE a
	-- from de_report_action_segment a,    -- Modified by sangeetha for  PNR2.0_16143
	FROM de_report_action_dataset_segment a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_report_action_dataset b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				AND b.dataset_name = a.dataset_name --column name  modified by sangeetha for  PNR2.0_16152
			)

	-- code added by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010 starts
	DELETE a
	FROM de_report_dataset_segment_map a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_report_action_dataset b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				AND b.dataset_name = a.dataset_name
			)

	-- code added by Gowrisankar M for PNR2.0_26390 on 30-Mar-2010 ends
	-- de_report_action_dataset added by Feroz
	DELETE a
	FROM de_report_action_dataset a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_report_action_dataset b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				AND b.dataset_name = a.dataset_name
			)

	UPDATE a
	SET a.dataset_description = b.dataset_description,
		a.modifeidby = @ctxt_user,
		a.modifieddate = @date
	FROM de_report_action_dataset a(NOLOCK),
		re_published_report_action_dataset b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.ecr_no = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.action_name = b.action_name
		AND a.dataset_name = b.dataset_name
		AND isnull(a.dataset_description, '') <> isnull(b.dataset_description, '')

	INSERT INTO de_report_action_dataset (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		action_name,
		dataset_name,
		dataset_description,
		TIMESTAMP,
		createdby,
		createddate,
		modifeidby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.action_name,
		a.dataset_name,
		a.dataset_description,
		1,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_report_action_dataset a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.ecr_no = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_report_action_dataset b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.action_name = a.action_name
				AND b.dataset_name = a.dataset_name
			)

	---------------------------------------------------------------------------------------
	-- de_action_reuse_info added by Feroz
	DELETE a
	FROM de_action_reuse_info a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_action_reuse_info b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.task_name = a.task_name
				AND b.reuse_task = a.reuse_task
			)

	UPDATE a
	SET a.task_name = b.task_name,
		a.reuse_activity = b.reuse_activity,
		a.reuse_ui = b.reuse_ui,
		a.reuse_task = b.reuse_task,
		a.reuse_page = b.reuse_page,
		a.task_pattern = b.task_pattern,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date
	FROM de_action_reuse_info a(NOLOCK),
		re_published_action_reuse_info b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.process_name = c.process_name
		AND b.rcnno = c.ecr_no
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.task_name = b.task_name
		AND a.reuse_task = b.reuse_task

	--and  (isnull(a.task_name,'')   <> isnull(b.task_name,'') or --shakthi
	--isnull(a.reuse_activity,'')  <> isnull(b.reuse_activity,'') or
	--isnull(a.reuse_ui,'')   <> isnull(b.reuse_ui,'') or
	--isnull(a.reuse_task,'')   <> isnull(b.reuse_task,'') or
	--isnull(a.reuse_page,'')   <> isnull(b.reuse_page,'') or
	--isnull(a.task_pattern,'')  <> isnull(b.task_pattern,'') )
	INSERT INTO de_action_reuse_info (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		task_name,
		task_descr,
		task_seq,
		task_pattern,
		reuse_activity,
		reuse_ui,
		reuse_page,
		reuse_task,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		primary_control_bts,
		task_sysid,
		ui_sysid,
		task_type
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.task_name,
		a.task_descr,
		a.task_seq,
		a.task_pattern,
		a.reuse_activity,
		a.reuse_ui,
		a.reuse_page,
		a.reuse_task,
		1,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.primary_control_bts,
		a.task_sysid,
		a.ui_sysid,
		a.task_type
	FROM re_published_action_reuse_info a(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.rcnno = c.ecr_no
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action_reuse_info b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.task_name = a.task_name
				AND b.reuse_task = a.reuse_task
			)

	---------------------------------------------------------------------------------------------
	-- Added By feroz for 203_3 chart
	DELETE a
	FROM de_chart_header a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_chart_header (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		chart_type,
		chart_desc,
		chart_title,
		tooltip,
		datagrid,
		datagrid_type,
		legend_title,
		width,
		height,
		font,
		font_size,
		font_color,
		series_legend,
		background_color,
		graphicsmode,
		legend_font,
		legend_font_size,
		legend_font_color,
		x_axis_title,
		x_series_elements,
		x_error_band_type,
		x_error_marker_type,
		x_error_marker_size,
		x_error_marker_val,
		y_axis_title,
		x_auto_scale,
		x_divisions_min,
		x_divisions_max,
		x_units,
		x_cal_err_value,
		y_units,
		x_showvalue,
		X_showname,
		x_font,
		x_font_size,
		x_font_color,
		x_con_type,
		x_con_color,
		x_con_style,
		x_con_weight,
		x_con_wt_val,
		x_marker_type,
		x_marker_size,
		x_marker_color,
		x_marker_size_val,
		y_series_elements,
		y_error_band_type,
		y_error_marker_type,
		y_error_marker_size,
		y_error_marker_value,
		y_auto_scale,
		y_divisions_min,
		y_divisions_max,
		y_secondary_axis,
		y_cal_err_value,
		y_font,
		y_font_size,
		y_font_color,
		y_con_type,
		y_connector_color,
		y_connector_style,
		y_con_weight,
		y_con_wt_val,
		y_marker_type,
		y_marker_size,
		y_marker_color,
		y_marker_size_val,
		background_image,
		override_chart_type,
		x_show_err_band,
		y_show_err_band,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		x_numdivlines,
		y_numdivlines,
		canvas_color,
		divline_color
		) --Code Modified for the Bug ID: PNR2.0_34035
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.chart_type,
		a.chart_desc,
		a.chart_title,
		a.tooltip,
		a.datagrid,
		a.datagrid_type,
		a.legend_title,
		a.width,
		a.height,
		a.font,
		a.font_size,
		a.font_color,
		a.series_legend,
		a.background_color,
		a.graphicsmode,
		a.legend_font,
		a.legend_font_size,
		a.legend_font_color,
		a.x_axis_title,
		a.x_series_elements,
		a.x_error_band_type,
		a.x_error_marker_type,
		a.x_error_marker_size,
		a.x_error_marker_val,
		a.y_axis_title,
		a.x_auto_scale,
		a.x_divisions_min,
		a.x_divisions_max,
		a.x_units,
		a.x_cal_err_value,
		a.y_units,
		a.x_showvalue,
		a.X_showname,
		a.x_font,
		a.x_font_size,
		a.x_font_color,
		a.x_con_type,
		a.x_con_color,
		a.x_con_style,
		a.x_con_weight,
		a.x_con_wt_val,
		a.x_marker_type,
		a.x_marker_size,
		a.x_marker_color,
		a.x_marker_size_val,
		a.y_series_elements,
		a.y_error_band_type,
		a.y_error_marker_type,
		a.y_error_marker_size,
		a.y_error_marker_value,
		a.y_auto_scale,
		a.y_divisions_min,
		a.y_divisions_max,
		a.y_secondary_axis,
		a.y_cal_err_value,
		a.y_font,
		a.y_font_size,
		a.y_font_color,
		a.y_con_type,
		a.y_connector_color,
		a.y_connector_style,
		a.y_con_weight,
		a.y_con_wt_val,
		a.y_marker_type,
		a.y_marker_size,
		a.y_marker_color,
		a.y_marker_size_val,
		a.background_image,
		a.override_chart_type,
		a.x_show_err_band,
		a.y_show_err_band,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		x_numdivlines,
		y_numdivlines,
		canvas_color,
		divline_color --Code Modified for the Bug ID: PNR2.0_34035
	FROM re_published_chart_header a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name

	--------------------------------------------------------------------------------------------------
	DELETE a
	FROM de_chart_series a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_chart_series (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		axis_id,
		series_id,
		series_name,
		con_type,
		con_color,
		con_style,
		con_weight,
		con_wt_val,
		marker_type,
		marker_size,
		marker_size_val,
		mark_color,
		error_band_type,
		error_marker_type,
		error_marker_size,
		err_mark_size_val,
		auto_scale,
		divisions_min,
		divisions_max,
		units,
		x_showvalue,
		x_showname,
		sequence,
		y_secondary_axis,
		Y_Legend_Caption,
		cal_err_value,
		error_bands,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		chart_type
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.axis_id,
		a.series_id,
		a.series_name,
		a.con_type,
		a.con_color,
		a.con_style,
		a.con_weight,
		a.con_wt_val,
		a.marker_type,
		a.marker_size,
		a.marker_size_val,
		a.mark_color,
		a.error_band_type,
		a.error_marker_type,
		a.error_marker_size,
		a.err_mark_size_val,
		a.auto_scale,
		a.divisions_min,
		a.divisions_max,
		a.units,
		a.x_showvalue,
		a.x_showname,
		a.sequence,
		a.y_secondary_axis,
		a.Y_Legend_Caption,
		a.cal_err_value,
		a.error_bands,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.chart_type
	FROM re_published_chart_series a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name

	--------------------------------------------------------------------------------------------------
	DELETE a
	FROM de_chart_sample_data a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_chart_sample_data (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		x_series_data,
		y_series_id,
		y_value,
		y_error_value,
		tooltip_text,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.x_series_data,
		a.y_series_id,
		a.y_value,
		a.y_error_value,
		a.tooltip_text,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_chart_sample_data a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name

	----------------------------------------------------------------------------------------------------
	-- de_spin_control added by feroz
	DELETE a
	FROM de_spin_control a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_spin_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.spin_control_bt_synonym = a.spin_control_bt_synonym
			)

	UPDATE a
	SET control_type = b.control_type,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_spin_control a(NOLOCK),
		re_published_spin_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND b.spin_control_bt_synonym = a.spin_control_bt_synonym
		AND a.control_type <> b.control_type

	INSERT INTO de_spin_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		control_type,
		spin_control_bt_synonym,
		spincontrol_section,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		control_bt_synonym,
		control_type,
		spin_control_bt_synonym,
		spincontrol_section,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_spin_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_spin_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.spin_control_bt_synonym = c.spin_control_bt_synonym
			)

	--------------------------------------------------------------------------------------------------
	-- code added for state processing by feroz starts
	-- de_ui_state
	UPDATE a
	SET a.state_descr = b.state_descr,
		a.system_state = b.system_state,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state a(NOLOCK),
		re_published_ui_state b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		--Code Modified for bugId : PNR2.0_13656
		AND a.state_id = b.state_id
		AND (
			a.state_descr <> b.state_descr
			OR a.system_state <> b.system_state
			)

	INSERT INTO de_ui_state (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		state_id,
		state_descr,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		system_state
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.state_id,
		a.state_descr,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		system_state
	FROM re_published_ui_state a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.state_id = c.state_id
			)

	--------------------------------------------------------------------------------------------------
	-- de_ui_state_section
	UPDATE a
	SET a.collapse = b.collapse,
		a.visible = b.visible,
		a.enable = b.enable,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state_section a(NOLOCK),
		re_published_ui_state_section b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		--Code Modified for bugId : PNR2.0_13656
		AND a.state_id = b.state_id
		AND a.section_bt_synonym = b.section_bt_synonym
		AND (
			a.collapse <> b.collapse
			OR a.visible <> b.visible
			OR a.enable <> b.enable
			)

	INSERT INTO de_ui_state_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		section_bt_synonym,
		collapse,
		visible,
		enable,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.section_bt_synonym,
		a.collapse,
		a.visible,
		a.enable,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_state_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.state_id = c.state_id
			)

	--------------------------------------------------------------------------------------------------
	-- de_ui_state_control
	UPDATE a
	SET a.visible = b.visible,
		a.enable = b.enable,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state_control a(NOLOCK),
		re_published_ui_state_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		--Code Modified for bugId : PNR2.0_13656
		AND a.state_id = b.state_id
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym

	--and  ( a.visible  <> b.visible  or --shakthi
	--a.enable  <> b.enable )
	INSERT INTO de_ui_state_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		section_bt_synonym,
		control_bt_synonym,
		visible,
		enable,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.visible,
		a.enable,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_state_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.state_id = c.state_id
			)

	--------------------------------------------------------------------------------------------------
	-- de_ui_state_task
	UPDATE a
	SET a.rt_state = b.rt_state,
		a.focus_control = b.focus_control,
		a.state_id = b.state_id,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state_task a(NOLOCK),
		re_published_ui_state_task b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name

	--and  ( isnull(a.rt_state,'')   <> isnull(b.rt_state,'')  or --shakthi
	--isnull(a.focus_control,'') <> isnull(b.focus_control,'') or
	--isnull(a.state_id,'')   <> isnull(b.state_id,'') )
	INSERT INTO de_ui_state_task (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		task_name,
		rt_state,
		focus_control,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.task_name,
		a.rt_state,
		a.focus_control,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_state_task a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_task c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.task_name = c.task_name
			)

	--------------------------------------------------------------------------------------------------
	-- de_ui_state_task_mst
	UPDATE a
	SET a.task_descr = b.task_descr,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state_task_mst a(NOLOCK),
		re_published_ui_state_task_mst b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.task_descr <> b.task_descr

	INSERT INTO de_ui_state_task_mst (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		task_name,
		task_descr,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.task_name,
		a.task_descr,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_state_task_mst a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_task_mst c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.task_name = c.task_name
				AND a.state_id = c.state_id
			)

	-- Code added for the BugId PNR2.0_1790 Starts
	--de_ui_state_column table
	UPDATE a
	SET a.visible = b.visible,
		modifiedby = @ctxt_user,
		modifieddate = @date,
		a.enable = b.enable
	FROM de_ui_state_column a(NOLOCK),
		re_published_ui_state_column b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcn_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.column_bt_synonym = b.column_bt_synonym
		AND a.state_id = b.state_id -- Code added by Gowrisankar M for PNR2.0_22370 on 25-May-2009

	INSERT INTO de_ui_state_column (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		column_no,
		visible,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecr_no,
		enable
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.column_bt_synonym,
		a.column_no,
		a.visible,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ecr_no,
		a.enable
	FROM re_published_ui_state_column a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcn_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_column c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.column_bt_synonym = c.column_bt_synonym
				AND a.state_id = c.state_id
			)

	--de_ui_state_page table
	-- Code modification  for  PNR2.0_22275 starts
	UPDATE a
	SET a.visible = b.visible,
		a.enable = b.enable,
		a.focus = b.focus,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_state_page a(NOLOCK),
		re_published_ui_state_page b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcn_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym

	INSERT INTO de_ui_state_page (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		state_id,
		visible,
		enable,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecr_no,
		focus
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.state_id,
		a.visible,
		a.enable,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ecr_no,
		a.focus
	FROM re_published_ui_state_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcn_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_state_page c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.state_id = c.state_id
			)

	-- Code modification  for  PNR2.0_22275 ends
	-- Code added for the BugId PNR2.0_1790 Ends
	-- code added for state processing by feroz ends
	---------------------------------------------------------------------------------------------
	-----   Code added for the BugId : PLF2.0_13289    Starts      
	DELETE a
	FROM de_ezwiz_wizard a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_wizard c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
			)

	UPDATE a
	SET a.wizard_desc = b.wizard_desc,
		a.wizard_type = b.wizard_type,
		a.subscription_level = b.subscription_level,
		a.TIMESTAMP = b.TIMESTAMP,
		a.modified_by = @ctxt_user,
		a.modified_date = @date,
		a.wizard_code = b.wizard_code
	FROM de_ezwiz_wizard a(NOLOCK),
		re_published_ezwiz_wizard b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name

	INSERT INTO de_ezwiz_wizard (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		wizard_desc,
		wizard_type,
		subscription_level,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date,
		wizard_code
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		a.wizard_desc,
		a.wizard_type,
		a.subscription_level,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		wizard_code
	FROM re_published_ezwiz_wizard a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_wizard c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
			)

	DELETE a
	FROM de_ezwiz_wizard_local_info a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_wizard_local_info c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
				AND c.lang_id = a.lang_id
			)

	UPDATE a
	SET a.wizard_desc = b.wizard_desc,
		a.TIMESTAMP = b.TIMESTAMP,
		a.modified_by = @ctxt_user,
		a.modified_date = @date
	FROM de_ezwiz_wizard_local_info a(NOLOCK),
		re_published_ezwiz_wizard_local_info b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name
		AND a.lang_id = b.lang_id

	INSERT INTO de_ezwiz_wizard_local_info (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		lang_id,
		wizard_desc,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		a.lang_id,
		a.wizard_desc,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ezwiz_wizard_local_info a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_wizard_local_info c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
				AND a.lang_id = c.lang_id
			)

	DELETE a
	FROM de_ezwiz_wizard_step a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_wizard_step c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
				AND c.step_desc = a.step_desc
			)

	UPDATE a
	SET a.TIMESTAMP = b.TIMESTAMP,
		a.modified_by = @ctxt_user,
		a.modified_date = @date,
		a.subscription_level = b.subscription_level,
		a.target_ilboname = b.target_ilboname,
		a.target_activityname = b.target_activityname,
		a.target_componentname = b.target_componentname,
		a.step_seqno = b.step_seqno
	FROM de_ezwiz_wizard_step a(NOLOCK),
		re_published_ezwiz_wizard_step b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name
		AND a.step_desc = b.step_desc

	/*and	 a.step_seqno	=b.step_seqno
and	 a.target_ilboname	= b.target_ilboname
and  a.target_activityname = b.target_activityname
and  a.target_componentname = b.target_componentname*/
	INSERT INTO de_ezwiz_wizard_step (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		step_desc,
		step_seqno,
		target_ilboname,
		target_activityname,
		target_componentname,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date,
		subscription_level,
		target_ilbodesc,
		target_activitydesc,
		target_componentdesc
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		a.step_desc,
		a.step_seqno,
		a.target_ilboname,
		a.target_activityname,
		target_componentname,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		subscription_level,
		target_ilbodesc,
		target_activitydesc,
		target_componentdesc
	FROM re_published_ezwiz_wizard_step a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_wizard_step c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
				AND a.step_desc = c.step_desc
			)

	/*and	 a.step_seqno	=c.step_seqno
and	 a.target_ilboname	= c.target_ilboname
and  a.target_activityname = c.target_activityname
and  a.target_componentname = c.target_componentname*/
	DELETE a
	FROM de_ezwiz_wizard_step_local_info a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_wizard_step_local_info c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
				AND c.step_seqno = a.step_seqno
				AND c.lang_id = a.lang_id
			)

	UPDATE a
	SET a.TIMESTAMP = b.TIMESTAMP,
		a.step_desc = b.step_desc,
		a.modified_by = @ctxt_user,
		a.modified_date = @date
	FROM de_ezwiz_wizard_step_local_info a(NOLOCK),
		re_published_ezwiz_wizard_step_local_info b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name
		--and  a.step_desc	= b.step_desc
		AND a.step_seqno = b.step_seqno
		AND a.lang_id = b.lang_id

	INSERT INTO de_ezwiz_wizard_step_local_info (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		step_seqno,
		lang_id,
		step_desc,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		a.step_seqno,
		a.lang_id,
		a.step_desc,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ezwiz_wizard_step_local_info a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_wizard_step_local_info c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
				--and  a.step_desc	= c.step_desc
				AND a.step_seqno = c.step_seqno
				AND a.lang_id = c.lang_id
			)

	DELETE a
	FROM de_ezwiz_res_step_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_res_step_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
				AND c.parent_step_desc = A.parent_step_desc
				AND c.child_step_desc = a.child_step_desc
				AND c.parent_bt_synonym = a.parent_bt_synonym
				AND c.child_bt_synonym = a.child_bt_synonym
			)

	UPDATE a
	SET a.parent_step_seqno = b.parent_step_seqno,
		a.child_step_seqno = b.child_step_seqno,
		a.parent_controlid = b.parent_controlid,
		a.parent_viewname = b.parent_viewname,
		a.child_controlid = b.child_controlid,
		a.child_viewname = b.child_viewname,
		a.TIMESTAMP = b.TIMESTAMP,
		a.modified_by = @ctxt_user,
		a.modified_date = @date
	FROM de_ezwiz_res_step_dataitem a(NOLOCK),
		re_published_ezwiz_res_step_dataitem b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name
		AND a.parent_step_desc = b.parent_step_desc
		AND a.child_step_desc = b.child_step_desc
		AND a.parent_bt_synonym = b.parent_bt_synonym
		AND a.child_bt_synonym = b.child_bt_synonym

	/*and	 a.parent_controlid	= b.parent_controlid
and	 a.parent_viewname	=b.parent_viewname
and	 a.child_controlid	=b.child_controlid
and	 a.child_viewname =b.child_viewname*/
	INSERT INTO de_ezwiz_res_step_dataitem (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		parent_step_desc,
		child_step_desc,
		parent_bt_synonym,
		child_bt_synonym,
		parent_controlid,
		parent_viewname,
		child_controlid,
		child_viewname,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date,
		parent_step_seqno,
		child_step_seqno
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		a.parent_step_desc,
		child_step_desc,
		parent_bt_synonym,
		child_bt_synonym,
		parent_controlID,
		parent_viewname,
		child_controlID,
		child_viewname,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		parent_step_seqno,
		child_step_seqno
	FROM re_published_ezwiz_res_step_dataitem a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_res_step_dataitem c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
				AND a.parent_step_desc = c.parent_step_desc
				AND a.child_step_desc = c.child_step_desc
				AND a.parent_bt_synonym = c.parent_bt_synonym
				AND a.child_bt_synonym = c.child_bt_synonym
			)

	/*and	 a.parent_controlid	= c.parent_controlid
and	 a.parent_viewname	=c.parent_viewname
and	 a.child_controlid	=c.child_controlid
and	 a.child_viewname =c.child_viewname*/
	DELETE a
	FROM de_ezwiz_res_ilbo_dataitem a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezwiz_res_ilbo_dataitem c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.wizard_name = a.wizard_name
				AND a.parent_ilbo_desc = c.parent_ilbo_desc
				AND a.child_ilbo_desc = c.child_ilbo_desc
				AND a.parent_ilbo_name = c.parent_ilbo_name
				AND a.child_ilbo_name = c.child_ilbo_name
				AND a.parent_comp_desc = c.parent_comp_desc
				AND a.child_comp_desc = c.child_comp_desc
				AND a.parent_act_desc = c.parent_act_desc
				AND a.child_act_desc = c.child_act_desc
				AND a.parent_bt_synonym = c.parent_bt_synonym
				AND a.child_bt_synonym = c.child_bt_synonym
				AND a.parent_controlid = c.parent_controlid
				AND a.parent_viewname = c.parent_viewname
				AND a.child_controlid = c.child_controlid
				AND a.child_viewname = c.child_viewname
				AND a.step_desc = c.step_desc
			)

	UPDATE a
	SET a.step_seqno = b.step_seqno,
		a.TIMESTAMP = b.TIMESTAMP,
		a.modified_by = @ctxt_user,
		a.modified_date = @date
	FROM de_ezwiz_res_ilbo_dataitem a(NOLOCK),
		re_published_ezwiz_res_ilbo_dataitem b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.wizard_name = b.wizard_name
		AND a.parent_ilbo_desc = b.parent_ilbo_desc
		AND a.child_ilbo_desc = b.child_ilbo_desc
		AND a.parent_ilbo_name = b.parent_ilbo_name
		AND a.child_ilbo_name = b.child_ilbo_name
		AND a.parent_comp_desc = b.parent_comp_desc
		AND a.child_comp_desc = b.child_comp_desc
		AND a.parent_act_desc = b.parent_act_desc
		AND a.child_act_desc = b.child_act_desc
		AND a.parent_bt_synonym = b.parent_bt_synonym
		AND a.child_bt_synonym = b.child_bt_synonym
		AND a.parent_controlid = b.parent_controlid
		AND a.parent_viewname = b.parent_viewname
		AND a.child_controlid = b.child_controlid
		AND a.child_viewname = b.child_viewname
		AND a.step_desc = b.step_desc

	INSERT INTO de_ezwiz_res_ilbo_dataitem (
		customer_name,
		project_name,
		process_name,
		component_name,
		ecrno,
		wizard_name,
		parent_ilbo_desc,
		child_ilbo_desc,
		parent_ilbo_name,
		child_ilbo_name,
		parent_comp_desc,
		child_comp_desc,
		parent_act_desc,
		child_act_desc,
		parent_bt_synonym,
		child_bt_synonym,
		parent_controlid,
		parent_viewname,
		child_controlid,
		child_viewname,
		TIMESTAMP,
		created_by,
		created_date,
		modified_by,
		modified_date,
		step_seqno,
		step_desc
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		@ecr_no,
		a.wizard_name,
		parent_ilbo_desc,
		child_ilbo_desc,
		parent_ilbo_name,
		child_ilbo_name,
		parent_comp_desc,
		child_comp_desc,
		parent_act_desc,
		child_act_desc,
		parent_bt_synonym,
		child_bt_synonym,
		parent_controlID,
		parent_viewname,
		child_controlID,
		child_viewname,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		step_seqno,
		step_desc
	FROM re_published_ezwiz_res_ilbo_dataitem a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezwiz_res_ilbo_dataitem c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.wizard_name = c.wizard_name
				AND a.parent_ilbo_desc = c.parent_ilbo_desc
				AND a.child_ilbo_desc = c.child_ilbo_desc
				AND a.parent_ilbo_name = c.parent_ilbo_name
				AND a.child_ilbo_name = c.child_ilbo_name
				AND a.parent_comp_desc = c.parent_comp_desc
				AND a.child_comp_desc = c.child_comp_desc
				AND a.parent_act_desc = c.parent_act_desc
				AND a.child_act_desc = c.child_act_desc
				AND a.parent_bt_synonym = c.parent_bt_synonym
				AND a.child_bt_synonym = c.child_bt_synonym
				AND a.parent_controlid = c.parent_controlid
				AND a.parent_viewname = c.parent_viewname
				AND a.child_controlid = c.child_controlid
				AND a.child_viewname = c.child_viewname
				AND a.step_desc = c.step_desc
			)

	----   Code added for the BugId : PLF2.0_13289    Ends
	-- Code added for the BugId PNR2.0_1790 Starts
	-- code added for Ezee View Starts
	--de_ezeeview_sp table
	-- modified by bug id : PNR2.0_20589
	-- modified by feroz for bug id : PNR2.0_21027
	DELETE a
	FROM de_ezeeview_sp a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezeeview_sp b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.Link_ControlName = a.Link_ControlName
			)

	DELETE a
	FROM de_ezeeview_spparamlist a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ezeeview_spparamlist b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.Link_ControlName = a.Link_ControlName
				AND b.Mapped_Control = a.Mapped_Control
			)

	UPDATE a
	SET a.Target_SPName = b.Target_SPName,
		-- modified by feroz for bug id : PNR2.0_21027
		a.Link_Caption = b.Link_Caption,
		a.Linked_Component = b.Linked_Component,
		a.Linked_Activity = b.Linked_Activity,
		a.Linked_ui = b.Linked_ui,
		a.Linked_Task = b.Linked_Task,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ezeeview_sp a(NOLOCK),
		re_published_ezeeview_sp b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no -- modified by bug id : PNR2.0_20589
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.Link_ControlName = b.Link_ControlName

	INSERT INTO de_ezeeview_sp (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		Link_ControlName,
		Target_SPName,
		Link_Caption,
		Linked_Component,
		Linked_Activity,
		Linked_ui,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		Linked_Task
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.Link_ControlName,
		a.Target_SPName,
		a.Link_Caption,
		a.Linked_Component,
		a.Linked_Activity,
		a.Linked_ui,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		Linked_Task
	FROM re_published_ezeeview_sp a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no -- modified by bug id : PNR2.0_20589
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezeeview_sp c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.Link_ControlName = c.Link_ControlName -- Modified for bug id :PNR2.0_21050
			)

	UPDATE a
	SET a.Target_SPName = b.Target_SPName,
		a.ParameterName = b.ParameterName,
		a.Link_Caption = b.Link_Caption,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ezeeview_spparamlist a(NOLOCK),
		re_published_ezeeview_spparamlist b(NOLOCK), -- Commented for bug id :PNR2.0_21050
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no -- modified by bug id : PNR2.0_20589
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.Link_ControlName = b.Link_ControlName
		AND a.Mapped_Control = b.Mapped_Control

	INSERT INTO de_ezeeview_spparamlist (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		Link_ControlName,
		Target_SPName,
		ParameterName,
		Mapped_Control,
		Link_Caption,
		--code modified for the caseid :PNR2.0_24424 starts
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		control_page_name
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.Link_ControlName,
		a.Target_SPName,
		a.ParameterName,
		a.Mapped_Control,
		a.Link_Caption,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		control_page_name
	--code modified for the caseid :PNR2.0_24424 ends
	FROM re_published_ezeeview_spparamlist a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no -- modified by bug id : PNR2.0_20589
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ezeeview_spparamlist c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.Link_ControlName = c.Link_ControlName -- Modified for bug id :PNR2.0_21050
				AND a.Mapped_Control = c.Mapped_Control -- Modified for bug id :PNR2.0_21050
			)

	-- code added for Ezee View Ends
	-- modified by feroz for bug id : PNR2.0_21027
	DELETE a
	FROM de_ext_js_section a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ext_js_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.section_type = a.section_type
			)

	UPDATE a
	SET a.section_width = b.section_width,
		a.section_height = b.section_height,
		a.section_class = b.section_class,
		a.rvw_task = b.rvw_task,
		a.callout_task = b.callout_task,
		a.Direction = b.Direction,
		a.Scroll_Behaviour = b.Scroll_Behaviour,
		a.Scroll_Delay = b.Scroll_Delay,
		a.Fade_Delay = b.Fade_Delay,
		a.no_of_columns = b.no_of_columns,
		a.report_item_class = b.report_item_class,
		a.Property_Class = b.Property_Class,
		a.value_class = b.value_class,
		a.sample_data = b.sample_data,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.ecr_no = @ico_no
	FROM de_ext_js_section a(NOLOCK),
		re_published_ext_js_section b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.section_type = b.section_type

	INSERT INTO de_ext_js_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		section_type,
		Section_Width,
		Section_Height,
		Section_Class,
		RVW_Task,
		Callout_Task,
		Direction,
		Scroll_Behaviour,
		Scroll_Delay,
		Fade_Delay,
		No_Of_Columns,
		Report_Item_Class,
		Property_Class,
		Value_Class,
		sample_data,
		ecr_no,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		section_bt_synonym,
		section_type,
		Section_Width,
		Section_Height,
		Section_Class,
		RVW_Task,
		Callout_Task,
		Direction,
		Scroll_Behaviour,
		Scroll_Delay,
		Fade_Delay,
		No_Of_Columns,
		Report_Item_Class,
		Property_Class,
		Value_Class,
		sample_data,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ext_js_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ext_js_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.section_type = c.section_type
			)

	---------------------------------------------------------------------------------------------
	-- modified by feroz for bug id : PNR2.0_21027
	DELETE a
	FROM de_ext_js_control a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ext_js_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.feature_name = a.feature_name
			)

	UPDATE a
	SET a.Ctrl_height = b.Ctrl_height,
		a.ctrl_width = b.ctrl_width,
		a.Control_Class = b.Control_Class,
		a.rvw_task = b.rvw_task,
		a.callout_task = b.callout_task,
		a.Type_Delay = b.Type_Delay,
		a.Type_Direction = b.Type_Direction,
		a.Fade_Delay = b.Fade_Delay,
		a.Fade_Direction = b.Fade_Direction,
		a.loop_count = b.loop_count,
		a.sample_data = b.sample_data,
		a.Extjs_Ctrl_type = b.Extjs_Ctrl_type,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.ecr_no = @ico_no
	FROM de_ext_js_control a(NOLOCK),
		re_published_ext_js_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.feature_name = b.feature_name

	INSERT INTO de_ext_js_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		Extjs_Ctrl_type,
		Ctrl_height,
		ctrl_width,
		Control_Class,
		RVW_Task,
		Callout_Task,
		Type_Delay,
		Type_Direction,
		Fade_Delay,
		Fade_Direction,
		Loop_Count,
		sample_data,
		feature_name,
		ecr_no,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		Extjs_Ctrl_type,
		Ctrl_height,
		ctrl_width,
		Control_Class,
		RVW_Task,
		Callout_Task,
		Type_Delay,
		Type_Direction,
		Fade_Delay,
		Fade_Direction,
		Loop_Count,
		sample_data,
		feature_name,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ext_js_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ext_js_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.feature_name = c.feature_name
			)

	---------------------------------------------------------------------------------------------
	-- modified by feroz for bug id : PNR2.0_21027
	DELETE a
	FROM de_ext_js_section_column a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ext_js_section_column b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.section_type = a.section_type
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET a.column_sequence = b.column_sequence,
		a.is_key = b.is_key,
		a.datatype = b.datatype,
		a.grouping = b.grouping,
		a.grouping_function = b.grouping_function,
		a.grouping_synonym = b.grouping_synonym,
		a.rvw_task = b.rvw_task,
		a.callout_task = b.callout_task,
		a.label_class = b.label_class,
		a.control_class = b.control_class,
		a.sample_data = b.sample_data,
		a.modifiedby = @ctxt_user,
		a.modifieddate = @date,
		a.ecr_no = @ico_no,
		a.FieldList = b.FieldList,
		a.Default_Dragoption = b.Default_Dragoption,
		a.column_type = b.column_type,
		a.visible_length = b.visible_length,
		a.image_column = b.image_column
	FROM de_ext_js_section_column a(NOLOCK),
		re_published_ext_js_section_column b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.section_type = b.section_type
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.column_bt_synonym = b.column_bt_synonym

	INSERT INTO de_ext_js_section_column (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		section_type,
		control_bt_synonym,
		column_sequence,
		column_bt_synonym,
		is_key,
		datatype,
		grouping,
		grouping_function,
		grouping_synonym,
		rvw_task,
		callout_task,
		label_class,
		control_class,
		sample_data,
		ecr_no,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		FieldList,
		Default_Dragoption,
		column_type,
		pivot_sequence,
		visible_length,
		image_column
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		section_bt_synonym,
		section_type,
		control_bt_synonym,
		column_sequence,
		column_bt_synonym,
		is_key,
		datatype,
		grouping,
		grouping_function,
		grouping_synonym,
		rvw_task,
		callout_task,
		label_class,
		control_class,
		sample_data,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		FieldList,
		Default_Dragoption,
		column_type,
		pivot_sequence,
		visible_length,
		image_column
	FROM re_published_ext_js_section_column a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ext_js_section_column c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.section_type = c.section_type
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.column_bt_synonym = c.column_bt_synonym
			)

	-- Code added for the BugId PNR2.0_1790 Ends
	---------------------------------------------------------------------------------------------
	--For task control attribute map handling
	DELETE a
	FROM de_task_control_attributemap a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_control c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				--and  c.page_bt_synonym  = a.page_name
				--and  c.section_bt_synonym = a.section_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.control_id = a.control_id
				AND c.view_name = a.view_name
			
			UNION
			
			SELECT 'K'
			FROM de_ui_grid g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ui_name
				--and  g.page_bt_synonym  = a.page_name
				--and  g.section_bt_synonym = a.section_name
				AND g.column_bt_synonym = a.control_bt_synonym
				AND g.control_id = a.control_id
				AND g.view_name = a.view_name
			
			UNION
			
			SELECT 'K'
			FROM de_ui_page c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.control_bt_synonym
			
			UNION
			
			SELECT 'K'
			FROM de_ui_section g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ui_name
				--and  g.page_bt_synonym  = a.page_name
				AND g.section_bt_synonym = a.control_bt_synonym
			)

	DELETE a
	FROM de_fw_des_ilbo_service_view_attributemap a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ilbocode = b.ui_name --madhan
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_control c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ilbocode
				--and  c.page_bt_synonym  = a.page_name
				--and  c.section_bt_synonym = a.section_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.control_id = a.controlid
				AND c.view_name = a.viewname
			
			UNION
			
			SELECT 'K'
			FROM de_ui_grid g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ilbocode
				--and  g.page_bt_synonym  = a.page_name
				-- and  g.section_bt_synonym = a.section_name
				AND g.column_bt_synonym = a.control_bt_synonym
				AND g.control_id = a.controlid
				AND g.view_name = a.viewname
			
			UNION
			
			SELECT 'K'
			FROM de_ui_page c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ilbocode
				AND c.page_bt_synonym = a.control_bt_synonym
			
			UNION
			
			SELECT 'K'
			FROM de_ui_section g(NOLOCK)
			WHERE g.customer_name = a.customer_name
				AND g.project_name = a.project_name
				AND g.process_name = a.process_name
				AND g.component_name = a.component_name
				AND g.activity_name = a.activity_name
				AND g.ui_name = a.ilbocode
				--and  g.page_bt_synonym  = a.page_bt_synonym
				--and  g.section_bt_synonym = a.section_name
				AND g.section_bt_synonym = a.control_bt_synonym
			)

	--For task control attribute map handling ends 
	-- code added by feroz for listedit -- start
	DELETE a
	FROM de_listedit_column a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_listedit_column b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.listedit_synonym = a.listedit_synonym
				AND b.listedit_column_synonym = a.listedit_column_synonym
			)

	UPDATE a
	SET a.listedit_column_seqno = b.listedit_column_seqno,
		a.listedit_controlid = b.listedit_controlid,
		a.listedit_viewname = b.listedit_viewname,
		a.column_prefix = b.column_prefix
	FROM de_listedit_column a(NOLOCK),
		re_published_listedit_column b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.listedit_synonym = b.listedit_synonym
		AND a.listedit_column_synonym = b.listedit_column_synonym

	INSERT INTO de_listedit_column (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		listedit_synonym,
		listedit_column_synonym,
		listedit_column_seqno,
		listedit_controlid,
		listedit_viewname,
		ecrno,
		column_prefix,
		createdby,
		createddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		listedit_synonym,
		listedit_column_synonym,
		listedit_column_seqno,
		listedit_controlid,
		listedit_viewname,
		@ico_no,
		column_prefix,
		@ctxt_user,
		@date
	FROM re_published_listedit_column a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_listedit_column c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.listedit_synonym = c.listedit_synonym
				AND a.listedit_column_synonym = c.listedit_column_synonym
			)

	-- de_listedit_control_map
	DELETE a
	FROM de_listedit_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_listedit_control_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.mapped_bt_synonym = a.mapped_bt_synonym
				AND b.listedit_synonym = a.listedit_synonym
			)

	-- Modified By feroz for bug id :PNR2.0_23463
	UPDATE a
	SET a.listedit_controlid = b.listedit_controlid,
		a.listedit_viewname = b.listedit_viewname
	FROM de_listedit_control_map a(NOLOCK),
		re_published_listedit_control_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.mapped_bt_synonym = b.mapped_bt_synonym
		AND a.listedit_synonym = b.listedit_synonym

	-- Modified By feroz for bug id :PNR2.0_23463
	INSERT INTO de_listedit_control_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		mapped_bt_synonym,
		listedit_synonym,
		ecrno,
		control_id,
		view_name,
		createdby,
		createddate,
		listedit_controlid,
		listedit_viewname
		) -- Modified By feroz for bug id :PNR2.0_23463
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		mapped_bt_synonym,
		listedit_synonym,
		@ico_no,
		control_id,
		view_name,
		@ctxt_user,
		@date,
		listedit_controlid,
		listedit_viewname -- Modified By feroz for bug id :PNR2.0_23463
	FROM re_published_listedit_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_listedit_control_map c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.mapped_bt_synonym = c.mapped_bt_synonym
				AND a.listedit_synonym = c.listedit_synonym
			)

	-- de_resolvelist_data_map
	DELETE a
	FROM de_resolvelist_data_map a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_resolvelist_data_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.mapped_bt_syn_page = a.mapped_bt_syn_page --Modified for  PNR2.0_26701
				AND b.mapped_bt_synonym = a.mapped_bt_synonym
				AND b.listedit_synonym = a.listedit_synonym
				AND b.listedit_column_synonym = a.listedit_column_synonym
				AND b.data_mapped_synonym = a.data_mapped_synonym
			)

	UPDATE a
	SET a.control_id = b.control_id,
		a.view_name = b.view_name,
		a.data_mapped_synonym = b.data_mapped_synonym,
		a.page_bt_synonym = b.page_bt_synonym,
		a.section_bt_synonym = b.section_bt_synonym,
		a.list_index_search = b.list_index_search,
		a.primary_search_column = b.primary_search_column,
		a.visible = b.visible
	FROM de_resolvelist_data_map a(NOLOCK),
		re_published_resolvelist_data_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.mapped_bt_syn_page = b.mapped_bt_syn_page --Modified for  PNR2.0_26701
		AND a.mapped_bt_synonym = b.mapped_bt_synonym
		AND a.listedit_synonym = b.listedit_synonym
		AND a.listedit_column_synonym = b.listedit_column_synonym

	-- Modification for the defect id: TECH-16126
	INSERT INTO de_resolvelist_data_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		listedit_synonym,
		mapped_bt_synonym,
		listedit_column_synonym,
		data_mapped_synonym,
		primary_search_column,
		list_index_search,
		control_id,
		view_name,
		visible,
		ecrno,
		createdby,
		createddate,
		mapped_bt_syn_page,
		map_listdata
		) --Modified for  PNR2.0_26701
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		listedit_synonym,
		mapped_bt_synonym,
		listedit_column_synonym,
		data_mapped_synonym,
		primary_search_column,
		list_index_search,
		control_id,
		view_name,
		visible,
		@ico_no,
		@ctxt_user,
		@date,
		mapped_bt_syn_page,
		map_listdata --Modified for  PNR2.0_26701
	FROM re_published_resolvelist_data_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_resolvelist_data_map c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.mapped_bt_syn_page = c.mapped_bt_syn_page
				AND a.mapped_bt_synonym = c.mapped_bt_synonym
				AND a.listedit_synonym = c.listedit_synonym
				AND a.listedit_column_synonym = c.listedit_column_synonym
				AND a.data_mapped_synonym = c.data_mapped_synonym
			)

	-- Modification for the defect id: TECH-16126
	----code added by kiruthika for bugid:PLF2.0_03710
	------- For combolink de_ui_combolink
	DELETE a
	FROM de_ui_combolink a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_combolink b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.Combo_control_bt_synonym = a.Combo_control_bt_synonym
				AND b.link_control_bt_synonym = a.link_control_bt_synonym
			)

	UPDATE a
	SET link_control_caption = b.link_control_caption,
		Display_seqno = b.Display_seqno,
		separatelink_req = b.separatelink_req,
		map = b.map,
		modifiedby = @ctxt_user,
		modifieddate = @date
	FROM de_ui_combolink a(NOLOCK),
		re_published_ui_combolink b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcno = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.Combo_control_bt_synonym = b.Combo_control_bt_synonym
		AND a.link_control_bt_synonym = b.link_control_bt_synonym
		AND (
			isnull(a.link_control_caption, '') <> isnull(b.link_control_caption, '')
			OR isnull(a.Display_seqno, 0) <> isnull(b.Display_seqno, 0)
			OR ISNULL(a.separatelink_req, '') <> ISNULL(b.separatelink_req, '')
			OR ISNULL(a.map, '') <> ISNULL(b.map, '')
			)

	INSERT INTO de_ui_combolink (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Combo_control_bt_synonym,
		link_control_bt_synonym,
		link_control_caption,
		Display_seqno,
		separatelink_req,
		map,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.Combo_control_bt_synonym,
		a.link_control_bt_synonym,
		a.link_control_caption,
		a.Display_seqno,
		a.separatelink_req,
		a.map,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no
	FROM re_published_ui_combolink a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_combolink c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.Combo_control_bt_synonym = c.Combo_control_bt_synonym
				AND a.link_control_caption = c.link_control_caption
			)

	-----------
	------- For de_user_section  
	DELETE a
	FROM de_user_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_user_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.type = a.type
				AND b.include_value = a.include_value
				AND b.languageid = a.languageid
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.include_text = b.include_text
	FROM de_user_section a(NOLOCK),
		re_published_user_section b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.type = b.type
		AND a.include_value = b.include_value
		AND a.languageid = b.languageid

	INSERT INTO de_user_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		type,
		include_text,
		include_value,
		languageid,
		ecrno,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.type,
		a.include_text,
		a.include_value,
		a.languageid,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_user_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_user_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.type = c.type
				AND a.languageid = c.languageid
				AND a.include_value = c.include_value
			)

	--
	-----------Column Group start
	------- For de_ui_columngroup
	DELETE a
	FROM de_ui_columngroup a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_columngroup b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.Group_Caption = b.Group_Caption,
		a.grouplevel = b.grouplevel,
		a.groupseqno = b.groupseqno,
		a.parentgroup = b.parentgroup,
		a.parentgroupseq = b.parentgroupseq
	FROM de_ui_columngroup a(NOLOCK),
		re_published_ui_columngroup b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name

	INSERT INTO de_ui_columngroup (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
	FROM re_published_ui_columngroup a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_columngroup c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
			)

	------- For de_phone_columngroup
	DELETE a
	FROM de_phone_columngroup a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_phone_columngroup b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.Group_Caption = b.Group_Caption,
		a.grouplevel = b.grouplevel,
		a.groupseqno = b.groupseqno,
		a.parentgroup = b.parentgroup,
		a.parentgroupseq = b.parentgroupseq
	FROM de_phone_columngroup a(NOLOCK),
		re_published_phone_columngroup b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name

	INSERT INTO de_phone_columngroup (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
	FROM re_published_phone_columngroup a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_phone_columngroup c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
			)

	------- For de_tablet_columngroup
	DELETE a
	FROM de_tablet_columngroup a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_tablet_columngroup b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.Group_Caption = b.Group_Caption,
		a.grouplevel = b.grouplevel,
		a.groupseqno = b.groupseqno,
		a.parentgroup = b.parentgroup,
		a.parentgroupseq = b.parentgroupseq
	FROM de_tablet_columngroup a(NOLOCK),
		re_published_tablet_columngroup b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name

	INSERT INTO de_tablet_columngroup (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		Group_caption,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		grouplevel,
		groupseqno,
		parentgroup,
		parentgroupseq
	FROM re_published_tablet_columngroup a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_tablet_columngroup c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
			)

	------- For de_ui_column_group_mapping
	DELETE a
	FROM de_ui_column_group_mapping a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_column_group_mapping b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.SequenceNo = b.SequenceNo,
		a.mapped_entity = b.mapped_entity
	FROM de_ui_column_group_mapping a(NOLOCK),
		re_published_ui_column_group_mapping b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name
		AND b.column_bt_synonym = a.column_bt_synonym

	INSERT INTO de_ui_column_group_mapping (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_column_group_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_column_group_mapping c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	------- For de_phone_column_group_mapping
	DELETE a
	FROM de_phone_column_group_mapping a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_phone_column_group_mapping b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.SequenceNo = b.SequenceNo,
		a.mapped_entity = b.mapped_entity
	FROM de_phone_column_group_mapping a(NOLOCK),
		re_published_phone_column_group_mapping b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name
		AND b.column_bt_synonym = a.column_bt_synonym

	INSERT INTO de_phone_column_group_mapping (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_phone_column_group_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_phone_column_group_mapping c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	------- For de_tablet_column_group_mapping
	DELETE a
	FROM de_tablet_column_group_mapping a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_tablet_column_group_mapping b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
				AND b.Group_Name = a.Group_Name
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.SequenceNo = b.SequenceNo,
		a.mapped_entity = b.mapped_entity
	FROM de_tablet_column_group_mapping a(NOLOCK),
		re_published_tablet_column_group_mapping b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND b.grid_control_bt_synonym = a.grid_control_bt_synonym
		AND b.Group_Name = a.Group_Name
		AND b.column_bt_synonym = a.column_bt_synonym

	INSERT INTO de_tablet_column_group_mapping (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Page_bt_synonym,
		section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		grid_control_bt_synonym,
		Group_name,
		column_bt_synonym,
		SequenceNo,
		mapped_entity,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_tablet_column_group_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_tablet_column_group_mapping c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.grid_control_bt_synonym = c.grid_control_bt_synonym
				AND a.Group_Name = c.Group_Name
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	------------Column Group Ends
	--device tables  start
	------- For de_ui_device_control  
	DELETE a
	FROM de_ui_device_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_device_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.attributename = a.attributename
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.attributevalue = b.attributevalue,
		a.control_id = b.controlid,
		a.view_name = b.viewname
	FROM de_ui_device_control a(NOLOCK),
		re_published_ui_device_control b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.attributename = b.attributename

	INSERT INTO de_ui_device_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		attributename,
		attributevalue,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		control_id,
		view_name
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.attributename,
		a.attributevalue,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.controlid,
		a.viewname
	FROM re_published_ui_device_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_device_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.attributename = c.attributename
			)

	---device ends
	--device tables  start
	DELETE a
	FROM de_ui_device_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_device_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.attributename = a.attributename
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.attributevalue = b.attributevalue
	FROM de_ui_device_section a(NOLOCK),
		re_published_ui_device_section b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.attributename = b.attributename

	INSERT INTO de_ui_device_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		attributename,
		attributevalue,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.attributename,
		a.attributevalue,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_device_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_device_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.attributename = c.attributename
			)

	---device ends
	--device tables  start
	------- For de_user_section  
	DELETE a
	FROM de_ui_device_page a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_device_page b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.attributename = a.attributename
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.attributevalue = b.attributevalue
	FROM de_ui_device_page a(NOLOCK),
		re_published_ui_device_page b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.attributename = b.attributename

	INSERT INTO de_ui_device_page (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		attributename,
		attributevalue,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.attributename,
		a.attributevalue,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_device_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_device_page c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.attributename = c.attributename
			)

	---device ends
	--device tables  start
	------- For de_user_section  
	DELETE a
	FROM de_ui_device_grid a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_device_grid b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
				AND b.attributename = a.attributename
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		attributevalue = b.attributevalue,
		a.control_id = b.controlid,
		a.view_name = b.viewname
	FROM de_ui_device_grid a(NOLOCK),
		re_published_ui_device_grid b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.column_bt_synonym = b.column_bt_synonym
		AND a.attributename = b.attributename

	INSERT INTO de_ui_device_grid (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		attributename,
		attributevalue,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		control_id,
		view_name
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.column_bt_synonym,
		a.attributename,
		a.attributevalue,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		a.controlid,
		a.viewname
	FROM re_published_ui_device_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND b.customer_name = a.customer_name
		AND b.project_name = a.project_name
		AND b.ecr_no = a.ecr_no
		AND b.process_name = a.process_name
		AND b.component_name = a.component_name
		AND b.activity_name = a.activity_name
		AND b.ui_name = a.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_device_grid c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND a.ecr_no = @ecr_no
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.column_bt_synonym = a.column_bt_synonym
				AND c.attributename = a.attributename
			)

	---device ends
	--device tables  start
	DELETE a
	FROM de_ui_device a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM re_published_ui_device b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.attributename = a.attributename
			)

	UPDATE a
	SET modifiedby = @ctxt_user,
		modifieddate = @date,
		a.attributevalue = b.attributevalue
	FROM de_ui_device a(NOLOCK),
		re_published_ui_device b(NOLOCK),
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.attributename = b.attributename

	INSERT INTO de_ui_device (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		attributename,
		attributevalue,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.attributename,
		a.attributevalue,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_device a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 'K'
			FROM de_ui_device c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.ecr_no = @ecr_no
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.attributename = c.attributename
			)

	---device ends
	/*
--de_ui_section_control_map tables  start

delete a
from de_ui_section_control_map a ,
#de_rmt_ico_ui_tmp c
where c.customer_name  = @customer_name
and  c.project_name  = @project_name
and  c.ico_no   = @ico_no
and  c.ecr_no   = @ecr_no
and  c.process_name  = @process_name_tmp
and  c.component_name = @component_name_tmp

and  a.customer_name  = c.customer_name
and  a.project_name  = c.project_name
and  a.process_name  = c.process_name
and  a.component_name = c.component_name
and  a.activity_name  = c.activity_name
and  a.ui_name   = c.ui_name
and  not exists    ( select 'K'
from re_published_ui_section_control_map b(nolock)
where   b.customer_name  =   a.customer_name
and  b.project_name     =   a.project_name
and b.ecr_no   = @ecr_no
and b.process_name     =   a.process_name
and b.component_name    =   a.component_name
and b.activity_name     =   a.activity_name
and b.ui_name           =   a.ui_name
and	b.page_bt_synonym	= a.page_bt_synonym
and	b.section_bt_synonym= a.section_bt_synonym
and	b.control_bt_synonym = a.control_bt_synonym )

update a
set  modifiedby    = @ctxt_user,
modifieddate   = @date
from de_ui_section_control_map   a (nolock),
re_published_ui_section_control_map b (nolock),
#de_rmt_ico_ui_tmp   c
where c.customer_name  = @customer_name
and  c.project_name  = @project_name
and  c.ico_no   = @ico_no
and  c.ecr_no   = @ecr_no
and  c.process_name  = @process_name_tmp
and  c.component_name = @component_name_tmp

and  b.customer_name  = c.customer_name
and  b.project_name  = c.project_name
and  b.ecr_no   = c.ecr_no
and  b.process_name  = c.process_name
and  b.component_name = c.component_name
and  b.activity_name  = c.activity_name
and  b.ui_name   = c.ui_name

and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.process_name  = b.process_name
and a.component_name    =   b.component_name
and a.activity_name     =   b.activity_name
and a.ui_name           =   b.ui_name
and a.page_bt_synonym	= b.page_bt_synonym
and a.section_bt_synonym= b.section_bt_synonym
and a.control_bt_synonym= b.control_bt_synonym
and a.control_id	= b.control_id	
and a.view_name	= b.view_name


insert into de_ui_section_control_map(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,
control_id,view_name,createdby,createddate,modifiedby,modifieddate) 
select a.customer_name,   a.project_name,   a.process_name,   a.component_name,a.activity_name,a.ui_name, a.page_bt_synonym,a.section_bt_synonym,a.control_bt_synonym,
a.control_id,a.view_name,@ctxt_user,@date,@ctxt_user,@date
from re_published_ui_section_control_map a (nolock),
#de_rmt_ico_ui_tmp   b
where b.customer_name  = @customer_name
and  b.project_name  = @project_name
and  b.ico_no   = @ico_no
and  b.ecr_no   = @ecr_no
and  b.process_name  = @process_name_tmp
and  b.component_name = @component_name_tmp

and  a.customer_name  = b.customer_name
and  a.project_name  = b.project_name
and  a.ecr_no   = b.ecr_no
and  a.process_name  = b.process_name
and  a.component_name = b.component_name
and  a.activity_name  = b.activity_name
and  a.ui_name   = b.ui_name

and  not exists    ( select 'K'
from de_ui_section_control_map c(nolock)
where   a.customer_name  =   c.customer_name
and  a.project_name     =   c.project_name
and a.ecr_no   = @ecr_no
and a.process_name     =   c.process_name
and a.component_name    =   c.component_name
and a.activity_name     =   c.activity_name
and a.ui_name           =   c.ui_name
and	a.page_bt_synonym	=c.page_bt_synonym
and a.section_bt_synonym = c.section_bt_synonym	
and a.control_bt_synonym = c.control_bt_synonym
and a.control_id	= c.control_id
and a.view_name		= c.view_name)

---de_ui_section_control_map ends
*/
	--insertion into placeholder and tooltip starts
	DELETE a
	FROM de_ui_tooltip_lng_extn a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_tooltip_lng_extn b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET a.control_id = c.control_id,
		a.view_name = c.view_name,
		a.languageid = c.languageid,
		a.tooltip = c.tooltip,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_ui_tooltip_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_ui_tooltip_lng_extn c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.page_bt_synonym = c.page_bt_synonym
		AND a.section_bt_synonym = c.section_bt_synonym
		AND a.control_bt_synonym = c.control_bt_synonym
		AND a.column_bt_synonym = c.column_bt_synonym

	INSERT INTO de_ui_tooltip_lng_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		control_id,
		view_name,
		languageid,
		ecrno,
		tooltip,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		control_id,
		view_name,
		languageid,
		@ico_no,
		tooltip,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_tooltip_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_tooltip_lng_extn c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.column_bt_synonym = c.column_bt_synonym
			)

	DELETE a
	FROM de_ui_placeholder_lng_extn a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_placeholder_lng_extn b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	UPDATE a
	SET a.control_id = c.control_id,
		a.view_name = c.view_name,
		a.languageid = c.languageid,
		a.placeholder = c.placeholder,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_ui_placeholder_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_ui_placeholder_lng_extn c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.control_bt_synonym = c.control_bt_synonym
		and a.languageid	=	c.languageid --Tech-71539
	
	INSERT INTO de_ui_placeholder_lng_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		control_bt_synonym,
		control_id,
		view_name,
		languageid,
		ecrno,
		placeholder,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		control_bt_synonym,
		control_id,
		view_name,
		languageid,
		@ico_no,
		placeholder,
		TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_ui_placeholder_lng_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_placeholder_lng_extn c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.control_bt_synonym = c.control_bt_synonym
				--Code Added for TECH-74150 starts
				AND a.placeholder	=	c.placeholder
				AND a.languageid	=	c.languageid 
				--Code Added for TECH-74150 ends
			)

	--insertion into placeholder and tooltip ends
	----- QlikLink PLF2.0_16291
	DELETE a
	FROM de_ui_control_association_map a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_control_association_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.Section_bt_synonym = a.Section_bt_synonym
				AND b.Control_id = a.Control_id
				AND b.view_name = a.view_name
				AND b.propertyname = a.propertyname
				AND b.propertycontrol = a.propertycontrol
				AND b.property_controlid = a.property_controlid
				AND b.property_viewname = a.property_viewname
			)

	UPDATE a
	SET a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_ui_control_association_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_ui_control_association_map c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.Section_bt_synonym = a.Section_bt_synonym
		AND c.Control_id = a.Control_id
		AND c.view_name = a.view_name
		AND c.propertyname = a.propertyname
		AND c.propertycontrol = a.propertycontrol
		AND c.property_controlid = a.property_controlid
		AND c.property_viewname = a.property_viewname

	INSERT INTO de_ui_control_association_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_id,
		view_name,
		propertyname,
		propertycontrol,
		property_controlid,
		property_viewname,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_id,
		view_name,
		a.propertyname,
		a.propertycontrol,
		property_controlid,
		property_viewname,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no
	FROM re_published_ui_control_association_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_control_association_map c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.Section_bt_synonym = a.Section_bt_synonym
				AND c.Control_id = a.Control_id
				AND c.view_name = a.view_name
				AND c.propertyname = a.propertyname
				AND c.propertycontrol = a.propertycontrol
				AND c.property_controlid = a.property_controlid
				AND c.property_viewname = a.property_viewname
			)

	------ QlikLink
	------ code added for PLF2.0_16291 (Pivot tables )starts
	DELETE a
	FROM de_pivot_configure a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_pivot_configure b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_name = a.page_name
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	UPDATE a
	SET a.configpan_pos = c.configpan_pos,
		a.rowgrandtot_pos = c.rowgrandtot_pos,
		a.rowsubtot_pos = c.rowsubtot_pos,
		a.colgrandtot_pos = c.colgrandtot_pos,
		a.colsubtot_pos = c.colsubtot_pos,
		a.rowgrandtot_text = c.rowgrandtot_text,
		a.colgrandtot_text = c.colgrandtot_text,
		a.rowsubtot_text = c.rowsubtot_text,
		a.colsubtot_text = c.colsubtot_text,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_pivot_configure a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_pivot_configure c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.page_name = c.page_name
		AND a.control_bt_synonym = c.control_bt_synonym

	INSERT INTO de_pivot_configure (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_name,
		Control_bt_synonym,
		configpan_pos,
		rowgrandtot_pos,
		rowsubtot_pos,
		colgrandtot_pos,
		colsubtot_pos,
		rowgrandtot_text,
		colgrandtot_text,
		rowsubtot_text,
		colsubtot_text,
		TIMESTAMP,
		ecrno,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_name,
		a.Control_bt_synonym,
		a.configpan_pos,
		a.rowgrandtot_pos,
		a.rowsubtot_pos,
		a.colgrandtot_pos,
		a.colsubtot_pos,
		a.rowgrandtot_text,
		a.colgrandtot_text,
		a.rowsubtot_text,
		a.colsubtot_text,
		a.TIMESTAMP,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_pivot_configure a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		--and  a.ecr_no    =  b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_pivot_configure c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_name = c.page_name
				AND a.control_bt_synonym = c.control_bt_synonym
			)

	DELETE a
	FROM de_pivot_Fields a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_pivot_fields b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_name = a.page_name
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET a.rowlabel = c.rowlabel,
		a.columnlabel = c.columnlabel,
		a.fieldValue = c.fieldValue,
		a.rowlabelseq = c.rowlabelseq,
		a.columnlabelseq = c.columnlabelseq,
		a.valueseq = c.valueseq,
		a.ValueFunction = c.ValueFunction,
		a.rowlabelsorting = c.rowlabelsorting,
		a.columnlabelsorting = c.columnlabelsorting,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_pivot_Fields a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_pivot_fields c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.page_name = c.page_name
		AND a.control_bt_synonym = c.control_bt_synonym
		AND a.column_bt_synonym = c.column_bt_synonym

	INSERT INTO de_pivot_Fields (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_name,
		Control_bt_synonym,
		column_bt_synonym,
		rowlabel,
		columnlabel,
		fieldValue,
		rowlabelseq,
		columnlabelseq,
		valueseq,
		ValueFunction,
		rowlabelsorting,
		columnlabelsorting,
		ecrno,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_name,
		a.Control_bt_synonym,
		a.column_bt_synonym,
		a.rowlabel,
		a.columnlabel,
		a.fieldValue,
		a.rowlabelseq,
		a.columnlabelseq,
		a.valueseq,
		a.ValueFunction,
		a.rowlabelsorting,
		a.columnlabelsorting,
		@ico_no,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_pivot_fields a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		--and  a.ecr_no    =  b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_pivot_fields c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_name = c.page_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	DELETE a
	FROM de_pivot_lang_extn a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_pivot_lang_extn b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_name = a.page_name
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.DisplayField = a.DisplayField
				AND b.Languageid = a.Languageid
			)

	UPDATE a
	SET a.DisplayText = c.DisplayText,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_pivot_lang_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_pivot_lang_extn c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.page_name = c.page_name
		AND a.control_bt_synonym = c.control_bt_synonym
		AND a.DisplayField = c.DisplayField
		AND a.Languageid = c.Languageid

	INSERT INTO de_pivot_lang_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_name,
		Control_bt_synonym,
		DisplayField,
		Languageid,
		DisplayText,
		ecrno,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_name,
		a.Control_bt_synonym,
		a.DisplayField,
		a.Languageid,
		a.DisplayText,
		@ico_no,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_pivot_lang_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		--and  a.ecr_no    =  b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_pivot_lang_extn c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_name = c.page_name
				AND c.control_bt_synonym = a.control_bt_synonym
				AND a.DisplayField = c.DisplayField
				AND a.Languageid = c.Languageid
			)

	------ code added for PLF2.0_16291 (Pivot tables )Ends 
	--phone and tablet tables start PLF2.0_17570	
	DELETE a
	FROM de_tablet_grid a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tablet_grid b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	DELETE a
	FROM de_tablet_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tablet_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	DELETE a
	FROM de_tablet_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tablet_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
			)

	DELETE a
	FROM de_tablet_page a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tablet_page b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
			)

	DELETE a
	FROM de_tablet a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_tablet b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
			)

	DELETE a
	FROM de_phone_grid a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_phone_grid b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.column_bt_synonym = a.column_bt_synonym
			)

	DELETE a
	FROM de_phone_control a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_phone_control b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
			)

	DELETE a
	FROM de_phone_section a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_phone_section b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
			)

	DELETE a
	FROM de_phone_page a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_phone_page b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
			)

	DELETE a
	FROM de_phone a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_phone b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
			)

	UPDATE a
	SET a.ui_type = c.ui_type,
		a.ui_format = c.ui_format,
		a.tab_height = c.tab_height,
		a.TabStyle = c.TabStyle,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.Layout = c.Layout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.TabHeaderPostion = c.TabHeaderPostion,
		a.TabRotation = c.TabRotation
	FROM de_phone a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_phone c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_phone (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		ui_descr,
		ui_type,
		ui_format,
		tab_height,
		ecrno,
		TabStyle,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		Layout,
		XYCoordinates,
		ColumnLayWidth,
		TabHeaderPostion,
		TabRotation
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.ui_descr,
		a.ui_type,
		a.ui_format,
		a.tab_height,
		@ico_no,
		a.TabStyle,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		Layout,
		XYCoordinates,
		ColumnLayWidth,
		TabHeaderPostion,
		TabRotation
	FROM re_published_phone a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_phone c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
			)

	UPDATE a
	SET a.ui_type = c.ui_type,
		a.ui_format = c.ui_format,
		a.tab_height = c.tab_height,
		a.TabStyle = c.TabStyle,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.Layout = c.Layout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.TabHeaderPostion = c.TabHeaderPostion,
		a.TabRotation = c.TabRotation
	FROM de_tablet a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_tablet c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_tablet (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		ui_descr,
		ui_type,
		ui_format,
		tab_height,
		ecrno,
		TabStyle,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		Layout,
		XYCoordinates,
		ColumnLayWidth,
		TabHeaderPostion,
		TabRotation
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.ui_descr,
		a.ui_type,
		a.ui_format,
		a.tab_height,
		@ico_no,
		a.TabStyle,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		Layout,
		XYCoordinates,
		ColumnLayWidth,
		TabHeaderPostion,
		TabRotation
	FROM re_published_tablet a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tablet c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.HeaderPosition = c.HeaderPosition,
		a.TabRotation = c.TabRotation,
		a.TabTitleStyle = c.TabTitleStyle,
		a.TabIconPosition = c.TabIconPosition,
		a.PageLayout = c.PageLayout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.PageClass = c.PageClass
	FROM de_phone_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_phone_page c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym

	INSERT INTO de_phone_page (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		horder,
		vorder,
		HeaderPosition,
		TabRotation,
		TabTitleStyle,
		TabIconPosition,
		PageLayout,
		XYCoordinates,
		ColumnLayWidth,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		PageClass
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.horder,
		a.vorder,
		a.HeaderPosition,
		a.TabRotation,
		a.TabTitleStyle,
		a.TabIconPosition,
		a.PageLayout,
		a.XYCoordinates,
		a.ColumnLayWidth,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		PageClass
	FROM re_published_phone_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_phone_page c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.HeaderPosition = c.HeaderPosition,
		a.TabRotation = c.TabRotation,
		a.TabTitleStyle = c.TabTitleStyle,
		a.TabIconPosition = c.TabIconPosition,
		a.PageLayout = c.PageLayout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.PageClass = c.PageClass
	FROM de_tablet_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_tablet_page c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym

	INSERT INTO de_tablet_page (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		horder,
		vorder,
		HeaderPosition,
		TabRotation,
		TabTitleStyle,
		TabIconPosition,
		PageLayout,
		XYCoordinates,
		ColumnLayWidth,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		PageClass
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.horder,
		a.vorder,
		a.HeaderPosition,
		a.TabRotation,
		a.TabTitleStyle,
		a.TabIconPosition,
		a.PageLayout,
		a.XYCoordinates,
		a.ColumnLayWidth,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		PageClass
	FROM re_published_tablet_page a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tablet_page c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.section_type = c.section_type,
		a.title_required = c.title_required,
		a.border_required = c.border_required,
		a.parent_section = c.parent_section,
		a.title_alignment = c.title_alignment,
		a.width = c.width,
		a.height = c.height,
		a.caption_Format = c.caption_Format,
		a.ctrl_caption_align = c.ctrl_caption_align,
		a.Section_width_Scalemode = c.Section_width_Scalemode,
		a.Section_height_Scalemode = c.Section_height_Scalemode,
		a.SectionPrefixClass = c.SectionPrefixClass,
		a.Region = c.Region,
		a.TitlePosition = c.TitlePosition,
		a.CollapseDir = c.CollapseDir,
		a.SectionLayout = c.SectionLayout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_phone_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_phone_section c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym

	INSERT INTO de_phone_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		section_type,
		title_required,
		border_required,
		parent_section,
		horder,
		vorder,
		title_alignment,
		width,
		height,
		caption_Format,
		ctrl_caption_align,
		Section_width_Scalemode,
		Section_height_Scalemode,
		SectionPrefixClass,
		ecrno,
		Region,
		TitlePosition,
		CollapseDir,
		SectionLayout,
		XYCoordinates,
		ColumnLayWidth,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.section_type,
		a.title_required,
		a.border_required,
		a.parent_section,
		a.horder,
		a.vorder,
		a.title_alignment,
		a.width,
		a.height,
		a.caption_Format,
		a.ctrl_caption_align,
		a.Section_width_Scalemode,
		a.Section_height_Scalemode,
		a.SectionPrefixClass,
		@ico_no,
		a.Region,
		a.TitlePosition,
		a.CollapseDir,
		a.SectionLayout,
		a.XYCoordinates,
		a.ColumnLayWidth,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_phone_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_phone_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.section_type = c.section_type,
		a.title_required = c.title_required,
		a.border_required = c.border_required,
		a.parent_section = c.parent_section,
		a.title_alignment = c.title_alignment,
		a.width = c.width,
		a.height = c.height,
		a.caption_Format = c.caption_Format,
		a.ctrl_caption_align = c.ctrl_caption_align,
		a.Section_width_Scalemode = c.Section_width_Scalemode,
		a.Section_height_Scalemode = c.Section_height_Scalemode,
		a.SectionPrefixClass = c.SectionPrefixClass,
		a.Region = c.Region,
		a.TitlePosition = c.TitlePosition,
		a.CollapseDir = c.CollapseDir,
		a.SectionLayout = c.SectionLayout,
		a.XYCoordinates = c.XYCoordinates,
		a.ColumnLayWidth = c.ColumnLayWidth,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate
	FROM de_tablet_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_tablet_section c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym

	INSERT INTO de_tablet_section (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		section_type,
		title_required,
		border_required,
		parent_section,
		horder,
		vorder,
		title_alignment,
		width,
		height,
		caption_Format,
		ctrl_caption_align,
		Section_width_Scalemode,
		Section_height_Scalemode,
		SectionPrefixClass,
		ecrno,
		Region,
		TitlePosition,
		CollapseDir,
		SectionLayout,
		XYCoordinates,
		ColumnLayWidth,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.section_type,
		a.title_required,
		a.border_required,
		a.parent_section,
		a.horder,
		a.vorder,
		a.title_alignment,
		a.width,
		a.height,
		a.caption_Format,
		a.ctrl_caption_align,
		a.Section_width_Scalemode,
		a.Section_height_Scalemode,
		a.SectionPrefixClass,
		@ico_no,
		a.Region,
		a.TitlePosition,
		a.CollapseDir,
		a.SectionLayout,
		a.XYCoordinates,
		a.ColumnLayWidth,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_tablet_section a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tablet_section c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.control_type = c.control_type,
		a.order_seq = c.order_seq,
		a.visible_length = c.visible_length,
		a.sample_data = c.sample_data,
		a.LabelClass = c.LabelClass,
		a.ControlClass = c.ControlClass,
		a.freezecount = c.freezecount,
		a.TemplateID = c.TemplateID,
		a.label_column_width = c.label_column_width,
		a.data_column_width = c.data_column_width,
		a.label_column_scalemode = c.label_column_scalemode,
		a.data_column_scalemode = c.data_column_scalemode,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.TemplateCategory = c.TemplateCategory,
		a.TemplateSpecific = c.TemplateSpecific
	FROM de_phone_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_phone_control c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym
		AND c.control_bt_synonym = a.control_bt_synonym

	INSERT INTO de_phone_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		order_seq,
		data_column_width,
		label_column_width,
		label_column_scalemode,
		data_column_scalemode,
		control_id,
		view_name,
		visible_length,
		sample_data,
		LabelClass,
		ControlClass,
		freezecount,
		TemplateID,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		TemplateCategory,
		TemplateSpecific
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.control_type,
		a.horder,
		a.vorder,
		a.order_seq,
		a.data_column_width,
		a.label_column_width,
		a.label_column_scalemode,
		a.data_column_scalemode,
		a.control_id,
		a.view_name,
		a.visible_length,
		a.sample_data,
		a.LabelClass,
		a.ControlClass,
		a.freezecount,
		a.TemplateID,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		TemplateCategory,
		TemplateSpecific
	FROM re_published_phone_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_phone_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
			)

	UPDATE a
	SET a.horder = c.horder,
		a.vorder = c.vorder,
		a.control_type = c.control_type,
		a.order_seq = c.order_seq,
		a.visible_length = c.visible_length,
		a.sample_data = c.sample_data,
		a.LabelClass = c.LabelClass,
		a.ControlClass = c.ControlClass,
		a.freezecount = c.freezecount,
		a.TemplateID = c.TemplateID,
		a.label_column_width = c.label_column_width,
		a.data_column_width = c.data_column_width,
		a.label_column_scalemode = c.label_column_scalemode,
		a.data_column_scalemode = c.data_column_scalemode,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.TemplateCategory = c.TemplateCategory,
		a.TemplateSpecific = c.TemplateSpecific
	FROM de_tablet_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_tablet_control c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym
		AND c.control_bt_synonym = a.control_bt_synonym

	INSERT INTO de_tablet_control (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		control_type,
		horder,
		vorder,
		order_seq,
		data_column_width,
		label_column_width,
		label_column_scalemode,
		data_column_scalemode,
		control_id,
		view_name,
		visible_length,
		sample_data,
		LabelClass,
		ControlClass,
		freezecount,
		TemplateID,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		TemplateCategory,
		TemplateSpecific
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.control_type,
		a.horder,
		a.vorder,
		a.order_seq,
		a.data_column_width,
		a.label_column_width,
		a.label_column_scalemode,
		a.data_column_scalemode,
		a.control_id,
		a.view_name,
		a.visible_length,
		a.sample_data,
		a.LabelClass,
		a.ControlClass,
		a.freezecount,
		a.TemplateID,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		TemplateCategory,
		TemplateSpecific
	FROM re_published_tablet_control a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tablet_control c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
			)

	UPDATE a
	SET a.column_type = c.column_type,
		a.column_no = c.column_no,
		a.visible_length = c.visible_length,
		a.sample_data = c.sample_data,
		a.ColumnClass = c.ColumnClass,
		a.TemplateID = c.TemplateID,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.TemplateCategory = c.TemplateCategory,
		a.TemplateSpecific = c.TemplateSpecific
	FROM de_phone_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_phone_grid c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym
		AND c.control_bt_synonym = a.control_bt_synonym
		AND c.column_bt_synonym = a.column_bt_synonym

	INSERT INTO de_phone_grid (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		column_type,
		column_no,
		control_id,
		view_name,
		visible_length,
		sample_data,
		ColumnClass,
		TemplateID,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		TemplateCategory,
		TemplateSpecific
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.column_bt_synonym,
		a.column_type,
		a.column_no,
		a.control_id,
		a.view_name,
		a.visible_length,
		a.sample_data,
		a.ColumnClass,
		a.TemplateID,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		TemplateCategory,
		TemplateSpecific
	FROM re_published_phone_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_phone_grid c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	UPDATE a
	SET a.column_type = c.column_type,
		a.column_no = c.column_no,
		a.visible_length = c.visible_length,
		a.sample_data = c.sample_data,
		a.ColumnClass = c.ColumnClass,
		a.TemplateID = c.TemplateID,
		a.modifiedby = c.modifiedby,
		a.modifieddate = c.modifieddate,
		a.TemplateCategory = c.TemplateCategory,
		a.TemplateSpecific = c.TemplateSpecific
	FROM de_tablet_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b,
		re_published_tablet_grid c(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND c.customer_name = b.customer_name
		AND c.project_name = b.project_name
		AND c.ecr_no = b.ecr_no
		AND c.process_name = b.process_name
		AND c.component_name = b.component_name
		AND c.activity_name = b.activity_name
		AND c.ui_name = b.ui_name
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND c.page_bt_synonym = a.page_bt_synonym
		AND c.section_bt_synonym = a.section_bt_synonym
		AND c.control_bt_synonym = a.control_bt_synonym
		AND c.column_bt_synonym = a.column_bt_synonym

	INSERT INTO de_tablet_grid (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		column_bt_synonym,
		column_type,
		column_no,
		control_id,
		view_name,
		visible_length,
		sample_data,
		ColumnClass,
		TemplateID,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		TemplateCategory,
		TemplateSpecific
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.column_bt_synonym,
		a.column_type,
		a.column_no,
		a.control_id,
		a.view_name,
		a.visible_length,
		a.sample_data,
		a.ColumnClass,
		a.TemplateID,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		TemplateCategory,
		TemplateSpecific
	FROM re_published_tablet_grid a(NOLOCK),
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_tablet_grid c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND c.page_bt_synonym = a.page_bt_synonym
				AND c.section_bt_synonym = a.section_bt_synonym
				AND c.control_bt_synonym = a.control_bt_synonym
				AND c.column_bt_synonym = a.column_bt_synonym
			)

	--phone and tablet tables end PLF2.0_17570	
	DELETE a
	FROM de_custom_listedit a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_custom_listedit (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		listedit_synonym,
		list_search_id,
		list_search_context,
		list_index_search,
		list_recurrent_search,
		list_search_delay,
		list_select_column,
		list_result_column,
		list_width,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT DISTINCT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		page_bt_synonym,
		listedit_synonym,
		list_search_id,
		list_search_context,
		list_index_search,
		list_recurrent_search,
		list_search_delay,
		list_select_column,
		list_result_column,
		list_width,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_custom_listedit a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_custom_listedit c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.listedit_synonym = c.listedit_synonym
			)

	--code added by kiruthika for bugid:PLF2.0_03710
	-- de_date_highlight_control_map
	DELETE a
	FROM de_date_highlight_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_date_highlight_control_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.listedit_synonym = a.listedit_synonym
			)

	-- Modified By feroz for bug id :PNR2.0_23463
	UPDATE a
	SET a.listedit_controlid = b.listedit_controlid,
		a.listedit_viewname = b.listedit_viewname
	FROM de_date_highlight_control_map a(NOLOCK),
		re_published_date_highlight_control_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.listedit_synonym = b.listedit_synonym

	-- Modified By feroz for bug id :PNR2.0_23463
	INSERT INTO de_date_highlight_control_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		listedit_synonym,
		controlid,
		viewname,
		listedit_controlid,
		listedit_viewname,
		createdby,
		createddate,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.listedit_synonym,
		a.controlid,
		a.viewname,
		a.listedit_controlid,
		a.listedit_viewname,
		@ctxt_user,
		@date,
		@ico_no
	FROM re_published_date_highlight_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_date_highlight_control_map c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.listedit_synonym = c.listedit_synonym
			)

	-- code added by feroz for listedit -- end
	---------------------------------------------------------------------------------------------
	-- code added by feroz for UI Toolbar -- Start
	-- de_ui_toolbar_group
	DELETE a
	FROM de_ui_toolbar_group a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_toolbar_group b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.group_name = a.group_name
			)

	INSERT INTO de_ui_toolbar_group (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		group_name,
		group_descr,
		createddate,
		createdby,
		modifieddate,
		modifiedby,
		ecrno,
		Orientation
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		group_name,
		group_descr,
		@date,
		@ctxt_user,
		@date,
		@ctxt_user,
		@ico_no,
		Orientation
	FROM re_published_ui_toolbar_group a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_toolbar_group c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.group_name = c.group_name
			)

	--- specify template starts--
	DELETE a
	FROM de_ui_Temp_placeholders a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_Temp_placeholders b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.templateid = a.templateid
			)

	INSERT INTO de_ui_Temp_placeholders (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		templateid,
		control_id,
		view_name,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		placeholder,
		associatedColumn,
		associatedevent
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.templateid,
		a.control_id,
		a.view_name,
		@ctxt_user,
		getdate(),
		@ctxt_user,
		getdate(),
		a.placeholder,
		a.associatedColumn,
		a.associatedevent
	FROM re_published_ui_Temp_placeholders a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_Temp_placeholders c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.templateid = c.templateid
			)

	DELETE a
	FROM de_ui_template_controlmap a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_template_controlmap b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.templateid = a.templateid
			)

	INSERT INTO de_ui_template_controlmap (
		customer_name,
		project_name,
		ecrno,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		templateid,
		control_id,
		view_name,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.customer_name,
		a.project_name,
		@ico_no,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.templateid,
		a.control_id,
		a.view_name,
		@ctxt_user,
		getdate(),
		@ctxt_user,
		getdate()
	FROM re_published_ui_template_controlmap a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_template_controlmap c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.templateid = c.templateid
			)

	-- specify template ends---
	-- specify calender starts--
	DELETE a
	FROM de_calendar_configure a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_calendar_configure b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_name = a.page_name
				AND b.section_name = a.section_name
			)

	INSERT INTO de_calendar_configure (
		Customer_name,
		Project_name,
		Process_name,
		Component_name,
		Activity_name,
		ui_name,
		page_name,
		section_name,
		ecrno,
		monthview_cal,
		weekview_cal,
		editable,
		detailspane,
		listview_req,
		DefaultTemplate,
		eventstyle,
		month_nav_req,
		week_nav_req,
		tap_req,
		doubletap_req,
		drag_req,
		month_nav_event,
		week_nav_event,
		tapevent,
		doubletap_event,
		dragevent,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.Customer_name,
		a.Project_name,
		a.Process_name,
		a.Component_name,
		a.Activity_name,
		a.ui_name,
		a.page_name,
		a.section_name,
		@ico_no,
		a.monthview_cal,
		a.weekview_cal,
		a.editable,
		a.detailspane,
		a.listview_req,
		a.DefaultTemplate,
		a.eventstyle,
		a.month_nav_req,
		a.week_nav_req,
		a.tap_req,
		a.doubletap_req,
		a.drag_req,
		a.month_nav_event,
		a.week_nav_event,
		a.tapevent,
		a.doubletap_event,
		a.dragevent,
		TIMESTAMP,
		@ctxt_user,
		getdate(),
		@ctxt_user,
		getdate()
	FROM re_published_calendar_configure a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_calendar_configure c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_name = c.page_name
				AND a.section_name = c.section_name
			)

	-- specify calender ends--
	-- de_ui_toolbar
	DELETE a
	FROM de_ui_toolbar a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_toolbar b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.group_name = a.group_name
				AND b.group_task_name = a.group_task_name
			)

	UPDATE a
	SET a.task_seqno = b.task_seqno,
		a.class_name = b.class_name,
		a.display_text = b.display_text,
		a.group_task_desc = b.group_task_desc,
		a.group_node_task = b.group_node_task
	FROM de_ui_toolbar a(NOLOCK),
		re_published_ui_toolbar b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.group_name = b.group_name
		AND a.group_task_name = b.group_task_name

	INSERT INTO de_ui_toolbar (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		group_name,
		group_task_name,
		task_seqno,
		class_name,
		display_text,
		group_task_desc,
		createddate,
		createdby,
		modifieddate,
		modifiedby,
		ecrno,
		group_node_task
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		group_name,
		group_task_name,
		task_seqno,
		class_name,
		display_text,
		group_task_desc,
		@date,
		@ctxt_user,
		@date,
		@ctxt_user,
		@ico_no,
		group_node_task
	FROM re_published_ui_toolbar a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_toolbar c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.group_name = c.group_name
				AND a.group_task_name = c.group_task_name
			)

	-- de_ui_displaytext_lang_extn
	DELETE a
	FROM de_ui_displaytext_lang_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_displaytext_lang_extn b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.group_task_name = a.group_task_name
				AND b.lang_id = a.lang_id
				AND a.group_name = b.group_name
			)

	UPDATE a
	SET a.display_text = b.display_text
	FROM de_ui_displaytext_lang_extn a(NOLOCK),
		re_published_ui_displaytext_lang_extn b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.group_task_name = b.group_task_name
		AND a.lang_id = b.lang_id
		AND a.group_name = b.group_name

	INSERT INTO de_ui_displaytext_lang_extn (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		group_task_name,
		display_text,
		lang_id,
		createddate,
		createdby,
		ecrno,
		group_name
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		group_task_name,
		display_text,
		lang_id,
		@date,
		@ctxt_user,
		@ico_no,
		group_name
	FROM re_published_ui_displaytext_lang_extn a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_displaytext_lang_extn c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.group_task_name = c.group_task_name
				AND a.lang_id = c.lang_id
				AND a.group_name = c.group_name
			)

	-- de_ui_toolbar_mapping
	DELETE a
	FROM de_ui_toolbar_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_ui_toolbar_mapping b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.toolbar_id = a.toolbar_id
				AND b.group_task_name = a.group_task_name
			)

	UPDATE a
	SET a.display_seqno = b.display_seqno,
		a.class_name = b.class_name,
		a.display_text = b.display_text,
		a.caption_req = b.caption_req,
		a.control_req = b.control_req
	FROM de_ui_toolbar_mapping a(NOLOCK),
		re_published_ui_toolbar_mapping b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.toolbar_id = b.toolbar_id
		AND a.group_task_name = b.group_task_name

	INSERT INTO de_ui_toolbar_mapping (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		toolbar_id,
		group_task_name,
		display_seqno,
		class_name,
		display_text,
		caption_req,
		control_req,
		createddate,
		createdby,
		modifieddate,
		modifiedby,
		ecrno
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		toolbar_id,
		group_task_name,
		display_seqno,
		class_name,
		display_text,
		caption_req,
		control_req,
		@date,
		@ctxt_user,
		@date,
		@ctxt_user,
		@ico_no
	FROM re_published_ui_toolbar_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_ui_toolbar_mapping c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.toolbar_id = c.toolbar_id
				AND a.group_task_name = c.group_task_name
			)

	-- code added by feroz for UI Toolbar -- End
	---------------------------------------------------------------------------------------------
	-- code added by Jeya for Dynamic Section -- start
	DELETE a
	FROM de_dynamic_sec_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_dynamic_sec_control_map b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecrno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
			)

	UPDATE a
	SET a.control_bt_synonym = b.control_bt_synonym,
		a.controlid = b.controlid,
		a.viewname = b.viewname
	FROM de_dynamic_sec_control_map a(NOLOCK),
		re_published_dynamic_sec_control_map b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.rcnno = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_bt_synonym = b.section_bt_synonym

	INSERT INTO de_dynamic_sec_control_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_bt_synonym,
		controlid,
		viewname,
		ecrno,
		createdby,
		createddate
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_bt_synonym,
		a.controlid,
		a.viewname,
		@ico_no,
		@ctxt_user,
		@date
	FROM re_published_dynamic_sec_control_map a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_dynamic_sec_control_map c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
			)

	-- code added by Jeya for Dynamic Section -- End
	---------------------------------------------------------------------------------------------
	-- code added by Jeya Latha K for Contextual Links and Control Extensions Starts
	DELETE a
	FROM de_contextual_links a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_contextual_links b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_name = a.section_name
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.contextual_link_name = a.contextual_link_name
			) -- bug id : PNR2.0_25741, PNR2.0_25884

	-- Code added for the Bug Id PNR2.0_25912 Starts
	UPDATE a
	SET a.contextual_link_seq = b.contextual_link_seq,
		a.task_description = b.task_description,
		a.extend_as = b.extend_as,
		a.source_from = b.source_from,
		a.tolltiptext = b.tolltiptext,
		a.linked_componentname = b.linked_componentname,
		a.linked_activityname = b.linked_activityname,
		a.linked_uiname = b.linked_uiname,
		a.subscription_name = b.subscription_name,
		a.task_name = b.task_name,
		a.task_type = b.task_type
	FROM de_contextual_links a(NOLOCK),
		re_published_contextual_links b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_name = b.section_name
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.contextual_link_name = b.contextual_link_name

	-- Code added for the Bug Id PNR2.0_25912 end
	INSERT INTO de_contextual_links (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_name,
		control_bt_synonym,
		contextual_link_name,
		contextual_link_seq,
		task_description,
		extend_as,
		source_from,
		tolltiptext,
		linked_componentname,
		linked_activityname,
		linked_uiname,
		subscription_name,
		task_name,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		task_type
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_name,
		a.control_bt_synonym,
		contextual_link_name,
		contextual_link_seq,
		task_description,
		extend_as,
		source_from,
		tolltiptext,
		linked_componentname,
		linked_activityname,
		linked_uiname,
		subscription_name,
		task_name,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		task_type
	FROM re_published_contextual_links a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_contextual_links c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_name = c.section_name
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.contextual_link_name = c.contextual_link_name
			) -- Modified for the Bug ID PNR2.0_25928

	DELETE a
	FROM de_control_extensions a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_control_extensions b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_name = a.section_name
				AND b.control_bt_synonym = a.control_bt_synonym
				AND b.controlextension_name = a.controlextension_name
			) -- bug id : PNR2.0_25741, PNR2.0_25884

	-- Code added for the Bug Id PNR2.0_25912 Starts
	UPDATE a
	SET a.controlextension_seq = b.controlextension_seq,
		a.task_description = b.task_description,
		a.extend_as = b.extend_as,
		a.source_from = b.source_from,
		a.image_path = b.image_path,
		a.tooltiptext = b.tooltiptext, -- PNR2.0_25915
		a.linked_componentname = b.linked_componentname,
		a.linked_activityname = b.linked_activityname,
		a.linked_uiname = b.linked_uiname,
		a.subscription_name = b.subscription_name,
		a.task_name = b.task_name,
		a.task_type = b.task_type
	FROM de_control_extensions a(NOLOCK),
		re_published_control_extensions b(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND b.customer_name = c.customer_name
		AND b.project_name = c.project_name
		AND b.ecr_no = c.ecr_no
		AND b.process_name = c.process_name
		AND b.component_name = c.component_name
		AND b.activity_name = c.activity_name
		AND b.ui_name = c.ui_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.section_name = b.section_name
		AND a.control_bt_synonym = b.control_bt_synonym
		AND a.controlextension_name = b.controlextension_name

	-- Code added for the Bug Id PNR2.0_25912 end
	INSERT INTO de_control_extensions (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_name,
		control_bt_synonym,
		controlextension_name,
		controlextension_seq,
		task_description,
		extend_as,
		source_from,
		tooltiptext,
		linked_componentname,
		linked_activityname,
		linked_uiname,
		subscription_name,
		task_name,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		task_type,
		image_path
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_name,
		a.control_bt_synonym,
		controlextension_name,
		controlextension_seq,
		task_description,
		extend_as,
		source_from,
		tooltiptext,
		linked_componentname,
		linked_activityname,
		linked_uiname,
		subscription_name,
		task_name,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		task_type,
		image_path
	FROM re_published_control_extensions a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_control_extensions c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_name = c.section_name
				AND a.control_bt_synonym = c.control_bt_synonym
				AND a.controlextension_name = c.controlextension_name
			) -- Modified for the Bug ID PNR2.0_25928

	-- code added by Jeya Latha K for Contextual Links and Control Extensions End
	-- 29) To delete the services for the task which are removed - de_fw_des_ilbo_service_view_datamap
	--Code commented By Sangeetha L for the Bug ID:PNR2.0_3277
	--Bug Descr:Invalid primary key violation in table fw_des_service
	-- code uncommented by Anuradha M on 18-10-2005 for the Bug id : PNR2.0_4287
	DELETE a
	FROM de_fw_des_ilbo_service_view_datamap a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ilbocode = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ilbocode
				AND c.task_name = a.taskname
			)

	-- code uncommented by Anuradha M on 18-10-2005 for the Bug id : PNR2.0_4287
	--Code commented By Sangeetha L for the Bug ID:PNR2.0_3277
	--Bug Descr:Invalid primary key violation in table fw_des_service
	---------------------------------------------------------------------------------------------
	-- 30) To delete the services for the task which are removed - de_task_service_map
	DELETE a
	FROM de_task_service_map a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.task_name = a.task_name
			)

	--------------------------------------------------------------------------------------------
	-- 27) To get the controlid & viewname for the hidden view
	-- code modified by Ganesh for the callid PNR2.0_3864 on 15/09/05
	IF EXISTS (
			SELECT 's'
			FROM de_hidden_view a(NOLOCK),
				#de_rmt_ico_ui_tmp b
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND EXISTS (
					SELECT 's'
					FROM de_ui_control d(NOLOCK)
					WHERE d.customer_name = a.customer_name
						AND d.project_name = a.project_name
						AND d.process_name = a.process_name
						AND d.component_name = a.component_name
						AND d.activity_name = a.activity_name
						AND d.ui_name = a.ui_name
						AND d.control_id = a.control_id
						AND d.view_name = a.view_name
					
					UNION
					
					SELECT 's'
					FROM de_ui_grid c(NOLOCK)
					WHERE c.customer_name = a.customer_name
						AND c.project_name = a.project_name
						AND c.process_name = a.process_name
						AND c.component_name = a.component_name
						AND c.activity_name = a.activity_name
						AND c.ui_name = a.ui_name
						AND c.control_id = a.control_id
						AND c.view_name = a.view_name
					)
			)
	BEGIN
		UPDATE a
		SET control_bt_synonym = b.new_control_bt_synonym
		FROM de_fw_des_ilbo_service_view_datamap a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ilbocode = b.ui_name
			AND a.page_bt_synonym = b.page_name
			AND a.controlid = b.control_id
			AND a.viewname = b.view_name
			AND c.customer_name = a.customer_name
			AND c.project_name = a.project_name
			AND c.process_name = a.process_name
			AND c.component_name = a.component_name
			AND c.activity_name = a.activity_name
			AND c.ui_name = a.ilbocode
			AND a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp

		UPDATE a
		SET -- control_id    = b.control_id,
			view_name = 'h' + hidden_view_bt_synonym
		--Code commented By Ganesh for the Bug ID: PNR2.0_3493
		--   new_control_bt_synonym = a.hidden_view_bt_synonym
		FROM de_hidden_view a(NOLOCK),
			de_ui_control b(NOLOCK),
			es_comp_ctrl_type_mst c(NOLOCK),
			#de_rmt_ico_ui_tmp d
		WHERE d.customer_name = @customer_name
			AND d.project_name = @project_name
			AND d.ico_no = @ico_no
			AND d.ecr_no = @ecr_no
			AND d.process_name = @process_name_tmp
			AND d.component_name = @component_name_tmp
			AND a.customer_name = d.customer_name
			AND a.project_name = d.project_name
			AND a.process_name = d.process_name
			AND a.component_name = d.component_name
			AND a.activity_name = d.activity_name
			AND a.ui_name = d.ui_name
			AND b.customer_name = a.customer_name
			AND b.project_name = a.project_name
			AND b.process_name = a.process_name
			AND b.component_name = a.component_name
			AND b.activity_name = a.activity_name
			AND b.ui_name = a.ui_name
			AND b.page_bt_synonym = a.page_name
			AND b.control_bt_synonym = a.control_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.ctrl_type_name = b.control_type
			AND c.base_ctrl_type <> 'Grid'

		--Code modified by Ganesh on 30-3-05 for the bug id :: PNR2.0_1665
		DECLARE hidd_cur INSENSITIVE CURSOR
		FOR
		SELECT b.activity_name,
			b.ui_name,
			b.page_bt_synonym,
			b.control_bt_synonym
		FROM de_ui_control b(NOLOCK),
			es_comp_ctrl_type_mst c(NOLOCK),
			#de_rmt_ico_ui_tmp d
		WHERE b.customer_name = @customer_name
			AND b.project_name = @project_name
			AND b.process_name = @process_name_tmp
			AND b.component_name = @component_name_tmp
			AND b.customer_name = c.customer_name
			AND b.project_name = c.project_name
			AND b.process_name = c.process_name
			AND b.component_name = c.component_name
			AND b.control_type = c.ctrl_type_name
			AND c.base_ctrl_type = 'Grid'
			AND b.customer_name = d.customer_name
			AND b.project_name = d.project_name
			AND b.process_name = d.process_name
			AND b.component_name = d.component_name
			AND b.activity_name = d.activity_name
			AND b.ui_name = d.ui_name

		OPEN hidd_cur

		WHILE 1 = 1
		BEGIN
			FETCH NEXT
			FROM hidd_cur
			INTO @activity_name_tmp,
				@ui_name_tmp,
				@page_name,
				@grid_ctrl_name

			IF @@fetch_status <> 0
				BREAK

			SET @hdn_view_tmp = 0

			SELECT @hdn_view_tmp = max(convert(VARCHAR, b.view_name))
			FROM de_ui_grid b(NOLOCK)
			WHERE b.customer_name = @customer_name
				AND b.project_name = @project_name
				AND b.process_name = @process_name_tmp
				AND b.component_name = @component_name_tmp
				AND b.activity_name = @activity_name_tmp
				AND b.ui_name = @ui_name_tmp
				AND b.page_bt_synonym = @page_name
				AND b.control_bt_synonym = @grid_ctrl_name

			DECLARE gird_hdn_view INSENSITIVE CURSOR
			FOR
			SELECT a.control_id,
				b.hidden_view_bt_synonym
			FROM de_ui_control a(NOLOCK),
				de_hidden_view b(NOLOCK),
				es_comp_ctrl_type_mst c(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @page_name
				AND a.control_bt_synonym = @grid_ctrl_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_name
				AND a.control_bt_synonym = b.control_bt_synonym
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.control_type = c.ctrl_type_name
				AND c.base_ctrl_type = 'Grid'

			OPEN gird_hdn_view

			WHILE 1 = 1
			BEGIN
				FETCH NEXT
				FROM gird_hdn_view
				INTO @ctrl_hdb_ctrl_id,
					@ctrl_hdn_name

				IF @@fetch_status <> 0
					BREAK

				SET @hdn_view_tmp = @hdn_view_tmp + 1

				UPDATE de_hidden_view
				SET -- control_id    = @ctrl_hdb_ctrl_id,
					view_name = @hdn_view_tmp
				--new_control_bt_synonym = @ctrl_hdn_name
				FROM de_hidden_view a(NOLOCK)
				WHERE a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @process_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @activity_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.page_name = @page_name
					AND a.control_bt_synonym = @grid_ctrl_name
					AND a.hidden_view_bt_synonym = @ctrl_hdn_name
			END

			CLOSE gird_hdn_view

			DEALLOCATE gird_hdn_view

			SET @ctrl_hdn_name = ''

			DECLARE gird_ctrl_hdn_view INSENSITIVE CURSOR
			FOR
			SELECT b.control_bt_synonym,
				a.control_id,
				b.hidden_view_bt_synonym
			FROM de_ui_grid a(NOLOCK),
				de_hidden_view b(NOLOCK)
			WHERE a.customer_name = @customer_name
				AND a.project_name = @project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @page_name
				AND a.control_bt_synonym = @grid_ctrl_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_bt_synonym = b.page_name
				AND a.column_bt_synonym = b.control_bt_synonym

			OPEN gird_ctrl_hdn_view

			WHILE 1 = 1
			BEGIN
				FETCH NEXT
				FROM gird_ctrl_hdn_view
				INTO @grid_clmn_name,
					@grid_ctrl_id,
					@ctrl_hdn_name

				IF @@fetch_status <> 0
					BREAK

				SET @hdn_view_tmp = @hdn_view_tmp + 1

				UPDATE de_hidden_view
				SET -- control_id    = @grid_ctrl_id,
					view_name = @hdn_view_tmp
				-- new_control_bt_synonym = a.hidden_view_bt_synonym
				FROM de_hidden_view a(NOLOCK)
				WHERE a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @process_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @activity_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.page_name = @page_name
					AND a.control_bt_synonym = @grid_clmn_name
					AND a.hidden_view_bt_synonym = @ctrl_hdn_name
			END

			CLOSE gird_ctrl_hdn_view

			DEALLOCATE gird_ctrl_hdn_view
		END

		CLOSE hidd_cur

		DEALLOCATE hidd_cur

		UPDATE a
		SET -- controlid   = b.control_id,
			viewname = b.view_name
		FROM de_fw_des_ilbo_service_view_datamap a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ilbocode = b.ui_name
			AND a.page_bt_synonym = b.page_name
			AND a.control_bt_synonym = b.new_control_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.activity_name = b.activity_name
			AND c.ui_name = b.ui_name
			AND a.customer_name = @customer_name
			AND a.project_name = @project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp

		-- code added by Ganesh for the bugid :: pnr2.0_2290 on 03/05/05
		-- hidden view publsih\sub dataitem control id & view name has to be updated.
		UPDATE a
		SET published_control_name = control_id,
			published_view_name = view_name
		FROM de_publication_dataitem a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.Customer_Name = b.Customer_Name
			AND a.Project_Name = b.Project_Name
			AND a.Process_Name = b.Process_Name
			AND a.Component_Name = b.Component_Name
			AND a.Activity_Name = b.Activity_Name
			AND a.UI_Name = b.UI_Name
			AND a.Page_Bt_Synonym = b.Page_Name
			AND a.Published_Bt_Synonym = b.hidden_view_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.activity_name = b.activity_name
			AND c.ui_name = b.ui_name
			AND b.customer_name = @customer_name
			AND b.project_name = @project_name
			AND b.process_name = @process_name_tmp
			AND b.component_name = @component_name_tmp

		UPDATE a
		SET subscribed_control_name = control_id,
			subscribed_view_name = view_name
		FROM de_subscription_dataitem a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.Customer_Name = b.Customer_Name
			AND a.Project_Name = b.Project_Name
			AND a.Process_Name = b.Process_Name
			AND a.Component_Name = b.Component_Name
			AND a.Activity_Name = b.Activity_Name
			AND a.UI_Name = b.UI_Name
			AND a.Page_Bt_Synonym = b.Page_Name
			AND a.subscribed_bt_synonym = b.hidden_view_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.activity_name = b.activity_name
			AND c.ui_name = b.ui_name
			AND b.customer_name = @customer_name
			AND b.project_name = @project_name
			AND b.process_name = @process_name_tmp
			AND b.component_name = @component_name_tmp

		UPDATE a
		SET subscribed_control_name = control_id,
			subscribed_view_name = view_name
		FROM de_resolved_link_dataitem a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.Customer_Name = b.Customer_Name
			AND a.Project_Name = b.Project_Name
			AND a.Process_Name = b.Process_Name
			AND a.Component_Name = b.Component_Name
			AND a.Activity_Name = b.Activity_Name
			AND a.UI_Name = b.UI_Name
			AND a.Page_Bt_Synonym = b.Page_Name
			AND a.subscribed_bt_synonym = b.hidden_view_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.activity_name = b.activity_name
			AND c.ui_name = b.ui_name
			AND b.customer_name = @customer_name
			AND b.project_name = @project_name
			AND b.process_name = @process_name_tmp
			AND b.component_name = @component_name_tmp

		UPDATE a
		SET published_control_name = control_id,
			published_view_name = view_name
		FROM de_resolved_link_dataitem a(NOLOCK),
			de_hidden_view b(NOLOCK),
			#de_rmt_ico_ui_tmp c
		WHERE a.Customer_Name = b.Customer_Name
			AND a.Project_Name = b.Project_Name
			AND a.publication_comp_name = b.Component_Name
			AND a.publication_act_name = b.Activity_Name
			AND a.publication_ui_name = b.UI_Name
			AND a.Published_Bt_Synonym = b.hidden_view_bt_synonym
			AND c.customer_name = b.customer_name
			AND c.project_name = b.project_name
			AND c.process_name = b.process_name
			AND c.component_name = b.component_name
			AND c.activity_name = b.activity_name
			AND c.ui_name = b.ui_name
			AND b.customer_name = @customer_name
			AND b.project_name = @project_name
			AND b.process_name = @process_name_tmp
			AND b.component_name = @component_name_tmp
	END

	--code commented by Anuradha on 16-Mar-2006 for the Bug id : Bug Id : PNR2.0_7254 -- Start
	-- code added by Ganesh for the callid :: PNR2.0_4277 on 18/10/05
	--Code uncommented for bugId : PNR2.0_9857
	DELETE a
	FROM de_hidden_view_usage a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_action c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				AND c.page_bt_synonym = a.page_name -- Added by Sangeetha G for PNR2.0_16899
				AND c.task_name = a.action_name
			)

	DELETE a
	FROM de_hidden_view_usage a,
		#de_rmt_ico_ui_tmp b
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_hidden_view c(NOLOCK)
			WHERE c.customer_name = a.customer_name
				AND c.project_name = a.project_name
				AND c.process_name = a.process_name
				AND c.component_name = a.component_name
				AND c.activity_name = a.activity_name
				AND c.ui_name = a.ui_name
				--and  c.page_name   =  a.page_name
				AND c.page_name = a.control_page_name --code modified by kiruthika for bugid:PNR2.0_10703
				AND c.control_bt_synonym = a.control_bt_sysnonym
				AND c.hidden_view_bt_synonym = a.hidden_view_bt_sysnonym
			)

	--code commented by Anuradha on 16-Mar-2006 for the Bug id : Bug Id : PNR2.0_7254 -- End
	---------------------------------------------------------------------------------------------
	-- Code addded By feroz for context menu -- PNR2.0_1476 -- Start
	DELETE a
	FROM de_ui_contextmenu_task_dtl a,
		#de_rmt_ico_ui_tmp c
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name

	INSERT INTO de_ui_contextmenu_task_dtl (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_name,
		section_name,
		control_bt_synonym,
		control_id,
		task_name,
		task_descr,
		task_type,
		task_seq,
		task_pattern,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		ecrno,
		map_flag
		)
	SELECT a.customer_name,
		a.project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_name,
		a.control_bt_synonym,
		a.control_id,
		a.task_name,
		a.task_descr,
		a.task_type,
		a.task_seq,
		a.task_pattern,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		@ico_no,
		'1'
	FROM re_published_ui_contextmenu_task_dtl a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcn_no = b.ecr_no -- code modified by Feroz for bug id : PNR2.0_18426
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name

	-- Code addded By feroz for context menu -- PNR2.0_1476 -- End
	/*Code added by Gankan.G for CaseID: PNR2.0_32794  starts*/
	UPDATE a
	SET a.task_descr = b.task_descr,
		a.task_confirm_msg = b.task_confirm_msg,
		a.task_status_msg = b.task_status_msg,
		a.sectionlaunchtype = b.sectionlaunchtype -- added for SectionLaunch Type TECH-12776 
	FROM de_action a(NOLOCK),
		re_action b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name

	UPDATE a
	SET a.task_descr = b.task_descr,
		a.task_confirm_msg = b.task_confirm_msg,
		a.task_status_msg = b.task_status_msg
	FROM de_action_lng_extn a(NOLOCK),
		re_action_lng_extn b(NOLOCK)
	WHERE a.customer_name = @customer_name
		AND a.project_name = @project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND a.page_bt_synonym = b.page_bt_synonym
		AND a.task_name = b.task_name
		AND a.languageid = b.languageid

	-- Code modification starts for sync view
	DELETE a
	FROM de_sync_view a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_sync_view b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.ecr_no = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.legrid_control_id = a.legrid_control_id
				AND b.legrid_view_name = a.legrid_view_name
				AND b.map_le_viewname = a.map_le_viewname
				AND b.map_legrid_view_name = a.map_legrid_view_name
			)

	--set a.le_column_bt_synonym = b.le_column_bt_synonym,
	--a.mapped_le_column = b.mapped_le_column,
	--a.mapped_grd_column  = b.mapped_grd_column
	--from de_listedit_column    a (nolock),
	--re_published_listedit_column b (nolock),
	--#de_rmt_ico_ui_tmp    c (nolock)
	--where  c.customer_name   = @customer_name
	--and   c.project_name   = @project_name
	--and   c.ico_no     = @ico_no
	--and   c.ecr_no     = @ecr_no
	--and   c.process_name   = @process_name_tmp
	--and   c.component_name   = @component_name_tmp
	--and   b.customer_name   = c.customer_name
	--and   b.project_name   = c.project_name
	--and   b.ecr_no     = c.ecr_no
	--and   b.process_name   = c.process_name
	--and   b.component_name   = c.component_name
	--and   b.activity_name   = c.activity_name
	--and   b.ui_name = c.ui_name
	--and   a.customer_name   = b.customer_name
	--and   a.project_name   = b.project_name
	--and   a.process_name   = b.process_name
	--and   a.component_name   = b.component_name
	--and   a.activity_name   = b.activity_name
	--and   a.ui_name     = b.ui_name
	--and   a.listedit_synonym  = b.listedit_synonym
	--and   a.listedit_column_synonym = b.listedit_column_synonym
	INSERT INTO de_sync_view (
		Customer_name,
		Project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		legrid_control_bt_syonym,
		legrid_control_id,
		legrid_view_name,
		map_le_synonym,
		map_le_column_synonym,
		map_le_controlid,
		map_le_viewname,
		map_legrid_view_name,
		ecrno,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		legrid_column_bt_synonym,
		map_legrid_column_bt_synonym
		)
	SELECT a.Customer_name,
		a.Project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.legrid_control_bt_syonym,
		a.legrid_control_id,
		a.legrid_view_name,
		a.map_le_synonym,
		a.map_le_column_synonym,
		a.map_le_controlid,
		a.map_le_viewname,
		a.map_legrid_view_name,
		@ico_no,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date,
		legrid_column_bt_synonym,
		map_legrid_column_bt_synonym
	FROM re_published_sync_view a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.ecr_no = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_sync_view c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.legrid_control_id = c.legrid_control_id
				AND a.legrid_view_name = c.legrid_view_name
				AND a.map_le_viewname = c.map_le_viewname
				AND a.map_legrid_view_name = c.map_legrid_view_name
			)

	-- Code modification Ends for sync view
	-- Code for ListItem Mobility Starts
	DELETE a
	FROM de_nativeapp_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp c(NOLOCK)
	WHERE c.customer_name = @customer_name
		AND c.project_name = @project_name
		AND c.ico_no = @ico_no
		AND c.ecr_no = @ecr_no
		AND c.process_name = @process_name_tmp
		AND c.component_name = @component_name_tmp
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM re_published_nativeapp_mapping b(NOLOCK)
			WHERE b.customer_name = a.customer_name
				AND b.project_name = a.project_name
				AND b.rcnno = @ecr_no
				AND b.process_name = a.process_name
				AND b.component_name = a.component_name
				AND b.activity_name = a.activity_name
				AND b.ui_name = a.ui_name
				AND b.page_bt_synonym = a.page_bt_synonym
				AND b.section_bt_synonym = a.section_bt_synonym
				AND b.control_Hidden_bt_synonym = a.control_Hidden_bt_synonym
				AND b.MappedGridColumnSynonym = a.MappedGridColumnSynonym
				AND b.control_id = a.control_id   --Added against TECH-70535
				AND b.View_name = a.view_name  --Added against TECH-70535
			)

	INSERT INTO de_nativeapp_mapping (
		Customer_name,
		Project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		page_bt_synonym,
		section_bt_synonym,
		control_Hidden_bt_synonym,
		MappedGridColumnSynonym,
		ecrno,
		control_id,
		view_name,
		GridControlID,
		GridViewName,
		control_hiddenview,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate
		)
	SELECT a.Customer_name,
		a.Project_name,
		a.process_name,
		a.component_name,
		a.activity_name,
		a.ui_name,
		a.page_bt_synonym,
		a.section_bt_synonym,
		a.control_Hidden_bt_synonym,
		a.MappedGridColumnSynonym,
		@ico_no,
		a.control_id,
		a.view_name,
		a.GridControlID,
		a.GridViewName,
		a.control_hiddenview,
		a.TIMESTAMP,
		@ctxt_user,
		@date,
		@ctxt_user,
		@date
	FROM re_published_nativeapp_mapping a(NOLOCK),
		#de_rmt_ico_ui_tmp b(NOLOCK)
	WHERE b.customer_name = @customer_name
		AND b.project_name = @project_name
		AND b.ico_no = @ico_no
		AND b.ecr_no = @ecr_no
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.rcnno = b.ecr_no
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.activity_name = b.activity_name
		AND a.ui_name = b.ui_name
		AND NOT EXISTS (
			SELECT 's'
			FROM de_nativeapp_mapping c(NOLOCK)
			WHERE a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_bt_synonym
				AND a.section_bt_synonym = c.section_bt_synonym
				AND a.control_Hidden_bt_synonym = c.control_Hidden_bt_synonym
				AND a.MappedGridColumnSynonym = c.MappedGridColumnSynonym
				AND a.control_id = c.control_id  --Added against TECH-70535
				AND a.View_name = c.view_name   --Added against TECH-70535
			)

	-- Code for ListItem Mobility Ends
	--**********************************************************
	/*Code added by Gankan.G for CaseID: PNR2.0_32794  ends*/

		--Added by 11536 for the case ID TECH-66583 control Type and task type property History

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.ctrl_type_descr		         =	a.ctrl_type_descr,		
					b.base_ctrl_type                 =	a.base_ctrl_type,
					b.mandatory_flag				 =	a.mandatory_flag,				
					b.visisble_flag				     =	a.visisble_flag,				
					b.editable_flag			         =	a.editable_flag,			
					b.caption_req                    =	a.caption_req,
					b.select_flag				     =	a.select_flag,				
					b.zoom_req					     =	a.zoom_req,					
					b.insert_req				     =	a.insert_req,				
					b.delete_req                     =	a.delete_req,
					b.help_req					     =	a.help_req,					
					b.event_handling_req			 =	a.event_handling_req,			
					b.ellipses_req			         =	a.ellipses_req,			
					b.comp_ctrl_type_sysid           =	a.comp_ctrl_type_sysid,
					b.caption_alignment			     =	a.caption_alignment,			
					b.caption_position			     =	a.caption_position,			
					b.caption_wrap			         =	a.caption_wrap,			
					b.visisble_rows                  =	a.visisble_rows,
					b.ctrl_type_doc				     =	a.ctrl_type_doc,				
					b.ctrl_position				     =	a.ctrl_position,				
					b.label_class			         =	a.label_class,			
					b.ctrl_class                     =	a.ctrl_class,
					b.password_char				     =	a.password_char,				
					b.tskimg_class				     =	a.tskimg_class,				
					b.hlpimg_class			         =	a.hlpimg_class,			
					b.disponlycmb_req                =	a.disponlycmb_req,
					b.html_txt_area				     =	a.html_txt_area,				
					b.report_req					 =	a.report_req,					
					b.Auto_tab_stop			         =	a.Auto_tab_stop,			
					b.Spin_required                  =	a.Spin_required,
					b.Spin_up_image				     =	a.Spin_up_image,				
					b.Spin_down_image			     =	a.Spin_down_image,			
					b.InPlace_Calendar		         =	a.InPlace_Calendar,		
					b.EditMask                       =	a.EditMask,
					b.NoofLinesPerRow			     =	a.NoofLinesPerRow,			
					b.RowHeight					     =	a.RowHeight,					
					b.Vscrollbar_Req			     =	a.Vscrollbar_Req,			
					b.Is_Extjs_Control               =	a.Is_Extjs_Control,
					b.Extjs_Ctrl_type			     =	a.Extjs_Ctrl_type,			
					b.gridlite_req				     =	a.gridlite_req,				
					b.bulletlink_req			     =	a.bulletlink_req,			
					b.buttoncombo_req                =	a.buttoncombo_req,
					b.associatedlist_req			 =	a.associatedlist_req,			
					b.onfocustask_req			     =	a.onfocustask_req,			
					b.listrefilltask_req		     =	a.listrefilltask_req,		
					b.attach_document                =	a.attach_document,
					b.image_upload				     =	a.image_upload,				
					b.inplace_image				     =	a.inplace_image,				
					b.listedit_noofcolumns	         =	a.listedit_noofcolumns,	
					b.image_row_height               =	a.image_row_height,
					b.relative_url_path			     =	a.relative_url_path,			
					b.relative_document_path		 =	a.relative_document_path,		
					b.relative_image_path	         =	a.relative_image_path,	
					b.save_doc_content_to_db         =	a.save_doc_content_to_db,
					b.save_image_content_to_db	     =	a.save_image_content_to_db,	
					b.dataascaption				     =	a.dataascaption,				
					b.image_icon				     =	a.image_icon,				
					b.Date_highlight                 =	a.Date_highlight,
					b.ezee_report				     =	a.ezee_report,				
					b.Lite_Attach_Document		     =	a.Lite_Attach_Document,		
					b.Browse_Button_Enable	         =	a.Browse_Button_Enable,	
					b.Delete_Button_Enable           =	a.Delete_Button_Enable,
					b.image_row_width			     =	a.image_row_width,			
					b.image_preview_height		     =	a.image_preview_height,		
					b.image_preview_width	         =	a.image_preview_width,	
					b.image_preview_req              =	a.image_preview_req,
					b.Lite_Attach_Image			     =	a.Lite_Attach_Image,			
					b.timezone					     =	a.timezone,					
					b.autoexpand				     =	a.autoexpand,				
					b.Disp_Only_Apply_Len            =	a.Disp_Only_Apply_Len,
					b.editcombo_req				     =	a.editcombo_req,				
					b.Label_Link					 =	a.Label_Link,					
					b.captiontype			         =	a.captiontype,			
					b.controlstyle                   =	a.controlstyle,
					b.IsListBox					     =	a.IsListBox,					
					b.Toolbar_Not_Req			     =	a.Toolbar_Not_Req,			
					b.ColumnBorder_Not_Req	         =	a.ColumnBorder_Not_Req,	
					b.RowBorder_Not_Req              =	a.RowBorder_Not_Req,
					b.PagenavigationOnly			 =	a.PagenavigationOnly,			
					b.RowNO_Not_Req				     =	a.RowNO_Not_Req,				
					b.ButtonHome_Req			     =	a.ButtonHome_Req,			
					b.ButtonPrevious_Req             =	a.ButtonPrevious_Req,
					b.Accpet_Type				     =	a.Accpet_Type,				
					b.combo_link					 =	a.combo_link,					
					b.QR_Image				         =	a.QR_Image,				
					b.Tooltip_Not_Req                =	a.Tooltip_Not_Req,
					b.Forcefit					     =	a.Forcefit,					
					b.columncaption_Not_Req		     =	a.columncaption_Not_Req	,	
					b.Border_Not_Req			     =	a.Border_Not_Req,			
					b.IsModal                        =	a.IsModal,
					b.Alternate_Color_Req		     =	a.Alternate_Color_Req,		
					b.Map_In_Req					 =	a.Map_In_Req,					
					b.Map_Out_Req			         =	a.Map_Out_Req,			
					b.Barcode_Image                  =	a.Barcode_Image,
					b.Isfallback					 =	a.Isfallback,					
					b.config_parameter			     =	a.config_parameter,			
					b.config_value			         =	a.config_value,			
					b.upload                         =	a.upload,
					b.Is_Varbinary				     =	a.Is_Varbinary,				
					b.FileSize					     =	a.FileSize,					
					b.EMail					         =	a.EMail,					
					b.Phone                          =	a.Phone,
					b.StaticCaption				     =	a.StaticCaption,				
					b.Datagrid					     =	a.Datagrid,					
					b.MoveFirst				         =	a.MoveFirst,			
					b.Move_PrevSet                   =	a.Move_PrevSet,
					b.Move_Previous				     =	a.Move_Previous,				
					b.Move_Next					     =	a.Move_Next,					
					b.Move_NextSet			         =	a.Move_NextSet,			
					b.Move_Last                      =	a.Move_Last,
					b.Carousel_Req				     =	a.Carousel_Req,				
					b.Orientation				     =	a.Orientation,				
					b.WrapCount				         =	a.WrapCount,				
					b.Box_Type                       =	a.Box_Type,
					b.ISDeviceInfo				     =	a.ISDeviceInfo,				
					b.ListControl				     =	a.ListControl,				
					b.col_caption_align		         =	a.col_caption_align,		
					b.Gridheaderstyle                =	a.Gridheaderstyle,
					b.Gridtoolbarstyle			     =	a.Gridtoolbarstyle,			
					b.preevent					     =	a.preevent,					
					b.postevent				         =	a.postevent,				
					b.norowstodisplay_notreq         =	a.norowstodisplay_notreq,
					b.col_data_align				 =	a.col_data_align,				
					b.avn_download				     =	a.avn_download,				
					b.PreventDownload		         =	a.PreventDownload,		
					b.ishijri                        =	a.ishijri,
					b.slider_type				     =	a.slider_type,				
					b.max_value					     =	a.max_value,					
					b.min_value				         =	a.min_value,				
					b.step_value                     =	a.step_value,
					b.spin_system_task			     =	a.spin_system_task,			
					b.enabledefault				     =	a.enabledefault,				
					b.hideinsert				     =	a.hideinsert,				
					b.hidedelete                     =	a.hidedelete,
					b.hidecopy					     =	a.hidecopy,					
					b.hidecut					     =	a.hidecut,					
					b.hidefilterdata			     =	a.hidefilterdata,			
					b.hidepdf                        =	a.hidepdf,
					b.hidereport					 =	a.hidereport,					
					b.hidehtml					     =	a.hidehtml,					
					b.hideexportexcel		         =	a.hideexportexcel,		
					b.hideexportcsv                  =	a.hideexportcsv,
					b.hideexporttext				 =	a.hideexporttext,				
					b.hideimportdata				 =	a.hideimportdata,				
					b.hidechart				         =	a.hidechart,				
					b.hideexportopenoffice           =	a.hideexportopenoffice,
					b.hidepersonalize			     =	a.hidepersonalize,			
					b.hidefiltercolumn			     =	a.hidefiltercolumn,			
					b.searchhide				     =	a.searchhide,				
					b.autolist_not_req               =	a.autolist_not_req,
					b.hideselect					 =	a.hideselect,					
					b.AutoHeight					 =	a.AutoHeight,					
					b.IsPivot				         =	a.IsPivot,				
					b.QlikLink                       =	a.QlikLink,
					b.RangeMinimum				     =	a.RangeMinimum,				
					b.RangeMaximum				     =	a.RangeMaximum,				
					b.RangeStartValue		         =	a.RangeStartValue,		
					b.RangeEndValue                  =	a.RangeEndValue,
					b.RangeStep					     =	a.RangeStep,					
					b.RangeLabel					 =	a.RangeLabel,					
					b.RangeSelect			         =	a.RangeSelect,			
					b.ValueShown                     =	a.ValueShown,
					b.Style						     =	a.Style,						
					b.SystemGeneratedFileId		     =	a.SystemGeneratedFileId,		
					b.IsMarquee				         =	a.IsMarquee,				
					b.IsAssorted                     =	a.IsAssorted,
					b.RatingType					 =	a.RatingType,					
					b.CaptchaData				     =	a.CaptchaData,				
					b.rangetype				         =	a.rangetype,				
					b.RenderAs                       =	a.RenderAs,
					b.noofrowsselected_req		     =	a.noofrowsselected_req,		
					b.AttachmentWithDesc			 =	a.AttachmentWithDesc,			
					b.preserve_gridposition	         =	a.preserve_gridposition,	
					b.Image_Accept_Type              =	a.Image_Accept_Type,
					b.Accept_Type				     =	a.Accept_Type,				
					b.file_Accept_Type			     =	a.file_Accept_Type,			
					b.MlsearchOnly			         =	a.MlsearchOnly,			
					b.hidecolumnchooser              =	a.hidecolumnchooser
			FROM	re_published_comp_ctrl_type_mst a,
					de_comp_ctrl_type_mst b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.ctrl_type_name	=	a.ctrl_type_name 
			
			AND		a.Customer_Name		=	@customer_name
			AND		a.Project_Name		=	@project_name
			AND		a.Process_Name		=	@process_name_tmp
			AND		a.Component_Name	=	@component_name_tmp
			AND		a.rcnno				=	@ecr_no	

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.ctrl_type_descr                =	a.ctrl_type_descr,
					b.base_ctrl_type                 =	a.base_ctrl_type,
					b.Configuration                  =	a.Configuration,
					b.SliderType                     =	a.SliderType,
					b.SliderBehaviour                =	a.SliderBehaviour,
					b.RenderType                     =	a.RenderType,
					b.Orientation                    =	a.Orientation,
					b.Startvalue                     =	a.Startvalue,
					b.Endvalue                       =	a.Endvalue,
					b.Minvalue                       =	a.Minvalue,
					b.Maxvalue                       =	a.Maxvalue,
					b.Stepvalue                      =	a.Stepvalue,
					b.SliderValue                    =	a.SliderValue,
					b.Showvalue                      =	a.Showvalue,
					b.ShowTooltip                    =	a.ShowTooltip,
					b.Rangelabel                     =	a.Rangelabel,
					b.Rangevalue                     =	a.Rangevalue,
					b.Rangetooltip                   =	a.Rangetooltip,
					b.RangeSelect                    =	a.RangeSelect,
					b.ValueShown                     =	a.ValueShown,
					b.ExpandEvent                    =	a.ExpandEvent,
					b.ExpandAllEvent                 =	a.ExpandAllEvent,
					b.CollapseEvent                  =	a.CollapseEvent,
					b.CollapseAllEvent               =	a.CollapseAllEvent,
					b.ClickEvent                     =	a.ClickEvent,
					b.DDToolTip                      =	a.DDToolTip,
					b.ZoomMin                        =	a.ZoomMin,
					b.ZoomMax                        =	a.ZoomMax,
					b.DefaultZoom                    =	a.DefaultZoom,
					b.ZoomStep                       =	a.ZoomStep,
					b.NodeWidth                      =	a.NodeWidth,
					b.NodeHeight                     =	a.NodeHeight,
					b.DefaultFile                    =	a.DefaultFile,
					b.IsOrgChart                     =	a.IsOrgChart,
					b.checkevent                     =	a.checkevent,
					b.bufferedrows                   =	a.bufferedrows,
					b.SparkChartType                 =	a.SparkChartType,
					b.ChartType                      =	a.ChartType,
					b.Delayedpwdmask                 =	a.Delayedpwdmask,
					b.preserve_gridposition          =	a.preserve_gridposition,
					b.Dynamicfileupload              =	a.Dynamicfileupload,
					b.ServerSidePrint                =	a.ServerSidePrint,
					b.MultiFileSelect                =	a.MultiFileSelect,
					b.NoofCtrlPerLine                =	a.NoofCtrlPerLine,
					b.FormWidth                      =	a.FormWidth,
					b.ControlWidth                   =	a.ControlWidth,
					b.LabelWidth                     =	a.LabelWidth,
					b.MetaDataBasedLink              =	a.MetaDataBasedLink,
					b.LabelAlignment                 =	a.LabelAlignment,
					b.Scan                           =	a.Scan,
					b.Autoselect                     =	a.Autoselect,
					b.IsList                         =	a.IsList,
					b.MultiSelect                    =	a.MultiSelect,
					b.SelectedRowcount               =	a.SelectedRowcount,
					b.DockedItem                     =	a.DockedItem,
					b.NFCEnabled                     =	a.NFCEnabled,
					b.AutoScan                       =	a.AutoScan,
					b.IsToggle                       =	a.IsToggle,
					b.NodeIconReqd                   =	a.NodeIconReqd,
					b.NodeCustomClass                =	a.NodeCustomClass,
					b.IsDocked                       =	a.IsDocked,
					b.RuleBuilder                    =	a.RuleBuilder,
					b.MultiSelectComboforRB          =	a.MultiSelectComboforRB,
					b.CalendarControl                =	a.CalendarControl,
					b.Setfocusevent                  =	a.Setfocusevent,
					b.Leavefocusevent                =	a.Leavefocusevent,
					b.GanttControl                   =	a.GanttControl,
					b.AutoSync                       =	a.AutoSync,
					b.SetFocusEventOccurence         =	a.SetFocusEventOccurence,
					b.LeaveFocusEventOccurence       =	a.LeaveFocusEventOccurence,
					b.IsChips                        =	a.IsChips,
					b.IsSpellcheck                   =	a.IsSpellcheck,
					b.DirectPrint                    =	a.DirectPrint,
					b.ListItemExpander               =	a.ListItemExpander,
					b.ReadOnly                       =	a.ReadOnly,
					b.ShowTodayLine                  =	a.ShowTodayLine,
					b.ShowRollupTasks                =	a.ShowRollupTasks,
					b.ShowProjectLines               =	a.ShowProjectLines,
					b.SkipWeekendsDuringDragDrop     =	a.SkipWeekendsDuringDragDrop,
					b.LockedGridWidth                =	a.LockedGridWidth,
					b.RowHeight                      =	a.RowHeight,
					b.BottomLabelField               =	a.BottomLabelField,
					b.TopLabelField                  =	a.TopLabelField,
					b.LeftLabelField                 =	a.LeftLabelField,
					b.RightLabelField                =	a.RightLabelField,
					b.RollupLabelField               =	a.RollupLabelField,
					b.Baseline                       =	a.Baseline,
					b.ScrollToDateCentered           =	a.ScrollToDateCentered,
					b.Zoom                           =	a.Zoom,
					b.Fit                            =	a.Fit,
					b.Export                         =	a.Export,
					b.Highlight                      =	a.Highlight,
					b.Indent                         =	a.Indent,
					b.ContextMenu                    =	a.ContextMenu,
					b.PopupTaskEditor                =	a.PopupTaskEditor,
					b.GanttShift                     =	a.GanttShift,
					b.GanttExpand                    =	a.GanttExpand,
					b.GanttInsert                    =	a.GanttInsert,
					b.GanttDelete                    =	a.GanttDelete,
					b.Calendar                       =	a.Calendar,
					b.IsScheduler                    =	a.IsScheduler,
					b.ListItemType                   =	a.ListItemType,
					b.IsSelectionReqdList            =	a.IsSelectionReqdList,
					b.RowAlwaysExpanded              =	a.RowAlwaysExpanded,
					b.IsMobile                       =	a.IsMobile,
					b.PaginationReqd                 =	a.PaginationReqd,
					b.UpdateTaskReqd                 =	a.UpdateTaskReqd,
					b.DeleteTaskReqd                 =	a.DeleteTaskReqd,
					b.ShowLines						 =	a.ShowLines,	--TECH-68066
					b.PreTask						 =	a.PreTask,		--TECH-68066
					b.PostTask						 =	a.PostTask,		--TECH-68066
					b.BulkDownload					 =	a.BulkDownload,	--TECH-68067
					--Code added for TECH-69624 starts
					b.HideRuleHeader				 =	a.HideRuleHeader,
					b.HideANDOperator				 =	a.HideANDOperator,
					b.HideOROperator				 =	a.HideOROperator,
					b.HideNOTOperator				 =	a.HideNOTOperator,
					b.HideGroupOperator				 =	a.HideGroupOperator,
					b.HideRuleOperator				 =	a.HideRuleOperator,
					b.SelectOnlyListValues			 =	a.SelectOnlyListValues,					
					--Code added for TECH-69624 ends
					--Code added for TECH-71262 on 14July22 starts
					b.BrowsePreTask					 =	a.BrowsePreTask,
					b.BrowsePostTask				 =	a.BrowsePostTask,
					b.DeletePreTask					 =	a.DeletePreTask,
					b.DeletePostTask				 =	a.DeletePostTask,
					b.ButtonStyle					 =	a.ButtonStyle,
					--Code added for TECH-71262 on 14July22 ends
					b.BadgeText						 =	a.BadgeText,	--code added by  Tech-72114 
					b.AutoHeight					 =	a.AutoHeight,		--code added by  Tech-72114
					--Code added for TECH-73996 starts
					b.EyeIconForPassword			 =	a.EyeIconForPassword,		
					b.Signature						 =	a.Signature,					
					b.KeyupSearch					 =	a.KeyupSearch,				
					b.Stepper						 =	a.Stepper,					
					b.LiveClock						 =	a.LiveClock,					
					b.ClearTask						 =	a.ClearTask,					
					b.ShowAnimation					 =	a.ShowAnimation,				
					b.PreventMultipleRowSelection 	 =	a.PreventMultipleRowSelection,
					b.PreviousCount					 =	a.PreviousCount		
					--Code added for TECH-73996 ends
			FROM	re_published_comp_ctrl_type_mst_extn a,
					de_comp_ctrl_type_mst_extn b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.ctrl_type_name	=	a.ctrl_type_name 
			
			AND		a.Customer_Name		=	@customer_name
			AND		a.Project_Name		=	@project_name
			AND		a.Process_Name		=	@process_name_tmp
			AND		a.Component_Name	=	@component_name_tmp
			AND		a.rcnno				=	@ecr_no	

			UPDATE	b
			SET		b.ModifiedBy					 =	@Ctxt_User,
					b.ModifiedDate					 =	GETDATE(),
					b.task_type_descr	             =	a.task_type_descr,	                     
					b.default_for                    =	a.default_for,                        
					b.refresh_on_save			     =	a.refresh_on_save,			             
					b.valid_on_init				     =	a.valid_on_init,				     
					b.err_handle_method	             =	a.err_handle_method,             
					b.incl_place_holder              =	a.incl_place_holder,                  
					b.cond_ml_fetch				     =	a.cond_ml_fetch,				     
					b.clr_on_page_save			     =	a.clr_on_page_save,			     
					b.hdr_fetch_req		             =	a.hdr_fetch_req,		             
					b.ml_fet_req                     =	a.ml_fet_req,                         
					b.hdr_ref_req				     =	a.hdr_ref_req,				             
					b.hdr_check_req				     =	a.hdr_check_req,				     
					b.proc_sel_rows		             =	a.proc_sel_rows,		             
					b.usr_role_map                   =	a.usr_role_map,                       
					b.trn_scope_req				     =	a.trn_scope_req,				     
					b.comp_task_type_sysid		     =	a.comp_task_type_sysid,		     
					b.task_type_doc		             =	a.task_type_doc,		             
					b.hdr_save_req                   =	a.hdr_save_req,                       
					b.ml_save_req				     =	a.ml_save_req,				             
					b.fprowno_req				     =	a.fprowno_req,				             
					b.cbdef_req			             =	a.cbdef_req,			             
					b.no_placeholder                 =	a.no_placeholder,                     
					b.data_save_req				     =	a.data_save_req,				     
					b.print_req					     =	a.print_req,					     
					b.task_confirmation	             =	a.task_confirmation,	             
					b.Logic_Extensions               =	a.Logic_Extensions,                   
					b.process_updrows			     =	a.process_updrows,			             
					b.alternate_db				     =	a.alternate_db,				     
					b.sys_proc_sel_rows	             =	a.sys_proc_sel_rows,             
					b.sys_process_updrows            =	a.sys_process_updrows,                
					b.Linkasui					     =	a.Linkasui,					     
					b.Uiastrans					     =	a.Uiastrans,					     
					b.MLSaveSinglesegment            =	a.MLSaveSinglesegment,              
					b.sys_proc_selupd_rows           =	a.sys_proc_selupd_rows,
					b.CurrentContextInformation	     =	a.CurrentContextInformation,	
					b.ParentContextInformation	     =	a.ParentContextInformation,	
					b.ModeflagEnabled	             =	a.ModeflagEnabled,	
					b.BulkValidation                 =	a.BulkValidation,
					b.BubbleMessage					 =	a.BubbleMessage		--TECH-74150
			FROM	re_published_comp_task_type_mst a,
					de_comp_task_type_mst b
			WHERE	b.Customer_Name		=	a.Customer_Name
			AND		b.Project_Name		=	a.Project_Name
			AND		b.Process_Name		=	a.Process_Name
			AND		b.Component_Name	=	a.Component_Name
			AND		b.task_type_name	=	a.task_type_name 
			
			AND		a.Customer_Name		=	@customer_name
			AND		a.Project_Name		=	@project_name
			AND		a.Process_Name		=	@process_name_tmp
			AND		a.Component_Name	=	@component_name_tmp
			AND		a.rcnno				=	@ecr_no	

		INSERT INTO de_comp_ctrl_type_mst
			(	customer_name,				project_name,				ecrno,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					createddate,				modifiedby,				modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@ico_no,				process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				@ctxt_user,					GETDATE(),					@ctxt_user,				GETDATE()
		FROM	re_published_comp_ctrl_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name
		AND		Project_Name		=	@project_name
		AND		Process_Name		=	@process_name_tmp
		AND		Component_Name		=	@component_name_tmp
		AND		rcnno				=	@ecr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	de_comp_ctrl_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.ctrl_type_name	=	a.ctrl_type_name  )

		INSERT INTO de_comp_ctrl_type_mst_extn
			(	customer_name,				project_name,				ecrno,				process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
				Configuration,				SliderType,					SliderBehaviour,	RenderType,
				Orientation,				Startvalue,					Endvalue,			Minvalue,
				Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
				ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
				RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
				CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
				ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
				NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
				checkevent,					bufferedrows,				SparkChartType,		ChartType,
				Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
				MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
				LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
				Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
				DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
				NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
				MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
				GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
				IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
				ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
				SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
				TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
				Baseline,					ScrollToDateCentered,		Zoom,				Fit,
				Export,						Highlight,					Indent,				ContextMenu,
				PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
				GanttDelete,				Calendar,					IsScheduler,		ListItemType,
				IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
				UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
				createdby,					createddate,				modifiedby,			modifieddate,
				ShowLines,					PreTask,					PostTask,			BulkDownload,	--TECH-68066	--TECH-68067
				HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
				HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, 	--Code added for TECH-69624 
				BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
				ButtonStyle,				BadgeText,					AutoHeight,--Code added for TECH-71262 on 14July22	--Tech-72114
				--Code added for TECH-73996 starts
				EyeIconForPassword,			Signature,					KeyupSearch,		Stepper,					
				LiveClock,					ClearTask,					ShowAnimation,		PreventMultipleRowSelection, 
				PreviousCount	)			
				--Code added for TECH-73996 ends
			SELECT DISTINCT
				customer_name,				project_name,				@ico_no,			process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
				Configuration,				SliderType,					SliderBehaviour,	RenderType,
				Orientation,				Startvalue,					Endvalue,			Minvalue,
				Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
				ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
				RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
				CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
				ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
				NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
				checkevent,					bufferedrows,				SparkChartType,		ChartType,
				Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
				MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
				LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
				Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
				DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
				NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
				MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
				GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
				IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
				ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
				SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
				TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
				Baseline,					ScrollToDateCentered,		Zoom,				Fit,
				Export,						Highlight,					Indent,				ContextMenu,
				PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
				GanttDelete,				Calendar,					IsScheduler,		ListItemType,
				IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
				UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE(),
				ShowLines,					PreTask,					PostTask,			BulkDownload,	--TECH-68066
				HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
				HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues,	--Code added for TECH-69624 
				BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
				ButtonStyle,				BadgeText,					AutoHeight,	--Code added for TECH-71262 on 14July22		-- Tech-72114
				--Code added for TECH-73996 starts
				EyeIconForPassword,			Signature,					KeyupSearch,		Stepper,					
				LiveClock,					ClearTask,					ShowAnimation,		PreventMultipleRowSelection, 
				PreviousCount				
				--Code added for TECH-73996 ends
		FROM	re_published_comp_ctrl_type_mst_extn a (NOLOCK)
		WHERE	Customer_Name		=	@customer_name
		AND		Project_Name		=	@project_name
		AND		Process_Name		=	@process_name_tmp
		AND		Component_Name		=	@component_name_tmp
		AND		rcnno				=	@ecr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	de_comp_ctrl_type_mst_extn b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.ctrl_type_name	=	a.ctrl_type_name  )

		INSERT INTO de_comp_task_type_mst
			(	customer_name,				project_name,				ecrno,				process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,	--TECH-74150
				createdby,					createddate,				modifiedby,			modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@ico_no,			process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,	--TECH-74150
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE()
		FROM	re_published_comp_task_type_mst a(NOLOCK)
		WHERE	Customer_Name		=	@customer_name
		AND		Project_Name		=	@project_name
		AND		Process_Name		=	@process_name_tmp
		AND		Component_Name		=	@component_name_tmp
		AND		rcnno				=	@ecr_no
		AND NOT EXISTS (	SELECT 'X'
							FROM	de_comp_task_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.task_type_name	=	a.task_type_name )


		--case ID TECH-66583 Ends

	SET NOCOUNT OFF
END
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_populate_downloadico' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_populate_downloadico TO PUBLIC
END
GO

