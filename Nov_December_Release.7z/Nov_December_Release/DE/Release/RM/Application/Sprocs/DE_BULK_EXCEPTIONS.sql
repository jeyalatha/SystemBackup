/************************************************************************************
Procedure name					: DE_BULK_EXCEPTIONS  
Description						: To Trace the Bulk Exceptions for Component at ECR level
Author							: Deepika S 										 
Date							: 08-Nov-2022										 
*************************************************************************************/

Create PROCEDURE DE_BULK_EXCEPTIONS
@customer_name	engg_name,		---INPUT
@project_name	engg_name,    	---INPUT
@proc_name		engg_name,    	---INPUT
@comp_name		engg_name  		---INPUT
AS
BEGIN
SET NOCOUNT ON
--null checking    
IF ISNULL(@customer_name,'') = ''      
BEGIN      
RAISERROR ('Customer name canNOT be blank.', 16,1)      
RETURN      
END      
      
IF ISNULL(@project_name,'') = ''      
BEGIN      
RAISERROR('Project Name canNOT be blank.', 16,1)      
RETURN      
END       
    
IF ISNULL(@proc_name,'') = ''      
BEGIN      
RAISERROR('Process Name canNOT be blank.', 16,1)      
RETURN      
END       
     
IF ISNULL(@comp_name,'') = ''      
BEGIN      
RAISERROR('Component Name canNOT be blank.', 16,1)      
RETURN      
END       

SELECT DISTINCT  'Dataitem "' +a.dataitemname+'" is involved in both Ilbo mapping AND Control attribute mapping for the segment "'+a.segmentname+'" against service "'+a.servicename+'"' 'Error Description'
		 FROM	de_fw_des_ilbo_service_view_attributemap a(NOLOCK),
		
				de_fw_des_ilbo_service_view_datamap b (NOLOCK)
					WHERE a.customer_name = @customer_name
					AND a.project_name = @project_name
					AND a.process_name = @proc_name
					AND a.component_name = @comp_name
				--	AND servicename = @service_name
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.servicename = b.servicename
					AND a.segmentname = b.segmentname
					AND a.dataitemname = b.dataitemname


UNION
-----------------------2-----------------------------------------------------------------------------
SELECT  'Dataitem does NOT EXISTS For the Service ' + a.servicename +'.Pls Define the dataitem AND proceed.'    'Error Description' 
FROM    de_fw_des_processsection_br_is a(NOLOCK)      
WHERE a.customer_name    = @customer_name      
AND  a.project_name		 = @project_name      
AND   a.process_name	 = @proc_name      
AND   a.component_name   = @comp_name      
AND     NOT EXISTS (SELECT 'x' FROM de_fw_des_service_dataitem     b(NOLOCK)      
WHERE a.customer_name    = b.customer_name      
AND   a.project_name     = b.project_name      
AND   a.process_name     = b.process_name      
AND   a.component_name   = b.component_name      
AND   a.servicename      = b.servicename)      
AND     EXISTS   (SELECT 'x' FROM  de_fw_des_ilbo_service_view_datamap c (NOLOCK)      
WHERE a.customer_name    = c.customer_name      
AND   a.project_name     = c.project_name      
AND   a.process_name     = c.process_name      
AND   a.component_name   = c.component_name      
AND   a.servicename      = c.servicename)    
UNION  
-----------------------------------------3---------------------------------------------------------------------
SELECT  'For the service:"'+ a.servicename + '"under the segment:"' + a.segmentname + '"the dataitemname:"'+ a.dataitemname+ '" contain spaces'      		'Error Description'
FROM   de_fw_des_service_dataitem a(NOLOCK)      
WHERE   a.customer_name  = @customer_name      
AND		a.project_name   = @project_name      
AND		a.process_name   = @proc_name      
AND		a.component_name = @comp_name      
AND     CHARINDEX(' ',a.dataitemname) <> 0   
-----------------------------------------4---------------------------------------------------------------------------
 UNION  

 
 SELECT 'For The Activity ' + activity_name +'in the UI '+ ui_name +' The Following task ' +action_name +' Has More Than One Main Report'      'Error Description'
    
From de_report_action_dataset_segment a (Nolock)      
Where Customer_Name = @customer_name      
and  Project_Name = @project_name      
and  Process_Name = @proc_name      
and  Component_Name = @comp_name      
and  exists   (      
Select 'x'      
From de_report_action_dataset_segment b (Nolock)      
Where Customer_Name = @customer_name      
and  Project_Name = @project_name      
and  Process_Name = @proc_name      
and  Component_Name = @comp_name      
and  segment_instance = 'Multiple'      
and  sub_report  = 'No'      
and  a.activity_name = b.activity_name      
and  b.ui_name  = a.ui_name      
and  b.action_name = a.action_name      
Group by ui_name, action_name      
Having count(distinct dataset_name) > 1    )  

 UNION

------------------------------5----------------------------------------------------------------------------------------
SELECT 'Atleast one Report Task should be present for the ILBO: ' + ISNULL(a.ui_name,'') + ' Since ''Configure Alternate Database'' option is used in Action Pattern'  'Error Description'
FROM de_action a(NOLOCK),      
  es_comp_task_type_mst_vw b(NOLOCK)      
WHERE a.Customer_Name  = @customer_name      
AND  a.Project_Name  = @project_name      
AND  a.Process_Name  = @proc_name      
AND  a.Component_Name = @comp_name      
      
AND  a.customer_name  = b.customer_name      
AND  a.project_name  = b.project_name      
AND  a.process_name  = b.process_name      
AND  a.component_name = b.component_name      
AND  a.task_pattern  = b.task_type_name      
AND  ISNULL(b.alternate_db,'N')= 'Y'      
      
AND  NOT EXISTS (SELECT 'x'      
   FROM de_action c(NOLOCK),     
     de_task_service_map d (NOLOCK)      
   WHERE c.Customer_Name  = @customer_name      
   AND  c.Project_Name  = @project_name      
   AND  c.Process_Name  = @proc_name      
   AND  c.Component_Name = @comp_name      
      
   AND  c.customer_name = a.customer_name      
   AND  c.project_name = a.project_name      
   AND  c.process_name = a.process_name      
   AND  c.component_name= a.component_name      
   AND  c.activity_name = a.activity_name      
   AND  c.ui_name  = a.ui_name      
   AND  c.task_type  = 'Report'      
         
   AND  c.customer_name = d.customer_name      
   AND  c.project_name = d.project_name      
   AND  c.process_name = d.process_name      
   AND  c.component_name= d.component_name      
   AND  c.activity_name = d.activity_name      
   AND  c.ui_name  = d.ui_name      
   AND  c.task_name  = d.task_name     )

   UNION
   ------------------------------------------------------------------6------------------------------------------------------
   SELECT  'SP ERROR CODE IS DUPLICATED FOR THE METHOD :' + method_name +'. CHANGE AND PROCEED' 'Error Description'
   FROM de_fw_des_brerror (NOLOCK)      
WHERE  customer_name  = @customer_name      
AND  project_name = @project_name      
AND   process_name  = @proc_name      
AND   component_name  = @comp_name      
GROUP BY component_name, methodid, method_name, sperrorcode      
HAVING COUNT (*) > 1  
UNION
------------------------------------------------7-------------------------------------------------------------
SELECT 'One or more Subscription EXISTS For Control'+control_bt_synonym+'.'  'Error Description'
FROM de_subscription (NOLOCK)      
WHERE  customer_name  = @customer_name      
AND   project_name  = @project_name      
AND   process_name  = @proc_name      
AND   component_name  = @comp_name      
GROUP BY  customer_name, project_name,      
process_name, component_name,      
activity_name, ui_name,      
page_bt_synonym,control_bt_synonym      
HAVING COUNT(*) > 1      
UNION
---------------------------------------------------8---------------------------------------------------------------
select 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym'+b.bt_synonym_name+' ' 'Error Description'
from  de_ui     a(nolock),      
de_glossary b  
where  a.customer_name    =  @customer_name      
and   a.project_name    =  @project_name      
and   a.process_name    =  @proc_name      
and   a.component_name    =  @comp_name      
and  a.customer_name    =  b.customer_name      
and   a.project_name    =  b.project_name      
and   a.process_name    =  b.process_name      
and   a.component_name    =  b.component_name      
and  a.component_name = b.bt_synonym_name      
and  len(bt_synonym_caption) > 60      
union      
select 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym'+b.bt_synonym_name+' ' 'Error Description'
from  de_ui     a(nolock),      
de_glossary b  (nolock)
where  a.customer_name    =  @customer_name      
and   a.project_name    =  @project_name      
and   a.process_name    =  @proc_name      
and   a.component_name    =  @comp_name      
and  a.customer_name    =  b.customer_name      
and   a.project_name    =  b.project_name      
and   a.process_name    =  b.process_name      
and   a.component_name    =  b.component_name      
and  a.activity_name  = b.bt_synonym_name      
and  len(bt_synonym_caption) > 60      
union      
select 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym'+b.bt_synonym_name+' ' 'Error Description'
from  de_ui     a(nolock),      
de_glossary b  (nolock)
where  a.customer_name    =  @customer_name      
and   a.project_name    =  @project_name      
and   a.process_name    =  @proc_name      
and   a.component_name    =  @comp_name      
and  a.customer_name    =  b.customer_name      
and   a.project_name    =  b.project_name      
and   a.process_name    =  b.process_name      
and   a.component_name    =  b.component_name      
and  a.ui_name   = b.bt_synonym_name      
and  len(bt_synonym_caption) > 60      
union      
select 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym'+c.bt_synonym_name+' ' 'Error Description'
from  de_ui_control     a(nolock),      
es_comp_ctrl_type_mst   b(nolock),      
de_glossary  c  
where  a.customer_name		=  @customer_name      
and   a.project_name		= @project_name      
and   a.process_name		=  @proc_name      
and   a.component_name		=  @comp_name      
and   a.customer_name		=  b.customer_name      
and   a.project_name		=  b.project_name      
and   a.process_name		=  b.process_name      
and   a.component_name		=  b.component_name      
and   a.control_type		=  b.ctrl_type_name      
and   a.customer_name		=  c.customer_name      
and   a.project_name		=  c.project_name      
and   a.process_name     =  c.process_name      
and   a.component_name    =  c.component_name      
and   a.control_bt_synonym    =  c.bt_synonym_name      
and   b.base_ctrl_type    <> 'label'      
--and  len(bt_synonym_caption) > 60      
and  len(bt_synonym_caption) > 120 
union      
select 'Length of BT Synonym Caption(S) Exceeds 60  Characters for the Synonym'+b.bt_synonym_name+' ' 'Error Description'
from  de_ui_grid    a(nolock),      
de_glossary b  
where  a.customer_name    =  @customer_name      
and   a.project_name    =  @project_name      
and   a.process_name    =  @proc_name      
and   a.component_name    =  @comp_name      
and  a.customer_name    =  b.customer_name      
and   a.project_name    =  b.project_name      
and   a.process_name    =  b.process_name      
and   a.component_name    =  b.component_name      
and  a.column_bt_synonym = b.bt_synonym_name      
and  len(bt_synonym_caption) > 60      
      
Union--deck
---------------------------------------------------9---------------------------------------------------------------
SELECT 'For the Numeric BT "'+a.bt_name+'", precision canNOT be Blank'	'Error Description'
FROM de_glossary  a,       
de_business_term b(NOLOCK)      
WHERE a.customer_name = b.customer_name      
AND a.project_name = b.project_name      
AND a.process_name = b.process_name      
AND a.component_name= b.component_name      
AND a.bt_name = b.bt_name  
AND b.data_type = 'numeric'      
AND a.customer_name = @customer_name      
AND   a.project_name  = @project_name      
AND   a.process_name  = @proc_name      
AND   a.component_name= @comp_name      
AND ISNULL(b.precision_type,'') = ''   

UNION  
-------------------------------------------------10----------------------------------------------------------------------------
SELECT   'Some of the Business Terms for the component has zero LENGTH.'        'Error Description'
FROM de_business_term (NOLOCK)      
WHERE customer_name  = @customer_name      
AND  project_name  = @project_name      
AND  process_name   = @proc_name      
AND  component_name  = @comp_name   
AND   data_type in ('numeric','int','integer')  
AND  ISNULL(LENGTH, 0) = 0
--------------------------------------------------11----------------------------------------------------------------------------
UNION
SELECT 'For the btsynonym  "' + a.bt_name + '" the mapped Precision type "'+  a.precision_type +'" is NOT Defined for the Component.'        'Error Description'
FROM de_business_term a(NOLOCK)        
WHERE a.customer_name = @customer_name        
AND  a.project_name =   @project_name        
AND  a.process_name =   @proc_name        
AND  a.component_name = @comp_name        
AND   ISNULL(a.precision_type, '') <> ''        
AND  a.precision_type NOT in (SELECT DISTINCT b.pt_name        
FROM de_precision_type b (NOLOCK)        
WHERE   b.customer_name = a.customer_name        
AND  b.project_name  = a.project_name        
AND  b.process_name = a.process_name        
AND  b.component_name =a.component_name )  

--------------------------------------------------12----------------------------------------------------------------------------
UNION
SELECT 'For the Subscription '+ subscription_name +' Task Name is NOT defined'       'Error Description' 
FROM de_subscription c (NOLOCK)        
WHERE c.customer_name  = @customer_name        
AND  c.project_name  =   @project_name        
AND  c.component_name =  @comp_name        
AND  NOT EXISTS (  SELECT 's'        
FROM de_action  d (NOLOCK)        
WHERE d.customer_name  = c.customer_name        
AND  d.project_name  = c.project_name        
AND  d.component_name = c.component_name        
AND  d.activity_name  = c.activity_name        
AND  d.ui_name   = c.ui_name        
AND  d.page_bt_synonym = c.page_bt_synonym        
AND  d.primary_control_bts=  c.control_bt_synonym      
AND  task_type   in ('Help','Link','Report'))               
        
--------------------------------------------------13----------------------------------------------------------------------------
UNION
SELECT 'Fetch task is duplicated In the Component :: '+d.component_name+' for the Publication UI ::  '+ d.ui_name        'Error Description'
FROM de_action    d (NOLOCK)        
WHERE d.customer_name  = @customer_name        
AND  d.project_name  = @project_name        
AND  d.component_name = @comp_name        
AND  EXISTS ( SELECT 's'        
FROM de_publication b (NOLOCK)        
WHERE b.customer_name  = d.customer_name        
AND  b.project_name  = d.project_name        
AND  b.component_name = d.component_name        
AND  b.activity_name  = d.activity_name        
AND  b.ui_name   = d.ui_name)        
AND  ISNULL(primary_control_bts, '[None]') = '[None]'        
AND  task_type ='Fetch'        
GROUP BY d.customer_name, d.project_name, d.process_name, d.component_name, d.activity_name, d.ui_name , task_type        
HAVING COUNT(*) > 1        
        
		UNION
--------------------------------------------------14----------------------------------------------------------------------------
 SELECT 'Fetch task is duplicated In the Component :: '+ d.component_name + ' for the Publication UI ::  '+ d.ui_name       'Error Description'
FROM de_action    d (NOLOCK)        
WHERE EXISTS ( SELECT 's'        
FROM de_resolved_link   a (NOLOCK),        
de_publication    b (NOLOCK)        
WHERE a.customer_name  = @customer_name        
AND  a.project_name  = @project_name        
AND  a.component_name = @comp_name        
        
AND  b.customer_name  = a.customer_name        
AND  b.project_name  = a.project_name        
AND  b.component_name <>a.component_name        
AND  b.component_name = a.publication_comp_name        
AND  b.activity_name  = a.publication_act_name        
AND  b.ui_name   = a.publication_ui_name        
AND  b.publication_name = a.publication_name        
        
AND  d.customer_name  = b.customer_name        
AND  d.project_name  = b.project_name        
AND  d.component_name = b.component_name        
AND  d.activity_name  = b.activity_name        
AND  d.ui_name   = b.ui_name)        
AND  ISNULL(primary_control_bts, '[None]') = '[None]'        
AND  task_type   ='Fetch'        
GROUP BY d.customer_name, d.project_name, d.process_name,  d.component_name, d.activity_name, d.ui_name , task_type        
HAVING COUNT(*) > 1        
        UNION
--------------------------------------------------15----------------------------------------------------------------------------
     
SELECT 'Task Description getting duplicated For the task '''+a.task_name+'''.Pls change the task description AND proceed.'    'Error Description'    
FROM  de_action a (NOLOCK),        
de_action b (NOLOCK)        
WHERE a.customer_name   = @customer_name        
AND   a.project_name    = @project_name        
AND   a.process_name    = @proc_name          
AND   a.component_name  = @comp_name             
AND   a.customer_name   = b.customer_name        
AND   a.project_name    = b.project_name        
AND   a.process_name    = b.process_name        
AND   a.component_name  = b.component_name        
AND   a.task_name       = b.task_name        
AND   a.task_descr      <> b.task_descr        

--------------------------------------------------16----------------------------------------------------------------------------
UNION
SELECT DISTINCT 'For the Language '''+C.quick_code_value+''' Task Description getting duplicated For the task '''+a.task_name+'''.Pls change the task description AND proceed.'        'Error Description'
FROM       
  de_action_lng_extn a (NOLOCK),        
de_action_lng_extn b (NOLOCK) ,
ep_language_met c (NOLOCK)     
       
WHERE a.customer_name   = @customer_name         
AND   a.project_name    = @project_name         
AND   a.process_name    = @proc_name           
AND   a.component_name  = @comp_name              
AND   a.customer_name   = b.customer_name        
AND   a.project_name    = b.project_name        
AND   a.process_name    = b.process_name        
AND   a.component_name  = b.component_name        
AND   a.task_name       = b.task_name        
AND   a.languageid      = b.languageid        
AND   a.task_descr      <> b.task_descr        
AND   C.quick_code = A.languageid
AND	  C.quick_code = B.languageid
AND  C.quick_code_type ='language_code'

--------------------------------------------------17----------------------------------------------------------------------------
UNION 
SELECT 'Dataitem does NOT EXISTS for the Report Dataset "'+a.dataset_name+'" under the Task : "'+
a.action_name +'"'+ ' for the Activity/UI : '+a.activity_name+'/'+ a.ui_name            'Error Description'
  
FROM   de_report_action_dataset_segment a(NOLOCK)        
WHERE a.customer_name  = @customer_name     
AND   a.project_name   = @project_name      
AND   a.process_name   = @proc_name         
AND   a.component_name = @comp_name         
AND   NOT EXISTS  ( SELECT 'x'        
FROM  de_report_action_dataset_dataitem b (NOLOCK)        
WHERE b.customer_name   = a.customer_name        
AND  b.project_name    =  a.project_name        
AND  b.process_name    =  a.process_name        
AND  b.component_name  =  a.component_name        
AND  b.activity_name = a.activity_name        
AND  b.ui_name   = a.ui_name        
AND  b.page_bt_synonym = a.page_bt_synonym        
AND  b.action_name  = a.action_name        
AND b.report_name = a.report_name      
AND  b.dataset_name  = a.dataset_name )   

--------------------------------------------------18----------------------------------------------------------------------------
UNION
SELECT 'BT has NOT been mapped to the dataitem '+''''+  a.dataitem_name +''''+ ' under the dataset ' + ''''+ a.dataset_name+'''' + ' for the report task '+ '''' + a.action_name + ''''        'Error Description'
FROM   de_report_action_dataset_dataitem a(NOLOCK) ,        
DE_GLOSSARY b   (NOLOCK)
WHERE a.customer_name    = @customer_name      
AND   a.project_name     = @project_name      
AND   a.process_name     = @proc_name         
AND   a.component_name   = @comp_name           
AND   a.customer_name    =  b.customer_name        
AND   a.project_name     =  b.project_name        
AND   a.process_name   = b.process_name        
AND   a.component_name   =  b.component_name        
AND   a.dataitem_name  = b.BT_Synonym_name        
AND   ISNULL(b.bt_name, '') = ''        
--AND a.dataitem_name <> 'text255'
 
--------------------------------------------------19----------------------------------------------------------------------------
     UNION   
select 'In the Method:'+a.method_name+'for the parameter:'+a.logicalparametername+'the btname:'+a.btname +'used is not defined for the component.'        
from de_fw_des_br_logical_parameter a (nolock)        
where a.customer_name    =  @customer_name     
and    a.project_name     = @project_name      
and  a.process_name    =    @proc_name         
and  a.component_name  =    @comp_name         
and  not exists (         
select 's'        
from de_fw_req_bterm b (nolock)        
where a.customer_name    = b.customer_name        
and    a.project_name     = b.project_name        
and  a.process_name    = b.process_name        
and  a.component_name  = b.component_name        
and  a.btname    = b.btname)  
union
--------------------------------------------------20----------------------------------------------------------------------------
SELECT 'The header btsynonym "'+c.bt_synonym_name +'", in Activity "'+a.activity_name+'"; UI "'+a.ui_name+'", is NOT mapped with any businessterms.' 'Error Description'
FROM de_ui_control    a (NOLOCK),        
es_comp_ctrl_type_mst  b (NOLOCK),        
DE_GLOSSARY    c   
WHERE a.customer_name    =  @customer_name     
AND    a.project_name     = @project_name      
AND  a.process_name    =    @proc_name         
AND  a.component_name  =    @comp_name          
AND    a.customer_name    = b.customer_name        
AND    a.project_name     = b.project_name        
AND a.process_name   = b.process_name        
AND    a.control_type   = b.ctrl_type_name        
AND  a.component_name  = b.component_name        
AND  a.process_name   = b.process_name        
AND    a.customer_name    = c.customer_name        
AND    a.project_name     = c.project_name        
       
AND a.process_name   = c.process_name        
AND    a.component_name   = c.component_name        
AND    a.control_bt_synonym  = c.bt_synonym_name        
-- AND    b.base_ctrl_type    NOT in ('link','radiobutton','button','line', 'Grid')--added BY Ganesh        
AND    b.base_ctrl_type    NOT in ('link','button','line', 'Grid','label')--ModIFied for bugid:PNR2.0_9192--PNR2.0_14041        
AND    a.control_type    NOT in ('filler', 'filler2')--added BY Ganesh        
AND  ISNULL(c.bt_name,'')  = ''        
                

--------------------------------------------------21----------------------------------------------------------------------------
UNION

select 'The grid column btsynonym " '+c.bt_synonym_name+' ", in Activity "'+a.activity_name+'"; UI "'+a.ui_name+'", is not mapped with any businessterms.'        'Error Description'
from
de_ui_grid      a (nolock),        
es_comp_ctrl_type_mst  b (nolock),        
de_glossary    c   
where  a.customer_name     = @customer_name     
and    a.project_name      = @project_name      
and    a.process_name      = @proc_name         
and    a.component_name    = @comp_name         
and    a.customer_name     = b.customer_name        
and    a.project_name      = b.project_name        
and    a.process_name      = b.process_name        
and    a.column_type       = b.ctrl_type_name        
and    a.component_name    = b.component_name        
and    a.customer_name     = c.customer_name        
and    a.project_name      = c.project_name        
and    a.process_name      = c.process_name --PNR2.0_11087        
and    a.component_name    = c.component_name        
and    a.column_bt_synonym = c.bt_synonym_name        
        
--  and    b.base_ctrl_type   not in ('link','radiobutton','button','filler','line')--added by Ganesh        
and    b.base_ctrl_type   not in ('radiobutton','button','filler','line')--PNR2.0_11087        
and  isnull(c.bt_name,'')= ''   

UNION 
--------------------------------------------------22----------------------------------------------------------------------------
SELECT 'For the Service Dataitem : '+a.dataitemname+' of the service : '+a.servicename+' Bt name is NOT mapped'      'Error Description'  
FROM   de_fw_des_service_dataitem a(NOLOCK),        
de_glossary b  (NOLOCK)
WHERE  a.customer_name  =    @customer_name        
AND    a.project_name      = @project_name       
AND    a.process_name      = @proc_name          AND    a.component_name =    @comp_name             
AND    a.customer_name    = b.customer_name        
AND    a.project_name     = b.project_name        
AND    a.process_name      = b.process_name        
AND    a.component_name    = b.component_name        
AND    a.dataitemname      = b.bt_synonym_name        
-- AND    a.servicename       = @servicename        
AND    ISNULL(b.bt_name,'')=''    

UNION   
--------------------------------------------------23----------------------------------------------------------------------------
SELECT 'The hidden view btsynonym "'+ c.bt_synonym_name +'" is NOT mapped with the businessterm'        'Error Description'
FROM de_hidden_view  a (NOLOCK),        
de_glossary  c   
WHERE a.customer_name     =  @customer_name        
AND    a.project_name      = @project_name        
AND  a.process_name    =     @proc_name           
AND  a.component_name    =   @comp_name             
        
AND    a.customer_name     = c.customer_name        
AND    a.project_name      = c.project_name        
AND  a.process_name     = c.process_name        
AND    a.component_name    = c.component_name        
AND    a.hidden_view_bt_synonym  = c.bt_synonym_name        
        
AND  ISNULL(c.bt_name,'')   = ''        
AND  ISNULL(a.HIDDEN_VIEW_SOURCE,'')   = ''
    
	UNION    
--------------------------------------------------24----------------------------------------------------------------------------

SELECT 'For the Existing Service: '+a.servicename+', Dataitem:'+a.dataitemname+' is NOT mapped to Business Term'      'Error Description'
FROM de_fw_des_di_parameter   a (NOLOCK)      
WHERE a.customer_name   = @customer_name      
AND    a.project_name    = @project_name      
AND  a.process_name  = @proc_name      
AND  a.component_name  = @comp_name --code modIFied BY Gowrisankar for PNR2.0_13486 on 02-May-2007      
AND  NOT EXISTS ( SELECT 'x'      
FROM de_fw_req_bterm_synonym b(NOLOCK)      
WHERE b.customer_name   = a.customer_name      
AND    b.project_name    = a.project_name      
AND  b.process_name  = a.process_name      
AND  b.component_name  = a.component_name      
AND  b.btsynonym   = a.dataitemname )      
AND  a.segmentname   <> 'Fw_context'      
--------------------------------------------------25 hdn vw----------------------------------------------------------------------------
UNION
--------------------------------------------------26----------------------------------------------------------------------------
SELECT 'The BTSynonym "'+a.bt_synonym_name +'" is NOT mapped with the Business Term'        'Error Description'
FROM de_re_wsinp_cat_parameters   c (NOLOCK),        
de_glossary   a,   
de_re_wsinp_area_dtl b (NOLOCK)        
WHERE a.customer_name    = @customer_name       
AND    a.project_name     =@project_name       
AND  a.process_name    =   @proc_name          
AND  a.component_name   =  @comp_name            
AND    a.customer_name     = c.customer_code        
AND    a.project_name      = c.project_code        
AND c.customer_code    = b.customer_code        
AND    c.project_code    = b.project_code        
AND     c.area_code     = b.area_code        
AND    a.customer_name     = b.customer_code        
AND    a.project_name      = b.project_code        
AND     a.component_name   = b.component_name        
AND    a.bt_synonym_name    = c.bt_name        
AND  ISNULL(a.bt_name,'')   = '' 

UNION
--------------------------------------------------27----------------------------------------------------------------------------
SELECT 'Business Terms : '+ bt_name +' Mapped With the BTSYNONYM(S) NOT Defined for the Component.'        'Error Description'
FROM de_Glossary      
WHERE   customer_name    = @customer_name        
AND project_name     =     @project_name        
AND  process_name   =      @proc_name           
AND  component_name   =    @comp_name             
AND  component_name+bt_name NOT in        
( SELECT  component_name+bt_name        
FROM  de_business_term (NOLOCK)        
WHERE   customer_name  = @customer_name        
AND    project_name   =  @project_name        
AND  process_name =      @proc_name           
AND  component_name =    @comp_name     )        
AND  ISNULL(bt_name,'') <> ''        
AND  bt_name <> 'MODEFLAG'        
   
   UNION     
--------------------------------------------------28----------------------------------------------------------------------------
SELECT 'For the Existing Service'+a.servicename+' , Dataitem '+a.dataitemname +' is NOT mapped to Business Term'  'Error Description'
FROM de_fw_des_di_parameter   a (NOLOCK)        
WHERE a.customer_name   =  @customer_name        
AND    a.project_name    = @project_name        
AND  a.process_name  =     @proc_name           
AND  a.component_name  =   @comp_name            
AND  NOT EXISTS ( SELECT 'x'        
FROM de_fw_req_bterm_synonym b(NOLOCK)        
WHERE b.customer_name   = a.customer_name        
AND    b.project_name    = a.project_name        
AND  b.process_name  = a.process_name        
AND  b.component_name  = a.component_name        
AND  b.btsynonym   = a.dataitemname )        
AND  a.segmentname   <> 'Fw_context'   

UNION     
 --------------------------------------------------29----------------------------------------------------------------------------
SELECT'In the re-used service '''+ a.servicename + ''' the dataitem '''+ a.dataitemname + ''' has been mapped to two dIFferent Controls under the segment '''+ a.segmentname+ '''.Please change the same AND proceed'            'Error Description'
FROM  de_fw_des_ilbo_service_view_datamap a (NOLOCK),            
de_fw_des_ilbo_service_view_datamap b (NOLOCK)            
WHERE a.customer_name =  @customer_name            
AND   a.project_name  =  @project_name            
AND   a.process_name  =  @proc_name            
AND   a.component_name = @comp_name            
AND   a.customer_name   =  b.customer_name            
AND   a.project_name    =  b.project_name            
AND   a.process_name    =  b.process_name            
AND   a.component_name  =  b.component_name            
AND   a.activity_name   =  b.activity_name            
AND   a.ilbocode        =  b.ilbocode            
AND   a.servicename     =  b.servicename            
AND   a.segmentname     =  b.segmentname            
AND   a.dataitemname    =  b.dataitemname            
AND (a.controlid      <> b.controlid            
or    a.viewname        <> b.viewname)            
AND   a.taskname        <> b.taskname            
 
 UNION           
  --------------------------------------------------30----------------------------------------------------------------------------
--SELECT 'More than one service ( ' + servicename + ',' + servicename + ' ) are mapped for the task ' + taskname + ' in the ui ' + ilbocode + ' Please Remove the unwanted service AND Proceed'      
SELECT 'More than one service  are mapped for the task ' + taskname + ' in the ui ' + ilbocode + ' Please Remove the unwanted service AND Proceed'       'Error Description'
FROM    de_fw_des_ilbo_service_view_datamap (NOLOCK)      
WHERE   customer_name = @customer_name        
AND     project_name  = @project_name         
AND     process_name  = @proc_name            
AND     component_name= @comp_name             
GROUP BY  customer_name,project_name,process_name,component_name,ilbocode,taskname      
HAVING COUNT(DISTINCT servicename)>1

UNION
  --------------------------------------------------31----------------------------------------------------------------------------
SELECT 'BR Parameter - Dataitem mapping is NOT defined for the parameter : '+ brp.logicalparametername +' Under the Service/Method : ' + ps.servicename +'/'+ ps.method_name+' . Map the same AND proceed.' 'Error Description'    
 FROM de_fw_des_processsection_br_is ps (NOLOCK),      
 de_fw_des_br_logical_parameter brp (NOLOCK)      
 WHERE ps.customer_name = @customer_name        
 AND  ps.project_name  =  @project_name         
 AND  ps.process_name  =  @proc_name            
 AND  ps.component_name = @comp_name            
 AND  ps.customer_name = brp.customer_name      
 AND  ps.project_name  = brp.project_name      
 AND  ps.process_name  = brp.process_name      
 AND  ps.component_name = brp.component_name      
 --   AND  ps.servicename  = @servicename      
 AND  ps.isbr    = '1'      
 AND  ps.method_name  = brp.method_name      
 AND  ps.methodid   = brp.methodid      
 AND  NOT EXISTS  (  SELECT 'X'      
    FROM  de_fw_des_di_parameter dip (NOLOCK)      
    WHERE dip.customer_name  =  @customer_name        
    AND  dip.project_name   =   @project_name         
    AND  dip.process_name   =   @proc_name            
    AND  dip.component_name   = @comp_name            
    AND  dip.customer_name   =  ps.customer_name      
    AND  dip.project_name   =  ps.project_name      
    AND  dip.process_name   =  ps.process_name      
    AND  dip.component_name  =  ps.component_name      
    AND  dip.servicename    =  ps.servicename      
    AND  dip.sectionname    =  ps.sectionname      
    AND  dip.customer_name   =  brp.customer_name      
    AND  dip.project_name   =  brp.project_name      
    AND  dip.process_name   =  brp.process_name      
    AND  dip.component_name  =  brp.component_name      
    AND  dip.methodid    =  brp.methodid      
    AND  dip.parametername  =  brp.logicalparametername      
    AND  dip.method_name    =  brp.method_name ) 
   UNION       
  --------------------------------------------------32 duplicate----------------------------------------------------------------------------

  --------------------------------------------------33----------------------------------------------------------------------------
   select distinct 'Integration service segment not exists for Service Name '+a.servicename      'Error Description'
   from de_fw_des_processsection_br_is a (nolock)
   where 
		a.customer_name	=		@customer_name
   and a.project_name	=		@project_name 
   and a.process_name	=		@proc_name    
   and a.component_name =		@comp_name    
  and isbr   = 0    
and not exists ( select 'x' from de_fw_des_integ_serv_map b (nolock)
   where a.customer_name = b.customer_name
and a.project_name = b.project_name   
and a.process_name = b.process_name
and a.component_name = b.component_name
and   a.integservicename = b.  integservicename 

and  b.callingservicename  =a.servicename     
and a.sectionname  = b.sectionname      
and a.sequenceno  = b.sequenceno      
and integsegment  = 'fw_context'  
and integdataitem  = 'ouinstance' )


UNION
  --------------------------------------------------34----------------------------------------------------------------------------

select   'FOR THE SERVICE ' + ps1.servicename + ' PROCESS SECTION ' + ps1.SECTIONNAME + ' SEQUENCE NO ' + + cast (ps1.sequenceno  as varchar(10))  + ' IS DATATIEM MAPPING DOES NOT EXISTS'           'Error Description'
from de_fw_des_processsection_br_is ps1 (nolock)      
where ps1.customer_name = @customer_name       
and ps1.project_name =    @project_name        
and ps1.process_name =    @proc_name           
and ps1.component_name =  @comp_name           
and ps1.isbr  = '0'      
and ps1.sequenceno  not in (select  distinct IS1.sequenceno      
FROM DE_FW_DES_INTEG_SERV_MAP is1 (nolock)      
WHERE ps1.customer_name = is1.customer_name      
and ps1.project_name = is1.project_name      
and  ps1.process_name = is1.process_name      
and  ps1.component_name = is1.component_name      
and     ps1.sectionname  = is1.sectionname      
and ps1.servicename  = is1.callingservicename      
and     ps1.sequenceno  = is1.sequenceno      
and     ps1.integservicename    = is1.integservicename )      

union
  --------------------------------------------------35----------------------------------------------------------------------------
  SELECT 'One or more parameters of br used by the integration service used BY the given service ' + ps1.servicename  +   ' are not mapped'      'Error Description'
FROM de_fw_des_processsection_br_is ps1 (NOLOCK),      
de_fw_des_processsection_br_is ps2 (NOLOCK),      
de_fw_des_br_logical_parameter brp (NOLOCK)      
WHERE ps1.customer_name = @customer_name       
AND  ps1.project_name =   @project_name       
AND  ps1.process_name =   @proc_name           
AND  ps1.component_name = @comp_name           
AND  ps1.customer_name = brp.customer_name      
AND  ps1.project_name = brp.project_name      
AND  ps1.process_name = brp.process_name      
AND  ps1.component_name = brp.component_name      
-- AND  ps1.servicename  = @servicename      
AND  ps1.isbr   = '0'      
AND  ps2.customer_name = ps1.customer_name      
AND  ps2.project_name = ps1.project_name      
AND  ps2.component_name = ps1.component_name
AND  ps2.servicename  = ps1.integservicename      
AND  ps2.isbr   = '1'      
AND  brp.method_name  = ps2.method_name      
AND  brp.methodid  = ps2.methodid      
AND  NOT  EXISTS (SELECT 'X'        
   FROM de_fw_des_di_parameter dip (NOLOCK) 
   WHERE dip.customer_name  = brp.customer_name       
   AND   dip.project_name    = brp.project_name      
   AND   dip.process_name    = brp.process_name      
   AND   dip.component_name  = brp.component_name      
   AND   dip.servicename   = ps2.servicename      
   AND   dip.sectionname   = ps2.sectionname      
   AND   dip.sequenceno   = ps2.sequenceno      
   AND   dip.parametername  = brp.logicalparametername)      
 UNION     
  --------------------------------------------------36----------------------------------------------------------------------------
SELECT 'One or more service dataitems of the integration service ''' + sdi.servicename + ''' used BY the calling service ''' + ps.servicename + ''' are NOT mapped'      'Error Description'
FROM de_fw_des_processsection_br_is ps (NOLOCK),      
de_fw_des_service_dataitem  sdi (NOLOCK)      
WHERE ps.customer_name = @customer_name       
AND  ps.project_name  =  @project_name        
AND  ps.process_name  =  @proc_name           
AND  ps.component_name = @comp_name           
AND  ps.customer_name = sdi.customer_name      
AND  ps.project_name  = sdi.project_name       
AND  ps.isbr    = '0'      
AND  sdi.servicename  = ps.integservicename      
AND  sdi.flowattribute  != 3      
AND  sdi.mANDatoryflag != 0      
      
AND  NOT EXISTS ( SELECT 'X'      
  FROM de_fw_des_integ_serv_map map (NOLOCK)      
  WHERE  map.customer_name  = ps.customer_name      
  AND  map.project_name  = ps.project_name      
  AND  map.process_name  = ps.process_name      
  AND  map.component_name  = ps.component_name      
  AND  map.integservicename  = ps.integservicename      
  AND  map.callingservicename = ps.servicename      
  AND  map.customer_name  = sdi.customer_name      
  AND  map.project_name  = sdi.project_name      
  AND  map.integsegment  = sdi.segmentname      
  AND  map.integdataitem  = sdi.dataitemname   )
      
  UNION
  --------------------------------------------------37----------------------------------------------------------------------------

SELECT 'One or more segments for the service ' + ss.servicename + ' do not have any dataitems'      'Error Description'
FROM  de_fw_des_service_segment ss (NOLOCK)      
WHERE ss.customer_name = @customer_name       
AND  ss.project_name  =  @project_name        
AND  ss.process_name  =  @proc_name           
AND  ss.component_name = @comp_name           
--    AND  ss.servicename   = @servicename      
AND  NOT EXISTS ( SELECT  'X'      
  FROM  de_fw_des_service_dataitem di (NOLOCK)      
  WHERE di.customer_name = @customer_name       
  AND  di.project_name  =  @project_name        
  AND  di.process_name  =  @proc_name           
  AND  di.component_name = @comp_name           
  AND  di.customer_name = ss.customer_name      
  AND  di.project_name  = ss.project_name      
  AND  di.process_name  = ss.process_name      
  AND  di.component_name = ss.component_name      
  AND  di.servicename   = ss.servicename       
  AND  di.segmentname =ss.segmentname )   
  UNION
  --------------------------------------------------38----------------------------------------------------------------------------
 SELECT 'For the service :: '+psbr.servicename+ ', Method :: '+psbr.method_name+', Errorid ::'+ cast (dbr.errorid as varchar(10)) +  ' Placeholder is NOT mapped'      'Error Description'
FROM  de_fw_des_processsection_br_is psbr (NOLOCK),      
de_fw_des_brerror    dbr (NOLOCK),      
de_fw_des_error_placeholder  dep (NOLOCK),      
de_fw_des_error  B (NOLOCK) --code added BY kiruthika for bug id:PNR2.0_6130      
WHERE psbr.customer_name  =  @customer_name       
AND  psbr.project_name   =   @project_name        
AND  psbr.process_name   =   @proc_name           
AND  psbr.component_name  =  @comp_name           
AND  psbr.customer_name  =  dbr.customer_name      
AND  psbr.project_name   =  dbr.project_name      
AND  psbr.process_name  =  dbr.process_name      
AND  psbr.component_name  =  dbr.component_name      
--    AND  psbr.servicename   =  @servicename      
AND  psbr.methodid    =  dbr.methodid      
AND  psbr.method_name   =  dbr.method_name      
AND  psbr.isbr     =  '1'      
AND  dbr.customer_name   =  dep.customer_name      
AND  dbr.project_name   =  dep.project_name      
AND  dbr.process_name   =  dep.process_name      
AND  dbr.component_name  =  dep.component_name      
AND  dbr.errorid    =   dep.errorid      
--code added BY kiruthika for bugid:PNR2.0_6130      
AND   dbr.customer_name   =   b.customer_name      
AND   dbr.project_name   =   b.project_name      
AND   dbr.process_name   =   b.process_name      
AND   dbr.component_name  =  b.componentname      
AND   dbr.errorid    =  b.errorid      
AND   (errormessage LIKE '%<%' OR errormessage LIKE '%^%')      
--code ends      
--AND  dep.placeholdername NOT in( SELECT dbp.placeholdername      
AND NOT EXISTS ( SELECT 'x'      
FROM  de_fw_des_be_placeholder dbp (NOLOCK)      
WHERE  dbp.customer_name   = dbr.customer_name      
AND    dbp.project_name    = dbr.project_name      
AND    dbp.process_name    = dbr.process_name      
AND   dbp.component_name   = dbr.component_name      
AND   dbp.methodid     = dbr.methodid      
AND   dbp.placeholdername    = dep.placeholdername      
AND   dbp.errorid      = dbr.errorid      
AND   dbp.method_name    = dbr.method_name      
union      
SELECT 'x'      
FROM de_fw_des_di_placeholder ddp (NOLOCK)      
WHERE  ddp.customer_name   = psbr.customer_name      
AND    ddp.project_name    = psbr.project_name      
AND    ddp.process_name    = psbr.process_name      
AND    ddp.component_name   = psbr.component_name      
AND    ddp.servicename    = psbr.servicename      
AND    ddp.sectionname    = psbr.sectionname      
AND ddp.sequenceno   = psbr.sequenceno      
AND    ddp.methodid     = dbr.methodid      
AND ddp.placeholdername  = dep.placeholdername      
AND    ddp.errorid      = dep.errorid      
AND    ddp.method_name   = dbr.method_name )      

UNION
  --------------------------------------------------39----------------------------------------------------------------------------
      SELECT 'There are no Process sections defined in the service ' + servicename      'Error Description'

FROM de_fw_des_service (NOLOCK)      
WHERE customer_name =@customer_name       
AND  project_name =  @project_name        
AND  process_name =  @proc_name           
AND  componentname = @comp_name           
AND     servicename NOT in      
(SELECT servicename      
FROM de_fw_des_processsection (NOLOCK)      
WHERE customer_name = @customer_name       
AND  project_name =   @project_name        
AND  process_name =   @proc_name           
AND  component_name = @comp_name            
AND  sectiontype  = 0 )    
UNION
   --------------------------------------------------40----------------------------------------------------------------------------
         SELECT 'Process section'+ ps.sectionname  +' for the service ' + ps.servicename + ' does NOT have any methods defined for it'      'Error Description'
FROM de_fw_des_processsection ps (NOLOCK)     
WHERE ps.customer_name = @customer_name       
AND  ps.project_name  =  @project_name        
AND  ps.process_name  =  @proc_name           
AND  ps.component_name = @comp_name           
--    AND  ps.servicename  = @servicename      
AND  NOT EXISTS ( SELECT 'x'      
FROM de_fw_des_processsection_br_is psbr (NOLOCK)      
WHERE ps.customer_name = psbr.customer_name      
AND  ps.project_name  = psbr.project_name    AND  ps.process_name  = psbr.process_name      
AND  ps.component_name = psbr.component_name      
AND  ps.servicename  =  psbr.servicename      
AND  ps.sectionname    =  psbr.sectionname  )      
--GROUP BY psbr.sectionname )   

UNION
   --------------------------------------------------41----------------------------------------------------------------------------
   SELECT 'For the service/segment/dataitem: '+a.servicename+'/'+ a.segmentname+'/'+a.dataitemname+   ', the LENGTH of the Default value defined is greater than the LENGTH defined for the control bt synonym'      'Error Description'
FROM de_fw_des_ilbo_service_view_datamap a(NOLOCK),      
de_glossary b,  
de_business_term c(NOLOCK),      
de_fw_des_service_dataitem d(NOLOCK)      
WHERE a.customer_name         = @customer_name       
AND   a.project_name          = @project_name        
AND   a.process_name          = @proc_name           
AND   a.component_name		  = @comp_name           
AND   a.customer_name		  = b.customer_name      
AND   a.project_name          = b.project_name      
AND   a.process_name          = b.process_name      
AND   a.component_name        = b.component_name      
AND   a.control_bt_synonym    = b.bt_synonym_name      
AND   b.customer_name         = c.customer_name      
AND   b.project_name          = c.project_name    
AND   b.process_name          = c.process_name      
AND   b.component_name        = c.component_name      
AND   b.bt_name         = c.bt_name      
AND   a.customer_name         = d.customer_name      
AND   a.project_name          = d.project_name      
AND   a.process_name          = d.process_name      
AND   a.component_name        = d.component_name      
AND   a.servicename           = d.servicename      
AND   a.segmentname     = d.segmentname      
AND   a.dataitemname          = d.dataitemname      
AND   ISNULL(d.defaultvalue,'')<> ''      
AND   len(d.defaultvalue)     > c.LENGTH      
AND   c.data_type        = 'CHAR'   
      
	  UNION
   --------------------------------------------------42----------------------------------------------------------------------------
   SELECT 'In the service '+ b.servicename +' for the method '+ a.method_name +' the record set parameter has been mapped to the single instance segment '+ b.segmentname +' .Map it to multiple instance segment.'      'Error Description'
FROM de_fw_des_br_logical_parameter a (NOLOCK),      
de_fw_des_di_parameter  b (NOLOCK),      
de_fw_des_service_segment c (NOLOCK)      
WHERE a.customer_name   = @customer_name       
AND a.project_name   =    @project_name        
AND a.process_name   =    @proc_name           
AND a.component_name  =   @comp_name           
AND a.customer_name   = b.customer_name      
AND a.project_name   = b.project_name      
AND  a.process_name   = b.process_name      
AND  a.component_name  = b.component_name      
AND ISNULL(a.recordsetname,'') <> ''      
AND ISNULL(a.rssequenceno,'') <> ''      
AND a.methodid   = b.methodid      
AND a.logicalparametername  = b.parametername      
AND b.customer_name   = c.customer_name      
AND b.project_name   = c.project_name      
AND  b.process_name   = c.process_name      
AND  b.component_name  = c.component_name      
AND b.servicename   = c.servicename      
AND b.segmentname   = c.segmentname      
AND c.instanceflag   = 0      
UNION
   --------------------------------------------------43----------------------------------------------------------------------------
SELECT  'In the service: "'+ c.servicename +'", for the Method: "'+ a.method_name +'", more than one RecordSet has been defined. ModIFy AND proceed.'      'Error Description'
FROM de_fw_des_br_logical_parameter  a(NOLOCK),      
  de_Fw_Des_di_parameter    b(NOLOCK),      
  de_fw_des_ilbo_service_view_datamap c(NOLOCK)      
WHERE a.customer_name     = @customer_name       
AND  a.project_name     =   @project_name        
AND  a.process_name     =   @proc_name           
AND  a.component_name    =  @comp_name           
AND  a.customer_name   = b.customer_name      
AND  a.project_name   = b.project_name      
AND  a.process_name   = b.process_name      
AND  a.component_name  = b.component_name      
AND  a.methodid    = b.methodid      
AND  a.logicalparametername = b.parametername      
AND  b.customer_name   = c.customer_name      
AND  b.project_name   = c.project_name      
AND  b.process_name   = c.process_name      
AND  b.component_name  = c.component_name      
AND  b.servicename   = c.servicename      
AND  b.segmentname   = c.segmentname      
AND  b.dataitemname   = c.dataitemname      
AND  ISNULL(a.recordsetname,'') <> ''       
GROUP BY a.customer_name, a.project_name, a.process_name, a.component_name, c.servicename, a.methodid, a.method_name      
HAVING COUNT(DISTINCT a.recordsetname) > 1      
--ORDER BY a.customer_name, a.project_name, a.process_name, a.component_name, c.servicename, a.methodid, a.method_name      

UNION
   --------------------------------------------------44----------------------------------------------------------------------------
 SELECT  'In the service '''+ b.servicename +''', for the method '''+ a.method_name +''', 
 Recordset-Name has NOT been defined for the parameter '''+a.logicalparametername+''', 
 mapped to the multiple instance segment '''+ b.segmentname + ''''      'Error Description'
FROM de_fw_des_br_logical_parameter a (NOLOCK),      
de_fw_des_di_parameter   b (NOLOCK),      
de_fw_des_service_segment  c (NOLOCK),      
de_fw_des_service_dataitem  d(NOLOCK)      
WHERE a.customer_name   =   @customer_name      
AND  a.project_name   =     @project_name       
AND  a.process_name   =     @proc_name          
AND  a.component_name  =    @comp_name          
AND  a.customer_name = b.customer_name      
AND  a.project_name   = b.project_name      
AND  a.process_name   = b.process_name      
AND  a.component_name  = b.component_name      
AND  ISNULL(a.recordsetname,'') = ''      
AND     a.flowdirection   = 1      
AND  a.methodid    = b.methodid      
AND  a.logicalparametername = b.parametername      
AND  b.customer_name   = c.customer_name      
AND  b.project_name   = c.project_name      
AND  b.process_name   = c.process_name      
AND  b.component_name  = c.component_name      
AND  b.servicename   = c.servicename      
AND  b.segmentname   = c.segmentname      
AND  b.customer_name   = d.customer_name      
AND  b.project_name   = d.project_name      
AND  b.process_name   = d.process_name      
AND  b.component_name  = d.component_name      
AND  b.servicename   = d.servicename      
AND  b.segmentname   = d.segmentname      
AND  b.dataitemname   = d.dataitemname      
AND  d.flowattribute   = 1      
AND  c.instanceflag   = 1      
AND  EXISTS     ( SELECT 'x'      
FROM de_fw_des_br_logical_parameter e(NOLOCK)      
WHERE e.customer_name    = a.customer_name      
AND  e.project_name    = a.project_name      
AND  e.process_name    = a.process_name      
AND  e.component_name   = a.component_name      
AND  a.methodid     = a.methodid      
AND ISNULL(a.recordsetname,'') <> '' )      
 UNION
 --------------------------------------------------45----------------------------------------------------------------------------
   SELECT 'For the service : ' + a.servicename + ', the Processsection-Sequenceno is NOT continuous. Change AND proceed.'      'Error Description'
FROM de_fw_des_processsection a(NOLOCK)      
WHERE a.customer_name = @customer_name       
AND   a.project_name  = @project_name        
AND   a.process_name  = @proc_name           
AND   a.component_name= @comp_name           
GROUP BY servicename,sequenceno      
HAVING COUNT(customer_name+project_name+process_name+component_name+servicename+convert(varchar(3),sequenceno)) >1 -- code modIFied for PNR2.0_13486 on 02-May-2007      
   UNION
 --------------------------------------------------46----------------------------------------------------------------------------
SELECT 'There are no main types sections in the service ' + servicename      'Error Description'
FROM de_fw_des_service (NOLOCK)      
WHERE customer_name = @customer_name      
AND  project_name = @project_name      
AND  process_name = @proc_name      
AND  componentname = @comp_name      
AND     servicename NOT in      
(SELECT servicename      
FROM de_fw_des_processsection (NOLOCK)      
WHERE customer_name = @customer_name      
AND  project_name = @project_name      
AND  process_name = @proc_name      
AND  component_name = @comp_name      
AND  sectiontype  = 0 )    
UNION
 --------------------------------------------------47----------------------------------------------------------------------------
SELECT      'One or more process sections for the service ' + ps.sectionname + ' do NOT have rules defined for them'      'Error Description'
FROM de_fw_des_processsection ps (NOLOCK)      
WHERE ps.customer_name = @customer_name      
AND  ps.project_name  = @project_name      
AND  ps.process_name  = @proc_name      
AND  ps.component_name = @comp_name      
--    AND  ps.servicename  = @servicename      
AND  ps.sectionname  NOT in( SELECT psbr.sectionname      
FROM de_fw_des_processsection_br_is psbr (NOLOCK)      
WHERE ps.customer_name = psbr.customer_name      
AND  ps.project_name  = psbr.project_name      
AND  ps.process_name  = psbr.process_name      
AND  ps.component_name = psbr.component_name      
AND  psbr.servicename  = ps.servicename      
GROUP BY psbr.sectionname )  
UNION
 --------------------------------------------------48----------------------------------------------------------------------------
 SELECT   'LENGTH of BT Synonym Caption(S) '+bt_synonym_caption+ ' canNOT Exceed 60  Characters' 'Error Description'
  FROM  de_glossary_lng_extn  (NOLOCK)      
    WHERE  customer_name  = @customer_name        
    AND   project_name  = @project_name           
    AND   process_name  = @proc_name        
    AND   component_name  = @comp_name      
    AND  ISNULL(bt_name,'') <> ''        
    AND  len(bt_synonym_caption) > 60   
	UNION
	-------------------------------------------codegen level errors-----------------------
 --------------------------------------------------49----------------------------------------------------------------------------
 SELECT 'PAGE NAME'+b.page_bt_synonym+' AND SECTION NAME '+a.section_bt_synonym+' ARE SAME IN THE UI "'+A.ui_name+'". KINDLY CHANGE' 'Error Description'
 FROM de_ui_section a(NOLOCK) , de_ui_page b(NOLOCK)    
WHERE a.customer_name      = @customer_name    
AND   a.project_name       = @project_name    
AND   a.process_name       = @proc_name    
AND   a.component_name     = @comp_name    
AND   a.customer_name      = b.customer_name    
AND   a.project_name       = b.project_name    
AND   a.process_name       = b.process_name    
AND   a.component_name     = b.component_name    
AND   a.activity_name      = b.activity_name    
AND   a.ui_name               = b.ui_name    
AND  a.section_bt_synonym = b.page_bt_synonym

UNION
 --------------------------------------------------50----------------------------------------------------------------------------
 SELECT 'SECTION NAME DUPLICATION IS AVAILABLE FOR THE SECTION "'+A.section_bt_synonym+'" WITHIN THE COMPONENT'   'Error Description'
 FROM de_ui_section a(NOLOCK)    
WHERE a.customer_name   = @customer_name    
AND   a.project_name    = @project_name    
AND   a.process_name    = @proc_name    
AND   a.component_name  = @comp_name    
GROUP BY a.customer_name,a.project_name,a.process_name,a.component_name,a.activity_name,a.ui_name,a.section_bt_synonym    
HAVING COUNT(*) >1

UNION
 --------------------------------------------------51----------------------------------------------------------------------------
 SELECT 'PAGE PREFIX DUPLICATION IS AVAILABLE "'+A.page_prefix+'" WITHIN THE COMPONENT'   'Error Description'
 FROM de_ui_page a(NOLOCK)    
WHERE a.customer_name   = @customer_name    
AND   a.project_name    = @project_name    
AND   a.process_name    = @proc_name    
AND   a.component_name  = @comp_name    
    
GROUP BY a.customer_name,a.project_name,a.process_name,a.component_name,a.page_prefix    
HAVING COUNT(*) >1

UNION
 --------------------------------------------------52----------------------------------------------------------------------------
 SELECT 'SP NAME IS BLANK FOR THE METHOD . KINDLY CONTACT PLATFORM TEAM' 'Error Description'
 FROM de_fw_Des_processsection_br_is a(NOLOCK) , de_fw_des_sp b(NOLOCK)    
WHERE   a.customer_name    =    @customer_name    
AND     a.project_name   =    @project_name
AND   a.process_name    = @proc_name        
AND     a.component_name   =    @comp_name    
AND  a.isbr     ='1'    
AND     a.customer_name   = b.customer_name    
AND     a.project_name   = b.project_name    
AND     a.process_name   = b.process_name    
AND     a.component_name  = b.component_name    
AND     a.method_name   = b.method_name    
AND     ISNULL(b.spname,'')     = '' 

UNION
 --------------------------------------------------53----------------------------------------------------------------------------
 SELECT 'SP NAME IS NOT MAPPED FOR THE METHOD "'+c.methodname +'". KINDLY CONTACT PLATFORM TEAM'  'Error Description'
 FROM de_fw_Des_processsection_br_is a(NOLOCK) , de_Fw_Des_businessrule c(NOLOCK)--, de_fw_des_sp b(NOLOCK)    
WHERE   a.customer_name     =    @customer_name    
AND     a.project_name      =    @project_name 
AND   a.process_name    = @proc_name           
AND     a.component_name    =    @comp_name    
AND     a.isbr       =    '1'    
AND     a.customer_name     =    c.customer_name  
AND     a.project_name  =  c.project_name  
AND     a.process_name  =    c.process_name  
AND     a.component_name    =    c.component_name  
AND     a.method_name       =    c.methodname  
AND    c.systemgenerated =    '1'  
AND NOT EXISTS( SELECT 's' FROM  de_fw_des_sp b(NOLOCK)    
WHERE   a.customer_name   = b.customer_name    
AND     a.project_name   = b.project_name    
AND     a.process_name   = b.process_name    
AND     a.component_name  = b.component_name    
AND     a.method_name   = b.method_name)

UNION
 --------------------------------------------------54----------------------------------------------------------------------------
 SELECT 'ATLEAST ONE EDITABLE CONTROL MUST BE PRESENT WITHIN THE ACTIVITY'+ c.activity_name 'Error Description'
  FROM de_ui c(NOLOCK)    
WHERE c.customer_name = @customer_name    
AND   c.project_name  =@project_name    
AND   c.process_name  =@proc_name    
AND   c.component_name=@comp_name    
AND   c.activity_name<> 'IntegrationActivity' --test  
AND NOT EXISTS    
(SELECT 's'    
 FROM de_ui_control a(NOLOCK) , es_comp_ctrl_type_mst b(NOLOCK)     
WHERE   a.customer_name  = b.customer_name    
AND     a.project_name  = b.project_name    
AND     a.process_name  = b.process_name    
AND     a.component_name = b.component_name    
AND     a.control_type  = b.ctrl_type_name    
AND  a.customer_name  = c.customer_name    
AND     a.project_name  = c.project_name    
AND     a.process_name  = c.process_name    
AND     a.component_name = c.component_name    
AND     a.activity_name  = c.activity_name    
AND     a.ui_name   = c.ui_name    
AND     b.base_ctrl_type    in('Assorted','CheckBox','Combo','DataHyperLink',    'EDIT','GRID','ListEdit','ListView',    
'Pivot','RadioButton','SLIDER','StackedLinks','TreeGrid'    
))
UNION
  --------------------------------------------------55----------------------------------------------------------------------------
   SELECT 'Main UI does NOT exist for this activity '+a.activity_name  'Error Description'
FROM  de_ui a(NOLOCK)      
WHERE a.customer_name =  @customer_name      
AND   a.project_name =  @project_name      
AND   a.process_name = @proc_name    
AND   a.component_name =  @comp_name      
AND NOT EXISTS  (SELECT 'x'      
FROM  de_ui b(NOLOCK)      
WHERE customer_name =  b.customer_name      
AND  project_name =  b.project_name      
AND  component_name =  b.component_name    
AND  activity_name =  b.activity_name    
AND  activity_name <>'IntegrationActivity'    
AND  ui_type   in ('Main', 'MainmodIFy'))    
    UNION
  --------------------------------------------------56----------------------------------------------------------------------------
  SELECT 'For Component : '+PG.component_name+', Activity :'+pg.activity_name+', UI : '+pg.ui_name+' Section is NOT defined for one or more of the Pages.'   'Error Description'
FROM de_ui_page  pg (NOLOCK)      
WHERE pg.customer_name =   @customer_name      
AND  pg.project_name  = @project_name      
--AND  pg.ecrno   = @engg_req_no      
AND  pg.process_name  = @proc_name      
AND  pg.component_name = @comp_name      
--AND  pg.activity_name =  @activity_name      
--AND  pg.ui_name   =  @ui_name_tmp      
AND  NOT EXISTS (SELECT 'x'      
FROM de_ui_section sec(NOLOCK)      
WHERE pg.customer_name = sec.customer_name      
AND  pg.project_name  = sec.project_name      
AND  pg.process_name  = sec.process_name      
AND  pg.component_name = sec.component_name      
AND  pg.activity_name = sec.activity_name      
AND  pg.ui_name   = sec.ui_name      
AND  pg.page_bt_synonym = sec.page_bt_synonym)     
  UNION    
  --------------------------------------------------57----------------------------------------------------------------------------
  SELECT 'For Component :'+A.COMPONENT_NAME+', Activity :'+a.activity_name+',UI :'+a.ui_name+' Page Layout is NOT defined for one or more of the sections.''Error Description'
FROM  de_ui a(NOLOCK)      
WHERE a.customer_name = @customer_name      
AND   a.project_name = @project_name      
AND   a.process_name = @proc_name    
AND  A.component_name = @comp_name     
AND  EXISTS  (SELECT 'x'      
FROM  de_ui_section b(NOLOCK)      
WHERE a.customer_name =  b.customer_name      
AND   A.project_name =   b.project_name      
AND   a.process_name =   b.process_name    
AND   a.component_name = b.component_name      
AND   a.activity_name =  b.activity_name      
AND   a.ui_name       =  b.ui_name      
AND  (hORDER   = 0 or vORDER = 0))   

UNION 
  --------------------------------------------------58----------------------------------------------------------------------------
  SELECT 'For Component :'+CTRL.COMPONENT_NAME + ', Activity :'+ctrl.activity_name+'  , UI:'+ctrl.ui_name+'    Columns are NOT defined for one or more of the Grid Controls.' 'Error Description'
FROM de_ui_control  ctrl (NOLOCK),      
es_comp_ctrl_type_mst_vw  ctype (NOLOCK)      
WHERE ctrl.customer_name  = ctype.customer_name      
AND  ctrl.project_name  = ctype.project_name      
AND  ctrl.process_name  = ctype.process_name      
AND  ctrl.component_name  = ctype.component_name      
AND  ctrl.control_type  = ctype.ctrl_type_name      
AND  ctype.base_ctrl_type = 'Grid'      
AND  ctrl.customer_name  =   @customer_name      
AND  ctrl.project_name  = @project_name      
--AND  ctrl.ecrno    = @engg_req_no      
AND  ctrl.process_name  = @proc_name      
AND  ctrl.component_name  = @comp_name      
--AND  ctrl.activity_name  =  @activity_name      
--AND  ctrl.ui_name   =  @ui_name_tmp      
AND  NOT EXISTS (SELECT 'x'      
FROM de_ui_grid grd(NOLOCK)      
WHERE ctrl.customer_name  = grd.customer_name      
AND  ctrl.project_name  = grd.project_name      
AND  ctrl.process_name  = grd.process_name      
AND  ctrl.component_name  = grd.component_name      
AND  ctrl.activity_name  = grd.activity_name      
AND  ctrl.ui_name   = grd.ui_name      
AND  ctrl.page_bt_synonym = grd.page_bt_synonym      
AND  ctrl.section_bt_synonym = grd.section_bt_synonym      
AND  ctrl.control_bt_synonym = grd.control_bt_synonym)     

UNION
  --------------------------------------------------59----------------------------------------------------------------------------
  SELECT'For Component :'+CTRL.COMPONENT_NAME+', Activity Code :'+ctrl.activity_name+', UI :'+ctrl.ui_name+'is NOT defined for one or more of the Radio Button Controls.'        'Error Description'
FROM de_ui_control  ctrl (NOLOCK),      
es_comp_ctrl_type_mst_vw ctype (NOLOCK)      
WHERE ctrl.customer_name  = ctype.customer_name      
AND  ctrl.project_name  = ctype.project_name      
AND  ctrl.process_name  = ctype.process_name      
AND  ctrl.component_name  = ctype.component_name      
AND  ctrl.control_type  = ctype.ctrl_type_name      
AND  ctype.base_ctrl_type = 'RadioButton'      
AND  ctrl.customer_name =   @customer_name      
AND  ctrl.project_name  = @project_name      
--AND  ctrl.ecrno    = @engg_req_no      
AND  ctrl.process_name  = @proc_name      
AND  ctrl.component_name  = @comp_name      
--AND  ctrl.activity_name  =  @activity_name      
--AND  ctrl.ui_name   =  @ui_name_tmp      
AND  NOT EXISTS (SELECT 'x'      
FROM de_radio_button rd(NOLOCK)      
WHERE ctrl.customer_name  = rd.customer_name      
AND  ctrl.project_name  = rd.project_name      
AND  ctrl.process_name  = rd.process_name      
AND  ctrl.component_name  = rd.component_name      
AND  ctrl.activity_name  = rd.activity_name      
AND  ctrl.ui_name   = rd.ui_name      
AND  ctrl.page_bt_synonym = rd.page_bt_synonym      
AND  ctrl.section_bt_synonym = rd.section_bt_synonym      
AND  ctrl.control_bt_synonym = rd.control_bt_synonym)    


  --------------------------------------------------60----------------------------------------------------------------------------



	SET NOCOUNT off

END    


