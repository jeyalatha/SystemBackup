IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_refinedata_population_sp' AND TYPE = 'P')
BEGIN
  DROP PROC de_refinedata_population_sp
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_refinedata_population_sp.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 20-01-05 (Patch Release 3)    */
/********************************************************************************/
/* procedure      de_refinedata_population_sp                                   */
/* description                                                                  */
/********************************************************************************/
/* project        de                                                         */
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author                                                      */
/* date                                                          */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/*modified by        DNR             */
/*modified date      19-May-2004           */
/*modified purpose    DEENG203ACC_000043
while generating the services,refine services information is getting vanished. */
/*modified by        DNR             */
/*modified date      23-June-2004          */
/*modified purpose    DEENG203ACC_000081
REFINE METHOD TABLES NEED TO BE POPULATED AT THE TIME OF DESIGN GENERATION  */
/*modified by        DNR             */
/*modified date      24-June-2004          */
/*modified purpose    DEENG203ACC_000081
REFINE METHOD TABLES NEED TO BE POPULATED AT THE TIME OF DESIGN GENERATION  */
/********************************************************************************/
/* Modified by : Balaji S for callid PNR2.0_7749        */
/* Modified on : 05 Apr 2006              */
/* Description : while Generating services,refine methods attributes have been changed*/
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/**************************************************************************************/
/* Modified by			: Ponmalar A												  */
/* Date					: 27-May-2022												  */
/* Defect ID			: TECH-69327												  */
/* Description			: Provision for modeling bubble message - display the multiple
						  messages when we fire a task - Bubble message.			  */
/**************************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230		  */
/**************************************************************************************/
CREATE PROCEDURE de_refinedata_population_sp
	@ctxt_language_in engg_ctxt_language,
	@ctxt_ouinstance_in engg_ctxt_ouinstance,
	@ctxt_service_in engg_ctxt_service,
	@ctxt_user_in engg_ctxt_user,
	@engg_activity_in engg_description,
	@engg_component_in engg_description,
	@engg_customer_name_in engg_name,
	@engg_process_in engg_description,
	@engg_project_name_in engg_name,
	@engg_req_no_in engg_name,
	@engg_ui_name_in engg_description,
	@engg_page_in engg_description,
	@engg_task_in engg_name,
	@engg_service_in engg_name,
	@engg_gen_applyrefine	engg_seqno,
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @ps_name_tmp engg_name,
		@mt_name_tmp engg_name,
		@seq_no engg_sequence_no,
		@param_name_tmp engg_name,
		@flowbr_name_tmp engg_name,
		@mt_id engg_id_no,
		@spname engg_name,
		@accessdatabase_tmp engg_sequence_no,
		@operationtype_tmp engg_sequence_no,
		@isintegbr_tmp engg_sequence_no,
		@systemgenerated_tmp engg_sequence_no,
		@getdate engg_date

	SELECT @getdate = getdate()

	UPDATE a
	SET include_flag = 0,
		createddate = getdate(),
		modifieddate = getdate()
	FROM de_refine_process_section a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name_in
		AND a.project_name = @engg_project_name_in
		AND a.process_name = @engg_process_in
		AND a.component_name = @engg_component_in
		AND a.activity_name = @engg_activity_in
		AND a.ui_name = @engg_ui_name_in
		AND a.service_name = @engg_service_in
		AND a.ps_name NOT IN (
			SELECT b.sectionname
			FROM de_fw_des_processsection_br_is b(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.service_name = b.servicename
			)

	DECLARE ref_ps CURSOR
	FOR
	SELECT sectionname
	FROM de_fw_des_processsection(NOLOCK)
	WHERE customer_name = @engg_customer_name_in
		AND project_name = @engg_project_name_in
		AND process_name = @engg_process_in
		AND component_name = @engg_component_in
		AND servicename = @engg_service_in

	OPEN ref_ps

	WHILE 1 = 1
	BEGIN
		FETCH NEXT
		FROM ref_ps
		INTO @ps_name_tmp

		IF @@fetch_status <> 0
			BREAK

		IF NOT EXISTS (
				SELECT 'X'
				FROM de_refine_process_section(NOLOCK)
				WHERE customer_name = @engg_customer_name_in
					AND project_name = @engg_project_name_in
					AND process_name = @engg_process_in
					AND component_name = @engg_component_in
					AND activity_name = @engg_activity_in
					AND ui_name = @engg_ui_name_in
					AND service_name = @engg_service_in
					AND ps_name = @ps_name_tmp
				)
		BEGIN
			INSERT INTO de_refine_process_section (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				service_name,
				ps_name,
				sequence_no,
				update_flag,
				refps_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				include_flag,
				ecrno
				) --chan
			SELECT @engg_customer_name_in,
				@engg_project_name_in,
				@engg_process_in,
				@engg_component_in,
				@engg_activity_in,
				@engg_ui_name_in,
				@engg_service_in,
				sectionname,
				sequenceno,
				1,
				newid(),
				0,
				@ctxt_user_in,
				@getdate,
				@ctxt_user_in,
				@getdate,
				1,
				@engg_req_no_in
			FROM de_fw_des_processsection(NOLOCK)
			WHERE servicename = @engg_service_in
				AND customer_name = @engg_customer_name_in
				AND project_name = @engg_project_name_in
				AND process_name = @engg_process_in
				AND component_name = @engg_component_in
				AND servicename = @engg_service_in
				AND sectionname = @ps_name_tmp
		END
	END

	CLOSE ref_ps

	DEALLOCATE ref_ps

	UPDATE a
	SET include_flag = 0,
		createddate = getdate(),
		modifieddate = getdate()
	FROM de_refine_methods a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name_in
		AND a.project_name = @engg_project_name_in
		AND a.process_name = @engg_process_in
		AND a.component_name = @engg_component_in
		AND a.activity_name = @engg_activity_in
		AND a.ui_name = @engg_ui_name_in
		AND a.service_name = @engg_service_in
		AND a.method_name NOT IN (
			SELECT b.method_name
			FROM de_fw_des_processsection_br_is b(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.service_name = b.servicename
				AND a.ps_name = b.sectionname
			)

	DECLARE ref_met CURSOR
	FOR
	SELECT bs.methodname,
		br.sectionname,
		br.sequenceno,
		sp.methodid,
		sp.spname,
		accessesdatabase,
		operationtype,
		isintegbr,
		systemgenerated
	FROM de_fw_des_businessrule bs(NOLOCK),
		de_fw_des_processsection_br_is br(NOLOCK),
		de_fw_des_sp sp(NOLOCK)
	WHERE br.customer_name = bs.customer_name
		AND br.project_name = bs.project_name
		AND br.process_name = bs.process_name
		AND br.component_name = bs.component_name
		AND br.method_name = bs.methodname
		AND br.methodid = bs.methodid
		AND br.servicename = @engg_service_in
		AND br.customer_name = @engg_customer_name_in
		AND br.project_name = @engg_project_name_in
		AND br.process_name = @engg_process_in
		AND br.component_name = @engg_component_in
		AND br.isbr = 1
		AND SP.customer_name = BS.customer_name
		AND SP.project_name = bs.project_name
		AND SP.process_name = bs.process_name
		AND SP.component_name = bs.component_name
		AND SP.methodid = bs.methodid

	OPEN ref_met

	WHILE 1 = 1
	BEGIN
		FETCH NEXT
		FROM ref_met
		INTO @mt_name_tmp,
			@ps_name_tmp,
			@seq_no,
			@mt_id,
			@spname,
			@accessdatabase_tmp,
			@operationtype_tmp,
			@isintegbr_tmp,
			@systemgenerated_tmp

		IF @@fetch_status <> 0
			BREAK

		--Code Modified For BugId : PNR2.0_7749
		IF NOT EXISTS (
				SELECT 'X'
				FROM de_refine_methods(NOLOCK)
				WHERE customer_name = @engg_customer_name_in
					AND project_name = @engg_project_name_in
					AND process_name = @engg_process_in
					AND component_name = @engg_component_in
					AND activity_name = @engg_activity_in
					AND ui_name = @engg_ui_name_in
					AND ps_name = @ps_name_tmp
					AND service_name = @engg_service_in
					AND method_name = @mt_name_tmp
				)
		BEGIN
			--     update  de_refine_methods
			--     set  sequence_no   = @seq_no,
			-- --       spname    = @spname,
			--       createddate   = @getdate,
			--       modifieddate  = @getdate,
			--       accessdatabase = @accessdatabase_tmp ,
			--       operationtype = @operationtype_tmp,
			--       isintegbr  = @isintegbr_tmp,
			--       systemgenerated = @systemgenerated_tmp
			--     where  customer_name  = @engg_customer_name_in
			--     and    project_name   = @engg_project_name_in
			--     and  process_name   = @engg_process_in
			--     and  component_name  = @engg_component_in
			--     and  activity_name = @engg_activity_in
			--     and  ui_name   = @engg_ui_name_in
			--     and  ps_name   = @ps_name_tmp
			--     and  service_name  = @engg_service_in
			--     and  method_name  = @mt_name_tmp
			--    end
			--    else
			--    begin
			INSERT INTO de_refine_methods (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				service_name,
				ps_name,
				method_name,
				sequence_no,
				update_flag,
				refmet_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				include_flag,
				spname,
				accessdatabase,
				operationtype,
				isintegbr,
				systemgenerated,
				ecrno,
				sperrorprotocol		--TECH-69327
				) --chan
			SELECT @engg_customer_name_in,
				@engg_project_name_in,
				@engg_process_in,
				@engg_component_in,
				@engg_activity_in,
				@engg_ui_name_in,
				@engg_service_in,
				br.sectionname,
				bs.methodname,
				sequenceno,
				1,
				newid(),
				0,
				@ctxt_user_in,
				getdate(),
				@ctxt_user_in,
				getdate(),
				1,
				sp.spname,
				accessesdatabase,
				operationtype,
				isintegbr,
				systemgenerated,
				@engg_req_no_in,
				sp.sperrorprotocol    --TECH-69327
			FROM de_fw_des_businessrule bs(NOLOCK),
				de_fw_des_processsection_br_is br(NOLOCK),
				de_fw_des_sp sp(NOLOCK)
			WHERE br.customer_name = bs.customer_name
				AND br.project_name = bs.project_name
				AND br.process_name = bs.process_name
				AND br.component_name = bs.component_name
				AND br.method_name = bs.methodname
				AND br.customer_name = sp.customer_name
				AND br.project_name = sp.project_name
				AND br.process_name = sp.process_name
				AND br.component_name = sp.component_name
				AND br.method_name = sp.method_name
				AND br.methodid = sp.methodid
				AND br.servicename = @engg_service_in
				AND br.customer_name = @engg_customer_name_in
				AND br.project_name = @engg_project_name_in
				AND br.process_name = @engg_process_in
				AND br.component_name = @engg_component_in
				AND bs.methodname = @mt_name_tmp
				AND br.sectionname = @ps_name_tmp
				AND br.isbr = 1
				AND sp.methodid = @mt_id
		END
	END

	CLOSE ref_met

	DEALLOCATE ref_met

	DELETE
	FROM de_method_message_map
	WHERE service_name = @engg_service_in
		AND customer_name = @engg_customer_name_in
		AND project_name = @engg_project_name_in
		AND process_name = @engg_process_in
		AND component_name = @engg_component_in
		AND activity_name = @engg_activity_in
		AND ui_name = @engg_ui_name_in

	SELECT DISTINCT er.customer_name 'customer_name',
		er.project_name 'project_name',
		er.process_name 'process_name',
		er.component_name 'component_name',
		er.activity_name 'activity_name',
		er.ui_name 'ui_name',
		@engg_service_in 'Service',
		er.flowbr_name 'flowbr_name',
		method_name 'method_name',
		message_id 'message_id',
		de_err.error_descr 'error_descr1',
		1 'Update_Flag',
		'A' 'New_ID',
		0 'TimeStamp',
		@ctxt_user_in 'User1',
		@getdate 'Date1',
		@ctxt_user_in 'User2',
		@getdate 'Date2',
		message_id 'message_id1',
		de_err.error_descr 'error_descr2',
		msg_severity 'msg_severity',
		de_err.error_descr 'error_descr3',
		0 'Corrective_Action',
		0 'Map_Flag'
	INTO #de_method_message_map
	FROM de_flowbr_br_error er(NOLOCK),
		de_flowbr_method_map mp(NOLOCK),
		de_message de_err(NOLOCK)
	WHERE er.customer_name = mp.customer_name
		AND er.project_name = mp.project_name
		AND er.process_name = mp.process_name
		AND er.component_name = mp.component_name
		AND er.activity_name = mp.activity_name
		AND er.ui_name = mp.ui_name
		--  and er.page_bt_synonym = mp.page_bt_synonym
		AND er.page_bt_synonym = @engg_page_in
		AND er.task_name = @engg_task_in
		AND er.flowbr_name = mp.flowbr_name
		AND de_err.customer_name = mp.customer_name
		AND de_err.project_name = mp.project_name
		AND de_err.process_name = mp.process_name
		AND de_err.component_name = mp.component_name
		AND er.message_id = de_err.error_id
		AND mp.service_name = @engg_service_in
		AND mp.customer_name = @engg_customer_name_in
		AND mp.project_name = @engg_project_name_in
		AND mp.process_name = @engg_process_in
		AND mp.component_name = @engg_component_in
		AND mp.activity_name = @engg_activity_in
		AND mp.ui_name = @engg_ui_name_in
		AND NOT EXISTS (
			SELECT 'A'
			FROM de_method_message_map mmp(NOLOCK)
			WHERE mmp.customer_name = er.customer_name
				AND project_name = er.project_name
				AND process_name = er.process_name
				AND component_name = er.component_name
				AND activity_name = er.activity_name
				AND ui_name = er.ui_name
				AND service_name = @engg_service_in
				AND flowbr_name = er.flowbr_name
				AND method_name = mp.method_name
				AND message_id = er.message_id
			)

	INSERT INTO de_method_message_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		service_name,
		flowbr_name,
		method_name,
		message_id,
		message_descr,
		update_flag,
		metmsg_sysid,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		modifieddate,
		sp_message_no,
		sp_message_descr,
		message_severity,
		detail_description,
		corrective_action,
		map_flag,
		ecrno
		) --chan
	SELECT customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		Service,
		flowbr_name,
		method_name,
		message_id,
		error_descr1,
		Update_Flag,
		newid(),
		0,
		User1,
		Date1,
		User2,
		Date2,
		message_id,
		error_descr2,
		msg_severity,
		error_descr3,
		Corrective_Action,
		Map_Flag,
		@engg_req_no_in
	FROM #de_method_message_map

	DROP TABLE #de_method_message_map

	-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - START
	-- Process, Component in join added
	UPDATE a
	SET required_flag = 0,
		createddate = getdate(),
		modifieddate = getdate()
	FROM de_refine_parameter a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name_in
		AND a.project_name = @engg_project_name_in
		AND a.process_name = @engg_process_in
		AND a.component_name = @engg_component_in
		AND a.activity_name = @engg_activity_in
		AND a.ui_name = @engg_ui_name_in
		AND a.service_name = @engg_service_in
		AND a.parameter_name NOT IN ('ctxt_role','ctxt_validation') --TECH-69327 (18May2022)
		AND a.parameter_name NOT IN (
			SELECT b.logicalparametername
			FROM de_fw_des_br_logical_parameter b(NOLOCK),
				de_fw_des_processsection_br_is c(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.method_name = b.method_name
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.service_name = c.servicename
				AND a.method_name = c.method_name
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.methodid = c.methodid
				AND b.method_name = c.method_name
			)
			

	-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - END
	-- Process, Component in join added
	DECLARE di_param CURSOR
	FOR
	SELECT A.sectionname,
		A.method_name,
		A.parametername,
		B.logicalparamseqno
	FROM de_fw_des_di_parameter A(NOLOCK),
		de_fw_des_br_logical_parameter B(NOLOCK)
	WHERE A.customer_name = @engg_customer_name_in
		AND A.project_name = @engg_project_name_in
		AND A.process_name = @engg_process_in
		AND A.component_name = @engg_component_in
		AND A.servicename = @engg_service_in
		AND A.customer_name = B.customer_name
		AND A.project_name = B.project_name
		AND A.process_name = B.process_name
		AND A.component_name = B.component_name
		AND A.methodid = B.methodid
		AND A.parametername = B.logicalparametername

	OPEN di_param

	WHILE 1 = 1
	BEGIN
		FETCH NEXT
		FROM di_param
		INTO @ps_name_tmp,
			@mt_name_tmp,
			@param_name_tmp,
			@seq_no

		IF @@fetch_status <> 0
			BREAK

		SELECT @flowbr_name_tmp = flowbr_name
		FROM de_flowbr_method_map A(NOLOCK)
		WHERE A.customer_name = @engg_customer_name_in
			AND A.project_name = @engg_project_name_in
			AND A.process_name = @engg_process_in
			AND A.component_name = @engg_component_in
			AND A.activity_name = @engg_activity_in
			AND A.ui_name = @engg_ui_name_in
			AND A.service_name = @engg_service_in
			AND A.method_name = @mt_name_tmp

				
		IF EXISTS (
				SELECT 'X'
				FROM de_refine_parameter(NOLOCK)
				WHERE customer_name = @engg_customer_name_in
					AND project_name = @engg_project_name_in
					AND process_name = @engg_process_in
					AND component_name = @engg_component_in
					AND activity_name = @engg_activity_in
					AND ui_name = @engg_ui_name_in
					AND service_name = @engg_service_in
					AND method_name = @mt_name_tmp
					AND parameter_name = @param_name_tmp
				)
		BEGIN
			IF ISNULL(@engg_gen_applyrefine,0)	=	0	--TECH-75230 (For refine services in generate services if seqno changed)
			BEGIN
			UPDATE de_refine_parameter
			SET new_seq_no = @seq_no,
				modifiedby = @ctxt_user_in, --TECH-75230
				modifieddate = getdate()  --TECH-75230
			WHERE customer_name = @engg_customer_name_in
				AND project_name = @engg_project_name_in
				AND process_name = @engg_process_in
				AND component_name = @engg_component_in
				AND activity_name = @engg_activity_in
				AND ui_name = @engg_ui_name_in
				AND service_name = @engg_service_in
				AND method_name = @mt_name_tmp
				AND parameter_name = @param_name_tmp
			END
		END
		ELSE
		BEGIN
			INSERT INTO de_refine_parameter (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				service_name,
				flowbr_name,
				method_name,
				parameter_name,
				sequence_no,
				update_flag,
				refparam_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				new_seq_no,
				required_flag,
				ecrno,
				modifiedby,  --14469
				modifieddate --14469
				) --chan
			VALUES (
				@engg_customer_name_in,
				@engg_project_name_in,
				@engg_process_in,
				@engg_component_in,
				@engg_activity_in,
				@engg_ui_name_in,
				@engg_service_in,
				@flowbr_name_tmp,
				@mt_name_tmp,
				@param_name_tmp,
				@seq_no,
				1,
				newid(),
				1,
				@ctxt_user_in,
				@getdate,
				@seq_no,
				'1',
				@engg_req_no_in,
				@ctxt_user_in, --14469
				getdate() --14469
				)
		END

		IF NOT EXISTS (
				SELECT 'X'
				FROM de_method_doc(NOLOCK)
				WHERE customer_name = @engg_customer_name_in
					AND project_name = @engg_project_name_in
					AND process_name = @engg_process_in
					AND component_name = @engg_component_in
					AND activity_name = @engg_activity_in
					AND ui_name = @engg_ui_name_in
					AND service_name = @engg_service_in
					AND method_name = @mt_name_tmp
				)
		BEGIN
			INSERT INTO de_method_doc (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				service_name,
				flowbr_name,
				method_name,
				update_flag,
				metdoc_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				method_doc,
				ecrno
				) --chan
			SELECT @engg_customer_name_in,
				@engg_project_name_in,
				@engg_process_in,
				@engg_component_in,
				@engg_activity_in,
				@engg_ui_name_in,
				@engg_service_in,
				@flowbr_name_tmp,
				@mt_name_tmp,
				1,
				newid(),
				1,
				@ctxt_user_in,
				@getdate,
				doctext,
				@engg_req_no_in
			FROM de_fw_des_br_documentation(NOLOCK)
			WHERE customer_name = @engg_customer_name_in
				AND project_name = @engg_project_name_in
				AND process_name = @engg_process_in
				AND component_name = @engg_component_in
				AND method_name = @mt_name_tmp
		END
	END

	CLOSE di_param

	DEALLOCATE di_param

	DELETE de_refine_method_error_map
	WHERE customer_name = @engg_customer_name_in
		AND project_name = @engg_project_name_in
		AND process_name = @engg_process_in
		AND component_name = @engg_component_in
		AND service_name = @engg_service_in

	--CODE MODIFIED BY DNR ON 29-JUNE-2004 FOR THE BUG ID DEENG203ACC_000081
	--DE_REFINE_METHOD_ERROR_MAP TABLE IS NOT GETTING POPULATED DUE TO JOIN CONDITION FAIL.
	INSERT INTO de_refine_method_error_map (
		customer_name,
		project_name,
		process_name,
		component_name,
		activity_name,
		ui_name,
		service_name,
		flowbr_name,
		method_name,
		req_errorno,
		des_errorno,
		sp_errorno,
		TIMESTAMP,
		createdby,
		createddate,
		modifiedby,
		-- code changed by Yuvaraj A on 25/06/06
		modifieddate,
		req_error_desc,
		des_error_desc,
		sp_error_desc,
		severity,
		detaileddesc,
		correctiveaction,
		map_flag,
		error_context,
		ecrno
		) --chan
	SELECT DISTINCT D.customer_name,
		D.project_name,
		D.process_name,
		D.component_name,
		D.activity_name,
		D.ui_name,
		D.service_name,
		-- modified by Ganesh for the bugid :: DEENG203SYS_000326 to avoid insertion of null value in reqerror
		D.flowbr_name,
		D.method_name,
		isnull(C.reqerror, ''),
		C.errorid,
		B.sperrorcode,
		1,
		@ctxt_user_in,
		@getdate,
		@ctxt_user_in,
		-- code changed by Yuvaraj A on 25/06/06
		@getdate,
		C.errormessage,
		C.errormessage,
		C.errormessage,
		C.defaultseverity,
		C.detaileddesc,
		C.defaultcorrectiveaction,
		'1',
		b.error_context,
		@engg_req_no_in
	FROM de_fw_des_processsection_br_is A(NOLOCK),
		de_flowbr_method_map D(NOLOCK),
		de_fw_des_brerror B(NOLOCK),
		de_fw_des_error C(NOLOCK)
	WHERE A.customer_name = @engg_customer_name_in
		AND A.project_name = @engg_project_name_in
		AND A.process_name = @engg_process_in
		AND A.component_name = @engg_component_in
		AND A.servicename = @engg_service_in
		AND A.isbr = 1
		AND A.customer_name = D.customer_name
		AND A.project_name = D.project_name
		AND A.process_name = D.process_name
		AND A.component_name = D.component_name
		AND A.servicename = D.service_name
		AND A.Method_name = D.Method_name
		AND A.customer_name = B.customer_name
		AND A.project_name = B.project_name
		AND A.methodid = B.methodid
		AND A.method_name = B.method_name
		AND A.customer_name = C.customer_name
		AND A.project_name = C.project_name
		AND A.process_name = C.process_name
		AND A.component_name = C.componentname
		AND B.errorid = C.errorid

	-- code Modified by feroz on 04-Oct-2004 for bug id ::DEENG203SYS_000368
	UPDATE a
	SET include_flag = '0'
	FROM de_refine_methods a(NOLOCK)
	WHERE a.service_name = @engg_service_in
		AND a.customer_name = @engg_customer_name_in
		AND a.project_name = @engg_project_name_in
		AND a.process_name = @engg_process_in
		AND a.component_name = @engg_component_in
		AND a.method_name NOT IN (
			SELECT bs.methodname
			FROM de_fw_des_businessrule bs(NOLOCK),
				de_fw_des_processsection_br_is br(NOLOCK),
				de_fw_des_sp sp(NOLOCK)
			WHERE br.customer_name = bs.customer_name
				AND br.project_name = bs.project_name
				AND br.process_name = bs.process_name
				AND br.component_name = bs.component_name
				AND br.method_name = bs.methodname
				AND br.servicename = @engg_service_in
				AND br.customer_name = @engg_customer_name_in
				AND br.project_name = @engg_project_name_in
				AND br.process_name = @engg_process_in
				AND br.component_name = @engg_component_in
				AND br.isbr = 1
			)

		--TECH-69327

		IF EXISTS 
		(SELECT 'X'
		 FROM de_fw_des_service WITH (NOLOCK)
		 WHERE customer_name	=	@engg_customer_name_in
		 AND	project_name	=	@engg_project_name_in
		 AND	process_name	=	@engg_process_in
		 AND	componentname	=	@engg_component_in
		 AND	servicename		=	@engg_service_in
		 AND	isbubblemessage =   0
		 )
		BEGIN

		UPDATE a
		SET	 sperrorprotocol	=	0
		FROM de_refine_methods a(NOLOCK)
		JOIN de_task_service_method_vw b (NOLOCK)
		ON	a.customer_name	=	b.customer_name
		AND	a.project_name	=	b.project_name
		AND a.process_name	=	b.process_name
		AND	a.component_name=   b.component_name
		AND a.activity_name	=	b.activity_name
		AND a.ui_name		=	b.ui_name
		AND a.method_name	=	b.method_name
		WHERE a.customer_name	= @engg_customer_name_in
		AND   a.project_name	= @engg_project_name_in
		AND   a.process_name	= @engg_process_in
		AND   a.component_name	= @engg_component_in
		AND   b.service_name	= @engg_service_in

		END

	ELSE IF EXISTS 
	(SELECT 'X'
	 FROM de_fw_des_service WITH (NOLOCK)
	 WHERE customer_name	=	@engg_customer_name_in
	 AND	project_name	=	@engg_project_name_in
	 AND	process_name	=	@engg_process_in
	 AND	componentname	=	@engg_component_in
	 AND	servicename		=	@engg_service_in
	 AND	isbubblemessage =   1
	 )
	BEGIN

	UPDATE a
	SET	 sperrorprotocol	=	1
	FROM de_refine_methods a(NOLOCK)
	JOIN de_task_service_method_vw b (NOLOCK)
	ON	a.customer_name	=	b.customer_name
	AND	a.project_name	=	b.project_name
	AND a.process_name	=	b.process_name
	AND	a.component_name=   b.component_name
	AND a.activity_name	=	b.activity_name
	AND a.ui_name		=	b.ui_name
	AND a.method_name	=	b.method_name
	WHERE a.customer_name	= @engg_customer_name_in
	AND   a.project_name	= @engg_project_name_in
	AND   a.process_name	= @engg_process_in
	AND   a.component_name	= @engg_component_in
	AND   b.service_name	= @engg_service_in

	END
	--TECH-69327

END
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_refinedata_population_sp' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_refinedata_population_sp TO PUBLIC
END
GO





