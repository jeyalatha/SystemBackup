IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DE_FLOWBR_COMBO_SP_INS_DEL' AND TYPE = 'P')
BEGIN
	DROP PROC DE_FLOWBR_COMBO_SP_INS_DEL                                                                 
END
GO
/********************************************************************************/
/* Procedure    : DE_FLOWBR_COMBO_SP_INS_DEL                                    */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Ponmalar A													*/
/* Date         : 11-Nov-2022													*/
/* rTrack ID    : TECH-75230													*/
/* Description	: Populate combo option for Combo and Multiselect Combo, Listedit 
				  are handled in Generate Service itself.						*/
/********************************************************************************/
CREATE PROCEDURE DE_FLOWBR_COMBO_SP_INS_DEL
	@ctxt_language_in		engg_ctxt_language,
	@ctxt_ouinstance_in		engg_ctxt_ouinstance,
	@ctxt_service_in		engg_ctxt_service,
	@ctxt_user_in			engg_ctxt_user,
	@customer_name_in		engg_name,
	@project_name_in		engg_name,
	@process_name_in		engg_name,
	@component_name_in		engg_name,
	@activity_name_in		engg_name,
	@ui_name_in				engg_name,
	@page_bt_synonym_in		engg_name,
	@task_name_in			engg_name,
	@flowbr_name_in			engg_name,
	@combo_bt_synonym_in	engg_name,
	@combo_page_name_in		engg_name,
	@clear_tree_before_population_in engg_seqno,
	@timestamp_in engg_seqno,
	@engg_ecr_no engg_name, 
	@engg_tc_load			engg_seqno,
	@modeflag				engg_flag,
	@fprowno				engg_seqno,
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	DECLARE @combobtname	engg_name, 
			@flowbrname		engg_name,
			@flowbrdesc		engg_desc, 
			@flowbrseq		engg_seqno,
			@controlid		engg_name,
			@viewname		engg_name,
			@comp_prefix	engg_name,
			@page_prefix	engg_name,
			@ctrl_prfx		engg_name,
			@event_name		engg_name,
			@controltype	engg_name,
			@brcontrol		engg_name,
			@tmpflowbr_descr	engg_desc,
			@sectionname	engg_name,
			@loadcnt		engg_seqno,
			@mapload		engg_flag,
			@HdrML			engg_flag

		SELECT @comp_prefix = current_value
		FROM es_comp_param_mst(NOLOCK)
		WHERE customer_name = @customer_name_in
		AND project_name	= @project_name_in
		AND process_name	= @process_name_in
		AND component_name	= @component_name_in
		AND param_category	= 'compprefix'
		AND param_type		= 'namecon'

		SELECT @page_prefix = page_prefix
		FROM re_ui_page(NOLOCK)
		WHERE customer_name = @customer_name_in
		AND project_name	= @project_name_in
		AND process_name	= @process_name_in
		AND component_name	= @component_name_in
		AND activity_name	= @activity_name_in
		AND ui_name			= @ui_name_in
		AND page_bt_synonym = @page_bt_synonym_in
	    
		IF  ISNULL(@engg_tc_load,0)	=	1
		AND NOT EXISTS(
		SELECT 'X'
		FROM de_ui_control a (NOLOCK) 
		JOIN es_comp_ctrl_type_mst b (NOLOCK)
		ON  a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND	a.component_name	=	b.component_name
		AND a.control_type		=	b.ctrl_type_name
		WHERE	a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.control_bt_synonym	=  @combo_bt_synonym_in
		AND base_ctrl_type = 'Combo'
		UNION
		SELECT 'X'
		FROM de_ui_grid a (NOLOCK) 
		JOIN es_comp_ctrl_type_mst b (NOLOCK)
		ON a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND	a.component_name	=	b.component_name
		AND a.column_type		=	b.ctrl_type_name
		WHERE	a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.column_bt_synonym		=  @combo_bt_synonym_in
		AND base_ctrl_type = 'Combo'
		UNION
		SELECT 'X'
		FROM de_ui_grid a (NOLOCK) 
		JOIN de_ui_control b (NOLOCK)
		ON a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND a.component_name	=	b.component_name
		AND a.activity_name		=	b.activity_name
		AND a.ui_name			=	b.ui_name
		AND a.page_bt_synonym	=	b.page_bt_synonym
		AND a.section_bt_synonym	=	b.section_bt_synonym
		AND a.control_bt_synonym	=	b.control_bt_synonym
		JOIN es_comp_ctrl_type_mst c (NOLOCK)
		ON  b.customer_name		=	c.customer_name
		AND b.project_name		=	c.project_name
		AND b.process_name		=	c.process_name
		AND	b.component_name	=	c.component_name
		AND b.control_type		=	c.ctrl_type_name
		WHERE a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.column_bt_synonym		=  @combo_bt_synonym_in
		AND base_ctrl_type		= 'ListView'
		UNION
		SELECT 'X'
		FROM de_listedit_column a (NOLOCK) 
		WHERE	a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.listedit_column_synonym	=  @combo_bt_synonym_in
		)
		BEGIN
			RAISERROR('Load Methods are applicable only for Combo, MultiSelectCombo & List Controls. Error at Rowno: %i.',16,1,@fprowno)
			RETURN
		END


		SELECT @flowbrseq	=	ISNULL(max(flowbr_sequence),0)+1
		FROM	re_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in


		SELECT @brcontrol		=	control_bt_synonym,
			   @controlid		=	control_id,
			   @viewname		=	view_name,
			   @ctrl_prfx		=   control_prefix,
			   @controltype		=   'Combo',
			   @HdrML			=	'Hdr'
		FROM de_ui_control a (NOLOCK) 
		JOIN es_comp_ctrl_type_mst b (NOLOCK)
		ON  a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND	a.component_name	=	b.component_name
		AND a.control_type		=	b.ctrl_type_name
		WHERE	a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.control_bt_synonym	=  @combo_bt_synonym_in
		AND base_ctrl_type = 'Combo'
		
		IF ISNULL(@combobtname,'')	=	''
		BEGIN
		SELECT @brcontrol		=	column_bt_synonym ,
			   @controlid		=	control_id,
			   @viewname		=	view_name,
			   @ctrl_prfx		=   column_prefix,
			   @controltype		=   'Combo',
			   @HdrML			=	'ML'
		FROM de_ui_grid a (NOLOCK) 
		JOIN es_comp_ctrl_type_mst b (NOLOCK)
		ON a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND	a.component_name	=	b.component_name
		AND a.column_type		=	b.ctrl_type_name
		WHERE	a.customer_name			=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.column_bt_synonym		=  @combo_bt_synonym_in
		AND base_ctrl_type = 'Combo'
		END

		IF ISNULL(@combobtname,'')	=	''
		BEGIN
		SELECT @combobtname		=	a.column_bt_synonym,
			   @brcontrol		=	a.control_bt_synonym,
			   @controlid		=	b.control_id,
			   @viewname		=	b.view_name,
			   @ctrl_prfx		=   control_prefix,
			   @controltype		=   'MultiselectCombo'
		FROM de_ui_grid a (NOLOCK) 
		JOIN de_ui_control b (NOLOCK)
		ON a.customer_name		=	b.customer_name
		AND a.project_name		=	b.project_name
		AND a.process_name		=	b.process_name
		AND a.component_name	=	b.component_name
		AND a.activity_name		=	b.activity_name
		AND a.ui_name			=	b.ui_name
		AND a.page_bt_synonym	=	b.page_bt_synonym
		AND a.section_bt_synonym	=	b.section_bt_synonym
		AND a.control_bt_synonym	=	b.control_bt_synonym
		JOIN es_comp_ctrl_type_mst c (NOLOCK)
		ON  b.customer_name		=	c.customer_name
		AND b.project_name		=	c.project_name
		AND b.process_name		=	c.process_name
		AND	b.component_name	=	c.component_name
		AND b.control_type		=	c.ctrl_type_name
		WHERE a.customer_name	=	@customer_name_in
		AND		a.project_name			=	@project_name_in
		AND		a.process_name			=	@process_name_in
		AND		a.component_name		=	@component_name_in
		AND		a.activity_name			=	@activity_name_in
		AND		a.ui_name				=	@ui_name_in
		AND		a.column_bt_synonym		=  @combo_bt_synonym_in
		AND		base_ctrl_type			= 'ListView'
		END

		IF ISNULL(@combobtname,'')	=	''
		BEGIN
		SELECT @brcontrol		=	a.listedit_column_synonym,
			   @combobtname		=	a.listedit_synonym,
			   @ctrl_prfx		=   b.control_prefix,
			   @controlid		=	b.control_id,
			   @viewname		=	b.view_name,
			   @controltype		=   'ListEdit'
		FROM de_listedit_column a (NOLOCK) 
		JOIN de_ui_control b (NOLOCK)
		ON	a.customer_name	=	b.customer_name
		AND a.project_name	=	b.project_name
		AND a.process_name	=	b.process_name
		AND a.component_name=	b.component_name
		AND a.activity_name	=	b.activity_name
		AND a.ui_name		=	b.ui_name
		AND a.listedit_synonym	=	b.control_bt_synonym
		WHERE	a.customer_name				=	@customer_name_in
		AND		a.project_name				=	@project_name_in
		AND		a.process_name				=	@process_name_in
		AND		a.component_name			=	@component_name_in
		AND		a.activity_name				=	@activity_name_in
		AND		a.ui_name					=	@ui_name_in
		AND		a.listedit_column_synonym	=   @combo_bt_synonym_in
		END
			

		IF @controltype	=	'ListEdit'
		BEGIN
		SELECT	@flowbrname		=	@comp_prefix + @page_prefix +  @ctrl_prfx + '_LE_O'
		SELECT	@flowbrdesc = 'List Edit out for' + ' ' + @combobtname + ' - ' + @brcontrol
		SELECT	@event_name = 'LE_O' + @controlid
		SELECT  @tmpflowbr_descr = '%'+ ISNULL(@combobtname,'') + '%' + ISNULL(@brcontrol,'') + '%'
		END
		
		IF @controltype	=	'MultiselectCombo'
		BEGIN
		SELECT	@flowbrname		=	@comp_prefix + @page_prefix +  @ctrl_prfx + 'LdCmb'
		SELECT	@flowbrdesc = 'Flow BR for populating the MultiselectCombo' + ' ' + @combobtname + ' - ' + @brcontrol
		SELECT	@event_name = 'Attach_CmbLoad' + @controlid + @viewname
		SELECT  @tmpflowbr_descr = '%'+ ISNULL(@combobtname,'') + '%' + ISNULL(@brcontrol,'') + '%'
		END
		
		IF @controltype	=	'Combo'	AND	@HdrML	=	'Hdr'
		BEGIN
		SELECT	@flowbrname		=	@comp_prefix + @page_prefix +  @ctrl_prfx + 'LdCmb'
		SELECT	@flowbrdesc = 'Flow BR for populating the combo' + ' ' + @brcontrol + ' - ' + @brcontrol
		SELECT	@event_name = 'Hdr_Fetch'
		SELECT  @tmpflowbr_descr = '%'+ ISNULL(@brcontrol,'') + '%'
		END

		IF @controltype	=	'Combo' AND	@HdrML	=	'ML'
		BEGIN
		SELECT	@flowbrname		=	@comp_prefix + @page_prefix +  @ctrl_prfx + 'LdCmb'
		SELECT	@flowbrdesc = 'Flow BR for populating the combo' + ' ' + @brcontrol + ' - ' + @brcontrol
		SELECT	@event_name = 'ML_fetch' + @controlid
		SELECT  @tmpflowbr_descr = '%'+ ISNULL(@brcontrol,'') + '%'
		END

	--	SELECT @tmpflowbr_descr = '%'+ ISNULL(@combobtname,'') + '%' + ISNULL(@brcontrol,'') + '%'
	
		IF ISNULL(@modeflag,'')	IN ('U','Y')
		BEGIN

		IF ISNULL(@engg_tc_load,0)	=	1
		BEGIN

		IF ISNULL(@controltype,'')	=	'MultiselectCombo'
		AND NOT EXISTS (SELECT 'X'
						FROM de_business_term	(NOLOCK)
						WHERE customer_name = @customer_name_in
						AND project_name	= @project_name_in
						AND process_name	= @process_name_in
						AND component_name  = @component_name_in
						AND bt_name			= 'MultiSelectList'
						)
		BEGIN
				INSERT INTO de_business_term (
						customer_name,		project_name,		process_name,	component_name,
						bt_name,			bt_descr,			data_type,		bt_sysid,
						TIMESTAMP,			createdby,			createddate,	modifiedby,
						modifieddate,		length,				ecrno)
				SELECT @customer_name_in,	@project_name_in,	@process_name_in,	@component_name_in,
					   'MultiSelectList',	'MultiSelectList',	'Char',				newid(),
						1,					 @ctxt_user_in,		Getdate(),			@ctxt_user_in,
						Getdate(),			 8000,				@engg_ecr_no
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	re_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		)
		BEGIN
		INSERT INTO re_flowbr (
			customer_name,			project_name,			process_name,			component_name,
			activity_name,			ui_name,				page_bt_synonym,		task_name,
			flowbr_name,			flowbr_descr,			flowbr_sequence,		flowbr_sysid,
			task_sysid,				timestamp,				createdby,				createddate,
			modifiedby,				modifieddate,			map_flag,				control_id,
			view_name,				event_name,				rcnno) --chan
		VALUES (
			@customer_name_in,		@project_name_in,		@process_name_in,		@component_name_in,
			@activity_name_in,		@ui_name_in,			@page_bt_synonym_in,	@task_name_in,
			@flowbrname,			@flowbrdesc,			@flowbrseq,				NEWID(),
			NEWID(),				@timestamp_in,			@ctxt_user_in,			GETDATE(),
			@ctxt_user_in,			GETDATE(),				'Y',					@controlid,
			@viewname,				@event_name,			NULL
			) --chan
		END


		IF NOT EXISTS(
		SELECT 'X'
		FROM	de_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		)
		BEGIN
		INSERT INTO de_flowbr (
			customer_name,			project_name,			process_name,			component_name,
			activity_name,			ui_name,				page_bt_synonym,		task_name,
			flowbr_name,			flowbr_descr,			flowbr_sequence,		flowbr_sysid,
			task_sysid,				timestamp,				createdby,				createddate,
			modifiedby,				modifieddate,			map_flag,				control_id,
			view_name,				event_name,				ecrno) --chan
		VALUES (
			@customer_name_in,		@project_name_in,		@process_name_in,		@component_name_in,
			@activity_name_in,		@ui_name_in,			@page_bt_synonym_in,	@task_name_in,
			@flowbrname,			@flowbrdesc,			@flowbrseq,				NEWID(),
			NEWID(),				@timestamp_in,			@ctxt_user_in,			GETDATE(),
			@ctxt_user_in,			GETDATE(),				'Y',					@controlid,
			@viewname,				@event_name,			@engg_ecr_no
			) --chan
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	re_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		--AND		combo_bt_synonym=	@combobtname
		--AND		combo_page_name	=	@combo_page_name_in)
		AND NOT EXISTS	(SELECT 'X'
		FROM de_listedit_column a (NOLOCK) 
		WHERE	a.customer_name				=	@customer_name_in
		AND		a.project_name				=	@project_name_in
		AND		a.process_name				=	@process_name_in
		AND		a.component_name			=	@component_name_in
		AND		a.activity_name				=	@activity_name_in
		AND		a.ui_name					=	@ui_name_in
		AND		a.listedit_column_synonym	=  @combo_bt_synonym_in)
		BEGIN
		INSERT INTO re_flowbr_combo (
			customer_name,			project_name,			process_name,			component_name,
			activity_name,			ui_name,				page_bt_synonym,		task_name,
			flowbr_name,			combo_bt_synonym,		combo_page_name,		clear_tree_before_population,
			combo_sysid,			flowbr_sysid,			createdby,				createddate,
			modifiedby,				modifieddate,			timestamp,				rcnno) --chan
		VALUES (
			@customer_name_in,		@project_name_in,		@process_name_in,		@component_name_in,
			@activity_name_in,		@ui_name_in,			@page_bt_synonym_in,	@task_name_in,
			@flowbrname,			@brcontrol,				@combo_page_name_in,	@clear_tree_before_population_in,
			NEWID(),				NEWID(),				@ctxt_user_in,			GETDATE(),
			@ctxt_user_in,			GETDATE(),				@timestamp_in,			NULL
			) --chan
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	de_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		--AND		combo_bt_synonym=	@combobtname
		--AND		combo_page_name	=	@combo_page_name_in)
		AND NOT EXISTS	(SELECT 'X'
		FROM de_listedit_column a (NOLOCK) 
		WHERE	a.customer_name				=	@customer_name_in
		AND		a.project_name				=	@project_name_in
		AND		a.process_name				=	@process_name_in
		AND		a.component_name			=	@component_name_in
		AND		a.activity_name				=	@activity_name_in
		AND		a.ui_name					=	@ui_name_in
		AND		a.listedit_column_synonym	=  @combo_bt_synonym_in)
		BEGIN		
		INSERT INTO de_flowbr_combo (
			customer_name,			project_name,			process_name,			component_name,
			activity_name,			ui_name,				page_bt_synonym,		task_name,
			flowbr_name,			combo_bt_synonym,		combo_page_name,		clear_tree_before_population,
			combo_sysid,			flowbr_sysid,			createdby,				createddate,
			modifiedby,				modifieddate,			timestamp,				ecrno) --chan
		VALUES (
			@customer_name_in,		@project_name_in,		@process_name_in,		@component_name_in,
			@activity_name_in,		@ui_name_in,			@page_bt_synonym_in,	@task_name_in,
			@flowbrname,			@brcontrol,				@combo_page_name_in,	@clear_tree_before_population_in,
			NEWID(),				NEWID(),				@ctxt_user_in,			GETDATE(),
			@ctxt_user_in,			GETDATE(),				@timestamp_in,			@engg_ecr_no
			) --chan
		END

		END

		IF ISNULL(@engg_tc_load,0)	=	0
		BEGIN
		IF ISNULL(@controltype,'')	IN	('Combo','ListEdit')
		BEGIN
		IF EXISTS(
		SELECT 'X'
		FROM	re_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		combo_bt_synonym=	@brcontrol
		AND		combo_page_name	=	@combo_page_name_in
		)
		BEGIN
			DELETE
			FROM	re_flowbr_combo 
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		combo_bt_synonym=	@brcontrol
			AND		combo_page_name	=	@combo_page_name_in
		END

		IF EXISTS(
		SELECT 'X'
		FROM	de_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		combo_bt_synonym=	@brcontrol
		AND		combo_page_name	=	@combo_page_name_in)
		BEGIN
			DELETE
			FROM	de_flowbr_combo 
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		combo_bt_synonym=	@brcontrol
			AND		combo_page_name	=	@combo_page_name_in
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	re_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		AND		EXISTS (SELECT 'X'
		FROM	re_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		flowbr_descr	like @tmpflowbr_descr
		)
		BEGIN
			DELETE  re_flowbr
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		flowbr_descr	like @tmpflowbr_descr
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	de_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		AND		EXISTS (SELECT 'X'
		FROM	de_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		flowbr_descr	like @tmpflowbr_descr)
		BEGIN
			DELETE  de_flowbr
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		flowbr_descr	like @tmpflowbr_descr
		END

		END

		IF ISNULL(@controltype,'')	=	'MultiselectCombo'
		BEGIN
		
		SELECT @sectionname	=	 section_name 
		FROM  de_task_control_map  
		WHERE customer_name		 =	@customer_name_in
		AND	  project_name		 =	@project_name_in
		AND	  process_name		 =	@process_name_in
		AND	  component_name	 =	@component_name_in
		AND	  activity_name		 =	@activity_name_in
		AND	  ui_name			 =	@ui_name_in
		AND	  page_name			 =	@page_bt_synonym_in
		AND   control_type		 = 'MultiselectCombo'
		AND   control_bt_synonym = @combo_bt_synonym_in
		
		SELECT @loadcnt = COUNT(*)
		FROM	(
		SELECT DISTINCT ISNULL(Load,'N') Load
		FROM  de_task_control_map  (NOLOCK)
		WHERE customer_name		 =	@customer_name_in
		AND	  project_name		 =	@project_name_in
		AND	  process_name		 =	@process_name_in
		AND	  component_name	 =	@component_name_in
		AND	  activity_name		 =	@activity_name_in
		AND	  ui_name			 =	@ui_name_in
		AND	  page_name			 =	@page_bt_synonym_in
		AND	  section_name		 =  @sectionname
		AND   control_type		 = 'MultiselectCombo')a
		
		IF @loadcnt	=	1
		BEGIN
			SELECT @mapload			=   ISNULL(Load,'N')
			FROM  de_task_control_map  
			WHERE customer_name		 =	@customer_name_in
			AND	  project_name		 =	@project_name_in
			AND	  process_name		 =	@process_name_in
			AND	  component_name	 =	@component_name_in
			AND	  activity_name		 =	@activity_name_in
			AND	  ui_name			 =	@ui_name_in
			AND	  page_name			 =	@page_bt_synonym_in
			AND	  section_name		 =  @sectionname
			AND   control_type		 = 'MultiselectCombo'
		END


		IF ISNULL(@mapload,'N')	=	'N' AND @loadcnt	=	1
		BEGIN
		IF EXISTS(
		SELECT 'X'
		FROM	re_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		combo_bt_synonym=	@brcontrol
		AND		combo_page_name	=	@combo_page_name_in
		)
		BEGIN
			DELETE
			FROM	re_flowbr_combo 
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		combo_bt_synonym=	@brcontrol
			AND		combo_page_name	=	@combo_page_name_in
		END

		IF EXISTS(
		SELECT 'X'
		FROM	de_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		combo_bt_synonym=	@brcontrol
		AND		combo_page_name	=	@combo_page_name_in)
		BEGIN
			DELETE
			FROM	de_flowbr_combo 
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		combo_bt_synonym=	@brcontrol
			AND		combo_page_name	=	@combo_page_name_in
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	re_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		AND		EXISTS (SELECT 'X'
		FROM	re_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		flowbr_descr	like @tmpflowbr_descr
		)
		BEGIN
			DELETE  re_flowbr
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		flowbr_descr	like @tmpflowbr_descr
		END

		IF NOT EXISTS(
		SELECT 'X'
		FROM	de_flowbr_combo (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname)
		AND		EXISTS (SELECT 'X'
		FROM	de_flowbr (NOLOCK)
		WHERE	customer_name	=	@customer_name_in
		AND		project_name	=	@project_name_in
		AND		process_name	=	@process_name_in
		AND		component_name	=	@component_name_in
		AND		activity_name	=	@activity_name_in
		AND		ui_name			=	@ui_name_in
		AND		page_bt_synonym	=	@page_bt_synonym_in
		AND		task_name		=	@task_name_in
		AND		flowbr_name		=	@flowbrname
		AND		flowbr_descr	like @tmpflowbr_descr)
		BEGIN
			DELETE  de_flowbr
			WHERE	customer_name	=	@customer_name_in
			AND		project_name	=	@project_name_in
			AND		process_name	=	@process_name_in
			AND		component_name	=	@component_name_in
			AND		activity_name	=	@activity_name_in
			AND		ui_name			=	@ui_name_in
			AND		page_bt_synonym	=	@page_bt_synonym_in
			AND		task_name		=	@task_name_in
			AND		flowbr_name		=	@flowbrname
			AND		flowbr_descr	like @tmpflowbr_descr
		END
		END

		END

		END
		END

	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DE_FLOWBR_COMBO_SP_INS_DEL' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON DE_FLOWBR_COMBO_SP_INS_DEL	TO PUBLIC
END
GO

