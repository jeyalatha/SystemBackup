IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_gengen' AND TYPE = 'P')
BEGIN
  DROP PROC de_design_sp_gengen
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_design_sp_gengen.sql
********************************************************************************/
/*      V E R S I O N      :  2 . 0 . 4    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 12 - Jan -05 (Patch Release 1)    */
/********************************************************************************/
/* procedure    : de_design_sp_gengen                                           */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vasu k                                                        */
/* date         : 11/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : arunn                                                         */
/* date         : 14-nov-2005                                                   */
/* description  : to avoid the service generation for the service which is designed in DR */
/* Modified by saravanan for PNR2.0_9234 on 04-July-2006                        */
/* Modified by kiruthika for PNR2.0_9976 on 22-Aug-2006                        */
/* Modified by Gowrisankar for PNR2.0_9986 on 23-Aug-2006                       */
/* Modified by kiruthika for PNR2.0_9998 on 23-Aug-2006                        */
/* Modified by Gowrisankar for PNR2.0_14883 on 09-Aug-2007                        */
/* Modified by Sangeetha G for PNR2.0_14989 on 17-Aug-2007                        */
/* Modified by Chanheetha N A  for PNR2.0_15944 on 07-Nov-2007                  */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/********************************************************************************/
/* modified by   : Gowrisankar M           */
/* date     : 25-Sep-2008           */
/* BugId    : PNR2.0_19421, PNR2.0_19423         */
/* Description   : Validation added for Blank Control Prefixes   */
/********************************************************************************/
/* modified by   : Feroz           */
/* date     : 25-nov-2008         */
/* BugId    : PNR2.0_1790          */
/********************************************************************************/
/* modified by   : Chanheetha N A          */
/* date     : 10-02-2009           */
/* BugId    : PNR2.0_19412            */
/* Description   : Validation added for Blank Page Prefixes    */
/********************************************************************************/
/* modified by  : Feroz                                                */
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179             */
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
-- code modified by Ganesh for the mismatch in DR parameter
-- for the bugid :: DEENG203ACC_000133 on 30/12/04
/********************************************************************************/
/* modified by  : Makesh Prabu R            */
/* date         : 13-July-2010             */
/* Bug Id   : PNR2.0_27510             */
/* Description  : control prefix can not be blank or null error     */
/********************************************************************************/
/* modified by  : Sangeetha G												*/
/* date         : 18-Aug-2010												*/
/* Bug Id		: PNR2.0_27959												*/
/* Description  : Update sevice  removing some of the existing methods      */
/*				  and Updating the parameters								*/
/********************************************************************************/
/* modified by  : Sangeetha G												*/
/* date         : 16-Mar-2011												*/
/* Bug Id		: PNR2.0_30573												*/
/* Description  : Hdr save  and  ML save alone  for disposal tasks			*/
/********************************************************************************/
/* Modified by  :          Balaji D                                             */
/* Date         :          Feb 06 2011                                          */
/* Bug Id		:          PLF2.0_00214 										*/
/* Description  :          Zipped service release                               */
/********************************************************************************/
/* Modified by  :          Balaji D                                             */
/* Date         :          May 15 2012                                          */
/* Bug Id		:          PLF2.0_00376 										*/
/* Description  :          Validation needed while setting key pattern with     */
/*                         the special characters except !,$,~                  */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
/* Created by  	: Kiruthika R                                               	*/
/* Date         : 13-June-2016                                                  */
/*Defect Id 	: PLF2.0_18487	(Performance Tuning)							*/
/********************************************************************************/
/* Modified by: Jeya Latha/Ranjitha    Defect ID: TECH-16126      On: 30-Nov-2017 */
/********************************************************************************/
/* Modified by  : Jeya Latha K	Date: 30-Apr-2018  Defect ID : TECH-20897 */
/*******************************************************************************/
/* Modified by  : Ranjitha R		Date: 31-May-2018  Defect ID : TECH-22358 */
/*******************************************************************************/
CREATE PROCEDURE de_design_sp_gengen
	@ctxt_language engg_ctxt_language,
	@ctxt_ouinstance engg_ctxt_ouinstance,
	@ctxt_service engg_ctxt_service,
	@ctxt_user engg_ctxt_user,
	@engg_act_descr engg_description,
	@engg_act_pending engg_seqno,
	@engg_act_total engg_seqno,
	@engg_all_pages engg_flag,
	@engg_all_tasks engg_flag,
	@engg_component engg_description,
	@engg_customer_name engg_name,
	-- code modified by shafina on 11-Jan-2005 for DEENG203ACC_000135(New tab for ActionReuse is added.)
	@engg_gen_clearkey_pattern engg_description, --Input --Code Added for the Bug ID: PLF2.0_00214
	@engg_gen_is engg_seqno,
	@engg_gen_iscached engg_seqno, --Input --Code Added for the Bug ID: PLF2.0_00214
	@engg_gen_iszipped engg_seqno, --Input --Code Added for the Bug ID: PLF2.0_00214
	@engg_gen_last_gen engg_type, --engg_name ,--engg_date,  (Code modified by DNR for DEENG203ACC_000018)
	@engg_gen_met_count engg_seqno,
	@engg_gen_remarks engg_description,
	@engg_gen_ser_name engg_name,
	@engg_gen_setkey_pattern engg_description, --Input  --Code Added for the Bug ID: PLF2.0_00214
	@engg_gen_task_descr engg_description,
	@engg_gen_task_name engg_name,
	@engg_gen_task_pattern engg_name,
	@engg_ico_no engg_name,
	@engg_met_service engg_name,
	@engg_met_task engg_description,
	@engg_met_taskdescr engg_description,
	@engg_page_descr engg_description,
	@engg_page_pending engg_seqno,
	@engg_page_total engg_seqno,
	@engg_par_service engg_name,
	@engg_par_task engg_description,
	@engg_par_taskdescr engg_description,
	@engg_proj_proc_descr engg_description,
	@engg_project_name engg_name,
	@engg_ps_service engg_name,
	@engg_ps_task engg_description,
	@engg_ps_taskdescr engg_description,
	@engg_sdi_service engg_name,
	@engg_sdi_task engg_description,
	@engg_sdi_taskdescr engg_description,
	@engg_seg_service engg_name,
	@engg_seg_task engg_description,
	@engg_seg_taskdescr engg_description,
	@engg_ui_descr engg_description,
	@engg_ui_pending engg_seqno,
	@engg_ui_total engg_seqno,
	@modeflag engg_modeflag,
	@errorno INT, --@engg_errorno
	@fprowno engg_rowno,
	@placeholder1 VARCHAR(50), --engg_placeholder,
	@placeholder2 VARCHAR(50), --engg_placeholder,
	@placeholder3 VARCHAR(50), --engg_placeholder,
	@placeholder4 VARCHAR(50), --engg_placeholder,
	@successflag INT, --engg_successflag,
	@engg_gen_mode	engg_name,		--TECH-75230
	@engg_gen_applyrefine	engg_seqno,	--TECH-75230
	@engg_gen_refine_met_count	engg_seqno, --TECH-75230
	@m_errorid INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	--temporary and formal parameters mapping
	SELECT @ctxt_language = @ctxt_language

	SELECT @ctxt_ouinstance = @ctxt_ouinstance

	SELECT @ctxt_service = ltrim(rtrim(@ctxt_service))

	SELECT @ctxt_user = ltrim(rtrim(@ctxt_user))

	SELECT @engg_act_descr = ltrim(rtrim(@engg_act_descr))

	SELECT @engg_act_pending = @engg_act_pending

	SELECT @engg_act_total = @engg_act_total

	SELECT @engg_all_pages = ltrim(rtrim(@engg_all_pages))

	SELECT @engg_all_tasks = ltrim(rtrim(@engg_all_tasks))

	SELECT @engg_component = ltrim(rtrim(@engg_component))

	SELECT @engg_customer_name = ltrim(rtrim(@engg_customer_name))

	SELECT @engg_gen_is = @engg_gen_is

	--select @engg_gen_last_gen            = ltrim(rtrim(@engg_gen_last_gen))
	SELECT @engg_gen_met_count = @engg_gen_met_count

	SELECT @engg_gen_ser_name = ltrim(rtrim(@engg_gen_ser_name))

	SELECT @engg_gen_task_descr = ltrim(rtrim(@engg_gen_task_descr))

	SELECT @engg_gen_task_name = ltrim(rtrim(@engg_gen_task_name))

	SELECT @engg_gen_task_pattern = ltrim(rtrim(@engg_gen_task_pattern))

	SELECT @engg_ico_no = ltrim(rtrim(@engg_ico_no))

	SELECT @engg_met_service = ltrim(rtrim(@engg_met_service))

	SELECT @engg_met_task = ltrim(rtrim(@engg_met_task))

	SELECT @engg_met_taskdescr = ltrim(rtrim(@engg_met_taskdescr))

	SELECT @engg_page_descr = ltrim(rtrim(@engg_page_descr))

	SELECT @engg_page_pending = @engg_page_pending

	SELECT @engg_page_total = @engg_page_total

	SELECT @engg_par_service = ltrim(rtrim(@engg_par_service))

	SELECT @engg_par_task = ltrim(rtrim(@engg_par_task))

	SELECT @engg_par_taskdescr = ltrim(rtrim(@engg_par_taskdescr))

	SELECT @engg_proj_proc_descr = ltrim(rtrim(@engg_proj_proc_descr))

	SELECT @engg_project_name = ltrim(rtrim(@engg_project_name))

	SELECT @engg_ps_service = ltrim(rtrim(@engg_ps_service))

	SELECT @engg_ps_task = ltrim(rtrim(@engg_ps_task))

	SELECT @engg_ps_taskdescr = ltrim(rtrim(@engg_ps_taskdescr))

	SELECT @engg_sdi_service = ltrim(rtrim(@engg_sdi_service))

	SELECT @engg_sdi_task = ltrim(rtrim(@engg_sdi_task))

	SELECT @engg_sdi_taskdescr = ltrim(rtrim(@engg_sdi_taskdescr))

	SELECT @engg_seg_service = ltrim(rtrim(@engg_seg_service))

	SELECT @engg_seg_task = ltrim(rtrim(@engg_seg_task))

	SELECT @engg_seg_taskdescr = ltrim(rtrim(@engg_seg_taskdescr))

	SELECT @engg_ui_descr = ltrim(rtrim(@engg_ui_descr))

	SELECT @engg_ui_pending = @engg_ui_pending

	SELECT @engg_ui_total = @engg_ui_total

	SELECT @modeflag = ltrim(rtrim(@modeflag))

	--select @errorno                       = @errorno
	--select @fprowno                       = @fprowno
	--select @placeholder1                  = ltrim(rtrim(@placeholder1))
	--select @placeholder4                  = ltrim(rtrim(@placeholder4))
	--select @successflag                   = @successflag
	--Code Added for the Bug ID: PLF2.0_00214 starts
	SET @engg_gen_clearkey_pattern = ltrim(rtrim(@engg_gen_clearkey_pattern))
	SET @engg_gen_setkey_pattern = ltrim(rtrim(@engg_gen_setkey_pattern))

	--Code Added for the Bug ID: PLF2.0_00214 ends
	--null checking
	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SELECT @engg_act_descr = NULL

	IF @engg_act_pending = - 915
		SELECT @engg_act_pending = NULL

	IF @engg_act_total = - 915
		SELECT @engg_act_total = NULL

	IF @engg_all_pages = '~#~'
		SELECT @engg_all_pages = NULL

	IF @engg_all_tasks = '~#~'
		SELECT @engg_all_tasks = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_gen_is = - 915
		SELECT @engg_gen_is = NULL

	--if @engg_gen_last_gen   = '~#~' select @engg_gen_last_gen   = null
	IF @engg_gen_met_count = - 915
		SELECT @engg_gen_met_count = NULL

	IF @engg_gen_ser_name = '~#~'
		SELECT @engg_gen_ser_name = NULL

	IF @engg_gen_task_descr = '~#~'
		SELECT @engg_gen_task_descr = NULL

	IF @engg_gen_task_name = '~#~'
		SELECT @engg_gen_task_name = NULL

	IF @engg_gen_task_pattern = '~#~'
		SELECT @engg_gen_task_pattern = NULL

	IF @engg_ico_no = '~#~'
		SELECT @engg_ico_no = NULL

	IF @engg_met_service = '~#~'
		SELECT @engg_met_service = NULL

	IF @engg_met_task = '~#~'
		SELECT @engg_met_task = NULL

	IF @engg_met_taskdescr = '~#~'
		SELECT @engg_met_taskdescr = NULL

	IF @engg_page_descr = '~#~'
		SELECT @engg_page_descr = NULL

	IF @engg_page_pending = - 915
		SELECT @engg_page_pending = NULL

	IF @engg_page_total = - 915
		SELECT @engg_page_total = NULL

	IF @engg_par_service = '~#~'
		SELECT @engg_par_service = NULL

	IF @engg_par_task = '~#~'
		SELECT @engg_par_task = NULL

	IF @engg_par_taskdescr = '~#~'
		SELECT @engg_par_taskdescr = NULL

	IF @engg_proj_proc_descr = '~#~'
		SELECT @engg_proj_proc_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_ps_service = '~#~'
		SELECT @engg_ps_service = NULL

	IF @engg_ps_task = '~#~'
		SELECT @engg_ps_task = NULL

	IF @engg_ps_taskdescr = '~#~'
		SELECT @engg_ps_taskdescr = NULL

	IF @engg_sdi_service = '~#~'
		SELECT @engg_sdi_service = NULL

	IF @engg_sdi_task = '~#~'
		SELECT @engg_sdi_task = NULL

	IF @engg_sdi_taskdescr = '~#~'
		SELECT @engg_sdi_taskdescr = NULL

	IF @engg_seg_service = '~#~'
		SELECT @engg_seg_service = NULL

	IF @engg_seg_task = '~#~'
		SELECT @engg_seg_task = NULL

	IF @engg_seg_taskdescr = '~#~'
		SELECT @engg_seg_taskdescr = NULL

	IF @engg_ui_descr = '~#~'
		SELECT @engg_ui_descr = NULL

	IF @engg_ui_pending = - 915
		SELECT @engg_ui_pending = NULL

	IF @engg_ui_total = - 915
		SELECT @engg_ui_total = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	--if @errorno     = -915 select @errorno     = null
	--if @fprowno     = -915 select @fprowno     = null
	--if @placeholder1    = '~#~' select @placeholder1    = null
	--if @placeholder2    = '~#~' select @placeholder2    = null
	--if @placeholder3    = '~#~' select @placeholder3    = null
	--if @placeholder4    = '~#~' select @placeholder4    = null
	--if @successflag    = -915 select @successflag    = null
	--Code Added for the Bug ID: PLF2.0_00214 starts
	IF @engg_gen_clearkey_pattern = '~#~'
		SELECT @engg_gen_clearkey_pattern = NULL

	IF @engg_gen_iscached = - 915
		SELECT @engg_gen_iscached = NULL

	IF @engg_gen_iszipped = - 915
		SELECT @engg_gen_iszipped = NULL

	IF @engg_gen_setkey_pattern = '~#~'
		SELECT @engg_gen_setkey_pattern = NULL

	--Code Added for the Bug ID: PLF2.0_00214 ends
	DECLARE @service_name engg_name
	DECLARE @msg engg_documentation
	DECLARE @task_type engg_name
	DECLARE @wkf_req engg_flag
	DECLARE @area_code engg_name
	DECLARE @proc_sel_rows_tmp engg_flag

	SELECT @fprowno = @fprowno + 1

	IF (@modeflag = 's')
	BEGIN
		SELECT NULL 'errorno',
			@fprowno 'fprowno',
			NULL 'placeholder1',
			NULL 'placeholder2',
			NULL 'placeholder3',
			NULL 'placeholder4',
			0 'successflag'

		RETURN
	END

	CREATE TABLE #populate_header_control_extjs (
		control_name VARCHAR(60) collate database_default,
		default_value VARCHAR(30) collate database_default,
		bt_name VARCHAR(60) collate database_default,
		data_type VARCHAR(12) collate database_default,
		controlid VARCHAR(60) collate database_default,
		viewname VARCHAR(60) collate database_default,
		page_name VARCHAR(60) collate database_default
		)

	CREATE TABLE #populate_mapped_controls_extjs (
		page_bt_synonym VARCHAR(60) collate database_default,
		control_bt_synonym VARCHAR(60) collate database_default,
		control_id VARCHAR(60) collate database_default,
		control_prefix VARCHAR(20) collate database_default
		)

	CREATE TABLE #Listedit_Control (
		page_bt_synonym VARCHAR(60) collate database_default,
		control_bt_synonym VARCHAR(60) collate database_default,
		column_bt_synonym VARCHAR(60) collate database_default,
		control_id VARCHAR(60) collate database_default,
		view_name VARCHAR(60) collate database_default
		)

	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	-- Code modified by bakiaraj v on 28 DEC 2004 for the BUG ID : DEPF204ACC_000044
	SELECT @service_name = service_name
	FROM de_task_service_map(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp
		AND task_name = @engg_gen_task_name

	--code added by Kanagavel A for manual services checking 
	IF @modeflag IN (
			'Z',
			'Y',
			'U'
			)
	BEGIN
		IF EXISTS (
				SELECT 'K'
				FROM de_service_gen_log(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND task_name = @engg_gen_task_name
					AND Manually_Modified = 'Y'
				)
		BEGIN
			RAISERROR (
					'The Task has been involved in Manual Service.It can not be generated',
					16,
					1
					)

			RETURN
		END
	END

	-- Code added for TECH-16126 Starts
	IF EXISTS (
			SELECT 'x'
			FROM de_action(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND ecrno = @engg_ico_no
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_page_descr
				AND task_name = @engg_gen_task_name
				AND autoupload = 'Y'
			)
	BEGIN
		SELECT @msg = 'Please proceed with ''Manage Offline Task'' activity for Offline Tasks. Error at Row No.' + convert(CHAR(3), @fprowno)

		RAISERROR (
				@msg,
				16,
				1
				)

		RETURN
	END

	-- Code added for TECH-16126 Ends
	IF @engg_all_pages IS NULL
		SELECT @engg_all_pages = 0

	IF @engg_all_tasks IS NULL
		SELECT @engg_all_tasks = 0

	-- both 'All Pages' and 'All Tasks' are not selected
	-- and multiline selected, generate service for the selected task
	IF @engg_all_pages = 0
		AND @engg_all_tasks = 0
		AND @modeflag IN (
			'z',
			'Y'
			) --code modified for bugid:PNR2.0_9998
	BEGIN
		IF EXISTS (
				SELECT 'x'
				FROM de_fw_des_service(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND componentname = @component_name_tmp
					AND servicename = @service_name
					AND servicename NOT IN (
						SELECT DISTINCT service_name
						FROM de_service_gen_log_dtl(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @activity_name_tmp
							AND ui_name = @ui_name_tmp
							AND task_name = @engg_gen_task_name
						)
				)
		BEGIN
			SELECT @msg = 'The service is designed in Design Refinement, it cannot be generated.'

			EXEC engg_error_sp 'de_design_sp_gengen',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END

		-- Code modification for  PNR2.0_30573 starts 
		-- Code modification for  PNR2.0_30573 starts 
		DECLARE @ReturnValue NVARCHAR(max)
		DECLARE @query NVARCHAR(max)
		DECLARE @i NVARCHAR(max)

		IF EXISTS (
				SELECT '*'
				FROM de_action(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND task_name = @engg_gen_task_name
					AND task_type = 'disposal'
				)
		BEGIN
			SELECT @ReturnValue = COALESCE(@ReturnValue + ', '''')+ isnull(', '') + b.name
			FROM sysobjects a(NOLOCK),
				syscolumns b(NOLOCK)
			WHERE a.name = 'es_comp_task_type_mst'
				AND a.id = b.id
				AND b.name NOT IN (
					'comp_task_type_sysid',
					'timestamp',
					'createdby',
					'createddate',
					'modifiedby',
					'modifieddate',
					'task_type_doc',
					'customer_name',
					'project_name',
					'req_no',
					'process_name',
					'component_name',
					'task_type_name',
					'task_type_descr',
					'default_for',
					'no_placeholder',
					'trn_scope_req',
					'hdr_save_req',
					'ml_save_req',
					'fprowno_req'
					)

			SELECT @query = 'Select @i = isnull(' + COALESCE(@query, '') + @ReturnValue + ', '''')' + ' from es_comp_task_type_mst (nolock) where customer_name  = ''' + @engg_customer_name + ''' and project_name = ''' + @engg_project_name + ''' and  process_name  = ''' + @process_name_tmp + ''' and component_name  =  ''' + @component_name_tmp + ''' and task_type_name = ''' + @engg_gen_task_pattern + ''''

			EXEC sp_executesql @query = @query,
				@params = N'@i  nvarchar(max) OUTPUT',
				@i = @i OUTPUT

			IF charindex('y', @i, 1) <> 0
			BEGIN
				RAISERROR (
						'Task patterns with properties other than HdrSave,MLsave,transcope,fprowno reqd cannot be mapped to Diposal Tasks',
						16,
						1
						)

				RETURN
			END
		END

		-- Code modification for  PNR2.0_30573 ends 
		-- Code added for PNR2.0_19421 / PNR2.0_19423 by Gowrisankar on 25-Sep-2008 -- Starts
		DECLARE @nullprefixctrl engg_name,
			@nullprefixpage engg_name,
			@nullprefixsec engg_name

		-- Code added for PNR2.0_19412 by chanheetha on 10-02-2009 -- starts
		SELECT @nullprefixpage = ''

		SELECT @nullprefixpage = a.page_name
		FROM de_task_control_map a(NOLOCK),
			de_ui_page b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp
			AND a.activity_name = @activity_name_tmp
			AND a.ui_name = @ui_name_tmp
			AND a.action_name = @engg_gen_task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ui_name = b.ui_name
			AND a.page_name = b.page_bt_synonym
			AND isnull(b.page_prefix, '') = ''

		IF isnull(@nullprefixpage, '') <> ''
		BEGIN
			SELECT @msg = 'Page Prefix is blank for the Page "' + @nullprefixpage + '". Service cannot be generated for the task "' + @engg_gen_task_name + '"'

			EXEC engg_error_sp 'de_design_sp_gengen',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END

		-- Code added for PNR2.0_19412 by chanheetha on 10-02-2009 -- ends
		SELECT @nullprefixpage = a.page_name,
			@nullprefixsec = a.section_name,
			@nullprefixctrl = a.control_bt_synonym
		FROM de_task_control_map a(NOLOCK),
			de_ui_control b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp
			AND a.activity_name = @activity_name_tmp
			AND a.ui_name = @ui_name_tmp
			AND a.action_name = @engg_gen_task_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.activity_name = b.activity_name
			AND a.ui_name = b.ui_name
			AND a.page_name = b.page_bt_synonym
			AND a.section_name = b.section_bt_synonym
			AND a.control_bt_synonym = b.control_bt_synonym
			AND isnull(b.control_prefix, '') = ''
			AND (
				a.map_flag = 'Y'
				OR a.map_ml_flag = 'Y'
				) /* Code Added by Makesh Prabu R for CaseID: PNR2.0_27510 on 13/July/2010 */

		IF isnull(@nullprefixctrl, '') <> ''
		BEGIN
			SELECT @msg = 'Control Prefix is blank for the Control "' + @nullprefixctrl + '" in Page-Section : "' + @nullprefixpage + '-' + @nullprefixsec + '". Service cannot be generated for the task "' + @engg_gen_task_name + '"'

			EXEC engg_error_sp 'de_design_sp_gengen',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END
	
		-- Code added for PNR2.0_19421 / PNR2.0_19423 by Gowrisankar on 25-Sep-2008 -- Ends
		/** Mapping hidden views generated while creating controls related to Attach Document, Dynamic File upload, Multi file Select and Metadata based Link
	to  de_hidden_view_usage table. Code added for the Defect is: TECH-22358 .*/
		INSERT INTO de_hidden_view_usage (
			customer_name,
			project_name,
			process_name,
			component_name,
			activity_name,
			ui_name,
			page_name,
			action_name,
			control_bt_sysnonym,
			hidden_view_bt_sysnonym,
			TIMESTAMP,
			createdby,
			createddate,
			modifiedby,
			modifieddate,
			control_page_name,
			map_ml_flag,
			ecrno
			)
		SELECT customer_name,
			project_name,
			process_name,
			component_name,
			activity_name,
			ui_name,
			page_name,
			@engg_gen_task_name,
			control_bt_synonym,
			hidden_view_bt_synonym,
			1,
			@ctxt_user,
			getdate(),
			@ctxt_user,
			getdate(),
			page_name,
			'Y',
			@engg_ico_no
		FROM de_hidden_view vw(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @process_name_tmp
			AND component_name = @component_name_tmp
			AND activity_name = @activity_name_tmp
			AND ui_name = @ui_name_tmp
			AND control_bt_synonym IN (
				SELECT DISTINCT control_bt_synonym
				FROM de_task_control_map(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND action_name = @engg_gen_task_name
					AND map_flag = 'Y'
					AND (
						hidden_view_bt_synonym LIKE 'hdiFID%'
						OR hidden_view_bt_synonym LIKE 'hdiDFU%'
						OR hidden_view_bt_synonym LIKE 'hdiMFS%'
						OR hidden_view_bt_synonym LIKE 'hdiMDL%'
						)
					AND NOT EXISTS (
						SELECT '*'
						FROM de_hidden_view_usage(NOLOCK)
						WHERE customer_name = @engg_customer_name
							AND project_name = @engg_project_name
							AND process_name = @process_name_tmp
							AND component_name = @component_name_tmp
							AND activity_name = @activity_name_tmp
							AND ui_name = @ui_name_tmp
							AND action_name = @engg_gen_task_name
							AND hidden_view_bt_sysnonym = vw.hidden_view_bt_synonym
							AND control_bt_sysnonym = vw.control_bt_synonym
						)
				)

		/* Code added for Defect id: TECH-22358 ends. */
		-- Start added by Feroz For extjs  --PNR2.0_1790
		EXEC de_header_control_extjs @ctxt_language,
			@ctxt_service,
			@ctxt_ouinstance,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_ico_no,
			@process_name_tmp,
			@component_name_tmp,
			@activity_name_tmp,
			@ui_name_tmp,
			@engg_page_descr,
			@engg_gen_task_name

		-- End  added by Feroz For extjs  --PNR2.0_1790
		IF EXISTS (
				SELECT 'x'
				FROM de_task_control_attributemap(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND action_name = @engg_gen_task_name
				)
		BEGIN
			IF NOT EXISTS (
					SELECT 'x'
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'vw_plf_short_code'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					Generatedby,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@process_name_tmp,
					@component_name_tmp,
					'vw_plf_short_code',
					'vw_plf_short_code',
					'char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					60,
					NULL,
					NULL,
					@engg_ico_no
			END

			IF NOT EXISTS (
					SELECT 'x'
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'vw_plf_code'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					Generatedby,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@process_name_tmp,
					@component_name_tmp,
					'vw_plf_code',
					'vw_plf_code',
					'char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					128,
					NULL,
					NULL,
					@engg_ico_no
			END

			IF NOT EXISTS (
					SELECT 'x'
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'vw_plf_desc'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					Generatedby,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@process_name_tmp,
					@component_name_tmp,
					'vw_plf_desc',
					'vw_plf_desc',
					'char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					512,
					NULL,
					NULL,
					@engg_ico_no
			END

			IF NOT EXISTS (
					SELECT 'x'
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'vw_plf_long_desc'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					Generatedby,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@process_name_tmp,
					@component_name_tmp,
					'vw_plf_long_desc',
					'vw_plf_long_desc',
					'char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					1024,
					NULL,
					NULL,
					@engg_ico_no
			END

			IF NOT EXISTS (
					SELECT 'x' ---added by kanagavel for visible,enable in attributemap
					FROM de_business_term(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND bt_name = 'vw_plf_flag'
					)
			BEGIN
				INSERT INTO de_business_term (
					customer_name,
					project_name,
					process_name,
					component_name,
					bt_name,
					bt_descr,
					data_type,
					bt_sysid,
					TIMESTAMP,
					createdby,
					createddate,
					modifiedby,
					modifieddate,
					length,
					precision_type,
					Generatedby,
					ecrno
					)
				SELECT @engg_customer_name,
					@engg_project_name,
					@process_name_tmp,
					@component_name_tmp,
					'vw_plf_flag',
					'vw_plf_flag',
					'char',
					newid(),
					1,
					@ctxt_user,
					getdate(),
					@ctxt_user,
					getdate(),
					5,
					NULL,
					NULL,
					@engg_ico_no
			END
		END

		EXEC de_generate_design @ctxt_language,
			@ctxt_service,
			@ctxt_ouinstance,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@engg_ico_no,
			@process_name_tmp,
			@component_name_tmp,
			@activity_name_tmp,
			@ui_name_tmp,
			@engg_page_descr,
			@engg_gen_task_name,
			@engg_gen_applyrefine --TECH-75230

		-- Start added by Feroz For extjs --PNR2.0_1790
		DROP TABLE #populate_header_control_extjs

		DROP TABLE #populate_mapped_controls_extjs

		-- End added by Feroz For extjs --PNR2.0_1790
		DROP TABLE #listedit_control -- added By Feroz List Edit

		-- Code added by Saravanan on 29/03/2005 for Work Flow Incorporation - START (PNR2.0_3331)
		IF EXISTS (
				SELECT 'X'
				FROM de_workflow_req(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND wkf_req = 'Y'
				)
		BEGIN
			SELECT @wkf_req = 'Y'
		END

		IF @wkf_req = 'Y'
		BEGIN
			SELECT @task_type = task_type
			FROM de_action a(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @engg_page_descr
				AND task_name = @engg_gen_task_name

			SELECT @service_name = service_name
			FROM de_task_service_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND task_name = @engg_gen_task_name

			IF isnull(@service_name, '') <> ''
			BEGIN -- Code modified by Gowrisankar on 09-Aug-2007 for PNR2.0_14883
				IF @task_type IN (
						'INIT',
						'FETCH'
						)
				BEGIN
					IF EXISTS (
							SELECT 'x'
							FROM de_wsinp_task_dtl b(NOLOCK)
							WHERE b.customer_code = @engg_customer_name
								AND b.project_code = @engg_project_name
								AND b.component_name = @component_name_tmp
								AND b.activity_name = @activity_name_tmp
								AND b.task_name = @engg_gen_task_name
							)
					BEGIN
						SELECT @area_code = b.area_code
						FROM de_wsinp_task_dtl b(NOLOCK)
						WHERE b.customer_code = @engg_customer_name
							AND b.project_code = @engg_project_name
							AND b.component_name = @component_name_tmp
							AND b.activity_name = @activity_name_tmp
							AND b.task_name = @engg_gen_task_name

						EXEC DE_GENERATE_WF_INITFETCH_DESIGN @ctxt_language,
							@ctxt_service,
							@ctxt_ouinstance,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_ico_no,
							@process_name_tmp,
							@component_name_tmp,
							@activity_name_tmp,
							@ui_name_tmp,
							@engg_page_descr,
							@engg_gen_task_name,
							@service_name,
							@area_code
					END
				END

				IF EXISTS (
						SELECT 'x'
						FROM re_wsinp_cat_hdr a(NOLOCK),
							de_wsinp_task_dtl b(NOLOCK)
						WHERE a.customer_code = b.customer_code
							AND a.project_code = b.project_code
							AND a.area_code = b.area_code
							AND a.component_name = b.component_name
							AND a.activity_name = b.activity_name
							AND a.task_name = b.task_name
							AND a.customer_code = @engg_customer_name
							AND a.project_code = @engg_project_name
							AND a.component_name = @component_name_tmp
							AND a.activity_name = @activity_name_tmp --PNR2.0_15944
							AND a.task_name = @engg_gen_task_name
						)
				BEGIN
					SELECT @task_type = task_type
					FROM de_action a(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @activity_name_tmp
						AND ui_name = @ui_name_tmp
						AND page_bt_synonym = @engg_page_descr
						AND task_name = @engg_gen_task_name

					SELECT @service_name = service_name
					FROM de_task_service_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND activity_name = @activity_name_tmp
						AND ui_name = @ui_name_tmp
						AND task_name = @engg_gen_task_name

					--  Declare @area_code engg_name
					SELECT @area_code = a.area_code
					FROM re_wsinp_cat_hdr a(NOLOCK),
						de_wsinp_task_dtl b(NOLOCK)
					WHERE a.customer_code = b.customer_code
						AND a.project_code = b.project_code
						AND a.area_code = b.area_code
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.task_name = b.task_name
						AND a.customer_code = @engg_customer_name
						AND a.project_code = @engg_project_name
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @activity_name_tmp --PNR2.0_15944
						AND a.task_name = @engg_gen_task_name

					IF @task_type = 'TRANS'
					BEGIN
						EXEC DE_GENERATE_WF_TRANS_DESIGN @ctxt_language,
							@ctxt_service,
							@ctxt_ouinstance,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_ico_no,
							@process_name_tmp,
							@component_name_tmp,
							@activity_name_tmp,
							@ui_name_tmp,
							@engg_page_descr,
							@engg_gen_task_name,
							@service_name,
							@area_code
					END

					IF @task_type IN (
							'INIT',
							'FETCH'
							)
					BEGIN
						EXEC DE_GENERATE_WF_INITFETCH_DESIGN @ctxt_language,
							@ctxt_service,
							@ctxt_ouinstance,
							@ctxt_user,
							@engg_customer_name,
							@engg_project_name,
							@engg_ico_no,
							@process_name_tmp,
							@component_name_tmp,
							@activity_name_tmp,
							@ui_name_tmp,
							@engg_page_descr,
							@engg_gen_task_name,
							@service_name,
							@area_code
							--       Exec DE_APPEND_WF_CONTROL
							--        @ctxt_language ,
							--        @ctxt_service ,
							--        @ctxt_ouinstance ,
							--        @ctxt_user ,
							--        @engg_customer_name ,
							--        @engg_project_name ,
							--        @engg_ico_no ,
							--        @process_name_tmp ,
							--        @component_name_tmp ,
							--        @activity_name_tmp ,
							--        @ui_name_tmp ,
							--        @engg_page_descr ,
							--        @engg_gen_task_name,
							--        @service_name,
							--        @area_code
					END
				END
			END -- Code modified by Gowrisankar on 09-Aug-2007 for PNR2.0_14883
		END
	END

	--code modified by kiruthika
	--code modified for bugid:PNR2.0_9998
	--if @modeflag in ('z','Y')
	IF @modeflag = 'Y'
		AND isnull(@service_name, '') <> ''
	BEGIN
		IF @engg_gen_is = 1
		BEGIN
			UPDATE De_fw_Des_service
			SET isintegser = 1
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND componentname = @component_name_tmp
				AND servicename = @service_name
		END
		ELSE
		BEGIN
			DECLARE @calling_service engg_service_name

			-- Code modified by Gowrisankar for PNR2.0_9986 on 23-Aug-2006  --Starts
			IF EXISTS (
					SELECT 's'
					FROM de_fw_Des_processsection_br_is(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						-- and  process_name	= @process_name_tmp
						-- and  component_name  = @component_name_tmp
						AND integservicename = @service_name
					)
			BEGIN
				SELECT @calling_service = servicename
				FROM de_fw_Des_processsection_br_is(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					-- and  process_name	= @process_name_tmp
					-- and  component_name  = @component_name_tmp
					AND integservicename = @service_name

				SELECT @msg = 'The service ' + isnull(@service_name, '') + ' is already used as  integration service in calling service ' + isnull(@calling_service, '')

				-- Code modified by Gowrisankar for PNR2.0_9986 on 23-Aug-2006 --Ends
				EXEC engg_error_sp 'de_design_sp_gengen',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
			ELSE
			BEGIN
				UPDATE De_fw_Des_service
				SET isintegser = 0
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND componentname = @component_name_tmp
					AND servicename = @service_name
			END
		END
	END

	--code added for the Bug ID:PLF2.0_00376 starts
	DECLARE @errorid INT,
		@count INT,
		@char VARCHAR(1),
		@len INT

	IF isnull(@engg_gen_setkey_pattern, '') <> ''
	BEGIN
		SET @count = 1
		SET @errorid = 0

		WHILE (@errorid = 0)
		BEGIN
			SET @char = substring(@engg_gen_setkey_pattern, @count, 1)

			IF NOT (
					(@char LIKE '[a-z]')
					OR (@char LIKE '[0-9]')
					OR (@char = '_')
					)
			BEGIN
				IF NOT (@char LIKE '[$,!,~]')
					SET @errorid = 1
			END

			SET @count = @count + 1

			IF @count > len(@engg_gen_setkey_pattern)
				BREAK
		END
	END

	IF @errorid = 1
	BEGIN
		SELECT @msg = 'Setkey pattern contains Special Characters : <%1> '

		EXEC engg_error_sp 'de_design_sp_gengen',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@char,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF isnull(@engg_gen_clearkey_pattern, '') <> ''
	BEGIN
		SET @count = 1
		SET @errorid = 0

		WHILE (@errorid = 0)
		BEGIN
			SET @char = substring(@engg_gen_clearkey_pattern, @count, 1)

			IF NOT (
					(@char LIKE '[a-z]')
					OR (@char LIKE '[0-9]')
					OR (@char = '_')
					)
			BEGIN
				IF NOT (@char LIKE '[$,!,~]')
					SET @errorid = 1
			END

			SET @count = @count + 1

			IF @count > len(@engg_gen_clearkey_pattern)
				BREAK
		END
	END

	IF @errorid = 1
	BEGIN
		SELECT @msg = 'Clearkey pattern contains Special Characters : <%1> '

		EXEC engg_error_sp 'de_design_sp_gengen',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@char,
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	--code added for the Bug ID:PLF2.0_00376 ends
	--code added for the Bug ID:PLF2.0_00214 starts
	IF @modeflag IN (
			'Z',
			'Y',
			'U'
			)
	BEGIN
		IF isnull(@engg_gen_iscached, 0) = 0
			AND isnull(@engg_gen_setkey_pattern, '') <> '' --(isnull(@engg_gen_clearkey_pattern,'') <> '' or isnull(@engg_gen_setkey_pattern,'') <> '')
		BEGIN
			--select  @msg =   'SetKey pattern and ClearKey pattern applicable only for Cached services'
			SELECT @msg = 'SetKey pattern applicable only for Cached services'

			EXEC engg_error_sp 'de_design_sp_gengen',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			IF @m_errorid <> 0
				RETURN
		END

		IF isnull(@engg_gen_iszipped, 0) = 1
		BEGIN
			IF NOT EXISTS (
					SELECT '*'
					FROM de_action a(NOLOCK),
						de_ui_control b(NOLOCK),
						es_comp_ctrl_type_mst c(NOLOCK)
					WHERE a.customer_name = b.customer_name
						AND a.project_name = b.project_name
						AND a.process_name = b.process_name
						AND a.component_name = b.component_name
						AND a.activity_name = b.activity_name
						AND a.ui_name = b.ui_name
						AND a.page_bt_synonym = b.page_bt_synonym
						AND a.primary_control_bts = b.control_bt_synonym
						AND b.customer_name = c.customer_name
						AND b.project_name = c.project_name
						AND b.process_name = c.process_name
						AND b.component_name = c.component_name
						AND b.control_type = c.ctrl_type_name
						AND a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @activity_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.task_name = @engg_gen_task_name
						AND isnull(report_req, '') = 'y'
					)
			BEGIN
				SELECT @msg = 'Zipped service  applicable only for Report Task'

				EXEC engg_error_sp 'de_design_sp_gengen',
					1,
					@msg,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					'',
					'',
					'',
					'',
					@m_errorid OUTPUT

				IF @m_errorid <> 0
					RETURN
			END
		END

		UPDATE De_fw_Des_service
		SET isCached = isnull(@engg_gen_iscached, 0),
			isZipped = isnull(@engg_gen_iszipped, 0),
			SetKey_Pattern = isnull(@engg_gen_setkey_pattern, ''),
			ClearKey_Pattern = isnull(@engg_gen_clearkey_pattern, '')
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @process_name_tmp
			AND componentname = @component_name_tmp
			AND servicename = @service_name
	END

	--code added for the Bug ID:PLF2.0_00214 ends
	/* code added by Padmapriya L on 27/09/2005*/
	DECLARE @task_name_tmp engg_name,
		@act_name engg_name,
		@ui_name engg_name,
		@page_name engg_name,
		@act_id engg_seq_no

	IF EXISTS (
			SELECT 'x'
			FROM de_action_reuse_info(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND reuse_task = @engg_gen_task_name
			)
	BEGIN
		DECLARE task_Cur1 CURSOR
		FOR
		SELECT Task_name,
			activity_name,
			ui_name,
			page_bt_synonym
		FROM re_action_reuse_info(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @process_name_tmp
			AND component_name = @component_name_tmp
			AND reuse_task = @engg_gen_task_name

		OPEN task_Cur1

		WHILE (1 = 1)
		BEGIN
			FETCH NEXT
			FROM task_Cur1
			INTO @task_name_tmp,
				@act_name,
				@ui_name,
				@page_name

			IF @@fetch_status <> 0
				BREAK

			SELECT @act_id = activityid
			FROM de_fw_req_activity(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activityname = @act_name

			IF EXISTS (
					SELECT 'x'
					FROM de_task_service_map(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND task_name = @task_name_tmp
					)
			BEGIN
				DELETE
				FROM de_task_service_map
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND task_name = @task_name_tmp
			END

			INSERT INTO de_task_service_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				task_name,
				service_name,
				taskser_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate
				)
			SELECT @engg_customer_name,
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@act_name,
				@ui_name,
				@task_name_tmp,
				service_name,
				newid(),
				1,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate()
			FROM de_task_service_map(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND task_name = @engg_gen_task_name

			IF EXISTS (
					SELECT 'x'
					FROM de_fw_des_ilbo_service_view_datamap(NOLOCK)
					WHERE customer_name = @engg_customer_name
						AND project_name = @engg_project_name
						AND process_name = @process_name_tmp
						AND component_name = @component_name_tmp
						AND taskname = @task_name_tmp
					)
			BEGIN
				DELETE
				FROM de_fw_des_ilbo_service_view_datamap
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND taskname = @task_name_tmp
			END

			INSERT INTO de_fw_des_ilbo_service_view_datamap (
				customer_name,
				ilbocode,
				servicename,
				activityid,
				taskname,
				segmentname,
				dataitemname,
				iscontrol,
				upduser,
				updtime,
				project_name,
				process_name,
				component_name,
				activity_name,
				page_bt_synonym,
				control_bt_synonym,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				controlid,
				viewname,
				variablename
				)
			SELECT @engg_customer_name,
				@ui_name,
				servicename,
				@act_id,
				@task_name_tmp,
				segmentname,
				dataitemname,
				iscontrol,
				@ctxt_user,
				getdate(),
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@act_name,
				@page_name,
				control_bt_synonym,
				1,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				controlid,
				viewname,
				variablename
			FROM de_fw_des_ilbo_service_view_datamap(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND taskname = @engg_gen_task_name
		END

		CLOSE task_Cur1

		DEALLOCATE task_Cur1
			--- Multiline Seqment
	END

	-- Modified by Sangeetha G for PNR2.0_14989
	SELECT @proc_sel_rows_tmp = proc_sel_rows
	FROM es_comp_task_type_mst a(NOLOCK),
		de_action b(NOLOCK)
	WHERE b.customer_name = @engg_customer_name
		AND b.project_name = @engg_project_name
		AND b.process_name = @process_name_tmp
		AND b.component_name = @component_name_tmp
		AND b.activity_name = @activity_name_tmp
		AND b.ui_name = @ui_name_tmp
		AND b.task_name = @engg_gen_task_name
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.component_name
		AND a.task_type_name = b.task_pattern

	UPDATE de_fw_des_service_segment
	SET process_selrows = @proc_sel_rows_tmp
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND servicename = @service_name

	-- code added By Kanagavel on 20/7/2015 for Workflow default dataitem handling
	IF NOT EXISTS (
			SELECT 's'
			FROM es_comp_param_mst(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND param_category IN (
					'CHAR',
					'DATE',
					'INTEGER',
					'TIME'
					) --CODE MODIFIED BY KIRUTHIKA FOR BUG ID:PNR2.0_4926
			)
	BEGIN
		SET @msg = 'Default Value For The Component Is Not Present'

		EXEC engg_error_sp 'de_generate_design',
			1,
			@msg,
			@ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		RETURN
	END
	ELSE
	BEGIN
		--code Modified For BugId : PNR2.0_4649 Default Value For Date-Time is Date
		UPDATE a
		SET a.defaultvalue = c.current_value
		FROM de_fw_des_Service_dataitem a(NOLOCK),
			de_glossary b(NOLOCK),
			es_comp_param_mst c(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp
			AND a.servicename = @service_name
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.dataitemname = b.bt_synonym_name
			AND b.customer_name = c.customer_name
			AND b.project_name = c.project_name
			AND b.process_name = c.process_name
			AND b.component_name = c.component_name
			AND c.param_category = CASE b.data_type
				WHEN 'Numeric'
					THEN 'Integer'
				WHEN 'Date-Time'
					THEN 'Date'
				ELSE b.data_type
				END
			AND a.dataitemname <> 'ModeFlag'

		IF EXISTS (
				SELECT 'x'
				FROM de_fw_des_Service_dataitem a(NOLOCK),
					de_glossary b(NOLOCK),
					es_comp_param_mst c(NOLOCK)
				WHERE a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.dataitemname = b.bt_synonym_name
					AND b.data_type = 'Char'
					AND b.length < 3
					AND b.customer_name = c.customer_name
					AND b.project_name = c.project_name
					AND b.process_name = c.process_name
					AND b.component_name = c.component_name
					AND b.data_type = c.param_category
					AND len(current_value) > 2
					AND a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.servicename = @service_name
					AND a.dataitemname <> 'ModeFlag'
				)
		BEGIN
			UPDATE a
			SET a.defaultvalue = substring(current_value, 1, cast(b.length AS INT))
			FROM de_fw_des_Service_dataitem a(NOLOCK),
				de_glossary b(NOLOCK),
				es_comp_param_mst c(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.servicename = @service_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.dataitemname = b.bt_synonym_name
				AND b.customer_name = c.customer_name
				AND b.project_name = c.project_name
				AND b.process_name = c.process_name
				AND b.component_name = c.component_name
				AND b.data_type = c.param_category
				AND b.data_type = 'CHAR'
				AND a.dataitemname <> 'ModeFlag'
				AND b.length < 3
		END
	END

	-- code added By Kanagavel on 20/7/2015 for Workflow default dataitem handling
	IF EXISTS (
			SELECT 'x'
			FROM sysobjects(NOLOCK)
			WHERE name = 'de_customer_space'
				AND type = 'u'
			)
	BEGIN
		UPDATE de_customer_space
		SET validate_req = 'Y'
		WHERE customername = @engg_customer_name
			AND projectname = @engg_project_name
			AND processname = @process_name_tmp
			AND componentname = @component_name_tmp
	END

	--Code Modification for  PNR2.0_27959 starts
	SELECT @service_name = service_name
	FROM de_task_service_map(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp
		AND task_name = @engg_gen_task_name

	-- Added for TECH-20897 Starts
	IF EXISTS (
			SELECT 'x'
			FROM es_comp_task_type_mst tsk(NOLOCK),
				de_action act(NOLOCK)
			WHERE act.customer_name = tsk.customer_name
				AND act.project_name = tsk.project_name
				AND act.process_name = tsk.process_name
				AND act.component_name = tsk.component_name
				AND act.task_pattern = tsk.task_type_name
				AND act.customer_name = @engg_customer_name
				AND act.project_name = @engg_project_name
				AND act.process_name = @process_name_tmp
				AND act.component_name = @component_name_tmp
				AND act.activity_name = @activity_name_tmp
				AND act.ui_name = @ui_name_tmp
				AND act.task_name = @engg_gen_task_name
				AND tsk.BulkValidation = 'Y'
			)
	BEGIN
		UPDATE a
		SET method_exec_cont = 'Y'
		FROM de_fw_des_businessrule a(NOLOCK),
			de_fw_des_processsection_br_is b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp
			AND servicename = @service_name
			AND (
				a.methodname LIKE '%HdrRef'
				OR a.methodname LIKE '%MtO'
				)
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.methodname = b.method_name
			AND a.methodid = b.methodid

		UPDATE a
		SET sperrorprotocol = 2
		FROM de_fw_des_sp a(NOLOCK),
			de_fw_des_processsection_br_is b(NOLOCK)
		WHERE a.customer_name = @engg_customer_name
			AND a.project_name = @engg_project_name
			AND a.process_name = @process_name_tmp
			AND a.component_name = @component_name_tmp
			AND servicename = @service_name
			AND (
				a.method_name NOT LIKE '%HdrRef'
				OR a.method_name NOT LIKE '%MtO'
				)
			AND a.customer_name = b.customer_name
			AND a.project_name = b.project_name
			AND a.process_name = b.process_name
			AND a.component_name = b.component_name
			AND a.method_name = b.method_name
			AND a.methodid = b.methodid
	END

	-- Added for TECH-20897 Ends
	IF isnull(@service_name, '') <> ''
	BEGIN
		EXEC de_generate_userdef_segments @CTxt_Language,
			@CTxt_OUInstance,
			@CTxt_Service,
			@CTxt_User,
			@engg_customer_name,
			@engg_project_name,
			@engg_ico_no,
			@process_name_tmp,
			@component_name_tmp,
			@activity_name_tmp,
			@ui_name_tmp,
			@service_name,
			@engg_gen_task_name,
			@m_errorid OUTPUT
	END

	--TECH-75230 (Refine methods & Refine Service - Update services done when we select applyrefinements in generate services)
		DECLARE @method_name engg_name
		
		IF @engg_gen_applyrefine = 1
		BEGIN
			UPDATE De_fw_Des_service
			SET ApplyRefinements = 1
			WHERE customer_name		= @engg_customer_name
			AND project_name		= @engg_project_name
			AND process_name		= @process_name_tmp
			AND componentname		= @component_name_tmp
			AND servicename			= @service_name
		
		EXEC	de_refine_sp_updsergen
			@Ctxt_Language			=	@Ctxt_Language,
			@ctxt_OUInstance		=	@ctxt_OUInstance,
			@Ctxt_Service			=	@Ctxt_Service,
			@ctxt_User				=	@ctxt_User,
			@engg_act_descr			=	@engg_act_descr,
			@engg_all_pages			=	@engg_all_pages,
			@engg_all_tasks			=	@engg_all_tasks,
			@engg_all_ui			=	0,
			@engg_cf_mthname		=	'',
			@engg_cf_newmthname		=	'',
			@engg_cf_psname			=	'',
			@engg_cf_psnewname		=	'',
			@engg_component			=	@engg_component,
			@engg_customer_name		=	@engg_customer_name,
			@engg_gen_last_gen		=	@engg_gen_last_gen,
			@engg_gen_remarks		=	@engg_gen_remarks,
			@engg_gen_ser_name		=	@engg_gen_ser_name,
			@engg_gen_task_descr	=	@engg_gen_task_descr,
			@engg_gen_task_name		=	@engg_gen_task_name,
			@engg_gen_task_pattern	=	@engg_gen_task_pattern,
			@engg_gen_bubl_msg		=	0,
			@engg_ico_no			=	@engg_ico_no,
			@engg_proj_proc_descr	=	@engg_proj_proc_descr,
			@engg_project_name		=	@engg_project_name,
			@engg_service_name		=	@engg_gen_ser_name,
			@engg_ui_descr			=	@engg_ui_descr,
			@ModeFlag				=	@modeflag,
			@fpRowNo				=	@fprowno,
			@m_errorid				=	@m_errorid OUTPUT

		DECLARE methodname CURSOR FAST_FORWARD  FOR  
  
		SELECT DISTINCT method_name 
		FROM de_refine_parameter (NOLOCK)
		WHERE customer_name		= @engg_customer_name
		AND   project_name		= @engg_project_name
		AND   process_name		= @process_name_tmp
		AND   component_name	= @component_name_tmp
		AND   activity_name		= @activity_name_tmp
		AND   ui_name			= @ui_name_tmp
		AND   service_name		= @service_name

		  
		OPEN methodname  
		  
		WHILE (1=1)  
		BEGIN  
		FETCH NEXT FROM methodname INTO @method_name  
		  
		IF @@FETCH_STATUS <> 0  
		BREAK  

		EXEC de_method_sp_updsergen
			@Ctxt_Language			=	@ctxt_language,
			@ctxt_OUInstance		=	@ctxt_ouinstance,
			@Ctxt_Service			=	@ctxt_service,
			@ctxt_User				=	@ctxt_user,
			@engg_act_descr			=	@engg_act_descr,
			@engg_all_pages			=	@engg_all_pages,
			@engg_all_tasks			=	@engg_all_tasks,
			@engg_all_ui			=	0,
			@engg_component			=	@engg_component,
			@engg_customer_name		=	@engg_customer_name,
			@engg_flowbr_name		=	'',
			@engg_gen_flowbr_name	=	'',
			@engg_gen_met_name		=	@method_name,
			@engg_gen_ser_name		=	@engg_gen_ser_name,
			@engg_gen_task_descr	=	@engg_gen_task_descr,
			@engg_gen_task_name		=	@engg_gen_task_name,
			@engg_ico_no			=	@engg_ico_no,
			@engg_method_name		=	@method_name,					
			@engg_process_descr		=	@engg_proj_proc_descr,
			@engg_project_name		=	@engg_project_name,
			@engg_service_name		=	@engg_gen_ser_name,
			@engg_space				=	'',
			@engg_ui_descr			=	@engg_ui_descr,
			@ModeFlag				=	@modeflag,
			@ErrorNo				=	@errorno,
			@fpRowNo				=	@fprowno,
			@PlaceHolder1			=	@placeholder1,
			@PlaceHolder2			=	@placeholder2,
			@PlaceHolder3			=	@placeholder3,
			@PlaceHolder4			=	@placeholder4,
			@SuccessFlag			=	'',
			@m_errorid				=	@m_errorid OUTPUT
			
		END  

		CLOSE methodname  
		DEALLOCATE methodname  
		
		END
		ELSE IF @engg_gen_applyrefine = 0
		BEGIN
			UPDATE De_fw_Des_service
			SET ApplyRefinements = 0
			WHERE customer_name		= @engg_customer_name
				AND project_name	= @engg_project_name
				AND process_name	= @process_name_tmp
				AND componentname	= @component_name_tmp
				AND servicename		= @service_name
		END		
	--TECH-75230

	--Code Modification for  PNR2.0_27959 ends
	SELECT NULL 'errorno',
		@fprowno 'fprowno',
		NULL 'placeholder1',
		NULL 'placeholder2',
		NULL 'placeholder3',
		NULL 'placeholder4',
		0 'successflag'

	SET NOCOUNT OFF
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_gengen' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_design_sp_gengen TO PUBLIC
END
GO