IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_design_sp_savctltc' AND TYPE = 'P')
BEGIN
	DROP PROC de_design_sp_savctltc                                                                 
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_design_sp_savctltc.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : de_design_sp_savctltc                                         */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Muthu Kumar.K                                                 */
/* Date         : 19/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* modified by  : Feroz															*/
/* date         : 04-Aug-2009                                                   */
/* Bug Id   : PNR2.0_2179														*/
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* modified by  : Sangeetha G                                        */
/* date         : 03-Apr-2013                                                   */
/* Bug Id   : PLF2.0_03043             */
/* Description  : To update controlid viewname in action control map table  */
/********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/***************************************************************************************/
/* Modified by  : Ranjitha R	Date: 31-May-2018  Defect ID : TECH-22398			   */
/***************************************************************************************/
/* Modified by  : Ponmalar A	Date: 27-Oct-2022  Defect ID : TECH-73996			   */
/***************************************************************************************/
/* Modified by  : Ponmalar A	Date: 01-Dec-2022  Defect ID	:TECH-75230			   */
/***************************************************************************************/

CREATE PROCEDURE de_design_sp_savctltc
	@ctxt_language engg_ctxt_language, --Input
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input
	@ctxt_service engg_ctxt_service, --Input
	@ctxt_user engg_ctxt_user, --Input
	@engg_act_descr engg_name, --Input
	@engg_component engg_description, --Input
	@engg_customer_name engg_name, --Input
	@engg_ico_no engg_name, --Input
	@engg_map_all engg_flag, --Input
	@engg_map_flag engg_flag, --Input
	@engg_page_descr engg_name, --Input
	@engg_proj_proc_descr engg_description, --Input
	@engg_project_name engg_name, --Input
	@engg_task_name engg_name, --Input
	@engg_tc_ctrl_bts engg_name, --Input
	@engg_tc_hdrtask_descr engg_description, --Input
	@engg_tc_page engg_name, --Input
	@engg_tc_page_name engg_name, --Input
	@engg_tc_sec_name engg_name, --Input
	@engg_tc_section engg_name, --Input
	@engg_tc_task_name engg_name, --Input
	@engg_ui_descr engg_name, --Input
	@modeflag engg_modeflag, --Input
	@engg_mapping_instance engg_name, --Input
	@engg_tc_load	engg_seqno,					--TECH-75230
	@engg_tc_ctrl_type	engg_name,					--TECH-75230
	@fprowno engg_rowno, --Input/Output
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaration of temporary variables
	--temporary and formal parameters mapping
	--null checking
	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SET @engg_ico_no = NULL

	IF @engg_map_all = '~#~'
		SET @engg_map_all = NULL

	IF @engg_map_flag = '~#~'
		SET @engg_map_flag = NULL

	IF @engg_page_descr = '~#~'
		SET @engg_page_descr = NULL

	IF @engg_proj_proc_descr = '~#~'
		SET @engg_proj_proc_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_task_name = '~#~'
		SET @engg_task_name = NULL

	IF @engg_tc_ctrl_bts = '~#~'
		SET @engg_tc_ctrl_bts = NULL

	IF @engg_tc_hdrtask_descr = '~#~'
		SET @engg_tc_hdrtask_descr = NULL

	IF @engg_tc_page = '~#~'
		SET @engg_tc_page = NULL

	IF @engg_tc_page_name = '~#~'
		SET @engg_tc_page_name = NULL

	IF @engg_tc_sec_name = '~#~'
		SET @engg_tc_sec_name = NULL

	IF @engg_tc_section = '~#~'
		SET @engg_tc_section = NULL

	IF @engg_tc_task_name = '~#~'
		SET @engg_tc_task_name = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @modeflag = '~#~'
		SET @modeflag = NULL

	IF @engg_mapping_instance = '~#~'
		SET @engg_mapping_instance = NULL

	IF @fprowno = - 915
		SET @fprowno = NULL

	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	IF @engg_map_all IS NULL
		SELECT @engg_map_all = 0

	IF @engg_map_flag IS NULL
		SELECT @engg_map_flag = 0

	SELECT @fprowno = @fprowno + 1

	--if @engg_map_all = 1 or @engg_map_flag = 1  -- if any of the map flag is selected
	--begin
	SELECT @engg_map_all = CASE @engg_map_all
			WHEN 1
				THEN 'Y'
			WHEN 0
				THEN 'N'
			END

	SELECT @engg_map_flag = CASE @engg_map_flag
			WHEN 1
				THEN 'Y'
			WHEN 0
				THEN 'N'
			END
	--TECH-75230
	DECLARE @tc_load engg_flag
	SELECT  @tc_load = CASE @engg_tc_load	WHEN 1 THEN 'Y'		
												WHEN 0 THEN 'N'
							END	
	--TECH-75230


	--TECH-73996
	DECLARE @hdnctlbt engg_name

	SELECT	@hdnctlbt					=	a.control_bt_synonym
	FROM	de_hidden_view  a (NOLOCK) 
	JOIN	de_ui_control   b (NOLOCK)
	ON		a.customer_name				= b.customer_name
	AND		a.project_name				= b.project_name
	AND		a.process_name				= b.process_name
	AND		a.component_name			= b.component_name
	AND		a.activity_name				= b.activity_name
	AND		a.ui_name					= b.ui_name
	AND		a.page_name					= b.page_bt_synonym
	AND		a.section_name				= b.section_bt_synonym
	AND		a.control_bt_synonym		= b.control_bt_synonym
	JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
	ON		b.customer_name				= c.customer_name
	AND		b.project_name				= c.project_name
	AND		b.process_name				= c.process_name
	AND		b.component_name			= c.component_name
	AND		b.control_type				= c.ctrl_type_name
	WHERE	 a.customer_name			= @engg_customer_name
	AND		 a.project_name				= @engg_project_name	
	AND		 a.process_name				= @process_name_tmp
	AND		 a.component_name			= @component_name_tmp
	AND		 a.activity_name			= @activity_name_tmp
	AND		 a.ui_name					= @ui_name_tmp
	AND		 a.page_name				= @engg_tc_page_name
	AND		 a.section_name				= @engg_tc_sec_name
	AND		 a.hidden_view_bt_synonym	= @engg_tc_ctrl_bts
	AND		 c.base_ctrl_type			= 'Combo'

	IF ISNULL(@hdnctlbt,'') = ''
	BEGIN
	SELECT	@hdnctlbt					=	a.control_bt_synonym
	FROM	de_hidden_view  a (NOLOCK) 
	JOIN	de_ui_grid   b (NOLOCK)
	ON		a.customer_name				= b.customer_name
	AND		a.project_name				= b.project_name
	AND		a.process_name				= b.process_name
	AND		a.component_name			= b.component_name
	AND		a.activity_name				= b.activity_name
	AND		a.ui_name					= b.ui_name
	AND		a.page_name					= b.page_bt_synonym
	AND		a.section_name				= b.section_bt_synonym
	AND		a.control_bt_synonym		= b.column_bt_synonym
	JOIN	es_comp_ctrl_type_mst	c (NOLOCK)
	ON		b.customer_name				= c.customer_name
	AND		b.project_name				= c.project_name
	AND		b.process_name				= c.process_name
	AND		b.component_name			= c.component_name
	AND		b.column_type				= c.ctrl_type_name
	WHERE	 a.customer_name			= @engg_customer_name
	AND		 a.project_name				= @engg_project_name	
	AND		 a.process_name				= @process_name_tmp
	AND		 a.component_name			= @component_name_tmp
	AND		 a.activity_name			= @activity_name_tmp
	AND		 a.ui_name					= @ui_name_tmp
	AND		 a.page_name				= @engg_tc_page_name
	AND		 a.section_name				= @engg_tc_sec_name
	AND		 a.hidden_view_bt_synonym	= @engg_tc_ctrl_bts
	AND		 c.base_ctrl_type			= 'Combo'
	END

	IF EXISTS
	(SELECT 'X'
	FROM	es_quick_code_met (NOLOCK)
	WHERE	CustomerName	=	@engg_customer_name
	AND		ProjectName		=	@engg_project_name
	AND		ParameterCode	=	'DefaultinghiddenView'
	AND		ParameterText	=	'AUTO_MAP_HDNVIEW_COMBO'
	AND		ParameterValue	=	'Y')	
	AND		NOT EXISTS
	(SELECT 'X'
	 FROM	de_task_service_method_vw (NOLOCK)
	 WHERE	customer_name		=	@engg_customer_name 
	 AND	project_name		=	@engg_project_name
	 AND	process_name		=	@process_name_tmp
	 AND	component_name		=	@component_name_tmp
	 AND	activity_name		=	@activity_name_tmp
	 AND	ui_name				=   @ui_name_tmp	
	 AND	task_name 			= 	@engg_tc_task_name)
	BEGIN
		IF EXISTS 
		(SELECT 'X'
		FROM	de_hidden_view a (NOLOCK) 
		WHERE	a.customer_name				= @engg_customer_name
		AND		a.project_name				= @engg_project_name	
		AND		a.process_name				= @process_name_tmp
		AND		a.component_name			= @component_name_tmp
		AND		a.activity_name				= @activity_name_tmp
		AND		a.ui_name					= @ui_name_tmp
		AND		a.page_name					= @engg_tc_page_name
		AND		a.section_name				= @engg_tc_sec_name
		AND		a.hidden_view_bt_synonym	= @engg_tc_ctrl_bts
		)	
		AND (ISNULL(@engg_map_flag,'') = 'N' OR ISNULL(@engg_map_all,'') = 'N')
		BEGIN

		IF EXISTS (
		SELECT 'X'
		FROM de_task_Control_map  (NOLOCK) 
		WHERE customer_name			= @engg_customer_name
		AND	 project_name			= @engg_project_name
		AND	 process_name			= @process_name_tmp
		AND	 component_name			= @component_name_tmp
		AND	 activity_name			= @activity_name_tmp
		AND	 ui_name				= @ui_name_tmp
		AND	 action_name			= @engg_tc_task_name
		AND	 page_name				= @engg_tc_page_name
		AND	 section_name			= @engg_tc_sec_name
		AND  control_bt_synonym		= @hdnctlbt
		AND  ISNULL(map_flag,'')	=	'Y'
		)

			BEGIN
				RAISERROR('Dependent Hidden View cannot be unmapped since the relevant Visible control is mapped.',16,1)
				RETURN
			END
		END
	END
	--TECH-73996

	IF @engg_tc_task_name IS NOT NULL
	BEGIN
		IF NOT EXISTS (
				SELECT 'x'
				FROM de_task_control_map
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					--and  a.req_no			= @engg_ico_no
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND action_name = @engg_tc_task_name
					AND page_name = @engg_tc_page_name
					AND section_name = @engg_tc_sec_name
					AND control_bt_synonym = @engg_tc_ctrl_bts
				)
		BEGIN
			EXEC de_task_control_map_sp_ins @ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@engg_customer_name,
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@activity_name_tmp,
				@ui_name_tmp,
				@engg_tc_task_name,
				@engg_tc_page_name,
				@engg_tc_sec_name,
				@engg_tc_ctrl_bts,
				@engg_map_flag,
				@engg_map_all,
				@engg_mapping_instance,
				1,
				@tc_load,	--TECH-75230		
				@m_errorid
		END
		ELSE
		BEGIN
			-- code added by ganesh on 07-Sep-2004 for PREVIEWENG203ACC_000098 (Modified Date must be updated.)
			UPDATE de_task_control_map
			SET map_flag = @engg_map_flag,
				map_ml_flag = @engg_map_all,
				mapping_instance = @engg_mapping_instance,
				modifiedby = @ctxt_user,
				modifieddate = getdate(),
				Load		= @tc_load	--TECH-75230
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				--and	a.req_no		= @engg_ico_no
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND action_name = @engg_tc_task_name
				AND page_name = @engg_tc_page_name
				AND section_name = @engg_tc_sec_name
				AND control_bt_synonym = @engg_tc_ctrl_bts

			--Code modification for PLF2.0_03043 starts
			IF EXISTS (
					SELECT 'x'
					FROM de_ui_control a(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @activity_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.page_bt_synonym = @engg_tc_page_name
						AND a.section_bt_synonym = @engg_tc_sec_name
						AND a.control_bt_synonym = @engg_tc_ctrl_bts
						AND EXISTS (
							SELECT 'x'
							FROM de_task_control_map tsk(NOLOCK),
								de_ui_control ctrl(NOLOCK)
							WHERE tsk.customer_name = @engg_customer_name
								AND tsk.project_name = @engg_project_name
								AND tsk.process_name = @process_name_tmp
								AND tsk.component_name = @component_name_tmp
								AND tsk.activity_name = @activity_name_tmp
								AND tsk.ui_name = @ui_name_tmp
								AND tsk.action_name = @engg_tc_task_name
								AND tsk.page_name = @engg_tc_page_name
								AND tsk.section_name = @engg_tc_sec_name
								AND tsk.control_bt_synonym = @engg_tc_ctrl_bts
								AND tsk.customer_name = ctrl.customer_name
								AND tsk.project_name = ctrl.project_name
								AND tsk.process_name = ctrl.process_name
								AND tsk.component_name = ctrl.component_name
								AND tsk.activity_name = ctrl.activity_name
								AND tsk.ui_name = ctrl.ui_name
								AND tsk.page_name = ctrl.page_bt_synonym
								AND tsk.section_name = ctrl.section_bt_synonym
								AND tsk.control_bt_synonym = ctrl.control_bt_synonym
								AND (
									tsk.control_id <> ctrl.control_id
									OR tsk.view_name <> ctrl.view_name
									)
							)
					)
			BEGIN
				UPDATE a
				SET a.control_id = b.control_id,
					a.view_name = b.view_name
				FROM de_task_control_map a(NOLOCK),
					de_ui_control b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @activity_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.action_name = @engg_tc_task_name
					AND a.page_name = @engg_tc_page_name
					AND a.section_name = @engg_tc_sec_name
					AND a.control_bt_synonym = @engg_tc_ctrl_bts
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_name = b.page_bt_synonym
					AND a.section_name = b.section_bt_synonym
					AND a.control_bt_synonym = b.control_bt_synonym
			END

			IF EXISTS (
					SELECT 'x'
					FROM de_ui_grid a(NOLOCK)
					WHERE a.customer_name = @engg_customer_name
						AND a.project_name = @engg_project_name
						AND a.process_name = @process_name_tmp
						AND a.component_name = @component_name_tmp
						AND a.activity_name = @activity_name_tmp
						AND a.ui_name = @ui_name_tmp
						AND a.page_bt_synonym = @engg_tc_page_name
						AND a.section_bt_synonym = @engg_tc_sec_name
						AND a.column_bt_synonym = @engg_tc_ctrl_bts
						AND EXISTS (
							SELECT 'x'
							FROM de_task_control_map tsk(NOLOCK),
								de_ui_grid ctrl(NOLOCK)
							WHERE tsk.customer_name = @engg_customer_name
								AND tsk.project_name = @engg_project_name
								AND tsk.process_name = @process_name_tmp
								AND tsk.component_name = @component_name_tmp
								AND tsk.activity_name = @activity_name_tmp
								AND tsk.ui_name = @ui_name_tmp
								AND tsk.action_name = @engg_tc_task_name
								AND tsk.page_name = @engg_tc_page_name
								AND tsk.section_name = @engg_tc_sec_name
								AND tsk.control_bt_synonym = @engg_tc_ctrl_bts
								AND tsk.customer_name = ctrl.customer_name
								AND tsk.project_name = ctrl.project_name
								AND tsk.process_name = ctrl.process_name
								AND tsk.component_name = ctrl.component_name
								AND tsk.activity_name = ctrl.activity_name
								AND tsk.ui_name = ctrl.ui_name
								AND tsk.page_name = ctrl.page_bt_synonym
								AND tsk.section_name = ctrl.section_bt_synonym
								AND tsk.control_bt_synonym = ctrl.column_bt_synonym
								AND (
									tsk.control_id <> ctrl.control_id
									OR tsk.view_name <> ctrl.view_name
									)
							)
					)
			BEGIN
				UPDATE a
				SET a.control_id = b.control_id,
					a.view_name = b.view_name
				FROM de_task_control_map a(NOLOCK),
					de_ui_grid b(NOLOCK)
				WHERE a.customer_name = @engg_customer_name
					AND a.project_name = @engg_project_name
					AND a.process_name = @process_name_tmp
					AND a.component_name = @component_name_tmp
					AND a.activity_name = @activity_name_tmp
					AND a.ui_name = @ui_name_tmp
					AND a.action_name = @engg_tc_task_name
					AND a.page_name = @engg_tc_page_name
					AND a.section_name = @engg_tc_sec_name
					AND a.control_bt_synonym = @engg_tc_ctrl_bts
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.page_name = b.page_bt_synonym
					AND a.section_name = b.section_bt_synonym
					AND a.control_bt_synonym = b.column_bt_synonym
			END
					--Code modification for PLF2.0_03043 ends
		END
	END
	ELSE -- task name is empty in multiline, map it now for the selected task name
	BEGIN
		EXEC de_task_control_map_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@engg_customer_name,
			@engg_project_name,
			@process_name_tmp,
			@component_name_tmp,
			@activity_name_tmp,
			@ui_name_tmp,
			@engg_task_name,
			@engg_tc_page_name,
			@engg_tc_sec_name,
			@engg_tc_ctrl_bts,
			@engg_map_flag,
			@engg_map_all,
			@engg_mapping_instance,
			1,
			@engg_tc_load,	--TECH-75230
			@m_errorid
	END

	/*end
else  --
begin
-- delete the records in the table , which are previously mapped
-- now those unchecked(not maped)
delete from de_task_control_map
where  customer_name  = @engg_customer_name
and  project_name  = @engg_project_name
--and  a.req_no   = @engg_ico_no
and  process_name  = @process_name_tmp
and  component_name  = @component_name_tmp
and  activity_name  = @activity_name_tmp
and  ui_name    = @ui_name_tmp
and  action_name   = @engg_tc_task_name
and  page_name    = @engg_tc_page_name
and  section_name  = @engg_tc_sec_name
and  control_bt_synonym = @engg_tc_ctrl_bts
end
*/
	-- Added BY Feroz image & attach document
	IF EXISTS (
			SELECT 'x'
			FROM de_ui_control a(NOLOCK),
				es_comp_ctrl_type_mst b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_tc_page_name
				AND a.section_bt_synonym = @engg_tc_sec_name
				AND a.control_bt_synonym = @engg_tc_ctrl_bts
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.control_type = b.ctrl_type_name
				AND (
					b.image_upload = 'Y'
					OR attach_document = 'Y'
					)
			
			UNION
			
			SELECT 'x'
			FROM de_ui_grid a(NOLOCK),
				es_comp_ctrl_type_mst b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_tc_page_name
				AND a.section_bt_synonym = @engg_tc_sec_name
				AND a.column_bt_synonym = @engg_tc_ctrl_bts
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.column_type = b.ctrl_type_name
				AND (
					b.image_upload = 'Y'
					OR attach_document = 'Y'
					)
			)
	BEGIN
		IF @engg_map_flag = 'Y'
		BEGIN
			INSERT INTO de_hidden_view_usage (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				page_name,
				action_name,
				control_bt_sysnonym,
				hidden_view_bt_sysnonym,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				control_page_name,
				map_ml_flag,
				ecrno
				)
			SELECT @engg_customer_name,
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@activity_name_tmp,
				@ui_name_tmp,
				@engg_page_descr,
				@engg_tc_task_name,
				control_bt_synonym,
				hidden_view_bt_synonym,
				1,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				page_name,
				'Y',
				@engg_ico_no
			FROM de_hidden_view x(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_name = @engg_tc_page_name
				AND section_name = @engg_tc_sec_name
				AND control_bt_synonym = @engg_tc_ctrl_bts
				AND NOT EXISTS (
					SELECT 'x'
					FROM de_hidden_view_usage z(NOLOCK)
					WHERE z.customer_name = x.customer_name
						AND z.project_name = x.project_name
						AND z.process_name = x.process_name
						AND z.component_name = x.component_name
						AND z.activity_name = x.activity_name
						AND z.ui_name = x.ui_name
						AND z.control_page_name = x.page_name
						AND z.action_name = @engg_tc_task_name
						AND z.control_bt_sysnonym = x.control_bt_synonym
						AND z.hidden_view_bt_sysnonym = x.hidden_view_bt_synonym
					)

			-- By JL Starts
			INSERT INTO de_task_control_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				action_name,
				page_name,
				section_name,
				control_bt_synonym
				)
			SELECT DISTINCT @engg_customer_name,
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@activity_name_tmp,
				@ui_name_tmp,
				@engg_task_name,
				a.page_bt_synonym,
				b.section_name,
				a.published_bt_synonym
			FROM de_publication_dataitem a(NOLOCK),
				de_hidden_view_usage c(NOLOCK),
				de_hidden_view b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = isnull(@engg_tc_page, a.page_bt_synonym)
				AND b.section_name = isnull(@engg_tc_section, b.section_name)
				AND c.customer_name = b.customer_name
				AND c.project_name = b.project_name
				AND c.process_name = b.process_name
				AND c.component_name = b.component_name
				AND c.activity_name = b.activity_name
				AND c.ui_name = b.ui_name
				AND c.page_name = b.page_name
				AND c.control_bt_sysnonym = b.control_bt_synonym
				AND c.hidden_view_bt_sysnonym = b.hidden_view_bt_synonym
				AND a.customer_name = c.customer_name
				AND a.project_name = c.project_name
				AND a.process_name = c.process_name
				AND a.component_name = c.component_name
				AND a.activity_name = c.activity_name
				AND a.ui_name = c.ui_name
				AND a.page_bt_synonym = c.page_name
				AND a.published_bt_synonym = c.hidden_view_bt_sysnonym
				AND a.published_control_name = b.control_id
				AND a.published_view_name = b.view_name
				AND a.published_bt_synonym NOT IN (
					SELECT control_bt_synonym
					FROM de_task_control_map m(NOLOCK)
					WHERE m.customer_name = @engg_customer_name
						AND m.project_name = @engg_project_name
						AND m.process_name = @process_name_tmp
						AND m.component_name = @component_name_tmp
						AND m.activity_name = @activity_name_tmp
						AND m.ui_name = @ui_name_tmp
						AND m.page_name = isnull(a.page_bt_synonym, m.page_name)
						AND m.section_name = isnull(@engg_tc_section, m.section_name)
						AND m.action_name = @engg_task_name
					)

			INSERT INTO de_task_control_map (
				customer_name,
				project_name,
				process_name,
				component_name,
				activity_name,
				ui_name,
				action_name,
				page_name,
				section_name,
				control_bt_synonym,
				map_flag,
				map_ml_flag,
				tc_sysid,
				TIMESTAMP,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				ecrno
				)
			SELECT DISTINCT @engg_customer_name,
				@engg_project_name,
				@process_name_tmp,
				@component_name_tmp,
				@activity_name_tmp,
				@ui_name_tmp,
				@engg_task_name,
				a.page_name,
				b.section_name,
				hidden_view_bt_sysnonym,
				'Y',
				'Y',
				newid(),
				0,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@engg_ico_no
			FROM de_hidden_view_usage a(NOLOCK),
				de_hidden_view b(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.action_name = @engg_task_name
				AND a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_name = b.page_name
				AND a.control_bt_sysnonym = b.control_bt_synonym
				AND a.hidden_view_bt_sysnonym = b.hidden_view_bt_synonym
				--and     b.page_name 	=  isnull(@engg_tc_page,b.page_name)
				--and   	b.section_name 	=  isnull(@engg_tc_section,b.section_name)	
				AND a.hidden_view_bt_sysnonym NOT IN (
					SELECT control_bt_synonym
					FROM de_task_control_map m(NOLOCK)
					WHERE m.customer_name = @engg_customer_name
						AND m.project_name = @engg_project_name
						AND m.process_name = @process_name_tmp
						AND m.component_name = @component_name_tmp
						AND m.activity_name = @activity_name_tmp
						AND m.ui_name = @ui_name_tmp
						--Code Modified for bugId :PNR2.0_11358
						--and   m.page_name		= isnull(@engg_tc_page,m.page_name)
						--and   m.section_name	= isnull(@engg_tc_section,m.section_name)
						AND m.action_name = @engg_task_name
					)
				--By JL Ends
		END
		ELSE
		BEGIN
			DELETE
			FROM de_hidden_view_usage
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND control_page_name = @engg_tc_page_name
				AND control_bt_sysnonym = @engg_tc_ctrl_bts
				AND action_name = @engg_task_name -- code added for the Defect id: TECH-22358

			DELETE
			FROM de_task_control_map
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND action_name = @engg_task_name
				AND page_name = @engg_tc_page_name
				AND control_bt_synonym = @engg_tc_ctrl_bts
		END
	END

	--TECH-75230
		EXEC	DE_FLOWBR_COMBO_SP_INS_DEL
			@ctxt_language_in						=	@ctxt_language,
			@ctxt_ouinstance_in						=	@ctxt_ouinstance,
			@ctxt_service_in						=	@ctxt_service,
			@ctxt_user_in							=	@ctxt_user,
			@customer_name_in						=	@engg_customer_name,
			@project_name_in						=	@engg_project_name,
			@process_name_in						=	@process_name_tmp,
			@component_name_in						=	@component_name_tmp,
			@activity_name_in						=	@activity_name_tmp,
			@ui_name_in								=	@ui_name_tmp,
			@page_bt_synonym_in						=	@engg_page_descr,	
			@task_name_in							=	@engg_task_name,
			@flowbr_name_in							=	'',
			@combo_bt_synonym_in					=	@engg_tc_ctrl_bts,
			@combo_page_name_in						=	@engg_tc_page_name,
			@clear_tree_before_population_in		=	0,
			@timestamp_in							=	1,
			@engg_ecr_no							=	@engg_ico_no,
			@engg_tc_load							=	@engg_tc_load,
			@modeflag								=	@modeflag,
			@fprowno								=	@fprowno,
			@m_errorid								=	0	
	--TECH-75230

	-- Added BY Feroz
	--output parameters
	SELECT @fprowno 'fprowno'

	/*
--OuputList
Select null 'fprowno' from ***
*/
	SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_design_sp_savctltc' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON de_design_sp_savctltc	TO PUBLIC
END
GO

