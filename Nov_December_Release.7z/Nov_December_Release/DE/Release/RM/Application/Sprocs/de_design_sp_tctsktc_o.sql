IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_tctsktc_o' AND TYPE = 'P')
BEGIN
  DROP PROC de_design_sp_tctsktc_o
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_design_sp_tctsktc_o.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : de_design_sp_tctsktc_o                                        */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Muthu Kumar.K                                                 */
/* Date         : 19/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230  */
/********************************************************************************/
CREATE PROCEDURE de_design_sp_tctsktc_o
	@ctxt_language engg_ctxt_language, --Input 
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input 
	@ctxt_service engg_ctxt_service, --Input 
	@ctxt_user engg_ctxt_user, --Input 
	@engg_act_descr engg_name, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_ico_no engg_name, --Input 
	@engg_page_descr engg_name, --Input 
	@engg_proj_proc_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_task_name engg_name, --Input 
	@engg_tc_hdrtask_descr engg_description, --Input 
	@engg_tc_page engg_name, --Input 
	@engg_tc_section engg_name, --Input 
	@engg_ui_descr engg_name, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaration of temporary variables
	--temporary and formal parameters mapping
	--null checking
	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SET @engg_ico_no = NULL

	IF @engg_page_descr = '~#~'
		SET @engg_page_descr = NULL

	IF @engg_proj_proc_descr = '~#~'
		SET @engg_proj_proc_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_task_name = '~#~'
		SET @engg_task_name = NULL

	IF @engg_tc_hdrtask_descr = '~#~'
		SET @engg_tc_hdrtask_descr = NULL

	IF @engg_tc_page = '~#~'
		SET @engg_tc_page = NULL

	IF @engg_tc_section = '~#~'
		SET @engg_tc_section = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	DECLARE @map_flag_tmp INT
	DECLARE @map_ml_flag_tmp INT
	DECLARE @page_bt_synonym_tmp engg_name
	DECLARE @section_bt_synonym_tmp engg_name
	DECLARE @task_name_tmp engg_name
	DECLARE @control_bt_synonym_tmp engg_name
	DECLARE @ord_flg INT
	DECLARE @guid engg_guid

	SELECT @guid = newid()

	SELECT @engg_tc_page = NULL

	SELECT @engg_tc_section = NULL

	DECLARE @taskpattern_tmp engg_name

	SELECT @taskpattern_tmp = vw.default_for
	FROM de_action act(NOLOCK),
		es_comp_task_type_mst_vw vw(NOLOCK)
	WHERE act.customer_name = @engg_customer_name
		AND act.project_name = @engg_project_name
		AND act.process_name = @process_name_tmp
		AND act.component_name = @component_name_tmp
		AND act.activity_name = @activity_name_tmp
		AND act.ui_name = @ui_name_tmp
		AND act.task_name = @engg_task_name
		AND vw.customer_name = @engg_customer_name
		AND vw.project_name = @engg_project_name
		AND vw.process_name = @process_name_tmp
		AND vw.component_name = @component_name_tmp
		AND vw.task_type_name = act.task_pattern

	-- 
	-- 
	-- 
	-- 				
	-- 
	-- 	if @taskpattern_tmp ='Init'
	-- 	begin	
	-- 				select		@engg_task_name			'engg_tc_task_name',
	-- 							a.page_bt_synonym		'engg_tc_page_name',
	-- 							a.section_bt_synonym	'engg_tc_sec_name'	,
	-- 							control_bt_synonym		'engg_tc_ctrl_bts',		
	-- 							0					'engg_map_flag' ,		
	-- 							0						'engg_map_all'
	-- 				from	de_ui_control			a (nolock),
	-- 						es_comp_ctrl_type_mst_vw	ctm (nolock)	
	-- 				where a.customer_name		=	@engg_customer_name 
	-- 				and   a.project_name		=	@engg_project_name
	-- 				and   a.process_name		=	@process_name_tmp
	-- 				and   a.component_name		=	@component_name_tmp
	-- 				and   a.activity_name		=	@activity_name_tmp
	-- 				and   a.ui_name				=   @ui_name_tmp
	-- 				and   a.customer_name 		= 	ctm.customer_name
	-- 				and   a.project_name 		=   ctm.project_name
	-- 				and   a.process_name 		= 	ctm.process_name
	-- 				and	  a.control_type		=   ctm.ctrl_type_name	
	-- 				and	  ctm.base_ctrl_type	= 'Combo'
	-- 				and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 				and   a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
	-- 				and   a.control_bt_synonym not in( select control_bt_synonym 
	-- 												   from de_task_control_map m(nolock)																	
	-- 													where m.customer_name		=	@engg_customer_name 
	-- 													and   m.project_name		=	@engg_project_name
	-- 													and   m.process_name		=	@process_name_tmp
	-- 													and   m.component_name		=	@component_name_tmp
	-- 													and   m.activity_name		=	@activity_name_tmp
	-- 													and   m.ui_name				=   @ui_name_tmp	
	-- 													and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 													and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 													and   m.action_name 		= 	@engg_task_name)																			
	-- 				union
	-- 				select	@engg_task_name				'engg_tc_task_name',
	-- 						a.page_bt_synonym			'engg_tc_page_name',	
	-- 						a.section_bt_synonym		'engg_tc_sec_name'	,
	-- 						column_bt_synonym			'engg_tc_ctrl_bts',		
	-- 						0						'engg_map_flag' ,	
	-- 						0							'engg_map_all'
	-- 				from	de_ui_grid				a (nolock),
	-- 						es_comp_ctrl_type_mst_vw	ctm (nolock)
	-- 				where a.customer_name		=	@engg_customer_name 
	-- 				and   a.project_name		=	@engg_project_name
	-- 				and   a.process_name		=	@process_name_tmp
	-- 				and   a.component_name		=	@component_name_tmp
	-- 				and   a.activity_name		=	@activity_name_tmp
	-- 				and   a.ui_name				=   @ui_name_tmp
	-- 				and   a.customer_name 		= 	ctm.customer_name
	-- 				and   a.project_name 		=   ctm.project_name
	-- 				and   a.process_name 		= 	ctm.process_name
	-- 				and	  a.column_type		=   ctm.ctrl_type_name	
	-- 				and	  ctm.base_ctrl_type	= 'Combo'
	-- 				and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 				and   a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
	-- 				and   a.column_bt_synonym not in( select control_bt_synonym 
	-- 															   from de_task_control_map m(nolock)																	
	-- 																where m.customer_name		=	@engg_customer_name 
	-- 																and   m.project_name		=	@engg_project_name
	-- 																and   m.process_name		=	@process_name_tmp
	-- 																and   m.component_name		=	@component_name_tmp
	-- 																and   m.activity_name		=	@activity_name_tmp
	-- 																and   m.ui_name				=   @ui_name_tmp	
	-- 																and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 																and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 																and   m.action_name 		= 	@engg_task_name)																			
	-- 
	-- 				union
	-- 				select		@engg_task_name			'engg_tc_task_name',
	-- 							a.page_bt_synonym		'engg_tc_page_name',	
	-- 							c.section_bt_synonym	'engg_tc_sec_name'	,
	-- 							a.published_bt_synonym	'engg_tc_ctrl_bts',	
	-- 							0						'engg_map_flag' ,	
	-- 							0						'engg_map_all'
	-- 				from	de_resolved_link_dataitem	a (nolock),
	-- 						de_ui_control				c(nolock),
	-- 						es_comp_ctrl_type_mst_vw	ctm (nolock)
	-- 				where a.customer_name		=	@engg_customer_name 
	-- 				and   a.project_name		=	@engg_project_name
	-- 				and   a.process_name		=	@process_name_tmp
	-- 				and   a.component_name		=	@component_name_tmp
	-- 				and   a.activity_name		=	@activity_name_tmp
	-- 				and   a.ui_name				=   @ui_name_tmp
	-- 				and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 				and   c.section_bt_synonym 	=  isnull(@engg_tc_section,c.section_bt_synonym)
	-- 				and	  c.control_type		=   ctm.ctrl_type_name	
	-- 				and	  ctm.base_ctrl_type	<> 'Grid'
	-- 				and   a.customer_name		=	c.customer_name
	-- 				and   a.project_name		=	c.project_name
	-- 				and   a.process_name		=	c.process_name
	-- 				and   a.component_name		=	c.component_name
	-- 				and   a.activity_name		=	c.activity_name
	-- 				and   a.ui_name				=	c.ui_name
	-- 				and   a.published_control_name	= c.control_bt_synonym
	-- 				and   a.published_view_name 	= c.view_name
	-- 				and   a.published_bt_synonym not in( select control_bt_synonym 
	-- 												   from de_task_control_map m(nolock)																	
	-- 													where m.customer_name		=	@engg_customer_name 
	-- 													and   m.project_name		=	@engg_project_name
	-- 													and   m.process_name		=	@process_name_tmp
	-- 													and   m.component_name		=	@component_name_tmp
	-- 													and   m.activity_name		=	@activity_name_tmp
	-- 													and   m.ui_name				=   @ui_name_tmp	
	-- 													and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 													and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 													and   m.action_name 		= 	@engg_task_name)																			
	-- 			
	-- 			union
	-- 			select		@engg_task_name			'engg_tc_task_name',
	-- 						c.page_bt_synonym		'engg_tc_page_name',	
	-- 						c.section_bt_synonym	'engg_tc_sec_name'	,
	-- 						a.published_bt_synonym	'engg_tc_ctrl_bts',
	-- 						0						'engg_map_flag' ,	
	-- 						0						'engg_map_all'
	-- 			from	de_resolved_link_dataitem	a (nolock),
	-- 			de_ui_grid				c(nolock),
	-- 			es_comp_ctrl_type_mst_vw	ctm (nolock)
	-- 			where a.customer_name		=	@engg_customer_name 
	-- 			and   a.project_name		=	@engg_project_name
	-- 			and   a.process_name		=	@process_name_tmp
	-- 			and   a.component_name		=	@component_name_tmp
	-- 			and   a.activity_name		=	@activity_name_tmp
	-- 			and   a.ui_name				=   @ui_name_tmp
	-- 			and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 			and   c.section_bt_synonym 	=  isnull(@engg_tc_section,c.section_bt_synonym)
	-- 			and	  c.column_type		=   ctm.ctrl_type_name	
	-- 			and	  ctm.base_ctrl_type	= 'Grid'
	-- 			and   a.customer_name		=	c.customer_name
	-- 			and   a.project_name		=	c.project_name
	-- 			and   a.process_name		=	c.process_name
	-- 			and   a.component_name		=	c.component_name
	-- 			and   a.activity_name		=	c.activity_name
	-- 			and   a.ui_name				=	c.ui_name
	-- 			and   a.published_control_name	= c.control_bt_synonym
	-- 			and   a.published_view_name 	= c.view_name
	-- 			and   a.published_bt_synonym not in( select control_bt_synonym 
	-- 										   from de_task_control_map m(nolock)																	
	-- 											where m.customer_name		=	@engg_customer_name 
	-- 											and   m.project_name		=	@engg_project_name
	-- 											and   m.process_name		=	@process_name_tmp
	-- 											and   m.component_name		=	@component_name_tmp
	-- 											and   m.activity_name		=	@activity_name_tmp
	-- 											and   m.ui_name				=   @ui_name_tmp	
	-- 											and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 											and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 											and   m.action_name 		= 	@engg_task_name)																			
	-- 			union
	-- 	
	-- 			select  @engg_task_name 		'engg_tc_task_name',	
	-- 					page_name				'engg_tc_page_name',	
	-- 					section_name			'engg_tc_sec_name',
	-- 					control_bt_synonym		'engg_tc_ctrl_bts',	
	-- 				case map_flag
	-- 				when 'Y' then 1
	-- 				else 0 end					'engg_map_all' ,
	-- 				case map_ml_flag
	-- 				when 'Y' then 1
	-- 				else 0 end					'engg_map_flag' 
	-- 		    from de_task_control_map m(nolock)																	
	-- 			where m.customer_name		=	@engg_customer_name 
	-- 			and   m.project_name		=	@engg_project_name
	-- 			and   m.process_name		=	@process_name_tmp
	-- 			and   m.component_name		=	@component_name_tmp
	-- 			and   m.activity_name		=	@activity_name_tmp
	-- 			and   m.ui_name				=   @ui_name_tmp	
	-- 			and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 			and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 			and   m.action_name 		= 	@engg_task_name
	-- 
	-- 		end
	-- 
	-- 
	-- 	if @taskpattern_tmp 	in( 'Fetch','Trans','UI')
	-- 	begin
	-- 
	-- 		select	@engg_task_name			'engg_tc_task_name',
	-- 				a.page_bt_synonym		'engg_tc_page_name',		
	-- 				a.section_bt_synonym	'engg_tc_sec_name',
	-- 				control_bt_synonym		'engg_tc_ctrl_bts',	
	-- 				'0'						'engg_map_flag' ,					
	-- 				'0'						'engg_map_all'	
	-- 		from de_ui_control a(nolock)
	-- 		where a.customer_name		=	@engg_customer_name 
	-- 		and   a.project_name		=	@engg_project_name
	-- 		and   a.process_name		=	@process_name_tmp
	-- 		and   a.component_name		=	@component_name_tmp
	-- 		and   a.activity_name		=	@activity_name_tmp
	-- 		and   a.ui_name				=   @ui_name_tmp
	-- 		and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 		and   a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)
	-- 		and   a.control_bt_synonym not in( select control_bt_synonym 
	-- 											from de_task_control_map m(nolock)																	
	-- 											where m.customer_name		=	@engg_customer_name 
	-- 											and   m.project_name		=	@engg_project_name
	-- 											and   m.process_name		=	@process_name_tmp
	-- 											and   m.component_name		=	@component_name_tmp
	-- 											and   m.activity_name		=	@activity_name_tmp
	-- 											and   m.ui_name				=   @ui_name_tmp	
	-- 											and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 											and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 											and   m.action_name 		= 	@engg_task_name)																			
	-- 
	-- 		union
	-- 		select		@engg_task_name			'engg_tc_task_name',
	-- 					a.page_bt_synonym		'engg_tc_page_name',	
	-- 					a.section_bt_synonym	'engg_tc_sec_name',
	-- 					column_bt_synonym		'engg_tc_ctrl_bts',	
	-- 					0					'engg_map_flag' ,		
	-- 					0						'engg_map_all'		
	-- 		from 	de_ui_grid a(nolock)
	-- 		where a.customer_name		=	@engg_customer_name 
	-- 		and   a.project_name		=	@engg_project_name
	-- 		and   a.process_name		=	@process_name_tmp
	-- 		and   a.component_name		=	@component_name_tmp
	-- 		and   a.activity_name		=	@activity_name_tmp
	-- 		and   a.ui_name				=   @ui_name_tmp
	-- 		and   a.page_bt_synonym 	=  isnull(@engg_tc_page,a.page_bt_synonym)
	-- 		and   a.section_bt_synonym 	=  isnull(@engg_tc_section,a.section_bt_synonym)	
	-- 		and   a.column_bt_synonym not in( select control_bt_synonym 
	-- 											from de_task_control_map m(nolock)																	
	-- 											where m.customer_name		=	@engg_customer_name 
	-- 											and   m.project_name		=	@engg_project_name
	-- 											and   m.process_name		=	@process_name_tmp
	-- 											and   m.component_name		=	@component_name_tmp
	-- 											and   m.activity_name		=	@activity_name_tmp
	-- 											and   m.ui_name				=   @ui_name_tmp	
	-- 											and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 											and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 											and   m.action_name 		= 	@engg_task_name)																			
	-- 
	-- 		union
	-- 		select 		m.action_name				'engg_tc_task_name',
	-- 				m.page_name					'engg_tc_page_name' ,
	-- 				m.section_name				'engg_tc_sec_name' ,
	-- 				control_bt_synonym			'engg_tc_ctrl_bts' ,
	-- 				case map_flag
	-- 				when 'Y' then 1
	-- 				else 0 end					'engg_map_all' ,
	-- 				case map_ml_flag
	-- 				when 'Y' then 1
	-- 				else 0 end					'engg_map_flag' 
	-- 		from de_task_control_map m(nolock)																	
	-- 		where m.customer_name		=	@engg_customer_name 
	-- 		and   m.project_name		=	@engg_project_name
	-- 		and   m.process_name		=	@process_name_tmp
	-- 		and   m.component_name		=	@component_name_tmp
	-- 		and   m.activity_name		=	@activity_name_tmp
	-- 		and   m.ui_name				=   @ui_name_tmp	
	-- 		and   m.page_name			= 	isnull(@engg_tc_page,m.page_name)
	-- 		and   m.section_name		= 	isnull(@engg_tc_section,m.section_name)
	-- 		and   m.action_name 		= 	@engg_task_name
	-- 		
	-- 	end
	-- 	
	-- 
	SELECT CASE map_ml_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_all',
		CASE map_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_flag',
		control_bt_synonym 'engg_tc_ctrl_bts',
		page_name 'engg_tc_page_name',
		section_name 'engg_tc_sec_name',
		action_name 'engg_tc_task_name',
		mapping_instance 'engg_mapping_instance',
		CASE [Load] WHEN 'Y' THEN 1 ELSE 0 END 'engg_tc_load', ---TECH-75230
		control_type 'engg_tc_ctrl_type'	--TECH-75230
	FROM de_task_control_map a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.activity_name = @activity_name_tmp
		AND a.ui_name = @ui_name_tmp
		AND a.action_name = @engg_task_name
		AND a.control_bt_synonym NOT IN (
			SELECT hidden_view_bt_synonym
			FROM de_hidden_view b(NOLOCK)
			WHERE a.customer_name = b.customer_name
				AND a.project_name = b.project_name
				AND a.process_name = b.process_name
				AND a.component_name = b.component_name
				AND a.activity_name = b.activity_name
				AND a.ui_name = b.ui_name
				AND a.page_name = b.page_name
				AND a.section_name = b.section_name
				AND isnull(b.HIDDEN_VIEW_SOURCE, '') <> ''
			)

	/* 
	--OuputList
	Select null 'engg_map_all', 
	null 'engg_map_flag', 
	null 'engg_tc_ctrl_bts', 
	null 'engg_tc_page_name', 
	null 'engg_tc_sec_name', 
	null 'engg_tc_task_name', 
	null 'engg_mapping_instance' from *** 
*/
	SET NOCOUNT OFF
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_tctsktc_o' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_design_sp_tctsktc_o TO PUBLIC
END
GO