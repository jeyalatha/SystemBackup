IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DEactpatSpsavetsktyp' AND TYPE = 'P')
    BEGIN
        DROP PROC DEactpatSpsavetsktyp
    END
GO
/*********************************************************************************/
/* Procedure					: DEactpatSpsavetsktyp							 */
/* Description					: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									 */
/* Date							: Nov 16 2022 11:52AM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Created By					: VimalKumar R									 */
/* Date							: 01/12/2022									 */
/* Description					: 												 */
/*********************************************************************************/

Create Procedure DEactpatSpsavetsktyp
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@de_engg_cmbtaskt_met      	engg_name, --Input 
	@de_engg_cmbtask_patt      	engg_name, --Input 
	@de_engg_component         	engg_description, --Input 
	@de_engg_customer_name     	engg_name, --Input 
	@de_engg_ecr_no            	engg_name, --Input 
	@de_engg_process_descr     	engg_description, --Input 
	@de_engg_project_name      	engg_name, --Input 
	@de_engg_taskcmb_type      	engg_name, --Input 
	@de_engg_tasktxt_desc      	engg_description, --Input 
	@de_engg_task_descr        	engg_description, --Input 
	@de_engg_task_docum        	engg_description, --Input 
	@de_engg_task_req          	engg_flag, --Input 
	@de_engg_tasttxt_docu      	engg_description, --Input 
	@de_engg_txttask_patt_desc 	engg_description, --Input 
	@de_engg_txttask_patt_name 	engg_name, --Input 
	@hdncustomer               	engg_name, --Input 
	@hdnproject                	engg_name, --Input 
	@modeflag                  	modeflag, --Input 
	@prj_hdn_ctrl              	plf_hdn_ctrl_bt, --Input 
	@fprowno                   	rowno, --Input/Output
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = @ctxt_user
	Set @ctxt_service               = @ctxt_service
	Set @de_engg_cmbtaskt_met       = @de_engg_cmbtaskt_met
	Set @de_engg_cmbtask_patt       = @de_engg_cmbtask_patt
	Set @de_engg_component          = @de_engg_component
	Set @de_engg_customer_name      = @de_engg_customer_name
	Set @de_engg_ecr_no             = @de_engg_ecr_no
	Set @de_engg_process_descr      = @de_engg_process_descr
	Set @de_engg_project_name       = @de_engg_project_name
	Set @de_engg_taskcmb_type       = @de_engg_taskcmb_type
	Set @de_engg_tasktxt_desc       = @de_engg_tasktxt_desc
	Set @de_engg_task_descr         = @de_engg_task_descr
	Set @de_engg_task_docum         = @de_engg_task_docum
	Set @de_engg_task_req           = @de_engg_task_req
	Set @de_engg_tasttxt_docu       = @de_engg_tasttxt_docu
	Set @de_engg_txttask_patt_desc  = @de_engg_txttask_patt_desc
	Set @de_engg_txttask_patt_name  = @de_engg_txttask_patt_name
	Set @hdncustomer                = @hdncustomer
	Set @hdnproject                 = @hdnproject
	Set @modeflag                   = @modeflag
	Set @prj_hdn_ctrl               = @prj_hdn_ctrl

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @de_engg_cmbtaskt_met = '~#~' 
		Select @de_engg_cmbtaskt_met = null  

	IF @de_engg_cmbtask_patt = '~#~' 
		Select @de_engg_cmbtask_patt = null  

	IF @de_engg_component = '~#~' 
		Select @de_engg_component = null  

	IF @de_engg_customer_name = '~#~' 
		Select @de_engg_customer_name = null  

	IF @de_engg_ecr_no = '~#~' 
		Select @de_engg_ecr_no = null  

	IF @de_engg_process_descr = '~#~' 
		Select @de_engg_process_descr = null  

	IF @de_engg_project_name = '~#~' 
		Select @de_engg_project_name = null  

	IF @de_engg_taskcmb_type = '~#~' 
		Select @de_engg_taskcmb_type = null  

	IF @de_engg_tasktxt_desc = '~#~' 
		Select @de_engg_tasktxt_desc = null  

	IF @de_engg_task_descr = '~#~' 
		Select @de_engg_task_descr = null  

	IF @de_engg_task_docum = '~#~' 
		Select @de_engg_task_docum = null  

	IF @de_engg_task_req = '~#~' 
		Select @de_engg_task_req = null  

	IF @de_engg_tasttxt_docu = '~#~' 
		Select @de_engg_tasttxt_docu = null  

	IF @de_engg_txttask_patt_desc = '~#~' 
		Select @de_engg_txttask_patt_desc = null  

	IF @de_engg_txttask_patt_name = '~#~' 
		Select @de_engg_txttask_patt_name = null  

	IF @hdncustomer = '~#~' 
		Select @hdncustomer = null  

	IF @hdnproject = '~#~' 
		Select @hdnproject = null  

	IF @modeflag = '~#~' 
		Select @modeflag = null  

	IF @prj_hdn_ctrl = '~#~' 
		Select @prj_hdn_ctrl = null  

	IF @fprowno = -915
		Select @fprowno = null  

	DECLARE @engg_process_name engg_name,
		@engg_comp_name engg_name,
		@msg engg_description

	SELECT @engg_process_name = process_name,
		@engg_comp_name = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @de_engg_customer_name
		AND project_name = @de_engg_project_name
		AND process_descr = @de_engg_process_descr
		AND component_descr = @de_engg_component
	ORDER BY 1, 2


	IF @modeflag IN (
			'U',
			'Y'
			)
	BEGIN
		IF @de_engg_task_descr = 'Process only Selected Rows'
			AND @de_engg_task_req = 1
		BEGIN
			SELECT @msg = 'Kindly select the "System Process only Selected Rows"  instead of  "Process only Selected Rows" and proceed.'

			EXEC engg_error_sp 'ep_main13SpenggavHdrSav',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		IF @de_engg_task_descr = 'Process only Updated Rows'
			AND @de_engg_task_req = 1
		BEGIN
			SELECT @msg = 'Kindly select the "System Process only Updated Rows"  instead of  "Process only Updated Rows" and proceed.'

			EXEC engg_error_sp 'ep_main13SpenggavHdrSav',
				1,
				@msg,
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				'',
				'',
				'',
				'',
				@m_errorid OUTPUT

			RETURN
		END

		--TECH-69327
		IF ISNULL(@de_engg_cmbtaskt_met,'') IN ('Initialize','Fetch') AND @de_engg_task_req = 1 AND ISNULL(@de_engg_task_descr,'') = 'Bubble Message'
		BEGIN
			RAISERROR ('Bubble message is not applicable for ''Initialize'' and ''Fetch''.',16,1)
		END

		DECLARE @renderas engg_name

		SELECT @renderas = CASE 
				WHEN sys_proc_sel_rows = 'y'
					THEN 'System Process only Selected Rows'
				WHEN sys_process_updrows = 'y'
					THEN 'System Process only Updated Rows'
				WHEN sys_proc_selupd_rows = 'y'
					THEN 'System Process only selected Updated Rows'
				END
		FROM es_comp_task_type_mst(NOLOCK)
		WHERE customer_name = @de_engg_customer_name
			AND project_name = @de_engg_project_name
			AND process_name = @engg_process_name
			AND component_name = @engg_comp_name
			AND task_type_name = @de_engg_cmbtask_patt

		IF EXISTS (
				SELECT 'x'
				FROM es_comp_task_type_mst(NOLOCK)
				WHERE customer_name = @de_engg_customer_name
					AND project_name = @de_engg_project_name
					AND process_name = @engg_process_name
					AND component_name = @engg_comp_name
					AND task_type_name = @de_engg_cmbtask_patt
					AND len(@renderas) <> 0
					AND @de_engg_task_req = 1
					AND @de_engg_task_descr IN (
						'System Process only Selected Rows',
						'System Process only Updated Rows',
						'System Process only selected Updated Rows'
						)
					AND @renderas <> @de_engg_task_descr
				)
		BEGIN
			RAISERROR (
					'Kindly choose any one attribute from the following list ''System Process only Selected Rows, System Process only Updated Rows, System Process only selected Updated Rows''.',
					16,
					1
					)

			RETURN
		END

		IF @de_engg_task_descr = 'Bulk Validation'
			AND @de_engg_cmbtaskt_met <> 'Trans'
			AND	@de_engg_task_req = 1	
		BEGIN
			RAISERROR (
					'Bulk Validation is applicable only for the Action type ''TRANS''.',
					16,
					1
					)

			RETURN
		END

		IF EXISTS (
				SELECT 'x'
				FROM ep_action_mst a(NOLOCK),
					de_task_control_map b(NOLOCK)
				WHERE a.customer_name = @de_engg_customer_name
					AND a.project_name = @de_engg_project_name
					AND a.process_name = @engg_process_name
					AND a.component_name = @engg_comp_name
					AND a.task_pattern = @de_engg_cmbtask_patt
					AND a.customer_name = b.customer_name
					AND a.project_name = b.project_name
					AND a.process_name = b.process_name
					AND a.component_name = b.component_name
					AND a.activity_name = b.activity_name
					AND a.ui_name = b.ui_name
					AND a.task_name = b.action_name
				)
		BEGIN
			DECLARE @count engg_flag,
				@de_engg_task_req1 engg_flag

			IF (@de_engg_task_req = 1)
			BEGIN
				SELECT @de_engg_task_req1 = 'Y'
			END

			IF (@de_engg_task_req = 0)
			BEGIN
				SELECT @de_engg_task_req1 = 'n'
			END

			SELECT @count = NULL

			SELECT @count = CASE 
					WHEN @de_engg_task_descr = 'Clear On Page Save'
						AND (@de_engg_task_req1 <> a.clr_on_page_save)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Combo Default Required'
						AND (@de_engg_task_req1 <> a.cbdef_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Conditional Multiline Fetch'
						AND (@de_engg_task_req1 <> a.cond_ml_fetch)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Data Saving Task'
						AND (@de_engg_task_req1 <> a.data_save_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Header Fetch Required'
						AND (@de_engg_task_req1 <> a.hdr_fetch_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Header Save Required'
						AND (@de_engg_task_req1 <> a.hdr_save_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Include Message Place Holder'
						AND (@de_engg_task_req1 <> a.incl_place_holder)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'ML Save Required'
						AND (@de_engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'LinkAsUI Required'
						AND (@de_engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Uiastrans Required'
						AND (@de_engg_task_req1 <> a.ml_save_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Multiline Fetch Required'
						AND (@de_engg_task_req1 <> a.ml_fet_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'ML Singlesegment Required'
						AND (@de_engg_task_req1 <> a.MLSaveSinglesegment)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Process only Selected Rows'
						AND (@de_engg_task_req1 <> a.proc_sel_rows)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Process only Updated Rows'
						AND (@de_engg_task_req1 <> a.process_updrows)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Refresh On Save'
						AND (@de_engg_task_req1 <> a.refresh_on_save)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Header Refresh Method Required'
						AND (@de_engg_task_req1 <> a.hdr_ref_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Method for Header Check Required'
						AND (@de_engg_task_req1 <> a.hdr_check_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Method for Message Handling'
						AND (@de_engg_task_req1 <> a.err_handle_method)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND (@de_engg_task_req1 <> a.usr_role_map)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Task Conformation'
						AND (@de_engg_task_req1 <> a.task_confirmation)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Logic Extensions'
						AND (@de_engg_task_req1 <> a.Logic_Extensions)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Transaction Scope Required'
						AND (@de_engg_task_req1 <> a.trn_scope_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Validate On Initiate'
						AND (@de_engg_task_req1 <> a.valid_on_init)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Fprowno Required'
						AND (@de_engg_task_req1 <> a.fprowno_req)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Configure Alternate Database'
						AND (@de_engg_task_req1 <> a.alternate_db)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'System Process only Selected Rows'
						AND (@de_engg_task_req1 <> a.sys_proc_sel_rows)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'System Process only Updated Rows'
						AND (@de_engg_task_req1 <> a.sys_process_updrows)
						THEN 'y'
					WHEN @de_engg_task_descr = 'System Process only selected Updated Rows'
						AND (@de_engg_task_req1 <> a.sys_proc_selupd_rows)
						THEN 'y'
					WHEN @de_engg_task_descr = 'Parent Context Parameters'
						AND (@de_engg_task_req1 <> a.ParentContextInformation)
						THEN 'y'
					WHEN @de_engg_task_descr = 'Current Context Parameters'
						AND (@de_engg_task_req1 <> a.CurrentContextInformation)
						THEN 'y'
					WHEN @de_engg_cmbtaskt_met = 'DoNotDefault'
						AND (a.default_for <> 'DND')
						THEN 'Y'
					WHEN @de_engg_cmbtaskt_met = 'Initialize'
						AND (a.default_for <> 'Init')
						THEN 'Y'
					WHEN @de_engg_cmbtaskt_met NOT IN (
							'DoNotDefault',
							'Initialize'
							)
						AND (@de_engg_cmbtaskt_met <> a.default_for)
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Modeflag Enabled'
						AND (@de_engg_task_req1 <> a.ModeflagEnabled)
						THEN 'y'
					WHEN @de_engg_task_descr = 'Bulk Validation'
						AND (@de_engg_task_req1 <> a.BulkValidation)
						THEN 'y'
					WHEN @de_engg_task_descr = 'Bubble Message'
						AND (@de_engg_task_req1 <> a.BubbleMessage)
						THEN 'y'
					ELSE 'n'
					END
			FROM es_comp_task_type_mst a(NOLOCK)
			WHERE customer_name = @de_engg_customer_name
				AND project_name = @de_engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @de_engg_cmbtask_patt

			IF @count <> 'n'
			BEGIN
				RAISERROR (
						'Action Pattern Name %s is in use..Cannot modify..',
						16,
						1,
						@de_engg_cmbtask_patt
						)

				RETURN
			END
		END
		ELSE
		BEGIN
			UPDATE a
			SET a.clr_on_page_save = CASE 
					WHEN @de_engg_task_descr = 'Clear On Page Save'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Clear On Page Save'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.clr_on_page_save
					END,
				a.cbdef_req = CASE 
					WHEN @de_engg_task_descr = 'Combo Default Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Combo Default Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.cbdef_req
					END,
				a.cond_ml_fetch = CASE 
					WHEN @de_engg_task_descr = 'Conditional Multiline Fetch'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Conditional Multiline Fetch'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.cond_ml_fetch
					END,
				a.data_save_req = CASE 
					WHEN @de_engg_task_descr = 'Data Saving Task'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Data Saving Task'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.data_save_req
					END,
				a.hdr_fetch_req = CASE 
					WHEN @de_engg_task_descr = 'Header Fetch Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Header Fetch Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_fetch_req
					END,
				a.hdr_save_req = CASE 
					WHEN @de_engg_task_descr = 'Header Save Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Header Save Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_save_req
					END,
				a.incl_place_holder = CASE 
					WHEN @de_engg_task_descr = 'Include Message Place Holder'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Include Message Place Holder'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.incl_place_holder
					END,
				a.ml_save_req = CASE 
					WHEN @de_engg_task_descr = 'ML Save Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'ML Save Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.ml_save_req
					END,
				a.Linkasui = CASE 
					WHEN @de_engg_task_descr = 'LinkAsUI Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'LinkAsUI Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.Linkasui
					END,
				a.Uiastrans = CASE 
					WHEN @de_engg_task_descr = 'Uiastrans Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Uiastrans Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.Linkasui
					END,
				a.ml_fet_req = CASE 
					WHEN @de_engg_task_descr = 'Multiline Fetch Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Multiline Fetch Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.ml_fet_req
					END,
				a.MLSaveSinglesegment = CASE 
					WHEN @de_engg_task_descr = 'ML Singlesegment Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'ML Singlesegment Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.MLSaveSinglesegment
					END,
				a.proc_sel_rows = CASE 
					WHEN @de_engg_task_descr = 'Process only Selected Rows'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Process only Selected Rows'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.proc_sel_rows
					END,
				a.process_updrows = CASE 
					WHEN @de_engg_task_descr = 'Process only Updated Rows'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Process only Updated Rows'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.process_updrows
					END,
				a.refresh_on_save = CASE 
					WHEN @de_engg_task_descr = 'Refresh On Save'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Refresh On Save'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.refresh_on_save
					END,
				a.hdr_ref_req = CASE 
					WHEN @de_engg_task_descr = 'Separate Header Refresh Method Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Header Refresh Method Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_ref_req
					END,
				a.hdr_check_req = CASE 
					WHEN @de_engg_task_descr = 'Separate Method for Header Check Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Method for Header Check Required'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.hdr_check_req
					END,
				a.err_handle_method = CASE 
					WHEN @de_engg_task_descr = 'Separate Method for Message Handling'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Separate Method for Message Handling'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.err_handle_method
					END,
				a.usr_role_map = CASE 
					WHEN @de_engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND @de_engg_task_req = 1
						THEN 'y'
					WHEN @de_engg_task_descr = 'Should User Role to be Mapped to All Methods'
						AND @de_engg_task_req = 0
						THEN 'n'
					ELSE a.usr_role_map
					END,
				a.task_confirmation = CASE 
					WHEN @de_engg_task_descr = 'Task Conformation'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Task Conformation'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.task_confirmation
					END,
				a.Logic_extensions = CASE 
					WHEN @de_engg_task_descr = 'Logic Extensions'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Logic Extensions'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.Logic_extensions
					END,
				a.trn_scope_req = CASE 
					WHEN @de_engg_task_descr = 'Transaction Scope Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Transaction Scope Required'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.trn_scope_req
					END,
				a.valid_on_init = CASE 
					WHEN @de_engg_task_descr = 'Validate On Initiate'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Validate On Initiate'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.valid_on_init
					END,
				a.fprowno_req = CASE 
					WHEN @de_engg_task_descr = 'Fprowno Required'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Fprowno Required'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.fprowno_req
					END,
				a.alternate_db = CASE 
					WHEN @de_engg_task_descr = 'Configure Alternate Database'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Configure Alternate Database'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.alternate_db
					END,
				a.sys_proc_sel_rows = CASE 
					WHEN @de_engg_task_descr = 'System Process only Selected Rows'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'System Process only Selected Rows'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.sys_proc_sel_rows
					END,
				a.sys_process_updrows = CASE 
					WHEN @de_engg_task_descr = 'System Process only Updated Rows'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'System Process only Updated Rows'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.sys_process_updrows
					END,
				a.sys_proc_selupd_rows = CASE 
					WHEN @de_engg_task_descr = 'System Process only selected Updated Rows'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'System Process only selected Updated Rows'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.sys_proc_selupd_rows
					END,
				a.ParentContextInformation = CASE 
					WHEN @de_engg_task_descr = 'Parent Context Parameters'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Parent Context Parameters'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.ParentContextInformation
					END,
				a.CurrentContextInformation = CASE 
					WHEN @de_engg_task_descr = 'Current Context Parameters'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Current Context Parameters'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.CurrentContextInformation
					END,
				a.ModeflagEnabled = CASE 
					WHEN @de_engg_task_descr = 'Modeflag Enabled'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Modeflag Enabled'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.ModeflagEnabled
					END,
				a.bulkvalidation = CASE 
					WHEN @de_engg_task_descr = 'Bulk Validation'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Bulk Validation'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.bulkvalidation
					END,
				a.BubbleMessage = CASE 
					WHEN @de_engg_task_descr = 'Bubble Message'
						AND @de_engg_task_req = 1
						THEN 'Y'
					WHEN @de_engg_task_descr = 'Bubble Message'
						AND @de_engg_task_req = 0
						THEN 'N'
					ELSE a.BubbleMessage
					END,				
				a.task_type_descr = @de_engg_tasktxt_desc,
				a.task_type_doc = @de_engg_tasttxt_docu,
				a.default_for = CASE 
					WHEN @de_engg_cmbtaskt_met = 'DoNotDefault'
						THEN 'DND'
					WHEN @de_engg_cmbtaskt_met = 'Initialize'
						THEN 'Init'
					ELSE @de_engg_cmbtaskt_met
					END
			FROM es_comp_task_type_mst a(NOLOCK)
			WHERE customer_name = @de_engg_customer_name
				AND project_name = @de_engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @de_engg_cmbtask_patt
		END
	END

	UPDATE a
	SET a.task_type_descr = @de_engg_tasktxt_desc,
		a.task_type_doc = @de_engg_tasttxt_docu
	FROM es_comp_task_type_mst a(NOLOCK)
	WHERE customer_name = @de_engg_customer_name
		AND project_name = @de_engg_project_name
		AND process_name = @engg_process_name
		AND component_name = @engg_comp_name
		AND task_type_name = @de_engg_cmbtask_patt

	EXEC REActionpatternSaveSp
			@ctxt_ouinstance				=	@ctxt_ouinstance,
			@ctxt_user						=	@ctxt_user,                 
			@ctxt_language 					=	@ctxt_language,
			@ctxt_service 					=	@ctxt_service,
			@engg_cmbtaskt_met 				=	@de_engg_cmbtaskt_met,      
			@engg_cmbtask_patt 				=	@de_engg_cmbtask_patt,      
			@engg_component 				=	@de_engg_component,         
			@engg_customer_name 			=	@de_engg_customer_name,     
			@engg_process_descr 			=   @de_engg_process_descr,             
			@engg_project_name				=	@de_engg_project_name,      
			@engg_req_no 					=	@de_engg_ecr_no,
			@engg_tasktxt_desc 				=	@de_engg_tasktxt_desc,     
			@engg_task_descr 				=	@de_engg_task_descr,        
			@engg_task_req 					=	@de_engg_task_req,           
			@engg_tasttxt_docu 				=	@de_engg_tasttxt_docu,      
			@guid							=	'',
			@hidden_control1 				=	@prj_hdn_ctrl,    
			@modeflag 						=	@modeflag,      
			@engg_a_fprowno 				=	@fprowno,     
			@engg_k_fprowno 				=	'',
			@m_errorid						=	@m_errorid  

	EXEC DEActionpatternSaveSp
			@ctxt_ouinstance				=	@ctxt_ouinstance,
			@ctxt_user						=	@ctxt_user,                 
			@ctxt_language 					=	@ctxt_language,
			@ctxt_service 					=	@ctxt_service,
			@engg_cmbtaskt_met 				=	@de_engg_cmbtaskt_met,      
			@engg_cmbtask_patt 				=	@de_engg_cmbtask_patt,      
			@engg_component 				=	@de_engg_component,         
			@engg_customer_name 			=	@de_engg_customer_name,     
			@engg_process_descr 			=   @de_engg_process_descr,             
			@engg_project_name				=	@de_engg_project_name,      
			@engg_req_no 					=	@de_engg_ecr_no,
			@engg_tasktxt_desc 				=	@de_engg_tasktxt_desc,     
			@engg_task_descr 				=	@de_engg_task_descr,        
			@engg_task_req 					=	@de_engg_task_req,           
			@engg_tasttxt_docu 				=	@de_engg_tasttxt_docu,      
			@guid							=	'',
			@hidden_control1 				=	@prj_hdn_ctrl,    
			@modeflag 						=	@modeflag,      
			@engg_a_fprowno 				=	@fprowno,     
			@engg_k_fprowno 				=	'',
			@m_errorid						=	@m_errorid  
           
												              
	--SELECT @engg_a_fprowno 'engg_a_fprowno',
	--	@engg_k_fprowno 'engg_k_fprowno'
												              
	/* 
	-- OutputList
	Select
		null 'fprowno', 
	*/

	Set nocount off
End


IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DEactpatSpsavetsktyp' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON DEactpatSpsavetsktyp TO PUBLIC
END
GO