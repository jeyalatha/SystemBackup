IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_update_refine_methods' AND TYPE = 'P')
BEGIN
  DROP PROC de_update_refine_methods
END
GO
/********************************************************************************/
/* procedure    : de_update_refine_methods                                      */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : DNR                                                         */
/* date         : 23/ June/2004                                                 */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : DNR                                                           */
/* date         : 25-June-2004                                                  */
/* description  : DEENG203ACC_000081                                            */
/* RefineMethods Information is not updating properly.       */
/* Modified by  : Shriram V              */
/* Date  : 09-Mar-04              */
/* Bug Id       : DEENG203SYS_000528           */
/* Description  : Customer JNJ,Project GAIT, Engineering Change Request # MntCompECR Update Service Tab If u press Update Services button after selecting all the rows in the multiline,Follwing error is being thrown.Violation of PRIMARY KEY constraint 'de_

fw_des_brerror_pkey'. Cannot insert duplicate key in object 'de_fw_des_brerror'. */

/*http://ramcovm156/rvw */
/********************************************************************************/
/* Modified By : Anuradha M       */
/* Date        : 13/07/2005       */
/* Bug Id      : PNR2.0_3241       */
/* Description : While publishing the ECR error thrown as Placeholder is not mapped*/
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230  */
/********************************************************************************/
CREATE Procedure de_update_refine_methods
@ctxt_language              engg_ctxt_language,
@ctxt_ouinstance            engg_ctxt_ouinstance,
@ctxt_service               engg_ctxt_service,
@ctxt_user                  engg_ctxt_user,
@customer_name          engg_name,
@project_name       engg_name,
@process_name    engg_name,
@component_name    engg_name,
@activity_name    engg_name,
@ui_name     engg_name,
@service_name    engg_name,
@method_name    engg_name,
@flowbr_name    engg_name,
@engg_ico_no    engg_name,--chan
@m_errorid                  int output
as
begin

set nocount on

set @m_errorid = 0

---------------------------------------------------------------------------------------------
-- UPDATING THE REFINED METHOD PARAMETERS INFORMATION
---------------------------------------------------------------------------------------------

declare  @parameter_name_tmp  engg_name ,
@new_seq_no_tmp   engg_seqno ,
@required_flag_tmp  engg_flag ,
@method_id    engg_id_no,
@sequence_no_tmp   engg_sequence_no,
@EndPos1     int,
@StartPos1     int,
@msg     engg_description,
@StartPos     Int,
@EndPos       Int,
@PlaceHolder    varchar(25),
@err_msg     varchar(100),
@getdate     engg_date

Select  @getdate = getdate()
Select  @StartPos  = 1
select @EndPos1  = 0
select @StartPos1 = 250



select  @method_id = methodid
from de_fw_des_businessrule(nolock)
where  customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name =  @process_name
and  component_name =  @component_name
and  methodname  = @method_name

declare curTasks cursor for
select  parameter_name ,sequence_no, new_seq_no , required_flag
from  de_refine_parameter (nolock)
where  customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name =  @process_name
and  component_name =  @component_name
and  activity_name = @activity_name
and  ui_name   = @ui_name
and  service_name = @service_name
and  method_name  = @method_name
-- modified by Ganesh on 30/09/04 the method parameter which are removed in refine
-- is not getting deleted from method parameter
and  flowbr_name  = isnull(@flowbr_name, '')

open curTasks

while 1=1
begin

fetch next  from curTasks
into  @parameter_name_tmp ,@sequence_no_tmp, @new_seq_no_tmp , @required_flag_tmp

if @@fetch_status<>0
break

if isnull(@new_seq_no_tmp ,0)= 0
select  @new_seq_no_tmp = @sequence_no_tmp

if isnull(@required_flag_tmp,'0') = '1'
begin
update  de_fw_des_br_logical_parameter
set  logicalparamseqno   = @new_seq_no_tmp,
	modifiedby	= @ctxt_user,--TECH-75230
	modifieddate	=	getdate(),  --TECH-75230
	ecrno = @engg_ico_no --TECH-75230
where  customer_name    = @customer_name
and  project_name     = @project_name
and  process_name   = @process_name
and     component_name   = @component_name
and  method_name      = @method_name
and  logicalparametername  = @parameter_name_tmp
end
else
begin

if exists ( select 'X'
from de_fw_des_be_placeholder (nolock)
where  customer_name  = @customer_name
and  project_name  = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  method_name  = @method_name
and  parametername = @parameter_name_tmp
)
begin
raiserror('parameter can not be deleted since it is mapped to the place holder',16,5)
return
end

if exists( select  'X'
from  de_fw_des_di_placeholder(nolock)
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  servicename  = @service_name
and  method_name  = @method_name
and  placeholdername = @parameter_name_tmp
)
begin
raiserror('parameter can not be deleted since it is mapped to the place holder',16,5)
return
end


delete de_fw_des_di_parameter
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  servicename  = @service_name
and  method_name  = @method_name
and  parametername =  @parameter_name_tmp

-- Code commented by Anuradha M on 13/07/2005 for the Bug ID : PNR2.0_3241
--    delete   de_fw_des_di_placeholder
--    where  customer_name = @customer_name
--    and  project_name = @project_name
--    and  process_name = @process_name
--    and  component_name = @component_name
--    and  servicename  = @service_name
--    and  method_name  = @method_name
--    and  placeholdername not in ( select parametername
--            from de_fw_des_di_parameter (nolock)
--            where  customer_name = @customer_name
--            and  project_name = @project_name
--            and  process_name = @process_name
--            and  component_name = @component_name
--            and  servicename  = @service_name
--            and  method_name  = @method_name)

-- Code Modified by Anuradha M on 13/07/2005 for the Bug ID : PNR2.0_3241
-- code modified by Ganesh for the callid :: Platform_2.0.3.X_471 on 5/9/05
delete  a
from de_fw_des_be_placeholder a
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  method_name  = @method_name
and  not exists ( select  's'
from de_fw_des_di_parameter b (nolock)
where  b.customer_name = a.customer_name
and  b.project_name = a.project_name
and  b.process_name = a.process_name
and  b.component_name= a.component_name
and  b.servicename = @service_name
and  b.method_name = a.method_name
and  b.parametername = a.parametername)
and  not exists (  select  's'
from de_fw_des_di_parameter c (nolock)
where  c.customer_name = a.customer_name
and  c.project_name = a.project_name
and  c.process_name = a.process_name
and  c.component_name= a.component_name
and  c.methodid  = a.methodid
and  c.method_name = a.method_name
and  c.parametername = a.parametername)

delete  a
from de_fw_des_br_logical_parameter a
where  customer_name   = @customer_name
and  project_name   = @project_name
and  process_name   =  @process_name
and     component_name   =  @component_name
and  method_name    = @method_name
and  logicalparametername = @parameter_name_tmp
and  not exists (  select  's'
from de_fw_des_di_parameter c (nolock)
where  c.customer_name = a.customer_name
and  c.project_name = a.project_name
and  c.process_name = a.process_name
and  c.component_name= a.component_name
and  c.methodid  = a.methodid
and  c.method_name = a.method_name
and  c.parametername = a.logicalparametername)

delete  a
from de_fw_des_service_dataitem a
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  servicename  = @service_name
and  not exists (
select  's'
from   de_fw_des_di_parameter b (nolock)
where  b.customer_name = a.customer_name
and  b.project_name = a.project_name
and  b.process_name = a.process_name
and  b.component_name= a.component_name
and  b.servicename = a.servicename
and  b.segmentname = a.segmentname
and  b.dataitemname = a.dataitemname )

delete a
from de_fw_des_service_segment a
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  servicename  = @service_name
and  not exists (
select  's'
from de_fw_des_service_dataitem b (nolock)
where  b.customer_name = a.customer_name
and  b.project_name = a.project_name
and  b.process_name = a.process_name
and  b.component_name= a.component_name
and  b.servicename = a.servicename
and  b.segmentname = a.segmentname )
end --else end
end --while end
close curTasks
deallocate curTasks
--------------------------------------------------------------------------------------------
--UPDATING THE METHOD-ERROR MAPPING
--------------------------------------------------------------------------------------------

declare @req_errorno_tmp   engg_seqno,
@des_errorno_tmp   engg_seqno,
@sp_errorno_tmp    engg_seqno,
@req_error_desc_tmp   engg_error_message,
@des_error_desc_tmp   engg_error_message,
@sp_error_desc_tmp   engg_error_message,
@severity_tmp    engg_seqno,
@detaileddesc_tmp   engg_error_message,
@correctiveaction_tmp  engg_error_message,
@map_flag_tmp    engg_flag,
@error_context    engg_name

declare curErr cursor for
select req_errorno,des_errorno,sp_errorno,req_error_desc,
des_error_desc,sp_error_desc,severity,detaileddesc,
-- code changed by Yuvaraj A on 25/06/06
correctiveaction,map_flag, error_context

from  de_refine_method_error_map (nolock)
where  customer_name  =  @customer_name
and  project_name  =  @project_name
and  process_name =  @process_name
and  component_name =  @component_name
and  activity_name = @activity_name
and  ui_name   = @ui_name
and  method_name  = @method_name
and  flowbr_name  = @flowbr_name

open curErr

while 1=1
begin

fetch next from curErr
into  @req_errorno_tmp,  @des_errorno_tmp,
@sp_errorno_tmp,  @req_error_desc_tmp,
@des_error_desc_tmp, @sp_error_desc_tmp,
@severity_tmp,   @detaileddesc_tmp,
-- code changed by Yuvaraj A on 25/06/06
@correctiveaction_tmp, @map_flag_tmp,   @error_context


if @@fetch_status <> 0
break

if @map_flag_tmp = '1'
begin

if exists(  select 'X'
from de_fw_des_brerror (nolock)
where customer_name = @customer_name
and  project_name = @project_name
and  method_name  = @method_name
and  methodid  = @method_id
and  errorid   = @des_errorno_tmp
)
begin
--- Code modified by Saravanan on 12/04/2005 for Bug Id :: PNR2.0_1925 -
--- Process Name & Component Name added
-- code changed by Yuvaraj A on 25/06/06
update  de_fw_des_brerror
set  sperrorcode  = @sp_errorno_tmp,
error_context =   @error_context
where customer_name = @customer_name
and  project_name  =  @project_name
and  process_name =  @process_name
and  component_name =  @component_name
and  method_name  = @method_name
and  methodid  = @method_id
--Modified by Shriram V on 09/03/04 for bug Id :DEENG203SYS_000528
and  errorid   = @des_errorno_tmp
--Modified by Shriram V on 09/03/04 for bug Id :DEENG203SYS_000528
end
else
begin
-- code changed by Yuvaraj A on 25/06/06
insert into de_fw_des_brerror
(methodid,errorid,upduser,updtime,customer_name,project_name,method_name,
timestamp,createdby,createddate,sperrorcode, process_name, component_name, error_context,ecrno)--chan
values
(@method_id,@des_errorno_tmp,@ctxt_user,@getdate,@customer_name,@project_name,@method_name,
1, @ctxt_user,@getdate,@sp_errorno_tmp, @process_name, @component_name, @error_context,@engg_ico_no)
--- Code modified by Saravanan on 12/04/2005 for Bug Id :: PNR2.0_1925 -
--- Process Name & Component Name added
end

--    insert into de_fw_des_error
--    (componentname,errorid,displaytype,errorsource,errormessage,defaultseverity,upduser,
--    updtime,customer_name,project_name,process_name,timestamp,createdby,createddate,
--    reqerror,detaileddesc,defaultcorrectiveaction)
--    values
--    (@customer_name,@des_errorno_tmp,'Message Box',0,@des_error_desc_tmp,@severity_tmp,@ctxt_user,
--    @getdate,@customer_name,@project_name,@process_name,1,@ctxt_user,@getdate,
--    @req_errorno_tmp,@detaileddesc_tmp,@correctiveaction_tmp
--
--
update  de_fw_des_error
set  errormessage    =  @des_error_desc_tmp,
defaultseverity   =  @severity_tmp,
detaileddesc    =  @detaileddesc_tmp,
defaultcorrectiveaction =  @correctiveaction_tmp
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  componentname = @component_name
and  reqerror  = @req_errorno_tmp
--Modified by Shriram V on 09/03/04 for bug Id :DEENG203SYS_000528
and  errorid   = @des_errorno_tmp
--Modified by Shriram V on 09/03/04 for bug Id :DEENG203SYS_000528

-- code modified by Ganesh on 16/12/04 for the bugid ::: DRENG203SYS_000098
-- To Get the Place of the error which is updated.
While   ISNULL(CHARINDEX('<', @des_error_desc_tmp, @StartPos), 0) > 0
Begin
Select @StartPos = CHARINDEX('<', @des_error_desc_tmp, @StartPos) + 1

Select @EndPos   = CHARINDEX('>', @des_error_desc_tmp, @StartPos)

Select @StartPos1 = CHARINDEX('<', @des_error_desc_tmp, @StartPos)

if @StartPos1 = 0 or @StartPos1 > @EndPos
begin
If @EndPos < @StartPos
Break
if @EndPos1 < @StartPos
begin
Select @PlaceHolder = SUBSTRING(@des_error_desc_tmp, @StartPos, @EndPos - @StartPos)

select @PlaceHolder = replace(@PlaceHolder,' ','$1$')

if  @PlaceHolder not like '%$1$%' and isnull(@PlaceHolder, '') <> '' --and @PlaceHolder
begin
if not exists ( select 'x'
from  de_fw_des_error_placeholder(nolock)
where  errorid   = @des_errorno_tmp
and   placeholdername = @placeholder
and   customer_name   = @customer_name
and   project_name  = @project_name
and   process_name  = @process_name
and   component_name  = @component_name)
begin
Exec  de_fw_des_error_placeholder_sp_ins
@CTXT_LANGUAGE, @ctxt_ouinstance, @CTXT_SERVICE,
@CTXT_USER, @des_errorno_tmp, @PlaceHolder,
@CTXT_USER, @getdate, @customer_name,
@project_name, @component_name,@process_name,1,@engg_ico_no, @M_ERRORID--chan
end
end

end
end
End

-- code added by Ganesh for the bugid ::PNR2.0_1969 on 13/4/05
-- PL Text in the place holder is to be added.
Select  @StartPos = 1
select @EndPos1  = 0
select @StartPos1 = 250

While   ISNULL(CHARINDEX('^', @des_error_desc_tmp, @StartPos), 0) > 0
Begin
Select @StartPos = CHARINDEX('^', @des_error_desc_tmp, @StartPos) + 1

Select @EndPos   = CHARINDEX('!', @des_error_desc_tmp, @StartPos)

Select @StartPos1 = CHARINDEX('^', @des_error_desc_tmp, @StartPos)

if @StartPos1 = 0 or @StartPos1 > @EndPos
begin
If @EndPos < @StartPos
Break
if @EndPos1 < @StartPos
begin

Select @PlaceHolder = SUBSTRING(@des_error_desc_tmp, @StartPos, @EndPos - @StartPos)

select @PlaceHolder = replace(@PlaceHolder,' ','$1$')

if  @PlaceHolder not like '%$1$%' and isnull(@PlaceHolder, '') <> ''
begin
if not exists ( select 'x'
from  de_fw_des_error_placeholder(nolock)
where  errorid   = @des_errorno_tmp
and   placeholdername = @placeholder
and   customer_name   = @customer_name
and   project_name  = @project_name
and   process_name  = @process_name
and   component_name  = @component_name)
begin
Exec  de_fw_des_error_placeholder_sp_ins
@CTXT_LANGUAGE, @ctxt_ouinstance, @CTXT_SERVICE,
@CTXT_USER, @des_errorno_tmp, @PlaceHolder,
@CTXT_USER, @getdate, @customer_name,
@project_name, @component_name,@process_name,1,@engg_ico_no, @M_ERRORID--chan
end
end
end
end
end


end
else
begin

delete  de_fw_des_be_placeholder
where customer_name = @customer_name
and  project_name = @process_name
and  process_name = @process_name
and  component_name = @component_name
and  method_name  = @method_name
and  errorid   = @des_errorno_tmp

delete   de_fw_des_di_placeholder
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  servicename  = @service_name
and  method_name  = @method_name
and  errorid   = @des_errorno_tmp

delete de_fw_des_brerror
where customer_name = @customer_name
and  project_name = @process_name
and  process_name = @process_name
and  component_name = @component_name
and  method_name  = @method_name
and  errorid   = @des_errorno_tmp

delete from de_fw_des_corr_action_local_info
where  customer_name = @customer_name
and  project_name = @project_name
and  errorid   = @des_errorno_tmp

delete  from de_fw_des_context
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  errorid   = @des_errorno_tmp

delete from de_fw_des_err_det_local_info
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  errorid   = @des_errorno_tmp

delete from de_fw_des_error_placeholder
where  customer_name = @customer_name
and  project_name = @project_name
and  process_name = @process_name
and  component_name = @component_name
and  errorid   = @des_errorno_tmp

-- code modified by Ganesh for the callid :: Platform_2.0.3.X_471 on 5/9/05

delete de_fw_des_error
where  customer_name =  @customer_name
and  project_name =  @project_name
and  process_name =  @process_name
and  componentname =  @component_name
and  reqerror  =  @req_errorno_tmp
and  errorid   = @des_errorno_tmp


end

end

close curErr
deallocate curErr

---------------------------------------------------------------------------------------------
--     UPDATE METHOD DOCUMENTATION
--------------------------------------------------------------------------------------------

update de_fw_des_br_documentation
set  doctext   = method_doc
from de_fw_des_br_documentation A(nolock),
de_method_doc B(nolock)
where  B.customer_name  =  @customer_name
and  B.project_name   =  @project_name
and  B.process_name  = @process_name
and  B.component_name =  @component_name
and  B.activity_name  = @activity_name
and  B.ui_name   = @ui_name
and  B.method_name   = @method_name
and  B.flowbr_name  = @flowbr_name
and  A.customer_name  =  B.customer_name
and  A.project_name   =  B.project_name
and  A.process_name  = B.process_name
and  A.component_name =  B.component_name
and  A.method_name  = B.method_name



set nocount off

end

/* Modified by  : Shriram V              */
/* Date   : 09-Mar-04              */
/* Bug Id       : DEENG203SYS_000528           */
/* Description  : Customer JNJ,Project GAIT, Engineering Change Request # MntCompECR Update Service Tab If u press Update Services button after selecting all the rows in the multiline,Follwing error is being thrown.Violation of PRIMARY KEY constraint 'de
_
fw_des_brerror_pkey'. Cannot insert duplicate key in object 'de_fw_des_brerror'. */

/*http://ramcovm156/rvw */

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_update_refine_methods' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_update_refine_methods TO PUBLIC
END
GO

