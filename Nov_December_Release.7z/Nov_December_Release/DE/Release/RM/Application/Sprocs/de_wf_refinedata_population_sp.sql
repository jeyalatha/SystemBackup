IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_wf_refinedata_population_sp' AND TYPE = 'P')
BEGIN
  DROP PROC de_wf_refinedata_population_sp
END
GO
/********************************************************************************/
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 20-01-05 (Patch Release 3)    */
/********************************************************************************/
/* procedure      de_refinedata_population_sp                                   */
/* description                                                                  */
/********************************************************************************/
/* project        de                                                       		*/
/* version                                                                      */
/********************************************************************************/
/* referenced                                                                   */
/* tables                                                                       */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author            Balaji S                                    				*/
/* date              Populating refine tables for work flow						*/
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230	*/
/********************************************************************************/
CREATE procedure de_wf_refinedata_population_sp
	@ctxt_language_in             engg_ctxt_language,
	@ctxt_ouinstance_in           engg_ctxt_ouinstance,
	@ctxt_service_in              engg_ctxt_service,
	@ctxt_user_in                 engg_ctxt_user,
	@engg_activity_in             engg_description,
	@engg_component_in            engg_description,
	@engg_customer_name_in        engg_name,
	@engg_process_in        	  engg_description,
	@engg_project_name_in         engg_name,
	@engg_req_no_in               engg_name,
	@engg_ui_name_in              engg_description,
	@engg_page_in		      	  engg_description,
	@engg_task_in		      	  engg_name,
	@engg_service_in	      	  engg_name,
	@m_errorid                    int output
as
begin
	set nocount on

	declare @ps_name_tmp		engg_name,
			@mt_name_tmp		engg_name,
			@seq_no				engg_sequence_no,
			@param_name_tmp		engg_name,
			@flowbr_name_tmp	engg_name,
			@mt_id				engg_id_no,
			@spname				engg_name, 
			@accessdatabase_tmp	engg_sequence_no,
			@operationtype_tmp	engg_sequence_no,
			@isintegbr_tmp		engg_sequence_no,
			@systemgenerated_tmp engg_sequence_no,
			@getdate			engg_date,
			@guid_tmp			engg_guid 

	select @getdate	= getdate(),
			@guid_tmp = newid()

	update 	a
	set		include_flag	=	1,
			createddate	 =	getdate(),
			modifieddate =  getdate()
	from 	de_refine_process_section 		a (nolock),
			de_fw_des_processsection_br_is	b (nolock)
	where 	a.customer_name		=	@engg_customer_name_in
	and   	a.project_name		=	@engg_project_name_in
	and   	a.process_name		=	@engg_process_in
	and   	a.component_name	=	@engg_component_in  
	and		a.activity_name		= 	@engg_activity_in
	and		a.ui_name			= 	@engg_ui_name_in
	and   	a.service_name		=	@engg_service_in
	and		a.ps_name			= 	b.sectionname
	and	 	a.customer_name		=	b.customer_name		
	and   	a.project_name		=	b.project_name		
	and   	a.process_name		=	b.process_name		
	and   	a.component_name	=	b.component_name
	and   	a.service_name		=	b.servicename


	update 	a
	set		include_flag	=	0,
			createddate	 =	getdate(),
			modifieddate =  getdate()
	from 	de_refine_process_section a (nolock)
	where 	a.customer_name		=	@engg_customer_name_in
	and   	a.project_name		=	@engg_project_name_in
	and   	a.process_name		=	@engg_process_in
	and   	a.component_name	=	@engg_component_in  
	and		a.activity_name		= 	@engg_activity_in
	and		a.ui_name			= 	@engg_ui_name_in
	and   	a.service_name		=	@engg_service_in
	and		a.ps_name	not in 	
			(select b.sectionname
			from	de_fw_des_processsection_br_is b (nolock)
			where 	a.customer_name		=	b.customer_name		
			and   	a.project_name		=	b.project_name		
			and   	a.process_name		=	b.process_name		
			and   	a.component_name	=	b.component_name
			and   	a.service_name		=	b.servicename)

	declare ref_ps cursor 
	for select sectionname
	from  de_fw_des_processsection (nolock)
	where customer_name		=	@engg_customer_name_in
	and   project_name		=	@engg_project_name_in
	and   process_name		=	@engg_process_in
	and   component_name	=	@engg_component_in  
	and   servicename		=	@engg_service_in

	open  ref_ps

	while 1 = 1

	begin

			fetch next from ref_ps into @ps_name_tmp

			if @@fetch_status <> 0 break

			if not exists ( select 'X' 
						from 	de_refine_process_section(nolock)
						where customer_name		=	@engg_customer_name_in
						and   project_name		=	@engg_project_name_in
						and   process_name		=	@engg_process_in
						and   component_name	=	@engg_component_in  
						and	  activity_name		=	@engg_activity_in
						and	  ui_name			=	@engg_ui_name_in
						and	  service_name		=	@engg_service_in
						and	  ps_name			=	@ps_name_tmp 	
					)
			begin
							

					insert into de_refine_process_section
					(customer_name	,project_name	,process_name,	component_name,
					activity_name	,ui_name	,service_name,	ps_name,
					sequence_no	,update_flag	,refps_sysid,   timestamp,
					createdby	,createddate,	modifiedby,	modifieddate,include_flag)
					select @engg_customer_name_in,@engg_project_name_in,@engg_process_in,@engg_component_in ,
					@engg_activity_in,@engg_ui_name_in,@engg_service_in,sectionname,
					sequenceno,1,newid(),0,
					@ctxt_user_in,@getdate,@ctxt_user_in,@getdate,1	
					from de_fw_des_processsection(nolock)
					where servicename 	= 	@engg_service_in
					and customer_name 	= 	@engg_customer_name_in
					and project_name  	= 	@engg_project_name_in	
					and process_name  	= 	@engg_process_in
					and component_name 	=	@engg_component_in
					and	servicename		=	@engg_service_in
					and	sectionname		=	@ps_name_tmp
			end

	end

	close ref_ps

	deallocate ref_ps



	update 	a
	set		include_flag	=	0,
			createddate	 =	getdate(),
			modifieddate =  getdate()
	from 	de_refine_methods a (nolock)
	where 	a.customer_name		=	@engg_customer_name_in
	and   	a.project_name		=	@engg_project_name_in
	and   	a.process_name		=	@engg_process_in
	and   	a.component_name	=	@engg_component_in  
	and		a.activity_name		= 	@engg_activity_in
	and		a.ui_name			= 	@engg_ui_name_in
	and   	a.service_name		=	@engg_service_in
	and		a.method_name		not in 	
			(select b.method_name
			from	de_fw_des_processsection_br_is b (nolock)
			where 	a.customer_name		=	b.customer_name		
			and   	a.project_name		=	b.project_name		
			and   	a.process_name		=	b.process_name		
			and   	a.component_name	=	b.component_name
			and   	a.service_name		=	b.servicename
			and		a.ps_name			=	b.sectionname)

	declare ref_met  cursor 
	for 
	select 	bs.methodname,br.sectionname,br.sequenceno,sp.methodid,sp.spname,
			accessesdatabase,operationtype,isintegbr,systemgenerated
	from 	de_fw_des_businessrule 			bs(nolock),
			de_fw_des_processsection_br_is 	br(nolock),
			de_fw_des_sp					sp(nolock)
	where 	br.customer_name	=	bs.customer_name
	and  	br.project_name		=	bs.project_name
	and  	br.process_name		=	bs.process_name
	and  	br.component_name	=	bs.component_name
	and  	br.method_name		=	bs.methodname
	and		br.methodid			= 	bs.methodid
	and  	br.servicename 		= 	@engg_service_in
	and 	br.customer_name 	= 	@engg_customer_name_in
	and 	br.project_name  	= 	@engg_project_name_in	
	and 	br.process_name  	= 	@engg_process_in
	and 	br.component_name 	= 	@engg_component_in
	and		br.isbr				=	1
	AND		SP.customer_name 	=	BS.customer_name
	AND  	SP.project_name 	=  	bs.project_name 
	AND  	SP.process_name 	= 	bs.process_name 
	AND  	SP.component_name 	=	bs.component_name 
	AND  	SP.methodid			= 	bs.methodid

	open ref_met

	while 1 = 1
	begin

		fetch next from ref_met into  @mt_name_tmp,@ps_name_tmp,@seq_no,@mt_id,@spname,
			@accessdatabase_tmp,@operationtype_tmp,@isintegbr_tmp,@systemgenerated_tmp


		 if @@fetch_status <> 0 break

		 --Code Modified For BugId : PNR2.0_7749
		 if not exists ( select 'X' 
					 from 	de_refine_methods(nolock)
					where 	customer_name 	= 	@engg_customer_name_in
					and   	project_name  	= 	@engg_project_name_in	
					and 	process_name  	= 	@engg_process_in
					and 	component_name 	= 	@engg_component_in
					and 	activity_name	= 	@engg_activity_in
					and 	ui_name			= 	@engg_ui_name_in
					and		ps_name			= 	@ps_name_tmp
					and		service_name 	= 	@engg_service_in
					and		method_name		=	@mt_name_tmp
		  )
		 BEGIN
-- 				update 	de_refine_methods
-- 				set		sequence_no	 	= @seq_no,
-- -- 						spname		 	= @spname,
-- 						createddate	 	= @getdate,
-- 						modifieddate 	= @getdate,
-- 						accessdatabase	= @accessdatabase_tmp ,
-- 						operationtype	= @operationtype_tmp,
-- 						isintegbr		= @isintegbr_tmp,
-- 						systemgenerated = @systemgenerated_tmp
-- 				where 	customer_name 	= @engg_customer_name_in
-- 				and   	project_name  	= @engg_project_name_in	
-- 				and 	process_name  	= @engg_process_in
-- 				and 	component_name 	= @engg_component_in
-- 				and 	activity_name	= @engg_activity_in
-- 				and 	ui_name			= @engg_ui_name_in
-- 				and		ps_name			= @ps_name_tmp
-- 				and		service_name 	= @engg_service_in
-- 				and		method_name		= @mt_name_tmp
-- 		 end
-- 		 else
-- 		 begin
		
				
				insert into de_refine_methods
				(customer_name,	project_name,	process_name,
				component_name,	activity_name,	ui_name,	service_name,
				ps_name,	method_name,	sequence_no,	update_flag,
				refmet_sysid,	timestamp,	createdby,	createddate,
				modifiedby,	modifieddate,	include_flag, spname,accessdatabase,operationtype,
				isintegbr,systemgenerated)

				select @engg_customer_name_in,@engg_project_name_in,@engg_process_in,
				@engg_component_in,@engg_activity_in,@engg_ui_name_in,@engg_service_in,
				br.sectionname,bs.methodname,sequenceno,1,newid(),0,@ctxt_user_in,getdate(),
				@ctxt_user_in,getdate(),1,sp.spname,accessesdatabase,operationtype,isintegbr,systemgenerated

				from 	de_fw_des_businessrule 			bs(nolock),
						de_fw_des_processsection_br_is 	br(nolock),
						de_fw_des_sp					sp(nolock)				
				where br.customer_name	=	bs.customer_name
				and  br.project_name	=	bs.project_name
				and  br.process_name	=	bs.process_name
				and  br.component_name	=	bs.component_name
				and  br.method_name		=	bs.methodname
				and  br.customer_name	=	sp.customer_name
				and  br.project_name	=	sp.project_name
				and  br.process_name	=	sp.process_name
				and  br.component_name	=	sp.component_name
				and  br.method_name		=	sp.method_name
				and	 br.methodid		=	sp.methodid
				and  br.servicename 	= 	@engg_service_in
				and  br.customer_name 	= 	@engg_customer_name_in
				and  br.project_name  	= 	@engg_project_name_in	
				and  br.process_name  	= 	@engg_process_in
				and  br.component_name 	= 	@engg_component_in
				and	 bs.methodname		=	@mt_name_tmp
				and	 br.sectionname		=	@ps_name_tmp
				and	 br.isbr			=	1
				and	 sp.methodid		=	@mt_id	

		 end
	end

	close ref_met
	deallocate ref_met


	declare ref_met_integ  cursor 
	for 
	select 	br.integservicename,br.sectionname,br.sequenceno,'','',
			'','','',''
	from 	de_fw_des_processsection_br_is 	br(nolock)
	where 	br.servicename 		= 	@engg_service_in
	and 	br.customer_name 	= 	@engg_customer_name_in
	and 	br.project_name  	= 	@engg_project_name_in	
	and 	br.process_name  	= 	@engg_process_in
	and 	br.component_name 	= 	@engg_component_in
	and		br.isbr				=	0

	open ref_met_integ

	while 1 = 1
	begin

		fetch next from ref_met_integ into  @mt_name_tmp,@ps_name_tmp,@seq_no,@mt_id,@spname,
			@accessdatabase_tmp,@operationtype_tmp,@isintegbr_tmp,@systemgenerated_tmp


		 if @@fetch_status <> 0 break

		 --Code Modified For BugId : PNR2.0_7749
		 if not exists ( select 'X' 
					 from 	de_refine_methods(nolock)
					where 	customer_name 	= 	@engg_customer_name_in
					and   	project_name  	= 	@engg_project_name_in	
					and 	process_name  	= 	@engg_process_in
					and 	component_name 	= 	@engg_component_in
					and 	activity_name	= 	@engg_activity_in
					and 	ui_name			= 	@engg_ui_name_in
					and		ps_name			= 	@ps_name_tmp
					and		service_name 	= 	@engg_service_in
					and		method_name		=	@mt_name_tmp
		  )
		 BEGIN
-- 				update 	de_refine_methods
-- 				set		sequence_no	 	= @seq_no,
-- -- 						spname		 	= @spname,
-- 						createddate	 	= @getdate,
-- 						modifieddate 	= @getdate,
-- 						accessdatabase	= @accessdatabase_tmp ,
-- 						operationtype	= @operationtype_tmp,
-- 						isintegbr		= @isintegbr_tmp,
-- 						systemgenerated = @systemgenerated_tmp
-- 				where 	customer_name 	= @engg_customer_name_in
-- 				and   	project_name  	= @engg_project_name_in	
-- 				and 	process_name  	= @engg_process_in
-- 				and 	component_name 	= @engg_component_in
-- 				and 	activity_name	= @engg_activity_in
-- 				and 	ui_name			= @engg_ui_name_in
-- 				and		ps_name			= @ps_name_tmp
-- 				and		service_name 	= @engg_service_in
-- 				and		method_name		= @mt_name_tmp
-- 		 end
-- 		 else
-- 		 begin
		
				
				insert into de_refine_methods
				(customer_name,	project_name,	process_name,
				component_name,	activity_name,	ui_name,	service_name,
				ps_name,	method_name,	sequence_no,	update_flag,
				refmet_sysid,	timestamp,	createdby,	createddate,
				modifiedby,	modifieddate,	include_flag, spname,accessdatabase,operationtype,
				isintegbr,systemgenerated)

				select @engg_customer_name_in,@engg_project_name_in,@engg_process_in,
				@engg_component_in,@engg_activity_in,@engg_ui_name_in,@engg_service_in,
				br.sectionname,br.integservicename,sequenceno,1,newid(),0,@ctxt_user_in,getdate(),
				@ctxt_user_in,getdate(),1,'','','',1,''
				from 	de_fw_des_processsection_br_is 	br(nolock)
				where   br.servicename 	= 	@engg_service_in
				and  br.customer_name 	= 	@engg_customer_name_in
				and  br.project_name  	= 	@engg_project_name_in	
				and  br.process_name  	= 	@engg_process_in
				and  br.component_name 	= 	@engg_component_in
				and	 br.sectionname		=	@ps_name_tmp
				and	 br.isbr			=	0
				and	 br.integservicename		=	@mt_name_tmp
-- 
-- 				insert into de_is_dataitem_map
-- 				(	customer_name,			project_name,			process_name,			component_name,
-- 					activity_name,			ui_name,				service_name,			ps_name,
-- 					is_name,				called_segment_name,	called_dataitem_name,	calling_segment_name,
-- 					calling_dataitem_name,	update_flag,			isdi_sysid,				timestamp,
-- 					createdby,				createddate,			modifiedby,				modifieddate)
-- 				select	
-- 					customer_name,			project_name,			process_name,			component_name,
-- 					'',						'',						callingservicename,		sectionname,
-- 					integservicename,		integsegment,			integdataitem,			callingsegment,			
-- 					callingdataitem,		'1',					@guid_tmp,				'1',
-- 					@ctxt_user_in,				@getdate,			@ctxt_user_in,				@getdate
-- 				from	de_fw_des_integ_serv_map	a(nolock)
-- 				where	a.customer_name			=	@engg_customer_name_in
-- 				and		a.project_name			=	@engg_project_name_in
-- 				and		a.process_name			=	@engg_process_in
-- 				and		a.component_name		=	@engg_component_in
-- 				and		a.callingservicename	=	@engg_service_in
-- 				and		a.sectionname			=	@ps_name_tmp
-- 				and		a.integservicename		=	@mt_name_tmp
-- 				and		not exists	(	select	'x'
-- 										from	de_is_dataitem_map	b(nolock)
-- 										where	a.customer_name		=	b.customer_name
-- 										and		a.project_name		=	b.project_name
-- 										and		a.process_name		=	b.process_name
-- 										and		a.component_name	=	b.component_name
-- 										and		a.callingservicename=	b.service_name
-- 										and		a.sectionname		=	b.ps_name
-- 										and		a.integsegment		=   b.called_segment_name
-- 										and		a.integdataitem		=	b.called_dataitem_name)
-- 

				
		 end
	end

	close ref_met_integ
	deallocate ref_met_integ


		
	delete from 
	de_method_message_map
	where service_name 	= @engg_service_in
	and customer_name 	= @engg_customer_name_in
	and project_name  	= @engg_project_name_in	
	and process_name  	= @engg_process_in
	and component_name 	= @engg_component_in
	and activity_name	= @engg_activity_in
	and ui_name			= @engg_ui_name_in

	select distinct er.customer_name 'customer_name',er.project_name 'project_name', er.process_name 'process_name',
	er.component_name 'component_name', er.activity_name 'activity_name', er.ui_name 'ui_name', @engg_service_in 'Service', er.flowbr_name 'flowbr_name', method_name 'method_name',
	message_id 'message_id', de_err.error_descr 'error_descr1',1 'Update_Flag','A' 'New_ID',0 'TimeStamp',@ctxt_user_in 'User1',
	@getdate 'Date1',@ctxt_user_in 'User2',@getdate 'Date2',message_id 'message_id1',de_err.error_descr 'error_descr2',
	msg_severity 'msg_severity',de_err.error_descr 'error_descr3',0 'Corrective_Action',0 'Map_Flag'
	into #de_method_message_map
	from 
	de_flowbr_br_error er(nolock),de_flowbr_method_map mp(nolock),
	de_message	de_err (nolock)
	where er.customer_name	= mp.customer_name
	and er.project_name     = mp.project_name
	and er.process_name	= mp.process_name
	and er.component_name	= mp.component_name
	and er.activity_name	= mp.activity_name
	and er.ui_name		= mp.ui_name
-- 	and	er.page_bt_synonym	= mp.page_bt_synonym
	and er.page_bt_synonym	= @engg_page_in
	and er.task_name	= @engg_task_in	
	and er.flowbr_name 	= mp.flowbr_name

	and	de_err.customer_name	= mp.customer_name
	and de_err.project_name     = mp.project_name
	and de_err.process_name	= mp.process_name
	and de_err.component_name	= mp.component_name
	and	er.message_id			= de_err.error_id

	and mp.service_name 	= @engg_service_in
	and mp.customer_name 	= @engg_customer_name_in
	and mp.project_name  	= @engg_project_name_in	
	and mp.process_name  	= @engg_process_in
	and mp.component_name 	= @engg_component_in
	and mp.activity_name	= @engg_activity_in
	and mp.ui_name		= @engg_ui_name_in
	and	not exists(	Select	'A'
					from	de_method_message_map	mmp (nolock)
					where	mmp.customer_name		= er.customer_name
					and		project_name		= er.project_name
					and		process_name		= er.process_name
					and		component_name		= er.component_name
					and		activity_name		= er.activity_name
					and		ui_name				= er.ui_name
					and		service_name		= @engg_service_in
					and		flowbr_name			= er.flowbr_name
					and		method_name			= mp.method_name
					and		message_id			= er.message_id)


	insert into de_method_message_map
	(customer_name,project_name,process_name,
	component_name,activity_name,ui_name,service_name,flowbr_name,method_name,
	message_id,message_descr,update_flag,metmsg_sysid,timestamp,createdby,
	createddate,modifiedby,modifieddate,sp_message_no,sp_message_descr,
	message_severity,detail_description,corrective_action,map_flag)
	select customer_name,project_name, process_name,
	component_name, activity_name, ui_name, Service, flowbr_name, method_name,
	message_id, error_descr1,Update_Flag,newid(),0,User1,
	Date1,User2,Date2,message_id,error_descr2,
	msg_severity,error_descr3,Corrective_Action,Map_Flag
	from #de_method_message_map

	drop table #de_method_message_map

-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - START
-- Process, Component in join added

	update 	a
	set		required_flag	=	0,
			createddate	 =	getdate(),
			modifieddate =  getdate()
	from 	de_refine_parameter a (nolock)
	where 	a.customer_name		=	@engg_customer_name_in
	and   	a.project_name		=	@engg_project_name_in
	and   	a.process_name		=	@engg_process_in
	and   	a.component_name	=	@engg_component_in  
	and		a.activity_name		= 	@engg_activity_in
	and		a.ui_name			= 	@engg_ui_name_in
	and   	a.service_name		=	@engg_service_in
	and		a.parameter_name	not in 	
			(select b.logicalparametername
			from	de_fw_des_br_logical_parameter b (nolock),
					de_fw_des_processsection_br_is c (nolock)
			where 	a.customer_name		=	b.customer_name		
			and   	a.project_name		=	b.project_name		
			and   	a.process_name		=	b.process_name		
			and   	a.component_name	=	b.component_name	
			and		a.method_name		=	b.method_name

			and 	a.customer_name		=	c.customer_name		
			and   	a.project_name		=	c.project_name		
			and   	a.process_name		=	c.process_name		
			and   	a.component_name	=	c.component_name
			and		a.service_name		= 	c.servicename
			and		a.method_name		=	c.method_name

			and 	b.customer_name		=	c.customer_name		
			and   	b.project_name		=	c.project_name		
			and   	b.process_name		=	c.process_name		
			and   	b.component_name	=	c.component_name
			and		b.methodid			=	c.methodid
			and		b.method_name		=	c.method_name)
-- Code modified by Saravanan on 01/06/2005 for PNR2.0_2672 - END
-- Process, Component in join added


	declare di_param cursor 
	for select A.sectionname, A.method_name,A.parametername,B.logicalparamseqno
	from  de_fw_des_di_parameter A (nolock),
		  de_fw_des_br_logical_parameter B(nolock)
	where A.customer_name		=	@engg_customer_name_in
	and   A.project_name		=	@engg_project_name_in
	and   A.process_name		=	@engg_process_in
	and   A.component_name		=	@engg_component_in  
	and   A.servicename			=	@engg_service_in
	and	  A.customer_name		=	B.customer_name
	and   A.project_name		=	B.project_name		
 	and   A.process_name		=	B.process_name		
 	and   A.component_name		=	B.component_name		
	and   A.methodid			=	B.methodid			
	and	  A.parametername		=	B.logicalparametername

	open di_param

	while 	1 = 1
	begin
	
			fetch next from di_param
			into 	@ps_name_tmp,@mt_name_tmp,@param_name_tmp,@seq_no

			if @@fetch_status <> 0	Break

			select	@flowbr_name_tmp	=	flowbr_name
			from	de_flowbr_method_map A(nolock)
			where A.customer_name		=	@engg_customer_name_in
			and   A.project_name		=	@engg_project_name_in
			and   A.process_name		=	@engg_process_in
			and   A.component_name		=	@engg_component_in  
			and	  A.activity_name		= 	@engg_activity_in
			and	  A.ui_name				= 	@engg_ui_name_in
			and   A.service_name		=	@engg_service_in
			and	  A.method_name			=	@mt_name_tmp

			if exists ( select 'X'
			from	de_refine_parameter (nolock)	
			where 	customer_name	=	@engg_customer_name_in
			and   	project_name	=	@engg_project_name_in
			and   	process_name	=	@engg_process_in
			and   	component_name	=	@engg_component_in  
			and		activity_name	= 	@engg_activity_in
			and		ui_name			= 	@engg_ui_name_in
			and   	service_name	=	@engg_service_in
			and		method_name		=	@mt_name_tmp
			and		parameter_name	=	@param_name_tmp
		    )
			begin

					update de_refine_parameter
					set		new_seq_no		=	@seq_no,
							modifiedby		=	@ctxt_user_in,	--TECH-75230
							modifieddate	=	getdate()	--TECH-75230
					where 	customer_name	=	@engg_customer_name_in
					and   	project_name	=	@engg_project_name_in
					and   	process_name	=	@engg_process_in
					and   	component_name	=	@engg_component_in  
					and		activity_name	= 	@engg_activity_in
					and		ui_name			= 	@engg_ui_name_in
					and   	service_name	=	@engg_service_in
					and		method_name		=	@mt_name_tmp
					and		parameter_name	=	@param_name_tmp

			end
			else
			begin
					insert into de_refine_parameter
					(customer_name,project_name,process_name,component_name,activity_name,ui_name,
					service_name,flowbr_name,method_name,parameter_name,sequence_no,update_flag,
					refparam_sysid,timestamp,createdby,createddate,new_seq_no,required_flag,
					modifiedby,modifieddate)--TECH-75230
					values
					(@engg_customer_name_in,@engg_project_name_in,@engg_process_in,@engg_component_in,@engg_activity_in,@engg_ui_name_in,
					 @engg_service_in,@flowbr_name_tmp,@mt_name_tmp,@param_name_tmp,@seq_no,1,
					newid(),1,@ctxt_user_in,@getdate,@seq_no,'1',
					@ctxt_user_in,getdate()) --TECH-75230
	
			end

			if not exists ( select 'X' 
			from 	de_method_doc(nolock)
			where 	customer_name 	= 	@engg_customer_name_in
			and   	project_name  	= 	@engg_project_name_in	
			and 	process_name  	= 	@engg_process_in
			and 	component_name 	= 	@engg_component_in
			and 	activity_name	= 	@engg_activity_in
			and 	ui_name			= 	@engg_ui_name_in
			and		service_name 	= 	@engg_service_in
			and		method_name		=	@mt_name_tmp
			)
			begin
			
				insert into de_method_doc
				(customer_name,project_name,process_name,component_name,activity_name,ui_name,
				service_name,flowbr_name,method_name,update_flag,metdoc_sysid,timestamp,
				createdby,createddate,method_doc)
				select 
				@engg_customer_name_in,@engg_project_name_in,@engg_process_in,@engg_component_in,@engg_activity_in,@engg_ui_name_in,
				@engg_service_in,@flowbr_name_tmp,@mt_name_tmp,1,newid(),1,
				@ctxt_user_in,@getdate,doctext
				from	de_fw_des_br_documentation(nolock)
				where 	customer_name 	= 	@engg_customer_name_in
				and   	project_name  	= 	@engg_project_name_in	
				and 	process_name  	= 	@engg_process_in
				and 	component_name 	= 	@engg_component_in
				and		method_name		=	@mt_name_tmp
			
			end


	end

	close	di_param
	deallocate di_param

	delete de_refine_method_error_map
	where 	customer_name 	= 	@engg_customer_name_in
	and 	project_name  	= 	@engg_project_name_in	
	and 	process_name  	= 	@engg_process_in
	and 	component_name 	= 	@engg_component_in
	and		service_name 	= 	@engg_service_in

	--CODE MODIFIED BY DNR ON 29-JUNE-2004 FOR THE BUG ID DEENG203ACC_000081 
	--DE_REFINE_METHOD_ERROR_MAP TABLE IS NOT GETTING POPULATED DUE TO JOIN CONDITION FAIL.	
	
	insert into de_refine_method_error_map 
	(customer_name,project_name,process_name,component_name,activity_name,ui_name,service_name,
	 flowbr_name,method_name,req_errorno,des_errorno,sp_errorno,timestamp,createdby,createddate,modifiedby,
-- code changed by Yuvaraj A on 25/06/06
	 modifieddate,req_error_desc,des_error_desc,sp_error_desc,severity,detaileddesc,correctiveaction,map_flag)
	select  distinct D.customer_name,D.project_name,D.process_name,D.component_name,D.activity_name,D.ui_name,D.service_name,
			-- modified by Ganesh for the bugid :: DEENG203SYS_000326 to avoid insertion of null value in reqerror							
			D.flowbr_name,D.method_name,isnull(C.reqerror,''),C.errorid,B.sperrorcode,1,@ctxt_user_in,@getdate,@ctxt_user_in,
-- code changed by Yuvaraj A on 25/06/06
			@getdate,C.errormessage,C.errormessage,C.errormessage,C.defaultseverity,C.detaileddesc,C.defaultcorrectiveaction,'1'
	from 	de_fw_des_processsection_br_is 	A(nolock),
			de_flowbr_method_map 			D (nolock),
			de_fw_des_brerror				B(nolock),
			de_fw_des_error					C(nolock)
	where 	A.customer_name 	= 	@engg_customer_name_in
	and 	A.project_name  	= 	@engg_project_name_in	
	and 	A.process_name  	= 	@engg_process_in
	and 	A.component_name 	= 	@engg_component_in
	and		A.servicename 		= 	@engg_service_in
	and		A.isbr				=	1
	
	and		A.customer_name		=	D.customer_name
	and  	A.project_name		=	D.project_name
	and 	A.process_name  	= 	D.process_name
	and 	A.component_name 	= 	D.component_name 	
	and		A.servicename		=	D.service_name
	and		A.Method_name		=	D.Method_name

	and		A.customer_name		=	B.customer_name
	and  	A.project_name		=	B.project_name
	and		A.methodid			=	B.methodid
	and		A.method_name		=	B.method_name
	
	and		A.customer_name		=	C.customer_name
	and  	A.project_name		=	C.project_name
	and 	A.process_name  	= 	C.process_name
	and 	A.component_name 	= 	C.componentname 	
		
	and		B.errorid			=	C.errorid


-- code Modified by feroz on 04-Oct-2004 for bug id ::DEENG203SYS_000368

	update 	a
	set 	include_flag = '1'
	from 	de_refine_methods 		a  (nolock),
			de_fw_des_businessrule			bs(nolock),  
			de_fw_des_processsection_br_is 	br(nolock),
			de_fw_des_sp					sp(nolock)
	where 	a.service_name 		= 	@engg_service_in
	and 	a.customer_name 	= 	@engg_customer_name_in
	and 	a.project_name  	= 	@engg_project_name_in	
	and 	a.process_name  	= 	@engg_process_in
	and 	a.component_name 	= 	@engg_component_in
	and 	a.method_name 		=   bs.methodname 
	and		br.customer_name	=	bs.customer_name
	and  	br.project_name		=	bs.project_name
	and  	br.process_name		=	bs.process_name
	and  	br.component_name	=	bs.component_name
	and  	br.method_name		=	bs.methodname
	and  	br.servicename 		= 	a.service_name
	and  	br.customer_name 	= 	a.customer_name
	and  	br.project_name  	= 	a.project_name
	and  	br.process_name  	= 	a.process_name
	and  	br.component_name 	= 	a.component_name
	and	 	br.isbr				=	1

	update 	a
	set 	include_flag = '1'
	from 	de_refine_methods 		a  (nolock),
			de_fw_des_businessrule			bs(nolock),  
			de_fw_des_processsection_br_is 	br(nolock),
			de_fw_des_sp					sp(nolock)
	where 	a.service_name 		= 	@engg_service_in
	and 	a.customer_name 	= 	@engg_customer_name_in
	and 	a.project_name  	= 	@engg_project_name_in	
	and 	a.process_name  	= 	@engg_process_in
	and 	a.component_name 	= 	@engg_component_in
	and 	a.method_name 		=   bs.methodname 
	and		br.customer_name	=	bs.customer_name
	and  	br.project_name		=	bs.project_name
	and  	br.process_name		=	bs.process_name
	and  	br.component_name	=	bs.component_name
	and  	br.method_name		=	bs.methodname
	and  	br.servicename 		= 	a.service_name
	and  	br.customer_name 	= 	a.customer_name
	and  	br.project_name  	= 	a.project_name
	and  	br.process_name  	= 	a.process_name
	and  	br.component_name 	= 	a.component_name
	and	 	br.isbr				=	1
	and		a.ps_name			=	br.sectionname

	update 	a
	set 	include_flag = '0'
	from 	de_refine_methods 		a  (nolock)
	where 	a.service_name 		= 	@engg_service_in
	and 	a.customer_name 	= 	@engg_customer_name_in
	and 	a.project_name  	= 	@engg_project_name_in	
	and 	a.process_name  	= 	@engg_process_in
	and 	a.component_name 	= 	@engg_component_in
	and 	a.method_name not in  	(select bs.methodname 
									 from 	de_fw_des_businessrule 			bs(nolock),
											de_fw_des_processsection_br_is 	br(nolock),
											de_fw_des_sp					sp(nolock)
									where br.customer_name	=	bs.customer_name
									and  br.project_name	=	bs.project_name
									and  br.process_name	=	bs.process_name
									and  br.component_name	=	bs.component_name
									and  br.method_name		=	bs.methodname
									and  br.servicename 	= 	@engg_service_in
									and  br.customer_name 	= 	@engg_customer_name_in
									and  br.project_name  	= 	@engg_project_name_in	
									and  br.process_name  	= 	@engg_process_in
									and  br.component_name 	= 	@engg_component_in
									and	 br.isbr			=	1
									)

	update 	a
	set 	include_flag = '1'
	from 	de_refine_methods		 		a (nolock),
			de_fw_des_processsection_br_is 	br(nolock)
	where 	a.service_name 		= 	@engg_service_in
	and 	a.customer_name 	= 	@engg_customer_name_in
	and 	a.project_name  	= 	@engg_project_name_in	
	and 	a.process_name  	= 	@engg_process_in
	and 	a.component_name 	= 	@engg_component_in
	and  	br.servicename 		= 	a.service_name
	and  	br.customer_name 	= 	a.customer_name
	and  	br.project_name  	= 	a.project_name
	and  	br.process_name  	= 	a.process_name
	and  	br.component_name 	= 	a.component_name
	and	 	br.isbr				=	0
	and		br.integservicename	=   a.method_name
	and		a.ps_name			=   br.sectionname
	

end

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_wf_refinedata_population_sp' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_wf_refinedata_population_sp TO PUBLIC
END
GO




