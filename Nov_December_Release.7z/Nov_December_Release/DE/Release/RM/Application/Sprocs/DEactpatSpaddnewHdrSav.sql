IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DEactpatSpaddnewHdrSav' AND TYPE = 'P')
    BEGIN
        DROP PROC DEactpatSpaddnewHdrSav
    END
GO
/*********************************************************************************/
/* Procedure					: DEactpatSpaddnewHdrSav						 */
/* Description					: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									 */
/* Date							: Nov 16 2022 11:52AM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Created By					: VimalKumar R									 */
/* Date							: 01/12/2022									 */
/* Description					: 												 */
/*********************************************************************************/

Create Procedure DEactpatSpaddnewHdrSav
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@de_engg_cmbtaskt_met      	engg_name, --Input 
	@de_engg_cmbtask_patt      	engg_name, --Input 
	@de_engg_component         	engg_description, --Input 
	@de_engg_customer_name     	engg_name, --Input 
	@de_engg_ecr_no            	engg_name, --Input 
	@de_engg_process_descr     	engg_description, --Input 
	@de_engg_project_name      	engg_name, --Input 
	@de_engg_taskcmb_type      	engg_name, --Input 
	@de_engg_tasktxt_desc      	engg_description, --Input 
	@de_engg_task_docum        	engg_description, --Input 
	@de_engg_tasttxt_docu      	engg_description, --Input 
	@de_engg_txttask_patt_desc 	engg_description, --Input 
	@de_engg_txttask_patt_name 	engg_name, --Input 
	@hdncustomer               	engg_name, --Input 
	@hdnproject                	engg_name, --Input 
	@prj_hdn_ctrl              	plf_hdn_ctrl_bt, --Input 
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = @ctxt_user
	Set @ctxt_service               = @ctxt_service
	Set @de_engg_cmbtaskt_met       = @de_engg_cmbtaskt_met
	Set @de_engg_cmbtask_patt       = @de_engg_cmbtask_patt
	Set @de_engg_component          = @de_engg_component
	Set @de_engg_customer_name      = @de_engg_customer_name
	Set @de_engg_ecr_no             = @de_engg_ecr_no
	Set @de_engg_process_descr      = @de_engg_process_descr
	Set @de_engg_project_name       = @de_engg_project_name
	Set @de_engg_taskcmb_type       = @de_engg_taskcmb_type
	Set @de_engg_tasktxt_desc       = @de_engg_tasktxt_desc
	Set @de_engg_task_docum         = @de_engg_task_docum
	Set @de_engg_tasttxt_docu       = @de_engg_tasttxt_docu
	Set @de_engg_txttask_patt_desc  = @de_engg_txttask_patt_desc
	Set @de_engg_txttask_patt_name  = @de_engg_txttask_patt_name
	Set @hdncustomer                = @hdncustomer
	Set @hdnproject                 = @hdnproject
	Set @prj_hdn_ctrl               = @prj_hdn_ctrl

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @de_engg_cmbtaskt_met = '~#~' 
		Select @de_engg_cmbtaskt_met = null  

	IF @de_engg_cmbtask_patt = '~#~' 
		Select @de_engg_cmbtask_patt = null  

	IF @de_engg_component = '~#~' 
		Select @de_engg_component = null  

	IF @de_engg_customer_name = '~#~' 
		Select @de_engg_customer_name = null  

	IF @de_engg_ecr_no = '~#~' 
		Select @de_engg_ecr_no = null  

	IF @de_engg_process_descr = '~#~' 
		Select @de_engg_process_descr = null  

	IF @de_engg_project_name = '~#~' 
		Select @de_engg_project_name = null  

	IF @de_engg_taskcmb_type = '~#~' 
		Select @de_engg_taskcmb_type = null  

	IF @de_engg_tasktxt_desc = '~#~' 
		Select @de_engg_tasktxt_desc = null  

	IF @de_engg_task_docum = '~#~' 
		Select @de_engg_task_docum = null  

	IF @de_engg_tasttxt_docu = '~#~' 
		Select @de_engg_tasttxt_docu = null  

	IF @de_engg_txttask_patt_desc = '~#~' 
		Select @de_engg_txttask_patt_desc = null  

	IF @de_engg_txttask_patt_name = '~#~' 
		Select @de_engg_txttask_patt_name = null  

	IF @hdncustomer = '~#~' 
		Select @hdncustomer = null  

	IF @hdnproject = '~#~' 
		Select @hdnproject = null  

	IF @prj_hdn_ctrl = '~#~' 
		Select @prj_hdn_ctrl = null  

	DECLARE @engg_process_name engg_name,
		@engg_comp_name engg_name,
		@engg_tt_refonsave engg_flag,
		@engg_tt_valoninit engg_flag,
		@engg_tt_ehmet engg_flag,
		@engg_ttclerph engg_flag,
		@engg_tt_condmlfet engg_flag,
		@engg_tt_clronsave engg_flag,
		@engg_tt_hdrfetreq engg_flag,
		@engg_tt_mlfetreq engg_flag,
		@engg_tt_hdrrefreq engg_flag,
		@engg_tt_hdrchkreq engg_flag,
		@engg_tt_procselrows engg_flag,
		@engg_tt_usrrolemap engg_flag,
		@engg_tt_trnscopereq engg_flag,
		@engg_tt_hdrsavreq engg_flag,
		@engg_tt_mlsavreq engg_flag,
		@engg_tt_cbdefreq engg_flag,
		@engg_tt_phno engg_seqno,
		@engg_tt_datasaving engg_flag,
		@engg_tt_print engg_flag,
		@engg_tt_fprowno engg_flag, -- Code added for PNR2.0_20339 on 17-Dec-2008 by Gowrisankar M
		@msg engg_documentation

	SELECT TOP 1 @engg_process_name = process_name,
		@engg_comp_name = component_name
	FROM ep_ui_req_dtl(NOLOCK)
	WHERE customer_name = @de_engg_customer_name
		AND project_name = @de_engg_project_name
		AND process_descr = @de_engg_process_descr
		AND component_descr = @de_engg_component
	ORDER BY 1, 2

	IF @de_engg_txttask_patt_name IS NULL
	BEGIN
		SELECT @msg = 'Task Name cannot be null'

		EXEC ENGG_ERROR_SP 'DEactpatSpaddnewHdrSav',
			1,
			@msg,
			@CTXT_LANGUAGE,
			@CTXT_OUINSTANCE,
			@CTXT_SERVICE,
			@CTXT_USER,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF dbo.ep_check_spl_char(@de_engg_txttask_patt_name) = 1
	BEGIN
		SELECT @msg = 'Task Name Cannot Contain Specialcharacter '

		EXEC ENGG_ERROR_SP 'DEactpatSpaddnewHdrSav',
			25,
			@msg,
			@CTXT_LANGUAGE,
			@CTXT_OUINSTANCE,
			@CTXT_SERVICE,
			@CTXT_USER,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF @de_engg_txttask_patt_desc IS NULL
	BEGIN
		SELECT @msg = 'Description cannot be Empty'

		EXEC ENGG_ERROR_SP 'DEactpatSpaddnewHdrSav',
			22,
			@msg,
			@CTXT_LANGUAGE,
			@CTXT_OUINSTANCE,
			@CTXT_SERVICE,
			@CTXT_USER,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	IF len(@de_engg_txttask_patt_desc) >= 60
	BEGIN
		SELECT @msg = 'Action Pattern Description  length should not be greater than 60'

		EXEC ENGG_ERROR_SP 'DEactpatSpaddnewHdrSav',
			22,
			@msg,
			@CTXT_LANGUAGE,
			@CTXT_OUINSTANCE,
			@CTXT_SERVICE,
			@CTXT_USER,
			'',
			'',
			'',
			'',
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

	SELECT @engg_tt_refonsave = 'N',
		@engg_tt_valoninit = 'N',
		@engg_tt_ehmet = 'N',
		@engg_ttclerph = 'N',
		@engg_tt_condmlfet = 'N',
		@engg_tt_clronsave = 'N',
		@engg_tt_hdrfetreq = 'N',
		@engg_tt_mlfetreq = 'N',
		@engg_tt_hdrrefreq = 'N',
		@engg_tt_hdrchkreq = 'N',
		@engg_tt_usrrolemap = 'N',
		@engg_tt_trnscopereq = 'N',
		@engg_tt_procselrows = 'N',
		@engg_tt_cbdefreq = 'N',
		@engg_tt_hdrsavreq = 'N',
		@engg_tt_mlsavreq = 'N',
		@engg_tt_phno = 0,
		@engg_tt_datasaving = 'N',
		@engg_tt_print = 'N',
		@engg_tt_fprowno = 'N' 

	IF EXISTS (
			SELECT 'X'
			FROM es_comp_task_type_mst(NOLOCK)
			WHERE customer_name = @de_engg_customer_name
				AND project_name = @de_engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @de_engg_txttask_patt_name
			)
	BEGIN
		RAISERROR (
				' Action Pattern Already Exists',
				16,
				1
				)

		RETURN
	END

	IF EXISTS (
			SELECT 'X'
			FROM es_comp_task_type_mst(NOLOCK)
			WHERE customer_name = @de_engg_customer_name
				AND project_name = @de_engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND default_for = CASE @de_engg_taskcmb_type
					WHEN 'Initialize'
						THEN 'Init'
					WHEN 'DoNotDefault'
						THEN 'DND'
					ELSE @de_engg_taskcmb_type
					END 
				AND default_for <> 'DND'
				AND task_type_name <> @de_engg_txttask_patt_name
			)
	BEGIN
		RAISERROR (
				' Default Already Exists for another action. save as DoNotDefault',
				16,
				1
				)

		RETURN
	END

	IF NOT EXISTS (
			SELECT 'x'
			FROM es_comp_task_type_mst(NOLOCK)
			WHERE customer_name = @de_engg_customer_name
				AND project_name = @de_engg_project_name
				AND process_name = @engg_process_name
				AND component_name = @engg_comp_name
				AND task_type_name = @de_engg_txttask_patt_name
				AND default_for = CASE @de_engg_taskcmb_type
					WHEN 'Initialize'
						THEN 'Init'
					WHEN 'DoNotDefault'
						THEN 'DND'
					ELSE @de_engg_taskcmb_type
					END --@default
				AND default_for <> 'DND'
			)
		SELECT @de_engg_taskcmb_type = CASE @de_engg_taskcmb_type
				WHEN 'DoNotDefault'
					THEN 'dnd'
				WHEN 'Initialize'
					THEN 'Init'
				ELSE @de_engg_taskcmb_type
				END

	BEGIN
		EXEC es_comp_task_type_mst_sp_ins @ctxt_language,
			@ctxt_ouinstance,
			@ctxt_service,
			@ctxt_user,
			@de_engg_customer_name,
			@de_engg_project_name,
			'base',
			@engg_process_name,
			@engg_comp_name,
			@de_engg_txttask_patt_name,
			@de_engg_txttask_patt_desc,
			@de_engg_taskcmb_type, --'DND',
			@engg_tt_refonsave,
			@engg_tt_valoninit,
			@engg_tt_ehmet,
			@engg_ttclerph,
			@engg_tt_condmlfet,
			@engg_tt_clronsave,
			@engg_tt_hdrfetreq,
			@engg_tt_mlfetreq,
			@engg_tt_hdrrefreq,
			@engg_tt_hdrchkreq,
			@engg_tt_procselrows,
			@engg_tt_usrrolemap,
			@engg_tt_trnscopereq,
			@de_engg_task_docum,
			@engg_tt_hdrsavreq,
			@engg_tt_mlsavreq,
			@engg_tt_fprowno, -- Code added for PNR2.0_20339 on 17-Dec-2008 by Gowrisankar M
			@engg_tt_cbdefreq,
			@engg_tt_phno,
			@engg_tt_datasaving,
			@engg_tt_print,
			'N',
			1,
			@m_errorid OUTPUT

		IF @m_errorid <> 0
			RETURN
	END

		EXEC RE_HdrSave_ActionPattern
				@ctxt_ouinstance			=	@ctxt_ouinstance			,
				@ctxt_user					=	@ctxt_user					,
				@ctxt_language				=	@ctxt_language				,
				@ctxt_service				=	@ctxt_service				,
				@engg_cmbtaskt_met			=	@de_engg_cmbtaskt_met		,
				@engg_cmbtask_patt			=	@de_engg_cmbtask_patt		,
				@engg_component				=	@de_engg_component			,
				@engg_customer_name			=	@de_engg_customer_name		,
				@engg_process_descr			=	@de_engg_process_descr		,
				@engg_project_name			=	@de_engg_project_name		,
				@engg_req_no				=	@de_engg_ecr_no				,
				@engg_taskcmb_type			=	@de_engg_taskcmb_type		,
				@engg_tasktxt_desc			=	@de_engg_tasktxt_desc		,
				@engg_task_docum			=	@de_engg_task_docum			,
				@engg_tasttxt_docu			=	@de_engg_tasttxt_docu		,
				@engg_txttask_patt_desc		=	@de_engg_txttask_patt_desc	,
				@engg_txttask_patt_name		=	@de_engg_txttask_patt_name	,
				@guid						=	''							,
				@hidden_control1			=	@prj_hdn_ctrl				,
				@m_errorid					=	@m_errorid	 

		EXEC DE_HdrSave_ActionPattern
				@ctxt_ouinstance			=	@ctxt_ouinstance			,
				@ctxt_user					=	@ctxt_user					,
				@ctxt_language				=	@ctxt_language				,
				@ctxt_service				=	@ctxt_service				,
				@engg_cmbtaskt_met			=	@de_engg_cmbtaskt_met		,
				@engg_cmbtask_patt			=	@de_engg_cmbtask_patt		,
				@engg_component				=	@de_engg_component			,
				@engg_customer_name			=	@de_engg_customer_name		,
				@engg_process_descr			=	@de_engg_process_descr		,
				@engg_project_name			=	@de_engg_project_name		,
				@engg_req_no				=	@de_engg_ecr_no				,
				@engg_taskcmb_type			=	@de_engg_taskcmb_type		,
				@engg_tasktxt_desc			=	@de_engg_tasktxt_desc		,
				@engg_task_docum			=	@de_engg_task_docum			,
				@engg_tasttxt_docu			=	@de_engg_tasttxt_docu		,
				@engg_txttask_patt_desc		=	@de_engg_txttask_patt_desc	,
				@engg_txttask_patt_name		=	@de_engg_txttask_patt_name	,
				@guid						=	''							,
				@hidden_control1			=	@prj_hdn_ctrl				,
				@m_errorid					=	@m_errorid	 
				

	/* 
	-- OutputList
	Select
		null 'fprowno', 
	*/

	Set nocount off
End



IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DEactpatSpaddnewHdrSav' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON DEactpatSpaddnewHdrSav TO PUBLIC
END
GO