IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='DEactpatSpaddnewtsktypspO' AND TYPE = 'P')
    BEGIN
        DROP PROC DEactpatSpaddnewtsktypspO
    END
GO
/*********************************************************************************/
/* Procedure					: DEactpatSpaddnewtsktypspO					 */
/* Description					: 												 */
/*********************************************************************************/
/* Development history			: 												 */
/*********************************************************************************/
/* Author						: ModelExplorer									 */
/* Date							: Nov 16 2022 11:52AM							 */
/*********************************************************************************/
/* Modification History			: 												 */
/*********************************************************************************/
/* Created By					: VimalKumar R									 */
/* Date							: 01/12/2022									 */
/* Description					: 												 */
/*********************************************************************************/

Create Procedure DEactpatSpaddnewtsktypspO
	@ctxt_ouinstance           	ctxt_ouinstance, --Input 
	@ctxt_user                 	ctxt_user, --Input 
	@ctxt_language             	ctxt_language, --Input 
	@ctxt_service              	ctxt_service, --Input 
	@de_engg_cmbtaskt_met      	engg_name, --Input 
	@de_engg_cmbtask_patt      	engg_name, --Input 
	@de_engg_component         	engg_description, --Input 
	@de_engg_customer_name     	engg_name, --Input 
	@de_engg_ecr_no            	engg_name, --Input 
	@de_engg_process_descr     	engg_description, --Input 
	@de_engg_project_name      	engg_name, --Input 
	@de_engg_taskcmb_type      	engg_name, --Input 
	@de_engg_tasktxt_desc      	engg_description, --Input 
	@de_engg_task_docum        	engg_description, --Input 
	@de_engg_tasttxt_docu      	engg_description, --Input 
	@de_engg_txttask_patt_desc 	engg_description, --Input 
	@de_engg_txttask_patt_name 	engg_name, --Input 
	@hdncustomer               	engg_name, --Input 
	@hdnproject                	engg_name, --Input 
	@prj_hdn_ctrl              	plf_hdn_ctrl_bt, --Input 
	@fprowno                   	rowno, --Input/Output
	@m_errorid                 	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on

	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	-- declaration of temporary variables


	-- temporary and formal parameters mapping

	Set @ctxt_user                  = @ctxt_user
	Set @ctxt_service               = @ctxt_service
	Set @de_engg_cmbtaskt_met       = @de_engg_cmbtaskt_met
	Set @de_engg_cmbtask_patt       = @de_engg_cmbtask_patt
	Set @de_engg_component          = @de_engg_component
	Set @de_engg_customer_name      = @de_engg_customer_name
	Set @de_engg_ecr_no             = @de_engg_ecr_no
	Set @de_engg_process_descr      = @de_engg_process_descr
	Set @de_engg_project_name       = @de_engg_project_name
	Set @de_engg_taskcmb_type       = @de_engg_taskcmb_type
	Set @de_engg_tasktxt_desc       = @de_engg_tasktxt_desc
	Set @de_engg_task_docum         = @de_engg_task_docum
	Set @de_engg_tasttxt_docu       = @de_engg_tasttxt_docu
	Set @de_engg_txttask_patt_desc  = @de_engg_txttask_patt_desc
	Set @de_engg_txttask_patt_name  = @de_engg_txttask_patt_name
	Set @hdncustomer                = @hdncustomer
	Set @hdnproject                 = @hdnproject
	Set @prj_hdn_ctrl               = @prj_hdn_ctrl

	-- null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @de_engg_cmbtaskt_met = '~#~' 
		Select @de_engg_cmbtaskt_met = null  

	IF @de_engg_cmbtask_patt = '~#~' 
		Select @de_engg_cmbtask_patt = null  

	IF @de_engg_component = '~#~' 
		Select @de_engg_component = null  

	IF @de_engg_customer_name = '~#~' 
		Select @de_engg_customer_name = null  

	IF @de_engg_ecr_no = '~#~' 
		Select @de_engg_ecr_no = null  

	IF @de_engg_process_descr = '~#~' 
		Select @de_engg_process_descr = null  

	IF @de_engg_project_name = '~#~' 
		Select @de_engg_project_name = null  

	IF @de_engg_taskcmb_type = '~#~' 
		Select @de_engg_taskcmb_type = null  

	IF @de_engg_tasktxt_desc = '~#~' 
		Select @de_engg_tasktxt_desc = null  

	IF @de_engg_task_docum = '~#~' 
		Select @de_engg_task_docum = null  

	IF @de_engg_tasttxt_docu = '~#~' 
		Select @de_engg_tasttxt_docu = null  

	IF @de_engg_txttask_patt_desc = '~#~' 
		Select @de_engg_txttask_patt_desc = null  

	IF @de_engg_txttask_patt_name = '~#~' 
		Select @de_engg_txttask_patt_name = null  

	IF @hdncustomer = '~#~' 
		Select @hdncustomer = null  

	IF @hdnproject = '~#~' 
		Select @hdnproject = null  

	IF @prj_hdn_ctrl = '~#~' 
		Select @prj_hdn_ctrl = null  

	IF @fprowno = -915
		Select @fprowno = null  

	DECLARE 
		@de_engg_process_name	engg_name,
		@de_engg_comp_name		engg_name

	SELECT TOP 1 
		@de_engg_process_name	=	process_name,
		@de_engg_comp_name		=	component_name
	FROM	ep_ui_req_dtl(NOLOCK)
	WHERE	customer_name		=	@de_engg_customer_name
	AND		project_name		=	@de_engg_project_name
	AND		process_descr		=	@de_engg_process_descr
	AND		component_descr		=	@de_engg_component
	ORDER
	BY 1,2

	DELETE
	FROM es_ctrl_dtl_tmp
	WHERE guid					=	@prj_hdn_ctrl

	IF NOT EXISTS (
			SELECT 'x'
			FROM	es_ctrl_dtl_tmp(NOLOCK)
			WHERE	customer_name	=	@de_engg_customer_name
			AND		project_name	=	@de_engg_project_name
			AND		process_name	=	@de_engg_process_name
			AND		component_name	=	@de_engg_comp_name
			AND		def_task_type	=	CASE 
			WHEN @de_engg_cmbtaskt_met =	'DoNotDefault'
				THEN 'dnd'
			ELSE @de_engg_cmbtaskt_met
				END
			AND		task_type		=	@de_engg_cmbtask_patt
			AND		user_id			=	@ctxt_user
			AND		guid			=	@prj_hdn_ctrl
			)
	BEGIN
		INSERT INTO es_ctrl_dtl_tmp (
			customer_name,
			project_name,
			process_name,
			component_name,
			task_type,
			def_task_type,
			user_id,
			guid,
			ctrl_req,
			task_properties,
			enumerated_task_value,
			task_enum_value
			)
		SELECT DISTINCT 
			@de_engg_customer_name,
			@de_engg_project_name,
			@de_engg_process_name,
			@de_engg_comp_name,
			@de_engg_cmbtask_patt,
			quick_code,
			@ctxt_user,
			@prj_hdn_ctrl,
			0,
			quick_code_value,
			CASE 
				WHEN quick_code_value IN ('No of Place Holders')
					THEN '0'
				ELSE NULL
				END,
			CASE 
				WHEN quick_code_value IN ('No of Place Holders')
					THEN b.no_placeholder
				ELSE NULL
				END
		FROM	es_ctrl_task_met		a(NOLOCK),
				de_comp_task_type_mst	b(NOLOCK)
		WHERE	quick_code_type			= 'task'
		AND		quick_code				= default_for
		AND		task_type_name			= @de_engg_cmbtask_patt
		AND		default_for				= CASE 
			WHEN @de_engg_cmbtaskt_met	= 'DoNotDefault'
				THEN 'dnd'
			ELSE @de_engg_cmbtaskt_met
			END
		AND customer_name				= @de_engg_customer_name
			AND project_name			= @de_engg_project_name
			AND process_name			= @de_engg_process_name
			AND component_name			= @de_engg_comp_name
	END

	UPDATE a
	SET a.task_req = CASE 
			WHEN a.task_properties			=	'Clear On Page Save'
				AND b.clr_on_page_save		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Combo Default Required'
				AND b.cbdef_req				=	'y'
				THEN 1
			WHEN a.task_properties			=	'Conditional Multiline Fetch'
				AND b.cond_ml_fetch			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Data Saving Task'
				AND b.data_save_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Header Fetch Required'
				AND b.hdr_fetch_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Header Save Required'
				AND b.hdr_save_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Include Message Place Holder'
				AND b.incl_place_holder		=	'y'
				THEN 1
			WHEN a.task_properties			=	'ML Save Required'
				AND b.ml_save_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Multiline Fetch Required'
				AND b.ml_fet_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'ML Singlesegment Required'
				AND b.MLSaveSinglesegment	=	'y'
				THEN 1
			WHEN a.task_properties			=	'Process only Selected Rows'
				AND b.proc_sel_rows			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Process only Updated Rows'
				AND b.process_updrows		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Refresh On Save'
				AND b.refresh_on_save		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Separate Header Refresh Method Required'
				AND b.hdr_ref_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Separate Method for Header Check Required'
				AND b.hdr_check_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Separate Method for Message Handling'
				AND b.err_handle_method		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Should User Role to be Mapped to All Methods'
				AND b.usr_role_map			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Task Conformation'
				AND b.task_confirmation		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Logic Extensions'
				AND b.Logic_extensions		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Transaction Scope Required'
				AND b.trn_scope_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Validate On Initiate'
				AND b.valid_on_init			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Fprowno Required'
				AND b.fprowno_req			=	'y'
				THEN 1
			WHEN a.task_properties			=	'Configure Alternate Database'
				AND b.alternate_db			=	'y'
				THEN 1 
			WHEN a.task_properties			=	'System Process only Selected Rows'
				AND b.sys_proc_sel_rows		=	'y'
				THEN 1
			WHEN a.task_properties			=	'System Process only Updated Rows'
				AND b.sys_process_updrows	=	'y'
				THEN 1
			WHEN a.task_properties			=	'LinkAsUI Required'
				AND b.Linkasui				=	'y'
				THEN 1
			WHEN a.task_properties			=	'Uiastrans Required'
				AND b.Uiastrans				=	'y'
				THEN 1
			WHEN a.task_properties			=	'Current Context Parameters'
				AND b.CurrentContextInformation = 'y'
				THEN 1

			WHEN a.task_properties			=	'Parent Context Parameters'
				AND b.ParentContextInformation = 'y'
				THEN 1
			WHEN a.task_properties			=	'Modeflag Enabled'
				AND b.ModeflagEnabled		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Bulk Validation'
				AND b.BulkValidation		=	'y'
				THEN 1
			WHEN a.task_properties			=	'Bubble Message'
				AND b.BubbleMessage			=	'y'
				THEN 1
			ELSE 0
			END
	FROM	es_ctrl_dtl_tmp			a(NOLOCK),
			de_comp_task_type_mst	b(NOLOCK)
	WHERE	a.customer_name		= @de_engg_customer_name
	AND a.project_name			= @de_engg_project_name
	AND a.process_name			= @de_engg_process_name
	AND a.component_name		= @de_engg_comp_name
	AND a.def_task_type			= CASE 
		WHEN @de_engg_cmbtaskt_met = 'DoNotDefault'
			THEN 'dnd'
		ELSE @de_engg_cmbtaskt_met
		END
	AND a.task_type				= @de_engg_cmbtask_patt
	AND b.customer_name			= a.customer_name
	AND b.project_name			= a.project_name
	AND b.process_name			= a.process_name
	AND b.component_name		= a.component_name
	AND b.task_type_name		= a.task_type
	AND b.default_for			= a.def_task_type
	AND a.guid					= @prj_hdn_ctrl

	SELECT DISTINCT 
	a.task_properties	'de_engg_task_descr',
	a.task_req			'de_engg_task_req'
	FROM	es_ctrl_dtl_tmp		a(NOLOCK),
			es_ctrl_task_met	b(NOLOCK)
	WHERE	a.customer_name		=	@de_engg_customer_name
	AND		a.project_name		=	@de_engg_project_name
	AND		a.process_name		=	@de_engg_process_name
	AND		a.component_name	=	@de_engg_comp_name
	AND		a.def_task_type		=	CASE 
	WHEN	@de_engg_cmbtaskt_met	=	'DoNotDefault'
		THEN 'dnd'
	ELSE	@de_engg_cmbtaskt_met
	END
	AND		a.task_type			=	@de_engg_cmbtask_patt
	AND		a.def_task_type		=	b.quick_code
	AND		b.quick_code_type	=	'task'
	AND		isnull(a.enumerated_task_value, '#') = '#'
	AND		a.guid				=	@prj_hdn_ctrl
	
	UNION
	
	SELECT DISTINCT 
		b.quick_code_value	'de_engg_task_descr',
		0					'de_engg_task_req'
	FROM	es_ctrl_task_met b(NOLOCK)
	WHERE	b.quick_code_type		=	'task'
	AND		b.quick_code_value		<>	'No of Place Holders'
	AND		quick_code				=	'DND'
	AND		b.quick_code_value NOT IN (
		SELECT DISTINCT a.task_properties
		FROM	es_ctrl_dtl_tmp		a(NOLOCK),
				es_ctrl_task_met	b(NOLOCK)
		WHERE a.customer_name		= @de_engg_customer_name
			AND a.project_name		= @de_engg_project_name
			AND a.task_type			= @de_engg_cmbtask_patt
			AND b.quick_code_type	= 'task'
			AND quick_code			= def_task_type
			AND isnull(a.enumerated_task_value, '#') = '#'
			AND a.guid				= @prj_hdn_ctrl
		)

	/* 
	-- OutputList
	Select
		null 'fprowno', 
		null 'de_engg_task_descr', 
		null 'de_engg_task_req', 
	*/

	Set nocount off
End

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'DEactpatSpaddnewtsktypspO' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON DEactpatSpaddnewtsktypspO TO PUBLIC
END
GO


