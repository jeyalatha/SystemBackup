IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_bterm_sp_savassyn' AND TYPE = 'P')
BEGIN
	DROP PROC de_bterm_sp_savassyn
END
GO
/********************************************************************************/
/* procedure        :   de_bterm_sp_savassyn                       */
/* description      :                                                 */
/********************************************************************************/
/* project          :                                                 */
/* version          :                                                 */
/********************************************************************************/
/* referenced       :                                                 */
/* tables           :                                                 */
/********************************************************************************/
/* development history   :                                                */
/********************************************************************************/
/* author          :   T.C.E. HEMALATHA                              */
/* date           :   19 MARCH 2004                                 */
/********************************************************************************/
/* modification history  :                                              */
/* modified by   : DNR             */
/* modified on   : 20-Apr-2004           */
/* modified for   : DEENG203SYS_0000014         */
/********************************************************************************/
/* modification history  :                                              */
/* modified by   : A.G.Senthil kumar             */
/* modified on   : 20-Apr-2004           */
/* modified for   : DEENG203SYS_0000003         */
/* modified by   : DNR             */
/* modified on   : 26-Apr-2004           */
/* modified for   : DEENG203SYS_000139          */
/*After mapping a btname to a control in maintain business terms, type of that control and length is unaltered, it is showing the old type and length only.*/
/* modified by   : DNR             */
/* modified on   : 17-June-2004          */
/* modified for   : DEENG203SYS_000139          */
/*In associate business term tab, bt synonym datatype and lenth are not getting updated with mapped BT datatype and length.*/
/* modified by   : Feroz            */
/* modified on   : 30-June-2004          */
/* modified for   : DEENG203SYS_000261          */
/*Error cannot be find in which rowno, so placeholder value passed     */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3058         */
/* Modified on : 16/06/2005              */
/* Description : Method Parameter Name :- Placeholder1, Placeholder2, Placeholder3, Placeholder4
the BT mapped is etwrrsamount which is a numeric datatype of precision (12,2).
But the method parameter is getting mapped to a BT called "Placeholder" on
service generation but the service segment Dataitem is mapped
correctly to etwrrsamount           */
/********************************************************************************/
/* modification history                                                         */
/* Modified by : Ganesh for callid PNR2.0_3313         */
/* Modified on : 21/07/2005              */
/* Description : When I am publishing ECR the following error is coming. Business Terms :
RPT_NumberofDays Mapped With the BTSYNONYM(S) not Defined for the Component. */
/********************************************************************************/
/*Modified by : Sangeetha L for Bugid PNR2.0_7829 on 07-Apr-2006    */
/********************************************************************************/
/* Modified by : Chanheetha N A             */
/* Modified on : 08-Aug-2006              */
/* BUG ID      : PNR2.0_10007             */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 25-Aug-2006              */
/* BUG ID      : PNR2.0_10036             */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 16-May-2007              */
/* BUG ID      : PNR2.0_13677             */
/********************************************************************************/
/* Modified by : kiruthika R             */
/* Modified on : 25-Oct-2007              */
/* BUG ID      : PNR2.0_15833             */
/********************************************************************************/
/* modified by   : Chanheetha N A        */
/* date     : 17-nov-2007         */
/* BugId    : PNR2.0_16023          */
/************************************************************************/
/* modified by   : Gowrisankar M         */
/* date     : 10-Jan-2008         */
/* BugId    : PNR2.0_16453          */
/************************************************************************/
/* modified by   : Sangeetha G             */
/* date       : 03-Aug-2009              */
/* BugId      : PNR2.0_23139              */
/* modified for  : During 'Validate' in handlechanges  BT not mapped    */
/*                 to dataitem err  thrown        */
/************************************************************************/
/* modified by                    Date                       Defect ID            */
/* Veena U                        22-Jun-2016                PLF2.0_19034�        */
/******************************************************************************************/
/* modified by                    Date                       Defect ID					  */
/* Kanagavel A                   26-July-2016                PLF2.0_19034�				  */
/* Is Rating validation Changed to Rating Type											  */
/* Modified by  : Jeya Latha K/Venkatesan K		Date: 31-Oct-2018  Defect ID : TECH-28010 */
/* Modified by  : Jeya Latha K/Venkatesan K     Date: 17-Jun-2019  Defect ID : TECH-34971 */
/* Modified by  : Jeya Latha K/Venkatesan K     Date: 10-Aug-2019  Defect ID : TECH-36826 */   
/* Modified by  : Jeya Latha K				    Date: 01-Nov-2019  Defect ID : TECH-39534 */   
/******************************************************************************************/
/* Modified by			: Ponmalar A													  */
/* Date					: 29-Sep-2022													  */
/* Defect ID			: TECH-73216													  */
/******************************************************************************************/
/* Modified by			: Priyadharshini U												  */
/* Date					: 28-Oct-2022													  */
/* Defect ID			: TECH-73996													  */
/******************************************************************************************/
/* Modified by			: Ponmalar A													  */
/* Date					: 01-Dec-2022													  */
/* Defect ID			: TECH-75230													  */
/******************************************************************************************/
CREATE PROCEDURE de_bterm_sp_savassyn
-- temporary store for input parameter assignment
@ctxt_language     engg_ctxt_language   ,
@ctxt_ouinstance     engg_ctxt_ouinstance   ,
@ctxt_service     engg_ctxt_service   ,
@ctxt_user      engg_ctxt_user   ,
@engg_act_descr   engg_description,
@engg_btnamelike  engg_description,
@engg_btdes_like  engg_description,
@engg_btsyn_datayp  engg_name,
@engg_btsyn_btlength engg_name,
@engg_btsyn_btname  engg_name,
@engg_btsyn_datatype engg_name,
@engg_btsyn_length  engg_length,
@engg_btsyn_like  engg_description,
@engg_btsyn_name  engg_name,
@engg_btsyn_descr  engg_description,
@engg_btsyn_spl_text engg_description,
@engg_btsyn_status  engg_description,
@engg_component   engg_description,
@engg_customer_name  engg_name,
@engg_datatype   engg_type,
@engg_from_length  engg_length,
@engg_ico_no   engg_name,
@engg_match_status  engg_name,
@engg_process_descr  engg_description,
@engg_project_name  engg_name,
@engg_res_btsyn   engg_description,
@engg_src_criteria  engg_description,
@engg_to_length   engg_length,
@engg_tot_btsyn   engg_description,
@engg_ui_descr   engg_description,
@engg_unr_btsyn   engg_description,
@modeflag    engg_flag,
@fprowno    engg_rowno,
@m_errorid     engg_seq_no OUTPUT   --To Return Execution Status

AS
BEGIN

DECLARE @length_tmp   engg_rowno,
@data_type_tmp   engg_name

-- NOCOUNT Should be Switched ON to Prevent Phantom Rows
SET NOCOUNT ON

-- @m_errorid should be 0 to Indicate Success
SELECT @m_errorid =0



IF @ctxt_language = -915
SELECT @ctxt_language = NULL
IF @ctxt_ouinstance = -915
SELECT @ctxt_ouinstance = NULL
SELECT @ctxt_service = LTRIM(RTRIM(@ctxt_service))
IF @ctxt_service = '~#~'
SELECT @ctxt_service = NULL
SELECT @ctxt_user = LTRIM(RTRIM(@ctxt_user))
IF @ctxt_user = '~#~'
SELECT @ctxt_user = NULL
SELECT @engg_btsyn_btname = LTRIM(RTRIM(@engg_btsyn_btname))
IF @engg_btsyn_btname = '~#~'
SELECT @engg_btsyn_btname = NULL
SELECT @engg_btsyn_datatype = LTRIM(RTRIM(@engg_btsyn_datatype))
IF @engg_btsyn_datatype = '~#~'
SELECT @engg_btsyn_datatype = NULL
IF @engg_btsyn_length = -915
SELECT @engg_btsyn_length = NULL
SELECT @engg_btsyn_name = LTRIM(RTRIM(@engg_btsyn_name))
IF @engg_btsyn_name = '~#~'
SELECT @engg_btsyn_name = NULL
SELECT @engg_btsyn_spl_text = LTRIM(RTRIM(@engg_btsyn_spl_text))
IF @engg_btsyn_spl_text = '~#~'
SELECT @engg_btsyn_spl_text = NULL
SELECT @engg_component = LTRIM(RTRIM(@engg_component))
IF @engg_component = '~#~'
SELECT @engg_component = NULL
SELECT @engg_customer_name = LTRIM(RTRIM(@engg_customer_name))
IF @engg_customer_name = '~#~'
SELECT @engg_customer_name = NULL
SELECT @engg_ico_no = LTRIM(RTRIM(@engg_ico_no))
IF @engg_ico_no = '~#~'
SELECT @engg_ico_no = NULL
SELECT @engg_process_descr = LTRIM(RTRIM(@engg_process_descr))
IF @engg_process_descr = '~#~'
SELECT @engg_process_descr = NULL
SELECT @engg_project_name = LTRIM(RTRIM(@engg_project_name))
IF @engg_project_name = '~#~'
SELECT @engg_project_name = NULL
SELECT @modeflag = LTRIM(RTRIM(@modeflag))
IF @modeflag = '~#~'
SELECT @modeflag = NULL
IF @fprowno = -915
SELECT @fprowno = NULL


--  Template Select Statement for Selecting data to App Layer
--  SELECT
--  @fprowno 'FPROWNO'
--  FROM  ***

--CODE MODIFIED BY DNR ON 02-JUNE-2004 FOR THE BUGID DEENG203ACC_000061
--CHECK BOX SELECTION IS NOT MANDATORY TO SAVE THE DETAILS
if @modeflag = 's'
begin
SELECT   @fprowno = isnull  (@fprowno,0) + 1
SELECT     @fprowno  'FPROWNO'
return
end
--
SELECT   @fprowno = isnull  (@fprowno,0) + 1

DECLARE  @msg     engg_description  ,
@process_name  engg_name,
@component_name  engg_name,
@bt_name_tmp  engg_name,
@date    engg_date

select @date = getdate()

select  @process_name		=	process_name,
		@component_name		=	component_name
from	de_ui_ico(nolock)
where	customer_name		=	@engg_customer_name
and		project_name		=	@engg_project_name
and		ico_no				=	@engg_ico_no
and		process_descr		=	@engg_process_descr
and		component_descr		=	@engg_component

	--Code Commented for Defect ID : TECH-39534 Starts
	--declare @isglanceui		engg_flag,
	--		@tmp_datatype	engg_name
	
	--select @isglanceui = dbo.ngplf_get_isglanceui(@engg_customer_name, @engg_project_name, @component_name,@tmp_actname, @tmp_uiname) 

	--If ISNULL(@isglanceui,'') = 'y'
	--BEGIN
		--If @modeflag <> 'D'
		--Begin 
			
		--	SELECT  @tmp_datatype	=	data_type
		--	FROM    de_business_term(nolock)
		--	WHERE   customer_name       =	@engg_customer_name
		--	and     project_name        =	@engg_project_name
		--	and		process_name		=	@process_name
		--	and		component_name		=	@component_name
		--	and		bt_name				=	@engg_btsyn_btname

		--	IF EXISTS	( SELECT 'X'
		--		FROM	ngplf_wr_glossary gl(nolock),
		--				ngplf_wr_controlcolumn_vw vw(NOLOCK)
		--		where	gl.CustomerID		=	@engg_customer_name  
		--		AND		gl.ProjectID		=	@engg_project_name  	
		--		AND		gl.processname		=	@process_name  
		--		AND		gl.componentname	=	@component_name 
		--		AND		gl.btsynonymname	=	@engg_btsyn_name
		--		AND		gl.datatype			<>	@tmp_datatype
		--		AND		@tmp_datatype		<> 'VarBinary'
				
		--		AND		gl.CustomerID	=	vw.CustomerID
		--		AND		gl.ProjectID		=	vw.ProjectID
		--		AND		gl.processname		=	vw.ProcessName
		--		AND		gl.componentname	=	vw.ComponentName
		--		AND		gl.btsynonymname	=	vw.BTSynonymName
		--		UNION
		--		SELECT 'X'
		--		FROM	ngplf_wr_glossary gl(nolock),
		--				ngplf_wr_enumerated rad(NOLOCK)
		--		where	gl.CustomerID		=	@engg_customer_name  
		--		AND		gl.ProjectID		=	@engg_project_name 	
		--		AND		gl.processname		=	@process_name  
		--		AND		gl.componentname	=	@component_name 
		--		AND		gl.btsynonymname	=	@engg_btsyn_name
		--		AND		gl.datatype			<>	@tmp_datatype
		--		AND		@tmp_datatype		<> 'VarBinary'
				
		--		AND		gl.CustomerID		=	rad.CustomerID
		--		AND		gl.ProjectID		=	rad.ProjectID
		--		AND		gl.processname		=	rad.ProcessName
		--		AND		gl.componentname	=	rad.ComponentName
		--		AND		gl.btsynonymname	=	rad.EnumBTSynonym
		--		AND		rad.EnumeratedType	=	'Radio'
		--		UNION
		--		SELECT 'X'
		--		FROM	ngplf_wr_glossary gl(nolock),
		--				ngplf_wr_listedit_column lst(NOLOCK)
		--		where	gl.CustomerID		=	@engg_customer_name  
		--		AND		gl.ProjectID		=	@engg_project_name  	
		--		AND		gl.processname		=	@process_name  
		--		AND		gl.componentname	=	@component_name 
		--		AND		gl.btsynonymname	=	@engg_btsyn_name
		--		AND		gl.datatype			<>	@tmp_datatype
		--		AND		@tmp_datatype		<> 'VarBinary'
				
		--		AND		gl.CustomerID		=	lst.CustomerID
		--		AND		gl.ProjectID		=	lst.ProjectID
		--		AND		gl.processname		=	lst.ProcessName
		--		AND		gl.componentname	=	lst.ComponentName
		--		AND		gl.btsynonymname	=	lst.ColumnBTSynonym
		--		)

		--		BEGIN
		--			RAISERROR ('DataType mismatch for the BTSynonym: "%s". Since "%s" datatype mapped in Glance. Kinldy Change datatype in glance and proceed further.',16,1,@engg_btsyn_name,@tmp_datatype)
		--			Return
		--		END
--Code Commented for Defect ID : TECH-39534 Ends
				-- Added by 11536 to allow the datatype change for glance synonym except stringEdit & numericEdit

			--IF EXISTS	( SELECT 'X'
			--				FROM	de_glossary gl(nolock),
			--						ngplf_wr_controlcolumn_vw vw(NOLOCK)
			--				where	gl.customer_name	=	@engg_customer_name  
			--				AND		gl.project_name		=	@engg_project_name  	
			--				AND		gl.process_name		=	@process_name  
			--				AND		gl.component_name	=	@component_name 
			--				AND		gl.bt_synonym_name	=	@engg_btsyn_name
			--				AND		gl.data_type		<>	@tmp_datatype
			--				AND		ISNULL(IsGlance,'')	=	'y'	
			--				AND		@tmp_datatype		<> 'VarBinary'
							
			--				AND		gl.customer_name	=	vw.CustomerID
			--				AND		gl.project_name		=	vw.ProjectID
			--				AND		gl.process_name		=	vw.ProcessName
			--				AND		gl.component_name	=	vw.ComponentName
			--				AND		gl.bt_synonym_name	=	vw.BTSynonymName

			--				AND		ControlTypeName		 in ('stringEdit','numericEdit','date','time','dateTime')

			--				)

			--IF EXISTS ( SELECT 'X'
			--				FROM	de_glossary (nolock)
			--				where	customer_name	=	@engg_customer_name  
			--				AND		project_name	=	@engg_project_name  	
			--				AND		process_name	=	@process_name  
			--				AND		component_name	=	@component_name 
			--				AND		bt_synonym_name	=	@engg_btsyn_name
			--				AND		data_type		<>	@tmp_datatype
			--				AND		ISNULL(IsGlance,'')	=	'y'	
			--				AND		@tmp_datatype	<> 'VarBinary')

							--BEGIN
							--	RAISERROR ('DataType mismatch for the BTSynonym: "%s". Since "%s" datatype mapped in Glance. Kinldy delete & add the exact control type in glance and proceed further.',16,1,@engg_btsyn_name,@tmp_datatype)
							--	Return
							--END
			--END --Code Commented for Defect ID : TECH-39534 
		--END

--CODE ADDED BY DNR ON 18-JUNE-2004 FOR THE BUG ID DEENG203SYS_000209
--IF INVALID BT IS GIVEN IN THE MULTILINE, SYSTEM SHOULD SAY "INVALID BTERMS", BUT IT THROWS THE FOLLOWING ERROR "CANNOT INSERT THE VALUE NULL INTO COLUMN 'LENGTH', TABLE 'RVW20APPDB.DBO.EP_COMPONENT_GLOSSARY_MST'; COLUMN DOES NOT ALLOW NULLS. UPDATE FAILS."
--code added by kiruthika for bugid:PNR2.0_10036
if @modeflag in ('U','Y')
begin
if rtrim(@engg_btsyn_name) in ('Ctxt_Role','Ctxt_User','Ctxt_Service','Ctxt_OUInstance','Ctxt_Language','fprowno','modeflag','HdnWFOrgUnit','HdnWFDocKey')
begin
SELECT  @msg = 'Business Term should not be modified for the synonym name ' + @engg_btsyn_name + ' at row no : ' + cast(@fprowno as char(10))
EXEC    engg_error_sp
'de_bterm_savassyn',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service  ,
@ctxt_user,
'',
'',
'',
'',
@m_errorid OUT

IF @m_errorid <> 0
RETURN
END
end

--code added by kiruthika for bugid:PNR2.0_10036

IF ISNULL(@engg_btsyn_btname,'') <> ''
begin
IF  exists
(SELECT  'x'
FROM      de_business_term(nolock)
WHERE   customer_name       =  @engg_customer_name
and     project_name        =  @engg_project_name
and  process_name  = @process_name			
and  component_name  = @component_name
and  bt_name       =  @engg_btsyn_btname
)
BEGIN
SELECT  @length_tmp = length,
@data_type_tmp =data_type
FROM    de_business_term(nolock)
WHERE   customer_name       =  @engg_customer_name
and     project_name        =  @engg_project_name
and  process_name  = @process_name			
and  component_name  = @component_name
and  bt_name       =  @engg_btsyn_btname
END
ELSE
BEGIN
-- code modified by shafina on 15-Dec-2004 for DEENG203ACC_000127(In Associate BTerms Tab , when 'Invalid Business Term' error is thrown - rowno and bt name is not shown in the error description.)
SELECT  @msg = 'Invalid Business Term ' + @engg_btsyn_btname + ' at row no : ' + cast(@fprowno as char(10))
EXEC    engg_error_sp
'de_bterm_savassyn',
1,
@msg,
@ctxt_language,
@ctxt_ouinstance,
@ctxt_service  ,
@ctxt_user,
'',
'',
'',
'',
@m_errorid OUT

IF @m_errorid <> 0
RETURN
END
if    @data_type_tmp in('Date')
begin
--    select @length_tmp = 10
select @length_tmp = 11 /*  PNR2.0_7829 */
end

declare @ctrl_type engg_name ,@ratingtype engg_name, @act_name engg_name, @ui_name engg_name

Select top 1 @act_name = activity_name
from de_ui_ico(nolock)
where customer_name  = @engg_customer_name
and   project_name  = @engg_project_name
and   ico_no    = @engg_ico_no
and   process_name  = @process_name
and   component_name  = @component_name
and   activity_descr  = @engg_act_descr

Select top 1 @ui_name  = ui_name
from de_ui_ico(nolock)
where customer_name  = @engg_customer_name
and   project_name  = @engg_project_name
and   ico_no    = @engg_ico_no
and   process_name  = @process_name
and   component_name  = @component_name
and   activity_name  = @act_name
and  ui_descr   = @engg_ui_descr

Select @ctrl_type = ''
Select top 1 @ctrl_type = control_type
from de_ui_control ctrl(nolock)
where ctrl.customer_name = @engg_customer_name
and  ctrl.project_name = @engg_project_name
and  ctrl.process_name = @process_name
and  ctrl.component_name = @component_name
and  ctrl.activity_name = @act_name
and  ctrl.ui_name  = @ui_name
and  ctrl.control_bt_synonym = @engg_btsyn_name
and  ctrl.section_bt_Synonym <> 'PrjhdnSection'

if  ISNULL(@ctrl_type,'') = ''
Select top 1 @ctrl_type = column_type
from de_ui_grid ctrl(nolock)
where ctrl.customer_name = @engg_customer_name
and  ctrl.project_name = @engg_project_name
and  ctrl.process_name = @process_name
and  ctrl.component_name = @component_name
and  ctrl.activity_name = @act_name
and  ctrl.ui_name  = @ui_name
and  ctrl.control_bt_synonym = @engg_btsyn_name
and  ctrl.section_bt_Synonym <> 'PrjhdnSection'

Select top 1  @ratingtype = RatingType
from es_comp_ctrl_type_mst (nolock)
where customer_name = @engg_customer_name
and  project_name = @engg_project_name
and  process_name = @process_name
and  component_name = @component_name
and  ctrl_type_name = @ctrl_type

if isnull(@ratingtype,'') <> '' and @data_type_tmp not in ( 'Integer','Numeric')
Begin
Raiserror('Bt associated with Rating Control "%s" should be of Numeric Datatype.Error in Row %i',16,4,@engg_btsyn_name,@fprowno)
return
End

--TECH-73996
DECLARE	@Stepperdatatype	engg_name,	@liveclockdatatype engg_name
SELECT @Stepperdatatype			=	data_type
FROM de_business_term (NOLOCK)
WHERE	customer_name		=	@engg_customer_name
AND		project_name		=	@engg_project_name
AND		process_name		=	@process_name
AND		component_name		=	@component_name
AND		bt_name				=	@engg_btsyn_btname	

SELECT @liveclockdatatype			=	data_type
FROM de_business_term (NOLOCK)
WHERE	customer_name		=	@engg_customer_name
AND		project_name		=	@engg_project_name
AND		process_name		=	@process_name
AND		component_name		=	@component_name
AND		bt_name				=	@engg_btsyn_btname	

if exists (SELECT 'X'
from	de_ui_control a (nolock)
join	es_comp_ctrl_type_mst_extn b (nolock)
on		a.customer_name		 =	b.customer_name
and		a.project_name		 =	b.project_name
and		a.process_name		 =	b.process_name
and		a.component_name	 =	b.component_name
and		a.control_type		 =  b.ctrl_type_name
where	a.customer_name		=	@engg_customer_name
and		a.project_name		=	@engg_project_name
and		a.process_name		=	@process_name
and		a.component_name	=	@component_name
and		a.activity_name		=	@act_name
and		a.ui_name			=	@ui_name
and		a.control_bt_synonym =	@engg_btsyn_name
and     b.base_ctrl_type		=	'Edit'
and		b.Stepper				=	'y'
UNION
SELECT 'X'
from	de_ui_grid a (nolock)
join	es_comp_ctrl_type_mst_extn b (nolock)
on		a.customer_name		 =	b.customer_name
and		a.project_name		 =	b.project_name
and		a.process_name		 =	b.process_name
and		a.component_name	 =	b.component_name
and		a.column_type		 =  b.ctrl_type_name
where	a.customer_name		=	@engg_customer_name
and		a.project_name		=	@engg_project_name
and		a.process_name		=	@process_name
and		a.component_name	=	@component_name
and		a.activity_name		=	@act_name
and		a.ui_name			=	@ui_name
and		a.column_bt_synonym =	@engg_btsyn_name
and     b.base_ctrl_type		=	'Edit'
and		b.Stepper				=	'y'
)
AND		@Stepperdatatype NOT IN ('Integer','Numeric')
begin
	raiserror('For Stepper control mapped BT should be Integer/Numeric at rowno %i',16,1,@fprowno)
	return
end

if exists (SELECT 'X'
from	de_ui_control a (nolock)
join	es_comp_ctrl_type_mst_extn b (nolock)
on		a.customer_name		 =	b.customer_name
and		a.project_name		 =	b.project_name
and		a.process_name		 =	b.process_name
and		a.component_name	 =	b.component_name
and		a.control_type		 =  b.ctrl_type_name
where	a.customer_name		=	@engg_customer_name
and		a.project_name		=	@engg_project_name
and		a.process_name		=	@process_name
and		a.component_name	=	@component_name
and		a.activity_name		=	@act_name
and		a.ui_name			=	@ui_name
and		a.control_bt_synonym =	@engg_btsyn_name
and     b.base_ctrl_type		=	'Edit'
and		b.LiveClock				=	'y'
UNION
SELECT 'X'
from	de_ui_grid a (nolock)
join	es_comp_ctrl_type_mst_extn b (nolock)
on		a.customer_name		 =	b.customer_name
and		a.project_name		 =	b.project_name
and		a.process_name		 =	b.process_name
and		a.component_name	 =	b.component_name
and		a.column_type		 =  b.ctrl_type_name
where	a.customer_name		=	@engg_customer_name
and		a.project_name		=	@engg_project_name
and		a.process_name		=	@process_name
and		a.component_name	=	@component_name
and		a.activity_name		=	@act_name
and		a.ui_name			=	@ui_name
and		a.column_bt_synonym =	@engg_btsyn_name
and     b.base_ctrl_type		=	'Edit'
and		b.LiveClock				=	'y'
)
AND		@liveclockdatatype NOT IN ('Time','Datetime','Date-time')
begin
	raiserror('For LiveClock control attribute mapped BT should be Time/Datetime at rowno %i',16,1,@fprowno)
	return
end

	DECLARE @cnt_ctrlbtsyn	engg_seqno,
			@cnt_grdbtsyn	engg_seqno,
			@cnt_secbtsyn	engg_seqno,
			@cnt_pgbtsyn	engg_seqno,
			@btname			engg_name,
			@datatype		engg_name,
			@length			engg_seqno,
			@btdatatype		engg_name,
			@btlength		engg_seqno,
			@prectype		engg_name,
			@tot_len		engg_seqno,
			@dec_len		engg_seqno
			
	SELECT	@cnt_pgbtsyn	=	count(*)
	FROM	(	SELECT	page_bt_Synonym,ui_name
				FROM	de_ui_page  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name  
				AND		page_bt_Synonym		= @engg_btsyn_name
				GROUP BY ui_name,page_bt_Synonym ) d	
				
	SELECT	@cnt_secbtsyn	=	count(*)
	FROM	(	SELECT	section_bt_Synonym,ui_name
				FROM	de_ui_section  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name  
				AND		section_bt_Synonym	= @engg_btsyn_name
				GROUP BY ui_name,section_bt_Synonym ) c

	SELECT	@cnt_ctrlbtsyn	=	count(*)
	FROM	(	SELECT	control_bt_Synonym,ui_name
				FROM	de_ui_control  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name  
				AND		control_bt_Synonym	= @engg_btsyn_name
				GROUP BY ui_name,control_bt_Synonym ) a

	SELECT	@cnt_grdbtsyn	=	count(*)
	FROM	(	SELECT	column_bt_Synonym,ui_name
				FROM	de_ui_grid  WITH(NOLOCK)
				WHERE	customer_name		= @engg_customer_name  
				AND		project_name		= @engg_project_name   
				AND		column_bt_Synonym	= @engg_btsyn_name
				GROUP BY ui_name,column_bt_Synonym ) b			
	
	IF EXISTS(select 'X'		--TECH-75230
	FROM de_glossary (NOLOCK)
	WHERE	customer_name		= @engg_customer_name  
	AND		project_name		= @engg_project_name
	AND		process_name		<> @process_name
	AND		component_name		<> @component_name
	AND		bt_synonym_name		= @engg_btsyn_name	
	AND		ISNULL(bt_name,'')	<> '')	
	BEGIN
	SELECT  @btname				= bt_name
	FROM de_glossary (NOLOCK)
	WHERE	customer_name		= @engg_customer_name  
	AND		project_name		= @engg_project_name
	AND		process_name		<> @process_name
	AND		component_name		<> @component_name
	AND		bt_synonym_name		= @engg_btsyn_name	
	AND		ISNULL(bt_name,'')	<> ''
	

	SELECT	@datatype			= data_type,
			@length				= length,
			@prectype			= precision_type --TECH-75230
	FROM	de_business_term (NOLOCK)
	WHERE	customer_name		= @engg_customer_name  
	AND		project_name		= @engg_project_name
	AND		process_name		<> @process_name
	AND		component_name		<> @component_name
	AND		bt_name				= @btname
	END ----TECH-75230

	--TECH-75230
	SELECT	@tot_len			= total_length,
			@dec_len			= decimal_length
	FROM	de_precision_type (NOLOCK)
	WHERE	customer_name		= @engg_customer_name  
	AND		project_name		= @engg_project_name
	AND		process_name		<> @process_name
	AND		component_name		<> @component_name
	AND		pt_name				=  @prectype
	--TECH-75230

	SELECT	@btdatatype			= data_type,
			@btlength			= length
	FROM	de_business_term (NOLOCK)
	WHERE	customer_name		= @engg_customer_name  
	AND		project_name		= @engg_project_name
	AND		process_name		= @process_name
	AND     component_name		= @component_name
	AND		bt_name				= @engg_btsyn_btname

		IF ISNULL(@datatype,'') <> ''	--TECH-75230
		AND EXISTS (SELECT 'X'
		FROM de_glossary (NOLOCK)
		WHERE	customer_name		=  @engg_customer_name  
		AND		project_name		=  @engg_project_name
		AND		bt_synonym_name		=  @engg_btsyn_name	
		AND		(ISNULL(@datatype,'')	<> ISNULL(@btdatatype,'')
		OR		ISNULL(@length,0)		<> ISNULL(@btlength,0)))
			BEGIN
				IF (@cnt_ctrlbtsyn	>	1	OR	@cnt_grdbtsyn	>	1	OR	@cnt_secbtsyn	>	1	OR @cnt_pgbtsyn	>	1)	AND ISNULL(@prectype,'') = ''
					BEGIN
						RAISERROR('Business Term (Datatype - %s, DataLength - %i) is already mapped for this BT Synonym "%s". Please use this at rowno: %i to proceed.',16,1,@datatype,@length,@engg_btsyn_name,@fprowno)	--TECH-75230
						RETURN
					END
				ELSE IF (@cnt_ctrlbtsyn	>	1	OR	@cnt_grdbtsyn	>	1	OR	@cnt_secbtsyn	>	1	OR @cnt_pgbtsyn	>	1)	AND ISNULL(@prectype,'') <> ''
					BEGIN
						RAISERROR('Business Term (Datatype - %s, DataLength - %i) is already mapped for this BT Synonym "%s". Please use this Precision Type "%s" (Total Length - %i, Decimal Length - %i) at rowno: %i to proceed.',16,1,@datatype,@length,@engg_btsyn_name,@prectype,@tot_len,@dec_len,@fprowno)	--TECH-75230
						RETURN
					END
			END
--TECH-73996

-- code modified by shafina on 18-Nov-2004 for DEENG203SYS_000456 (ECR No. IMP_UAT_RPT_ECR_015 (On save of Associate BTerms for the option "Not Mapped to UI", following error occurs "Internal Server Error".)
select @bt_name_tmp  =  bt_name
from de_glossary(nolock)
WHERE   customer_name       =  @engg_customer_name
and     project_name        =  @engg_project_name
and  process_name  = @process_name
and  component_name  = @component_name
and  bt_synonym_name  =  @engg_btsyn_name

select @bt_name_tmp = isnull(@bt_name_tmp,  '')

if @bt_name_tmp <> @engg_btsyn_btname
begin

-- code added by ganesh on 28/06/05 for callid :: PNR2.0_3058
-- to update the bt name for the scratch variables
update a
set  btname   = @engg_btsyn_btname ,
modifiedby  = @ctxt_user,
modifieddate = @date
from de_scratch_variables_sys a (nolock)
WHERE   customer_name   = @engg_customer_name
and     project_name    = @engg_project_name
and  process_name = @process_name
and  component_name = @component_name
and  btsynonym  = @engg_btsyn_name

-- code modified by Ganesh for the callid :: PNR2.0_3313 on 21/07/05
if exists ( select  's'
from es_business_term
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    bt_name   = @engg_btsyn_btname )
begin
update es_business_term
set  length    = @length_tmp,
data_type  = @data_type_tmp ,
modifiedby  = @ctxt_user,
modifieddate = @date
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    bt_name   = @engg_btsyn_btname

update  ep_glossary_mst
set  length    = @length_tmp,
data_type  = @data_type_tmp ,
modifiedby  = @ctxt_user,
modifieddate = @date,
bt_name   = @engg_btsyn_btname
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    bt_synonym_name = @engg_btsyn_name

-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

update  a
set  a.length    = @length_tmp,
a.data_type   = @data_type_tmp,
a.modifiedby  = @ctxt_user,
a.modifieddate  = @date,
a.bt_name   = @engg_btsyn_btname
from    ep_glossary_mst a(nolock),
de_hidden_view b (nolock)
where  a.customer_name  = @engg_customer_name
and    a.project_name  = @engg_project_name
and   a.customer_name  = b.customer_name
and    a.project_name  = b.project_name
and     a.bt_synonym_name   = b.hidden_view_bt_synonym
and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006
-- code modified by shafina on 04-Jan-2005 for DEENG203ACC_000134 (In Associate Business terms , BT Name is not getting updated in lang extn tables.)
update  ep_glossary_mst_lng_extn
set  length    = @length_tmp,
data_type  = @data_type_tmp ,
modifiedby  = @ctxt_user,
modifieddate = @date,
bt_name   = @engg_btsyn_btname
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    bt_synonym_name = @engg_btsyn_name

-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

update  a
set  a.length    = @length_tmp,
a.data_type   = @data_type_tmp,
a.modifiedby  = @ctxt_user,
a.modifieddate  = @date,
a.bt_name   = @engg_btsyn_btname
from    ep_glossary_mst_lng_extn a(nolock),
de_hidden_view b (nolock)
where  a.customer_name  = @engg_customer_name
and    a.project_name  = @engg_project_name
and   a.customer_name  = b.customer_name
and    a.project_name  = b.project_name
and     a.bt_synonym_name   = b.hidden_view_bt_synonym
and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006
-- code modified by shafina on 29-Oct-2004 for DEENG203ACC_000113(When a btsynonym's length and datatype is updated , those btsynonyms referring this must also get updated.)
-- code modified by shafina on 24-Nov-2004 for DEENG203ACC_000113(When a btsynonym's length and datatype is updated , those btsynonyms referring this must also get updated.)
update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_glossary_mst  a (nolock) ,
de_hidden_view  b (nolock) ,
ep_glossary_mst  c (nolock)
where  b.customer_name   = @engg_customer_name
and    b.project_name   = @engg_project_name
and  b.process_name   = @process_name
and  b.component_name  = @component_name
and    b.hidden_view_bt_synonym= @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name    = b.project_name
and  a.bt_synonym_name  = b.hidden_view_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.new_control_bt_synonym= c.bt_synonym_name


update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_glossary_mst_lng_extn  a (nolock) ,
de_hidden_view    b (nolock) ,
ep_glossary_mst_lng_extn c (nolock)
where  b.customer_name   = @engg_customer_name
and    b.project_name   = @engg_project_name
and  b.process_name   = @process_name
and  b.component_name  = @component_name
and    b.hidden_view_bt_synonym= @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.bt_synonym_name  = b.hidden_view_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.new_control_bt_synonym= c.bt_synonym_name

update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_glossary_mst   a (nolock) ,
de_task_control_map  b (nolock) ,
ep_glossary_mst   c (nolock)
where  b.customer_name   = @engg_customer_name
and    b.project_name   = @engg_project_name
and  b.process_name   = @process_name
and  b.component_name  = @component_name
and    b.control_bt_synonym = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.bt_synonym_name  = b.control_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.new_control_bt_synonym= c.bt_synonym_name

update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_glossary_mst_lng_extn a (nolock) ,
de_task_control_map   b (nolock) ,
ep_glossary_mst_lng_extn c (nolock)
where  b.customer_name   = @engg_customer_name
and    b.project_name   = @engg_project_name
and  b.process_name   = @process_name
and  b.component_name  = @component_name
and    b.control_bt_synonym = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.bt_synonym_name  = b.control_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.new_control_bt_synonym= c.bt_synonym_name

-- code modified by shafina on 25-Oct-2004 for DEENG203ACC_000112 (updating Bt name also while updating Glossary tables.)
--    update  ep_published_glossary_mst
--    set  length    = @length_tmp,
--         data_type  = @data_type_tmp,
--      modifiedby  = @ctxt_user,
--      modifieddate = @date,
--      bt_name   = @engg_btsyn_btname
--    where  LTRIM(RTRIM(customer_name))  = @engg_customer_name
--    and    LTRIM(RTRIM(project_name))  = @engg_project_name
--    and    LTRIM(RTRIM(bt_synonym_name))  = @engg_btsyn_name
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_glossary_mst  a (nolock) ,
--      de_hidden_view    b (nolock) ,
--      ep_published_glossary_mst  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_glossary_mst  a (nolock) ,
--      de_task_control_map   b (nolock) ,
--      ep_published_glossary_mst  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.bt_synonym_name  = b.control_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
end -- end of bt check at customer/project level

update  ep_component_glossary_mst
set  length    = @length_tmp,
data_type  = @data_type_tmp,
modifiedby  = @ctxt_user,
modifieddate = @date,
bt_name   = @engg_btsyn_btname
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    process_name = @process_name
and    component_name = @component_name
and    bt_synonym_name = @engg_btsyn_name

-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

update  a
set  a.length    = @length_tmp,
a.data_type   = @data_type_tmp,
a.modifiedby  = @ctxt_user,
a.modifieddate  = @date,
a.bt_name   = @engg_btsyn_btname
from    ep_component_glossary_mst a(nolock),
de_hidden_view b (nolock)
where  a.customer_name  = @engg_customer_name
and    a.project_name  = @engg_project_name
and    a.process_name  = @process_name
and    a.component_name = @component_name
and   a.customer_name  = b.customer_name
and    a.project_name  = b.project_name
and    a.process_name  = b.process_name
and    a.component_name = b.component_name
and     a.bt_synonym_name   = b.hidden_view_bt_synonym
and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

--update  ep_component_glossary_mst_lng_extn
--set  length    = @length_tmp,
--data_type  = @data_type_tmp,
--modifiedby  = @ctxt_user,
--modifieddate = @date,
--bt_name   = @engg_btsyn_btname
--where  customer_name = @engg_customer_name
--and    project_name = @engg_project_name
--and    process_name = @process_name
--and    component_name = @component_name
--and    bt_synonym_name = @engg_btsyn_name

-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

--update  a
--set  a.length    = @length_tmp,
--a.data_type   = @data_type_tmp,
--a.modifiedby  = @ctxt_user,
--a.modifieddate  = @date,
--a.bt_name   = @engg_btsyn_btname
--from    ep_component_glossary_mst_lng_extn a(nolock),
--de_hidden_view b (nolock)
--where  a.customer_name  = @engg_customer_name
--and    a.project_name  = @engg_project_name
--and    a.process_name  = @process_name
--and    a.component_name = @component_name
--and   a.customer_name  = b.customer_name
--and    a.project_name  = b.project_name
--and    a.process_name  = b.process_name
--and    a.component_name = b.component_name
--and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006


update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_component_glossary_mst  a (nolock) ,
de_hidden_view    b (nolock) ,
ep_component_glossary_mst  c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.hidden_view_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from ep_component_glossary_mst_lng_extn  a (nolock) ,
--de_hidden_view      b (nolock) ,
--ep_component_glossary_mst_lng_extn c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name

update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from ep_component_glossary_mst  a (nolock) ,
de_task_control_map   b (nolock) ,
ep_component_glossary_mst  c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.control_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from ep_component_glossary_mst_lng_extn  a (nolock) ,
--de_task_control_map     b (nolock) ,
--ep_component_glossary_mst_lng_extn c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.control_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name
-- PNR2.0_13677
--    update  ep_published_comp_glossary_mst
--    set  length    = @length_tmp,
--         data_type  = @data_type_tmp ,
--      modifiedby  = @ctxt_user,
--      modifieddate = @date,
--      bt_name   = @engg_btsyn_btname
--    where  customer_name = @engg_customer_name
--    and    project_name = @engg_project_name
--    and    process_name = @process_name
--    and    component_name = @component_name
--    and    bt_synonym_name = @engg_btsyn_name
--    and  req_no   not in (select distinct rcr_no
--            from re_ui_ecr (nolock)
--            where  customer_name = @engg_customer_name
--            and  project_name = @engg_project_name
--            and  process_name = @process_name
--            and  component_name = @component_name)
-- Code added by chanheetha N A for the call id : PNR2.0_10007 on 23-Aug-2006

--    update  a
--    set  a.length    = @length_tmp,
--         a.data_type   = @data_type_tmp,
--      a.modifiedby  = @ctxt_user,
--      a.modifieddate  = @date,
--      a.bt_name   = @engg_btsyn_btname
--    from    ep_published_comp_glossary_mst a(nolock),
--      de_hidden_view b (nolock)
--    where  a.customer_name  = @engg_customer_name
--    and    a.project_name  = @engg_project_name
--    and    a.process_name  = @process_name
--    and    a.component_name = @component_name
--    and   a.customer_name  = b.customer_name
--    and    a.project_name  = b.project_name
--    and    a.process_name  = b.process_name
--    and    a.component_name = b.component_name
--    and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--    and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
--    and  a.req_no   not in (select distinct rcr_no
--            from re_ui_ecr (nolock)
--            where  customer_name = @engg_customer_name
--            and  project_name = @engg_project_name
--            and  process_name = @process_name
--            and  component_name = @component_name)
-- Code added by chanheetha N A for the call id : PNR2.0_10007 on 23-Aug-2006

--    update  ep_published_comp_glossary_mst_lng_extn
--    set  length    = @length_tmp,
--         data_type  = @data_type_tmp ,
--      modifiedby  = @ctxt_user,
--      modifieddate = @date,
--      bt_name   = @engg_btsyn_btname
--    where  customer_name = @engg_customer_name
--    and    project_name = @engg_project_name
--    and    process_name = @process_name
--    and    component_name = @component_name
--    and    bt_synonym_name = @engg_btsyn_name
--    and  req_no   not in (select distinct rcr_no
--            from re_ui_ecr (nolock)
--            where  customer_name = @engg_customer_name
--            and  project_name = @engg_project_name
--            and  process_name = @process_name
--            and  component_name = @component_name)

-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

--    update  a
--    set  a.length    = @length_tmp,
--         a.data_type   = @data_type_tmp,
--      a.modifiedby  = @ctxt_user,
--      a.modifieddate  = @date,
--      a.bt_name   = @engg_btsyn_btname
--    from    ep_published_comp_glossary_mst_lng_extn a(nolock),
--      de_hidden_view b (nolock)
--    where  a.customer_name  = @engg_customer_name
--    and    a.project_name  = @engg_project_name
--    and    a.process_name  = @process_name
--    and    a.component_name = @component_name
--    and   a.customer_name  = b.customer_name
--    and    a.project_name  = b.project_name
--    and    a.process_name  = b.process_name
--    and    a.component_name = b.component_name
--    and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--    and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
--    and  a.req_no   not in (select distinct rcr_no
--            from re_ui_ecr (nolock)
--            where  customer_name = @engg_customer_name
--            and  project_name = @engg_project_name
--            and  process_name = @process_name
--            and  component_name = @component_name)
-- Code added by chanheetha N A for the call id :PNR2.0_10007  on 23-Aug-2006

--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_comp_glossary_mst  a (nolock) ,
--      de_hidden_view     b (nolock) ,
--      ep_published_comp_glossary_mst  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.req_no    not in (select distinct rcr_no
--              from re_ui_ecr (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_comp_glossary_mst_lng_extn  a (nolock) ,
--      de_hidden_view        b (nolock) ,
--      ep_published_comp_glossary_mst_lng_extn  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name   = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.req_no    not in (select distinct rcr_no
--              from re_ui_ecr (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_comp_glossary_mst  a (nolock) ,
--      de_task_control_map    b (nolock) ,
--      ep_published_comp_glossary_mst  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.control_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.req_no    not in (select distinct rcr_no
--              from re_ui_ecr (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from ep_published_comp_glossary_mst_lng_extn  a (nolock) ,
--      de_task_control_map       b (nolock) ,
--      ep_published_comp_glossary_mst_lng_extn  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.control_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.req_no    not in (select distinct rcr_no
--              from re_ui_ecr (nolock)
--         where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
-- PNR2.0_13677
update  re_glossary
set  length    = @length_tmp,
data_type  = @data_type_tmp ,
modifiedby  = @ctxt_user,
modifieddate = @date,
bt_name   = @engg_btsyn_btname
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    process_name = @process_name
and    component_name = @component_name
and    bt_synonym_name = @engg_btsyn_name


update  a       /* PNR2.0_10007 */
set  a.length    = @length_tmp,
a.data_type   = @data_type_tmp ,
a.modifiedby  = @ctxt_user,
a.modifieddate  = @date,
a.bt_name   = @engg_btsyn_btname
from    re_glossary   a (nolock),
de_hidden_view  b (nolock)
where  a.customer_name  = @engg_customer_name
and    a.project_name  = @engg_project_name
and    a.process_name  = @process_name
and    a.component_name = @component_name
and   a.customer_name  = b.customer_name
and    a.project_name  = b.project_name
and    a.process_name  = b.process_name
and    a.component_name = b.component_name
and     a.bt_synonym_name   = b.hidden_view_bt_synonym
and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name


--update  re_glossary_lng_extn
--set  length    = @length_tmp,
--data_type  = @data_type_tmp ,
--modifiedby  = @ctxt_user,
--modifieddate = @date,
--bt_name   = @engg_btsyn_btname
--where  customer_name = @engg_customer_name
--and    project_name = @engg_project_name
--and    process_name = @process_name
--and    component_name = @component_name
--and    bt_synonym_name = @engg_btsyn_name

--update  a        /* PNR2.0_10007 */
--set  a.length    = @length_tmp,
--a.data_type   = @data_type_tmp ,
--a.modifiedby  = @ctxt_user,
--a.modifieddate  = @date,
--a.bt_name   = @engg_btsyn_btname
--from    re_glossary_lng_extn   a (nolock),
--de_hidden_view  b (nolock)
--where  a.customer_name  = @engg_customer_name
--and    a.project_name  = @engg_project_name
--and    a.process_name  = @process_name
--and    a.component_name = @component_name
--and   a.customer_name  = b.customer_name
--and    a.project_name  = b.project_name
--and    a.process_name  = b.process_name
--and    a.component_name = b.component_name
--and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name


update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from re_glossary  a (nolock) ,
de_hidden_view b (nolock) ,
re_glossary  c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.hidden_view_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from re_glossary_lng_extn   a (nolock) ,
--de_hidden_view   b (nolock) ,
--re_glossary_lng_extn   c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name


update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from re_glossary   a (nolock) ,
de_task_control_map b (nolock) ,
re_glossary   c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.control_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from re_glossary_lng_extn a (nolock) ,
--de_task_control_map  b (nolock) ,
--re_glossary_lng_extn c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.control_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name
-- PNR2.0_13677
--    update  re_published_glossary
--    set  length    = @length_tmp,
--         data_type  = @data_type_tmp,
--      modifiedby  = @ctxt_user,
--      modifieddate = @date,
--      bt_name   = @engg_btsyn_btname
--    where  customer_name = @engg_customer_name
--    and    project_name = @engg_project_name
--    and    process_name = @process_name
--    and    component_name = @component_name
--   and    bt_synonym_name = @engg_btsyn_name
--    and  ecr_no not in( select distinct ecr_no
--          from de_ui_ico (nolock)
--          where  customer_name = @engg_customer_name
--          and  project_name = @engg_project_name
--          and  process_name = @process_name
--          and  component_name = @component_name)
--
--
--  update  a    /*PNR2.0_10007 */
--    set  a.length    = @length_tmp,
--         a.data_type   = @data_type_tmp ,
--      a.modifiedby  = @ctxt_user,
--      a.modifieddate  = @date,
--      a.bt_name   = @engg_btsyn_btname
--    from    re_published_glossary   a (nolock),
--      de_hidden_view  b (nolock)
--    where  a.customer_name  = @engg_customer_name
--    and    a.project_name  = @engg_project_name
--    and    a.process_name  = @process_name
--    and    a.component_name = @component_name
--    and   a.customer_name  = b.customer_name
--    and    a.project_name  = b.project_name
--    and    a.process_name  = b.process_name
--    and    a.component_name = b.component_name
--    and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--    and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
--    and  a.ecr_no not in( select distinct ecr_no
--          from de_ui_ico (nolock)
--          where  customer_name = @engg_customer_name
--          and  project_name = @engg_project_name
--          and  process_name = @process_name
--          and  component_name = @component_name)
--
--
--    update  re_published_glossary_lng_extn
--    set  length    = @length_tmp,
--         data_type  = @data_type_tmp,
--      modifiedby  = @ctxt_user,
--      modifieddate = @date,
--      bt_name   = @engg_btsyn_btname
--    where  customer_name = @engg_customer_name
--    and    project_name = @engg_project_name
--    and    process_name = @process_name
--    and    component_name = @component_name
--    and    bt_synonym_name = @engg_btsyn_name
--    and  ecr_no not in( select distinct ecr_no
--          from de_ui_ico (nolock)
--          where  customer_name = @engg_customer_name
--          and  project_name = @engg_project_name
--          and  process_name = @process_name
--          and  component_name = @component_name)
--
--    update  a     /*PNR2.0_10007 */
--    set  a.length    = @length_tmp,
--         a.data_type   = @data_type_tmp ,
--      a.modifiedby  = @ctxt_user,
--      a.modifieddate  = @date,
--      a.bt_name   = @engg_btsyn_btname
--    from    re_published_glossary_lng_extn   a (nolock),
--      de_hidden_view  b (nolock)
--    where  a.customer_name  = @engg_customer_name
--    and    a.project_name  = @engg_project_name
--    and    a.process_name  = @process_name
--    and    a.component_name = @component_name
--    and   a.customer_name  = b.customer_name
--    and    a.project_name  = b.project_name
--    and    a.process_name  = b.process_name
--    and    a.component_name = b.component_name
--    and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--    and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name
--    and  a.ecr_no not in( select distinct ecr_no
--          from de_ui_ico (nolock)
--          where  customer_name = @engg_customer_name
--          and  project_name = @engg_project_name
--          and  process_name = @process_name
--          and  component_name = @component_name)
--
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from re_published_glossary  a (nolock) ,
--      de_hidden_view   b (nolock) ,
--      re_published_glossary  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.ecr_no    not in (select distinct ecr_no
--              from de_ui_ico (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length          = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from re_published_glossary_lng_extn  a (nolock) ,
--      de_hidden_view     b (nolock) ,
--      re_published_glossary_lng_extn c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.ecr_no    not in (select distinct ecr_no
--              from de_ui_ico (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from re_published_glossary  a (nolock) ,
--      de_task_control_map  b (nolock) ,
--      re_published_glossary  c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.control_bt_synonym
--    and  b.customer_name     = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.ecr_no    not in (select distinct ecr_no
--              from de_ui_ico (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
--
--    update  c
--    set    c.data_type    = a.data_type,
--      c.length                = a.length,
--      c.bt_name    = a.bt_name,
--      c.modifiedby   = @ctxt_user,
--      c.modifieddate   = @date
--    from re_published_glossary_lng_extn  a (nolock) ,
--      de_task_control_map    b (nolock) ,
--      re_published_glossary_lng_extn c (nolock)
--    where  a.customer_name   = @engg_customer_name
--    and    a.project_name   = @engg_project_name
--    and    a.process_name    = @process_name
--    and    a.component_name   = @component_name
--    and    a.bt_synonym_name   = @engg_btsyn_name
--    and  a.customer_name         = c.customer_name
--    and   a.project_name          = c.project_name
--    and  a.process_name      = c.process_name
--    and  a.component_name     = c.component_name
--    and  a.bt_synonym_name  = c.ref_bt_synonym_name
--    and  a.customer_name         = b.customer_name
--    and   a.project_name          = b.project_name
--    and  a.process_name      = b.process_name
--    and  a.component_name     = b.component_name
--    and  a.bt_synonym_name  = b.control_bt_synonym
--    and  b.customer_name         = c.customer_name
--    and   b.project_name          = c.project_name
--    and  b.process_name      = c.process_name
--    and  b.component_name     = c.component_name
--    and  b.new_control_bt_synonym= c.bt_synonym_name
--    and  c.ecr_no    not in (select distinct ecr_no
--              from de_ui_ico (nolock)
--              where  customer_name = @engg_customer_name
--              and  project_name = @engg_project_name
--              and  process_name = @process_name
--              and  component_name = @component_name)
-- PNR2.0_13677
update  de_glossary
set  length    = @length_tmp,
data_type  = @data_type_tmp,
modifiedby  = @ctxt_user,
modifieddate = @date,
bt_name   = @engg_btsyn_btname
where  customer_name = @engg_customer_name
and    project_name = @engg_project_name
and    process_name = @process_name
and    component_name = @component_name
and    bt_synonym_name = @engg_btsyn_name

update  a /* PNR2.0_10007 */
set  a.length    = @length_tmp,
a.data_type   = @data_type_tmp ,
a.modifiedby  = @ctxt_user,
a.modifieddate  = @date,
a.bt_name   = @engg_btsyn_btname
from    de_glossary   a (nolock),
de_hidden_view  b (nolock)
where  a.customer_name  = @engg_customer_name
and    a.project_name  = @engg_project_name
and    a.process_name  = @process_name
and    a.component_name = @component_name
and   a.customer_name  = b.customer_name
and    a.project_name  = b.project_name
and    a.process_name  = b.process_name
and    a.component_name = b.component_name
and     a.bt_synonym_name   = b.hidden_view_bt_synonym
and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name

--update  de_glossary_lng_extn
--set  length    = @length_tmp,
--data_type  = @data_type_tmp,
--modifiedby  = @ctxt_user,
--modifieddate = @date,
--bt_name   = @engg_btsyn_btname
--where  customer_name = @engg_customer_name
--and    project_name = @engg_project_name
--and    process_name = @process_name
--and    component_name = @component_name
--and    bt_synonym_name = @engg_btsyn_name

--update  a /* PNR2.0_10007 */
--set  a.length    = @length_tmp,
--a.data_type   = @data_type_tmp ,
--a.modifiedby  = @ctxt_user,
--a.modifieddate  = @date,
--a.bt_name   = @engg_btsyn_btname
--from    de_glossary_lng_extn   a (nolock),
--de_hidden_view  b (nolock)
--where  a.customer_name  = @engg_customer_name
--and    a.project_name  = @engg_project_name
--and    a.process_name  = @process_name
--and    a.component_name = @component_name
--and   a.customer_name = b.customer_name
--and    a.project_name  = b.project_name
--and    a.process_name  = b.process_name
--and    a.component_name = b.component_name
--and     a.bt_synonym_name   = b.hidden_view_bt_synonym
--and    b.HIDDEN_VIEW_SOURCE= @engg_btsyn_name

update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from de_glossary  a (nolock) ,
de_hidden_view b (nolock) ,
de_glossary  c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.hidden_view_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from de_glossary_lng_extn  a (nolock) ,
--de_hidden_view   b (nolock) ,
--de_glossary_lng_extn c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.hidden_view_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name

update  c
set    c.data_type    = a.data_type,
c.length                = a.length,
c.bt_name    = a.bt_name,
c.modifiedby   = @ctxt_user,
c.modifieddate   = @date
from de_glossary   a (nolock) ,
de_task_control_map b (nolock) ,
de_glossary   c (nolock)
where  a.customer_name   = @engg_customer_name
and    a.project_name   = @engg_project_name
and    a.process_name    = @process_name
and    a.component_name   = @component_name
and    a.bt_synonym_name   = @engg_btsyn_name
and  a.customer_name         = c.customer_name
and   a.project_name          = c.project_name
and  a.process_name      = c.process_name
and  a.component_name     = c.component_name
and  a.bt_synonym_name  = c.ref_bt_synonym_name
and  a.customer_name         = b.customer_name
and   a.project_name          = b.project_name
and  a.process_name      = b.process_name
and  a.component_name     = b.component_name
and  a.bt_synonym_name  = b.control_bt_synonym
and  b.customer_name         = c.customer_name
and   b.project_name          = c.project_name
and  b.process_name      = c.process_name
and  b.component_name     = c.component_name
and  b.new_control_bt_synonym= c.bt_synonym_name

--update  c
--set    c.data_type    = a.data_type,
--c.length                = a.length,
--c.bt_name    = a.bt_name,
--c.modifiedby   = @ctxt_user,
--c.modifieddate   = @date
--from de_glossary_lng_extn  a (nolock) ,
--de_task_control_map  b (nolock) ,
--de_glossary_lng_extn c (nolock)
--where  a.customer_name   = @engg_customer_name
--and    a.project_name   = @engg_project_name
--and    a.process_name    = @process_name
--and    a.component_name   = @component_name
--and    a.bt_synonym_name   = @engg_btsyn_name
--and  a.customer_name         = c.customer_name
--and   a.project_name          = c.project_name
--and  a.process_name      = c.process_name
--and  a.component_name     = c.component_name
--and  a.bt_synonym_name  = c.ref_bt_synonym_name
--and  a.customer_name         = b.customer_name
--and   a.project_name          = b.project_name
--and  a.process_name      = b.process_name
--and  a.component_name     = b.component_name
--and  a.bt_synonym_name  = b.control_bt_synonym
--and  b.customer_name         = c.customer_name
--and   b.project_name          = c.project_name
--and  b.process_name      = c.process_name
--and  b.component_name     = c.component_name
--and  b.new_control_bt_synonym= c.bt_synonym_name

end
end

-- Code commented and modified by Gowrisankar M for PNR2.0_16453 on 10-Jan-2008
--Code modification for PNR2.0_23139 starts
-- --chan
If  exists (select '*' from sysobjects (nolock)
where name  = 'de_customer_space'
and  type = 'U')
Begin

if exists (select  'x'
from de_glossary  (nolock)
where upper(customer_name) = upper(@engg_customer_name)
and     upper(project_name)  = upper(@engg_project_name)
and  upper(component_name) = upper(@component_name)
and  isnull(bt_name,'')  <> ''
and  bt_synonym_name        not in ( select btsynonym from de_fw_req_bterm_synonym  (nolock)
where upper(customer_name) = upper(@engg_customer_name)
and     upper(project_name)  = upper(@engg_project_name)
and  component_name   = @component_name)
and  bt_name     in   ( select btname
from de_fw_req_bterm (nolock)
where customer_name  = upper(@engg_customer_name)
and  upper(project_name) = upper(@engg_project_name)
and  component_name  = @component_name ))
begin

insert into de_fw_req_bterm_synonym
(btsynonym, btname,upduser,updtime,
customer_name,project_name,timestamp,createdby,createddate,process_name,component_name,ecrno)--chan
select  bt_synonym_name,bt_name,@ctxt_user,getdate(), --hostname to ctxt_user		--TECH-73216
customer_name,project_name,1,@ctxt_user,getdate(),process_name,component_name,@engg_ico_no --TECH-73216
from de_glossary  (nolock)
where upper(customer_name) = upper(@engg_customer_name)
and     upper(project_name)  = upper(@engg_project_name)
and  upper(component_name) = upper(@component_name)
and  isnull(bt_name,'')  <> ''
and  bt_synonym_name        not in ( select btsynonym from de_fw_req_bterm_synonym  (nolock)
where upper(customer_name) = upper(@engg_customer_name)
and     upper(project_name)  = upper(@engg_project_name)
and  component_name   = @component_name)
and  bt_name     in   ( select btname
from de_fw_req_bterm (nolock)
where customer_name  = upper(@engg_customer_name)
and  upper(project_name) = upper(@engg_project_name)
and  component_name  = @component_name )
and  len(bt_synonym_name) < 31
end

if exists ( select 'x'
from de_glossary a  (nolock),
de_fw_req_bterm_synonym b (nolock)
where upper(a.customer_name) = upper(@engg_customer_name)
and     upper(a.project_name) = upper(@engg_project_name)
and  upper(a.component_name) = upper(@component_name)
and  isnull(a.bt_name,'') <>  ''
and  upper(a.customer_name) = upper(b.customer_name)
and     upper(a.project_name) = upper(b.project_name)
and  a.process_name   =  b.process_name
and  a.component_name  =  b.component_name
and  a.bt_synonym_name  =  b.btsynonym
and     b.btname     <> a.bt_name )
begin

update de_fw_req_bterm_synonym
set  btname  = a.bt_name
from de_glossary a  (nolock),
de_fw_req_bterm_synonym b (nolock)
where upper(a.customer_name) = upper(@engg_customer_name)
and     upper(a.project_name) = upper(@engg_project_name)
and  upper(a.component_name) = upper(@component_name)
and  isnull(a.bt_name,'') <>  ''
and  upper(a.customer_name) = upper(b.customer_name)
and     upper(a.project_name) = upper(b.project_name)
and  a.process_name   =  b.process_name
and  a.component_name  =  b.component_name
and  a.bt_synonym_name  =  b.btsynonym
and     b.btname     <> a.bt_name

end

if exists ( select 'x'
from  de_glossary    a(nolock),
de_fw_req_bterm_synonym b(nolock),
de_fw_req_bterm   c(nolock)
where  a.customer_name   =  @engg_customer_name
and     a.project_name    =  @engg_project_name
and     a.process_name      =  @process_name
and   a.component_name   =  @component_name
and  a.bt_synonym_name  = @engg_btsyn_name
and   isnull(a.bt_name,'')  <>  ''
and   a.customer_name   =  b.customer_name
and     a.project_name    =  b.project_name
and     a.process_name      =  b.process_name
and   a.component_name   =  b.component_name
and  a.bt_synonym_name    =   b.btsynonym
and     a.bt_name        <>  b.btname
and   a.customer_name   =  c.customer_name
and     a.project_name    =  c.project_name
and     a.process_name      =  c.process_name
and   a.component_name   =  c.component_name
and  a.bt_name      =   c.btname
and   len(bt_synonym_name)  <  31  )
begin

delete de_fw_req_bterm_synonym
where  customer_name =  @engg_customer_name
and     project_name  =  @engg_project_name
and     process_name    =  @process_name
and   component_name  =  @component_name
and  btsynonym  = @engg_btsyn_name

insert into de_fw_req_bterm_synonym
( btsynonym, btname,upduser,updtime,customer_name,project_name,timestamp,createdby,createddate,process_name,component_name,ecrno)--chan
select  bt_synonym_name,bt_name,@ctxt_user,getdate(),customer_name,project_name,1,@ctxt_user,getdate(),process_name,component_name,@engg_ico_no  --TECH-73216
from  de_glossary  (nolock)
where  customer_name   =  @engg_customer_name
and     project_name    =  @engg_project_name
and     process_name      =  @process_name
and   component_name    =  @component_name
and  bt_synonym_name   = @engg_btsyn_name
and   isnull(bt_name,'')   <>  ''
and   len(bt_synonym_name)  <  31


end

End

--Code modification for PNR2.0_23139 ends

-- Code commented and modified by Gowrisankar M for PNR2.0_16453 on 10-Jan-2008

-- code modified by shafina on 06-July-2004 for updating Bt name correctly

--  UPDATE   de_glossary
--  SET      bt_name             =  isnull(@engg_btsyn_btname,''),
--     modifiedby   =  @ctxt_user,
--     modifieddate  =  @date
--  where  LTRIM(RTRIM(customer_name)) = @engg_customer_name
--  and    LTRIM(RTRIM(project_name)) = @engg_project_name
--  and    LTRIM(RTRIM(process_name))  = @process_name
--  and    LTRIM(RTRIM(component_name))  = @component_name
--  and    LTRIM(RTRIM(bt_synonym_name = @engg_btsyn_name

--Code Added for Defect ID : TECH-39534 Starts
--Code added by 11536 for NGPLF table
		DECLARE		@tmp_old_control_type	ENGG_NAME,
					@tmp_control_type		ENGG_NAME,
					@Tmp_DataLength			ENGG_ROWNO,
					@Tmp_DecimalLength		ENGG_ROWNO,
					@Tmp_DataType			ENGG_NAME

		IF @modeflag in ('U','Y')
		BEGIN
			IF EXISTS ( SELECT 'X'
						FROM	ngplf_wr_glossary (NOLOCK)
						WHERE	CustomerID			=	@engg_customer_name
						AND		ProjectID			=	@engg_project_name
						AND		ProcessName			=	@process_name
						AND		ComponentName		=	@component_name
						AND		BTSynonymName		=	@engg_btsyn_name	)
						BEGIN --1
							IF EXISTS ( SELECT 'X'
										FROM	ngplf_wr_control (NOLOCK)
										WHERE	CustomerID			=	@engg_customer_name
										AND		ProjectID			=	@engg_project_name
										AND		ProcessName			=	@process_name
										AND		ComponentName		=	@component_name
										AND		BTSynonymName		=	@engg_btsyn_name	)
										BEGIN	--2
											SELECT @tmp_old_control_type	= controltypename
											FROM	ngplf_wr_control (NOLOCK)
											WHERE	CustomerID			=	@engg_customer_name
											AND		ProjectID			=	@engg_project_name
											AND		ProcessName			=	@process_name
											AND		ComponentName		=	@component_name
											AND		BTSynonymName		=	@engg_btsyn_name	

											IF 	@tmp_old_control_type	IN ('stringEdit','numericEdit','date','dateEdit','time','dateTime')--11537 added dateedit control type
											BEGIN	--3
												IF @data_type_tmp	= 'Date' 
												BEGIN--4
													SET @tmp_control_type	= 'dateEdit'
												END--4

												IF @data_type_tmp	= 'Date-time' 
												BEGIN--5
													SET @tmp_control_type	= 'dateTimeEdit'
												END--5

												IF @data_type_tmp	IN ('Numeric','Integer') 
												BEGIN--6
													SET @tmp_control_type	= 'numericEdit'
												END--6

												IF @data_type_tmp	= 'Char' 
												BEGIN--7
													SET @tmp_control_type	= 'StringEdit'
												END--7

												IF @data_type_tmp	= 'time' 
												BEGIN--8
													SET @tmp_control_type	= 'time'
												END--8

												IF @tmp_old_control_type <> @tmp_control_type
												BEGIN
													UPDATE	ngplf_wr_control
													set		ControlTypeName		=	@tmp_control_type
													where	CustomerID			=	@engg_customer_name
													and		ProjectID			=	@engg_project_name
													and		ProcessName			=	@process_name
													and		ComponentName		=	@component_name
													and		BTSynonymName		=	@engg_btsyn_name

													UPDATE	ep_ui_control_dtl
													set		control_type		=	@tmp_control_type
													where	customer_name		=	@engg_customer_name
													and		Project_name		=	@engg_project_name
													and		Process_Name		=	@process_name
													and		Component_Name		=	@component_name
													and		control_bt_synonym	=	@engg_btsyn_name
								
													UPDATE	re_ui_control
													set		control_type		=	@tmp_control_type
													where	customer_name		=	@engg_customer_name
													and		Project_name		=	@engg_project_name
													and		Process_Name		=	@process_name
													and		Component_Name		=	@component_name
													and		control_bt_synonym	=	@engg_btsyn_name

													UPDATE	de_ui_control
													set		control_type		=	@tmp_control_type
													where	customer_name		=	@engg_customer_name
													and		Project_name		=	@engg_project_name
													and		Process_Name		=	@process_name
													and		Component_Name		=	@component_name
													and		control_bt_synonym	=	@engg_btsyn_name
												END
											END--3
										END--2

											IF @data_type_tmp	=	'numeric'
											BEGIN--9
													SELECT	@Tmp_DataLength		=	bt.length,
															@Tmp_DecimalLength	=	decimal_length,
															@Tmp_DataType		=	data_type 
													FROM	de_business_term bt (NOLOCK),
													--left OUTER JOIN	
													de_precision_type pt (NOLOCK) 
													where	bt.customer_name	=	pt.customer_name
													AND		bt.project_name		=	pt.project_name
													AND		bt.process_name		=	pt.process_name
													AND		bt.COMPONENT_NAME	=	pt.component_name
													AND		bt.precision_type	=	pt.pt_name				

													AND		bt.customer_name	=	@engg_customer_name
													AND		bt.project_name		=	@engg_project_name
													AND		bt.process_name		=	@process_name
													AND		bt.COMPONENT_NAME	=	@component_name
													AND		bt.bt_name			=	@engg_btsyn_btname
											END--9
											ELSE
											BEGIN--10
													SELECT	@Tmp_DataLength		=	bt.length,
															@Tmp_DecimalLength	=	null,
															@Tmp_DataType		=	data_type  
													FROM	de_business_term bt (NOLOCK) 					
													Where	 bt.customer_name	=	@engg_customer_name
													AND		bt.project_name		=	@engg_project_name
													AND		bt.process_name		=	@process_name
													AND		bt.COMPONENT_NAME	=	@component_name
													AND		bt.bt_name			=	@engg_btsyn_btname
											END--10

											UPDATE	gl
											set		BTName				=	@engg_btsyn_btname,
													DataType			=	@Tmp_DataType,	
													DataTypeLength		=	@Tmp_DataLength,
													DecimalLength		=	@Tmp_DecimalLength
											from	ngplf_wr_glossary	gl (nolock)
											where	gl.CustomerID		=	@engg_customer_name
											and		gl.ProjectID		=	@engg_project_name
											and		gl.ProcessName		=	@process_name
											and		gl.ComponentName	=	@component_name
											and		gl.BTSynonymName	=	@engg_btsyn_name
						END--1
		END
--Code Added for Defect ID : TECH-39534 Ends
SELECT  @fprowno  'FPROWNO'


SET NOCOUNT OFF

END
GO
IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_bterm_sp_savassyn' AND TYPE = 'P')
BEGIN
		GRANT EXEC ON de_bterm_sp_savassyn TO PUBLIC
END
GO



