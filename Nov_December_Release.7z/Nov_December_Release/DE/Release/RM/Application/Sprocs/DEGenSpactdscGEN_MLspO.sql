IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DEGenSpactdscGEN_MLspO' AND TYPE = 'P')
BEGIN
  DROP PROC DEGenSpactdscGEN_MLspO
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		DEGenSpactdscGEN_MLspO.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : DEGenSpactdscGEN_MLspO                                        */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Muthu Kumar.K                                                 */
/* Date         : 16/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  :          Balaji D                                             */
/* Date         :          Feb 06 2011                                          */
/* Bug Id  :          PLF2.0_00214           */
/* Description  :          Zipped service release                               */
/********************************************************************************************/
/* Modified by  :   Ponmalar A		Date: 01-Dec-2022	Defect ID : TECH-75230				*/
/* Description  :	Provision to retain the existing refinements during service generation. */
/********************************************************************************************/
CREATE PROCEDURE DEGenSpactdscGEN_MLspO
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input
	@ctxt_user engg_ctxt_user, --Input
	@ctxt_language engg_ctxt_language, --Input
	@ctxt_service engg_ctxt_service, --Input
	@data_set_name engg_name, --Input
	@engg_act_descr engg_description, --Input
	@engg_act_pending engg_seqno, --Input
	@engg_act_total engg_seqno, --Input
	@engg_all_pages engg_flag, --Input
	@engg_all_tasks engg_flag, --Input
	@engg_component engg_description, --Input
	@engg_customer_name engg_name, --Input
	@engg_ico_no engg_name, --Input
	@engg_page_descr engg_description, --Input
	@engg_page_pending engg_seqno, --Input
	@engg_page_total engg_seqno, --Input
	@engg_pfx_section engg_name, --Input
	@engg_project_name engg_name, --Input
	@engg_proj_proc_descr engg_description, --Input
	@engg_report_processtype engg_name, --Input
	@engg_report_reportcontext engg_description, --Input
	@engg_report_reportpage engg_description, --Input
	@engg_report_reporttype engg_name, --Input
	@engg_report_segmentinstance engg_name, --Input
	@engg_report_taskname engg_name, --Input
	@engg_task_name engg_name, --Input
	@engg_tc_hdrtask_descr engg_description, --Input
	@engg_tc_page engg_name, --Input
	@engg_tc_section engg_name, --Input
	-- @engg_tsk_pagedesc                      engg_description,  --Input
	@engg_ui_descr engg_description, --Input
	@engg_ui_pending engg_seqno, --Input
	@engg_ui_total engg_seqno, --Input
	@guid engg_guid, --Input
	@hidden_control1 engg_hiddencontrol, --Input
	@hidden_control2 engg_hiddencontrol, --Input
	@ouinstid engg_ouinstid, --Input
	@segment_sequence engg_seqno, --Input
	@timestamp engg_timestamp, --Input
	--  @fprowno                                engg_rowno,  --Input/Output
	@m_errorid INT OUTPUT --To Return Execution Status
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @data_set_name = '~#~'
		SET @data_set_name = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_act_pending = - 915
		SET @engg_act_pending = NULL

	IF @engg_act_total = - 915
		SET @engg_act_total = NULL

	IF @engg_all_pages = '~#~'
		SET @engg_all_pages = NULL

	IF @engg_all_tasks = '~#~'
		SET @engg_all_tasks = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SET @engg_ico_no = NULL

	IF @engg_page_descr = '~#~'
		SET @engg_page_descr = NULL

	IF @engg_page_pending = - 915
		SET @engg_page_pending = NULL

	IF @engg_page_total = - 915
		SET @engg_page_total = NULL

	IF @engg_pfx_section = '~#~'
		SET @engg_pfx_section = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_proj_proc_descr = '~#~'
		SET @engg_proj_proc_descr = NULL

	IF @engg_report_processtype = '~#~'
		SET @engg_report_processtype = NULL

	IF @engg_report_reportcontext = '~#~'
		SET @engg_report_reportcontext = NULL

	IF @engg_report_reportpage = '~#~'
		SET @engg_report_reportpage = NULL

	IF @engg_report_reporttype = '~#~'
		SET @engg_report_reporttype = NULL

	IF @engg_report_segmentinstance = '~#~'
		SET @engg_report_segmentinstance = NULL

	IF @engg_report_taskname = '~#~'
		SET @engg_report_taskname = NULL

	IF @engg_task_name = '~#~'
		SET @engg_task_name = NULL

	IF @engg_tc_hdrtask_descr = '~#~'
		SET @engg_tc_hdrtask_descr = NULL

	IF @engg_tc_page = '~#~'
		SET @engg_tc_page = NULL

	IF @engg_tc_section = '~#~'
		SET @engg_tc_section = NULL

	--  IF @engg_tsk_pagedesc = '~#~'
	--   SET @engg_tsk_pagedesc = null
	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @engg_ui_pending = - 915
		SET @engg_ui_pending = NULL

	IF @engg_ui_total = - 915
		SET @engg_ui_total = NULL

	IF @guid = '~#~'
		SET @guid = NULL

	IF @hidden_control1 = '~#~'
		SET @hidden_control1 = NULL

	IF @hidden_control2 = '~#~'
		SET @hidden_control2 = NULL

	IF @ouinstid = - 915
		SET @ouinstid = NULL

	IF @segment_sequence = - 915
		SET @segment_sequence = NULL

	IF @timestamp = - 915
		SET @timestamp = NULL

	--  IF @fprowno = -915
	--   SET @fprowno = null
	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT TOP 1 @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
	ORDER BY ui_descr

	DECLARE @page_bt_synonym_tmp engg_name

	SELECT @page_bt_synonym_tmp = min(page_bt_synonym)
	FROM de_ui_page NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		-- and  req_no   = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp
		AND horder = 0
		AND vorder = 0

	--Code commented for TECH-75230 starts
	--SELECT CONVERT(VARCHAR(20), ISNULL(b.createddate, GETDATE())) 'engg_gen_last_gen',
	--	(
	--		SELECT count(methodid)
	--		FROM de_fw_des_processsection_br_is c(NOLOCK)
	--		WHERE c.customer_name = @engg_customer_name
	--			AND c.project_name = @engg_project_name
	--			AND c.process_name = @process_name_tmp
	--			AND c.component_name = @component_name_tmp
	--			AND c.servicename = b.servicename
	--		) 'engg_gen_met_count',
	--	b.servicename 'engg_gen_ser_name',
	--	a.task_descr 'engg_gen_task_descr',
	--	a.task_name 'engg_gen_task_name',
	--	a.task_pattern 'engg_gen_task_pattern',
	--	b.remarks 'engg_gen_remarks',
	--	b.isintegser 'engg_gen_is',
	--	--Code Added for the Bug ID: PLF2.0_00214 starts
	--	b.isCached 'engg_iscached',
	--	b.isZipped 'engg_iszipped',
	--	b.ClearKey_Pattern 'engg_clearkey_pattern',
	--	b.SetKey_Pattern 'engg_setkey_pattern',
	--	--Code Added for the Bug ID: PLF2.0_00214 ends
	--	task_seq
	--FROM de_action a(NOLOCK),
	--	de_fw_des_service b(NOLOCK),
	--	de_task_service_map c(NOLOCK)
	--WHERE a.customer_name = @engg_customer_name
	--	AND a.project_name = @engg_project_name
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp
	--	AND a.activity_name = @activity_name_tmp
	--	AND a.ui_name = @ui_name_tmp
	--	AND a.page_bt_synonym = @page_bt_synonym_tmp
	--	AND c.service_name = b.servicename
	--	AND a.customer_name = b.customer_name
	--	AND a.project_name = b.project_name
	--	AND a.process_name = b.process_name
	--	AND a.component_name = b.componentname
	--	AND a.customer_name = c.customer_name
	--	AND a.project_name = c.project_name
	--	AND a.process_name = c.process_name
	--	AND a.component_name = c.component_name
	--	AND a.activity_name = c.activity_name
	--	AND a.ui_name = c.ui_name
	--	AND a.task_name = c.task_name
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_action_reuse_info(NOLOCK)
	--		WHERE a.customer_name = @engg_customer_name
	--			AND a.project_name = @engg_project_name
	--			AND a.process_name = @process_name_tmp
	--			AND a.component_name = @component_name_tmp
	--			AND a.activity_name = @activity_name_tmp
	--			AND a.ui_name = @ui_name_tmp
	--			AND a.page_bt_synonym = @engg_page_descr
	--		)
	
	--UNION
	
	--SELECT '' 'engg_gen_last_gen',
	--	'' 'engg_gen_met_count',
	--	'' 'engg_gen_ser_name',
	--	a.task_descr 'engg_gen_task_descr',
	--	a.task_name 'engg_gen_task_name',
	--	a.task_pattern 'engg_gen_task_pattern',
	--	'' 'engg_gen_remarks',
	--	0 'engg_gen_is',
	--	--Code Added for the Bug ID: PLF2.0_00214 starts
	--	0 'engg_iscached',
	--	0 'engg_iszipped',
	--	'' 'engg_clearkey_pattern',
	--	'' 'engg_setkey_pattern',
	--	--Code Added for the Bug ID: PLF2.0_00214 ends
	--	task_seq
	--FROM de_action a(NOLOCK)
	--WHERE a.customer_name = @engg_customer_name
	--	AND a.project_name = @engg_project_name
	--	AND a.process_name = @process_name_tmp
	--	AND a.component_name = @component_name_tmp
	--	AND a.activity_name = @activity_name_tmp
	--	AND a.ui_name = @ui_name_tmp
	--	AND a.page_bt_synonym = @page_bt_synonym_tmp
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_task_service_map map(NOLOCK),
	--			de_fw_des_service sr(NOLOCK)
	--		WHERE map.customer_name = @engg_customer_name
	--			AND map.project_name = @engg_project_name
	--			AND map.process_name = @process_name_tmp
	--			AND map.component_name = @component_name_tmp
	--			AND map.activity_name = @activity_name_tmp
	--			AND map.ui_name = @ui_name_tmp
	--			AND map.customer_name = sr.customer_name
	--			AND map.project_name = sr.project_name
	--			AND map.process_name = sr.process_name
	--			AND map.component_name = sr.componentname
	--			AND map.service_name = sr.servicename
	--		)
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_taskreuse_info(NOLOCK)
	--		WHERE customer_name = @engg_customer_name
	--			AND project_name = @engg_project_name
	--			AND process_name = @process_name_tmp
	--			AND component_name = @component_name_tmp
	--			AND activity_name = @activity_name_tmp
	--			AND ui_name = @ui_name_tmp
	--			AND page_bt_synonym = @page_bt_synonym_tmp
	--		)
	--	AND a.task_name NOT IN (
	--		SELECT task_name
	--		FROM de_action_reuse_info(NOLOCK)
	--		WHERE a.customer_name = @engg_customer_name
	--			AND a.project_name = @engg_project_name
	--			AND a.process_name = @process_name_tmp
	--			AND a.component_name = @component_name_tmp
	--			AND a.activity_name = @activity_name_tmp
	--			AND a.ui_name = @ui_name_tmp
	--			AND a.page_bt_synonym = @engg_page_descr
	--		)
	--ORDER BY a.task_seq
	--Code commented for TECH-75230 ends

	--Code added for TECH-75230 starts

	--Temp table population
	IF OBJECT_ID('tempdb..#genserdet') IS NOT NULL DROP TABLE #genserdet
	SELECT b.customer_name,
		   b.project_name,
		   b.process_name,
		   b.componentname,
		CONVERT(VARCHAR(20), ISNULL(b.createddate, GETDATE())) 'engg_gen_last_gen',
		b.servicename 'engg_gen_ser_name',
		a.task_descr 'engg_gen_task_descr',
		a.task_name 'engg_gen_task_name',
		a.task_pattern 'engg_gen_task_pattern',
		b.remarks 'engg_gen_remarks',
		b.isintegser 'engg_gen_is',
		--Code Added for the Bug ID: PLF2.0_00214 starts
		b.isCached 'engg_iscached',
		b.isZipped 'engg_iszipped',
		b.ClearKey_Pattern 'engg_clearkey_pattern',
		b.SetKey_Pattern 'engg_setkey_pattern',
		--Code Added for the Bug ID: PLF2.0_00214 ends
		task_seq,
		b.ApplyRefinements 'engg_gen_applyrefine', 
		convert(varchar(60),'')	'mode'
	INTO #genserdet
	FROM de_action a(NOLOCK),
		de_fw_des_service b(NOLOCK),
		de_task_service_map c(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.activity_name = @activity_name_tmp
		AND a.ui_name = @ui_name_tmp
		AND a.page_bt_synonym = @page_bt_synonym_tmp
		AND c.service_name = b.servicename
		AND a.customer_name = b.customer_name
		AND a.project_name = b.project_name
		AND a.process_name = b.process_name
		AND a.component_name = b.componentname
		AND a.customer_name = c.customer_name
		AND a.project_name = c.project_name
		AND a.process_name = c.process_name
		AND a.component_name = c.component_name
		AND a.activity_name = c.activity_name
		AND a.ui_name = c.ui_name
		AND a.task_name = c.task_name
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_action_reuse_info(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_page_descr
			)
	
	UNION
	SELECT a.customer_name,
		   a.project_name,
		   a.process_name,
		   a.component_name,
		   '' 'engg_gen_last_gen',
		   '' 'engg_gen_ser_name',
		a.task_descr 'engg_gen_task_descr',
		a.task_name 'engg_gen_task_name',
		a.task_pattern 'engg_gen_task_pattern',
		'' 'engg_gen_remarks',
		0 'engg_gen_is',
		--Code Added for the Bug ID: PLF2.0_00214 starts
		0 'engg_iscached',
		0 'engg_iszipped',
		'' 'engg_clearkey_pattern',
		'' 'engg_setkey_pattern',
		--Code Added for the Bug ID: PLF2.0_00214 ends
		task_seq,
		0 'engg_gen_applyrefine',
		convert(varchar(60),'')	'mode'	
	FROM de_action a(NOLOCK)
	WHERE a.customer_name = @engg_customer_name
		AND a.project_name = @engg_project_name
		AND a.process_name = @process_name_tmp
		AND a.component_name = @component_name_tmp
		AND a.activity_name = @activity_name_tmp
		AND a.ui_name = @ui_name_tmp
		AND a.page_bt_synonym = @page_bt_synonym_tmp
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_task_service_map map(NOLOCK),
				de_fw_des_service sr(NOLOCK)
			WHERE map.customer_name = @engg_customer_name
				AND map.project_name = @engg_project_name
				AND map.process_name = @process_name_tmp
				AND map.component_name = @component_name_tmp
				AND map.activity_name = @activity_name_tmp
				AND map.ui_name = @ui_name_tmp
				AND map.customer_name = sr.customer_name
				AND map.project_name = sr.project_name
				AND map.process_name = sr.process_name
				AND map.component_name = sr.componentname
				AND map.service_name = sr.servicename
			)
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_taskreuse_info(NOLOCK)
			WHERE customer_name = @engg_customer_name
				AND project_name = @engg_project_name
				AND process_name = @process_name_tmp
				AND component_name = @component_name_tmp
				AND activity_name = @activity_name_tmp
				AND ui_name = @ui_name_tmp
				AND page_bt_synonym = @page_bt_synonym_tmp
			)
		AND a.task_name NOT IN (
			SELECT task_name
			FROM de_action_reuse_info(NOLOCK)
			WHERE a.customer_name = @engg_customer_name
				AND a.project_name = @engg_project_name
				AND a.process_name = @process_name_tmp
				AND a.component_name = @component_name_tmp
				AND a.activity_name = @activity_name_tmp
				AND a.ui_name = @ui_name_tmp
				AND a.page_bt_synonym = @engg_page_descr
			)
	ORDER BY a.task_seq
	
	--Manual services populated in temp table
	IF OBJECT_ID('tempdb..#manualservice') IS NOT NULL DROP TABLE #manualservice
	SELECT  a.customer_name,	a.project_name	,a.process_name	,a.componentname,	engg_gen_ser_name
	INTO	#manualservice
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_fw_des_service b  (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.componentname
	AND		a.engg_gen_ser_name	=	b.servicename		
	LEFT JOIN	de_service_gen_log c (NOLOCK)
	ON		b.customer_name		=	c.customer_name
	AND		b.project_name		=	c.project_name
	AND		b.process_name		=	c.process_name
	AND		b.componentname		=	c.component_name
	AND		b.servicename		=	c.service_name
	WHERE	ISNULL(c.service_name,'') = ''
	AND		ISNULL(engg_gen_task_pattern,'')	<> 'Disposal'
	
	--Manual service -mode updation
	UPDATE #genserdet
	SET		mode = 'Manual'
	FROM	#manualservice	a (NOLOCK)
	JOIN	#genserdet b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.componentname
	AND		a.engg_gen_ser_name	=	b.engg_gen_ser_name
	
	--Manually modified services -mode updation
	UPDATE #genserdet
	SET	mode = 'Manual'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_service_gen_log b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	WHERE	ISNULL(Manually_modified,'N')	=	'Y'

	--Updating refined for the service which is having seq '0' in de_refine_parameter and that 0 params are not available in de_fw_des_br_logical_parameter
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_parameter b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_br_logical_parameter c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.method_name		=	c.method_name
	AND b.parameter_name	=	c.logicalparametername
	WHERE	ISNULL(mode,'')	=	''
	AND		b.sequence_no	=	0
	AND		ISNULL(c.logicalparametername,'') = ''

	--Updating refined for the service which is having seq '0' in de_refine_methods and that 0 methods are not availble in de_fw_des_processsection_br_is
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_methods b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_processsection_br_is c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.method_name		=	c.method_name
	AND b.service_name		=	c.ServiceName
	WHERE	ISNULL(mode,'')	=	''
	AND		b.include_flag	=	0
	AND		ISNULL(c.method_name,'') = ''

	--Updating refined for the service which is having seq '0' in de_refine_process_section and that 0 ProcSec are not available in de_fw_des_processsection_br_is
	UPDATE #genserdet
	SET	mode = 'Refined'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_refine_process_section b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	LEFT JOIN de_fw_des_processsection_br_is c
	ON  b.customer_name		=	c.customer_name
	AND	b.project_name		=	c.project_name
	AND b.process_name		=	c.process_name
	AND b.component_name	=	c.component_name
	AND b.service_name		=	c.ServiceName
	AND b.ps_name			=	c.SectionName
	WHERE	ISNULL(mode,'')	=	''
	AND		b.sequence_no	=	0
	AND		ISNULL(c.sectionname,'') = ''

	--Generate services -mode updation - for Manually_modified null and N
	UPDATE #genserdet
	SET	mode = 'Generated'
	FROM	#genserdet	a (NOLOCK)
	JOIN	de_service_gen_log b (NOLOCK)
	ON		a.customer_name		=	b.customer_name
	AND		a.project_name		=	b.project_name
	AND		a.process_name		=	b.process_name
	AND		a.componentname		=	b.component_name
	AND		a.engg_gen_ser_name	=	b.service_name
	WHERE	ISNULL(Manually_modified,'N')	=	'N'
	AND		ISNULL(mode,'')	=	''

	--Out from Temp table
	SELECT engg_gen_last_gen 'engg_gen_last_gen',
			CASE WHEN mode <> 'Manual' THEN (
			SELECT count(distinct method_name)
			FROM de_refine_methods c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.service_name = b.engg_gen_ser_name
			)
			ELSE (
			SELECT count(methodid)
			FROM de_fw_des_processsection_br_is c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.servicename = b.engg_gen_ser_name
			) END 'engg_gen_met_count',
		engg_gen_ser_name 'engg_gen_ser_name',
		engg_gen_task_descr 'engg_gen_task_descr',
		engg_gen_task_name 'engg_gen_task_name',
		engg_gen_task_pattern 'engg_gen_task_pattern',
		engg_gen_remarks 'engg_gen_remarks',
		engg_gen_is 'engg_gen_is',
		engg_iscached 'engg_iscached',
		engg_iszipped 'engg_iszipped',
		engg_clearkey_pattern 'engg_clearkey_pattern',
		engg_setkey_pattern 'engg_setkey_pattern',
		task_seq,
		mode		'engg_gen_mode',	
		engg_gen_applyrefine 'engg_gen_applyrefine', 
		CASE WHEN mode= 'Refined' THEN (
			SELECT count(methodid)
			FROM de_fw_des_processsection_br_is c(NOLOCK)
			WHERE c.customer_name = @engg_customer_name
				AND c.project_name = @engg_project_name
				AND c.process_name = @process_name_tmp
				AND c.component_name = @component_name_tmp
				AND c.servicename = b.engg_gen_ser_name
			) ELSE '' END  'engg_gen_refine_met_count' 
		FROM #genserdet b
		WHERE	 b.customer_name	= @engg_customer_name
		AND      b.project_name		= @engg_project_name
		AND      b.process_name		= @process_name_tmp
		AND      b.componentname	= @component_name_tmp
	--Code added for TECH-75230 ends


	/*
--OuputList
Select null 'fprowno',
null 'engg_gen_is',
null 'engg_gen_last_gen',
null 'engg_gen_met_count',
null 'engg_gen_remarks',
null 'engg_gen_ser_name',
null 'engg_gen_task_descr',
null 'engg_gen_task_name',
null 'engg_gen_task_pattern' from ***
*/
	SET NOCOUNT OFF
END
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DEGenSpactdscGEN_MLspO' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON DEGenSpactdscGEN_MLspO TO PUBLIC
END
GO


