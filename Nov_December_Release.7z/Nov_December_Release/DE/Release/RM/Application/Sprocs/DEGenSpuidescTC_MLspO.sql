IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DEGenSpuidescTC_MLspO' AND TYPE = 'P')
BEGIN
  DROP PROC DEGenSpuidescTC_MLspO
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		DEGenSpuidescTC_MLspO.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : DEGenSpuidescTC_MLspO                                         */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Muthu Kumar.K                                                 */
/* Date         : 16/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230  */
/********************************************************************************/
CREATE PROCEDURE DEGenSpuidescTC_MLspO
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input 
	@ctxt_user engg_ctxt_user, --Input 
	@ctxt_language engg_ctxt_language, --Input 
	@ctxt_service engg_ctxt_service, --Input 
	@data_set_name engg_name, --Input 
	@engg_act_descr engg_description, --Input 
	@engg_act_pending engg_seqno, --Input 
	@engg_act_total engg_seqno, --Input 
	@engg_all_pages engg_flag, --Input 
	@engg_all_tasks engg_flag, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_ico_no engg_name, --Input 
	@engg_page_descr engg_description, --Input 
	@engg_page_pending engg_seqno, --Input 
	@engg_page_total engg_seqno, --Input 
	@engg_pfx_section engg_name, --Input 
	@engg_project_name engg_name, --Input 
	@engg_proj_proc_descr engg_description, --Input 
	@engg_report_processtype engg_name, --Input 
	@engg_report_reportcontext engg_description, --Input 
	@engg_report_reportpage engg_description, --Input 
	@engg_report_reporttype engg_name, --Input 
	@engg_report_segmentinstance engg_name, --Input 
	@engg_report_taskname engg_name, --Input 
	@engg_task_name engg_name, --Input 
	@engg_tc_hdrtask_descr engg_description, --Input 
	@engg_tc_page engg_name, --Input 
	@engg_tc_section engg_name, --Input 
	--	@engg_tsk_pagedesc                      engg_description,  --Input 
	@engg_ui_descr engg_description, --Input 
	@engg_ui_pending engg_seqno, --Input 
	@engg_ui_total engg_seqno, --Input 
	@guid engg_guid, --Input 
	@hidden_control1 engg_hiddencontrol, --Input 
	@hidden_control2 engg_hiddencontrol, --Input 
	@ouinstid engg_ouinstid, --Input 
	@segment_sequence engg_seqno, --Input 
	@timestamp engg_timestamp, --Input
	--	@fprowno                                engg_rowno,  --Input/Output  
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))

	--null checking
	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @data_set_name = '~#~'
		SET @data_set_name = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_act_pending = - 915
		SET @engg_act_pending = NULL

	IF @engg_act_total = - 915
		SET @engg_act_total = NULL

	IF @engg_all_pages = '~#~'
		SET @engg_all_pages = NULL

	IF @engg_all_tasks = '~#~'
		SET @engg_all_tasks = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SET @engg_ico_no = NULL

	IF @engg_page_descr = '~#~'
		SET @engg_page_descr = NULL

	IF @engg_page_pending = - 915
		SET @engg_page_pending = NULL

	IF @engg_page_total = - 915
		SET @engg_page_total = NULL

	IF @engg_pfx_section = '~#~'
		SET @engg_pfx_section = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_proj_proc_descr = '~#~'
		SET @engg_proj_proc_descr = NULL

	IF @engg_report_processtype = '~#~'
		SET @engg_report_processtype = NULL

	IF @engg_report_reportcontext = '~#~'
		SET @engg_report_reportcontext = NULL

	IF @engg_report_reportpage = '~#~'
		SET @engg_report_reportpage = NULL

	IF @engg_report_reporttype = '~#~'
		SET @engg_report_reporttype = NULL

	IF @engg_report_segmentinstance = '~#~'
		SET @engg_report_segmentinstance = NULL

	IF @engg_report_taskname = '~#~'
		SET @engg_report_taskname = NULL

	IF @engg_task_name = '~#~'
		SET @engg_task_name = NULL

	IF @engg_tc_hdrtask_descr = '~#~'
		SET @engg_tc_hdrtask_descr = NULL

	IF @engg_tc_page = '~#~'
		SET @engg_tc_page = NULL

	IF @engg_tc_section = '~#~'
		SET @engg_tc_section = NULL

	-- 	IF @engg_tsk_pagedesc = '~#~' 
	-- 		SET @engg_tsk_pagedesc = null  
	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	IF @engg_ui_pending = - 915
		SET @engg_ui_pending = NULL

	IF @engg_ui_total = - 915
		SET @engg_ui_total = NULL

	IF @guid = '~#~'
		SET @guid = NULL

	IF @hidden_control1 = '~#~'
		SET @hidden_control1 = NULL

	IF @hidden_control2 = '~#~'
		SET @hidden_control2 = NULL

	IF @ouinstid = - 915
		SET @ouinstid = NULL

	IF @segment_sequence = - 915
		SET @segment_sequence = NULL

	IF @timestamp = - 915
		SET @timestamp = NULL

	-- 	IF @fprowno = -915
	-- 		SET @fprowno = null 
	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	DECLARE @page_bt_synonym_combo_tmp engg_name

	SELECT @page_bt_synonym_combo_tmp = min(page_bt_synonym)
	FROM de_ui_page NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		--	and		req_no			= @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp

	DECLARE @task_name_combo_tmp engg_name

	SELECT @task_name_combo_tmp = tname
	FROM (
		SELECT TOP 1 task_name 'tname'
		FROM de_action NOLOCK
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @process_name_tmp
			AND component_name = @component_name_tmp
			AND activity_name = @activity_name_tmp
			AND ui_name = @ui_name_tmp
			AND page_bt_synonym = @engg_page_descr
			AND task_name NOT IN (
				SELECT task_name
				FROM de_taskreuse_info(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @process_name_tmp
					AND component_name = @component_name_tmp
					AND activity_name = @activity_name_tmp
					AND ui_name = @ui_name_tmp
					AND page_bt_synonym = @engg_page_descr
				)
		ORDER BY task_seq
		) a

	-- 
	-- 	declare @map_flag_tmp 			int
	-- 	declare @map_ml_flag_tmp 		int
	-- 	declare	@page_bt_synonym_tmp 	engg_name
	-- 	declare @section_bt_synonym_tmp engg_name 
	-- 	declare	@task_name_tmp 			engg_name
	-- 	declare @control_bt_synonym_tmp	engg_name
	-- 	declare @ord_flg				int
	-- 	
	-- 	select @guid = newid()
	-- 
	-- 
	-- 	declare curActSecCtl cursor for 
	-- 		select 	a.page_bt_synonym ,
	-- 				a.section_bt_synonym ,
	-- 				b.task_name ,
	-- 				a.column_bt_synonym
	-- 		from 	de_ui_control_dtl_vw a ,
	-- 				ep_published_action_section_map_vw b
	-- 		where 	a.customer_name	= @engg_customer_name
	-- 		and		a.project_name	= @engg_project_name	
	-- 		and		a.process_name	= @process_name_tmp
	-- 		and		a.component_name= @component_name_tmp
	-- 		and 	a.activity_name	= @activity_name_tmp
	-- 		and		a.ui_name		= @ui_name_tmp
	-- 		and		b.task_name 	= @task_name_combo_tmp 
	-- 		--and		a.page_bt_synonym = @engg_tc_page	
	-- 		--and		a.section_bt_synonym = @engg_tc_section
	-- 		and 	a.customer_name	*= b.customer_name
	-- 		and		a.project_name	*= b.project_name
	-- 		and		a.req_no		*= b.req_no
	-- 		and		a.process_name	*= b.process_name
	-- 		and		a.component_name*= b.component_name
	-- 		and 	a.activity_name	*= b.activity_name
	-- 		and		a.ui_name		*= b.ui_name
	-- 		and		a.section_bt_synonym *= b.section_bt_synonym	
	-- 		and 	a.base_ctrl_type <>'grid'	
	-- 
	-- 	open curActSecCtl
	-- 	
	-- 	fetch next from curActSecCtl into 
	-- 		@page_bt_synonym_tmp , @section_bt_synonym_tmp , 
	-- 		@task_name_tmp , @control_bt_synonym_tmp
	-- 
	-- 	while @@fetch_status = 0
	-- 	begin
	-- 		-- if the task is not mapped to 'ep_published_action_section_map_vw' table
	-- 		-- or 'de_task_control_map' table to 
	-- 		-- show that record at last(@ord_flg = 2) set flags as not set(not checked)
	-- 		-- show this at last
	-- 		select @ord_flg = 2
	-- 		select @map_flag_tmp = 0 
	-- 		select @map_ml_flag_tmp = 0 
	-- 		
	-- 		-- this task is alredy mapped in this 'ep_published_action_section_map_vw' table
	-- 		-- then show it at the top and mapped recirds
	-- 		-- show this after mapped records in 'de_task_control_map' table
	-- 		if @task_name_tmp is not null  
	-- 		begin
	-- 			select @ord_flg = 1
	-- 			select @map_flag_tmp = 0 
	-- 			select @map_ml_flag_tmp = 0 
	-- 		end
	-- 
	-- 		select @task_name_tmp = @task_name_combo_tmp
	-- 		-- check the the selected task is alredy mapped in 'de_task_control_map' 
	-- 		-- the current page ,section and control 
	-- 		if exists ( select 'x' from de_task_control_map nolock	
	-- 					where 	customer_name	= @engg_customer_name
	-- 					and		project_name	= @engg_project_name	
	-- 					and		process_name	= @process_name_tmp
	-- 					and		component_name  = @component_name_tmp
	-- 					and 	activity_name	= @activity_name_tmp
	-- 					and		ui_name			= @ui_name_tmp
	-- 					and		action_name 	= @task_name_combo_tmp 
	-- 					and		page_name = @page_bt_synonym_tmp	
	-- 					and		section_name = @section_bt_synonym_tmp
	-- 					and		control_bt_synonym = @control_bt_synonym_tmp )
	-- 		begin
	-- 				-- if the the selected task is alredy mapped 
	-- 				-- to the current page ,section, and control. 
	-- 				-- if mapped  to display the record at the top 
	-- 				-- set this @ord_flg = 0
	-- 				
	-- 				select @ord_flg = 0  
	-- 				-- save the selected task in temperary variable, if it is not there it will
	-- 				select @task_name_tmp = @task_name_combo_tmp
	-- 				select 	@map_flag_tmp = case map_flag when 'Y' then 1 when 'N' then 0 end ,
	-- 						@map_ml_flag_tmp = case map_ml_flag when 'Y' then 1 when 'N' then 0 end
	-- 
	-- 		from de_task_control_map ( nolock	)
	-- 				where 	customer_name	= @engg_customer_name
	-- 				and		project_name	= @engg_project_name	
	-- 				and		process_name	= @process_name_tmp
	-- 				and		component_name  = @component_name_tmp
	-- 				and 	activity_name	= @activity_name_tmp
	-- 				and		ui_name			= @ui_name_tmp
	-- 				and		action_name 	= @task_name_tmp 
	-- 				and		page_name = @page_bt_synonym_tmp	
	-- 				and		section_name = @section_bt_synonym_tmp
	-- 				and		control_bt_synonym = @control_bt_synonym_tmp
	-- 			
	-- 		end		
	-- 		
	-- 		insert into de_task_control_map_tmp 
	-- 		(	timestamp , createdby , createddate , modifiedby , modifieddate ,
	-- 			guid , ord_flg , page_bt_synonym , section_bt_synonym , task_name ,
	-- 			control_bt_synonym , map_flag , map_ml_flag )
	-- 		values 
	-- 		(	1 , @ctxt_user , getdate() , @ctxt_user , getdate() , 
	-- 			@guid , @ord_flg , @page_bt_synonym_tmp , @section_bt_synonym_tmp , @task_name_tmp , 
	-- 			@control_bt_synonym_tmp , @map_flag_tmp , @map_ml_flag_tmp )
	-- 	
	-- 		fetch next from curActSecCtl into 
	-- 		@page_bt_synonym_tmp , @section_bt_synonym_tmp , 
	-- 		@task_name_tmp , @control_bt_synonym_tmp
	-- 
	-- 	end	
	-- 	
	-- 	close curActSecCtl
	-- 	deallocate curActSecCtl
	-- 
	-- 	select 	map_ml_flag				'engg_map_all' ,
	-- 			map_flag				'engg_map_flag' ,
	-- 			control_bt_synonym		'engg_tc_ctrl_bts' ,
	-- 			page_bt_synonym			'engg_tc_page_name' ,
	-- 			section_bt_synonym		'engg_tc_sec_name' ,
	-- 			task_name				'engg_tc_task_name'
	-- 	from 	de_task_control_map_tmp nolock
	-- 	where 	guid = @guid order by ord_flg
	-- 
	-- 	delete from  de_task_control_map_tmp where guid = @guid
	--
	SELECT CASE map_ml_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_all',
		CASE map_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_flag',
		control_bt_synonym 'engg_tc_ctrl_bts',
		page_name 'engg_tc_page_name',
		section_name 'engg_tc_sec_name',
		action_name 'engg_tc_task_name',
		mapping_instance 'engg_mapping_instance',
		CASE [Load] WHEN 'Y' THEN 1 ELSE 0 END 'engg_tc_load', ---TECH-75230
		control_type 'engg_tc_ctrl_type'	--TECH-75230
	-- 			@fprowno			'fprowno'
	FROM de_task_control_map(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp
		AND action_name = @task_name_combo_tmp

	/* 
	--OuputList
	Select null 'fprowno', 
	null 'engg_mapping_instance', 
	null 'engg_map_all', 
	null 'engg_map_flag', 
	null 'engg_tc_ctrl_bts', 
	null 'engg_tc_page_name', 
	null 'engg_tc_sec_name', 
	null 'engg_tc_task_name' from *** 
*/
	SET NOCOUNT OFF
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DEGenSpuidescTC_MLspO' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON DEGenSpuidescTC_MLspO TO PUBLIC
END
GO
