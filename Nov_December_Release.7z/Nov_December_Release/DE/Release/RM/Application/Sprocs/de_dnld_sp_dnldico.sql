IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_dnld_sp_dnldico' AND TYPE = 'P')
BEGIN
	DROP PROC de_dnld_sp_dnldico
END
GO
/***************************************************************************************  
Procedure Name And Id            :     de_dnld_sp_dnldico  
Description                      :  
Name Of The Author               :  
Date Created                     :     12/8/03  
Query File Name                  :  de_dnld_sp_dnldico.sql  
Modifications History            :  
Modified Date                    :  
modified purpose                 :  
Detailed Description             :  
***************************************************************************************/  
/* modified by  : Balaji S                                                     */  
/* date         : 05/07/2005                                                          */  
/* description  : Inserting Blank instead of ecr in de_ui_ico table        */  
/* BugID : PNR2.0_3142             */  
/**************************************************************************************/  
/* modified by  : Sangeetha L                                                    */  
/* date         : 12/07/2005                                                          */  
/* description  : On downloading the direct ECR no error is displayed but on         */  
/*      seeing the status of the ECR it is still in pending.*/  
/* BugID  : PNR2.0_3232            */  
/**************************************************************************************/  
/* modified by  : Balaji S                                                     */  
/* date         : 12/07/2005                                                          */  
/* description  : Validation added to Download the Previous ECR         */  
/* BugID  : PNR2.0_3216            */  
/**************************************************************************************/  
/* modified by  : Balaji S                                                     */  
/* date         : 13/07/2005                                                          */  
/* description  : Downloading Ecr Takes Time            */  
/* BugID  : PNR2.0_3240                */  
/* modified by  : Shriram.V                                                         */  
/* date         : 27/07/2005                                                          */  
/* description  : Please select atleast one record for download error comes even after selecting a row */  
/* BugID  : PNR2.0_3375                */  
/**************************************************************************************/  
/* BugID  : PNR2.0_3383                */  
/* modified by  : Saravanan                                                         */  
/* date         : 28/07/2005                                                          */  
/* description  : After click of download, ECR is not getting downloaded. */  
/* Modified by : Shriram V for callid PNR2.0_3616    */  
/* Modified on : 22/08/05        */  
/* Description : Length of BT Synonym Caption should not Exceed 60 Characters- */  
/*Validation to be put in RCN download/Publish and ECR download/Publish  */  
/**************************************************************************************/  
/* Modified by : Sageetha L                 */  
/* Modified on : 23/09/2005                 */  
/**************************************************************************************/  
/* Modified by : Sageetha L                 */  
/* Modified on : 20/10/2006                 */  
/* Description : PNR2.0_5621                */  
/**************************************************************************************/  
/* Modified by : Sageetha L                 */  
/* Modified on : 08/03/2006                 */  
/* Description : PNR2.0_6964                */  
/**************************************************************************************/  
/* Modified by : Sageetha L                 */  
/* Modified on : 13/03/2006                 */  
/* Description : PNR2.0_7112                */  
/**************************************************************************************/  
/* Modified by : Sageetha L                 */  
/* Modified on : 13/03/2006                 */  
/* Description : PNR2.0_7894                */  
/**************************************************************************************/  
/* modified by          : Sangeetha L For BugId :PNR2.0_8466                     */  
/* date                 : 15/05/2006                                            */  
/* description          : On download of ECR, Workflow Controls to be added for the UI for which workflow inputs have been given.           */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Chanheetha N A      29-Aug-2006    PNR2.0_10064              */  
/**************************************************************************************/  
/* Modified by : Feroz                */  
/* Modified on : 08/11/06               */  
/* Description : State Processing             */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Kiruthika R         18-Dec-2006    PNR2.0_11435              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Kiruthika R         19-Dec-2006    PNR2.0_11451              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Balaji S           16-Jan-2007    PNR2.0_11836              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Gowrisankar M         27-Jan-2007    PNR2.0_12009              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Balaji S           07-Feb-2007    PNR2.0_12133              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Balaji S           07-May-2007    PNR2.0_13557              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* chanheetha N A         11-May-2007    PNR2.0_13622              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Balaji S           05-Jun-2007    PNR2.0_13973              */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Anuradha M           22-Aug-2007    PNR2.0_15050               */  
/**************************************************************************************/  
/* Modified by      Date     Bug ID       */  
/* Gowrisankar M     22-Aug-2007    PNR2.0_15562        */  
/**************************************************************************************/  
/* modified by   : Chanheetha N A        */  
/* date     : 17-nov-2007         */  
/* BugId    : PNR2.0_16023          */  
/************************************************************************/  
/* modified by    : Sangeetha G         */  
/* date     : 28-nov-2007         */  
/* BugId    : PNR2.0_16082         */  
/************************************************************************/  
/* modified by     : Sangeetha G         */  
/* date       : 12-Mar-2008         */  
/* BugId      : PNR2.0_17182          */  
/************************************************************************/  
/* modified by     : Sangeetha G             */  
/* date     : 7-May-2008             */  
/* BugId      : PNR2.0_17846             */  
/* Modified For     : To populate the table de_comp_doc_status      */  
/************************************************************************/  
/* modified by     : Sangeetha G                                        */  
/* date           : 6-Oct-2008                                         */  
/* BugId           : PNR2.0_19527                                       */  
/* Modified For    : To  include BT -'plf_hdn_ctrl_bt'   in the model   */  
/************************************************************************/  
/* modified by     : Sangeetha G                                        */  
/* date           : 10-Oct-2008                                         */  
/* BugId           : PNR2.0_19576                                       */  
/************************************************************************/  
/* modified by     : Praveen kumar A                                       */  
/* date           : 23-Oct-2008                                         */  
/* BugId           : PNR2.0_19781                                      */  
/************************************************************************/  
/* modified by     : Gopinath S           */  
/* date            : 09-Dec-2008                                        */  
/* BugId           : PNR2.0_20277                                       */  
/************************************************************************/  
/* modified by     : Sangeetha G           */  
/* date            : 12-Dec-2008                                        */  
/* BugId           : PNR2.0_20298                                       */  
/* modified for    : While generating the services workflow methods     */  
/*                   are not created .         */  
/************************************************************************/  
/* modified by  : Feroz                                                 */  
/* date         : 28-Oct-2008                                           */  
/* Bug Id   : PNR2.0_1790           */  
/************************************************************************/  
/* Modified By       : Sangeetha G          */  
/* Date     : Sep 17 2010                   */  
/* Bug Id    : PNR2.0_28333                                     */  
/* Description       : Ezee view page for Platform                      */  
/***************************************************************************/  
/* modified by  : Jeyalatha K            */  
/* date    : 11-Feb-2011                                           */  
/* Bug Id   : PNR2.0_30127           */  
/* Modified for  : Feature  Release          */  
/*************************************************************************************/  
/* modified by  : Muthupandi S              */  
/* date         : 01-August-2011              */  
/* Bug ID  : PNR2.0_32554                    */  
/* Description : While removing any column,the mapped hidden view should get deleted with its */  
/*     ILBO association                */  
/*************************************************************************************/  
/* modified by  : Muthupandi S              */  
/* date         : 03-August-2011              */  
/* Bug ID  :  PNR2.0_32751                */  
/* Description  :  Modification in ILBO association deletion for enumerated combos  */  
/*************************************************************************************/  
/* modified by  : Veena U              */  
/* date         : 25-Feb-2015              */  
/* Bug ID  :  PLF2.0_11499                */  
/* Description  :  Changes for tab_type,New_Line_Ui  */  
/********************************************************************************/    
/* Modified by  : Veena U                                                   */  
/* Date         : 07-Aug-2015                          */  
/* Defect ID : PLF2.0_14096                                                 */  
/********************************************************************************/  
 /* Modified by  : Veena U                                                   */  
/* Date         : 24-Dec-2015*/  
/* Defect ID : PLF2.0_16153  */  
/********************************************************************************/  
/* Modified by  : Veena U                                                  */  
/* Date         : 24-Feb-2016                                                 */  
/* Defect ID : PLF2.0_16291                                                */  
/********************************************************************************/    
/* Created by   : Veena U                                                */  
/* Date         : 28-Mar-2016                                                  */  
/*Defect Id  : PLF2.0_17570          */  
/********************************************************************************/   
/* modified by   Date    Defect ID       */  
/* Veena U    08-Jun-2016   PLF2.0_18487      */  
/********************************************************************************/  
/* Modified by : Jeya Latha K/Ganesh Prabhu S for callid TECH-7349    */  
/* Modified on : 14-03-2017                */  
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */  
/***********************************************************************************/  
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */  
/* Modified on : 30-May-2017                                                                                        */  
/* Description : Platform Feature Release                                                              */  
/********************************************************************************/  
/* Modified by : Venkatesan K      for callid  TECH-20275                   */  
/* Modified on : 04-Apr-2018                                                                                        */  
/* Description : Performance Tunning                                                            */  
/********************************************************************************/  
/*Modified by : Ranjitha R   Defect ID: TECH-20897      On: 30-Apr-2018 */  
/********************************************************************************/  
/* Modified by  : Jeya Latha K Date: 30-Apr-2018  Defect ID : TECH-20897 */    
/********************************************************************************/  
/* Modified by  :  Venkatesan K                                                  */  
/* Date         :  10_05_2018                                                    */  
/* Description  :  Batch id table updation for batch track purpose.     */  
/* case id  :  TECH-20631              */  
/* Modified by  : Jeya Latha K/Venkatesan K Date: 31-Oct-2018  Defect ID : TECH-28010 */  
/* Modified by  : Jeya Latha K   Date: 25-Jul-2019  Defect ID: TECH-36371     */  
/* Modified by  : Ganesh Prabhu S  Date: 15-Oct-2019  Defect ID: TECH-38859     */  
/**************************************************************************************/  
/* Modified by : Venkatesan K       Date: 08-Nov-2019  Defect ID: TECH-39810 */  
/*************************************************************************************************/  
/* Modified by : Hareesh K/Jeya Latha K               Date: 04-Dec-2019  Defect ID : TECH-40809  */   
/* Modified by : Jeya Latha K                         Date: 29-Jan-2020  Defect ID : TECH-42483  */  
/* Modified by : Ganesh Prabhu S                      Date: 10-Mar-2022  Defect ID : TECH-66990  */  
/*************************************************************************************************/ 
/* Modified by	:	VimalKumar R																 */
/* Modified on	:	11/07/22				 													 */
/* Defect ID	:	TECH-70687																	 */
/* Description	:	Tool and Toolbars															 */
/*************************************************************************************************/
/* Modified by	:	Priyadharshini U															 */
/* Modified on	:	23-Aug-2022				 													 */
/* Defect ID	:	TECH-72114																	 */
/* Description	:	Provision to upload mobility config xml, template and CSS into model and	 */
/*					integrating with mobility code generator									 */
/*************************************************************************************************/
/* Modified by : Ponmalar A							  Date: 01-Dec-2022  Defect ID : TECH-75230  */  
/*************************************************************************************************/ 
CREATE PROCEDURE de_dnld_sp_dnldico  
@Ctxt_Language               engg_Ctxt_Language,  
@ctxt_OUInstance             engg_ctxt_OUInstance,  
@Ctxt_Service                engg_Ctxt_Service,  
@ctxt_User                   engg_ctxt_User,  
@engg_customer_name          engg_name,  
@engg_ico_descr              engg_description,  
@engg_ico_no                 engg_name,  
@engg_ico_status             engg_name,  
@engg_project_name           engg_name,  
@ModeFlag                    engg_ModeFlag,  
@fpRowNo                     engg_RowNo,  
@m_errorid                   engg_seqno     out  
as  
begin  -- nocount should be switched on to prevent phantom rows  
set nocount on  
  
-- @m_errorid should be 0 to indicate success  
select @m_errorid =0  
  
select     @Ctxt_Language          =     ltrim(rtrim(@Ctxt_Language))  
select     @ctxt_OUInstance        =     ltrim(rtrim(@ctxt_OUInstance))  
select     @Ctxt_Service           =     upper(ltrim(rtrim(@Ctxt_Service)))  
select     @ctxt_User              =     upper(ltrim(rtrim(@ctxt_User)))  
select     @engg_customer_name     =     upper(ltrim(rtrim(@engg_customer_name)))  
select     @engg_ico_descr         =     upper(ltrim(rtrim(@engg_ico_descr)))  
select     @engg_ico_no			   =     upper(ltrim(rtrim(@engg_ico_no)))  
select     @engg_project_name      =     upper(ltrim(rtrim(@engg_project_name)))  
select     @ModeFlag               =     upper(ltrim(rtrim(@ModeFlag)))  
select     @fpRowNo                =     ltrim(rtrim(@fpRowNo))  
  
if   @Ctxt_Language          = '-915'         select       @Ctxt_Language          =    null  
if   @ctxt_OUInstance        = '-915'         select       @ctxt_OUInstance   =    null  
if   @Ctxt_Service           = '~#~'          select       @Ctxt_Service           =    null  
if   @ctxt_User              = '~#~'          select       @ctxt_User              =    null  
if   @engg_customer_name     = '~#~'          select       @engg_customer_name     =    null  
if   @engg_ico_descr         = '~#~'          select       @engg_ico_descr         =    null  
if   @engg_ico_no            = '~#~'          select       @engg_ico_no            =    null  
if   @engg_project_name      = '~#~'          select       @engg_project_name      =    null  
if   @ModeFlag               = '~#~'          select       @ModeFlag               =    null  
if   @fpRowNo                = '-915'         select       @fpRowNo                =    null  
  
  
--temporary variables declaration  
declare @ecr_no_tmp    engg_name,  
@process_name_tmp  engg_name,  
@component_name_tmp  engg_name,  
@activity_name_tmp  engg_name,  
@ui_name_tmp   engg_name,  
@ecr_status    engg_name,  
@vartmp     engg_description,  
@msg     engg_description,  
@count_temp    engg_seqno,  
@date     engg_date,  
@ecr_number    engg_name,  
@ecr_no     engg_name,  
@ecrno     engg_name,  
@processname   engg_name,  
@componentname   engg_name,  
@activityname   engg_name,  
@uiname     engg_name,  
@rcnno_tmp    engg_name,  
@modifieddate_tmp  engg_date , @pre_ico_no             engg_name  
Set @date = getdate()  
  
--final select  
  
select @fpRowNo = @fpRowNo + 1  
--Added by Saravanan on 28/07/2005 for Bug Id : PNR2.0_3383 - START  
if   @ModeFlag <> 'Z'  
begin  
--Added by Shriram V on 27/07/2005 for Bug Id : PNR2.0_3375  
select @fpRowNo   'FPROWNO'  
return  
end  
--Added by Saravanan on 28/07/2005 for Bug Id : PNR2.0_3383 - END  
If exists (Select 'x' from de_ecr_publish_chk (nolock)  
where work_flag = 'D'  
and   customer_name = @engg_customer_name  
and   project_name  = @engg_project_name)  
begin  
Select @msg = ecr_no +  'is being downloaded by ' + publ_username +  ' from ' + convert(varchar(2),datepart (hh,start_time)) + ':'+ convert(varchar(2),datepart (mm,start_time))  
+ ':'+ cast(datepart (ss,start_time)as varchar(2)) + 'onwards. Please wait...'  
from de_ecr_publish_chk (nolock)  
where work_flag = 'D'  
exec   engg_error_sp 'de_dnld_sp_dnldico', 1, @msg ,  
@ctxt_language, @ctxt_ouinstance, @ctxt_service, @ctxt_user,  
'', '', '', '', @m_errorid  
return  
end  
  
  
Insert into de_ecr_publish_chk  
(customer_name,   project_name,  ecr_no,   publ_username,   start_time,  host_mcname,  work_flag)  
values  
(@engg_customer_name, @engg_project_name, @engg_ico_no,    @ctxt_user,    @date,  host_name(),  'D')  
  
-- code added for PNR2.0_15050  
select  @ecr_status   =  ECRType  
from  fw_rmt_ecr_vw (nolock)  
where  CustomerID   = @engg_customer_name  
and   ProjectID   = @engg_project_name  
and   ECRNumber   = @engg_ico_no  
  
-- Code modified by Gowrisankar for PNR2.0_15562 on 05-Oct-2007  
create table #de_rmt_ico_ui_tmp  
( customer_name   varchar(60) collate database_default,  
project_name    varchar(60) collate database_default,  
ico_no  varchar(60) collate database_default,  
ecr_no  varchar(60) collate database_default,  
process_name  varchar(60) collate database_default,  
component_name varchar(60) collate database_default,  
activity_name  varchar(60) collate database_default,  
ui_name   varchar(60) collate database_default,  
ico_descr  varchar(255) collate database_default,  
process_descr  varchar(255) collate database_default,  
component_descr  varchar(255) collate database_default,  
activity_descr  varchar(255) collate database_default,  
ui_descr  varchar(255) collate database_default  
)  
-- Code modified by Gowrisankar for PNR2.0_15562 on 05-Oct-2007  
  
if @ecr_status <> 'dir'  
begin  
declare @rcn_tmp as engg_name  
  
select  @rcn_tmp = rcnnumber  
from  fw_rmt_rcn_ecr_details (nolock)  
where  customerid  = @engg_customer_name  
and  projectid  = @engg_project_name  
and  ecrnumber  = @engg_ico_no  
  
  
insert  into #de_rmt_ico_ui_tmp  
select  distinct  a.customer_name,  a.project_name,  a.ico_no,   a.ecr_no,  
a.process_name,  a.component_name,  a.activity_name, a.ui_name,  
a.ico_descr,   a.process_descr,  a.component_descr,a.activity_descr,  
a.ui_descr  
from   de_rmt_ico_ui_vw a(nolock),  
re_ui_ecr b(nolock)  
where  a.customer_name = @engg_customer_name  
and   a.project_name  = @engg_project_name  
and   a.ico_no    = @engg_ico_no  
and   b.customer_name = a.customer_name  
and   b.project_name  = a.project_name  
and   b.process_name  = a.process_name  
and   b.ecr_no    = @rcn_tmp  
end  
else  
begin  
insert  into #de_rmt_ico_ui_tmp  
select  distinct  customer_name,  project_name,  ico_no,   ecr_no,  
process_name,  component_name,  activity_name, ui_name,  
ico_descr,   process_descr,  component_descr,activity_descr,  
ui_descr  
from   de_rmt_ico_ui_vw (nolock)  
where  customer_name  = @engg_customer_name  
and   project_name  = @engg_project_name  
and   ico_no    = @engg_ico_no  
end  
  
--   code added for PNR2.0_15050  
select @count_temp = 0  
  
select @count_temp = count(distinct component_name)  
from #de_rmt_ico_ui_tmp (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  ico_no   = @engg_ico_no  
  
  
if @count_temp > 1  
begin  
exec engg_error_sp  
'de_dnld_sp_dnldico',1,'Cannot Download this ECR as it is mapped to more than one component.' ,@ctxt_language,  
@ctxt_ouinstance,@ctxt_service,@ctxt_user,'','','','',@m_errorid out  
return  
end  

if @count_temp = 0  
begin  
exec engg_error_sp  
'de_dnld_sp_dnldico',1,'Cannot Download this ECR - No Task Details exists against ECR' ,@ctxt_language,  
@ctxt_ouinstance,@ctxt_service,@ctxt_user,'','','','',@m_errorid out  
return  
end  
--if exists( select 's'  
--from de_ui_ico a (nolock)  
--where a.customer_name = @engg_customer_name  
--and  a.project_name = @engg_project_name  
--and  a.ico_no  = @engg_ico_no)  
--begin  
--Select  @msg = 'THE ECR NUMBER : '+ @engg_ico_no+' IS ALREADY DOWNLOADED.'  
--exec engg_error_sp  
--'de_dnld_sp_dnldico',1, @msg,@ctxt_language,  
--@ctxt_ouinstance,@ctxt_service,@ctxt_user,'','','','',@m_errorid out  
--return  
--end  
  
select  @process_name_tmp = process_name ,  
@component_name_tmp = component_name,  
@ecr_no_tmp   = isnull(ecr_no,'') -- Code modified by Gowrisankar for PNR2.0_12009 on 27-Jan-2006  
from  #de_rmt_ico_ui_tmp (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  ico_no   = @engg_ico_no  
  
if exists (select 'x' -- Code added by Gopinath S for the Call ID PNR2.0_20277 starts here  
from de_ui_ico a (nolock),  
re_ui_ecr b (nolock)  
where a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.process_name  =   @process_name_tmp  
and  a.component_name = @component_name_tmp  
and  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.ecr_no   = b.ecr_no  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
and  isnull(a.ecr_no,'') <> ''  
and  exists   ( select 'x'  
from re_ui_ecr c(nolock)  
where a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  c.ecr_no   = @rcn_tmp  
and  a.process_name  =   @process_name_tmp  
and  a.component_name = @component_name_tmp  
and  c.customer_name  = b.customer_name  
and  c.project_name  = b.project_name  
and  c.process_name  = b.process_name  
and  c.component_name = b.component_name  
and  c.activity_name  = b.activity_name  
and  c.ui_name   = b.ui_name  
and  c.createddate  < b.createddate ))  
begin  
select @msg = 'Only latest ECR can be downloaded'  
exec engg_error_sp  
'de_dnld_sp_dnldico',1, @msg,@ctxt_language, @ctxt_ouinstance,@ctxt_service,  
@ctxt_user,'', '', '', '',@m_errorid out  
Return  
end       -- Code added by Gopinath S for the Call ID PNR2.0_20277 starts here  
  
select @vartmp = ''  
  
select @vartmp = ui_name  
from  #de_rmt_ico_ui_tmp a (nolock)  
where a.customer_name = @engg_customer_name  
and  a.project_name = @engg_project_name  
and  a.ico_no  = @engg_ico_no  
and  isnull(a.ecr_no,'')  = isnull(@ecr_no_tmp,'')   -- Code modified by Gowrisankar for PNR2.0_12009 on 27-Jan-2006  
and a.process_name = @process_name_tmp  
and  a.component_name= @component_name_tmp  
--   --Code added by Sangeetha L for PNR2.0_7894   /* PNR2.0_10064 */  
--     and     a.activity_name <> 'IntegrationActivity'  
--   --Code added by Sangeetha L for PNR2.0_7894  
  
and  exists ( select 's'  
from  de_ui_ico b (nolock)  
where  b.customer_name  = a.customer_name  
and  b.project_name  = a.project_name  
and  b.process_name  = a.process_name  
and  b.component_name = a.component_name  
and  b.activity_name  = a.activity_name  
--   --Code added by Sangeetha L for PNR2.0_7894  /* PNR2.0_10064 */  
--             and     b.activity_name     <> 'IntegrationActivity'  
--     --Code added by Sangeetha L for PNR2.0_7894  
and  b.ui_name   = a.ui_name  
and  ico_status   = 'C')  
  
if isnull(@vartmp,  '') <> ''  
begin  
--Code modified by Sangeetha L for PNR2.0_5621  
  
--code modified for bugId : PNR2.0_11836  
select  @pre_ico_no  = ico_no  
from    de_ui_ico(nolock)  
where   ico_no      <> @engg_ico_no  
and     ui_name     = @vartmp  
and  component_name= @component_name_tmp  
and     ico_status  = 'C'  
  
Select @msg = 'UI - ' + @vartmp + ' already exists in the ECR "'+@pre_ico_no+'".Publish the ECR "'+ @pre_ico_no+'" before downloading the ECR"'+@engg_ico_no  
exec engg_error_sp  
'de_dnld_sp_dnldico', 1,  @msg, @ctxt_language,  
@ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out  
return  
end  
--Code modified by Sangeetha L for PNR2.0_5621  
  
  
select @vartmp = ''  
  
select @vartmp  = ui_name,  
@ecr_number = current_req_no  
from  de_ui a (nolock)  
where a.customer_name = @engg_customer_name  
and  a.project_name = @engg_project_name  
and  a.process_name = @process_name_tmp  
and  a.component_name= @component_name_tmp  
--   --Code added by Sangeetha L for PNR2.0_7894  /* PNR2.0_10064 */  
--     and     a.activity_name <> 'IntegrationActivity'  
--   --Code added by Sangeetha L for PNR2.0_7894  
and     isnull(current_req_no, '') <> ''  
and  exists ( select 's'  
from  #de_rmt_ico_ui_tmp b (nolock)  
where  b.customer_name  = a.customer_name  
and  b.project_name  = a.project_name  
and  b.ico_no   = @engg_ico_no  
and  isnull(b.ecr_no,'')   = isnull(@ecr_no_tmp,'')  
and  b.process_name  = a.process_name  
and  b.component_name = a.component_name  
and  b.activity_name  = a.activity_name  
--          --Code added by Sangeetha L for PNR2.0_7894  
--          and     b.activity_name     <> 'IntegrationActivity'  
--        --Code added by Sangeetha L for PNR2.0_7894  
and  b.ui_name   = a.ui_name )  
  
if isnull(@vartmp, '') <> ''  
begin  
Select @msg = 'UI - ' + @vartmp + ' is already downloaded with another ECR : '+ @ecr_number  
  
exec engg_error_sp  
'de_dnld_sp_dnldico', 1, @msg, @ctxt_language,  
@ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out  
return  
end  
  
select @ecr_status  =  ECRType  
from fw_rmt_ecr_vw (nolock)  
where CustomerID  = @engg_customer_name  
and  ProjectID  = @engg_project_name  
and  ECRNumber  = @engg_ico_no  
  
  
if  @ecr_status <> 'Dir'  
begin  
-- code added by Balaji S for  BugID  : PNR2.0_3216  
--description  : Validation added to Download the Previous ECR  
  
  
declare Ico_cursor insensitive Cursor For  
Select distinct ecr_no,process_name,component_name,activity_name,ui_name  
from de_rmt_ico_ui_vw(nolock)  
where ico_no   = @engg_ico_no  
  
open ico_cursor  
--Code modified by sangeetha For BugID:PNR2.0_3240 Bug Descr:Unable to Download the following Direct ECR . It's hanging and Shows "Pls Wait...."  
WHILE (1=1)  
BEGIN  
  
fetch next from ico_cursor  
into  @ecrno,@processname,@componentname,@activityname,@uiname  
  
if (@@FETCH_STATUS <> 0)  
break  
  
  
  
Select @modifieddate_tmp = modifieddate  
from re_ui_ecr(nolock)  
where ecr_no    =  @ecrno  
and  process_name  =  @processname  
and  component_name = @componentname  
and  activity_name = @activityname  
and  ui_name   = @uiname  
  
/* code added for BugId :PNR2.0_3240 */  
Select top 1  
@rcnno_tmp  = ecr_no  
from re_ui_ecr (nolock)  
where ecr_no    <>  @ecrno  
and  process_name  =  @processname  
and  component_name = @componentname  
and  activity_name = @activityname  
and  ui_name   = @uiname  
and  short_close  <>  'Yes'  
and  modifieddate < @modifieddate_tmp  
order by modifieddate desc  
  
  
if @rcnno_tmp is not null  
begin  
  
--Code Modified for BugId : PNR2.0_12133  
select  top 1  
@ecr_no = ico_no  
from   de_rmt_ico_ui_vw(nolock)  
where   ecr_no    = @rcnno_tmp  
and   process_name   = @processname  
and   component_name  = @componentname  
and   activity_name  = @activityname  
and   ui_name     = @uiname  
  
  
if not exists ( Select 'x'  
from de_ui_ico(nolock)  
where ecr_no = @rcnno_tmp  
and  ecr_no is not null)  
begin  
select @msg = 'DownLoad the Previous ECR No.'+ @ecr_no+'-'+@uiname  
exec engg_error_sp  
'de_dnld_sp_dnldico', 1, @msg, @ctxt_language,  
@ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out  
close ico_cursor  
deallocate ico_cursor  
return  
end  
end  
  
end  
  
close ico_cursor  
deallocate ico_cursor  
-- code added by Balaji S for  BugID  : PNR2.0_3216  
--description  : Validation added to Download the Previous ECR  
--Code modified by sangeetha For BugID:PNR2.0_3240 Bug Descr:Unable to Download the following Direct ECR . It's hanging and Shows "Pls Wait...."  
select @count_temp = 0  
  
select @count_temp    = count(1)  
from  #de_rmt_ico_ui_tmp a (nolock)  
where a.customer_name = @engg_customer_name  
and  a.project_name = @engg_project_name  
and  a.ico_no  = @engg_ico_no  
and  a.ecr_no  = @ecr_no_tmp  
and  a.process_name = @process_name_tmp  
and  a.component_name= @component_name_tmp  
and  not exists (  select 's'  
from  re_published_ui b (nolock)  
where  b.customer_name  = a.customer_name  
and  b.project_name  = a.project_name  
and  b.ecr_no   = a.ecr_no  
and  b.process_name  = a.process_name  
and  b.component_name = a.component_name  
and  b.activity_name  = a.activity_name  
and  b.ui_name   = a.ui_name )  
  
if @count_temp > 0  
begin  
--    exec engg_error_sp  
--      'de_dnld_sp_dnldico', 1, 'UI does not exist for the ECR number', @ctxt_language,  
--      @ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out  
-- Modified by Sangeetha G for  PNR2.0_16082  
select @msg  =  'The corresponding RCN '+''''+ @ecr_no_tmp + ''''+' to the ECR '+''''+ @engg_ico_no+''''+ ' is not published.'  
exec engg_error_sp  
'de_dnld_sp_dnldico', 1, @msg , @ctxt_language,  
@ctxt_ouinstance, @ctxt_service, @ctxt_user, '', '', '', '', @m_errorid out  
return  
end  
  
select @count_temp = 0  
  
select @count_temp  = count(1)  
from de_ui_ico (nolock)  
where customer_name = @engg_customer_name  
and  project_name = @engg_project_name  
and  process_name = @process_name_tmp  
and  component_name = @component_name_tmp  
  
if  @count_temp = 0  
begin  
  
insert  into de_precision_type  
(customer_name,   project_name, process_name,  component_name,  
pt_name,    pt_descr,   pt_sysid,   timestamp,  
createdby,    createddate,  modifiedby,   modifieddate,  
total_length,   decimal_length,ecrno)  --chan  
select customer_name,   project_name,  @process_name_tmp,  @component_name_tmp,  
pt_name,    pt_descr,   newid(),   1,  
@ctxt_user,    @date,    @ctxt_user,   @date,  
total_length,   decimal_length  ,@engg_ico_no  
  
from es_pt_mst a(nolock)  
where customer_name  = @engg_customer_name  
and  project_name  = @engg_project_name  
and  len(pt_name )<=10 -- code added for the case id TECH-38859 by 11537  
  
and not exists(select 's' from de_precision_type b(nolock)  -- code added for the case id TECH-66990/TECH-68796 by 11537 
where a.customer_name = b.customer_name
and a.project_name = b.project_name
and	b.process_name	=@process_name_tmp
and	b.component_name	=@component_name_tmp
and a.pt_name = b.pt_name)  
   
-- Added by Sangeetha  for  PNR2.0_17182 starts  
  
  
insert into de_fw_req_precision  
(precisiontype,totallength,decimallength,upduser,updtime,customer_name,project_name,timestamp,createdby,createddate,  
modifiedby,modifieddate,process_name,component_name,ecrno)  
  
select  
a.pt_name,a.total_length,a.decimal_length, @ctxt_User, @date ,a.customer_name,a.project_name,a.timestamp,a.createdby,a.createddate,  
a.modifiedby,a.modifieddate,a.process_name,a.component_name ,a.ecrno  
from  de_precision_type a   (nolock)  
where a.customer_name = @engg_customer_name  
and   a.project_name = @engg_project_name  
and   a.process_name = @process_name_tmp  
and   a.component_name = @component_name_tmp  
and  len(pt_name )<=10 -- code added for the case id TECH-38859 by 11537     
and  not  exists  (select  'K'  from  de_fw_req_precision   b (nolock)  
where b.customer_name =  @engg_customer_name  
and   b.project_name =  @engg_project_name  
and   b.process_name =  a.process_name  
and   b.component_name =  a.component_name  
and   b.precisiontype  =    a.pt_name        )  
  
-- Added by Sangeetha  for  PNR2.0_17182 ends  
  
insert into de_business_term  
(  customer_name,  project_name,  bt_name,   bt_descr,    data_type,  
bt_sysid,   timestamp,   createdby,   createddate,   modifiedby,  
modifieddate,  length,   precision_type, process_name,  component_name,ecrno)  
select customer_name,  project_name,  bt_name,   bt_descr,    data_type,  
newid(),   1,     @ctxt_user,  @date,     @ctxt_user,  
@date,    length,   precision_type, @process_name_tmp,  @component_name_tmp  ,@engg_ico_no  
from es_business_term  a(nolock)  
where customer_name  = @engg_customer_name  
and  project_name  = @engg_project_name  
and  not exists (select 'x'              -- Added  by Sangeetha for PNR2.0_19576 starts  
from  de_business_term b(nolock)  
where b.customer_name =  a.customer_name  
and   b.project_name  =  a.project_name  
and   b.process_name  =  @process_name_tmp  
and   b.component_name=  @component_name_tmp  
and    b.bt_name       =  a.bt_name)-- Added  by Sangeetha for PNR2.0_19576 ends  
  
-- Added by Sangeetha  for  PNR2.0_17182 starts  
  
insert into de_fw_req_bterm  
(btname,  btdesc,    isbterm,  datatype, length, precisiontype,   minvalue,  maxvalue,  
upduser,  updtime,   customer_name, project_name,timestamp,  createdby,   createddate, process_name,  
component_name,ecrno)  
select  
a.bt_name,   a.bt_descr,   1,    a.data_type,a.length,    a.precision_type, null,   null,  
@ctxt_User,   @date ,  a.customer_name, a.project_name,1,  a.createdby,  a.createddate, a.process_name,  
a.component_name,  @engg_ico_no  
from de_business_term a (nolock)  
where a.customer_name  = @engg_customer_name  
and    a.project_name  = @engg_project_name  
and  a.process_name  =   @process_name_tmp  
and  a.component_name =  @component_name_tmp  
and  len(a.bt_name)  <= 30  
and     a.bt_name    not in (  select b.btname  
from   de_fw_req_bterm b(nolock)  
where   b.customer_name  = a.customer_name  
and     b.project_name   = a.project_name  
and     b.process_name   = a.process_name  
and     b.component_name = a.component_name )  
  
-- Added by Sangeetha  for  PNR2.0_17182 ends  
  
exec  de_insert_scratch  
@engg_customer_name,  
@engg_project_name,  
@process_name_tmp,  
@component_name_tmp,  
@ctxt_user  ,  
@engg_ico_no --chan  
  
end  
  
if not exists(  
select  'x'   
from de_scratch_variables_sys (nolock)  
where  customer_name   = @engg_customer_name  
and  project_name  =   @engg_project_name  
and  process_name  = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  btsynonym   =  'sysfprowno'  
)  
  
begin   
exec  de_insert_scratch  
@engg_customer_name,  
@engg_project_name,  
@process_name_tmp,  
@component_name_tmp,  
@ctxt_user  ,  
@engg_ico_no   
  
end     
     
  
insert into de_ui_ico  
(customer_name,   project_name,  ico_no,    ecr_no,    process_name,  component_name,  
activity_name,    ui_name,   process_descr,   component_descr,  activity_descr, ui_descr,  
ico_status,    ico_sysid,   timestamp,    createdby,    createddate,  ico_descr)  
select distinct  
customer_name,   project_name,  ico_no,    ecr_no,    process_name, component_name,  
activity_name,   ui_name,   process_descr,   component_descr,  activity_descr,  ui_descr,  
'C',     newid() ,  1,      @ctxt_user,   @date,   ico_descr  
from  #de_rmt_ico_ui_tmp a (nolock)  
where  a.customer_name = @engg_customer_name  
and  a.project_name = @engg_project_name  
and  a.ico_no  = @engg_ico_no  
and  a.ecr_no  = @ecr_no_tmp  
and  a.process_name = @process_name_tmp  
and  a.component_name= @component_name_tmp  
  
  
update de_ui  
set  current_req_no  = @engg_ico_no,  
ui_type    = c.ui_type,  
ui_format   = c.ui_format,  
caption_alignment = c.caption_alignment,  
trail_bar   = c.trail_bar,  
tab_height   = c.tab_height,  
ui_doc    = c.ui_doc,  
base_component_name = c.base_component_name,  
base_activity_name = c.base_activity_name,  
base_ui_name  = c.base_ui_name,  
grid_type = c.grid_type,  
state_processing = c.state_processing,  
callout_Type = c.callout_type, -- added by Jeya PNR2.0_1790  
taskpane_req = c.taskpane_req, -- added for the Bug ID: PNR2.0_30127  
modifiedby   = @ctxt_user,  
modifieddate  = @date  
,New_Line_Ui = c.New_Line_Ui,  
Tab_Type = c.Tab_Type,  
PostLaunchTask = c.PostLaunchTask,  
TabPosition    = c.TabPosition,  
Smarthide    = c.Smarthide,  
Is_device    = c.Is_device,  
HideIlbotitlemenu_req  = c.HideIlbotitlemenu_req,  
personalization = c.personalization,  
Exclude_Systemtabindex = c.Exclude_Systemtabindex-- PLF2.0_16291  
,DeviceType = c.DeviceType,--PLF2.0_17570  
TabStyle = c.TabStyle---PLF2.0_17570  
,IsDesktop = c.IsDesktop,  
Hide_Print = c.Hide_Print,  
Layout = c.Layout,  
TabHeaderPostion = c.TabHeaderPostion,  
XYCoordinates = c.XYCoordinates,  
ColumnLayWidth = C.ColumnLayWidth,  
TabRotation = c.TabRotation,  
DBName=c.dbname,  
ui_subtype=c.ui_subtype,  
IsGlance = c.IsGlance,  
NativeApplication = c.NativeApplication,  
Conditional_popupclose = c.Conditional_popupclose,  
Titlebar_Search  = c.Titlebar_Search , 
--Code added for TECH-70687 starts
Sidebar			=	c.Sidebar,
Docked			=	c.Docked,
LeftToolbar		=	c.LeftToolbar,
RightToolbar	=	c.RightToolbar,
TopToolbar		=	c.TopToolbar,
BottomToolbar	=	c.BottomToolbar,	
--Code added for TECH-70687 ends
--Code added for TECH-72114 starts
TemplateJSON	=	c.TemplateJSON, 
StyleSheet		=	c.StyleSheet, 
ConfigurationXML=   c.ConfigurationXML, 
TemplateJSONDBC	=	c.TemplateJSONDBC, 
StyleSheetDBC	=	c.StyleSheetDBC, 
ConfigurationXMLDBC	= c.ConfigurationXMLDBC,
--Code added for TECH-72114 ends
PullToRefresh	=	c.PullToRefresh --TECH-75230
from #de_rmt_ico_ui_tmp a (nolock),  
de_ui     b (nolock),  
re_published_ui  c (nolock)  
where a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  
and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
  
and  a.customer_name  = c.customer_name  
and  a.project_name  = c.project_name  
and  a.process_name  = c.process_name  
and  a.component_name = c.component_name  
and  a.activity_name  = c.activity_name  
and  a.ui_name   = c.ui_name  
and  a.ecr_no   = c.ecr_no  
  
and  a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.ico_no   = @engg_ico_no  
and  a.ecr_no   = @ecr_no_tmp  
and  a.process_name  = @process_name_tmp  
and  a.component_name = @component_name_tmp  
  
insert into de_ui  
( customer_name,   project_name,   process_name,  component_name,  activity_name,  
ui_name,    ui_descr,    ui_type,   ui_format,    caption_alignment,  
trail_bar,    tab_height,   ui_sysid,   timestamp,    createdby,  
createddate,   modifiedby,   modifieddate,  current_req_no,  ui_doc,  
base_component_name,base_activity_name, base_ui_name , grid_type, state_processing,ecrno ,callout_type,  --chan -- added by Jeya PNR2.0_1790  
taskpane_req -- added for the Bug ID: PNR2.0_30127  
,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req  
,personalization,Exclude_Systemtabindex-- PLF2.0_16291  
,DeviceType,TabStyle,IsDesktop,Hide_Print---PLF2.0_17570  
,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,ui_subtype,DBName,IsGlance,  
NativeApplication, Conditional_popupclose, Titlebar_Search,Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,        --Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC,  --TECH-72114
PullToRefresh)	--TECH-75230
select distinct  
b.customer_name,  b.project_name,  b.process_name, b.component_name,  b.activity_name,  
b.ui_name,    b.ui_descr,   b.ui_type,   b.ui_format,   b.caption_alignment,  
b.trail_bar,   b.tab_height,   b.ui_sysid,  1,      @ctxt_user,  
@date,     @ctxt_user,   @date,    @engg_ico_no,   b.ui_doc,  
b.base_component_name, b.base_activity_name, b.base_ui_name, b.grid_type, b.state_processing,@engg_ico_no,b.callout_type, -- added by Jeya PNR2.0_1790  
b.taskpane_req ,b.New_Line_Ui,b.Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req-- added for the Bug ID: PNR2.0_30127  
,personalization,Exclude_Systemtabindex-- PLF2.0_16291  
,DeviceType,TabStyle,IsDesktop,Hide_Print--PLF2.0_17570  
,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,b.ui_subtype,b.DBName,IsGlance,  
NativeApplication, Conditional_popupclose, Titlebar_Search,Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,        --Code added for TECH-70687
TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC,  --TECH-72114
PullToRefresh	--TECH-75230
from   #de_rmt_ico_ui_tmp a (nolock),  
re_published_ui  b (nolock)  
where a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.ico_no   = @engg_ico_no  
and  a.ecr_no   = @ecr_no_tmp  
and  a.process_name  = @process_name_tmp  
and  a.component_name = @component_name_tmp  
  
  
and  a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  
and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
and  a.ecr_no   = b.ecr_no  
  
and  not exists ( select 's'  
from de_ui c (nolock)  
where c.customer_name  = a.customer_name  
and  c.project_name  = a.project_name  
and  c.process_name  = a.process_name  
and  c.component_name = a.component_name  
and  c.activity_name  = a.activity_name  
and  c.ui_name   = a.ui_name )  
  
--Code Commented for bugId : PNR2.0_13973  
--Added by Shriram V on 22/08/05 for  Bug Id : PNR2.0_3616  
--  if exists( select 'x' from  
--    re_published_glossary_lng_extn A (nolock)  
--    where a.customer_name  = @engg_customer_name  
--    and a.project_name  = @engg_project_name  
--    and  a.process_name  = @process_name_tmp  
--    and  a.component_name = @component_name_tmp  
--    and  a.ecr_no  = @ecr_no_tmp  
--    and  len(a.bt_synonym_caption) > 60  
--   )  
--  
--  begin  
--   exec engg_error_sp  
--     'de_dnld_sp_dnldico',1,'BT Synonym Caption(S)Length cannot Exceed 60 Characters' ,@ctxt_language,  
--     @ctxt_ouinstance,@ctxt_service,@ctxt_user,'','','','',@m_errorid out  
--   return  
--  end  
  
--Added by Shriram V on 22/08/05 for  Bug Id : PNR2.0_3616  
  
exec  de_populate_downloadico  
@Ctxt_Language,  
@ctxt_OUInstance ,  
@Ctxt_Service ,  
@ctxt_User ,  
@engg_customer_name ,  
@engg_project_name ,  
@ecr_no_tmp ,  
@engg_ico_no,  
@process_name_tmp ,  
@component_name_tmp,  
@activity_name_tmp,  
@ui_name_tmp  
  
  
  
end  
else  
begin  
--Code modified for BugId : PNR2.0_3142  
--Code commented Sangeetha L for  BugId : PNR2.0_3232  
--BugDescr :On downloading the direct ECR no error is displayed but on seeing the status of the ECR it is still in pending.  
insert into de_ui_ico  
(customer_name,   project_name,  ico_no,    ecr_no,    process_name,  component_name,  
activity_name,    ui_name,   process_descr,   component_descr,  activity_descr, ui_descr,  
ico_status,    ico_sysid,   timestamp,    createdby,    createddate,  ico_descr)  
select distinct  
customer_name,   project_name,  ico_no,    '',     process_name,  component_name,  
activity_name,   ui_name,   process_descr,   component_descr,  activity_descr,  ui_descr,  
'C',     newid() ,  1,      @ctxt_user,   @date,   ico_descr  
from  #de_rmt_ico_ui_tmp a (nolock)  
where  a.customer_name = @engg_customer_name  
and  a.project_name = @engg_project_name  
and  a.ico_no  = @engg_ico_no  
--  and  a.ecr_no  = @ecr_no_tmp  
and  a.process_name = @process_name_tmp  
and  a.component_name= @component_name_tmp  
  
  
update de_ui  
set  current_req_no  = @engg_ico_no  
from #de_rmt_ico_ui_tmp a (nolock),  
de_ui     b (nolock)  
where a.customer_name  = b.customer_name  
and  a.project_name  = b.project_name  
and  a.process_name  = b.process_name  
and  a.component_name = b.component_name  
and  a.activity_name  = b.activity_name  
and  a.ui_name   = b.ui_name  
  
and  a.customer_name  = @engg_customer_name  
and  a.project_name  = @engg_project_name  
and  a.ico_no   = @engg_ico_no  
--  and  a.ecr_no   = @ecr_no_tmp  
and  a.process_name  = @process_name_tmp  
and  a.component_name = @component_name_tmp  
end  
--Code commented Sangeetha L for  BugId : PNR2.0_3232  
--BugDescr :On downloading the direct ECR no error is displayed but on seeing the status of the ECR it is still in pending.  
--Code Added by Sangeetha L on 23-09-2005 for Entrie in Workflow tables  
--Code added by Sangeetha L for the BUG ID:PNR2.0_6964 on 08-Mar-2006 starts  
Delete b  
from de_ui_control a (nolock),  
de_fw_Des_ilbo_Service_view_Datamap b (nolock),  
--Fw_Rmt_ECR_ui_details c  (nolock)  --PLF2.0_12342  
#de_rmt_ico_ui_tmp c (nolock) -- code modified by 11536 for the case id TECH-20275  
where c.customer_name   = @engg_customer_name  
and   c.project_name    = @engg_project_name  
and   c.process_name    = @process_name_tmp  
and   c.component_name   = @component_name_tmp  
and   c.ico_no      = @engg_ico_no  
and   a.customer_name    = c.customer_name  
and   a.project_name    = c.project_name  
and   a.process_name    = c.process_name  
and   a.component_name     = c.component_name  
and   a.activity_name      = c.activity_name --PNR2.0_7112  
and   a.ui_name         = c.ui_name  
and   a.customer_name    = b.customer_name  
and  a.project_name    = b.project_name  
and   a.process_name    = b.process_name  
and   a.component_name     = b.component_name  
and   a.activity_name      = b.activity_name--PNR2.0_7112  
and   a.ui_name         = b.ilbocode  
and   a.page_bt_synonym    = b.page_bt_synonym--PNR2.0_7112  
and   a.control_bt_synonym = b.control_bt_synonym  
and   a.control_id       <> b.controlid  
and   a.view_name         <> b.viewname  
  
  
  
delete b  
from de_ui_grid a(nolock) ,  
de_fw_Des_ilbo_Service_view_Datamap b (nolock)  ,  
--Fw_Rmt_ECR_ui_details c (nolock) --PLF2.0_12342  
#de_rmt_ico_ui_tmp c (nolock) -- code modified by 11536 for the case id TECH-20275  
where c.customer_name   = @engg_customer_name  
and   c.project_name    = @engg_project_name  
and   c.process_name    = @process_name_tmp  
and   c.component_name   = @component_name_tmp  
and   c.ico_no      = @engg_ico_no  
and   a.customer_name  = c.customer_name  
and   a.project_name    = c.project_name  
and   a.process_name    = c.process_name  
and   a.component_name     = c.component_name  
and   a.activity_name      = c.activity_name  --PNR2.0_7112  
and   a.ui_name         = c.ui_name  
and   a.customer_name    = b.customer_name  
and   a.project_name    = b.project_name  
and   a.process_name    = b.process_name  
and   a.component_name     = b.component_name  
and   a.activity_name      = b.activity_name--PNR2.0_7112  
and   a.ui_name            = b.ilbocode  
and   a.page_bt_synonym    = b.page_bt_synonym--PNR2.0_7112  
and   a.column_bt_synonym  = b.control_bt_synonym  
and   a.control_id         <> b.controlid /*Modification made by Muthupandi S for Bug id : PNR2.0_32751*/  
and   a.view_name          <> b.viewname   
  
  
delete b  
from de_hidden_view a(nolock),  
de_fw_Des_ilbo_Service_view_Datamap b (nolock) ,  
--Fw_Rmt_ECR_ui_details c  (nolock) --PLF2.0_12342  
#de_rmt_ico_ui_tmp c (nolock) -- code modified by 11536 for the case id TECH-20275  
where c.customer_name     = @engg_customer_name  
and   c.project_name      = @engg_project_name  
and   c.process_name      = @process_name_tmp  
and c.component_name     = @component_name_tmp  
and   c.ico_no        = @engg_ico_no  
and   a.customer_name      = c.customer_name  
and   a.project_name      = c.project_name  
and   a.process_name      = c.process_name  
and   a.component_name       = c.component_name  
and   a.activity_name        = c.activity_name --PNR2.0_7112  
and   a.ui_name           = c.ui_name  
and   a.customer_name      = b.customer_name  
and   a.project_name      = b.project_name  
and   a.process_name      = b.process_name  
and   a.component_name       = b.component_name  
and   a.activity_name        = b.activity_name -- PNR2.0_7112  
and   a.ui_name           = b.ilbocode  
and   a.page_name        = b.page_bt_synonym--PNR2.0_7112  
and   a.hidden_view_bt_synonym  = b.control_bt_synonym  
and   a.control_id         <> b.controlid  
and   a.view_name               <> b.viewname  
--Code added by Sangeetha L for the BUG ID:PNR2.0_6964 on 08-Mar-2006 -ends  
  
-- Code addition by Sangeetha for  PNR2.0_20298 starts  
/*Modification made by Muthupandi S for Bug id : PNR2.0_32554 Starts*/  
if exists (select  'X' from de_hidden_view a (nolock)  
 where  a.customer_name   = @engg_customer_name  
 and   a.project_name    = @engg_project_name  
 and   a.process_name    = @process_name_tmp  
 and   a.component_name   = @component_name_tmp       
 and not exists (select 'X' from de_ui_grid b (nolock)  
  where a.customer_name   = b.customer_name  
  and   a.project_name = b.project_name  
  and   a.process_name = b.process_name  
  and   a.component_name =  b.component_name  
  and   a.activity_name =  b.activity_name  
  and      a.ui_name  = b.ui_name  
  and   a.page_name  = b.page_bt_synonym  
  and   a.section_name =   b.section_bt_synonym  
  and   a.control_bt_synonym =  b.column_bt_synonym  
  and   a.control_id  =    b.control_id)  
  and not exists (select 'X' from de_ui_control c (nolock)  
  where a.customer_name   = c.customer_name  
  and   a.project_name = c.project_name  
  and   a.process_name = c.process_name  
  and   a.component_name =  c.component_name  
  and   a.activity_name =  c.activity_name  
  and      a.ui_name  = c.ui_name  
  and   a.page_name  = c.page_bt_synonym  
  and   a.section_name =   c.section_bt_synonym  
  and   a.control_bt_synonym =  c.control_bt_synonym  
  and   a.control_id  =    c.control_id)) /*Modification made by Muthupandi S for Bug id : PNR2.0_32751 Starts*/   
    
begin  
   delete a  
   from de_hidden_view a   
   where  a.customer_name   = @engg_customer_name  
   and   a.project_name    = @engg_project_name  
   and   a.process_name    = @process_name_tmp  
   and   a.component_name   = @component_name_tmp       
   and not exists (select 'X' from de_ui_grid b (nolock)  
  where a.customer_name   = b.customer_name  
  and   a.project_name = b.project_name  
  and   a.process_name = b.process_name  
  and   a.component_name =  b.component_name  
  and   a.activity_name =  b.activity_name  
  and   a.ui_name  = b.ui_name  
  and   a.page_name  = b.page_bt_synonym  
  and   a.section_name =   b.section_bt_synonym  
  and   a.control_bt_synonym =  b.column_bt_synonym  
  and   a.control_id  =    b.control_id)  
  and not exists (select 'X' from de_ui_control c (nolock)  
  where a.customer_name   = c.customer_name  
  and   a.project_name = c.project_name  
  and   a.process_name = c.process_name  
  and   a.component_name =  c.component_name  
  and   a.activity_name =  c.activity_name  
  and      a.ui_name  = c.ui_name  
  and   a.page_name  = c.page_bt_synonym  
  and   a.section_name =   c.section_bt_synonym  
  and   a.control_bt_synonym =  c.control_bt_synonym  
  and   a.control_id  =    c.control_id)/*Modification made by Muthupandi S for Bug id : PNR2.0_32751 Starts*/   
        
end  
/*Modification made by Muthupandi S for Bug id : PNR2.0_32554 Ends*/  
if not  exists  
(  
select  '*' from  de_workflow_req (nolock)  
where  customer_name     = @engg_customer_name  
and    project_name      = @engg_project_name  
and    process_name      = @process_name_tmp  
and    component_name    = @component_name_tmp  
)  
  
begin  
  
insert into de_workflow_req  
(customer_Name,Project_Name,Process_Name,Component_Name,wkf_req,createdby,createddate,modifiedby,modifieddate)  
values  
(@engg_customer_name,@engg_project_name,@process_name_tmp,@component_name_tmp,'Y',@ctxt_User,getdate(),@ctxt_User,getdate())  
  
end  
  
-- Code addition by Sangeetha for  PNR2.0_20298 ends  
  
  
if  @ecr_status <> 'Dir'  
begin  
  
--Code addedfor the BUG ID:PNR2.0_8466 on 15-May-2006  - starts  
  
Select @rcnno_tmp = ecr_no from de_ui_ico (nolock)  
where customer_name = @engg_customer_name  
and   project_name  = @engg_project_name  
and   ico_no    = @engg_ico_no  
/*PNR2.0_13622*/  
EXEC  ECR_DNLD_DE_APPEND_WF_CONTROL  
@Ctxt_Language, @Ctxt_Service, @ctxt_OUInstance, @ctxt_User,  
@engg_customer_name,  @engg_project_name,   @engg_ico_no  
/*PNR2.0_13622*/  
  
EXEC  ecr_dwnld_wrkflow_insert  
@engg_customer_name ,  
@engg_project_name ,  
@rcnno_tmp,  
@component_name_tmp  -- code added for Bugid : PNR2.0_19781  
  
  
  
  
--Code addedfor the BUG ID:PNR2.0_8466 on 15-May-2006  -ends  
end  
  
--code added by kiruthika For bugid:PNR2.0_11435  
if not exists(select  'x'  
from de_business_term d (nolock)  
where  d.customer_name  = @engg_customer_name  
and  d.project_name     = @engg_project_name  
and  d.process_name     = @process_name_tmp  
and  d.component_name   = @component_name_tmp  
and  d.bt_name          = 'WFCAT')  
begin  
insert into de_business_term  
(  
customer_name,  project_name,  bt_name,  bt_descr,  data_type,  
bt_sysid,   timestamp,   createdby,  createddate, modifiedby,  
modifieddate,  length,    precision_type, component_name, process_name  ,ecrno --chan  
)  
values  
(  
@engg_customer_name,  @engg_project_name,  'WFCAT',    'WFCAT', 'Integer',  
newid(),   1,     @ctxt_user,  getdate(),  @ctxt_user,  
getdate(),    4,     null, @component_name_tmp,@process_name_tmp  ,@engg_ico_no  
)  
end  
if not exists(  
select  'x'  
from de_business_term d (nolock)  
where  d.customer_name  = @engg_customer_name  
and  d.project_name  =   @engg_project_name  
and  d.process_name  = @process_name_tmp  
and  d.component_name  = @component_name_tmp  
and  d.bt_name   =  'WFDocKey')  
begin  
insert into de_business_term  
(  
customer_name,  project_name,  bt_name,  bt_descr,  data_type,  
bt_sysid,   timestamp,   createdby,  createddate, modifiedby,  
modifieddate,  length,    precision_type, component_name, process_name  ,ecrno  
)  
values  
(  
@engg_customer_name,  @engg_project_name,  'WFDocKey',    'WFDocKey', 'Char',  
newid(),   1,     @ctxt_user,  getdate(),  @ctxt_user,  
getdate(),   128,     null, @component_name_tmp,@process_name_tmp  ,@engg_ico_no  
)  
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'HdnWFOrgUnit')  
begin  
update de_glossary  
set    bt_name    = 'WFCAT',  
data_type  = 'Integer',  
length     =  4  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'HdnWFOrgUnit'  
and     isnull(bt_name,'') = ''  
  
--DE glossary changes by 11537 Starts  
--update de_glossary_lng_extn  
--set    bt_name    = 'WFCAT',  
--data_type  = 'Integer',  
--length     =  4  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'HdnWFOrgUnit'  
--and     isnull(bt_name,'') = ''  
--DE glossary changes by 11537 Ends
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'HdnWFDocKey')  
begin  
update de_glossary  
set     bt_name  = 'WFDocKey',  
data_type  = 'Char',  
length    =  128  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'HdnWFDocKey'  
and     isnull(bt_name,'') = ''  
  
--DE glossary changes by 11537 Starts  
--update de_glossary_lng_extn  
--set     bt_name  = 'WFDocKey',  
--data_type  = 'Char',  
--length     =  128  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'HdnWFDocKey'  
--and     isnull(bt_name,'') = ''  
--DE glossary changes by 11537 Ends
end  
  
--code added by kiruthika for bugid:PNR2.0_11451  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'Ctxt_Language')  
begin  
update de_glossary  
set     bt_name  = 'Ctxt_Language',  
data_type  = 'Integer',  
length     =  4  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'Ctxt_Language'  
and     isnull(bt_name,'') = ''  
  
  
--DE glossary changes by 11537 Starts 
--update de_glossary_lng_extn  
--set     bt_name  = 'Ctxt_Language',  
--data_type  = 'Integer',  
--length     =  4  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'Ctxt_Language'  
--and     isnull(bt_name,'') = ''  
 --DE glossary changes by 11537 Ends

end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'Ctxt_OUInstance')  
begin  
update de_glossary  
set     bt_name  = 'Ctxt_OUInstance',  
data_type  = 'Integer',  
length     =  4  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'Ctxt_OUInstance'  
and     isnull(bt_name,'') = ''  
  
  
--DE glossary changes by 11537 Starts  
--update de_glossary_lng_extn  
--set     bt_name  = 'Ctxt_OUInstance',  
--data_type  = 'Integer',  
--length     =  4  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'Ctxt_OUInstance'  
--and     isnull(bt_name,'') = ''  
 --DE glossary changes by 11537 Ends
  
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'Ctxt_Service')  
begin  
update de_glossary  
set     bt_name  = 'Ctxt_Service',  
data_type  = 'Char',  
length     =  32  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'Ctxt_Service'  
and     isnull(bt_name,'') = ''  
  
  
 --DE glossary changes by 11537 Starts 
--update de_glossary_lng_extn  
--set     bt_name  = 'Ctxt_Service',  
--data_type  = 'Char',  
--length     =  32  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'Ctxt_Service'  
and     isnull(bt_name,'') = ''  
 --DE glossary changes by 11537 Ends 
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'Ctxt_User')  
begin  
update de_glossary  
set     bt_name  = 'Ctxt_User',  
data_type  = 'Char',  
length     =  30  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'Ctxt_User'  
and     isnull(bt_name,'') = ''  
  
--DE glossary changes by 11537 Starts
--update de_glossary_lng_extn  
--set     bt_name  = 'Ctxt_User',  
--data_type  = 'Char',  
--length     =  30  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'Ctxt_User'
--DE glossary changes by 11537 Ends

  
and     isnull(bt_name,'') = ''  
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'Ctxt_Role')  
begin  
update de_glossary  
set     bt_name  = 'Ctxt_Role',  
data_type  = 'Char',  
length     =  30  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'Ctxt_Role'  
and     isnull(bt_name,'') = ''  
  
--DE glossary changes by 11537 Starts  
--update de_glossary_lng_extn  
--set     bt_name  = 'Ctxt_Role',  
--data_type  = 'Char',  
--length     =  30  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'Ctxt_Role'  
--and     isnull(bt_name,'') = ''  
--DE glossary changes by 11537 Ends
end  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where  customer_name  = @engg_customer_name  
and  project_name     = @engg_project_name  
and  process_name     = @process_name_tmp  
and  component_name   = @component_name_tmp  
and  bt_synonym_name  = 'fpRowNo')  
begin  
update de_glossary  
set     bt_name  = 'RowNo',  
data_type  = 'Integer',  
length     =  4  
where customer_name   = @engg_customer_name  
and   project_name    = @engg_project_name  
and   process_name    = @process_name_tmp  
and   component_name  = @component_name_tmp  
and   bt_synonym_name = 'fpRowNo'  
and     isnull(bt_name,'') = ''  
  
--DE glossary changes by 11537 Starts
--update de_glossary_lng_extn  
--set     bt_name  = 'RowNo',  
--data_type  = 'Integer',  
--length     =  4  
--where customer_name   = @engg_customer_name  
--and   project_name    = @engg_project_name  
--and   process_name    = @process_name_tmp  
--and   component_name  = @component_name_tmp  
--and   bt_synonym_name = 'fpRowNo'  
--and     isnull(bt_name,'') = ''  
-- DE glossary changes by 11537 Ends
end  

--update b  
--set  b.bt_synonym_caption ='--nocaption--'  
--from de_glossary a (nolock),  
--  de_glossary_lng_extn b(nolock)  
--where a.component_name = @component_name_tmp  
--and  a.customer_name  = b.customer_name  
--and  a.project_name  = b.project_name  
--and  a.process_name  = b.process_name  
--and  a.component_name = b.component_name  
--and  a.bt_synonym_name = b.bt_synonym_name  
--and  a.bt_synonym_caption= '--nocaption--'  
--and  b.languageid  <> '1'  
  
  
  
--Code Modified for bugId : PNR2.0_13557  
if not exists ( select 'x'  
from de_business_term(nolock)  
where customer_name = @engg_customer_name  
and  project_name  = @engg_project_name  
and  process_name  = @process_name_tmp  
and  component_name  = @component_name_tmp  
and  bt_name   = 'modeflag')  
begin  
insert into de_business_term  
( customer_name,  project_name,  process_name,  component_name,  
bt_name,   bt_descr,   data_type,   bt_sysid,  
timestamp,   createdby,   createddate,  modifiedby,  
modifieddate,  length,    precision_type,  Generatedby,ecrno)  
select  
@engg_customer_name,@engg_project_name, @process_name_tmp, @component_name_tmp,  
'modeflag',   'modeflag',   'Char',    newid(),  
1,     @ctxt_User,   getdate(),   @ctxt_User,  
getdate(),   2,     null,    null,@engg_ico_no  
end  
  
--Code addition for PNR2.0_19527  starts  
  
-- Code added for Bulk Validation TECH-20897 Starts  
If  exists(  Select 'x'  
from de_glossary (nolock)  
where customer_name = @engg_customer_name  
and  project_name    = @engg_project_name  
and  process_name    = @process_name_tmp  
and  component_name  = @component_name_tmp  
and  bt_synonym_name = 'Ctxt_Validation')  
begin  
 update de_glossary  
 set     bt_name   = 'Ctxt_Validation',  
   data_type  = 'Integer',  
   length   =  4  
 where customer_name  = @engg_customer_name  
 and   project_name  = @engg_project_name  
 and   process_name  = @process_name_tmp  
 and   component_name = @component_name_tmp  
 and   bt_synonym_name = 'Ctxt_Validation'  
 and   isnull(bt_name,'')= ''  
  
 --update de_glossary_lng_extn  
 --set     bt_name   = 'Ctxt_Validation',  
 --  data_type  = 'Integer',  
 --  length   =  4  
 --where customer_name   = @engg_customer_name  
 --and  project_name    = @engg_project_name  
 --and  process_name    = @process_name_tmp  
 --and  component_name  = @component_name_tmp  
 --and  bt_synonym_name = 'Ctxt_Validation'  
 --and     isnull(bt_name,'') = ''  
  
end  
-- Code added for Bulk Validation TECH-20897 Ends  
  
if not exists ( select 'x'  
from de_business_term(nolock)  
where customer_name = @engg_customer_name  
and  project_name  = @engg_project_name  
and  process_name  = @process_name_tmp  
and  component_name  = @component_name_tmp  
and  bt_name   = 'plf_hdn_ctrl_bt')  
begin  
insert into de_business_term  
( customer_name,  project_name,  process_name,  component_name,  
bt_name,   bt_descr,   data_type,   bt_sysid,  
timestamp,   createdby,   createddate,  modifiedby,  
modifieddate,  length,    precision_type,  Generatedby,ecrno)  
select  
@engg_customer_name,@engg_project_name, @process_name_tmp, @component_name_tmp,  
'plf_hdn_ctrl_bt',  'plf_hdn_ctrl_bt',   'Char',    newid(),  
1,     @ctxt_User,   getdate(),   @ctxt_User,  
getdate(),   20,     null,    null,@engg_ico_no  
end  
  
--Code addition for PNR2.0_19527  ends  
  
Delete from de_ecr_publish_chk  
where ecr_no = @engg_ico_no  
and   work_flag = 'D'  
and   customer_name = @engg_customer_name  
and   project_name  = @engg_project_name  
  
  
drop table #de_rmt_ico_ui_tmp   -- PNR2.0_15050  
--code added by senthil for ecr pulish from rcn publish screen.  
  
-- Added  by Sangeetha G  for  PNR2.0_17846  
exec  de_comp_doc_status_ins_sp  @engg_customer_name , @engg_project_name ,@process_name_tmp,@component_name_tmp,@engg_ico_no ,@ctxt_User,'D'  
  
  
if @Ctxt_Service = 'ec_dndecrsrdnld'  and  @engg_ico_status  not in ('dwnldezeeview')   --Code modified for PNR2.0_28333  
begin  
select @fpRowNo   'FPROWNO'  
end  
  
   if exists ( select  'x'  -- code added by 11536 for the case id TECH-20631  
     from de_ui_ico(nolock)    
     where customer_name  = @engg_customer_name    
     and  project_name  = @engg_project_name    
     and  ico_no    = rtrim(@engg_ico_no)    
     and  ico_status   = 'c'  
     )    
     begin   
  
      Update FW_NIA_GenDoc_Rcn_Ecr_ICO_temp   
      set  doc_status   = 'ECRDW'  
      where Customerid   = @engg_customer_name  
      and  Projectid   = @engg_project_name  
      and  ECRNumber   = rtrim(@engg_ico_no)   
  
     End  
  
-- NGPLF Changes Starts  
Declare @tmp_wr    engg_name,  
  @tmp_prc   engg_name,  
  @tmp_cmp   engg_name,  
  @tmp_act   engg_name,  
  @tmp_ui    engg_name,  
  @ctxt_role   engg_name  
  
declare getecr insensitive Cursor For  
Select distinct rcr_no, process_name, component_name, activity_name, ui_name  
from de_rmt_ico_ui_vw(nolock)  
where ico_no   = @engg_ico_no  
  
open getecr  
FETCH NEXT FROM getecr into @tmp_wr, @tmp_prc, @tmp_cmp, @tmp_act, @tmp_ui  
        
WHILE @@FETCH_STATUS = 0  
BEGIN   
  IF ISNULL(@tmp_wr,'') <> ''  
  BEGIN   
    Exec ngplf_dcn_download  
        @ctxt_language,   @ctxt_ouinstance,   @ctxt_user,    @ctxt_role,  
        @engg_customer_name, @engg_project_name,   @tmp_prc,    @tmp_cmp,  
        @engg_ico_no,   @tmp_wr,     @tmp_act,    @tmp_ui  
  END  
  
    FETCH NEXT FROM getecr into @tmp_wr, @tmp_prc, @tmp_cmp, @tmp_act, @tmp_ui  
END  
CLOSE getecr  
DEALLOCATE getecr  
  
-- NGPLF Changes Ends  
  
  
set nocount off  
  
End  
GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_dnld_sp_dnldico' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_dnld_sp_dnldico TO PUBLIC
END
GO
