IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_tcpgtc_o' AND TYPE = 'P')
BEGIN
  DROP PROC de_design_sp_tcpgtc_o
END
GO
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		de_design_sp_tcpgtc_o.sql
********************************************************************************/
/********************************************************************************/
/* Procedure    : de_design_sp_tcpgtc_o                                         */
/* Description  :                                                               */
/********************************************************************************/
/* Project      :                                                               */
/* ECR          :                                                               */
/* Version      :                                                               */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development history                                                          */
/********************************************************************************/
/* Author       : Muthu Kumar.K                                                 */
/* Date         : 19/Sep/2005                                                   */
/********************************************************************************/
/* Modification history                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230  */
/********************************************************************************/
CREATE PROCEDURE de_design_sp_tcpgtc_o
	@ctxt_language engg_ctxt_language, --Input 
	@ctxt_ouinstance engg_ctxt_ouinstance, --Input 
	@ctxt_service engg_ctxt_service, --Input 
	@ctxt_user engg_ctxt_user, --Input 
	@engg_act_descr engg_name, --Input 
	@engg_component engg_description, --Input 
	@engg_customer_name engg_name, --Input 
	@engg_ico_no engg_name, --Input 
	@engg_page_descr engg_name, --Input 
	@engg_proj_proc_descr engg_description, --Input 
	@engg_project_name engg_name, --Input 
	@engg_task_name engg_name, --Input 
	@engg_tc_hdrtask_descr engg_description, --Input 
	@engg_tc_page engg_name, --Input 
	@engg_ui_descr engg_name, --Input 
	@m_errorid INT OUTPUT --To Return Execution Status 
AS
BEGIN
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0

	--declaration of temporary variables
	--temporary and formal parameters mapping
	--null checking
	IF @ctxt_language = - 915
		SET @ctxt_language = NULL

	IF @ctxt_ouinstance = - 915
		SET @ctxt_ouinstance = NULL

	IF @ctxt_service = '~#~'
		SET @ctxt_service = NULL

	IF @ctxt_user = '~#~'
		SET @ctxt_user = NULL

	IF @engg_act_descr = '~#~'
		SET @engg_act_descr = NULL

	IF @engg_component = '~#~'
		SET @engg_component = NULL

	IF @engg_customer_name = '~#~'
		SET @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SET @engg_ico_no = NULL

	IF @engg_page_descr = '~#~'
		SET @engg_page_descr = NULL

	IF @engg_proj_proc_descr = '~#~'
		SET @engg_proj_proc_descr = NULL

	IF @engg_project_name = '~#~'
		SET @engg_project_name = NULL

	IF @engg_task_name = '~#~'
		SET @engg_task_name = NULL

	IF @engg_tc_hdrtask_descr = '~#~'
		SET @engg_tc_hdrtask_descr = NULL

	IF @engg_tc_page = '~#~'
		SET @engg_tc_page = NULL

	IF @engg_ui_descr = '~#~'
		SET @engg_ui_descr = NULL

	DECLARE @process_name_tmp engg_name

	SELECT @process_name_tmp = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_proj_proc_descr

	DECLARE @component_name_tmp engg_name

	SELECT @component_name_tmp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_descr = @engg_component

	DECLARE @activity_name_tmp engg_name

	SELECT @activity_name_tmp = activity_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_descr = @engg_act_descr

	DECLARE @ui_name_tmp engg_name

	SELECT @ui_name_tmp = ui_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_descr = @engg_ui_descr

	DECLARE @map_flag_tmp INT
	DECLARE @map_ml_flag_tmp INT
	DECLARE @page_bt_synonym_tmp engg_name
	DECLARE @section_bt_synonym_tmp engg_name
	DECLARE @task_name_tmp engg_name
	DECLARE @control_bt_synonym_tmp engg_name
	DECLARE @ord_flg INT
	DECLARE @guid engg_guid

	-- 	select @guid = newid()
	-- 	if @engg_tc_page<>'All' 
	-- 		declare curActSecCtl cursor for 
	-- 		select 	a.page_bt_synonym ,
	-- 				a.section_bt_synonym ,
	-- 				b.task_name ,
	-- 				a.column_bt_synonym
	-- 		from 	de_ui_control_dtl_vw a ,
	-- 				ep_published_action_section_map_vw b
	-- 		where 	a.customer_name	= @engg_customer_name
	-- 		and		a.project_name	= @engg_project_name	
	-- 		and		a.process_name	= @process_name_tmp
	-- 		and		a.component_name= @component_name_tmp
	-- 		and 	a.activity_name	= @activity_name_tmp
	-- 		and		a.ui_name		= @ui_name_tmp
	-- 		and		b.task_name 	= @engg_task_name 
	-- 		and		a.page_bt_synonym = @engg_tc_page	
	-- 		--and		a.section_bt_synonym = @engg_tc_section
	-- 		and 	a.customer_name	*= b.customer_name
	-- 		and		a.project_name	*= b.project_name
	-- 		and		a.req_no		*= b.req_no
	-- 		and		a.process_name	*= b.process_name
	-- 		and		a.component_name*= b.component_name
	-- 		and 	a.activity_name	*= b.activity_name
	-- 		and		a.ui_name		*= b.ui_name
	-- 		and		a.section_bt_synonym *= b.section_bt_synonym
	-- 		and 	a.base_ctrl_type <>'grid'	
	-- 	--else if @engg_task_name<>'All' and @engg_tc_page='All' and @engg_tc_section<>'All'
	-- 	else if @engg_tc_page='All' 
	-- 		declare curActSecCtl cursor for 
	-- 		select 	a.page_bt_synonym ,
	-- 				a.section_bt_synonym ,
	-- 				b.task_name ,
	-- 				a.column_bt_synonym
	-- 		from 	de_ui_control_dtl_vw a ,
	-- 				ep_published_action_section_map_vw b
	-- 		where 	a.customer_name	= @engg_customer_name
	-- 		and		a.project_name	= @engg_project_name	
	-- 		and		a.process_name	= @process_name_tmp
	-- 		and		a.component_name= @component_name_tmp
	-- 		and 	a.activity_name	= @activity_name_tmp
	-- 		and		a.ui_name		= @ui_name_tmp
	-- 		and		b.task_name 	= @engg_task_name 
	-- 		--and		a.page_bt_synonym = @engg_tc_page	
	-- 		--and		a.section_bt_synonym = @engg_tc_section
	-- 		and 	a.customer_name	*= b.customer_name
	-- 		and		a.project_name	*= b.project_name
	-- 		and		a.req_no		*= b.req_no
	-- 		and		a.process_name	*= b.process_name
	-- 		and		a.component_name*= b.component_name
	-- 		and 	a.activity_name	*= b.activity_name
	-- 		and		a.ui_name		*= b.ui_name
	-- 		and		a.section_bt_synonym *= b.section_bt_synonym	
	-- 		and 	a.base_ctrl_type <>'grid'
	-- 
	-- 
	-- 	open curActSecCtl
	-- 	
	-- 	fetch next from curActSecCtl into 
	-- 		@page_bt_synonym_tmp , @section_bt_synonym_tmp , 
	-- 		@task_name_tmp , @control_bt_synonym_tmp
	-- 
	-- 	while @@fetch_status = 0
	-- 	begin
	-- 		-- if the task is not mapped to 'ep_published_action_section_map_vw' table
	-- 		-- or 'de_task_control_map' table to 
	-- 		-- show that record at last(@ord_flg = 2) set flags as not set(not checked)
	-- 		-- show this at last
	-- 		select @ord_flg = 2
	-- 		select @map_flag_tmp = 0 
	-- 		select @map_ml_flag_tmp = 0 
	-- 		
	-- 		-- this task is alredy mapped in this 'ep_published_action_section_map_vw' table
	-- 		-- then show it at the top and mapped recirds
	-- 		-- show this after mapped records in 'de_task_control_map' table
	-- 		if @task_name_tmp is not null  
	-- 		begin
	-- 			select @ord_flg = 1
	-- 			select @map_flag_tmp = 0 
	-- 			select @map_ml_flag_tmp = 0 
	-- 		end
	-- 
	-- 		select @task_name_tmp = @engg_task_name
	-- 		-- check the the selected task is alredy mapped in 'de_task_control_map' 
	-- 		-- the current page ,section and control 
	-- 		if exists ( select 'x' from de_task_control_map nolock	
	-- 					where 	customer_name	= @engg_customer_name
	-- 					and		project_name	= @engg_project_name	
	-- 					and		process_name	= @process_name_tmp
	-- 					and		component_name  = @component_name_tmp
	-- 					and 	activity_name	= @activity_name_tmp
	-- 					and		ui_name			= @ui_name_tmp
	-- 					and		action_name 	= @engg_task_name 
	-- 					and		page_name = @page_bt_synonym_tmp	
	-- 					and		section_name = @section_bt_synonym_tmp
	-- 					and		control_bt_synonym = @control_bt_synonym_tmp )
	-- 		begin
	-- 				-- if the the selected task is alredy mapped 
	-- 				-- to the current page ,section, and control. 
	-- 				-- if mapped  to display the record at the top 
	-- 				-- set this @ord_flg = 0
	-- 				
	-- 				select @ord_flg = 0  
	-- 				-- save the selected task in temperary variable, if it is not there it will
	-- 				select @task_name_tmp = @engg_task_name
	-- 				select 	@map_flag_tmp = case map_flag when 'Y' then 1 when 'N' then 0 end ,
	-- 						@map_ml_flag_tmp = case map_ml_flag when 'Y' then 1 when 'N' then 0 end
	-- 				from de_task_control_map ( nolock	)
	-- 				where 	customer_name	= @engg_customer_name
	-- 				and		project_name	= @engg_project_name	
	-- 				and		process_name	= @process_name_tmp
	-- 				and		component_name  = @component_name_tmp
	-- 				and 	activity_name	= @activity_name_tmp
	-- 				and		ui_name			= @ui_name_tmp
	-- 				and		action_name 	= @task_name_tmp 
	-- 				and		page_name = @page_bt_synonym_tmp	
	-- 				and		section_name = @section_bt_synonym_tmp
	-- 				and		control_bt_synonym = @control_bt_synonym_tmp
	-- 			
	-- 		end		
	-- 		
	-- 		insert into de_task_control_map_tmp 
	-- 		(	timestamp , createdby , createddate , modifiedby , modifieddate ,
	-- 			guid , ord_flg , page_bt_synonym , section_bt_synonym , task_name ,
	-- 			control_bt_synonym , map_flag , map_ml_flag )
	-- 		values 
	-- 		(	1 , @ctxt_user , getdate() , @ctxt_user , getdate() , 
	-- 			@guid , @ord_flg , @page_bt_synonym_tmp , @section_bt_synonym_tmp , @task_name_tmp , 
	-- 			@control_bt_synonym_tmp , @map_flag_tmp , @map_ml_flag_tmp )
	-- 	
	-- 		fetch next from curActSecCtl into 
	-- 		@page_bt_synonym_tmp , @section_bt_synonym_tmp , 
	-- 		@task_name_tmp , @control_bt_synonym_tmp
	-- 
	-- 	end	
	-- 	
	-- 	close curActSecCtl
	-- 	deallocate curActSecCtl
	IF @engg_tc_page = 'All'
		SET @engg_tc_page = '%'
	SET @engg_tc_page = replace(replace(@engg_tc_page, '[', '%'), ']', '%')

	-- 	Select	@page_bt_synonym_tmp	= page_bt_synonym
	-- 	from	de_ui_page		(nolock)
	-- 	where	customer_name		= @engg_customer_name
	-- 	and		project_name		= @engg_project_name
	-- 	and		process_name		= @process_name_tmp
	-- 	and		component_name		= @component_name_tmp
	-- 	and		activity_name		= @activity_name_tmp
	-- 	and		ui_name				= @ui_name_tmp
	-- 	and		page_descr			like @engg_page_descr
	SELECT CASE map_ml_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_all',
		CASE map_flag
			WHEN 'Y'
				THEN 1
			ELSE 0
			END 'engg_map_flag',
		control_bt_synonym 'engg_tc_ctrl_bts',
		page_name 'engg_tc_page_name',
		section_name 'engg_tc_sec_name',
		action_name 'engg_tc_task_name',
		mapping_instance 'engg_mapping_instance',
		CASE [Load] WHEN 'Y' THEN 1 ELSE 0 END 'engg_tc_load', ---TECH-75230
		control_type 'engg_tc_ctrl_type'	---TECH-75230
	FROM de_task_control_map(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @process_name_tmp
		AND component_name = @component_name_tmp
		AND activity_name = @activity_name_tmp
		AND ui_name = @ui_name_tmp
		AND page_name LIKE @engg_tc_page
		AND action_name = @engg_task_name

	/* 
	--OuputList
	Select null 'engg_map_all', 
	null 'engg_map_flag', 
	null 'engg_tc_ctrl_bts', 
	null 'engg_tc_page_name', 
	null 'engg_tc_sec_name', 
	null 'engg_tc_task_name', 
	null 'engg_mapping_instance' from *** 
*/
	SET NOCOUNT OFF
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_design_sp_tcpgtc_o' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_design_sp_tcpgtc_o TO PUBLIC
END
GO