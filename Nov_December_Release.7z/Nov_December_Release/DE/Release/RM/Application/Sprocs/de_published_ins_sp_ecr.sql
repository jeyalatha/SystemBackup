IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_ins_sp_ecr' AND TYPE = 'P')
BEGIN
	DROP PROC de_published_ins_sp_ecr
END
GO
/*      V E R S I O N      :  PNR2.0_25308    */
/*      Released By        :  Development Team    */
/*      Release Comments   :  Phase 4 Release    */
/***************************************************************************************
 Procedure Name And Id            :      de_published_ins_sp_ecr
 Description                      :      
 Name Of The Author               :      Feroz
 Date Created                     :      7/7/04
 Query File Name                  :      de_published_ins_sp_ecr.sql
 Modifications History            :      
 Modified By                      :      
 Modified Date                    :      
 modified purpose                 :      
 Detailed Description             :      
 modification history                                                        		*/
/* Modified by : Gowrisankar for callid PNR2.0_4079				   	*/
/* Modified on : 03/09/05	 							*/
/* Description : Modification of the Enumerated Caption based on the language extension */
/************************************************************************************** */
/* Modified by : Anuradha						                */    
/* Modified on : 16 Mar 2006              					*/    
/* Description : Bug Id : PNR2.0_7254           				*/    
/********************************************************************************/   
/* Modified By  :	Date : 		Description :				*/
/* S K Mohamed Mohideen	15 Jun 2006	Task Confirmation Message changes	*/
/********************************************************************************/
/* Modified by : kiruthika R									   						*/
/* Modified on : 12/07/06	 														   */
/* Description : PNR2.0_9417															*/
/***************************************************************************************/
/* Modified by : Gowriasnkar M									   					   */
/* Modified on : 01-Nov-2006	 													   */
/* Description : PNR2.0_10761														   */
/***************************************************************************************/
/* Modified By  :	Date : 		Description :				*/
/* S K Mohamed Mohideen	10 Nov 2006	Task Status Message changes		*/
/********************************************************************************/
/* Modified by : Feroz		 													*/
/* Modified on : 08/11/06	 													*/
/* Description : State Processing 												*/
/********************************************************************************/
/* Modified by : Feroz		 													*/
/* Modified on : 28/06/07	 													*/
/* Description : AVS			 												*/
/********************************************************************************/
/* Modified by : hemalatha.K		 													*/
/* Modified on : 10/07/07	 													*/
/* Description : CVS			 												*/
/********************************************************************************/
/* Modified by : chanheetha N A													*/
/* Modified on : 18-Jul-2007	 												*/
/* Description : Added the column HIDDEN_VIEW_SOURCE in the table de_published_hidden_view */
/* Bug ID      : PNR2.0_14538                                                   */
/********************************************************************************/
/* Modified by : Feroz		 													*/
/* Modified on : 07/09/07	 													*/
/* Description : Health Monitoring												*/
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 25-Apr-2008                                                  */
/* Bug Id  : PNR2.0_1476          												*/
/********************************************************************************/
/* modified by  : Jeya Latha K                                                  */
/* date         : 13-May-2008                                                  	*/
/* Bug Id  	: PNR2.0_1522          												*/
/********************************************************************************/
/* Modified by : kiruthika R 													*/
/* Modified on : 01-aug-2008	 												*/
/* Description :  (multiple_ttx column added) 									*/
/* Bug ID      : PNR2.0_18491                                                  	*/
/********************************************************************************/
/* modified by  : Sangeetha G                                           		*/
/* date         : 16-Sep-2008                                           		*/
/* Bug Id  	: PNR2.0_19250          											*/
/* Modified for : Cannot insert the Value NULL into column 'map_ml_flag'		*/
/*	          table 'Publish_db.dbo.de_published_hidden_view_usage' 			*/
/********************************************************************************/
/* Modified by  : Gopinath S													*/
/* Date         : 06-OCT-2008													*/
/* Bug ID       : PNR2.0_19480													*/
/********************************************************************************/
/* Modified By					: chanheetha n a 								*/
/* Date						: 13-Nov-2008								 		*/
/* Bug ID					: PNR2.0_19951								 		*/
/* Description					: for handle changes							*/
/********************************************************************************/
/* modified by			: Feroz													*/
/* date					: 25-nov-2008											*/
/* BugId				: PNR2.0_1790 											*/
/********************************************************************************/
/* Modified By			: Sangeetha G 												*/
/* Date					: 5-Dec-2008												*/
/* Bug ID				: PNR2.0_20243 												*/
/* Description			: To incorporate the Email and trail bar in the report aspx	*/
/************************************************************************************/
/* modified by  : Sangeetha G                                           */
/* date         : 19-May-2009                                           */
/* Bug Id 	: PNR2.0_22275 						*/
/* modified for : To include page focus in state processing		*/
/************************************************************************/
/* modified by  : Feroz				                                            */
/* date         : 04-Aug-2009                                                   */
/* Bug Id 		: PNR2.0_2179													*/
/* Description  : Phase 3 Features - ListEdit, AttachDocument, Image & DateHighlight */
/********************************************************************************/
/* Modified By					: Feroz										 */
/* Date							: 26-Aug-2009								 */
/* Description					: PNR2.0_23463 								 */
/******************************************************************************/
/* Modified By     : Chanheetha N A        */
/* Date      : 23-Oct-2009         */
/* Bug Id      : PNR2.0_24424         */
/* Description     : Pagename added for mapped controls to launch EzeeView Link from model  */
/*************************************************************************************************************************/
/* modified by  : Feroz				                                            */
/* date         : 19-Jan-2010                                                   */
/* Bug Id 		: PNR2.0_25308													*/
/* Description  : Phase 4 Features												*/
/********************************************************************************/
/* Modified By					: 	Jeya Latha K						 	*/
/* Date							: 	26-Feb-2010								*/
/* Description					: 	Bug ID PNR2.0_26087						*/
/******************************************************************************/
/* Modified By					: Jeya Latha K								 */
/* Date							: 08-Feb-2010								 */
/* Description					: PNR2.0_25863 								 */
/******************************************************************************/
/* Modified By					: 	Jeya Latha K				 */
/* Date							: 	02-Mar-10					 */
/* Description					: 	Bug ID PNR2.0_26118			*/
/******************************************************************************/
/* Modified By					: 	Sangeetha G		*/
/* Date						: 	05-Apr-10		*/
/* Bugid					: 	PNR2.0_26335		*/
/* Modified For					: 	Traversal table schema change	*/
/**********************************************************************************************/
/* Modified By					: Sangeetha G 			              */
/* Date						: 28-Apr-2010				      */
/* Bug Id 					: PNR2.0_26701 				      */
/* Description					: Column addition for ListEdit Resolve tables */
/***********************************************************************************************/
/* Modified By					: Chanheetha N A		              */
/* Date						: 19-May-2010				      */
/* Bug Id 					: PNR2.0_26860 				      */
/* Description					: Column addition for freezecount             */
/***********************************************************************************************/
/* modified by		: Jeyalatha K 											*/
/* date				: 11-Feb-2011                                           */
/* Bug Id			: PNR2.0_30127											*/
/* Modified for		: Feature  Release										*/
/****************************************************************************/
/* modified by   : Sangeetha G												*/  
/* date			 : 11-Apr-2011												*/  
/* BugId		 : PNR2.0_30869												*/  
/* modified for	 : Feature Release											*/  
/****************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: May 18 2011												*/
/* Bug ID		: PNR2.0_31403 												*/
/* Case Desc	: Tree Grid Feature Enhancement.							*/
/****************************************************************************/  
/* modified by   : Jeya Latha K												*/  
/* date			 : 28-Oct-2011												*/  
/* BugId		 : PNR2.0_33318												*/  
/* modified for	 : Feature Release											*/  
/****************************************************************************/
/* modified by	: Balaji D											   		*/
/* modified on	: 15-Oct-2011												*/
/* Bug ID		: PNR2.0_34035 	[Changed Objects Bug Id :PNR2.0_35184]		*/
/* Case Desc	: Chart table schema change									*/
/*********************************************************************************/ 
/* modified by  :	Muthupand S												     */
/* date         :	07-Feb-2012													 */
/* Bug ID		:	PNR2.0_35480 												 */
/* Description	:	To populate the data for the newly added columns in existing Tables */							 
/*********************************************************************************/  
/* modified by	: Balaji D											   		*/
/* modified on	: Dec 31 2011												*/
/* Bug ID		: PNR2.0_35984 												*/
/* Case Desc	: Modelling for Splitter Section.							*/
/****************************************************************************/
/* modified by  : Balaji D  			                                    */
/* date         : July 02 2012			                                    */
/* BugId        : PLF2.0_00961 			                                    */
/* Case Desc    : PopUpSection,Button Right Align,Page/Button/Link Images.  */
/****************************************************************************/  
/* modified by  :	Kiruthika R												*/
/* date         :	06-Mar-2013											    */
/* Bug ID		:	PLF2.0_03710 											*/
/* Description	:	Customlist implementation for header edit controls.		*/
/****************************************************************************/
/* modified by  :	Gankan G												*/
/* date         :	28-May-2013												*/
/* Bug ID		:	PLF2.0_04721 											*/
/* Description	:	Code modified to handle equal	tabwidth				*/
/****************************************************************************/
/* modified by  :	Gankan G												*/
/* date         :	28-Oct-2013												*/
/* Bug ID		:	PLF2.0_06542 											*/
/* Description	:	Code modified to handle req_nofor handle changes		*/
/****************************************************************************/
/* modified by  :	Shakthi P														 */
/* date         :	26-FEB-2014												     	 */
/* Bug ID		:	PLF2.0_07676 													 */
/* Description	:	Changes for 2.x-3.x iEDK Tab Index,Custom CSS inclusion, Grid Tool */
/*Bar Hiding, Grid Tool Bar With Only Pagination, Grid Without Column Seperator and Grid Without Row Seperator	*/
/*************************************************************************************/
/* modified by  :	 Shakthi P             															*/
/* date         : 12-Mar-2014            														*/
/* Bug ID  		: PLF2.0_07805          														  */
/* Description 	: Changes for Section Level RowSpan, ColSpan, Filler Section - Control Level RowSpan        			  */
/*********************************************************************************/
/* modified by  : Veena U   			                                        */
/* date         : Oct 10 2014			                                        */
/* BugId        : PLF2.0_09035													*/
/* description  : Model changes for rowspan,colspan,IsStatic,IsCallout 
				  in  layout level.												*/
/********************************************************************************/
/* modified by  : Veena U														*/
/* date         : 25-Feb-2015													 */
/* Bug ID		:  PLF2.0_11499															 */
/* Description  :  Code added for table deletion in de_published_user_section*/
/********************************************************************************/  
/* Modified by  : Veena U	                                                  */
/* Date         : 07-Aug-2015                                                  */
/* Defect ID	: PLF2.0_14096                                                 */
/********************************************************************************/
 /* Modified by  : Veena U	                                                  */
/* Date         : 24-Dec-2015*/
/* Defect ID	: PLF2.0_16153                                                 */
/********************************************************************************/
/* Modified by  : Veena U	                                                  */
/* Date         : 02-Feb-2016                                                  */
/* Defect ID	: PLF2.0_16291													*/
/********************************************************************************/
/* Created by  	: Veena U                                                */
/* Date         : 16-March-2016                                                  */
/*Defect Id 	: PLF2.0_17326												*/
/********************************************************************************/ 
/* Created by  	: Veena U                                                */
/* Date         : 28-Mar-2016                                                  */
/*Defect Id 	: PLF2.0_17570										*/
/********************************************************************************/ 
/* modified by			Date				Defect ID							*/
/* Veena U				08-Jun-2016			PLF2.0_18487						*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S/Ranjitha R      for callid  TECH-10118                   */
/* Modified on : 30-May-2017                                                                                        */
/* Description : Platform Feature Release                                                              */
/********************************************************************************/
/* Modified by  : Jeya Latha K		Date: 16-Aug-2017  Defect ID	:TECH-12776	*/ 
/********************************************************************************/ 
/* Modified by  : JeyaLatha/Ranjitha    Defect ID: TECH-16126      On: 30-Nov-2017*/
/**********************************************************************************************/
/* Modified by  : Jeya Latha K		             Date: 30-Apr-2018  Defect ID : TECH-20897    */ 
/* Modified by  : Jeya Latha K/Venkatesan K	     Date: 31-Oct-2018  Defect ID : TECH-28010    */
/* Modified by  : Jeya Latha K				     Date: 08-Jan-2019  Defect ID : TECH-29822    */   
/* Modified by  : Jeya Latha K				     Date: 25-Jul-2019  Defect ID:  TECH-36371    */
/* Modified by  : Jeya Latha K  	             Date: 29-Jan-2020  Defect ID : TECH-42483    */
/* Modified by  : Rajeswari M/Jeya Latha K       Date: 27-Feb-2020  Defect ID : TECH-43307    */
/* Modified by  : Rajeswari M/Jeya Latha K		 Date: 24-Apr-2020  Defect ID : TECH-45546    */
/* Modified by  : Rajeswari M/Jeya Latha K		 Date: 06-May-2020  Defect ID : TECH-45828    */ 
/**********************************************************************************************/
/* Modified by		: Venkatesan K													          */
/* Modified Date	: 13-May-2020 	                                                          */
/* Defect ID		: TECH-46163													          */
/* Remarks   		: Platform Model Enhancement - Adding Report type control in 
						SP based report screen and adding new report type SSRS & DW.		  */
/* Modified by : Rajeswari M/Jeya Latha K   Date: 14-Jul-2020  Defect ID : TECH-47978		  */
/* Modified by : Rajeswari M/Priyadharshini U Date: 28-Jul-2021  Defect ID : TECH-60451       */
/* TECH-60451  : Launching Help&Link UIs, Popup sections and Grid Extensions in Side Drawer   */
/* TECH-61144  : New Feature--Task API Mapping												  */
/* TECH-61907  : Task API Mapping															  */
/* TECH-63527  : Associate Control added in ep_ui_control_dtl for Multiselectcombo			  */ 
/**********************************************************************************************/
/* Modified By	: Venkatesan K																  */
/* Defect ID	: TECH-66583																  */
/* Modified on	: 24Feb2022																	  */
/* Description	: RVW 2.0 Model publish table implementation for control and task property.	  */
/**********************************************************************************************/
/* Modified By	: Ponmalar A / Priyadharshini U												  */
/* Defect ID	: TECH-67697																  */
/* Modified on	: 31Mar2022																	  */
/* Description	: GQL Changes.																  */
/**********************************************************************************************/
/* Modified By	: Priyadharshini U															  */
/* Defect ID	: TECH-68064																  */
/* Modified on	: 13-Apr-2022																  */
/* Description	: Provision to specify PSR, PMR, PSMR in refine service in design engineering
				  and design service in design refinements.									  */
/**********************************************************************************************/
/* Modified By	: Ponmalar A/Priyadharshini U												  */
/* Defect ID	: TECH-68066																  */
/* Modified on	: 13-Apr-2022																  */
/* Description	: Post and Pre Tasks for Attachment controls.								  */
/**********************************************************************************************/
/* modified by  : Venkatesan K																  */
/* Date         : 13-APR-2022																  */
/* Defect ID	: TECH-68067																  */
/* Description  : Provision to download all the attachments as bulk in Grid Control.		  */
/**********************************************************************************************/
/* modified by  : Ponmalar A																  */
/* Date         : 13-APR-2022																  */
/* Defect ID	: TECH-68063																  */
/* Description  : Provision to map captions for control, column, section and Page in gql.	  */
/**********************************************************************************************/
/* modified by  : Ponmalar A																  */
/* Date         : 27-MAY-2022																  */
/* Defect ID	: TECH-69327																  */
/* Description  : Provision for modeling bubble message - 
				  display the multiple messages when we fire a task - Bubble message		  */
/**********************************************************************************************/
/* Modified by	:	Priyadharshini U 											*/
/* Modified on	:	08/06/22				 									*/
/* Defect ID	:	TECH-69624													*/
/* Description	:	Custom border, Custom actions and Responsive layout			*/
/********************************************************************************/
/* Modified by	:	VimalKumar R												*/
/* Modified on	:	11/07/22				 									*/
/* Defect ID	:	TECH-70687													*/
/* Description	:	Tool and Toolbars											*/
/********************************************************************************/
/* Modified by : Vimal Kumar R 													*/
/* Modified on : 27-July-2022                                                   */
/* Defect ID   : TECH-71262														*/
/* Description : Platform Features for the Month of July'22                     */
/********************************************************************************/
/* Modified By	: Ponmalar A													*/
/* Defect ID	: TECH-72114													*/
/* Modified on	: 22-Aug-2022													*/
/* Description	: 	Platform Release for the month of August'22					*/
/********************************************************************************/
/* Modified by : Ponmalar A		Date: 30-Sep-2022		Defect ID  : TECH-73216 */
/****************************************************************************************/
/* Modified by : Athul M / Vimal Kumar R												*/
/* Modified on : 27-Oct-2022															*/
/* Defect ID   : TECH-73996																*/
/* Description : Addition of attributes for control types in setup ui preferences screen*/
/****************************************************************************************/
/* Modified By	: Priyadharshini U														*/
/* Defect ID	: TECH-72114															*/
/* Modified on	: 22-Aug-2022															*/
/* Description	: Report modeling enablement in platform model for GQL based 
user interfaces																			*/
/****************************************************************************************/
/* Modified By	: Ponmalar A															*/
/* Defect ID	: TECH-75230															*/
/* Modified on	: 01-Dec-2022															*/
/* Description	: Platform Release for the month of Nov'22								*/
/****************************************************************************************/
CREATE PROCEDURE de_published_ins_sp_ecr
	@ctxt_ouinstance           engg_ctxt_ouinstance,
	@ctxt_user                 engg_ctxt_user,
	@ctxt_language             engg_ctxt_language,
	@ctxt_service              engg_ctxt_service,
	@customername              engg_name,
	@projectname               engg_name,
	@processname		   	   engg_name,
	@componentname 		   	   engg_name,
	@ecrno			   		   engg_name,
	@m_errorid                 engg_seqno   out
as
begin
	set nocount on

	insert into de_published_business_rule (ecrno, br_descr, br_doc, br_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, rule_sysid, timestamp) 
	select  @ecrno, br_descr, br_doc, br_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, newid(), timestamp from de_business_rule (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
		
	insert into de_published_business_object (ecrno, bo_descr, bo_doc, bo_name, bo_sysid, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, bo_descr, bo_doc, bo_name, newid(), component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp from de_business_object (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

--code modified for the call id : PNR2.0_19951 starts
	insert into de_published_bo_segment (ecrno, bo_name, bo_segment_descr, bo_segment_doc, bo_segment_instance, bo_segment_name, bo_segment_sysid, bo_sysid, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp,bo_segment_gen_name,implementation_type,implementation_name,bo_segment_gen_flag,bo_segment_cur_name) --chan
	select  @ecrno, bo_name, bo_segment_descr, bo_segment_doc, bo_segment_instance, bo_segment_name, newid(), bo_sysid, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp,bo_segment_gen_name,implementation_type,implementation_name,bo_segment_gen_flag,bo_segment_cur_name from de_bo_segment (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_bo_segment_dataitem (ecrno, bo_name, bo_segment_dataitem_descr, bo_segment_dataitem_doc, bo_segment_dataitem_name, bo_segment_dataitem_sysid, bo_segment_name, bo_segment_sysid, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp,bo_dataitem_gen_flag,part_of_key,bo_dataitem_gen_name,bo_dataitem_cur_name) --chan
	select  @ecrno, bo_name, bo_segment_dataitem_descr, bo_segment_dataitem_doc, bo_segment_dataitem_name, newid(), bo_segment_name, bo_segment_sysid, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, timestamp,bo_dataitem_gen_flag,part_of_key,bo_dataitem_gen_name,bo_dataitem_cur_name from de_bo_segment_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--code modified for the call id : PNR2.0_19951 ends	
	-- DDT Columns added for the BugId PNR2.0_1790
	insert into de_published_action_section_map (ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, section_page_bt_synonym, task_name, task_section_sysid, task_sysid, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, section_page_bt_synonym, task_name, newid(), task_sysid, timestamp, ui_name from de_action_section_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
--code modified for the call id : PNR2.0_19951 starts		
	insert into de_published_action (ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, primary_control_bts, process_name, project_name, task_descr, task_name, task_pattern, task_seq, task_sysid, task_type, timestamp, ui_name, ui_sysid, task_confirm_msg, task_status_msg,Act_flag,usageid	,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,	-- Column added by Mohideen on Jun 15, 2006 --chan
	task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close--Column added  for PNR2.0_30869 ,PLF2.0_00234
	,iscallout
	,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control	
	,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload,
	sectionlaunchtype, QuickTask, SystemTaskType,  -- Added for the Defect ID TECH-29822
	Systemgenerated)	--TECH-73216
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, primary_control_bts, process_name, project_name, task_descr, task_name, task_pattern, task_seq, newid(), task_type, timestamp, ui_name, ui_sysid, task_confirm_msg, task_status_msg,'Y',	usageid	,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,
    task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close 	-- Column added by Mohideen on Jun 15, 2006 ,--Code Modification for PNR2.0_30869 ends ,PLF2.0_00234
    ,iscallout ,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
	,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload,
	sectionlaunchtype, QuickTask, SystemTaskType,  -- Added for the Defect ID TECH-29822
    Systemgenerated	--TECH-73216
	from de_action (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--code modified for the call id : PNR2.0_19951 ends	


--Code modification for PNR2.0_26335 starts
	insert into de_published_ui_traversal (ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name,  linked_activity, linked_component, linked_ui, link_type, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, timestamp, treaversal_sysid, ui_name, ui_page_sysid, associated_ctrl_bt_synonym,trvsl_seq,Width,Height,Toolbar_notreq,LinkLaunchType) 
	select  @ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name,  linked_activity, linked_component, linked_ui, link_type, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym,timestamp, newid(), ui_name, ui_page_sysid, associated_ctrl_bt_synonym ,trvsl_seq,Width,Height,Toolbar_notreq,LinkLaunchType from de_ui_traversal (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--Code modification for PNR2.0_26335 ends
	--code modified by kiruthika for bugid:PNR2.0_9417		
	insert into de_published_ui_section (ecrno, activity_name, border_required, component_name, createdby, createddate, customer_name,  horder, modifiedby, modifieddate, page_bt_synonym, page_sysid, parent_section, process_name, project_name, section_bt_synonym, section_doc, timestamp, title_alignment, title_required, ui_name, ui_section_sysid, visisble_flag, vorder, 
	width, height, section_type, SectionPrefixClass, caption_Format, ctrl_caption_align, Setion_width_Scalemode, Setion_height_Scalemode, section_prefix,Associated_control,splitter_pos,section_collapsemode,NColSpan,NRowSpan,/*IsStatic,*/section_collapse,CarouselNavigation ,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,IsPlatform,Slidingbar_Height, IsResponsive, mob_pop_fullview, -- Code modified for  PNR2.0_31403 ,PNR2.0_34863 ,PLF2.0_17570
	BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor, BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, ForResponsive,--Code added for TECH-69624
	LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,MinimizedRows,ViewMode,HasTitleAction,	--Code added for TECH-70687
	TitleIcon,Orientation) ----Code Added for the Defect Id TECH-72114	--TECH-75230
	select  @ecrno, activity_name, border_required, component_name, createdby, createddate, customer_name,  horder, modifiedby, modifieddate, page_bt_synonym, page_sysid, parent_section, process_name, project_name, section_bt_synonym, section_doc, timestamp,title_alignment, title_required, ui_name, newid(), visisble_flag, vorder,
	width, height, section_type, SectionPrefixClass, caption_Format, ctrl_caption_align, Setion_width_Scalemode, Setion_height_Scalemode, section_prefix,Associated_control,splitter_pos,section_collapsemode,NColSpan,NRowSpan,/*IsStatic ,*/section_collapse,CarouselNavigation,cell_spacing,cell_padding,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,IsPlatform,Slidingbar_Height, IsResponsive, mob_pop_fullview,
	BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor, BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle,  ForResponsive, --Code added for TECH-69624
	LeftToolbar,RightToolbar,TopToolbar,BottomToolbar,MinimizedRows,ViewMode,HasTitleAction,	--Code added for TECH-70687
	TitleIcon,Orientation	--TECH-75230
	from de_ui_section (nolock) -- Code modified for  PNR2.0_31403 ,PNR2.0_34863,PLF2.0_17570	
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
		
	insert into de_published_ui_page (ecrno, activity_name, component_name, createdby, createddate, customer_name,  horder, modifiedby, modifieddate, page_bt_synonym, page_doc, page_prefix, process_name, project_name, timestamp, ui_name, ui_page_sysid, ui_sysid, vorder, page_type, pageimage,width,PageClass,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,-- code modified for the caseid: PLF2.0_00961--PLF2.0_04721,PLF2.0_17570
	LeftToolbar,RightToolbar,TopToolbar,BottomToolbar)	--Code added for TECH-70687
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  horder, modifiedby, modifieddate, page_bt_synonym, page_doc, page_prefix, process_name, project_name, timestamp, ui_name, newid(), ui_sysid, vorder ,page_type, pageimage,width,PageClass,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,
	LeftToolbar,RightToolbar,TopToolbar,BottomToolbar	--Code added for TECH-70687
	from de_ui_page (nolock) -- code modified for the caseid: PLF2.0_00961 --PLF2.0_04721,PLF2.0_17570
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	--Code Modification for PNR2.0_30869 starts 

	
	insert into de_published_ui_pageevents (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,
						EventRequired,Task_Onclick,SystemGenerated,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name, @ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,
						EventRequired,Task_Onclick,SystemGenerated,timestamp,createdby,createddate,modifiedby,modifieddate
	from de_ui_pageevents (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	--Code Modification for PNR2.0_30869 ends 

		
	insert into de_published_ibo_segment_dataitem (ecrno, component_name, createdby, createddate, customer_name,  ibo_name, ibo_segment_dataitem_descr, ibo_segment_dataitem_doc, ibo_segment_dataitem_name, ibo_segment_dataitem_sysid, ibo_segment_name, ibo_segment_sysid, modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, component_name, createdby, createddate, customer_name,  ibo_name, ibo_segment_dataitem_descr, ibo_segment_dataitem_doc, ibo_segment_dataitem_name, ibo_segment_dataitem_sysid, ibo_segment_name, ibo_segment_sysid, modifiedby, modifieddate, process_name, project_name, timestamp from de_ibo_segment_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ibo_segment (ecrno, component_name, createdby, createddate, customer_name,  ibo_name, ibo_segment_descr, ibo_segment_doc, ibo_segment_instance, ibo_segment_name, ibo_segment_sysid, ibo_sysid, modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, component_name, createdby, createddate, customer_name,  ibo_name, ibo_segment_descr, ibo_segment_doc, ibo_segment_instance, ibo_segment_name, ibo_segment_sysid, ibo_sysid, modifiedby, modifieddate, process_name, project_name, timestamp from de_ibo_segment (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

-- code uncommented by Anuradha on 16-Mar-2006 for the bug id : PNR2.0_7254	
--Code modification for PNR2.0_19250  starts
 	insert into de_published_hidden_view_usage (ecrno, action_name, activity_name, component_name, control_bt_sysnonym, control_page_name, createdby, createddate, customer_name,  hidden_view_bt_sysnonym, modifiedby, modifieddate, page_name, process_name, project_name, timestamp, ui_name,map_ml_flag) 
 	select  @ecrno, action_name, activity_name, component_name, control_bt_sysnonym, control_page_name, createdby, createddate, customer_name,  hidden_view_bt_sysnonym, modifiedby, modifieddate, page_name, process_name, project_name, timestamp, ui_name , map_ml_flag from de_hidden_view_usage (nolock)
 	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--Code modification for PNR2.0_19250  ends
-- code uncommented by Anuradha on 16-Mar-2006 for the bug id : PNR2.0_7254		
	insert into de_published_hidden_view (ecrno, activity_name, component_name, control_bt_synonym, control_id, control_sysid, createdby, createddate, customer_name,  hidden_view_bt_synonym, hidden_view_sysid, modifiedby, modifieddate, new_control_bt_synonym	, page_name, process_name, project_name, section_name, timestamp, transfer_flag, ui_name, view_name,HIDDEN_VIEW_SOURCE) /* PNR2.0_14538 */
	select  @ecrno, activity_name, component_name, control_bt_synonym, control_id, control_sysid, createdby, createddate, customer_name,  hidden_view_bt_synonym, newid(), modifiedby, modifieddate, new_control_bt_synonym, page_name, process_name, project_name	, section_name, timestamp, transfer_flag, ui_name, view_name,HIDDEN_VIEW_SOURCE from de_hidden_view (nolock)/*PNR2.0_14538*/
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	--insert into de_published_glossary_lng_extn (ecrno, bt_name, bt_synonym_caption, bt_synonym_doc, bt_synonym_name, component_name, createdby, createddate, customer_name, data_type,  glossary_sysid, languageid, length, modifiedby, modifieddate, multiinst_sample_data, process_name, project_name, ref_bt_synonym_name, singleinst_sample_data, synonym_status, timestamp) 
	--select  @ecrno, bt_name, bt_synonym_caption, bt_synonym_doc, bt_synonym_name, component_name, createdby, createddate, customer_name, data_type,  glossary_sysid, languageid, length, modifiedby, modifieddate, multiinst_sample_data, process_name, project_name, ref_bt_synonym_name, singleinst_sample_data, synonym_status, timestamp from de_glossary_lng_extn (nolock)
	--where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_glossary (ecrno, bt_name, bt_synonym_caption, bt_synonym_doc, bt_synonym_name, component_name, createdby, createddate, customer_name, data_type,  glossary_sysid, length, modifiedby, modifieddate, multiinst_sample_data, process_name, project_name, ref_bt_synonym_name, singleinst_sample_data, synonym_status, timestamp, IsGlance) 
	select  @ecrno, bt_name, bt_synonym_caption, bt_synonym_doc, bt_synonym_name, component_name, createdby, createddate, customer_name, data_type,  glossary_sysid, length, modifiedby, modifieddate, multiinst_sample_data, process_name, project_name, ref_bt_synonym_name, singleinst_sample_data, synonym_status, timestamp, IsGlance from de_glossary (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_flowbr_rule_map (ecrno, activity_name, br_component_name, br_id, br_name, br_sysid, br_type, component_name, createdby, createddate, customer_name,  flowbr_name, flowbr_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, seq_no, task_name, timestamp, ui_name) 
	select  @ecrno, activity_name, br_component_name, br_id, br_name, newid(), br_type, component_name, createdby, createddate, customer_name,  flowbr_name, flowbr_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, seq_no, task_name, timestamp, ui_name from de_flowbr_rule_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_flowbr_method_map (ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, metbr_sysid, method_name, modifiedby, modifieddate, process_name, project_name, service_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, newid(), method_name, modifiedby, modifieddate, process_name, project_name, service_name, timestamp, ui_name from de_flowbr_method_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_flowbr_combo (ecrno, activity_name, combo_bt_synonym, combo_page_name, combo_sysid, component_name, createdby, createddate, customer_name,  flowbr_name, flowbr_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, task_name, timestamp, ui_name, clear_tree_before_population) 
	select  @ecrno, activity_name, combo_bt_synonym, combo_page_name, newid(), component_name, createdby, createddate, customer_name,  flowbr_name, flowbr_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, task_name, timestamp, ui_name, clear_tree_before_population from de_flowbr_combo (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_flowbr_br_error (ecrno, activity_name, br_id, br_sysid, component_name, createdby, createddate, customer_name, default_flag,  flowbr_name, message_descr, message_id, modifiedby, modifieddate, msg_severity, msg_sysid, page_bt_synonym, process_name, project_name, task_name, timestamp, ui_name, error_context) 
	select  @ecrno, activity_name, br_id, br_sysid, component_name, createdby, createddate, customer_name, default_flag,  flowbr_name, message_descr, message_id, modifiedby, modifieddate, msg_severity, newid(), page_bt_synonym, process_name, project_name, task_name, timestamp, ui_name, error_context from de_flowbr_br_error (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_flowbr (ecrno, activity_name, component_name, control_id, createdby, createddate, customer_name,  event_name, flowbr_descr, flowbr_name, flowbr_sequence, flowbr_sysid, map_flag, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, task_name, task_sysid, timestamp, ui_name, view_name) 
	select  @ecrno, activity_name, component_name, control_id, createdby, createddate, customer_name,  event_name, flowbr_descr, flowbr_name, flowbr_sequence, newid(), map_flag, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, task_name, task_sysid, timestamp, ui_name, view_name from de_flowbr (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	insert into de_published_enum_value (ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  enum_caption, enum_code, enum_value_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, seq_no, timestamp, ui_name, ui_page_sysid) 
	select  @ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  enum_caption, enum_code, newid(), modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, seq_no, timestamp, ui_name, ui_page_sysid from de_enum_value (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
	insert into de_published_enum_value_lng_extn (ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  enum_caption, enum_code, enum_value_sysid, languageid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, seq_no, timestamp, ui_name, ui_page_sysid) 
	select  @ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  enum_caption, enum_code, newid(), languageid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, section_bt_synonym, seq_no, timestamp, ui_name, ui_page_sysid from de_enum_value_lng_extn (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
	
	insert into de_published_download_log (ecrno, activity_name, component_name, createdby, createddate, customer_name, doc_no,  l1, l2, l3, l4, logged_by, logged_date, log_type, modifiedby, modifieddate, process_name, project_name, seq_no, table_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name, doc_no,  l1, l2, l3, l4, logged_by, logged_date, log_type, modifiedby, modifieddate, process_name, project_name, seq_no, table_name, timestamp, ui_name from de_download_log (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	insert into de_published_business_term (ecrno, bt_descr, bt_name, bt_sysid, component_name, createdby, createddate, customer_name, data_type,  length, modifiedby, modifieddate, precision_type, process_name, project_name, timestamp,Generatedby) 
	select  @ecrno, bt_descr, bt_name, newid(), component_name, createdby, createddate, customer_name, data_type,  length, modifiedby, modifieddate, precision_type, process_name, project_name, timestamp,Generatedby from de_business_term (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

--Code modification for PNR2.0_19250  starts	

	insert into de_published_refine_methods 
	(ecrno, activity_name, component_name, createdby, createddate, customer_name,  include_flag, method_name, modifiedby, modifieddate, 
	process_name, project_name, ps_name, refmet_sysid, sequence_no, service_name, spname, timestamp, ui_name, update_flag,accessdatabase,
	isintegbr,operationtype,refined_flag,ref_method_name,systemgenerated, ProcessingType,  --TECH-68064
	sperrorprotocol  --TECH-69327	
	) 
	select  
	@ecrno, activity_name, component_name, createdby, createddate, customer_name,  include_flag, method_name, modifiedby, modifieddate, 
	process_name, project_name, ps_name, newid(), sequence_no, service_name, spname, timestamp, ui_name, update_flag ,accessdatabase,
	isintegbr,operationtype,refined_flag,ref_method_name,systemgenerated, ProcessingType,  --TECH-68064
	sperrorprotocol --TECH-69327	
	from de_refine_methods (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname 
	and  component_name = @componentname 
	
--Code modification for PNR2.0_19250  ends
	
	insert into de_published_refine_method_error_map (ecrno, activity_name, component_name, correctiveaction, createdby, createddate, customer_name, des_errorno, des_error_desc, detaileddesc,  flowbr_name, map_flag, method_name, modifiedby, modifieddate, process_name, project_name, req_errorno, req_error_desc, service_name, severity, sp_errorno, sp_error_desc, timestamp, ui_name, error_context) 
	select  @ecrno, activity_name, component_name, correctiveaction, createdby, createddate, customer_name, des_errorno, des_error_desc, detaileddesc,  flowbr_name, map_flag, method_name, modifiedby, modifieddate, process_name, project_name, req_errorno, req_error_desc, service_name, severity, sp_errorno, sp_error_desc, timestamp, ui_name, error_context from de_refine_method_error_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_refine_method_documentation (ecrno, component_name, createdby, createddate, customer_name,  flowbr_name, method_doc, method_name, modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, component_name, createdby, createddate, customer_name,  flowbr_name, method_doc, method_name, modifiedby, modifieddate, process_name, project_name, timestamp from de_refine_method_documentation (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_radio_button (ecrno, activity_name, button_caption, button_code, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  horder, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, radio_button_sysid, section_bt_synonym, seq_no, timestamp, ui_control_sysid, ui_name, vorder) 
	select  @ecrno, activity_name, button_caption, button_code, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  horder, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, radio_button_sysid, section_bt_synonym, seq_no, timestamp, ui_control_sysid, ui_name, vorder from de_radio_button (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079
	insert into de_published_radio_button_lng_extn (ecrno, activity_name, button_caption, button_code, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  horder, languageid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, radio_button_sysid, section_bt_synonym, seq_no, timestamp, ui_control_sysid, ui_name, vorder) 
	select  @ecrno, activity_name, button_caption, button_code, component_name, control_bt_synonym, createdby, createddate, customer_name, default_flag,  horder, languageid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, radio_button_sysid, section_bt_synonym, seq_no, timestamp, ui_control_sysid, ui_name, vorder from de_radio_button_lng_extn (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	--code added by Gowrisankar on 3-Oct-2005 for the callid PNR2.0_4079

	insert into de_published_publication_dataitem (ecrno, activity_name, component_name, createdby, createddate, customer_name, dataitemname,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, publication_dataitem_sysid, publication_name, publication_sysid, published_bt_synonym, published_control_name, published_flow_direction, published_view_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name, dataitemname,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, newid(), publication_name, publication_sysid, published_bt_synonym, published_control_name, published_flow_direction, published_view_name, timestamp, ui_name from de_publication_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_publication (ecrno, activity_name, component_name, createdby, createddate, customer_name,  linkid, modifiedby, modifieddate, process_name, project_name, publication_descr, publication_doc, publication_name, publication_sysid, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  linkid, modifiedby, modifieddate, process_name, project_name, publication_descr, publication_doc, publication_name, newid(), timestamp, ui_name from de_publication (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_precision_type (ecrno, component_name, createdby, createddate, customer_name, decimal_length,  modifiedby, modifieddate, process_name, project_name, pt_descr, pt_name, pt_sysid, timestamp, total_length) 
	select  @ecrno, component_name, createdby, createddate, customer_name, decimal_length,  modifiedby, modifieddate, process_name, project_name, pt_descr, pt_name, newid(), timestamp, total_length from de_precision_type (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	

	insert into de_published_subscription_dataitem (ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, subscribed_bt_synonym, subscribed_control_name, subscribed_flow_direction, subscribed_view_name, subscription_dataitem_sysid, subscription_name, subscription_sysid, timestamp, ui_name,Qlik_dataitem) --Vwqlik change
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, subscribed_bt_synonym, subscribed_control_name, subscribed_flow_direction, subscribed_view_name,newid(), subscription_name, subscription_sysid, timestamp, ui_name ,Qlik_dataitem from de_subscription_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_subscription (ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name,  link_type, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, subscription_descr, subscription_doc, subscription_name, subscription_sysid, sugg_publishing_act_name, sugg_publishing_comp_name, sugg_publishing_ui_name, timestamp, ui_name,post_task,
	 post_linktask) --Column added  for PNR2.0_30869 
-- code modified by shafina on 31-Jan-2005 for ECPF204ACC_000020 (Adding new column post_task in re_subscription , re_published_subscription, re_resolved_link ,re_published_resolved_link & for de tables also.)
	select  @ecrno, activity_name, component_name, control_bt_synonym, createdby, createddate, customer_name,  link_type, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, subscription_descr, subscription_doc, subscription_name, newid(),sugg_publishing_act_name, sugg_publishing_comp_name, sugg_publishing_ui_name, timestamp, ui_name,post_task , post_linktask from de_subscription (nolock)    --Column added  for PNR2.0_30869 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_service_gen_log_dtl (ecrno, activity_name, component_name, createdby, createddate, customer_name,  log_text, modifiedby, modifieddate, process_name, project_name, sequence_no, service_name, task_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  log_text, modifiedby, modifieddate, process_name, project_name, sequence_no, service_name, task_name, timestamp, ui_name from de_service_gen_log_dtl (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_service_gen_log (ecrno, activity_name, component_name, createdby, createddate, customer_name,  generation_date, modifiedby, modifieddate, no_of_methods, process_name, project_name, service_name, task_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  generation_date, modifiedby, modifieddate, no_of_methods, process_name, project_name, service_name, task_name, timestamp, ui_name from de_service_gen_log (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_scratch_variables_sys (ecrno, btname, btsynonym, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, scratchtype, spdatatype, timestamp) 
	select  @ecrno, btname, btsynonym, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, scratchtype, spdatatype, timestamp from de_scratch_variables_sys (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ui_ico (ecrno, activity_descr, activity_name, component_descr, component_name, createdby, createddate, customer_name,   ico_descr, ico_no, ico_status, ico_sysid, modifiedby, modifieddate, process_descr, process_name, project_name, timestamp, ui_descr, ui_name,ecr_no) 
	select  @ecrno, activity_descr, activity_name, component_descr, component_name, createdby, createddate, customer_name,   ico_descr, ico_no, ico_status, newid(), modifiedby, modifieddate, process_descr, process_name, project_name, timestamp, ui_descr, ui_name,ecr_no from de_ui_ico (nolock)
	where customer_name = @customername and  project_name = @projectname  and ico_no = @ecrno and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ui_grid (ecrno, activity_name, column_bt_synonym, column_no, column_prefix, column_type, col_doc, component_name, control_bt_synonym, control_id, createdby, createddate, customer_name,  grid_sysid, modifiedby, modifieddate, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, ui_control_sysid, ui_name, view_name, visible_length,Set_User_Pref,Default_required,visible,ColumnClass,Forcefit,TemplateID,iskey,Kyseq_no,
	TemplateCategory,TemplateSpecific,RowExpander, GridToForm,Column_class_ext6,icon_position,icon_class,TreeColumn,column_Transformas,sensitivedata,IsPlatform, CompactView,MoreEventEnabled,UpeSetFocusEnabled ,IsExtension,ExtensionOrder,AssociateControl) -- Added for TECH-20897,Added for the Defect ID TECH-45828, TECH-60451	--13639 on 22ndJuly2022
	select  @ecrno, activity_name, column_bt_synonym, column_no, column_prefix, column_type, col_doc, component_name, control_bt_synonym, control_id, createdby, createddate, customer_name,  newid(), modifiedby, modifieddate, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, ui_control_sysid, ui_name, view_name, visible_length,Set_User_Pref,Default_required,visible,ColumnClass,Forcefit,TemplateID,iskey,Kyseq_no,
	TemplateCategory,TemplateSpecific,RowExpander, GridToForm,Column_class_ext6,icon_position,icon_class,TreeColumn,column_Transformas, sensitivedata,IsPlatform, CompactView,MoreEventEnabled,UpeSetFocusEnabled, IsExtension,ExtensionOrder,AssociateControl from de_ui_grid (nolock)  --13639 on 22ndJuly2022
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	-- New column AccessKey added for the BugID PNR2.0_1522
	insert into de_published_ui_control (ecrno, activity_name, component_name, control_bt_synonym, control_doc, control_id, control_prefix, control_type, createdby, createddate, customer_name, data_column_width,  horder, label_column_width, modifiedby, modifieddate, order_seq, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, ui_control_sysid, ui_name, ui_section_sysid, view_name, visisble_length, vorder, label_column_scalemode, data_column_scalemode, 
	tab_seq, help_tabstop, LabelClass, ControlClass, LabelImageClass, ControlImageClass, AccessKey, Set_User_Pref, freezecount, controlimage, colspan, rowspan,TemplateID,Preserve_visible_length,Auto_width_column,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,sensitivedata,IsPlatform, DynamicStyle, ImageAsData,	UpeSetFocusEnabled,	MoreEventEnabled,ExtensionReqd,ExtensionLaunchMode,AssociateControl,-- code Added by Gopinath S for the Call ID PNR2.0_19480 -- code modified for the caseid: PNR2.0_26860,PLF2.0_00961,TECH-20897, TECH-60451,code added for TECH-63527
	BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor, BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, HasCustomAction, ForResponsive,	--Code added for TECH-69624
	ControlFormat,ButtonNature, InlineStyle )--TECH-75230
	select  @ecrno, activity_name, component_name, control_bt_synonym, control_doc, control_id, control_prefix, control_type, createdby, createddate, customer_name, data_column_width,  horder, label_column_width, modifiedby, modifieddate, order_seq, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, newid(), ui_name, ui_section_sysid, view_name, visisble_length, vorder, label_column_scalemode, data_column_scalemode, 
    tab_seq, help_tabstop, LabelClass, ControlClass, LabelImageClass, ControlImageClass, AccessKey, Set_User_Pref, freezecount, controlimage, colspan, rowspan,TemplateID,Preserve_visible_length,Auto_width_column ,TemplateCategory,TemplateSpecific,Control_class_ext6,icon_position,icon_class,sensitivedata,IsPlatform, DynamicStyle, ImageAsData,	UpeSetFocusEnabled,	MoreEventEnabled ,ExtensionReqd,ExtensionLaunchMode,AssociateControl,
	BorderLeftWidth, BorderRightWidth, BorderTopWidth, BorderBottomWidth, BorderLeftColor, BorderRightColor, BorderTopColor, BorderBottomColor, BorderTopLeftRadius, BorderTopRightRadius, BorderBottomLeftRadius, BorderBottomRightRadius, BorderStyle, HasCustomAction, ForResponsive	,ControlFormat,
	ButtonNature, InlineStyle --TECH-75230
	from de_ui_control (nolock) -- code modified for the caseid: PNR2.0_26860,PLF2.0_00961,Added for the Defect ID TECH-45828, TECH-60451,code added for TECH-63527	--Code added for TECH-69624
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_non_ui_control (ecrno, activity_name, component_name, control_bt_synonym, control_doc, control_id, control_prefix, control_type, createdby, createddate, customer_name, data_column_width,  horder, label_column_width, modifiedby, modifieddate, order_seq, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, ui_control_sysid, ui_name, ui_section_sysid, view_name, visisble_length, vorder, label_column_scalemode, data_column_scalemode)
	select  @ecrno, activity_name, component_name, control_bt_synonym, control_doc, control_id, control_prefix, control_type, createdby, createddate, customer_name, data_column_width,  horder, label_column_width, modifiedby, modifieddate, order_seq, page_bt_synonym, process_name, project_name, proto_tooltip, sample_data, section_bt_synonym, timestamp, newid(), ui_name, ui_section_sysid, view_name, visisble_length, vorder, label_column_scalemode, data_column_scalemode from de_non_ui_control (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ui (ecrno, activity_name, base_activity_name, base_component_name, base_ui_name, caption_alignment, component_name, createdby, createddate, current_req_no, customer_name,  modifiedby, modifieddate, process_name, project_name, tab_height, timestamp, trail_bar, ui_descr, ui_doc, ui_format, ui_name, ui_sysid, ui_type, grid_type, state_processing, callout_type,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req,Hide_Print,personalization,
	Exclude_Systemtabindex,DeviceType,TabStyle,IsDesktop,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,DBName,ui_subtype,IsGlance, NativeApplication, Conditional_popupclose,Titlebar_Search,
	Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar, --Code added for TECH-70687
	TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --Code Added for the Defect Id TECH-72114
	PullToRefresh)	--TECH-75230
	select  @ecrno, activity_name, base_activity_name, base_component_name, base_ui_name, caption_alignment, component_name, createdby, createddate, current_req_no, customer_name,  modifiedby, modifieddate, process_name, project_name, tab_height, timestamp, trail_bar, ui_descr, ui_doc, ui_format, ui_name, newid(), ui_type, grid_type, state_processing ,callout_type,New_Line_Ui,Tab_Type,PostLaunchTask,TabPosition,SmartHide,Is_device,HideIlbotitlemenu_req,Hide_Print,personalization,
	Exclude_Systemtabindex,DeviceType,TabStyle,IsDesktop,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation,hide_imp_defaults,DBName,ui_subtype,IsGlance, NativeApplication, Conditional_popupclose,Titlebar_Search,
	Sidebar,Docked,LeftToolbar,RightToolbar,TopToolbar,BottomToolbar, --Code added for TECH-70687
	TemplateJSON, StyleSheet, ConfigurationXML, TemplateJSONDBC, StyleSheetDBC, ConfigurationXMLDBC, --Code Added for the Defect Id TECH-72114
	PullToRefresh	--TECH-75230
	from de_ui (nolock)-- PLF2.0_16291,PLF2.0_17570
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_task_service_map (ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, service_name, taskser_sysid, task_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, service_name, newid(), task_name, timestamp, ui_name from de_task_service_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_task_control_map (ecrno, action_name, activity_name, component_name, control_bt_synonym, control_id, createdby, createddate, customer_name,  map_flag, map_ml_flag, modifiedby, modifieddate, new_control_bt_synonym, page_name, process_name, project_name, section_name, tc_sysid, timestamp, ui_name, view_name, mapping_instance,Load , control_type) 
	select  @ecrno, action_name, activity_name, component_name, control_bt_synonym, control_id, createdby, createddate, customer_name,  map_flag, map_ml_flag, modifiedby, modifieddate, new_control_bt_synonym, page_name, process_name, project_name, section_name, newid(), timestamp, ui_name, view_name, mapping_instance, Load, control_type from de_task_control_map (nolock)	--TECH-75230
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--de_task_control_attributemap

	insert into de_published_task_control_attributemap (ecrno,customer_name,project_name,process_name,component_name,activity_name,ui_name,action_name,page_name,section_name,control_bt_synonym,timestamp,createdby,createddate,modifiedby,modifieddate,control_id,View_Name,new_control_bt_synonym,propertytype,propertyname,btname,type)
	Select @ecrno,customer_name,project_name,process_name,component_name,activity_name,ui_name,action_name,page_name,section_name,control_bt_synonym,timestamp,createdby,createddate,modifiedby,modifieddate,control_id,View_Name,new_control_bt_synonym,propertytype,propertyname,btname,type	from de_task_control_attributemap (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	-- Start for the feature Context Menu(PNR2.0_1476) -Added by Jeya -- PNR2.0_26118
-- 	Delete
-- 	from de_published_ui_contextmenu_task_dtl 
-- 	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
-- 	
-- 	
-- 	insert into de_published_ui_contextmenu_task_dtl (customer_name, project_name, process_name, component_name, activity_name, ui_name, 
-- 		page_name, section_name, control_bt_synonym, control_id, map_flag, task_name, task_descr, task_type, task_seq, task_pattern,timestamp, 
-- 		createdby, createddate, modifiedby, modifieddate, ecrno)
-- 	select 	customer_name, project_name, process_name, component_name, activity_name, ui_name,  page_name, section_name, control_bt_synonym, control_id, 
-- 		map_flag, task_name, task_descr, task_type, task_seq, task_pattern, timestamp, createdby, createddate, modifiedby, modifieddate,
-- 		@ecrno
-- 	from de_ui_contextmenu_task_dtl (nolock)
-- 	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- End for the feature Context Menu(PNR2.0_1476) -Added by Jeya 

	insert into de_published_rulegroup_step_msg (ecrno, brgroup_name, component_name, createdby, createddate, customer_name, default_flag,  message_descr, message_id, modifiedby, modifieddate, msg_severity, msg_sysid, process_name, project_name, step_id, step_sysid, timestamp) 
	select  @ecrno, brgroup_name, component_name, createdby, createddate, customer_name, default_flag,  message_descr, message_id, modifiedby, modifieddate, msg_severity, newid(), process_name, project_name, step_id, step_sysid, timestamp from de_rulegroup_step_msg (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_rulegroup_step (ecrno, brgroup_name, brgroup_sysid, br_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, step_id, step_no, step_sysid, timestamp) 
	select  @ecrno, brgroup_name, brgroup_sysid, br_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, step_id, step_no, newid(), timestamp from de_rulegroup_step (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_rulegroup (ecrno, brgroup_descr, brgroup_doc, brgroup_name, brgroup_sysid, component_name, createdby, createddate, customer_name,  exposed_flag, modifiedby, modifieddate, process_name, project_name, ref_brgroup_name, timestamp) 
	select  @ecrno, brgroup_descr, brgroup_doc, brgroup_name, newid(), component_name, createdby, createddate, customer_name,  exposed_flag, modifiedby, modifieddate, process_name, project_name, ref_brgroup_name, timestamp from de_rulegroup (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_rmt_ico_ui (ecrno, activity_descr, activity_name, component_descr, component_name, createdby, createddate, customer_name,   ico_descr, ico_no, modifiedby, modifieddate, process_descr, process_name, project_name, rcr_no, timestamp, ui_descr, ui_name) 
	select  @ecrno, activity_descr, activity_name, component_descr, component_name, createdby, createddate, customer_name,   ico_descr, ico_no, modifiedby, modifieddate, process_descr, process_name, project_name, rcr_no, timestamp, ui_descr, ui_name from de_rmt_ico_ui (nolock)
	where customer_name = @customername and  project_name = @projectname and  ecr_no = @ecrno and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_resolved_link_dataitem (ecrno, activity_name, component_name, createdby, createddate, customer_name, dataitemname,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, publication_act_name, publication_comp_name, publication_name, publication_ui_name, published_bt_synonym, published_control_name, published_flow_direction, published_view_name, resolved_link_dataitem_sysid, resolved_link_sysid, subscribed_bt_synonym, subscribed_control_name, subscribed_flow_direction, subscribed_view_name, subscription_name, timestamp, ui_name) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name, dataitemname,  modifiedby, modifieddate, page_bt_synonym, process_name, project_name, publication_act_name, publication_comp_name, publication_name, publication_ui_name, published_bt_synonym, published_control_name, published_flow_direction, published_view_name, newid(), resolved_link_sysid, subscribed_bt_synonym, subscribed_control_name, subscribed_flow_direction, subscribed_view_name, subscription_name, timestamp, ui_name from de_resolved_link_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_resolved_link (ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, publication_act_name, publication_comp_name, publication_name, publication_ui_name, resolved_link_sysid, subscription_name, timestamp, ui_name,post_task , post_linktask)   --Column added  for PNR2.0_30869 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  modifiedby, modifieddate, process_name, project_name, publication_act_name, publication_comp_name, publication_name, publication_ui_name, newid(), subscription_name, timestamp, ui_name,post_task, post_linktask from de_resolved_link (nolock)   --Column added  for PNR2.0_30869 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname  
	
--Code modification for PNR2.0_19250  starts

	
	insert into de_published_refine_process_section
	(ecrno, activity_name, component_name, createdby, createddate, customer_name,  include_flag, 
	modifiedby, modifieddate, process_name, project_name, ps_name, refps_sysid, sequence_no, service_name, 
	timestamp, ui_name, update_flag,refined_flag) 
	select 
	@ecrno, activity_name, component_name, createdby, createddate, customer_name,  include_flag, 
	modifiedby, modifieddate, process_name, project_name, ps_name, newid(), sequence_no, service_name, 
	timestamp, ui_name, update_flag ,refined_flag
	from de_refine_process_section (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname 
	and  component_name = @componentname 

--Code modification for PNR2.0_19250  ends
	
	insert into de_published_refine_parameter (ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, method_name, modifiedby, modifieddate, new_seq_no, parameter_name, process_name, project_name, refparam_sysid, required_flag, sequence_no, service_name, timestamp, ui_name, update_flag) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, method_name, modifiedby, modifieddate, new_seq_no, parameter_name, process_name, project_name, newid(), required_flag, sequence_no, service_name, timestamp, ui_name, update_flag from de_refine_parameter (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_method_message_map (ecrno, activity_name, component_name, corrective_action, createdby, createddate, customer_name, detail_description,  flowbr_name, map_flag, message_descr, message_id, message_severity, method_name, metmsg_sysid, modifiedby, modifieddate, process_name, project_name, service_name, sp_message_descr, sp_message_no, timestamp, ui_name, update_flag, error_context) 
	select  @ecrno, activity_name, component_name, corrective_action, createdby, createddate, customer_name, detail_description,  flowbr_name, map_flag, message_descr, message_id, message_severity, method_name, newid(), modifiedby, modifieddate, process_name, project_name, service_name, sp_message_descr, sp_message_no, timestamp, ui_name, update_flag, error_context from de_method_message_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_method_doc (ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, metdoc_sysid, method_doc, method_name, modifiedby, modifieddate, process_name, project_name, service_name, timestamp, ui_name, update_flag) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  flowbr_name, newid(), method_doc, method_name, modifiedby, modifieddate, process_name, project_name, service_name, timestamp, ui_name, update_flag from de_method_doc (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	

	insert into de_published_message (ecrno, component_name, createdby, createddate, customer_name,  error_descr, error_id, error_serverity, message_sysid, modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, component_name, createdby, createddate, customer_name,  error_descr, error_id, error_serverity, newid(), modifiedby, modifieddate, process_name, project_name, timestamp from de_message (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_is_interaction (ecrno, activity_name, component_name, createdby, createddate, customer_name,  ispos_sysid, is_name, is_position, modifiedby, modifieddate, parent_name, process_name, project_name, ps_name, ps_position, service_name, timestamp, ui_name, update_flag) 
	select  @ecrno, activity_name, component_name, createdby, createddate, customer_name,  ispos_sysid, is_name, is_position, modifiedby, modifieddate, parent_name, process_name, project_name, ps_name, ps_position, service_name, timestamp, ui_name, update_flag from de_is_interaction (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_is_dataitem_map (ecrno, activity_name, called_dataitem_name, called_segment_name, calling_dataitem_name, calling_segment_name, component_name, createdby, createddate, customer_name,  isdi_sysid, is_name, modifiedby, modifieddate, process_name, project_name, ps_name, service_name, timestamp, ui_name, update_flag) 
	select  @ecrno, activity_name, called_dataitem_name, called_segment_name, calling_dataitem_name, calling_segment_name, component_name, createdby, createddate, customer_name,  isdi_sysid, is_name, modifiedby, modifieddate, process_name, project_name, ps_name, service_name, timestamp, ui_name, update_flag from de_is_dataitem_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_interaction_bo (ecrno, bo_descr, bo_doc, bo_name, bo_sysid, component_name, createdby, createddate, customer_name,  inter_component_name, modifiedby, modifieddate, process_name, project_name, timestamp) 
	select  @ecrno, bo_descr, bo_doc, bo_name, newid(), component_name, createdby, createddate, customer_name,  inter_component_name, modifiedby, modifieddate, process_name, project_name, timestamp from de_interaction_bo (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	-- code modified by Ganesh for the callid :: PNR2.0_3812 on 09/09/05
	-- DDT Columns added for the BugId PNR2.0_1790
	--Code Modification for PNR2.0_30869 starts 
	insert into de_published_action_lng_extn (activity_name,component_name,createdby,createddate,customer_name,ecrno,languageid,modifiedby,modifieddate,page_bt_synonym,primary_control_bts,process_name,project_name,task_descr,task_name,task_pattern,task_seq,task_sysid,task_type,timestamp,ui_name,ui_sysid, task_confirm_msg, task_status_msg,usageid,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name ,task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close,Iscallout 	-- Column added by Mohideen on Jun 15, 2006,PLF2.0_00234
	,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
	,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload)
	select  activity_name, component_name, createdby, createddate, customer_name, @ecrno, languageid, modifiedby, modifieddate, page_bt_synonym, primary_control_bts, process_name, project_name, task_descr, task_name, task_pattern, task_seq, task_sysid, task_type, timestamp, ui_name, ui_sysid, task_confirm_msg, task_status_msg,		usageid	,ddt_page_bt_synonym,ddt_control_bt_synonym,ddt_control_id,ddt_view_name,task_process_msg,PopUp_page_bt_synonym,PopUp_section,PopUp_close, Iscallout 	-- Column added by Mohideen on Jun 15, 2006,PLF2.0_00234
	,QR_sourceCtrl,QR_targetCtrl,Barcode_sourceCtrl,Barcode_targetCtrl,browse_control
	,QR_sourceCtrl_Page,QR_targetCtrl_Page,Barcode_sourceCtrl_Page,Barcode_targetCtrl_Page,browse_control_Page,group_name,Buttonbar_primary_section,Popup_onclick_close,Autoupload
	from de_action_lng_extn (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
   --Code Modification for PNR2.0_30869 ends 

	/* Insert script added on 30/12/04 for published_schema */

	-- code added by Ganesh for the callid :: Platform_2.0.3.X_493 on 5/9/05
	insert into de_published_schema_column (ecrno, customer_name, project_name, process_name, component_name, db_name, table_name, column_name, column_descr, column_order, is_key, is_nullable, can_be_defaulted, is_upper, udd_name, ml_reqd, column_sysid, table_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, default_data, check_constraint, bo_name, bo_segment_name, bo_dataitem_name, gen_flag, generated_name, current_name,is_identity,is_computed,is_compformula)/*Modification made by Muthupandi S for Bug id : PNR2.0_35480*/
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, table_name, column_name, column_descr, column_order, is_key, is_nullable, can_be_defaulted, is_upper, udd_name, ml_reqd, column_sysid, table_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, default_data, check_constraint, bo_name, bo_segment_name, bo_dataitem_name, gen_flag, generated_name, current_name,is_identity,is_computed,is_compformula from de_schema_column/*Modification made by Muthupandi S for Bug id : PNR2.0_35480*/
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
		
	insert into de_published_schema_preference (ecrno, customer_name, project_name, process_name, component_name, db_name, entity_name, entity_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, entity_prefix, entity_suffix)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, entity_name, entity_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, entity_prefix, entity_suffix from de_schema_preference
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_schema_relation (ecrno, customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, relationship_type, relation_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, gen_flag, generated_name,current_name) 
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, relationship_type, relation_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, gen_flag, generated_name,current_name from de_schema_relation
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_schema_relation_det (ecrno, customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, parent_column_name, child_column_name, reldet_sysid, relation_sysid, timestamp, createdby, createddate, modifiedby, modifieddate)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, parent_table_name, child_table_name, relationship_name, parent_column_name, child_column_name, reldet_sysid, relation_sysid, timestamp, createdby, createddate, modifiedby, modifieddate from de_schema_relation_det
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_schema_scripts (ecrno, customer_name, project_name, process_name, component_name, db_name, object_type, object_name, script_option, script_file_name, script_text, script_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, last_gen_date)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, object_type, object_name, script_option, script_file_name, script_text, script_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, last_gen_date from de_schema_scripts
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
		
	insert into de_published_schema_table (ecrno, customer_name, project_name, process_name, component_name, db_name, table_name, table_descr, table_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, bo_name, bo_segment_name, gen_flag, generated_name, create_req, drop_req, pk_cons_req, unique_index_req, fk_cons_req, check_cons_req, insert_sp_create_req, insert_sp_drop_req, insert_sp_grant_req, delete_sp_create_req, delete_sp_drop_req, delete_sp_grant_req, current_name,table_type)/*Modification made by Muthupandi S for Bug id : PNR2.0_35480*/
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, table_name, table_descr, table_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, bo_name, bo_segment_name, gen_flag, generated_name, create_req, drop_req, pk_cons_req, unique_index_req, fk_cons_req, check_cons_req, insert_sp_create_req, insert_sp_drop_req, insert_sp_grant_req, delete_sp_create_req, delete_sp_drop_req, delete_sp_grant_req, current_name,table_type from de_schema_table/*Modification made by Muthupandi S for Bug id : PNR2.0_35480*/
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_schema_udd (ecrno, customer_name, project_name, process_name, component_name, db_name, udd_name, udd_descr, udd_datatype,udd_length, udd_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, udd_decimal_length, bt_name, gen_flag, generated_name, create_req, drop_req, current_name)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, udd_name, udd_descr, udd_datatype,udd_length, udd_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, udd_decimal_length, bt_name, gen_flag, generated_name, create_req, drop_req, current_name from de_schema_udd
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
		
	insert into de_published_schema_validation_log (ecrno, customer_name, project_name, process_name, component_name, db_name, guid, seq_no, date, validation_text, timestamp, createdby, createddate, modifiedby, modifieddate)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, guid, seq_no, date, validation_text, timestamp, createdby, createddate, modifiedby, modifieddate from de_schema_validation_log
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
		
	insert into de_published_schema_view (ecrno, customer_name, project_name, process_name, component_name, db_name, view_name, view_descr, view_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, gen_flag, generated_name, create_req, drop_req, grant_req, current_name)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, view_name, view_descr, view_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, gen_flag, generated_name, create_req, drop_req, grant_req, current_name from de_schema_view
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
		
	insert into de_published_schema_view_column (ecrno, customer_name, project_name, process_name, component_name, db_name, view_name, column_name, column_descr, view_column_sysid, view_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, column_order, data_type, length)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, view_name, column_name, column_descr, view_column_sysid, view_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, column_order, data_type, length from de_schema_view_column
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_schema_option (ecrno, customer_name, project_name, process_name, component_name, db_name, option_name, option_flag, option_sysid, timestamp, createdby, createddate, modifiedby, modifieddate)
	select  @ecrno, customer_name, project_name, process_name, component_name, db_name, option_name, option_flag, option_sysid, timestamp, createdby, createddate, modifiedby, modifieddate from de_schema_option
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 


	-- added by feroz

	-- code modified by Saravana for PNR2.0_10761 on 01-Nov-2006
-- 	insert into de_published_report_action_segment (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name, segment_instance, mandatory_flag, datatset_name, modifieddate, modifiedby, createddate, createdby, map_flg, segment_seqno, report_id)
-- 	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name, segment_instance, mandatory_flag, datatset_name, modifieddate, modifiedby, createddate, createdby, map_flg, segment_seqno, report_id from de_report_action_segment (nolock) 
-- 	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
-- 	-- code modified by Saravana for PNR2.0_10761 on 01-Nov-2006
-- 
-- 	insert into de_published_report_action_segment_dataitem (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name, dataitem_name, segment_instance, default_value, part_of_key, mandatory_flag, flow_attribute, modifieddate,
-- 	modifiedby, createddate, createdby, timestamp, processing_type, report_type,  report_page, report_context)
-- 	select 	customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_btsynonym, action_name, segment_name, dataitem_name, segment_instance, default_value, part_of_key, mandatory_flag, flow_attribute, modifieddate,
-- 	modifiedby, createddate, createdby, timestamp, processing_type, report_type,  report_page, report_context from 	de_report_action_segment_dataitem (nolock)
-- 	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	-- Code Modification by Sangeetha for PNR2.0_20243  starts 
	insert into de_published_report_attributes (customer_name,project_name,ecrno,process_name,component_name,
	   activity_name,ui_name,page_name,task_name,report_name,report_page,report_context,rpt_name,
	   	   processing_type,report_type,createdby,createddate,modifiedby,modifieddate,trailbar_req,email_req,report_descr)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_name,
		   task_name,report_name,report_page,report_context,rpt_name,processing_type,report_type,createdby,
		   		   createddate,modifiedby,modifieddate,trailbar_req,email_req,report_descr
	from   de_report_attributes (nolock)
	where  customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	-- Code Modification by Sangeetha for PNR2.0_20243  ends
	
	--code modified by kiruthika for bugid :PNR2.0_18491 starts
	insert into de_published_report_action_dataset_segment (customer_name,project_name,ecrno,process_name,component_name,
		   activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,segment_name,
		   segment_instance,segment_seqno,sub_report,rpt_name,createdby,createddate,modifiedby,modifieddate,multiple_ttx)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,
		   action_name,report_name,dataset_name,segment_name,segment_instance,segment_seqno,sub_report,
		   rpt_name,createdby,createddate,modifiedby,modifieddate,multiple_ttx
	--code modified by kiruthika for bugid :PNR2.0_18491 ends
	from   de_report_action_dataset_segment (nolock)
	where  customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	insert into de_published_report_action_dataset_dataitem (customer_name,project_name,ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,
		   dataitem_name,dataitem_seqno,createdby,createddate,modifiedby,modifieddate,segment_name,segment_dataitemname)
	select customer_name,project_name,@ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,
		   dataitem_name,dataitem_seqno,createdby,createddate,modifiedby,modifieddate,segment_name,segment_dataitemname
	from   de_report_action_dataset_dataitem (nolock)
	where  customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	insert into de_published_report_dataset_segment_map (customer_name,project_name,ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,segment_name,
		   segment_instance,segment_seqno,map_flg,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,segment_name,
		   segment_instance,segment_seqno,map_flg,createdby,createddate,modifiedby,modifieddate
	from   de_report_dataset_segment_map (nolock)
	where  customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	
	insert into de_published_report_dataset_dataitem_map (customer_name,project_name,ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,segment_name,
		   dataset_dataitemname,segment_dataitemname,dataitem_seqno,map_flg,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,
		   component_name,activity_name,ui_name,page_bt_synonym,action_name,report_name,dataset_name,segment_name,
		   dataset_dataitemname,segment_dataitemname,dataitem_seqno,map_flg,createdby,createddate,modifiedby,modifieddate
	from   de_report_dataset_dataitem_map (nolock)
	where  customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_report_action_dataset (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, action_name, dataset_name, dataset_description, timestamp, createdby, createddate, modifeidby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, action_name, dataset_name, dataset_description, timestamp, createdby, createddate, modifeidby, modifieddate from 	de_report_action_dataset (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--code added for bugid: PLF2.0_07676 starts
	insert into  de_published_sp_report_action_segment (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,task_name,report_name,report_page,report_context,rpt_name,segment_name,segment_instance,segment_seqno,sub_report,createdby,createddate,modifiedby,modifieddate,trailbar_req,email_req,report_descr, report_type)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,task_name,report_name,report_page,report_context,rpt_name,segment_name,segment_instance,segment_seqno,sub_report,createdby,createddate,modifiedby,modifieddate,trailbar_req,email_req,report_descr, report_type	--TECH-46163
	from de_sp_report_action_segment(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_sp_report_action_dataitem (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,task_name,report_name,segment_name,dataitem_name,dataitem_seqno,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,task_name,report_name,segment_name,dataitem_name,dataitem_seqno,createdby,createddate,modifiedby,modifieddate
	from   de_sp_report_action_dataitem(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--code added for bugid: PLF2.0_07676 ends

	insert into de_published_scratch_variable (customer_name, project_name, process_name, ecrno, component_name, activity_name, ui_name, page_name, task_name, scratch_name, scratch_variable_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, instance)
	select customer_name, project_name, process_name, @ecrno, component_name, activity_name, ui_name, page_name, task_name, scratch_name, scratch_variable_sysid, timestamp, createdby, createddate, modifiedby, modifieddate, instance from de_scratch_variable (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_tree_dtl  (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, event_req, mapped_task, open_img_name, not_exp_img_name, expendable_img_name, expended_img_name, 
	close_img_name, chkbox_chk_img, chkbox_unchk_img, chkbox_parial_chkimg, createdby, createddate, modifiedby, modifieddate )
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, event_req, mapped_task, open_img_name, not_exp_img_name, expendable_img_name, expended_img_name, 
	close_img_name, chkbox_chk_img, chkbox_unchk_img, chkbox_parial_chkimg, createdby, createddate, modifiedby, modifieddate from de_tree_dtl (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert  into de_published_tree_sample_data (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, createdby, createddate, modifiedby, modifieddate, Node_id)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_type, node_description, createdby, createddate, modifiedby, modifieddate,Node_id	from de_tree_sample_data (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_tree_sample_data_map (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id, node_type, node_description, parent_node_type, parent_node_descr, mapped_flag, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, node_id, parent_node_id, node_type, node_description, parent_node_type, parent_node_descr, mapped_flag, createdby, createddate, modifiedby, modifieddate from de_tree_sample_data_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_action_reuse_info (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_seq, task_pattern, reuse_activity, reuse_ui, reuse_page, reuse_task, timestamp, createdby, createddate, modifiedby, modifieddate, primary_control_bts, task_sysid, ui_sysid, task_type)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_seq, task_pattern, reuse_activity, reuse_ui, reuse_page, reuse_task, timestamp, createdby, createddate, modifiedby, modifieddate, primary_control_bts, task_sysid, ui_sysid, task_type from de_action_reuse_info (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	-- Added By Feroz For 203_3
	insert into de_published_chart_header (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, chart_type, chart_desc, chart_title, tooltip, datagrid, datagrid_type, legend_title, width, height, font, font_size, font_color, series_legend, background_color, graphicsmode, legend_font, legend_font_size, legend_font_color, x_axis_title, x_series_elements, x_error_band_type, x_error_marker_type, x_error_marker_size, x_error_marker_val, y_axis_title, x_auto_scale, x_divisions_min, x_divisions_max, x_units, x_cal_err_value, y_units, x_showvalue, 
	x_showname, x_font, x_font_size, x_font_color, x_con_type, x_con_color, x_con_style, x_con_weight, x_con_wt_val, x_marker_type, x_marker_size, x_marker_color, x_marker_size_val, y_series_elements, y_error_band_type, y_error_marker_type, y_error_marker_size, y_error_marker_value, y_auto_scale, y_divisions_min, y_divisions_max, y_secondary_axis, y_cal_err_value, y_font, y_font_size, y_font_color, y_con_type, y_connector_color, y_connector_style, y_con_weight, y_con_wt_val, y_marker_type, y_marker_size, y_marker_color, y_marker_size_val, background_image, override_chart_type, 
	x_show_err_band, y_show_err_band, createdby, createddate, modifiedby, modifieddate,x_numdivlines,y_numdivlines,canvas_color,divline_color)--Code Modified for the Bug ID: PNR2.0_34035
	select 	customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, chart_type, chart_desc, chart_title, tooltip, datagrid, datagrid_type, legend_title, width, height, font, font_size, font_color, series_legend, background_color, graphicsmode, legend_font, legend_font_size, legend_font_color, x_axis_title, x_series_elements, x_error_band_type, x_error_marker_type, x_error_marker_size, x_error_marker_val, y_axis_title, x_auto_scale, x_divisions_min, x_divisions_max, x_units, x_cal_err_value, y_units, x_showvalue, 
	X_showname, x_font, x_font_size, x_font_color, x_con_type, x_con_color, x_con_style, x_con_weight, x_con_wt_val, x_marker_type, x_marker_size, x_marker_color, x_marker_size_val, y_series_elements, y_error_band_type, y_error_marker_type, y_error_marker_size, y_error_marker_value, y_auto_scale, y_divisions_min, y_divisions_max, y_secondary_axis, y_cal_err_value, y_font, y_font_size, y_font_color, y_con_type, y_connector_color, y_connector_style, y_con_weight, y_con_wt_val, y_marker_type, y_marker_size, y_marker_color, y_marker_size_val, background_image, override_chart_type, 
	x_show_err_band, y_show_err_band, createdby, createddate, modifiedby, modifieddate ,x_numdivlines,y_numdivlines,canvas_color,divline_color from de_chart_header (nolock) --Code Modified for the Bug ID: PNR2.0_34035
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_chart_sample_data (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id, y_value, y_error_value, tooltip_text, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, x_series_data, y_series_id, y_value, y_error_value, tooltip_text, createdby, createddate, modifiedby, modifieddate from de_chart_sample_data (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_chart_series (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name, con_type, con_color, con_style, con_weight, con_wt_val, marker_type, marker_size, marker_size_val, mark_color, error_band_type, error_marker_type, error_marker_size, err_mark_size_val, auto_scale, divisions_min, divisions_max, units, x_showvalue, x_showname, sequence, y_secondary_axis, Y_Legend_Caption, cal_err_value, error_bands,  createdby, createddate, modifiedby, modifieddate, chart_type)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, axis_id, series_id, series_name, con_type, con_color, con_style, con_weight, con_wt_val, marker_type, marker_size, marker_size_val, mark_color, error_band_type, error_marker_type, error_marker_size, err_mark_size_val, auto_scale, divisions_min, divisions_max, units, x_showvalue, x_showname, sequence, y_secondary_axis, Y_Legend_Caption, cal_err_value, error_bands,  createdby, createddate, modifiedby, modifieddate, chart_type from de_chart_series (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_refine_chart_service_segment (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, servicename, segmentname, instanceflag, timestamp, createdby, createddate, modifiedby, modifieddate, map)
	select customer_name, project_name, @ecrno, process_name, component_name, chart_id, chart_section, servicename, segmentname, instanceflag, timestamp, createdby, createddate, modifiedby, modifieddate, map from de_refine_chart_service_segment (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
 
	insert into de_published_refine_chart_service_dataitem (customer_name, project_name, ecrno, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname, ispartofkey, mandatoryflag, flowattribute, defaultvalue, timestamp, createdby, createddate, modifiedby, modifieddate, map)
	select customer_name, project_name, @ecrno, process_name, component_name, chart_id, chart_section, chart_attribute, servicename, segmentname, dataitemname, ispartofkey, mandatoryflag, flowattribute, defaultvalue, timestamp, createdby, createddate, modifiedby, modifieddate, map from de_refine_chart_service_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	-- Added by feroz for spin control
	insert into de_published_spin_control (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, control_type, spin_control_bt_synonym, spincontrol_section, createdby, createddate, modifiedby, modifieddate )
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, control_type, spin_control_bt_synonym, spincontrol_section, createdby, createddate, modifiedby, modifieddate from de_spin_control (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	-- Added By feroz for state Processing
	insert into de_published_ui_state (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, state_id, state_descr, createdby, createddate, modifiedby, modifieddate, system_state)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, state_id, state_descr, createdby, createddate, modifiedby, modifieddate, system_state from de_ui_state (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ui_state_section (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, collapse, visible, enable, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, collapse, visible, enable, createdby, createddate, modifiedby, modifieddate from de_ui_state_section (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ui_state_control (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, visible, enable, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, visible, enable, createdby, createddate, modifiedby, modifieddate from de_ui_state_control (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

--code modified for the call id : PNR2.0_19951 starts
	insert into de_published_ui_state_task (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, task_name, rt_state, focus_control, createdby, createddate, modifiedby, modifieddate,task_descr)
	select a.customer_name, a.project_name, @ecrno, a.process_name, a.component_name, a.activity_name, a.ui_name, a.page_bt_synonym, a.state_id, a.task_name, a.rt_state, a.focus_control, a.createdby, a.createddate, a.modifiedby, a.modifieddate,b.task_descr from 	de_ui_state_task a (nolock) , de_action b (nolock)
	where a.customer_name = @customername and  a.project_name = @projectname and  a.process_name = @processname and  a.component_name = @componentname and   a.customer_name = b.customer_name  and  a.project_name = b.project_name  
	and  a.process_name = b.process_name  and  a.component_name = b.component_name and a.activity_name = b.activity_name and a.ui_name = b.ui_name and a.page_bt_synonym = b.page_bt_synonym and a.task_name = b.task_name
--code modified for the call id : PNR2.0_19951 ends

	insert into de_published_ui_state_task_mst (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, task_name, task_descr, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, task_name, task_descr, createdby, createddate, modifiedby, modifieddate from 	de_ui_state_task_mst (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

--	Code added for the BugId PNR2.0_1790 Starts
	insert into de_published_ui_state_column (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym, column_no, visible,  createdby, createddate, modifiedby, modifieddate,req_no,enable)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, section_bt_synonym, control_bt_synonym, column_bt_synonym, column_no, visible, createdby, createddate, modifiedby, modifieddate,'BASE',enable from 	de_ui_state_column (nolock)--PLF2.0_06542
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

-- Code modification  for  PNR2.0_22275 starts
	insert into de_published_ui_state_page (customer_name, project_name, ecr_no, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, visible, enable,   createdby, createddate, modifiedby, modifieddate,focus,req_no)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, state_id, visible, enable,  createdby, createddate, modifiedby, modifieddate , focus,'BASE' from 	de_ui_state_page (nolock)--PLF2.0_06542
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

-- Code modification  for  PNR2.0_22275 ends

--	Code added for the BugId PNR2.0_1790 Ends
------Code added for the BugId : PLF2.0_13289   Starts  
	insert into de_published_ezwiz_wizard (customer_name,project_name,process_name,component_name,ecrno,wizard_name,wizard_desc,
	wizard_type,subscription_level,timestamp,created_by,created_date,modified_by,modified_date,wizard_code)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name,wizard_desc,
	wizard_type,subscription_level,timestamp,created_by,created_date,modified_by,modified_date,wizard_code
	from de_ezwiz_wizard (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ezwiz_wizard_local_info (customer_name,project_name,process_name,component_name,ecrno,wizard_name,
	lang_id,wizard_desc,timestamp,created_by,created_date,modified_by,modified_date)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name,
	lang_id,wizard_desc,timestamp,created_by,created_date,modified_by,modified_date
	from de_ezwiz_wizard_local_info (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ezwiz_wizard_step (customer_name,project_name,process_name,component_name,ecrno,wizard_name,
	step_desc,step_seqno,target_ilboname,target_activityname,target_componentname,timestamp,created_by,created_date,modified_by,modified_date,
	subscription_level,target_ilbodesc,target_activitydesc,target_componentdesc)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name,
	step_desc,step_seqno,target_ilboname,target_activityname,target_componentname,timestamp,created_by,created_date,modified_by,modified_date,
	subscription_level,target_ilbodesc,target_activitydesc,target_componentdesc
	from de_ezwiz_wizard_step (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ezwiz_wizard_step_local_info (customer_name,project_name,process_name,component_name,ecrno,wizard_name,
	lang_id,step_desc,timestamp,created_by,created_date,modified_by,modified_date,step_seqno)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name,
	lang_id,step_desc,timestamp,created_by,created_date,modified_by,modified_date,step_seqno
	from de_ezwiz_wizard_step_local_info (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ezwiz_res_step_dataitem (customer_name,project_name,process_name,component_name,ecrno,wizard_name
	,parent_step_desc,child_step_desc,parent_bt_synonym,child_bt_synonym,parent_controlid,parent_viewname,child_controlid,
	child_viewname,timestamp,created_by,	created_date,modified_by,modified_date,parent_step_seqno,child_step_seqno)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name
	,parent_step_desc,child_step_desc,parent_bt_synonym,child_bt_synonym,parent_controlid,parent_viewname,child_controlid,
	child_viewname,timestamp,created_by,	created_date,modified_by,modified_date,parent_step_seqno,child_step_seqno
	from de_ezwiz_res_step_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ezwiz_res_ilbo_dataitem (customer_name,project_name,process_name,component_name,ecrno,wizard_name,
	parent_ilbo_desc,child_ilbo_desc,parent_ilbo_name,child_ilbo_name,parent_comp_desc,child_comp_desc,parent_act_desc,
	child_act_desc,parent_bt_synonym,child_bt_synonym,parent_controlid,parent_viewname,child_controlID,child_viewname
	,timestamp,created_by,created_date,modified_by,modified_date,step_seqno,step_desc)
	select distinct customer_name,project_name,process_name,component_name,@ecrno,wizard_name,
	parent_ilbo_desc,child_ilbo_desc,parent_ilbo_name,child_ilbo_name,parent_comp_desc,child_comp_desc,parent_act_desc,
	child_act_desc,parent_bt_synonym,child_bt_synonym,parent_controlid,parent_viewname,child_controlID,child_viewname
	,timestamp,created_by,created_date,modified_by,modified_date,step_seqno,step_desc
	from de_ezwiz_res_ilbo_dataitem (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 


----------   Code added for the BugId : PLF2.0_13289    Ends      
--	Code added for the BugId PNR2.0_1790 Starts
	insert into de_published_ezeeview_sp  (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,timestamp,createdby,createddate,modifiedby,modifieddate, Linked_Task)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,Link_ControlName,Target_SPName,Link_Caption,Linked_Component,Linked_Activity,Linked_ui,timestamp,createdby,createddate,modifiedby,modifieddate, Linked_Task from 	de_ezeeview_sp  (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ezeeview_spparamlist  (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,timestamp,createdby,createddate,modifiedby,modifieddate, control_page_name)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,Link_ControlName,Target_SPName,ParameterName,Mapped_Control,Link_Caption,timestamp,createdby,createddate,modifiedby,modifieddate, control_page_name from 	de_ezeeview_spparamlist  (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
--	Code added for the BugId PNR2.0_1790 Ends

	-- Added By feroz for AVS
	insert into avs_published_comp_bt_val (customer_name, project_name, ecrno, process_name, component_name, bt_name, validation_code, ref_val_group, value1, value2, eval_sequence, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, bt_name, validation_code, ref_val_group, value1, value2, eval_sequence, createdby, createddate, modifiedby, modifieddate from avs_component_bt_validation (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into avs_published_message (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, ref_val_group, generated_message, message_documentation, createdby, createddate, modifiedby, modifieddate, custom_message)
	select customer_name, project_name, @ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, ref_val_group, generated_message, message_documentation, createdby, createddate, modifiedby, modifieddate, custom_message from avs_message (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into avs_published_msg_lng_extn (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, languageid, ref_val_group, generated_message, message_documentation, createdby, createddate, modifiedby, modifieddate, custom_message, translated_message)
	select customer_name, project_name, @ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, message_code, languageid, ref_val_group, generated_message, message_documentation, createdby, createddate, modifiedby, modifieddate, custom_message, translated_message from avs_message_lng_extn (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into avs_published_service_validation_dtl (customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, value1, value2, eval_sequence, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, service_name, segment_name, dataitemname, validation_code, value1, value2, eval_sequence, createdby, createddate, modifiedby, modifieddate from avs_service_validation_dtl (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	-- Added By Hemaltha.K for CVS (10/08/2007)

	insert into cvs_published_control_validation (
		customer_name,		project_name,		ecrno,			process_name,
		component_name,		activity_name,		ui_name,		page_name,
		task_name,		control_name,		validation_code,	value1,
		value2,			eval_sequence,		timestamp,		createdby,
		createddate,		modifiedby,		modifieddate)
	select 	customer_name,		project_name,		@ecrno,			process_name,
		component_name,		activity_name,		ui_name,		page_name,
		task_name,		control_name,		validation_code,	value1,
		value2,			eval_sequence,		timestamp,		createdby,
		createddate,		modifiedby,		modifieddate
	from	cvs_control_validation (nolock)
	where customer_name = @customername 
	and  project_name = @projectname 
	and  process_name = @processname 
	and  component_name = @componentname 


	insert into cvs_published_message (
		customer_name,		Project_name, 		ecrno,			process_name,
		component_name,		activity_name,		ui_name,		page_name,
		task_name,		control_name,		validation_code,	message_code,
		generated_message,	custom_message,		timestamp,		createdby,
		createddate,		modifiedby,		modifieddate )
	select	customer_name,		Project_name, 		@ecrno,			process_name,
		component_name,		activity_name,		ui_name,		page_name,
		task_name,		control_name,		validation_code,	message_code,
		generated_message,	custom_message,		timestamp,		createdby,
		createddate,		modifiedby,		modifieddate 
	from	cvs_message (nolock)
	where customer_name = @customername 
	and  project_name = @projectname 
	and  process_name = @processname 
	and  component_name = @componentname 



	insert into cvs_published_message_lng_extn (
		customer_name,		project_name,	ecrno,			process_name,
		component_name,		activity_name,	ui_name,		page_name,
		task_name,		control_name,	validation_code,	message_code,
		languageid,		translated_msg,	generated_message,	timestamp,
		createdby,		createddate,	modifiedby,		modifieddate)
	select	customer_name,		project_name,	@ecrno,			process_name,
		component_name,		activity_name,	ui_name,		page_name,
		task_name,		control_name,	validation_code,	message_code,
		languageid,		translated_msg,	generated_message,	timestamp,
		createdby,		createddate,	modifiedby,		modifieddate
	from	cvs_message_lng_extn (nolock)
	where customer_name = @customername 
	and  project_name = @projectname 
	and  process_name = @processname 
	and  component_name = @componentname 

-- Added By Feroz for Health mointoring (07/09/07)
	insert into  de_published_chm_service_datatitem(customer_name, project_name, ecrno, process_name, component_name, service_name, segment_name, dataitem_name, createdby, createddate, modifiedby, modifieddate)
	select 	customer_name, project_name, @ecrno, process_name, component_name, service_name, segment_name, dataitem_name, createdby, createddate, modifiedby, modifieddate	from de_chm_service_datatitem  (nolock)
	where customer_name = @customername 
	and  project_name = @projectname  
	and  process_name = @processname 
	and  component_name = @componentname 	

--	Code added for the BugId PNR2.0_1790 Starts
	insert into de_published_ext_js_section(customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, Section_Width, Section_Height, Section_Class, RVW_Task, Callout_Task, Direction, Scroll_Behaviour, Scroll_Delay, Fade_Delay, No_Of_Columns, Report_Item_Class, Property_Class, Value_Class, sample_data, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, Section_Width, Section_Height, Section_Class, RVW_Task, Callout_Task, Direction, Scroll_Behaviour, Scroll_Delay, Fade_Delay, No_Of_Columns, Report_Item_Class, Property_Class, Value_Class, sample_data, createdby, createddate, @ctxt_user, getdate() from 	de_ext_js_section (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

	insert into de_published_ext_js_control (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, Extjs_Ctrl_type, Ctrl_height, ctrl_width, Control_Class, RVW_Task, Callout_Task, Type_Delay, Type_Direction, Fade_Delay, Fade_Direction, Loop_Count, sample_data, feature_name, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, Extjs_Ctrl_type, Ctrl_height, ctrl_width, Control_Class, RVW_Task, Callout_Task, Type_Delay, Type_Direction, Fade_Delay, Fade_Direction, Loop_Count, sample_data, feature_name, createdby, createddate, @ctxt_user, getdate() from de_ext_js_control (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	
	insert into de_published_ext_js_section_column (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_sequence, column_bt_synonym, is_key, datatype, grouping, grouping_function, grouping_synonym, rvw_task, callout_task, label_class, control_class, sample_data, createdby, createddate, modifiedby, modifieddate, FieldList, Default_Dragoption, column_type,pivot_sequence,visible_length,image_column)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, section_type, control_bt_synonym, column_sequence, column_bt_synonym, is_key, datatype, grouping, grouping_function, grouping_synonym, rvw_task, callout_task, label_class, control_class, sample_data, createdby, createddate, @ctxt_user, getdate(), FieldList, Default_Dragoption, column_type,pivot_sequence,visible_length,image_column from de_ext_js_section_column (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 

--	Code added for the BugId PNR2.0_1790 Ends

	-- added By feroz for listedit start

	insert into de_published_listedit_column (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym, listedit_column_seqno, listedit_controlid, listedit_viewname, column_prefix, createdby, createddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, listedit_synonym, listedit_column_synonym, listedit_column_seqno, listedit_controlid, listedit_viewname, column_prefix, createdby, createddate from de_listedit_column (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
-- Modified By feroz for bug id :PNR2.0_23463 	
	insert into de_published_listedit_control_map (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym, control_id, view_name, createdby, createddate, listedit_controlid, listedit_viewname) 
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, mapped_bt_synonym, listedit_synonym, control_id, view_name, createdby, createddate, listedit_controlid, listedit_viewname from de_listedit_control_map (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
-- Modified By feroz for bug id :PNR2.0_23463 
	-- Modification for the defect id: TECH-16126
	insert into de_published_resolvelist_data_map (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, listedit_synonym, mapped_bt_synonym, listedit_column_synonym, data_mapped_synonym, primary_search_column, list_index_search, control_id, view_name, visible, createdby, createddate,mapped_bt_syn_page,map_listdata)  --Modified for  PNR2.0_26701
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, listedit_synonym, mapped_bt_synonym, listedit_column_synonym, data_mapped_synonym, primary_search_column, list_index_search, control_id, view_name, visible, createdby, createddate ,mapped_bt_syn_page, map_listdata from de_resolvelist_data_map (nolock)   --Modified for  PNR2.0_26701
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- Modification for the defect id: TECH-16126
	--code added by kiruthika for bugid:PLF2.0_03710
	insert into de_published_custom_listedit (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym, list_search_id, list_search_context, list_index_search, list_recurrent_search, list_search_delay, list_select_column, list_result_column, list_width, createdby, createddate, modifiedby, modifieddate) 
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, listedit_synonym, list_search_id,list_search_context, list_index_search, list_recurrent_search, list_search_delay, list_select_column, list_result_column, list_width, @ctxt_user, getdate(), @ctxt_user, getdate() from de_custom_listedit (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	--code added by kiruthika for bugid:PLF2.0_03710

---- Insert into de_published_ui_comobolink


insert into de_published_ui_combolink
(customer_name	,project_name		,process_name	,component_name, activity_name	,ui_name,
Combo_control_bt_synonym	,link_control_bt_synonym	,link_control_caption	,Display_seqno,
separatelink_req	,map	,createdby	,createddate	,modifiedby	,modifieddate,ecrno	)
select
customer_name	,project_name	,process_name	,component_name	,
activity_name	,ui_name	,Combo_control_bt_synonym	,link_control_bt_synonym	,link_control_caption	,Display_seqno,
separatelink_req	,map	,@ctxt_user	,GETDATE()	,@ctxt_user	,GETDATE(),@ecrno	
from de_ui_combolink(nolock)
where  customer_name  = @customername
and   project_name  = @projectname
and   process_name  = @processname
and   component_name  = @componentname
---insert into de_published_user_section
insert into de_published_user_section
(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,ecrno,createdby,createddate,modifiedby,modifieddate)
select
customer_name	,project_name	,process_name	,component_name	,activity_name	,ui_name	,page_bt_synonym,section_bt_synonym,
type,include_text,include_value,languageid,@ecrno,@ctxt_user,GETDATE(),@ctxt_user,GETDATE()	
from de_user_section(nolock)
where  customer_name  = @customername
and   project_name  = @projectname
and   process_name  = @processname
and   component_name  = @componentname
	insert into de_published_date_highlight_control_map (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, listedit_synonym, controlid, viewname,listedit_controlid, listedit_viewname, createdby, createddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, listedit_synonym, controlid, viewname,listedit_controlid, listedit_viewname, createdby, createddate from de_date_highlight_control_map (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_dynamic_sec_control_map  (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym, controlid, viewname,  createdby, createddate)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_bt_synonym, control_bt_synonym,  controlid, viewname, createdby, createddate from de_dynamic_sec_control_map (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- added By feroz for listedit ends
-- specify template starts--
	insert into de_published_ui_Temp_placeholders (activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,createdby,createddate,modifiedby,modifieddate,ecrno,placeholder,associatedColumn,associatedevent)
	select activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,@ctxt_user,getdate(),@ctxt_user,getdate(),@ecrno,placeholder,associatedColumn,associatedevent
	from de_ui_Temp_placeholders (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_ui_template_controlmap (activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,createdby,createddate,modifiedby,modifieddate,ecrno)
	select activity_name,customer_name,project_name,process_name,component_name,ui_name,page_bt_synonym,Control_bt_synonym,section_bt_synonym,templateid,control_id,view_name,@ctxt_user,getdate(),@ctxt_user,getdate(),@ecrno
	from de_ui_template_controlmap (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname


-- specify template ends
--- Maintain Calloout changes starts 11537---
	
	insert into de_published_task_callout_map (customer_name,project_name,process_name,component_name,activity_name,ui_name,action_name,calloutname,Calloutmode,page_name,section_name,control_bt_synonym,control_id,View_Name,FlowDirection,map_flag,ecrno,timestamp,createdby,createddate,modifiedby,modifieddate)
	select  customer_name,project_name,process_name,component_name,activity_name,ui_name,action_name,calloutname,Calloutmode,page_name,section_name,control_bt_synonym,control_id,View_Name,FlowDirection,map_flag,@ecrno,timestamp,createdby,getdate(),modifiedby,getdate()
	from de_task_callout_map (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_fw_des_publish_task_callout_dataitem (CustomerName,ProjectName,EcrNo,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,SegmentName,DataItemName,FlowAttribute,ControlID,ViewName,timestamp,createdby,createddate,modifiedby,modifieddate)
	select  distinct CustomerName,ProjectName,@ecrno,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,SegmentName,DataItemName,FlowAttribute,ControlID,ViewName,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_fw_des_task_callout_dataitem (nolock) 
	where CustomerName = @customername and  ProjectName = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_fw_des_publish_task_callout_segement (CustomerName,ProjectName,EcrNo,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,SegmentName,InstanceFlag,SegmentSequence,SegmentFlowAttribute,timestamp,createdby,createddate,modifiedby,modifieddate)
	select distinct CustomerName,ProjectName,@ecrno,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,SegmentName,InstanceFlag,SegmentSequence,SegmentFlowAttribute,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_fw_des_task_callout_segement (nolock) 
	where CustomerName = @customername and  ProjectName = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_fw_des_publish_task_callout (CustomerName,ProjectName,EcrNo,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,timestamp,createdby,createddate,modifiedby,modifieddate)
	select distinct CustomerName,ProjectName,@ecrno,Process_Name,Component_Name,Activity_Name,UI_Name,Task_Name,CalloutName,CalloutMode,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_fw_des_task_callout (nolock) 
	where CustomerName = @customername and  ProjectName = @projectname and  process_name = @processname and  component_name = @componentname
	--- Maintain Calloout changes Ends 11537---

	-- added by Feroz for ui Toolbar - starts
	insert into de_published_ui_toolbar_group (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_name, group_descr, createddate, createdby, 
	modifieddate, modifiedby, Orientation)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, group_name, group_descr, createddate, createdby, getdate(), @ctxt_user,
	Orientation from  de_ui_toolbar_group (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_ui_toolbar (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_name, group_task_name, task_seqno, class_name, display_text, group_task_desc, createddate, createdby, modifieddate, modifiedby,group_node_task)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, group_name, group_task_name, task_seqno, class_name, display_text, group_task_desc, createddate, createdby, getdate(), @ctxt_user	,group_node_task  from  de_ui_toolbar (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_ui_displaytext_lang_extn  (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, group_task_name, display_text, lang_id, createddate, createdby,group_name)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, group_task_name, display_text, lang_id, createddate, createdby ,group_name from de_ui_displaytext_lang_extn (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_ui_toolbar_mapping (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name, display_seqno, class_name, display_text, caption_req, control_req, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, toolbar_id, group_task_name, display_seqno, class_name, display_text, caption_req, control_req, createddate, createdby, getdate(), @ctxt_user from de_ui_toolbar_mapping (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	-- added by Feroz for ui Toolbar - Ends

	-- added by Jeya Latha K for Contextual Links and Control Extensions Starts

	insert into de_published_contextual_links (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name, contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name, task_name, createdby, createddate, modifiedby, modifieddate, task_type)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, contextual_link_name, contextual_link_seq, task_description, extend_as, source_from, tolltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name, task_name, createdby, createddate, @ctxt_user, getdate(), task_type from  de_contextual_links (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_control_extensions (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name, controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name, task_name, createdby, createddate, modifiedby, modifieddate, task_type, image_path)
	select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, section_name, control_bt_synonym, controlextension_name, controlextension_seq, task_description, extend_as, source_from, tooltiptext, linked_componentname, linked_activityname, linked_uiname, subscription_name, task_name, createdby, createddate, @ctxt_user, getdate(), task_type, image_path from  de_control_extensions (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- added by Jeya Latha K for Contextual Links and Control Extensions End

-- Code modification for  PNR2.0_30127 starts
insert into de_published_ui_taskpane (customer_name, project_name, ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_type, configuration_sp, data_sp, callout_req, timestamp, createdby, createddate,  modifiedby, modifieddate )     
select customer_name, project_name, @ecrno, process_name, component_name, activity_name, ui_name, page_bt_synonym, task_name, task_descr, task_type, configuration_sp, data_sp, callout_req, timestamp, createdby, createddate, modifiedby, modifieddate 
from de_ui_taskpane (nolock)   
where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname    
-- Code modification for  PNR2.0_30127 ends

	
	-- Code Added for the BugID : PNR2.0_33318 Starts  --code added for bugid: PLF2.0_07676 starts
	insert into de_published_schema_index (customer_name, project_name, ecrno, process_name, component_name, db_name, Index_name, Index_descr, Index_type, Table_name,timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, Index_name, Index_descr, Index_type, Table_name,timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_index (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_index_columns (customer_name, project_name, ecrno, process_name, component_name, db_name, Index_name, Table_name,Column_name, timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, Index_name, Table_name,Column_name, timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_index_columns (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_sp (customer_name, project_name, ecrno, process_name, component_name, db_name, sp_name, sp_descr, timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, sp_name, sp_descr, timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_sp (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_sp_param (customer_name, project_name, ecrno, process_name, component_name, db_name, sp_name, parameter_seq, parameter_name, parameter_descr, parameter_udd, flow_direction, timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, sp_name, parameter_seq, parameter_name, parameter_descr, parameter_udd, flow_direction, timestamp,  getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_sp_param (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_dependentobj (customer_name, project_name, ecrno, process_name, component_name, db_name, sp_name, dep_object_type, dep_object_name, timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, sp_name, dep_object_type, dep_object_name, timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_dependentobj (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_function (customer_name, project_name, ecrno, process_name, component_name, db_name, function_name, function_descr, timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, function_name, function_descr, timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_function (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_schema_function_param (customer_name, project_name, ecrno, process_name, component_name, db_name, function_name, parameter_seq,parameter_name, parameter_descr,parameter_udd, flow_direction,  timestamp, createddate, createdby, modifieddate, modifiedby)
	select customer_name, project_name, @ecrno, process_name, component_name, db_name, function_name, parameter_seq,parameter_name, parameter_descr,parameter_udd, flow_direction,  timestamp, getdate(), @ctxt_user, getdate(), @ctxt_user from de_schema_function_param (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	--device table insert starts by Kanagavel A
	insert de_published_ui_device_section(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
	select 	customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,attributename,attributevalue,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_device_section(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert de_published_ui_device_control(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
	select 	customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,attributename,attributevalue,@ctxt_user,getdate(),@ctxt_user,getdate(),control_id,view_name
	from de_ui_device_control(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert de_published_ui_device_page(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
	select 	customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,attributename,attributevalue,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_device_page(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert de_published_ui_device_grid(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate,controlid,viewname)
	select 									   customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,attributename,attributevalue,@ctxt_user,getdate(),@ctxt_user,getdate(),control_id,view_name
	from de_ui_device_grid(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert de_published_ui_device(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,attributename,attributevalue,createdby,createddate,modifiedby,modifieddate)
	select 	customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,attributename,attributevalue,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_device(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	/*
	insert de_published_ui_section_control_map(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_id,view_name,createdby,createddate,modifiedby,modifieddate)
	select 									   customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_id,view_name,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_section_control_map(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	*/
	--device table insert ends by Kanagavel A
	--insertion into placeholder and tooltip tables starts
	insert de_published_ui_tooltip_lng_extn(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,control_id,view_name,languageid,tooltip,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,control_id,view_name,languageid,tooltip,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_tooltip_lng_extn(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
		
	insert de_published_ui_placeholder_lng_extn(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,control_bt_synonym,control_id,view_name,languageid,placeholder,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,control_bt_synonym,control_id,view_name,languageid,placeholder,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_placeholder_lng_extn(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
				
	--insertion into placeholder and tooltip tables ends
	
		------ QlikLink PLF2.0_16291
	insert de_published_ui_control_association_map(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,Control_id,view_name,propertyname,propertycontrol,property_controlid,property_viewname,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,Control_id,view_name,propertyname,propertycontrol,property_controlid,property_viewname,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_control_association_map(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	
	------ QlikLink  
	------ code added for PLF2.0_16291 (Pivot tables )starts
	insert de_published_pivot_configure(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,configpan_pos,rowgrandtot_pos,rowsubtot_pos,colgrandtot_pos,colsubtot_pos,rowgrandtot_text,colgrandtot_text,rowsubtot_text,colsubtot_text,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,configpan_pos,rowgrandtot_pos,rowsubtot_pos,colgrandtot_pos,colsubtot_pos,rowgrandtot_text,colgrandtot_text,rowsubtot_text,colsubtot_text,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_pivot_configure(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert de_published_pivot_fields(customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,column_bt_synonym,rowlabel,columnlabel,fieldValue,rowlabelseq,columnlabelseq,valueseq,ValueFunction,rowlabelsorting,columnlabelsorting,ecrno,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,column_bt_synonym,rowlabel,columnlabel,fieldValue,rowlabelseq,columnlabelseq,valueseq,ValueFunction,rowlabelsorting,columnlabelsorting,@ecrno,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_pivot_fields(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert de_published_pivot_lang_extn(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,DisplayField,Languageid,DisplayText,timestamp,createdby,createddate,modifiedby,modifieddate)
	select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_name,Control_bt_synonym,DisplayField,Languageid,DisplayText,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_pivot_lang_extn(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	
	------ code added for PLF2.0_16291 (Pivot tables )Ends 
	----phone and tablet tables start PLF2.0_17570	
	insert into de_published_phone(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation
	from de_phone(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,createdby,createddate,modifiedby,modifieddate,Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,ui_descr,ui_type,ui_format,tab_height,TabStyle,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),Layout,XYCoordinates,ColumnLayWidth,TabHeaderPostion,TabRotation
	from de_tablet(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_phone_page(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),PageClass
	from de_phone_page(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
		
	insert into de_published_tablet_page(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate,PageClass)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,horder,vorder,HeaderPosition,TabRotation,TabTitleStyle,TabIconPosition,PageLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),PageClass
	from de_tablet_page(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_phone_section(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,horder,vorder,parent_section,border_required,title_required,title_alignment,width,height,caption_Format,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,horder,vorder,parent_section,border_required,title_required,title_alignment,width,height,caption_Format,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_phone_section(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet_section(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,horder,vorder,parent_section,border_required,title_required,title_alignment,width,height,caption_Format,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,createdby,createddate,modifiedby,modifieddate)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,section_type,horder,vorder,parent_section,border_required,title_required,title_alignment,width,height,caption_Format,Section_width_Scalemode,Section_height_Scalemode,SectionPrefixClass,Region,TitlePosition,CollapseDir,SectionLayout,XYCoordinates,ColumnLayWidth,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_tablet_section(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
		
	insert into de_published_phone_control(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,horder,vorder,data_column_width,label_column_width,label_column_scalemode,data_column_scalemode,order_seq,control_id,sample_data,view_name,visible_length,LabelClass,ControlClass,freezecount,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Control_class_ext6)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,horder,vorder,data_column_width,label_column_width,label_column_scalemode,data_column_scalemode,order_seq,control_id,sample_data,view_name,visible_length,LabelClass,ControlClass,freezecount,TemplateID,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),TemplateCategory,TemplateSpecific,Control_class_ext6
	from de_phone_control(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet_control(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,horder,vorder,data_column_width,label_column_width,order_seq,control_id,sample_data,view_name,visible_length,LabelClass,ControlClass,freezecount,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,label_column_scalemode,data_column_scalemode,TemplateCategory,TemplateSpecific,Control_class_ext6)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,control_type,horder,vorder,data_column_width,label_column_width,order_seq,control_id,sample_data,view_name,visible_length,LabelClass,ControlClass,freezecount,TemplateID,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),label_column_scalemode,data_column_scalemode,TemplateCategory,TemplateSpecific,Control_class_ext6
	from de_tablet_control(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
			
	insert into de_published_phone_grid(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_no,column_type,control_id,view_name,sample_data,visible_length,ColumnClass,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Column_class_ext6)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_no,column_type,control_id,view_name,sample_data,visible_length,ColumnClass,TemplateID,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),TemplateCategory,TemplateSpecific,Column_class_ext6
	from de_phone_grid(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet_grid(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_no,column_type,control_id,view_name,sample_data,visible_length,ColumnClass,TemplateID,timestamp,createdby,createddate,modifiedby,modifieddate,TemplateCategory,TemplateSpecific,Column_class_ext6)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,control_bt_synonym,column_bt_synonym,column_no,column_type,control_id,view_name,sample_data,visible_length,ColumnClass,TemplateID,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),TemplateCategory,TemplateSpecific,Column_class_ext6
	from de_tablet_grid(nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	----phone and tablet tables ends PLF2.0_17570	
	
	insert into de_published_ui_columngroup(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate,modifiedby,modifieddate,groupseqno, grouplevel, parentgroup, parentgroupseq)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),groupseqno, grouplevel, parentgroup, parentgroupseq
	from de_ui_columngroup (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_phone_columngroup(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate,modifiedby,modifieddate,groupseqno, grouplevel, parentgroup, parentgroupseq)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),groupseqno, grouplevel, parentgroup, parentgroupseq
	from de_phone_columngroup (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet_columngroup(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,createdby,createddate,modifiedby,modifieddate,groupseqno, grouplevel, parentgroup, parentgroupseq)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,Group_caption,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate(),groupseqno, grouplevel, parentgroup, parentgroupseq
	from de_tablet_columngroup (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_ui_column_group_mapping(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,modifieddate)	
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_column_group_mapping (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_phone_column_group_mapping(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,modifieddate)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_column_group_mapping (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_tablet_column_group_mapping(customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,createdby,createddate,modifiedby,modifieddate)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,Page_bt_synonym,section_bt_synonym,grid_control_bt_synonym,Group_name,column_bt_synonym,SequenceNo,mapped_entity,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_ui_column_group_mapping (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_calendar_configure(Customer_name,Project_name,ecrno,Process_name,Component_name,Activity_name,ui_name,page_name,section_name,monthview_cal,weekview_cal,editable,detailspane,listview_req,DefaultTemplate,eventstyle,month_nav_req,week_nav_req,tap_req,doubletap_req,drag_req,
	month_nav_event,week_nav_event,tapevent,doubletap_event,dragevent,timestamp,createdby,createddate,modifiedby,modifieddate)
	Select Customer_name,Project_name,@ecrno,Process_name,Component_name,Activity_name,ui_name,page_name,section_name,monthview_cal,weekview_cal,editable,detailspane,listview_req,DefaultTemplate,eventstyle,month_nav_req,week_nav_req,tap_req,doubletap_req,drag_req,month_nav_event,week_nav_event,
	tapevent,doubletap_event,dragevent,timestamp,@ctxt_user,getdate(),@ctxt_user,getdate()
	from de_calendar_configure (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	
	insert into de_published_sync_view (customer_name,project_name,ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,
	legrid_control_bt_syonym,legrid_control_id,legrid_view_name,map_le_synonym,map_le_column_synonym,map_le_controlid,map_le_viewname,map_legrid_view_name,
	createdby,created_date,modifiedby,modifieddate,legrid_column_bt_synonym,map_legrid_column_bt_synonym)
	Select customer_name,project_name,@ecrno,process_name,component_name,activity_name,ui_name,page_bt_synonym,section_bt_synonym,legrid_control_bt_syonym,
	legrid_control_id,legrid_view_name,map_le_synonym,map_le_column_synonym,map_le_controlid,map_le_viewname,map_legrid_view_name,
	@ctxt_user,getdate(),@ctxt_user,getdate(),legrid_column_bt_synonym,map_legrid_column_bt_synonym
	from de_sync_view (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
-- Code Added for the BugID : PNR2.0_33318 Ends --code added for bugid: PLF2.0_07676 ends
	
	insert into de_published_nativeapp_mapping (customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, 
	section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym, ecrno, control_id, view_name, GridControlID, GridViewName, control_hiddenview, 
	timestamp, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, process_name, component_name, activity_name, ui_name, page_bt_synonym, 
	section_bt_synonym, control_Hidden_bt_synonym, MappedGridColumnSynonym, @ecrno, control_id, view_name, GridControlID, GridViewName, control_hiddenview, 
	timestamp, @ctxt_user, getdate(), @ctxt_user, getdate()
	from de_nativeapp_mapping (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	-- Added for Message Based Actions TECH-12776 Starts
	insert into de_fw_des_publish_message_task_map (customer_name, project_name, process_name, component_name, activity_name, ui_name, ecrno, taskname, 
	MessageID, MessageDesc, maptask_name, maptask_Descr, maptask_type, HlpAssociatedcontrol, timestamp, createdby, createddate, modifiedby, modifieddate)
	select customer_name, project_name, process_name, component_name, activity_name, ui_name, @ecrno, taskname, 
	MessageID, MessageDesc, maptask_name, maptask_Descr, maptask_type, HlpAssociatedcontrol, timestamp, createdby, createddate, modifiedby, modifieddate
	from de_fw_des_message_task_map (nolock) where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- Added for Message Based Actions TECH-12776 Ends
		
	-- Code added for TECH-16126 Starts
	insert into de_published_offtask_query (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	
	query_name,	query_type,	query_instance,	query_text,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select  customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	query_name,	query_type,	query_instance,	
	query_text,	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_query (nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_offtask_queryparam (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,
	ui_name,	query_name,	parameter_name,	parameter_seq,	flow_direction,	mapped_control_name,	timestamp,	createdby,	createddate,
	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	query_name,	parameter_name,	
	parameter_seq,	flow_direction,	mapped_control_name,	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_queryparam (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_offtask_tskqrymap (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,
	task_name,	query_name,	query_seq,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select  customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	task_name,	query_name,	query_seq,
	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_tskqrymap (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_offtask_message (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,
	message_id,	message_desc,	severity,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	message_id,	message_desc,
	severity,	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_message (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_offtask_message_lng_extn (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,
	language_id,	message_id,	message_desc,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	language_id,	message_id,	
	message_desc,	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_message_lng_extn (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_offtask_message_ph (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,
	message_id,	placeholder_seq,	placeholder_name,	mapped_control_name,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	message_id,		placeholder_seq,
	placeholder_name,	mapped_control_name,	timestamp,	createdby,	getdate(),	modifiedby,	getdate()
	from de_offtask_message_ph (nolock) 
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	-- Code added for TECH-16126 Ends
	-- Code ends

	----13852 Added on 16dec2019 Starts

	insert into	de_published_mdcf_template(customer_name,	project_name,	ecrno,	process_name,	component_name,	TemplateID,
    TemplateDescription,	TimeStamp,	CreatedBy,	CreatedDate,	ModifiedBy,	ModifiedDate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	TemplateID,
    TemplateDescription,	TimeStamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from de_mdcf_template	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into	de_published_mdcf_template_ilbo(customer_name,	project_name,	ecrno,	TemplateID,	process_name,	component_name,	activity_name,
    ui_name,	TimeStamp,	CreatedBy,	CreatedDate,	ModifiedBy,	ModifiedDate)
	Select	customer_name,	project_name,	@ecrno,	TemplateID,	process_name,	component_name,	activity_name,
    ui_name,	TimeStamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from	de_mdcf_template_ilbo	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_mdcf_template_task(customer_name,project_name,	ecrno,	TemplateID,	process_name,	component_name,activity_name,
    ui_name,	Task_Name,	TimeStamp,	CreatedBy,	CreatedDate,	ModifiedBy,	ModifiedDate)
	Select customer_name,project_name,	@ecrno,	TemplateID,	process_name,	component_name,activity_name,
    ui_name,	Task_Name,	TimeStamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from	de_mdcf_template_task	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_mdcf_template_taskseq(customer_name,	project_name,	ecrno,	TemplateID,	process_name,	component_name,	activity_name,
    ui_name,	Task_name,	Task_Description,	Task_sequence,	task_type, TimeStamp,	CreatedBy,	CreatedDate,	ModifiedBy,	ModifiedDate)
	Select	customer_name,	project_name,	@ecrno,	TemplateID,	process_name,	component_name,	activity_name,
	ui_name,	Task_name,	Task_Description,	Task_sequence,	task_type, TimeStamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from	de_mdcf_template_taskseq	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert into de_published_mdcf_template_taskcontrol_map(customer_name,	project_name,	ecrno,	TemplateID,	process_name,component_name,activity_name,
    ui_name,	Task_name,	BT_synonym_name,	Control_ID,	View_name,	IsMandatory,	TableName,	ColumnName,	TimeStamp,	CreatedBy,	CreatedDate,	
    ModifiedBy,	ModifiedDate)
	Select customer_name,	project_name,	@ecrno,	TemplateID,	process_name,component_name,activity_name,
    ui_name,	Task_name,	BT_synonym_name,	Control_ID,	View_name,	IsMandatory,	TableName,	ColumnName,	TimeStamp,	@ctxt_user,	getdate(),
	@ctxt_user,		getdate()
	from de_mdcf_template_taskcontrol_map	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname


	insert into de_published_mdcf_glossary_lng_extn(customer_name,	project_name,	ecrno,	TemplateID,	process_name,	component_name,
	bt_synonym_name,	languageid,	bt_synonym_caption,	GuidanceText,	TimeStamp,	CreatedBy,	CreatedDate,	ModifiedBy,	ModifiedDate)
	Select	customer_name	,project_name,	@ecrno,	TemplateID,	process_name,	component_name,
    bt_synonym_name,	languageid,	bt_synonym_caption,	GuidanceText,	TimeStamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from de_mdcf_glossary_lng_extn with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
	 
	----13852 Added on 16dec2019 Ends

	----13852 Added on 02jan2020 Starts
	insert into de_published_up_defaulting_dtl(customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym,
    section_bt_synonym,	task_name,	control_bt_synonym,	parameter_name,	flow_direction,	control_id,	view_name,	createdby,	createddate,	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno, process_name,	component_name,	activity_name,	ui_name,	page_bt_synonym,	section_bt_synonym,	task_name,	control_bt_synonym,
    parameter_name,	flow_direction,	control_id,	view_name,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from de_up_defaulting_dtl	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	----13852 Added on 02jan2020 Ends

    ----13852 Added on 20feb2020 Starts

	insert into de_published_ui_section_refinement (customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,	
	Formfactor,	page_bt_synonym,	section_bt_synonym,	visible_flag,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select	customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,
    page_bt_synonym,	section_bt_synonym,	visible_flag,	timestamp,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from	de_ui_section_refinement	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname

	insert	into	de_published_responsive_sec_weightage(customer_name,	project_name,	ecrno,	process_name,	component_name,	activity_name,	ui_name,
    Formfactor,	page_bt_synonym,	parent_section,	section_bt_synonym,	Weightage,	SectionWidth,	timestamp,	createdby,	createddate,	modifiedby,	modifieddate)
	Select customer_name,	project_name,	@ecrno,	process_name,	component_name,	activity_name,	ui_name,	Formfactor,	page_bt_synonym,	parent_section,
    section_bt_synonym,	Weightage,	SectionWidth,	timestamp,	@ctxt_user,		getdate(),	@ctxt_user,	getdate()
	from de_responsive_sec_weightage	with(nolock)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname
   ----13852 Added on 20feb2020 End

   

   ---Added for the Defect ID TECH-45546 starts
   insert into de_published_els_query_listedit_map(customername,	projectname,	Ecrno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,
   ListControlID,	ListViewname,	QueryID,	SearchIndex,	Pagesize, createdby,	createddate,	Modifedby,	modifieddate)
   Select customername,	projectname,		@ecrno,	processname,	componentname,	activityname,	uiname,	ListControlSynonym,
   ListControlID, ListViewname,	QueryID,	SearchIndex,	Pagesize,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
   from de_els_query_listedit_map with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

   insert into de_published_els_query_listedit_input(customername,	projectname,	Ecrno,	processname, 	componentname,	activityname,	uiname,	ListControlSynonym,	
   ListControlID,	ListViewname,	QueryID,	ParameterName,	MappedSynonym, MappedControlID,	MappedViewName,	createdby,	createddate,	Modifedby,modifieddate)
   Select customername,	projectname,		@ecrno	,processname,	componentname,	activityname,	uiname,	ListControlSynonym,
   ListControlID, ListViewname,	QueryID,	ParameterName,	MappedSynonym,	MappedControlID,	MappedViewName,
   @ctxt_user,	getdate(),	@ctxt_user,	getdate()
   from de_els_query_listedit_input with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

   insert into de_published_els_query_listedit_result(customername,	projectname,	Ecrno,	processname, 	componentname,	activityname,	uiname,	
   ListControlSynonym,ListControlID,	ListViewname,	QueryID,	ResultColumnName,	MappedSynonym, MappedControlID,	MappedViewName,	
   ParameterCaption,	Width,	IsVisible,	createdby,	createddate,	Modifedby,	modifieddate,seqno)
   Select customername,		projectname,	@ecrno,	processname,	componentname,	activityname,	uiname,	ListControlSynonym,
   ListControlID, ListViewname,	QueryID,	ResultColumnName,	MappedSynonym,	MappedControlID,	MappedViewName,		ParameterCaption,Width,
   IsVisible,	 @ctxt_user,	getdate(),	@ctxt_user,	getdate(),seqno
   from de_els_query_listedit_result with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

   insert  into de_published_els_query_ps_map(CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	Createdby,	Createddate,	Modifedby,	Modifieddate)
   Select CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	 @ctxt_user,	getdate(),	@ctxt_user,	getdate()
   from de_els_query_ps_map with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

   insert into de_published_els_query_ps_input(CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	ParameterName,	SegmentName,	DataItemName,	Createdby,	Createddate,	Modifedby,	Modifieddate)
   Select CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	ParameterName,	SegmentName,	DataItemName,	@ctxt_user,	getdate(),	@ctxt_user,		getdate()
   from de_els_query_ps_input with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname


   insert into de_published_els_query_ps_result(CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	ResultColumn,	SegmentName,	DataItemName,	Createdby,	Createddate,	Modifedby,	Modifieddate)
   Select CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ServiceName,	ProcessSectionName,
   ProcessSectionSeq,	QueryID,	ResultColumn,	SegmentName,	DataItemName,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
   from de_els_query_ps_result with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

	---Added for the Defect ID TECH-45546 ends

   ----Added for the Defect ID TECH-45828 starts
	insert into de_published_upe_control (CustomerName,	ProjectName,	ECRNumber,	ProcessName,		ComponentName,	ActivityName,	UIName,
   PageName,	SectionName,	ControlID,	ViewName,	BTSynonymName,	IsSetFocus,	IsDependentCombo,	SetFocusEvent,	MoreEvent,	AppTableName,
   CreatedBy,	CreatedDate,	ModifedBy,	ModifiedDate,	controltype)
   select  CustomerName,	ProjectName,	@ecrno,		ProcessName,	ComponentName,	ActivityName,	UIName,	PageName,	SectionName,	
   ControlID,	ViewName,	BTSynonymName,	IsSetFocus,	IsDependentCombo,	SetFocusEvent,	MoreEvent,	AppTableName,
   @ctxt_user,	getdate(),	@ctxt_user,	getdate() ,controltype
   from  de_upe_control  with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

   insert into de_published_upe_control_parameters(	CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ActivityName,
   UIName,	PageName,	SectionName,	ControlID,	ViewName,	ParameterName,	ParameterType,	BTSynonymName,	ParameterSequence,	MappedControlID,
   MappedViewName,	MappedBTSynonym,	AppColumnName,	CreatedBy,	CreatedDate,	ModifedBy,	ModifiedDate)
   select 	CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ActivityName,UIName,	PageName,	SectionName,
   ControlID,	ViewName,	ParameterName,	ParameterType,	BTSynonymName,	ParameterSequence,	MappedControlID,MappedViewName,	MappedBTSynonym,
   AppColumnName,	@ctxt_user,	getdate(),	@ctxt_user,	getdate()
   from  de_upe_control_parameters   with(nolock)
   where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname


  --- Added for the Defect ID TECH-45828 ends

  -- Code Added for the Defect ID: TECH-47978 Starts
    insert into de_published_report_task_map(CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ActivityName,
    UIName,			PageName,		TaskName,	ReportName,		ReportContext,	EMailRequired, CreatedBy,		CreatedDate,	ModifedBy,	ModifiedDate)
	select  CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ActivityName, UIName,	PageName,	TaskName, ReportName,
	ReportContext,	EMailRequired, @ctxt_user,	getdate(),	@ctxt_user,	getdate()
	from  de_report_task_map  with(nolock)
    where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

	insert into de_published_report_task_map_param(CustomerName,	ProjectName,	ECRNumber,	ProcessName,	ComponentName,	ActivityName,
	UIName,	PageName,	TaskName,	ReportName,	ParameterSequence,	ParameterName,	MappedControlID,	MappedViewName,		MappedBTSynonym,
	MappedPageName,	CreatedBy,	CreatedDate,	ModifedBy,	ModifiedDate)
	select CustomerName,	ProjectName,	@ecrno,	ProcessName,	ComponentName,	ActivityName,
	UIName,	PageName,	TaskName,	ReportName,	ParameterSequence,	ParameterName,	MappedControlID,	MappedViewName,		MappedBTSynonym,
	MappedPageName,	@ctxt_user,		getdate(),		@ctxt_user,		getdate()
	from  de_report_task_map_param  with(nolock)
    where customername = @customername and  projectname = @projectname and  processname = @processname and  componentname = @componentname

-- Code Added for the Defect ID: TECH-47978 Ends

----Code added for TECH-60451 Starts
  INSERT INTO de_published_ui_grid_Extension 
					(Customer_Name,			Project_Name,			EcrNo,			Process_Name,	
					Component_Name,			Activity_Name,			UI_Name,	    Page_BT_Synonym,	
					Section_BT_Synonym,		Control_ID,				View_Name,		ParameterName,	
					ParameterSequence,		MappedBTSynonym,		MappedField,	
					CreatedBy,				CreatedDate,			ModifiedBy,		ModifiedDate)

  SELECT			Customer_Name,			Project_Name,			@ecrno,			Process_Name,	
					Component_Name,			Activity_Name,			UI_Name,	    Page_BT_Synonym,	
					Section_BT_Synonym,		Control_ID,				View_Name,		ParameterName,	
					ParameterSequence,		MappedBTSynonym,		MappedField,	
					@ctxt_user,				GETDATE(),				@ctxt_user,		GETDATE()
  FROM de_ui_grid_extension WITH(NOLOCK)
  WHERE customer_name = @customername AND  project_name = @projectname AND  process_name = @processname AND  component_name = @componentname

	----Code added for TECH-60451 Ends

	---Code added for TECH-61144 Starts
	
	INSERT INTO de_published_subtask
				( CustomerName,		ProjectName,	DocNo,			ProcessName,
				  ComponentName,	ActivityName,	UIName,			
				  SubTaskName,		SubTaskDesc,	SubTaskType,	
				  TimeStamp,
				  CreatedBy,		CreatedDate,	ModifiedBy,		ModifiedDate )
	SELECT		  
				CustomerName,		ProjectName,	@ecrno,			ProcessName,
				ComponentName,		ActivityName,	UIName,			
				SubTaskName,		SubTaskDesc,	SubTaskType,				
				TimeStamp,
				@ctxt_user,			GETDATE(),		@ctxt_user,		GETDATE()
				
	FROM  de_subtask WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_task_api_mapping
	          ( CustomerName,		ProjectName,		DocNo,			ProcessName,
			    ComponentName,		ActivityName,		UIName,			TaskName,
				ApiExecSequence,	ApiSpecID,			ApiSpecName,	ApiVersion,
				ApiPath,			ApiOperationVerb,	ApiOperationID,	ModeFlag,
				TimeStamp,			Thirdparty,
				CreatedBy,			CreatedDate,		ModifiedBy,		ModifiedDate,
				SubtaskName,	    SubTaskDescription)

	SELECT DISTINCT
			CustomerName,		ProjectName,			@ecrno,			ProcessName,
			ComponentName,		ActivityName,			UIName,			TaskName,
			ApiExecSequence,	ApiSpecID,				ApiSpecName,	ApiVersion,
			ApiPath,			ApiOperationVerb,		ApiOperationID,	ModeFlag,
			TimeStamp,			Thirdparty,
			@ctxt_user,		    GETDATE(),				@ctxt_user,		GETDATE(),
			SubtaskName,	    SubTaskDescription
   FROM   de_task_api_mapping WITH (NOLOCK)
   WHERE  CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname
	
	INSERT INTO de_published_task_api_parameter_map
				(CustomerName,		ProjectName,		DocNo,				ProcessName,	ComponentName,	ActivityName,	UIName,
				 TaskName,			ApiExecSequence,	ApiSpecID,			ApiSpecName,	ApiVersion,		ApiPath,		ApiOperationVerb,
				 ApiOperationID,	ParameterName,		ParameterLocation,	ParameterType,	Identifier,		DataType,		SchemaMemberLevel,
				 IsPrimitiveType,	IsMandatory,		ConstantValue,		ControlID,		ViewName,		BTSynonymName,	ControlDataType,
				 NodeID,			ParentNodeID,		ModeFlag,			TimeStamp,
				 CreatedBy,			CreatedDate,		ModifiedBy,			ModifiedDate )
	SELECT
				CustomerName,		ProjectName,		@ecrno,				ProcessName,	ComponentName,	ActivityName,	UIName,
			    TaskName,			ApiExecSequence,	ApiSpecID,			ApiSpecName,	ApiVersion,		ApiPath,		ApiOperationVerb,
				ApiOperationID,		ParameterName,		ParameterLocation,	ParameterType,	Identifier	,	DataType,		SchemaMemberLevel,
				IsPrimitiveType,	IsMandatory,		ConstantValue,		ControlID,		ViewName,		BTSynonymName,	ControlDataType,
				NodeID,				ParentNodeID,		ModeFlag,			TimeStamp,
				@ctxt_user,			GETDATE(),			@ctxt_user,			GETDATE()
	FROM	de_task_api_parameter_map WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_task_api_request_map
				(CustomerName,		 ProjectName,		DocNo,				ProcessName,		ComponentName,		ActivityName,		UIName,
			     TaskName,			 ApiExecSequence,	ApiSpecID,			ApiSpecName,		ApiVersion,			ApiPath,			ApiOperationVerb,
				 ApiOperationID,	 MediaType,			ParentSchemaName,	SchemaName,			FlattenedSchemaName,Identifier,			DataType,			
				 SchemaType,		 SchemaCategory,	SchemaMemberLevel,	IsPrimitiveType,	IsMandatory,		ConstantValue,		ControlID,			
				 ViewName,		     BTSynonymName,		ControlDataType,	ProcessingType,		NodeID,				ParentNodeID,		ModeFlag,			
				 TimeStamp,
				 CreatedBy,			CreatedDate	,		ModifiedBy,			ModifiedDate )

	SELECT		CustomerName,		ProjectName,		@ecrno,				ProcessName,		ComponentName,		ActivityName,		UIName,
				TaskName,			ApiExecSequence,	ApiSpecID,			ApiSpecName,		ApiVersion,			ApiPath,			ApiOperationVerb,
				ApiOperationID,		MediaType,			ParentSchemaName,	SchemaName,			FlattenedSchemaName,Identifier,			DataType,
				SchemaType,			SchemaCategory,		SchemaMemberLevel,	IsPrimitiveType,	IsMandatory,		ConstantValue,		ControlID,
				ViewName,			BTSynonymName,		ControlDataType,	ProcessingType,		NodeID,				ParentNodeID,		ModeFlag,
				TimeStamp,
				@ctxt_user,			GETDATE(),			@ctxt_user,			GETDATE()
	FROM de_task_api_request_map  WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_task_api_response_map
			(    CustomerName,		ProjectName,		DocNo,			ProcessName,		ComponentName,		ActivityName,		UIName,
				 TaskName,			ApiExecSequence,	ControlID,		ViewName,			BTSynonymName,		ControlDataType,	ApiSpecID,
			     ApiSpecName,		ApiVersion,			ApiPath,		ApiOperationVerb,	ApiOperationID,		MediaType,			ParentSchemaName,
				 SchemaName,		FlattenedSchemaName,Identifier,		DataType,			SchemaType,			SchemaCategory,		SchemaMemberLevel,
				 IsPrimitiveType,	IsMandatory,		ConstantValue,	NodeID,				ParentNodeID,		ModeFlag,			TimeStamp,
				 CreatedBy,			CreatedDate,		ModifiedBy,		ModifiedDate)
	SELECT 
				CustomerName,		ProjectName,		@ecrno,			ProcessName,		ComponentName,		ActivityName,		UIName,
				TaskName,			ApiExecSequence,	ControlID,		ViewName,			BTSynonymName,		ControlDataType,	ApiSpecID,
				ApiSpecName,		ApiVersion,			ApiPath,		ApiOperationVerb,	ApiOperationID,		MediaType,			ParentSchemaName,
				SchemaName,			FlattenedSchemaName,Identifier,		DataType,			SchemaType,			SchemaCategory,		SchemaMemberLevel,
				IsPrimitiveType,	IsMandatory,		ConstantValue,	NodeID,				ParentNodeID,		ModeFlag,			TimeStamp,
				@ctxt_user,			GETDATE(),			@ctxt_user,		GETDATE()
	FROM de_task_api_response_map WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_task_api_subtask
			  ( CustomerName,	ProjectName,	DocNo,			ProcessName,	ComponentName,		ActivityName,		UIName,
				TaskName,		TaskType,		SubTaskName,	SubTaskType,	SubTaskSequence,	ModeFlag,			TimeStamp,
				CreatedBy,		CreatedDate,	ModifiedBy,		ModifiedDate)
	SELECT
				CustomerName,	ProjectName,	@ecrno,			ProcessName,	ComponentName,		ActivityName,		UIName,
				TaskName,		TaskType,		SubTaskName,	SubTaskType,	SubTaskSequence,	ModeFlag,			TimeStamp,
				@ctxt_user,		GETDATE(),		@ctxt_user,		GETDATE()
	FROM de_task_api_subtask WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	---Code added for TECH-61144 Ends
	
	---Code added for TECH-61907 Starts

	INSERT INTO de_published_service_api_parameter_map
				(CustomerName,		ProjectName,		DocNo,				ProcessName,	ComponentName,	ServiceName,			ProcessSection,
				 Sequence,			ApiExecSequence,	ApiSpecID,			ApiSpecName,	ApiVersion,		ApiPath,				ApiOperationVerb,
				 ApiOperationID,	ParameterName,		ParameterLocation,	ParameterType,	Identifier,		DataType,				SchemaMemberLevel,
				 IsPrimitiveType,	IsMandatory,		ConstantValue,		SegmentName,	DataItemName,	DataItemFlowDirection,	ModeFlag,
				 TimeStamp,			CreatedBy,			CreatedDate,		ModifiedBy,		ModifiedDate )
	SELECT
				CustomerName,		ProjectName,		@ecrno,				ProcessName,	ComponentName,	ServiceName,			ProcessSection,
				Sequence,			ApiExecSequence,	ApiSpecID,			ApiSpecName,	ApiVersion,		ApiPath,				ApiOperationVerb,
				ApiOperationID,		ParameterName,		ParameterLocation,	ParameterType,	Identifier,		DataType,				SchemaMemberLevel,
				IsPrimitiveType,	IsMandatory,		ConstantValue,		SegmentName,	DataItemName,	DataItemFlowDirection,	ModeFlag,
				TimeStamp,			@ctxt_user,			GETDATE(),			@ctxt_user,		GETDATE()
	FROM	de_service_api_parameter_map WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname


	INSERT INTO de_published_service_api_request_map
				(CustomerName,		ProjectName,			DocNo,				ProcessName,	 ComponentName,		  ServiceName,			ProcessSection,
				 Sequence,			ApiExecSequence,		ApiSpecID,			ApiSpecName,	 ApiVersion,		  ApiPath,				ApiOperationVerb,
				 ApiOperationID,	MediaType,				ParentSchemaName,	SchemaName,		 FlattenedSchemaName, Identifier,			DataType,
				 SchemaType,		SchemaCategory,			SchemaMemberLevel,	IsPrimitiveType, IsMandatory,		  ConstantValue,		SegmentName,
				 DataItemName,		DataItemFlowDirection,	ControlDataType,	ProcessingType,	 NodeID,			  ParentNodeID,			ModeFlag,
				 TimeStamp,			CreatedBy,				CreatedDate,		ModifiedBy,		 ModifiedDate)
	SELECT
				CustomerName,		ProjectName,			@ecrno,				ProcessName,	 ComponentName,		  ServiceName,			ProcessSection,
				 Sequence,			ApiExecSequence,		ApiSpecID,			ApiSpecName,	 ApiVersion,		  ApiPath,				ApiOperationVerb,
				 ApiOperationID,	MediaType,				ParentSchemaName,	SchemaName,		 FlattenedSchemaName, Identifier,			DataType,
				 SchemaType,		SchemaCategory,			SchemaMemberLevel,	IsPrimitiveType, IsMandatory,		  ConstantValue,		SegmentName,
				 DataItemName,		DataItemFlowDirection,	ControlDataType,	ProcessingType,	 NodeID,			  ParentNodeID,			ModeFlag,
				 TimeStamp,			@ctxt_user,				GETDATE(),			@ctxt_user,		 GETDATE()
	FROM	de_service_api_request_map WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	
	INSERT INTO de_published_service_api_response_map
				(CustomerName,		ProjectName,			DocNo,				ProcessName,	 ComponentName,		    ServiceName,			ProcessSection,
				 Sequence,			ApiExecSequence,		SegmentName,		DataItemName,	 DataItemFlowDirection, ControlDataType,		ApiSpecID,
				 ApiSpecName,		ApiVersion,				ApiPath,			ApiOperationVerb,ApiOperationID,	    MediaType,				ParentSchemaName,
				 SchemaName,		FlattenedSchemaName,	Identifier,			DataType,		 SchemaType,			SchemaCategory,			SchemaMemberLevel,
				 IsPrimitiveType,	IsMandatory,			ConstantValue,		TimeStamp,		 CreatedBy,				CreatedDate,			ModifiedBy,
				 ModifiedDate)
	SELECT
				 CustomerName,		ProjectName,			@ecrno,				ProcessName,	 ComponentName,		    ServiceName,			ProcessSection,
				 Sequence,			ApiExecSequence,		SegmentName,		DataItemName,	 DataItemFlowDirection, ControlDataType,		ApiSpecID,
				 ApiSpecName,		ApiVersion,				ApiPath,			ApiOperationVerb,ApiOperationID,	    MediaType,				ParentSchemaName,
				 SchemaName,		FlattenedSchemaName,	Identifier,			DataType,		 SchemaType,			SchemaCategory,			SchemaMemberLevel,
				 IsPrimitiveType,	IsMandatory,			ConstantValue,		TimeStamp,		 @ctxt_user,			GETDATE(),				@ctxt_user,
				 GETDATE()	
	FROM	de_service_api_response_map WITH(NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	---Code added for TECH-61907 Ends

	--Code added for TECH-63474 Starts

	INSERT INTO de_published_task_gql_mapping
	            ( CustomerName,		ProjectName,		DocNo,		ProcessName,	ComponentName,
				  ActivityName,		UIName,				TaskName,	QuerySequence,	QueryName,
				  QueryType,		[Version],			QueryAlias,	TimeStamp,
				  CreatedBy,		CreatedDate,		ModifiedBy,	ModifiedDate,
				  ISCache,			Cache_TimeToLive,	KeyField,	Childqueryname)	--code added by defect id:TECH-64865

	SELECT		  CustomerName,		ProjectName,		@ecrno,		ProcessName,	ComponentName,
				  ActivityName,		UIName,				TaskName,	QuerySequence,	QueryName,
				  QueryType,		[Version],			QueryAlias,	TimeStamp,
				  @ctxt_user,		GETDATE(),			@ctxt_user, GETDATE(),
				  ISCache,			Cache_TimeToLive,	KeyField,	Childqueryname   --code added by defect id:TECH-64865
	FROM de_task_gql_mapping WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname


	INSERT INTO de_published_task_gql_argument_mapping
				( CustomerName,		ProjectName,	DocNo,			ProcessName,	ComponentName,
				  ActivityName,		UIName,			TaskName,		QuerySequence,	QueryName,
				  Argument,			ControlID,		ViewName,		ArgumentType,	DataType,
				  IsMandatory,		BTSynonym,		DefaultValue,	TimeStamp,		[Version],
				  CreatedBy,		CreatedDate,	ModifiedBy,		ModifiedDate,	FlattenedArgumentName,
				  ChildQueryName,	ProcessingType,	KeyField,
				  Category)	--11May2022 (14469)

	SELECT		  CustomerName,		ProjectName,	@ecrno,			ProcessName,	ComponentName,
				  ActivityName,		UIName,			TaskName,		QuerySequence,	QueryName,
				  Argument,			ControlID,		ViewName,		ArgumentType,	DataType,
				  IsMandatory,		BTSynonym,		DefaultValue,	TimeStamp,		[Version],
				  @ctxt_user,		GETDATE(),		@ctxt_user,      GETDATE(),		FlattenedArgumentName,
				  ChildQueryName,	ProcessingType,	KeyField,
				  Category
	FROM de_task_gql_argument_mapping WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname


	INSERT INTO de_published_task_gql_field_mapping
	           ( CustomerName,	ProjectName,	DocNo,		ProcessName,	ComponentName,
				 ActivityName,	UIName,			TaskName,	QuerySequence,	QueryName,
				 ControlID,		ViewName,		FieldName,	FieldAlias,		BTSynonym,
				 TimeStamp,		[Version],		FldDataType,MapType,	
				 CreatedBy,		CreatedDate,	ModifiedBy,	ModifiedDate,
				 ChildQueryName,KeyField,		CaptionFor)				--Code added for DefectId Tech-68063

	SELECT      CustomerName,	ProjectName,	@ecrno,		ProcessName,	ComponentName,
				ActivityName,	UIName,			TaskName,	QuerySequence,	QueryName,
				ControlID,		ViewName,		FieldName,	FieldAlias,		BTSynonym,
				TimeStamp,		[Version],		FldDataType, MapType,	
				@ctxt_user,		GETDATE(),		@ctxt_user, GETDATE(),
				ChildQueryName,	KeyField,		CaptionFor				----Code added for DefectId Tech-68063
	FROM de_task_gql_field_mapping WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_gql_Schema
	         ( CustomerName,	ProjectName,		DocNo,		ProcessName,	ComponentName,
			   [Version],		IntrospectionJSON,	SDLSchema,	TimeStamp,		IntrospectionJSONDbc,
			   SDLSchemaDbc,	
			   CreatedBy,		CreatedDate,		ModifiedBy,	ModifiedDate )

	SELECT	   CustomerName,	ProjectName,		@ecrno,		ProcessName,	ComponentName,
			    [Version],		IntrospectionJSON,	SDLSchema,	TimeStamp,		IntrospectionJSONDbc,
			   SDLSchemaDbc,	
			   @ctxt_user,		GETDATE(),		   @ctxt_user,   GETDATE() 
	FROM  de_gql_Schema WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

--Code added for TECH-63474 Ends

	--Code added for TECH-69624
	INSERT INTO de_published_ui_control_customaction 
			(	customer_name,			project_name,		ecrno,				process_name,		component_name,
				activity_name,			ui_name,			page_bt_synonym,	section_bt_synonym,	control_bt_synonym,
				ActionControlBTSynonym,	Control_ID,			View_Name,			ActionType,			ActionSequence,
				IconClass,				IconPosition,		Width,				ToolTip,			ActionName,
				ActionDescription,		ActionControlID,	ActionViewName,	
				Createdby,				Createddate,		Modifiedby,			Modifieddate)
	select		customer_name,			project_name,		@ecrno,				process_name,		component_name,
				activity_name,			ui_name,			page_bt_synonym,	section_bt_synonym,	control_bt_synonym,
				ActionControlBTSynonym,	Control_ID,			View_Name,			ActionType,			ActionSequence,
				IconClass,				IconPosition,		Width,				ToolTip,			ActionName,
				ActionDescription,		ActionControlID,	ActionViewName,	
				@ctxt_user,				GETDATE(),			@ctxt_user,			GETDATE() 
	FROM		de_ui_control_customaction WITH(NOLOCK)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	--Code added for TECH-69624

	--Code added for TECH-70687
	INSERT INTO de_published_ui_section_titleaction 
			(	customer_name,			project_name,		ecrno,				process_name,		component_name,
				activity_name,			ui_name,			page_bt_synonym,	section_bt_synonym,	TitleControlBTSynonym,
				ActionType,				ActionSequence,
				IconClass,				IconPosition,		Width,				ToolTip,			ActionName,
				ActionDescription,		ActionControlID,	ActionViewName,	
				Createdby,				Createddate,		Modifiedby,			Modifieddate,		Titleaction)
	select		customer_name,			project_name,		@ecrno,				process_name,		component_name,
				activity_name,			ui_name,			page_bt_synonym,	section_bt_synonym,	TitleControlBTSynonym,
				ActionType,				ActionSequence,
				IconClass,				IconPosition,		Width,				ToolTip,			ActionName,
				ActionDescription,		ActionControlID,	ActionViewName,	
				@ctxt_user,				GETDATE(),			@ctxt_user,			GETDATE(),			Titleaction
	FROM		de_ui_section_titleaction WITH(NOLOCK)
	where customer_name = @customername and  project_name = @projectname and  process_name = @processname and  component_name = @componentname 
	--Code added for TECH-70687


	INSERT INTO fw_published_graphql_arg_fields
	         (	customername,	projectname,	docno,				processname,	componentname,
				importversion,	[name],			queryname,			parentkey,		[key],
				category,		typename,		typekind,			oftypename,		oftypekind,
				defaultvalue,	typerequired,	oftyperequired,		IsMandatory,	
				createdby,		createddate,	modifiedby,			modifieddate)

	SELECT	   CustomerName,	ProjectName,	@ecrno,				ProcessName,	ComponentName,
			   importversion,	[name],			queryname,			parentkey,		[key],
			   category,		typename,		typekind,			oftypename,		oftypekind,
			   defaultvalue,	typerequired,	oftyperequired,		IsMandatory,
			   @ctxt_user,		GETDATE(),		@ctxt_user,			GETDATE()
	FROM  fw_graphql_arg_fields WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname



 	--Added by 11536 for the case ID TECH-66583 control Type and task type property History

	INSERT INTO de_published_comp_ctrl_type_mst
			(	customer_name,				project_name,				ecrno,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				createdby,					createddate,				modifiedby,				modifieddate	)
		SELECT DISTINCT
				customer_name,				project_name,				@ecrno,					process_name,
				component_name,				ctrl_type_name,				ctrl_type_descr,		base_ctrl_type,
				mandatory_flag,				visisble_flag,				editable_flag,			caption_req,
				select_flag,				zoom_req,					insert_req,				delete_req,
				help_req,					event_handling_req,			ellipses_req,			comp_ctrl_type_sysid,
				caption_alignment,			caption_position,			caption_wrap,			visisble_rows,
				ctrl_type_doc,				ctrl_position,				label_class,			ctrl_class,
				password_char,				tskimg_class,				hlpimg_class,			disponlycmb_req,
				html_txt_area,				report_req,					Auto_tab_stop,			Spin_required,
				Spin_up_image,				Spin_down_image,			InPlace_Calendar,		EditMask,
				NoofLinesPerRow,			RowHeight,					Vscrollbar_Req,			Is_Extjs_Control,
				Extjs_Ctrl_type,			gridlite_req,				bulletlink_req,			buttoncombo_req,
				associatedlist_req,			onfocustask_req,			listrefilltask_req,		attach_document,
				image_upload,				inplace_image,				listedit_noofcolumns,	image_row_height,
				relative_url_path,			relative_document_path,		relative_image_path,	save_doc_content_to_db,
				save_image_content_to_db,	dataascaption,				image_icon,				Date_highlight,
				ezee_report,				Lite_Attach_Document,		Browse_Button_Enable,	Delete_Button_Enable,
				image_row_width,			image_preview_height,		image_preview_width,	image_preview_req,
				Lite_Attach_Image,			timezone,					autoexpand,				Disp_Only_Apply_Len,
				editcombo_req,				Label_Link,					captiontype,			controlstyle,
				IsListBox,					Toolbar_Not_Req,			ColumnBorder_Not_Req,	RowBorder_Not_Req,
				PagenavigationOnly,			RowNO_Not_Req,				ButtonHome_Req,			ButtonPrevious_Req,
				Accpet_Type,				combo_link,					QR_Image,				Tooltip_Not_Req,
				Forcefit,					columncaption_Not_Req,		Border_Not_Req,			IsModal,
				Alternate_Color_Req,		Map_In_Req,					Map_Out_Req,			Barcode_Image,
				Isfallback,					config_parameter,			config_value,			upload,
				Is_Varbinary,				FileSize,					EMail,					Phone,
				StaticCaption,				Datagrid,					MoveFirst,				Move_PrevSet,
				Move_Previous,				Move_Next,					Move_NextSet,			Move_Last,
				Carousel_Req,				Orientation,				WrapCount,				Box_Type,
				ISDeviceInfo,				ListControl,				col_caption_align,		Gridheaderstyle,
				Gridtoolbarstyle,			preevent,					postevent,				norowstodisplay_notreq,
				col_data_align,				avn_download,				PreventDownload,		ishijri,
				slider_type,				max_value,					min_value,				step_value,
				spin_system_task,			enabledefault,				hideinsert,				hidedelete,
				hidecopy,					hidecut,					hidefilterdata,			hidepdf,
				hidereport,					hidehtml,					hideexportexcel,		hideexportcsv,
				hideexporttext,				hideimportdata,				hidechart,				hideexportopenoffice,
				hidepersonalize,			hidefiltercolumn,			searchhide,				autolist_not_req,
				hideselect,					AutoHeight,					IsPivot,				QlikLink,
				RangeMinimum,				RangeMaximum,				RangeStartValue,		RangeEndValue,
				RangeStep,					RangeLabel,					RangeSelect,			ValueShown,
				Style,						SystemGeneratedFileId,		IsMarquee,				IsAssorted,
				RatingType,					CaptchaData,				rangetype,				RenderAs,
				noofrowsselected_req,		AttachmentWithDesc,			preserve_gridposition,	Image_Accept_Type,
				Accept_Type,				file_Accept_Type,			MlsearchOnly,			hidecolumnchooser,
				timestamp,					
				@ctxt_user,					GETDATE(),					@ctxt_user,				GETDATE()
		FROM	de_comp_ctrl_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@CustomerName
		AND		Project_Name		=	@ProjectName
		AND		Process_Name		=	@processname
		AND		Component_Name		=	@componentname
		AND NOT EXISTS (	SELECT 'X'
								FROM	de_published_comp_ctrl_type_mst b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@CustomerName
								AND		b.Project_Name		=	@ProjectName
								AND		b.Process_Name		=	@processname
								AND		b.Component_Name	=	@componentname
								AND		b.ecrno				=	@ecrno )

	INSERT INTO de_published_comp_ctrl_type_mst_extn
				(	customer_name,				project_name,				ecrno,				process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					createdby,					createddate,				modifiedby,			modifieddate,
					ShowLines,					PreTask,					PostTask,			BulkDownload, 	--TECH-68066	--TECH-68067
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues, 	--Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight,	--Code added for TECH-71262 on 14July22 --Code Added for the Defect Id TECH-72114-
	                --Code added for TECH-73996 starts
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
					PreviousCount)
					--Code added for TECG-73996 ends
	SELECT DISTINCT
					customer_name,				project_name,				@ecrno,	process_name,
					component_name,				ctrl_type_name,				ctrl_type_descr,	base_ctrl_type,
					Configuration,				SliderType,					SliderBehaviour,	RenderType,
					Orientation,				Startvalue,					Endvalue,			Minvalue,
					Maxvalue,					Stepvalue,					SliderValue,		Showvalue,
					ShowTooltip,				Rangelabel,					Rangevalue,			Rangetooltip,
					RangeSelect,				ValueShown,					ExpandEvent,		ExpandAllEvent,
					CollapseEvent,				CollapseAllEvent,			ClickEvent,			DDToolTip,
					ZoomMin,					ZoomMax,					DefaultZoom,		ZoomStep,
					NodeWidth,					NodeHeight,					DefaultFile,		IsOrgChart,
					checkevent,					bufferedrows,				SparkChartType,		ChartType,
					Delayedpwdmask,				preserve_gridposition,		Dynamicfileupload,	ServerSidePrint,
					MultiFileSelect,			NoofCtrlPerLine,			FormWidth,			ControlWidth,
					LabelWidth,					MetaDataBasedLink,			LabelAlignment,		Scan,
					Autoselect,					IsList,						MultiSelect,		SelectedRowcount,
					DockedItem,					NFCEnabled,					AutoScan,			IsToggle,
					NodeIconReqd,				NodeCustomClass,			IsDocked,			RuleBuilder,
					MultiSelectComboforRB,		CalendarControl,			Setfocusevent,		Leavefocusevent,
					GanttControl,				AutoSync,					SetFocusEventOccurence,LeaveFocusEventOccurence,
					IsChips,					IsSpellcheck,				DirectPrint,		ListItemExpander,
					ReadOnly,					ShowTodayLine,				ShowRollupTasks,	ShowProjectLines,
					SkipWeekendsDuringDragDrop,	LockedGridWidth,			RowHeight,			BottomLabelField,
					TopLabelField,				LeftLabelField,				RightLabelField,	RollupLabelField,
					Baseline,					ScrollToDateCentered,		Zoom,				Fit,
					Export,						Highlight,					Indent,				ContextMenu,
					PopupTaskEditor,			GanttShift,					GanttExpand,		GanttInsert,
					GanttDelete,				Calendar,					IsScheduler,		ListItemType,
					IsSelectionReqdList,		RowAlwaysExpanded,			IsMobile,			PaginationReqd,
					UpdateTaskReqd,				DeleteTaskReqd,				timestamp,
					@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE(),
					ShowLines,					PreTask,					PostTask,			BulkDownload, --TECH-68066
					HideRuleHeader,				HideANDOperator,			HideOROperator,		HideNOTOperator,
					HideGroupOperator,			HideRuleOperator,			SelectOnlyListValues,	--Code added for TECH-69624
					BrowsePreTask,				BrowsePostTask,				DeletePreTask,		DeletePostTask,
					ButtonStyle,				BadgeText,					AutoHeight,	--Code Added for the Defect Id TECH-72114-	
					--Code added for TECH-71262 on 14July22 
					--Code added for  TECH-73996 starts
					EyeIconForPassword,			Signature,					KeyupSearch,				Stepper,					
					LiveClock,		 			ClearTask,					ShowAnimation,				PreventMultipleRowSelection, 
					PreviousCount
					--Code added for  TECH-73996 ends	
			FROM	de_comp_ctrl_type_mst_extn a (NOLOCK)
			WHERE	Customer_Name		=	@CustomerName
			AND		Project_Name		=	@ProjectName
			AND		Process_Name		=	@processname
			AND		Component_Name		=	@componentname
			AND NOT EXISTS (	SELECT 'X'
								FROM	de_published_comp_ctrl_type_mst_extn b (NOLOCK)
								WHERE	b.Customer_Name		=	a.Customer_Name
								AND		b.Project_Name		=	a.Project_Name
								AND		b.Process_Name		=	a.Process_Name
								AND		b.Component_Name	=	a.Component_Name
								AND		b.ctrl_type_name	=	a.ctrl_type_name 
								
								AND		b.Customer_Name		=	@CustomerName
								AND		b.Project_Name		=	@ProjectName
								AND		b.Process_Name		=	@processname
								AND		b.Component_Name	=	@componentname
								AND		b.ecrno				=	@ecrno )

	INSERT INTO de_published_comp_task_type_mst
			(	customer_name,				project_name,				ecrno,				process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,	--TECH-75230
				createdby,					createddate,				modifiedby,			modifieddate	)
	SELECT DISTINCT
				customer_name,				project_name,				@ecrno,	process_name,
				component_name,				task_type_name,				task_type_descr,	default_for,
				refresh_on_save,			valid_on_init,				err_handle_method,	incl_place_holder,
				cond_ml_fetch,				clr_on_page_save,			hdr_fetch_req,		ml_fet_req,
				hdr_ref_req,				hdr_check_req,				proc_sel_rows,		usr_role_map,
				trn_scope_req,				comp_task_type_sysid,		task_type_doc,		hdr_save_req,
				ml_save_req,				fprowno_req,				cbdef_req,			no_placeholder,
				data_save_req,				print_req,					task_confirmation,	Logic_Extensions,
				process_updrows,			alternate_db,				sys_proc_sel_rows,	sys_process_updrows,
				Linkasui,					Uiastrans,					MLSaveSinglesegment,sys_proc_selupd_rows,
				CurrentContextInformation,	ParentContextInformation,	ModeflagEnabled,	BulkValidation,
				timestamp,					BubbleMessage,	--TECH-75230
				@ctxt_user,					GETDATE(),					@ctxt_user,			GETDATE()
		FROM	de_comp_task_type_mst a (NOLOCK)
		WHERE	Customer_Name		=	@CustomerName
		AND		Project_Name		=	@ProjectName
		AND		Process_Name		=	@processname
		AND		Component_Name		=	@componentname
		AND NOT EXISTS (	SELECT 'X'
							FROM	de_published_comp_task_type_mst b (NOLOCK)
							WHERE	b.Customer_Name		=	a.Customer_Name
							AND		b.Project_Name		=	a.Project_Name
							AND		b.Process_Name		=	a.Process_Name
							AND		b.Component_Name	=	a.Component_Name
							AND		b.task_type_name	=	a.task_type_name 
							
							AND		b.Customer_Name		=	@CustomerName
							AND		b.Project_Name		=	@ProjectName
							AND		b.Process_Name		=	@processname
							AND		b.Component_Name	=	@componentname
							AND		b.ecrno				=	@ecrno )

	--case ID TECH-66583 Ends

--TECH-72114
	INSERT INTO de_published_task_gql_report
	         (	CustomerName,	ProjectName,	DocNo,			ProcessName,	ComponentName,
				ActivityName,	UIName,			TaskName,		ReportName,		OutputFormat,
				LaunchMode,		TimeStamp,		CreatedBy,		CreatedDate,	ModifiedBy,			ModifiedDate)

	SELECT	   CustomerName,	ProjectName,	@ecrno,			ProcessName,	ComponentName,
				ActivityName,	UIName,			TaskName,		ReportName,		OutputFormat,
				LaunchMode,		TimeStamp,		@ctxt_user,		GETDATE(),		@ctxt_user,			GETDATE()
	FROM  de_task_gql_report WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname

	INSERT INTO de_published_task_gql_report_param
	         (	CustomerName,	ProjectName,	DocNo,			ProcessName,	ComponentName,
				ActivityName,	UIName,			TaskName,		ReportName,		ParameterName,
				BTSynonym,		ControlID,		ViewName,		DefaultValue,	TimeStamp,
				CreatedBy,		CreatedDate,	ModifiedBy,		ModifiedDate)

	SELECT	   CustomerName,	ProjectName,	@ecrno,				ProcessName,	ComponentName,
			   ActivityName,	UIName,			TaskName,			ReportName,		ParameterName,
			   BTSynonym,		ControlID,		ViewName,			DefaultValue,	TimeStamp,	   
			   @ctxt_user,		GETDATE(),		@ctxt_user,			GETDATE()
	FROM  de_task_gql_report_param WITH (NOLOCK)
	WHERE CustomerName = @customername AND  ProjectName = @projectname AND  ProcessName = @processname AND  ComponentName = @componentname
--TECH-72114

set nocount off
end
GO

IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'de_published_ins_sp_ecr' AND TYPE = 'P')
BEGIN
	GRANT EXEC ON de_published_ins_sp_ecr TO PUBLIC
END
GO

