IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_method_sp_savparpar' AND TYPE = 'P')
BEGIN
  DROP PROC de_method_sp_savparpar
END
GO
/********************************************************************************/
/* procedure    : de_method_sp_savparpar                                        */
/* description  :                                                               */
/********************************************************************************/
/* project      :                                                               */
/* version      :                                                               */
/********************************************************************************/
/* referenced   :                                                               */
/* tables       :                                                               */
/********************************************************************************/
/* development history                                                          */
/********************************************************************************/
/* author       : vasu k                                                        */
/* date         : 12/ 12/ 2003                                                  */
/********************************************************************************/
/* modification history                                                         */
/********************************************************************************/
/* modified by  : DNR                                                           */
/* date         : 25-June-2004                                                  */
/* description  : DEENG203ACC_000081                                            */
/* RefineMethods Information is not updating properly.							*/
/* Modified By  :Sangeetha L	19Apr2006		PNR2.0_8038						*/
/********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230	*/
/********************************************************************************/
CREATE procedure de_method_sp_savparpar                                        
	@ctxt_language             engg_ctxt_language,
	@ctxt_ouinstance           engg_ctxt_ouinstance,
	@ctxt_service              engg_ctxt_service,
	@ctxt_user                 engg_ctxt_user,
	@engg_act_descr            engg_description,
	@engg_component            engg_description,
	@engg_customer_name        engg_name,
	@engg_flowbr_name          engg_name,
	@engg_ico_no               engg_name,
	@engg_met_newseq           engg_seqno,
	@engg_method_name          engg_name,
	@engg_par_parname          engg_name,
	@engg_par_reqflag          engg_flag,
	@engg_par_rsname           engg_name,
	@engg_par_seqno            engg_seqno,
	@engg_process_descr        engg_description,
	@engg_project_name         engg_name,
	@engg_service_name         engg_name,
	@engg_space		   		   engg_name,
	@engg_ui_descr             engg_description,
	@modeflag                  engg_modeflag,
	@fprowno                   engg_rowno,
	@m_errorid                 engg_seq_no output
as
begin

	set nocount on

	

	--temporary and formal parameters mapping
	select @ctxt_language                 = @ctxt_language
	select @ctxt_ouinstance               = @ctxt_ouinstance
	select @ctxt_service                  = ltrim(rtrim(@ctxt_service))
	select @ctxt_user                     = ltrim(rtrim(@ctxt_user))
	select @engg_act_descr                = ltrim(rtrim(@engg_act_descr))
	select @engg_component                = ltrim(rtrim(@engg_component))
	select @engg_customer_name            = ltrim(rtrim(@engg_customer_name))
	select @engg_flowbr_name              = ltrim(rtrim(@engg_flowbr_name))
	select @engg_ico_no                   = ltrim(rtrim(@engg_ico_no))
	select @engg_met_newseq               = @engg_met_newseq
	select @engg_method_name              = ltrim(rtrim(@engg_method_name))
	select @engg_par_parname              = ltrim(rtrim(@engg_par_parname))
	select @engg_par_reqflag     		  = ltrim(rtrim(@engg_par_reqflag))
	select @engg_par_rsname               = ltrim(rtrim(@engg_par_rsname))
	select @engg_par_seqno                = @engg_par_seqno
	select @engg_process_descr            = ltrim(rtrim(@engg_process_descr))
	select @engg_project_name             = ltrim(rtrim(@engg_project_name))
	select @engg_service_name             = ltrim(rtrim(@engg_service_name))
	select @engg_ui_descr                 = ltrim(rtrim(@engg_ui_descr))
	select @modeflag                      = ltrim(rtrim(@modeflag))
	select @fprowno                       = @fprowno

	--null checking
	if @ctxt_language 		= -915	select @ctxt_language 		= null
	if @ctxt_ouinstance 	= -915	select @ctxt_ouinstance 	= null
	if @ctxt_service 		= '~#~'	select @ctxt_service 		= null
	if @ctxt_user 			= '~#~'	select @ctxt_user 			= null
	if @engg_act_descr 		= '~#~'	select @engg_act_descr 		= null
	if @engg_component 		= '~#~'	select @engg_component 		= null
	if @engg_customer_name 	= '~#~'	select @engg_customer_name 	= null
	if @engg_flowbr_name 	= '~#~'	select @engg_flowbr_name 	= null
	if @engg_ico_no 		= '~#~'	select @engg_ico_no 		= null
	if @engg_met_newseq 	= -915	select @engg_met_newseq 	= null
	if @engg_method_name 	= '~#~'	select @engg_method_name 	= null
	if @engg_par_parname 	= '~#~'	select @engg_par_parname 	= null
	if @engg_par_reqflag 	= '~#~'	select @engg_par_reqflag 	= null
	if @engg_par_rsname 	= '~#~'	select @engg_par_rsname 	= null
	if @engg_par_seqno 		= -915	select @engg_par_seqno 		= null
	if @engg_process_descr 	= '~#~'	select @engg_process_descr 	= null
	if @engg_project_name 	= '~#~'	select @engg_project_name 	= null
	if @engg_service_name 	= '~#~'	select @engg_service_name 	= null
	if @engg_ui_descr 		= '~#~'	select @engg_ui_descr 		= null
	if @modeflag 			= '~#~'	select @modeflag 			= null
	if @fprowno 			= -915	select @fprowno 			= null



	select @fprowno = @fprowno + 1

/*Modified by Feroz for Bug ID DEENG203SYS_000072 on  28/5/2004 */
/*Component and Process Description Commented*/


	declare @process_name_tmp  engg_name
	select 	@process_name_tmp = process_name 
	from 	de_ui_ico nolock
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_descr	= @engg_process_descr
		
	declare @component_name_tmp  engg_name
	select @component_name_tmp = component_name 
	from de_ui_ico nolock
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_descr	= @engg_component


	declare @activity_name_tmp  engg_name
	select @activity_name_tmp = activity_name
	from de_ui_ico nolock
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and		activity_descr  = @engg_act_descr
			
	
	declare @ui_name_tmp	engg_name
	select  @ui_name_tmp = ui_name
	from 	de_ui_ico nolock
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and		activity_name	= @activity_name_tmp
	and 	ui_descr 		= @engg_ui_descr


	declare  @methodid_tmp  engg_id_no
	select @methodid_tmp = methodid 
	from de_fw_des_processsection_br_is nolock
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		process_name	= @process_name_tmp
	and		component_name	= @component_name_tmp
	and		servicename		= @engg_service_name
	and		method_name		= @engg_method_name

	
	if @engg_par_reqflag is null 
		select @engg_par_reqflag = '0'
	
	
	
	if @engg_par_reqflag = '1' and isnull(@engg_met_newseq,0) = 0
	begin
		exec	engg_error_sp	'de_method_sp_savparpar',
					1,
					'New Sequence Number cannot be null in Row No: <%1>' ,
					@ctxt_language,
					@ctxt_ouinstance,
					@ctxt_service,
					@ctxt_user,
					@fprowno,
					'',
					'',
					'',
					@m_errorid output
		return	
	end
	 	
-- 	if @engg_par_reqflag = 0 and isnull(@engg_met_newseq,'')<> ''
-- 	begin
-- 		exec	engg_error_sp	'de_method_sp_savparpar',
-- 					1,
-- 					'New Sequence Number should be null in Row No: <%1>' ,
-- 					@ctxt_language,
-- 					@ctxt_ouinstance,
-- 					@ctxt_service,
-- 					@ctxt_user,
-- 					@fprowno,
-- 					'',
-- 					'',
-- 					'',
-- 					@m_errorid output
-- 		return	
-- 	end

	if @engg_par_reqflag = '0'
		select @engg_met_newseq = 0

	if 	@engg_par_reqflag = '1'
	begin
		--CODE ADDED BY DNR ON 29-June-2004 FOR THE BUG ID DEENG203ACC_000081 
		--System should not allow to map the parameters,which are removed at the design time.
		if not exists( select 'X'
					from	de_fw_des_di_parameter (nolock)
					where 	customer_name 	= @engg_customer_name
					and 	project_name 	= @engg_project_name
					and 	process_name	= @process_name_tmp
					and 	component_name	= @component_name_tmp
					and 	servicename		= @engg_service_name
					and 	method_name		= @engg_method_name
					and		parametername	= @engg_par_parname )
		begin
				exec	engg_error_sp	'de_method_sp_savparpar',
				1,
				'Selected parameter is in deleted status,Error at row no: <%1>',
				@ctxt_language,
				@ctxt_ouinstance,
				@ctxt_service,
				@ctxt_user,
				@fprowno,
				'',
				'',
				'',
				@m_errorid output

				return	
		end	
	end

-- code modified by bakiaraj V 0n 30-DEC-2004 for ECPF204ACC_000016
-- code modified by Feroz 0n 16-Feb-2005 for DEPFSUPPORT_000021 
	if exists 	(select 'x'
				from	de_refine_parameter a (nolock)
				where 	a.customer_name 	= @engg_customer_name
				and 	a.project_name 		= @engg_project_name
				and 	a.process_name		= @process_name_tmp
				and 	a.component_name	= @component_name_tmp
				and 	a.activity_name		= @activity_name_tmp
				and 	a.ui_name			= @ui_name_tmp
				and 	a.service_name		= @engg_service_name
				and 	a.method_name		= @engg_method_name
				and		a.parameter_name	= @engg_par_parname
				and		a.parameter_name	not in (select 	b.logicalparametername 
													from 	de_fw_des_br_logical_parameter b (nolock),
															de_fw_des_processsection_br_is c (nolock)	
													where 	a.customer_name		= b.customer_name
													and		a.project_name		= b.project_name
													and		a.method_name		= b.method_name
													and 	a.customer_name		= c.customer_name
													and		a.project_name		= c.project_name
													and 	a.process_name		= c.process_name		
													and 	a.component_name	= c.component_name	
													and		a.service_name		= c.servicename	
													and		a.method_name		= c.method_name
													and		c.customer_name		= b.customer_name
													and		c.project_name		= b.project_name
													and		c.methodid			= b.methodid
													and		c.method_name		= b.method_name))

-- code modified by Feroz 0n 16-Feb-2005 for DEPFSUPPORT_000021 
	begin
		exec	engg_error_sp	'de_method_sp_savparpar',
		1,
		'Selected  Method Parameter is Deleted,while generating the design',
		@ctxt_language,
		@ctxt_ouinstance,
		@ctxt_service,
		@ctxt_user,
		@fprowno,
		'',
		'',
		'',
		@m_errorid output

		return			
	end	


	update de_refine_parameter 
	set required_flag 	=	@engg_par_reqflag,
		new_seq_no		= 	@engg_met_newseq,
		sequence_no		=	@engg_met_newseq,
		flowbr_name		=   isnull(@engg_flowbr_name,''),   /* PNR2.0_8038 */
		modifiedby		=	@ctxt_user,	--TECH-75230
		modifieddate	=	getdate() --TECH-75230
	where 	customer_name 	= @engg_customer_name
	and 	project_name 	= @engg_project_name
	and 	process_name	= @process_name_tmp
	and 	component_name	= @component_name_tmp
	and 	activity_name	= @activity_name_tmp
	and 	ui_name			= @ui_name_tmp
	and 	service_name	= @engg_service_name
	and 	method_name		= @engg_method_name
	and		parameter_name	= @engg_par_parname
			
		
-- 	else
-- 		exec de_refine_parameter_sp_ins
-- 		@ctxt_language , @ctxt_ouinstance , @ctxt_service , @ctxt_user ,
-- 		@engg_customer_name , @engg_project_name , @process_name_tmp , @component_name_tmp ,
-- 		@activity_name_tmp , @ui_name_tmp , @engg_service_name , @engg_flowbr_name ,
-- 		@engg_method_name , @engg_par_parname , @engg_par_seqno , @engg_met_newseq ,
-- 		@engg_par_reqflag , 1 , 1 , @m_errorid
-- 		


	select  @fprowno     'fprowno'

	set nocount off
end

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'de_method_sp_savparpar' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON de_method_sp_savparpar TO PUBLIC
END
GO


