IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DE_TASK_CONTROL_MAP_SP_INS' AND TYPE = 'P')
BEGIN
  DROP PROC DE_TASK_CONTROL_MAP_SP_INS
END
GO
set quoted_identifier off
go
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		DE_TASK_CONTROL_MAP_SP_INS.sql
********************************************************************************/
/*      V E R S I O N      :  2.0.4    */
/*      Released By        :  Ptech    */
/*      Release Comments   :  Released On 30-September-2004    */
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 01-APR-2004    */
/*      V E R S I O N      :  2.0.3    */
/*      Released By        :  PTech    */
/*      Release Comments   :  Released on 01-APR-2004    */
/**********************************************************************************/
/*      MODIFIED BY        : Muthu Kumar.K                                        */
/*      MODIFIED ON        : 19-09-05                                             */
/*   	DESCRIPTION        : Added Mapping_instance parameter in input parameter  */
/*                           and also in insert table of DE_TASK_CONTROL_MAP      */
/**********************************************************************************/
/* Mofidifed By :Ponmalar A		Date: 01Dec2022			DefectID:	TECH-75230	*/
/********************************************************************************/
CREATE PROCEDURE DE_TASK_CONTROL_MAP_SP_INS
	@CTXT_LANGUAGE_IN ENGG_CTXT_LANGUAGE,
	@CTXT_OUINSTANCE_IN ENGG_CTXT_OUINSTANCE,
	@CTXT_SERVICE_IN ENGG_CTXT_SERVICE,
	@CTXT_USER_IN ENGG_CTXT_USER,
	@CUSTOMER_NAME_IN ENGG_NAME,
	@PROJECT_NAME_IN ENGG_NAME,
	@PROCESS_NAME_IN ENGG_NAME,
	@COMPONENT_NAME_IN ENGG_NAME,
	@ACTIVITY_NAME_IN ENGG_NAME,
	@UI_NAME_IN ENGG_NAME,
	@ACTION_NAME_IN ENGG_NAME,
	@PAGE_NAME_IN ENGG_NAME,
	@SECTION_NAME_IN ENGG_NAME,
	@CONTROL_BT_SYNONYM_IN ENGG_NAME,
	@MAP_FLAG_IN ENGG_FLAG,
	@MAP_ML_FLAG_IN ENGG_FLAG,
	@MAPPING_INSTANCE_IN ENGG_NAME,
	@engg_tc_load	engg_flag,	--TECH-75230
	@TIMESTAMP_IN INT,
	@M_ERRORID INT OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	/********************************************************************************/
	/*                          TEMPORARY INPUT PARAMETERS                          */
	/********************************************************************************/
	DECLARE @ERRORMESSAGE_TMP VARCHAR(1000),
		@ERRORNO_TMP INT,
		@SPERROR INT,
		@DUPCOUNT_TMP INT,
		@TIMESTAMP_TMP INT,
		@CTXT_LANGUAGE_TMP ENGG_CTXT_LANGUAGE,
		@CUSTOMER_NAME_TMP ENGG_NAME,
		@CTXT_OUINSTANCE_TMP ENGG_CTXT_OUINSTANCE,
		@PROJECT_NAME_TMP ENGG_NAME,
		@CTXT_SERVICE_TMP ENGG_CTXT_SERVICE,
		@PROCESS_NAME_TMP ENGG_NAME,
		@COMPONENT_NAME_TMP ENGG_NAME,
		@CTXT_USER_TMP ENGG_CTXT_USER,
		@ACTIVITY_NAME_TMP ENGG_NAME,
		@UI_NAME_TMP ENGG_NAME,
		@ACTION_NAME_TMP ENGG_NAME,
		@PAGE_NAME_TMP ENGG_NAME,
		@SECTION_NAME_TMP ENGG_NAME,
		@CONTROL_BT_SYNONYM_TMP ENGG_NAME,
		@MAP_FLAG_TMP ENGG_FLAG,
		@MAP_ML_FLAG_TMP ENGG_FLAG,
		@MAPPING_INSTANCE_TMP ENGG_NAME,
		@TC_SYSID_TMP ENGG_SYSID

	/********************************************************************************/
	/*                                  ASSIGNING TO TEMP VARIABLE                  */
	/********************************************************************************/
	SELECT @CTXT_LANGUAGE_TMP = @CTXT_LANGUAGE_IN,
		@CUSTOMER_NAME_TMP = LTRIM(RTRIM(@CUSTOMER_NAME_IN)),
		@CTXT_OUINSTANCE_TMP = @CTXT_OUINSTANCE_IN,
		@PROJECT_NAME_TMP = LTRIM(RTRIM(@PROJECT_NAME_IN)),
		@CTXT_SERVICE_TMP = LTRIM(RTRIM(@CTXT_SERVICE_IN)),
		@PROCESS_NAME_TMP = LTRIM(RTRIM(@PROCESS_NAME_IN)),
		@COMPONENT_NAME_TMP = LTRIM(RTRIM(@COMPONENT_NAME_IN)),
		@CTXT_USER_TMP = LTRIM(RTRIM(@CTXT_USER_IN)),
		@ACTIVITY_NAME_TMP = LTRIM(RTRIM(@ACTIVITY_NAME_IN)),
		@UI_NAME_TMP = LTRIM(RTRIM(@UI_NAME_IN)),
		@ACTION_NAME_TMP = LTRIM(RTRIM(@ACTION_NAME_IN)),
		@PAGE_NAME_TMP = LTRIM(RTRIM(@PAGE_NAME_IN)),
		@SECTION_NAME_TMP = LTRIM(RTRIM(@SECTION_NAME_IN)),
		@CONTROL_BT_SYNONYM_TMP = LTRIM(RTRIM(@CONTROL_BT_SYNONYM_IN)),
		@MAP_FLAG_TMP = LTRIM(RTRIM(@MAP_FLAG_IN)),
		@MAP_ML_FLAG_TMP = LTRIM(RTRIM(@MAP_ML_FLAG_IN)),
		@MAPPING_INSTANCE_TMP = LTRIM(RTRIM(@MAPPING_INSTANCE_TMP)),
		@TIMESTAMP_TMP = @TIMESTAMP_IN,
		@M_ERRORID = 0

	/********************************************************************************/
	/*                   TEMPORARY AND FORMAL PARAMETERS MAPPING                    */
	/********************************************************************************/
	IF @CTXT_LANGUAGE_TMP = - 915
		SELECT @CTXT_LANGUAGE_TMP = NULL

	IF @CUSTOMER_NAME_TMP = '~#~'
		SELECT @CUSTOMER_NAME_TMP = NULL

	IF @CTXT_OUINSTANCE_TMP = - 915
		SELECT @CTXT_OUINSTANCE_TMP = NULL

	IF @PROJECT_NAME_TMP = '~#~'
		SELECT @PROJECT_NAME_TMP = NULL

	IF @CTXT_SERVICE_TMP = '~#~'
		SELECT @CTXT_SERVICE_TMP = NULL

	IF @PROCESS_NAME_TMP = '~#~'
		SELECT @PROCESS_NAME_TMP = NULL

	IF @COMPONENT_NAME_TMP = '~#~'
		SELECT @COMPONENT_NAME_TMP = NULL

	IF @CTXT_USER_TMP = '~#~'
		SELECT @CTXT_USER_TMP = NULL

	IF @ACTIVITY_NAME_TMP = '~#~'
		SELECT @ACTIVITY_NAME_TMP = NULL

	IF @UI_NAME_TMP = '~#~'
		SELECT @UI_NAME_TMP = NULL

	IF @ACTION_NAME_TMP = '~#~'
		SELECT @ACTION_NAME_TMP = NULL

	IF @PAGE_NAME_TMP = '~#~'
		SELECT @PAGE_NAME_TMP = NULL

	IF @SECTION_NAME_TMP = '~#~'
		SELECT @SECTION_NAME_TMP = NULL

	IF @CONTROL_BT_SYNONYM_TMP = '~#~'
		SELECT @CONTROL_BT_SYNONYM_TMP = NULL

	IF @MAP_FLAG_TMP = '~#~'
		SELECT @MAP_FLAG_TMP = NULL

	IF @MAP_ML_FLAG_TMP = '~#~'
		SELECT @MAP_ML_FLAG_TMP = NULL

	IF @MAPPING_INSTANCE_TMP = '~#~'
		SELECT @MAPPING_INSTANCE_TMP = NULL

	IF @TC_SYSID_TMP = '~#~'
		SELECT @TC_SYSID_TMP = NULL

	IF @TIMESTAMP_TMP = - 915
		SELECT @TIMESTAMP_TMP = NULL

	/********************************************************************************/
	/*                   ASSIGNMENT OF DEFAULT DATA                                 */
	/********************************************************************************/
	SELECT @DUPCOUNT_TMP = 0,
		@ERRORNO_TMP = 0,
		@SPERROR = 0

	SELECT @MAP_FLAG_TMP = ISNULL(@MAP_FLAG_TMP, 'Y'),
		@MAP_ML_FLAG_TMP = ISNULL(@MAP_ML_FLAG_TMP, 'N')

	/********************************************************************************/
	/*                   NULL CHECK VALIDATION                                      */
	/********************************************************************************/
	/*                   NULL CHECK FOR COLUMN CUSTOMER_NAME                       */
	BEGIN
		IF ISNULL(@CUSTOMER_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : CUSTOMER NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PROJECT_NAME                       */
	BEGIN
		IF ISNULL(@PROJECT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PROJECT NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PROCESS_NAME                       */
	BEGIN
		IF ISNULL(@PROCESS_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PROCESS NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN COMPONENT_NAME                       */
	BEGIN
		IF ISNULL(@COMPONENT_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : COMPONENT NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN ACTIVITY_NAME                       */
	BEGIN
		IF ISNULL(@ACTIVITY_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : ACTIVITY NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN UI_NAME                       */
	BEGIN
		IF ISNULL(@UI_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : USER INTERFACE NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN ACTION_NAME                       */
	BEGIN
		IF ISNULL(@ACTION_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : ACTION NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN PAGE_NAME                       */
	BEGIN
		IF ISNULL(@PAGE_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : PAGE NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN SECTION_NAME                       */
	BEGIN
		IF ISNULL(@SECTION_NAME_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : SECTION NAME"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN CONTROL_BT_SYNONYM                       */
	BEGIN
		IF ISNULL(@CONTROL_BT_SYNONYM_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : CONTROL BT SYNONYM"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN MAP_FLAG                       */
	BEGIN
		IF ISNULL(@MAP_FLAG_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : MAP FLAG"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/*                   NULL CHECK FOR COLUMN MAP_ML_FLAG                       */
	BEGIN
		IF ISNULL(@MAP_ML_FLAG_TMP, '~#~') = '~#~'
		BEGIN
			SELECT @ERRORMESSAGE_TMP = "ENTER VALUE FOR COLUMN : MAP TO ALL ML METHODS FLAG"

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   PRIMARY KEY VIOLATION CHECK                                */
	/********************************************************************************/
	/* VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,ACTION NAME,PAGE NAME,SECTION NAME,CONTROL BT SYNONYM IN  TASK CONTROL MAPPING CANNOT  BE REPEATED */
	BEGIN
		IF EXISTS (
				SELECT 1
				FROM DE_TASK_CONTROL_MAP
				WHERE CUSTOMER_NAME = @CUSTOMER_NAME_TMP
					AND PROJECT_NAME = @PROJECT_NAME_TMP
					AND PROCESS_NAME = @PROCESS_NAME_TMP
					AND COMPONENT_NAME = @COMPONENT_NAME_TMP
					AND ACTIVITY_NAME = @ACTIVITY_NAME_TMP
					AND UI_NAME = @UI_NAME_TMP
					AND ACTION_NAME = @ACTION_NAME_TMP
					AND PAGE_NAME = @PAGE_NAME_TMP
					AND SECTION_NAME = @SECTION_NAME_TMP
					AND CONTROL_BT_SYNONYM = @CONTROL_BT_SYNONYM_TMP
				)
		BEGIN
			SELECT @ERRORMESSAGE_TMP = " VALUES FOR COLUMNS CUSTOMER NAME,PROJECT NAME,PROCESS NAME,COMPONENT NAME,ACTIVITY NAME,USER INTERFACE NAME,ACTION NAME,PAGE NAME,SECTION NAME,CONTROL BT SYNONYM IN  TASK CONTROL MAPPING CANNOT  BE REPEATED "

			EXEC ENGG_ERROR_SP 'DE_TASK_CONTROL_MAP_SP_INS',
				@ERRORNO_TMP,
				@ERRORMESSAGE_TMP,
				@CTXT_LANGUAGE_TMP,
				@CTXT_OUINSTANCE_TMP,
				@CTXT_SERVICE_TMP,
				@CTXT_USER_TMP,
				'',
				'',
				'',
				'',
				@SPERROR OUTPUT

			SELECT @M_ERRORID = @SPERROR

			RETURN
		END
	END

	/********************************************************************************/
	/*                   CHECK FOR FORIEGN KEY VIOLATION                            */
	/********************************************************************************/
	/********************************************************************************/
	/*                   INSERT DATA INTO THE TABLE    DE_TASK_CONTROL_MAP            */
	/********************************************************************************/
	BEGIN
		EXEC ENGG_GET_NEWSYSID 'DE_TASK_CONTROL_MAP',
			@TC_SYSID_TMP OUTPUT

		INSERT INTO DE_TASK_CONTROL_MAP (
			CUSTOMER_NAME,
			PROJECT_NAME,
			PROCESS_NAME,
			COMPONENT_NAME,
			ACTIVITY_NAME,
			UI_NAME,
			ACTION_NAME,
			PAGE_NAME,
			SECTION_NAME,
			CONTROL_BT_SYNONYM,
			MAP_FLAG,
			MAP_ML_FLAG,
			MAPPING_INSTANCE,
			TC_SYSID,
			CREATEDBY,
			CREATEDDATE,
			MODIFIEDBY,
			MODIFIEDDATE,
			TIMESTAMP,
			Load		---TECH-75230
			)
		VALUES (
			@CUSTOMER_NAME_TMP,
			@PROJECT_NAME_TMP,
			@PROCESS_NAME_TMP,
			@COMPONENT_NAME_TMP,
			@ACTIVITY_NAME_TMP,
			@UI_NAME_TMP,
			@ACTION_NAME_TMP,
			@PAGE_NAME_TMP,
			@SECTION_NAME_TMP,
			@CONTROL_BT_SYNONYM_TMP,
			@MAP_FLAG_TMP,
			@MAP_ML_FLAG_TMP,
			@MAPPING_INSTANCE_TMP,
			@TC_SYSID_TMP,
			@CTXT_USER_TMP,
			GETDATE(),
			@CTXT_USER_TMP,
			GETDATE(),
			@TIMESTAMP_TMP,
			@engg_tc_load		--TECH-75230
			)
	END
END

GO

IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'DE_TASK_CONTROL_MAP_SP_INS' AND TYPE = 'P')
BEGIN
    GRANT EXEC ON DE_TASK_CONTROL_MAP_SP_INS TO PUBLIC
END
GO
