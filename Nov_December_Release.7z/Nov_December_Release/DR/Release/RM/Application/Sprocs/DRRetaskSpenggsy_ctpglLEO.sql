
/******************************************************************************/
/* Procedure					: DRRetaskSpenggsy_ctpglLEO								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* modified by  : Veena U                                      					*/  
/* date         : Nov 2 2015                                      				*/  
/* BugId        : PLF2.0_15434                                          		*/  
/********************************************************************************/ 
/* modified by  : Pavithra V                                      					*/  
/* date         : NOV-20-2019                                      				*/  
/* BugId        : TECH-39352                                          		*/  
/********************************************************************************/
/* modified by  : Ganesh Prabhu S                                      			*/  
/* date         : NOV-14-2022                                      				*/  
/* BugId        : TECH-74248                                          			*/  
/********************************************************************************/
CREATE Procedure DRRetaskSpenggsy_ctpglLEO
	@ctxt_ouinstance          	ctxt_ouinstance, --Input 
	@ctxt_user                	ctxt_user, --Input 
	@ctxt_language            	ctxt_language, --Input 
	@ctxt_service             	ctxt_service, --Input 
	@engg_component           	engg_description, --Input 
	@engg_ctrlatr_act_desc    	engg_description, --Input 
	@engg_ctrlatr_act_name    	engg_name, --Input 
	@engg_ctrlatr_seg_name    	engg_name, --Input 
	@engg_ctrlatr_task_desc   	engg_description, --Input 
	@engg_ctrlatr_task_name   	engg_name, --Input 
	@engg_ctrlatr_ui_desc     	engg_description, --Input 
	@engg_ctrlatr_ui_name     	engg_name, --Input 
	@engg_customer_name       	engg_name, --Input 
	@engg_ico_no              	engg_name, --Input 
	@engg_process_descr       	engg_description, --Input 
	@engg_project_name        	engg_name, --Input 
	@engg_service_name        	engg_name, --Input 
	@engg_ctrlatr_syn_typ     	engg_name, --Input 
	@m_errorid                	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	Set nocount on
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0

	--declaration of temporary variables


	--temporary and formal parameters mapping

	Set @ctxt_user                 = ltrim(rtrim(@ctxt_user))
	Set @ctxt_service              = ltrim(rtrim(@ctxt_service))
	Set @engg_component            = ltrim(rtrim(@engg_component))
	Set @engg_ctrlatr_act_desc     = ltrim(rtrim(@engg_ctrlatr_act_desc))
	Set @engg_ctrlatr_act_name     = ltrim(rtrim(@engg_ctrlatr_act_name))
	Set @engg_ctrlatr_seg_name     = ltrim(rtrim(@engg_ctrlatr_seg_name))
	Set @engg_ctrlatr_task_desc    = ltrim(rtrim(@engg_ctrlatr_task_desc))
	Set @engg_ctrlatr_task_name    = ltrim(rtrim(@engg_ctrlatr_task_name))
	Set @engg_ctrlatr_ui_desc      = ltrim(rtrim(@engg_ctrlatr_ui_desc))
	Set @engg_ctrlatr_ui_name      = ltrim(rtrim(@engg_ctrlatr_ui_name))
	Set @engg_customer_name        = ltrim(rtrim(@engg_customer_name))
	Set @engg_ico_no               = ltrim(rtrim(@engg_ico_no))
	Set @engg_process_descr        = ltrim(rtrim(@engg_process_descr))
	Set @engg_project_name         = ltrim(rtrim(@engg_project_name))
	Set @engg_service_name         = ltrim(rtrim(@engg_service_name))
	Set @engg_ctrlatr_syn_typ      = ltrim(rtrim(@engg_ctrlatr_syn_typ))

	--null checking

	IF @ctxt_ouinstance = -915
		Select @ctxt_ouinstance = null  

	IF @ctxt_user = '~#~' 
		Select @ctxt_user = null  

	IF @ctxt_language = -915
		Select @ctxt_language = null  

	IF @ctxt_service = '~#~' 
		Select @ctxt_service = null  

	IF @engg_component = '~#~' 
		Select @engg_component = null  

	IF @engg_ctrlatr_act_desc = '~#~' 
		Select @engg_ctrlatr_act_desc = null  

	IF @engg_ctrlatr_act_name = '~#~' 
		Select @engg_ctrlatr_act_name = null  

	IF @engg_ctrlatr_seg_name = '~#~' 
		Select @engg_ctrlatr_seg_name = null  

	IF @engg_ctrlatr_task_desc = '~#~' 
		Select @engg_ctrlatr_task_desc = null  

	IF @engg_ctrlatr_task_name = '~#~' 
		Select @engg_ctrlatr_task_name = null  

	IF @engg_ctrlatr_ui_desc = '~#~' 
		Select @engg_ctrlatr_ui_desc = null  

	IF @engg_ctrlatr_ui_name = '~#~' 
		Select @engg_ctrlatr_ui_name = null  

	IF @engg_customer_name = '~#~' 
		Select @engg_customer_name = null  

	IF @engg_ico_no = '~#~' 
		Select @engg_ico_no = null  

	IF @engg_process_descr = '~#~' 
		Select @engg_process_descr = null  

	IF @engg_project_name = '~#~' 
		Select @engg_project_name = null  

	IF @engg_service_name = '~#~' 
		Select @engg_service_name = null  

	IF @engg_ctrlatr_syn_typ = '~#~' 
		Select @engg_ctrlatr_syn_typ = null  

			declare @tmp_proc		engg_name,
			@tmp_comp		engg_name,
			@tmp_page		engg_name,
			@tmp_tsk		engg_name
						
	select 	@tmp_proc		= process_name 
	from 	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_descr	= @engg_process_descr
		
	select 	@tmp_comp		= component_name 
	from 	de_ui_ico (nolock)
	where 	customer_name	= @engg_customer_name
	and		project_name	= @engg_project_name
	and		ico_no			= @engg_ico_no
	and		process_name	= @tmp_proc
	and		component_descr	= @engg_component

	if	@engg_ctrlatr_syn_typ	= 'Control'
	Begin
			IF exists (	Select	'x'
					from	de_ui_control	ctrl(nolock),
							es_comp_ctrl_type_mst	ctype(nolock)
					where 	ctrl.customer_name		= ctype.customer_name
					and		ctrl.project_name		= ctype.project_name
					and		ctrl.process_name		= ctype.process_name
					and		ctrl.component_name		= ctype.component_name
					and		ctrl.control_type		= ctype.ctrl_type_name
					and		ctrl.customer_name		= @engg_customer_name
					and		ctrl.project_name		= @engg_project_name
					and		ctrl.process_name		= @tmp_proc
					and		ctrl.component_name		= @tmp_comp
					and 	activity_name			= @engg_ctrlatr_act_name
					and		ui_name					= @engg_ctrlatr_ui_name
					--and		base_ctrl_type			<>'Grid'
				--Code added by the defect id : TECH-39352
	           and     base_ctrl_type not in ('Grid','Label')
	           and     control_type <> 'Label'
	           --Code added by the defect id : TECH-39352
					and		visisble_flag			= 'Y'
					and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection'))
		Begin
			Select	distinct
					page_bt_synonym		'engg_ctrlatr_list_pagnam',
					control_bt_synonym	'engg_ctrlatr_list_synnam'
			from	de_ui_control	ctrl(nolock),
					es_comp_ctrl_type_mst	ctype(nolock)
			where 	ctrl.customer_name		= ctype.customer_name
			and		ctrl.project_name		= ctype.project_name
			and		ctrl.process_name		= ctype.process_name
			and		ctrl.component_name		= ctype.component_name
			and		ctrl.control_type		= ctype.ctrl_type_name
			and		ctrl.customer_name		= @engg_customer_name
			and		ctrl.project_name		= @engg_project_name
			and		ctrl.process_name		= @tmp_proc
			and		ctrl.component_name		= @tmp_comp
			and 	activity_name			= @engg_ctrlatr_act_name
			and		ui_name					= @engg_ctrlatr_ui_name
			--and		base_ctrl_type			<>'Grid'
			   --Code added by the defect id : TECH-39352
	           and     base_ctrl_type not in ('Grid','Label')
	           and     control_type <> 'Label'
	           --Code added by the defect id : TECH-39352
			and		visisble_flag			= 'Y'
			and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection')
		End
		Else
		Begin
			Select	''		'engg_ctrlatr_list_pagnam',
					''		'engg_ctrlatr_list_synnam'
		End
	End
	if	@engg_ctrlatr_syn_typ	= 'Page'
	Begin
		Select	distinct
				page_bt_synonym		'engg_ctrlatr_list_pagnam',
				page_bt_synonym		'engg_ctrlatr_list_synnam'
		from	de_ui_page	(nolock)
		where 	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and 	activity_name		= @engg_ctrlatr_act_name
		and		ui_name				= @engg_ctrlatr_ui_name
	End
		if	@engg_ctrlatr_syn_typ	= 'Section'
	Begin
		Select	distinct
				page_bt_synonym		'engg_ctrlatr_list_pagnam',
				section_bt_synonym	'engg_ctrlatr_list_synnam'
		from	de_ui_section	(nolock)
		where 	customer_name		= @engg_customer_name
		and		project_name		= @engg_project_name
		and		process_name		= @tmp_proc
		and		component_name		= @tmp_comp
		and 	activity_name		= @engg_ctrlatr_act_name
		and		ui_name				= @engg_ctrlatr_ui_name
		and		visisble_flag		= 'Y'
		and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection','[tabcontrol]')-- TECH-74248 11537
	End
		if	@engg_ctrlatr_syn_typ	in ('Column','Cell')
	Begin
		
	
		If exists (	Select	distinct 'x'
					from	de_ui_grid	ctrl(nolock),
							es_comp_ctrl_type_mst	ctype(nolock)
					where 	ctrl.customer_name		= ctype.customer_name
					and		ctrl.project_name		= ctype.project_name
					and		ctrl.process_name		= ctype.process_name
					and		ctrl.component_name		= ctype.component_name
					and		ctrl.column_type		= ctype.ctrl_type_name
					and		ctrl.customer_name		= @engg_customer_name
					and		ctrl.project_name		= @engg_project_name
					and		ctrl.process_name		= @tmp_proc
					and		ctrl.component_name		= @tmp_comp
					and 	activity_name			= @engg_ctrlatr_act_name
					and		ui_name					= @engg_ctrlatr_ui_name
					and		visisble_flag			= 'Y'
					and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection'))
		Begin
			Select	distinct
					page_bt_synonym		'engg_ctrlatr_list_pagnam',
					column_bt_synonym	'engg_ctrlatr_list_synnam'
			from	de_ui_grid	ctrl(nolock),
					es_comp_ctrl_type_mst	ctype(nolock)
			where 	ctrl.customer_name		= ctype.customer_name
			and		ctrl.project_name		= ctype.project_name
			and		ctrl.process_name		= ctype.process_name
			and		ctrl.component_name		= ctype.component_name
			and		ctrl.column_type		= ctype.ctrl_type_name
			and		ctrl.customer_name		= @engg_customer_name
			and		ctrl.project_name		= @engg_project_name
			and		ctrl.process_name		= @tmp_proc
			and		ctrl.component_name		= @tmp_comp
			and 	activity_name			= @engg_ctrlatr_act_name
			and		ui_name					= @engg_ctrlatr_ui_name
			and		visisble_flag			= 'Y'
			and		section_bt_synonym		not in ('PrjhdnSection','hdnrt_stsection')
		End
		Else
		Begin
			Select	''		'engg_ctrlatr_list_pagnam',
					''		'engg_ctrlatr_list_synnam'
		End
	End

	/* 
	--OutputList
		Select
		null 'engg_ctrlatr_list_pagnam', 
		null 'engg_ctrlatr_list_synnam', 
	*/
	
Set nocount off

End





