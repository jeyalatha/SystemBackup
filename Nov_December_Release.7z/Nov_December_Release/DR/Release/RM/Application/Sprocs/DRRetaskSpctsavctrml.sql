IF EXISTS(SELECT 'X' From SYSOBJECTS WHERE NAME ='DRRetaskSpctsavctrml' AND TYPE='P')
   BEGIN
        DROP PROC DRRetaskSpctsavctrml
   END
GO 
/********************************************************************************
Created By 		Platform DB Extractor
Created Date 	24 Sep 2019
Purpose 		DRRetaskSpctsavctrml.sql
********************************************************************************/
/******************************************************************************/
/* Procedure					: DRRetaskSpctsavctrml								 */
/* Description					: 								 */
/******************************************************************************/
/* Project						: 								 */
/* EcrNo						: 								 */
/* Version						: 								 */
/******************************************************************************/
/* Referenced					: 								 */
/* Tables						: 								 */
/******************************************************************************/
/* Development history			: 								 */
/******************************************************************************/
/* modified by  : Veena U                                      					*/
/* date         : Nov 2 2015                                      				*/
/* BugId        : PLF2.0_15434                                          		*/
/********************************************************************************/
/* modified by  : Loganayaki P                                      					*/
/* date         : OCT 14 2016                                      				*/
/* BugId        : TECH-218 													*/
/********************************************************************************/
/* Modified by : Jeya Latha K/Ganesh Prabhu S	for callid TECH-7349				*/
/* Modified on : 14-03-2017				 											*/
/* Description :  New Base Control types RSAssorted, RSPivotGrid, RSTreeGrid and New Feature Organization chart */
/***********************************************************************************/
/* Modified by : Ganesh Prabhu S	for callid TECH-64915				*/
/* Modified on : 22-12-2021				 											*/
/* Description :  Case sensitive handling for propertytype in de_fw_des_ilbo_service_view_attributemap insertion */
/***********************************************************************************/
/************************************************************************************/
/* Modified by : Manoj S															*/
/* Modified on : 08-02-2022				 											*/
/* Defect	id : TECH-66012															*/ 
/************************************************************************************/
/* Modified by : Deepika S															*/
/* Modified on : 27-10-2022				 											*/
/* Defect	id : TECH-73522															*/ 
/************************************************************************************/
/* Modified by : Manoj S															*/
/* Modified on : 18-11-2022				 											*/
/* Defect	id : TECH-74729															*/ 
/************************************************************************************/
CREATE procedure DRRetaskSpctsavctrml
	@ctxt_ouinstance        	ctxt_ouinstance, --Input 
	@ctxt_user              	ctxt_user, --Input 
	@ctxt_language          	ctxt_language, --Input 
	@ctxt_service           	ctxt_service, --Input 
	@engg_component         	engg_description, --Input 
	@engg_ctrlatr_act_desc  	engg_description, --Input 
	@engg_ctrlatr_act_name  	engg_name, --Input 
	@engg_ctrlatr_dataitem  	engg_name, --Input 
	@engg_ctrlatr_pag_nam   	engg_name, --Input 
	@engg_ctrlatr_prop_nam  	engg_name, --Input 
	@engg_ctrlatr_seg_name  	engg_name, --Input 
	@engg_ctrlatr_syn_nam   	engg_name, --Input 
	@engg_ctrlatr_syn_typ   	engg_name, --Input 
	@engg_ctrlatr_task_desc 	engg_description, --Input 
	@engg_ctrlatr_task_name 	engg_name, --Input 
	@engg_ctrlatr_ui_desc   	engg_description, --Input 
	@engg_ctrlatr_ui_name   	engg_name, --Input 
	@engg_customer_name     	engg_name, --Input 
	@engg_ico_no            	engg_name, --Input 
	@engg_process_descr     	engg_description, --Input 
	@engg_project_name      	engg_name, --Input 
	@engg_service_name      	engg_name, --Input 
	@modeflag               	modeflag, --Input 
	@fprowno                	rowno, --Input/Output
	@m_errorid              	int output --To Return Execution Status
as
Begin
	-- nocount should be switched on to prevent phantom rows
	SET NOCOUNT ON
	-- @m_errorid should be 0 to Indicate Success
	SET @m_errorid = 0
	--declaration of temporary variables
	--temporary and formal parameters mapping
	SET @ctxt_user = ltrim(rtrim(@ctxt_user))
	SET @ctxt_service = ltrim(rtrim(@ctxt_service))
	SET @engg_component = ltrim(rtrim(@engg_component))
	SET @engg_ctrlatr_act_desc = ltrim(rtrim(@engg_ctrlatr_act_desc))
	SET @engg_ctrlatr_act_name = ltrim(rtrim(@engg_ctrlatr_act_name))
	SET @engg_ctrlatr_dataitem = ltrim(rtrim(@engg_ctrlatr_dataitem))
	SET @engg_ctrlatr_pag_nam = ltrim(rtrim(@engg_ctrlatr_pag_nam))
	SET @engg_ctrlatr_prop_nam = ltrim(rtrim(@engg_ctrlatr_prop_nam))
	SET @engg_ctrlatr_seg_name = ltrim(rtrim(@engg_ctrlatr_seg_name))
	SET @engg_ctrlatr_syn_nam = ltrim(rtrim(@engg_ctrlatr_syn_nam))
	SET @engg_ctrlatr_syn_typ = ltrim(rtrim(@engg_ctrlatr_syn_typ))
	SET @engg_ctrlatr_task_desc = ltrim(rtrim(@engg_ctrlatr_task_desc))
	SET @engg_ctrlatr_task_name = ltrim(rtrim(@engg_ctrlatr_task_name))
	SET @engg_ctrlatr_ui_desc = ltrim(rtrim(@engg_ctrlatr_ui_desc))
	SET @engg_ctrlatr_ui_name = ltrim(rtrim(@engg_ctrlatr_ui_name))
	SET @engg_customer_name = ltrim(rtrim(@engg_customer_name))
	SET @engg_ico_no = ltrim(rtrim(@engg_ico_no))
	SET @engg_process_descr = ltrim(rtrim(@engg_process_descr))
	SET @engg_project_name = ltrim(rtrim(@engg_project_name))
	SET @engg_service_name = ltrim(rtrim(@engg_service_name))
	SET @modeflag = ltrim(rtrim(@modeflag))

	--null checking
	IF @ctxt_ouinstance = - 915
		SELECT @ctxt_ouinstance = NULL

	IF @ctxt_user = '~#~'
		SELECT @ctxt_user = NULL

	IF @ctxt_language = - 915
		SELECT @ctxt_language = NULL

	IF @ctxt_service = '~#~'
		SELECT @ctxt_service = NULL

	IF @engg_component = '~#~'
		SELECT @engg_component = NULL

	IF @engg_ctrlatr_act_desc = '~#~'
		SELECT @engg_ctrlatr_act_desc = NULL

	IF @engg_ctrlatr_act_name = '~#~'
		SELECT @engg_ctrlatr_act_name = NULL

	IF @engg_ctrlatr_dataitem = '~#~'
		SELECT @engg_ctrlatr_dataitem = NULL

	IF @engg_ctrlatr_pag_nam = '~#~'
		SELECT @engg_ctrlatr_pag_nam = NULL

	IF @engg_ctrlatr_prop_nam = '~#~'
		SELECT @engg_ctrlatr_prop_nam = NULL

	IF @engg_ctrlatr_seg_name = '~#~'
		SELECT @engg_ctrlatr_seg_name = NULL

	IF @engg_ctrlatr_syn_nam = '~#~'
		SELECT @engg_ctrlatr_syn_nam = NULL

	IF @engg_ctrlatr_syn_typ = '~#~'
		SELECT @engg_ctrlatr_syn_typ = NULL

	IF @engg_ctrlatr_task_desc = '~#~'
		SELECT @engg_ctrlatr_task_desc = NULL

	IF @engg_ctrlatr_task_name = '~#~'
		SELECT @engg_ctrlatr_task_name = NULL

	IF @engg_ctrlatr_ui_desc = '~#~'
		SELECT @engg_ctrlatr_ui_desc = NULL

	IF @engg_ctrlatr_ui_name = '~#~'
		SELECT @engg_ctrlatr_ui_name = NULL

	IF @engg_customer_name = '~#~'
		SELECT @engg_customer_name = NULL

	IF @engg_ico_no = '~#~'
		SELECT @engg_ico_no = NULL

	IF @engg_process_descr = '~#~'
		SELECT @engg_process_descr = NULL

	IF @engg_project_name = '~#~'
		SELECT @engg_project_name = NULL

	IF @engg_service_name = '~#~'
		SELECT @engg_service_name = NULL

	IF @modeflag = '~#~'
		SELECT @modeflag = NULL

	IF @fprowno = - 915
		SELECT @fprowno = NULL

	SELECT @fprowno = @fprowno + 1

	DECLARE @tmp_proc engg_name,
		@tmp_comp engg_name,
		@sect_name engg_name,
		@ctrl_name engg_name,
		@cont_name engg_name,
		@ctrl_id engg_name,
		@view_name engg_name,
		@property engg_name,
		@suffix engg_name,
		@prop_type engg_name,
		@activityid engg_seqno

	SELECT @tmp_proc = process_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_descr = @engg_process_descr

	SELECT @tmp_comp = component_name
	FROM de_ui_ico NOLOCK
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND ico_no = @engg_ico_no
		AND process_name = @tmp_proc
		AND component_descr = @engg_component

	SELECT @activityid = activityid
	FROM de_fw_req_activity(NOLOCK)
	WHERE customer_name = @engg_customer_name
		AND project_name = @engg_project_name
		AND process_name = @tmp_proc
		AND activityname = @engg_ctrlatr_act_name

	-- Code modified for TECH-218 Starts
	/*code modified for TECH-66012 starts */
	/*
	IF @engg_ctrlatr_syn_typ = 'Section'
	BEGIN
		SELECT @prop_type = 'control'
	END
	ELSE
	BEGIN
		SELECT @prop_type = @engg_ctrlatr_syn_typ
	END
	*/
	Select @prop_type		= @engg_ctrlatr_syn_typ
	/*code modified for TECH-66012 ends */
	Select @prop_type		= @engg_ctrlatr_syn_typ
	SELECT @property = quick_code,
		@suffix = suffix
	FROM de_attribute_quick_code_met(NOLOCK)
	WHERE quick_code_value = @engg_ctrlatr_prop_nam

	IF @prop_type = 'Page'
	BEGIN
		SELECT @cont_name = @engg_ctrlatr_pag_nam,
			@ctrl_name = @engg_ctrlatr_pag_nam,
			@ctrl_id = @engg_ctrlatr_pag_nam,
			@view_name = @engg_ctrlatr_pag_nam,
			@engg_ctrlatr_syn_typ = 'tab'
	END

	IF @prop_type = 'Section'
	BEGIN
		SELECT @cont_name = @engg_ctrlatr_syn_nam,
			@ctrl_name = @engg_ctrlatr_syn_nam,
			@ctrl_id = @engg_ctrlatr_syn_nam,
			@view_name = @engg_ctrlatr_syn_nam,
			@engg_ctrlatr_syn_typ = 'control'
	END

	IF @prop_type = 'Control'
	BEGIN
		SELECT @cont_name = @engg_ctrlatr_syn_nam,
			@ctrl_name = @engg_ctrlatr_syn_nam,
			@ctrl_id = control_id,
			@view_name = view_name,
			@engg_ctrlatr_syn_typ = 'control'
		FROM de_ui_control(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @engg_ctrlatr_act_name
			AND ui_name = @engg_ctrlatr_ui_name
			AND control_bt_synonym = @engg_ctrlatr_syn_nam
	END

	IF @prop_type IN (
			'Column',
			'cell'
			)
	BEGIN
		SELECT @cont_name = @engg_ctrlatr_syn_nam,
			@ctrl_name = @engg_ctrlatr_syn_nam,
			@ctrl_id = control_id,
			@view_name = view_name,
			@engg_ctrlatr_syn_typ = @prop_type
		FROM de_ui_grid(NOLOCK)
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activity_name = @engg_ctrlatr_act_name
			AND ui_name = @engg_ctrlatr_ui_name
			AND column_bt_synonym = @engg_ctrlatr_syn_nam
	END

	-- Code modified for TECH-218 Ends
	IF @modeflag IN (
			'U',
			'Y'
			)
	BEGIN
		RAISERROR (
				'The data cannot be modified. Kindly Delete and proceed.Error at Row No. %d',
				16,
				1,
				@fprowno
				)

		RETURN
	END
	--TECH-74729 Starts
	IF @modeflag IN (
			'I',
			'X',
			'U',
			'Y'
			)
			begin
		
	 if ((isnull(@engg_ctrlatr_pag_nam,'') = '') or (isnull(@engg_ctrlatr_syn_nam,'')= ''))
	 begin
		RAISERROR (
				'Kindly choose the Page name and Control name.Error at Row No. %d',
				16,
				1,
				@fprowno
				)

		RETURN
		end
		end
		--TECH-74729 ends
	IF @modeflag IN ('D')
	BEGIN
		DELETE
		FROM de_fw_des_ilbo_service_view_attributemap
		WHERE customer_name = @engg_customer_name
			AND project_name = @engg_project_name
			AND process_name = @tmp_proc
			AND component_name = @tmp_comp
			AND activityid = @activityid
			AND ilbocode = @engg_ctrlatr_ui_name
			AND servicename = @engg_service_name
			AND taskname = @engg_ctrlatr_task_name
			AND segmentname = @engg_ctrlatr_seg_name
			AND dataitemname = @engg_ctrlatr_dataitem
			AND page_bt_synonym = @engg_ctrlatr_pag_nam
			AND Control_bt_synonym = @ctrl_name
			AND propertyname = @property
			AND propertytype = @engg_ctrlatr_syn_typ
			AND type = @prop_type
	END

	IF @modeflag IN (
			'I',
			'X'
			)
	BEGIN
		IF EXISTS (
				SELECT 'X'
				FROM de_fw_des_ilbo_service_view_attributemap(NOLOCK)
				WHERE customer_name = @engg_customer_name
					AND project_name = @engg_project_name
					AND process_name = @tmp_proc
					AND component_name = @tmp_comp
					AND activityid = @activityid
					AND ilbocode = @engg_ctrlatr_ui_name
					AND taskname = @engg_ctrlatr_task_name
					AND segmentname = @engg_ctrlatr_seg_name
					AND dataitemname = @engg_ctrlatr_dataitem
					AND page_bt_synonym = @engg_ctrlatr_pag_nam
					AND control_bt_synonym = @ctrl_name
					AND propertytype = @engg_ctrlatr_syn_typ
					AND propertyname = @property
					AND type = @prop_type
				)
		BEGIN
			RAISERROR (
					'Dataitem Name ''%s'', Synonym type ''%s'', Page Name: ''%s'', Synonym Name: ''%s'' and Property Name: ''%s'' combination already exists for the Action Name: ''%s'' and Segment Name: ''%s''.Error in Row %d.',
					16,
					1,
					@engg_ctrlatr_dataitem,
					@engg_ctrlatr_syn_typ,
					@engg_ctrlatr_pag_nam,
					@ctrl_name,
					@engg_ctrlatr_prop_nam,
					@engg_ctrlatr_task_name,
					@engg_ctrlatr_seg_name,
					@fprowno
					)

			RETURN
		END
		--------------Code Added against the Defect ID : TECH-73522----------------------
		If exists (
			 select 'X' from de_fw_des_ilbo_service_view_datamap b (nolock)
					where customer_name = @engg_customer_name
					and project_name	= @engg_project_name
					and process_name	= @tmp_proc
					and component_name	= @tmp_comp
					AND activityid		= @activityid
					AND ilbocode		= @engg_ctrlatr_ui_name
					and servicename		= @engg_service_name
					and segmentname		= @engg_ctrlatr_seg_name
					AND dataitemname	= @engg_ctrlatr_dataitem

					)
					begin
					 
				raiserror( 'The Dataitem  "%s" already involved in the Ilbo Mapping  .Either remove the mapping in "ILBO Service Data Association" Tab or associate new dataitem.',16,1,@engg_ctrlatr_dataitem)
				
					
			RETURN
		END
		---------------------Ends------------------------------------------------
		ELSE
		BEGIN
			INSERT INTO de_fw_des_ilbo_service_view_attributemap (
				customer_name,
				ilbocode,
				servicename,
				activityid,
				taskname,
				segmentname,
				dataitemname,
				project_name,
				process_name,
				component_name,
				activity_name,
				page_bt_synonym,
				control_bt_synonym,
				createdby,
				createddate,
				modifiedby,
				modifieddate,
				controlid,
				viewname,
				ecrno,
				PropertyType,
				PropertyName,
				type
				)
			VALUES (
				@engg_customer_name,
				@engg_ctrlatr_ui_name,
				@engg_service_name,
				@activityid,
				@engg_ctrlatr_task_name,
				@engg_ctrlatr_seg_name,
				@engg_ctrlatr_dataitem,
				@engg_project_name,
				@tmp_proc,
				@tmp_comp,
				@engg_ctrlatr_act_name,
				@engg_ctrlatr_pag_nam,
				@ctrl_name,
				@ctxt_user,
				getdate(),
				@ctxt_user,
				getdate(),
				@ctrl_id,
				@view_name,
				@engg_ico_no,
				UPPER(LEFT(@engg_ctrlatr_syn_typ,1))+LOWER(SUBSTRING(@engg_ctrlatr_syn_typ,2,LEN(@engg_ctrlatr_syn_typ))),				--TECH-64915,
				@property,
				@prop_type
				)
		END
	END

	SELECT @fprowno 'fprowno'

	/* 
	--OutputList
		Select
		null 'fprowno', 
	*/
	SET NOCOUNT OFF
END

GO
IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME= 'DRRetaskSpctsavctrml' AND TYPE='P')
BEGIN
	GRANT EXEC ON  DRRetaskSpctsavctrml TO PUBLIC
END
GO 