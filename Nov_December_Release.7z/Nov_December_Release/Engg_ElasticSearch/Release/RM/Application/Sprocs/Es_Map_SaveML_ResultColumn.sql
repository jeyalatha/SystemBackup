IF EXISTS  (SELECT 'X' FROM SYSOBJECTS WHERE NAME ='Es_Map_SaveML_ResultColumn' AND TYPE = 'P')
    Begin
        Drop PROC Es_Map_SaveML_ResultColumn
    End
GO

/****************************************************************************/
/* Procedure					: Es_Map_SaveML_ResultColumn				*/
/* Description					: 											*/
/****************************************************************************/
/* Author						: 								            */
/* Date							: Mar 19 2020  4:45PM						*/
/****************************************************************************/
/* Modification History			: 								            */
/****************************************************************************/
/* Modified by : Jeya Latha K   Date: 14-Jul-2020  Defect ID : TECH-47978	*/
/****************************************************************************/
/* Modified by : Ganesh Prabhu S Date: 01-Nov-2022  Defect ID : TECH-74112	*/
/****************************************************************************/
CREATE PROCEDURE Es_Map_SaveML_ResultColumn
	   @ctxt_ouinstance             ctxt_ouinstance,
       @ctxt_user                   ctxt_user,
       @ctxt_language               ctxt_language,
       @ctxt_service                ctxt_service,
	   @ctxt_role					ctxt_role,
	   @CustomerName				engg_name,
	   @ProjectName					engg_name,
	   @Reqno						engg_name,
	   @ProcessName					engg_name,
	   @ComponentName				engg_name,
	   @ActivityName				engg_name,
	   @UIName						engg_name,
	   @ListControlSynonym			engg_name,				
	   @ListControlID				engg_name,
	   @ListViewName				engg_name,
	   @QueryTemplateid				engg_name,
	   @ResultColumnName			engg_name,
	   @ParameterCaption			engg_description,
	   @IsVisible					engg_flag,
	   @Width						engg_Seqno,
	   @MappedControlID				engg_name,
	   @MappedViewName				engg_name,
	   @sequenceno					engg_Seqno,
	   @Modeflag					engg_flag,
	   @fprowno						rowno,
	   @m_errorid                   INT OUTPUT
AS  
BEGIN  

SET NOCOUNT ON  
	
	DECLARE		@sysdate	engg_datetime,
				@MappedSynonym	engg_name,
				@tmp_visible	engg_flag

	SELECT		@sysdate	= Getdate()
	SELECT		@fprowno	=	@fprowno + 1
	SELECT		@Reqno		= 'BASE'

	--IF ISNULL(@MappedControlID, '') = ''
	--BEGIN
	--	RAISERROR('Mapped Control ID can not be blank.'
	--END

	IF ISNULL(@IsVisible, 0)	=	0
		SELECT @tmp_visible		=	'N'
	IF ISNULL(@IsVisible, 0)	=	1
		SELECT @tmp_visible		=	'Y'

	SELECT	@ListControlSynonym	=	rtrim(Control_bt_synonym)
	FROM	ep_ui_control_dtl (nolock)
	WHERE	Customer_Name		=	rtrim(@Customername)
	AND		Project_Name			=	rtrim(@ProjectName)
	AND		process_name			=	rtrim(@ProcessName)
	AND		component_name		=	rtrim(@ComponentName)
	AND		activity_name		=   rtrim(@ActivityName)		
	AND		ui_name				=	rtrim(@UIName)
	AND		Control_ID			=	rtrim(@ListControlID)
	AND		View_name			=	rtrim(@ListViewname)

	IF ISNULL(@ListControlSynonym,'')	=	''
	BEGIN
		SELECT	@ListControlSynonym	=	rtrim(Column_bt_synonym)
		FROM	ep_ui_grid_dtl (nolock)
		WHERE	Customer_Name		=	rtrim(@Customername)
		AND		Project_Name		=	rtrim(@ProjectName)
		AND		process_name		=	rtrim(@ProcessName)
		AND		component_name		=	rtrim(@ComponentName)
		AND		activity_name		=   rtrim(@ActivityName)		
		AND		ui_name				=	rtrim(@UIName)
		AND		Control_ID			=	rtrim(@ListControlID)
		AND		View_name			=	rtrim(@ListViewname)
	END

	SELECT	@MappedSynonym		=	rtrim(Control_bt_synonym)
	FROM	ep_ui_control_dtl (nolock)
	WHERE	Customer_Name		=	rtrim(@Customername)
	AND		Project_Name		=	rtrim(@ProjectName)
	AND		process_name		=	rtrim(@ProcessName)
	AND		component_name		=	rtrim(@ComponentName)
	AND		activity_name		=   rtrim(@ActivityName)		
	AND		ui_name				=	rtrim(@UIName)
	AND		Control_ID			=	rtrim(@MappedControlID)
	AND		View_name			=	rtrim(@MappedViewName)

	IF ISNULL(@MappedSynonym,'')	=	''
	BEGIN
		SELECT	@MappedSynonym		=	rtrim(Column_bt_synonym)
		FROM	ep_ui_grid_dtl (nolock)
		WHERE	Customer_Name		=	rtrim(@Customername)
		AND		Project_Name		=	rtrim(@ProjectName)
		AND		process_name		=	rtrim(@ProcessName)
		AND		component_name		=	rtrim(@ComponentName)
		AND		activity_name		=   rtrim(@ActivityName)		
		AND		ui_name				=	rtrim(@UIName)
		AND		Control_ID			=	rtrim(@MappedControlID)
		AND		View_name			=	rtrim(@MappedViewName)
	END

	IF ISNULL(@MappedSynonym,'')	=	''
	BEGIN
		SELECT	@MappedSynonym		=	rtrim(hidden_view_bt_synonym)
		FROM	de_hidden_view (nolock)
		WHERE	Customer_Name		=	rtrim(@Customername)
		AND		Project_Name		=	rtrim(@ProjectName)
		AND		process_name		=	rtrim(@ProcessName)
		AND		component_name		=	rtrim(@ComponentName)
		AND		activity_name		=   rtrim(@ActivityName)		
		AND		ui_name				=	rtrim(@UIName)
		AND		Control_ID			=	rtrim(@MappedControlID)
		AND		View_name			=	rtrim(@MappedViewName)
	END

-- Code Added for the Defect ID: TECH-47978 Starts
	IF ISNULL(@ParameterCaption,'') = ''
			BEGIN
				RAISERROR('Kindly specify the caption for the column: %s',16,1,@ParameterCaption)
				RETURN
			END

		IF @ParameterCaption LIKE '%#%' OR @ParameterCaption LIKE '%~%'
		BEGIN
			RAISERROR('Special characters(# or ~) is not allowed as column caption: %s',16,1,@ParameterCaption) --TECH-74112
			RETURN
		END 


	IF @Modeflag IN ('I', 'X', 'U', 'Y') --AND ISNULL(@MappedControlID, '') <> '' AND ISNULL(@MappedViewName, '') <> ''
	BEGIN

	--IF EXISTS (SELECT 'X'
	--FROM	ep_els_query_listedit_result (nolock)
	--WHERE	CustomerName		=	rtrim(@Customername)
	--AND		ProjectName			=	rtrim(@ProjectName)
	--AND		processname			=	rtrim(@ProcessName)
	--AND		componentname		=	rtrim(@ComponentName)
	--AND		activityname		=   rtrim(@ActivityName)		
	--AND		uiname				=	rtrim(@UIName)
	--AND		ListControlID		=	rtrim(@ListControlID)
	--AND		ListViewname		=	rtrim(@ListViewname)
	--AND		QueryID				=	rtrim(@QueryTemplateid)
	--AND		Reqno				=	rtrim(@Reqno)
	--AND		ResultColumnName	=	'*'
	--)
	--BEGIN
	--		RAISERROR ('Other Parameters are not allowed since already ''*'' mapped to this Query ID.', 16 1)
	--		RETURN	
	--END

	IF NOT EXISTS (SELECT 'X'
	FROM	ep_els_query_listedit_result (nolock)
	WHERE	CustomerName		=	rtrim(@Customername)
	AND		ProjectName			=	rtrim(@ProjectName)
	AND		processname			=	rtrim(@ProcessName)
	AND		componentname		=	rtrim(@ComponentName)
	AND		activityname		=   rtrim(@ActivityName)		
	AND		uiname				=	rtrim(@UIName)
	AND		ListControlID		=	rtrim(@ListControlID)
	AND		ListViewname		=	rtrim(@ListViewname)
	AND		QueryID				=	rtrim(@QueryTemplateid)
	AND		Reqno				=	rtrim(@Reqno)
	AND		ResultColumnName	=	rtrim(@ResultColumnName)
	)
	BEGIN
	
			INSERT INTO ep_els_query_listedit_result 
					(CustomerName,			ProjectName,			Reqno,				ProcessName,
					ComponentName,			ActivityName,			UiName,				ListControlSynonym,
					ListControlID,			ListViewname,			QueryID,			ResultColumnName,
					MappedSynonym,			MappedControlID,		MappedViewName,		ParameterCaption,
					Width,					IsVisible,				Createdby,			Createddate,			
					Modifedby,				Modifieddate,			seqno)
			SELECT
					@Customername,			@ProjectName,			@Reqno,				@ProcessName,
					@ComponentName,			@ActivityName,			@UIName,			@ListControlSynonym,
					@ListControlID,			@ListViewname,			@QueryTemplateid,	@ResultColumnName,
					@MappedSynonym,			@MappedControlID,		@MappedViewName,	@ParameterCaption,
					@Width,					@tmp_visible,			@ctxt_user,			@sysdate,				
					@ctxt_user,				@sysdate,				@sequenceno
	END
	ELSE
	BEGIN
		UPDATE ep_els_query_listedit_result SET 
								MappedControlID		=	@MappedControlID,
								MappedViewName		=	@MappedViewName,
								ParameterCaption	=	@ParameterCaption,
								Width				=	@Width,
								IsVisible			=	@tmp_visible,
								Modifedby			=	@ctxt_user,
								Modifieddate		=	@sysdate,
								seqno				=	@sequenceno
		WHERE	CustomerName		=	rtrim(@Customername)
		AND		ProjectName			=	rtrim(@ProjectName)
		AND		processname			=	rtrim(@ProcessName)
		AND		componentname		=	rtrim(@ComponentName)
		AND		activityname		=   rtrim(@ActivityName)		
		AND		uiname				=	rtrim(@UIName)
		AND		ListControlID		=	rtrim(@ListControlID)
		AND		ListViewname		=	rtrim(@ListViewname)
		AND		QueryID				=	rtrim(@QueryTemplateid)
		AND		Reqno				=	rtrim(@Reqno)
		AND		ResultColumnName	=	rtrim(@ResultColumnName)
	END
	END

-- Code Added for the Defect ID: TECH-47978 Starts
	IF (ISNULL(@Width,''))=0  
	 BEGIN
		  UPDATE ep_els_query_listedit_result SET 
								width	=	300
			WHERE	CustomerName		=	rtrim(@Customername)
			AND		ProjectName			=	rtrim(@ProjectName)
			AND		processname			=	rtrim(@ProcessName)
			AND		componentname		=	rtrim(@ComponentName)
			AND		activityname		=   rtrim(@ActivityName)		
			AND		uiname				=	rtrim(@UIName)
			AND		ListControlID		=	rtrim(@ListControlID)
			AND		ListViewname		=	rtrim(@ListViewname)
			AND		QueryID				=	rtrim(@QueryTemplateid)
			AND		Reqno				=	rtrim(@Reqno)
			AND		ResultColumnName	=	rtrim(@ResultColumnName)
	END
-- Code Added for the Defect ID: TECH-47978 Ends
	IF @Modeflag = 'D' --OR (ISNULL(@MappedControlID, '') = '' AND ISNULL(@MappedViewName,'') = '' ))
	BEGIN
		DELETE 
		FROM	ep_els_query_listedit_result
		WHERE	CustomerName		=	rtrim(@Customername)
		AND		ProjectName			=	rtrim(@ProjectName)
		AND		processname			=	rtrim(@ProcessName)
		AND		componentname		=	rtrim(@ComponentName)
		AND		activityname		=   rtrim(@ActivityName)		
		AND		uiname				=	rtrim(@UIName)
		AND		ListControlID		=	rtrim(@ListControlID)
		AND		ListViewname		=	rtrim(@ListViewname)
		AND		QueryID				=	rtrim(@QueryTemplateid)
		AND		Reqno				=	rtrim(@Reqno)
		AND		ResultColumnName	=	rtrim(@ResultColumnName)
	END
SET NOCOUNT OFF  

END 
GO

IF EXISTS ( SELECT 'Y' FROM SYSOBJECTS WHERE NAME = 'Es_Map_SaveML_ResultColumn' AND TYPE = 'P')
	GRANT EXEC ON Es_Map_SaveML_ResultColumn TO PUBLIC
GO

