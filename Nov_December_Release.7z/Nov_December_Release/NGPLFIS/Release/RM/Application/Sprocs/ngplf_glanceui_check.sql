IF EXISTS(SELECT 'X' FROM SYSOBJECTS WHERE NAME ='ngplf_GlanceUI_Check' AND TYPE='P')
   BEGIN
        DROP PROC ngplf_GlanceUI_Check
   END
GO 
/********************************************************************************/
/* Procedure					: To check whether the incoming UI is in Glance	*/
/* Description					:												*/
/*																				*/
/********************************************************************************/
/* Development history			: 												*/
/********************************************************************************/
/* Author						: 												*/
/* Date							:												*/
/********************************************************************************/
/* Modification History			: 												*/
/********************************************************************************/
/* Modified by  : Jeya Latha K/Venkatesan K	Date: 31-Oct-2018  Defect ID : TECH-28010 */  
/**************************************************************************************/
/* Modified by  : Venkatesan K	Date: 08-Nov-2022  Defect ID : TECH-75230			  */
/**************************************************************************************/
CREATE PROCEDURE ngplf_GlanceUI_Check
	@ctxt_language				NGPLF_CTXT_LANGUAGE,
	@ctxt_ouinstance			NGPLF_CTXT_OUINSTANCE,
	@ctxt_user					NGPLF_CTXT_USER,
	@ctxt_service_in			NGPLF_CTXT_service,
	@engg_customer_name_io		NGPLF_NAME,
	@engg_project_name_io		NGPLF_NAME,
	@engg_process_descr_io		NGPLF_caption,
	@engg_component_io			NGPLF_caption,
	@engg_req_no_io				NGPLF_caption,
	@engg_act_descr_io			NGPLF_caption,
	@engg_ui_descr_io			NGPLF_caption
AS
BEGIN	
SET NOCOUNT ON

--Temporary parameter declareation
		declare @tmp_customer_name		NGPLF_NAME,			@tmp_project_name		NGPLF_NAME,		@tmp_process_name			NGPLF_caption,
				@tmp_component_name		NGPLF_caption,		@tmp_req_no				NGPLF_NAME,		@tmp_activity_name			NGPLF_caption,
				@tmp_ui_name			NGPLF_caption,		@IsGlanceUI				NGPLF_NAME

		select	@tmp_customer_name	=	a.customer_name,
				@tmp_project_name	=	a.project_name,
				@tmp_process_name	=	a.process_name,
				@tmp_component_name	=	a.component_name,
				@tmp_activity_name	=	a.activity_name,
				@tmp_ui_name		=	a.ui_name,
				@tmp_req_no			=	b.req_no,
				@IsGlanceUI			=	IsGlance
		from	ep_ui_mst a(nolock),
				ep_ui_req_dtl b(nolock)
		WHere	b.customer_name		=	@engg_customer_name_io
		AND		b.project_name		=	@engg_project_name_io
		AND		b.process_descr		=	@engg_process_descr_io
		AND		b.component_descr	=	@engg_component_io
		AND		b.activity_descr	=	@engg_act_descr_io
		AND		b.ui_descr			=	@engg_ui_descr_io
		AND		b.req_no			=	@engg_req_no_io
		
		AND		a.customer_name		=	b.customer_name
		AND		a.project_name		=	b.project_name
		AND		a.process_name		=	b.process_name
		AND		a.component_name	=	b.component_name
		AND		a.activity_name		=	b.activity_name
		AND		a.ui_name			=	b.ui_name

	--TECH-75230
	IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'inf_req_rule_ilbo_details' AND TYPE IN ('U','V'))
	BEGIN  
		IF EXISTS ( SELECT 'X'
					FROM	fw_req_ilbo_rule_group (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END

			IF EXISTS ( SELECT 'X'
					FROM	fw_req_ilbo_rule_template (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END

			IF EXISTS ( SELECT 'X'
					FROM	inf_req_rule_ilbo_details (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END  
		END
		
		IF EXISTS (SELECT 'X' FROM SYSDATABASES WHERE NAME = 'iRuleDB'  ) AND ISNULL(@StateDesignType,'') = ''
		BEGIN 
					IF EXISTS ( SELECT 'X'
					FROM	iRuleDB..fw_req_ilbo_rule_group (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END

			IF EXISTS ( SELECT 'X'
					FROM	iRuleDB..fw_req_ilbo_rule_template (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END

			IF EXISTS ( SELECT 'X'
					FROM	iRuleDB..inf_req_rule_ilbo_details (NOLOCK)
					WHERE	CustomerName		=	@tmp_customer_name
					AND		ProjectName			=	@tmp_project_name
					AND		ComponentName		=	@tmp_component_name
					AND		ILBOCode			=	@tmp_ui_name )
					BEGIN
						SET @StateDesignType	=	'IRule'
					END  
		END 
		
		IF EXISTS (SELECT 'X' FROM SYSOBJECTS WHERE NAME = 'ep_ui_state_dtl' AND TYPE IN ('U','V'))  AND ISNULL(@StateDesignType,'') = ''
		BEGIN  
				IF EXISTS ( SELECT 'X'
				FROM	ep_ui_state_dtl (NOLOCK)
				WHERE	Customer_Name		=	@tmp_customer_name
				AND		Project_Name		=	@tmp_project_name
				AND		process_name		=	@tmp_process_name
				AND		Component_Name		=	@tmp_component_name
				AND		Activity_Name		=	@tmp_activity_name
				AND		UI_Name				=	@tmp_ui_name )
				BEGIN 	
					SET @StateDesignType	=	'RTState'
				END 
		END
		--TECH-75230
	SELECT	@tmp_customer_name		'Customer Name',
				@tmp_project_name		'Project Name', 
				@tmp_process_name		'Process Name', 
				@tmp_component_name 	'Component Name',
				@tmp_activity_name		'Activity Name',	
				@tmp_ui_name			'UI Name',			
				@tmp_req_no				'Request No.',		
				@IsGlanceUI				'IsGlanceUI'


SET NOCOUNT OFF
END 
--GO

--IF EXISTS( SELECT 'Y' FROM sysobjects WHERE name = 'ngplf_GlanceUI_Check' AND TYPE = 'P')
--	GRANT EXEC ON ngplf_GlanceUI_Check TO PUBLIC
--GO